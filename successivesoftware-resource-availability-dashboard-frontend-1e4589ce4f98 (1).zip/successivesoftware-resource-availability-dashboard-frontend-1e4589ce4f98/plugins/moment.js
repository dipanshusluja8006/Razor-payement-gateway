import Vue from 'vue'
import moment from 'moment'

/**
 * Date library momentjs
 * https://momentjs.com/
 */
Vue.prototype.$moment = moment
