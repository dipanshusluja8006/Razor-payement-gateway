import axios from 'axios'
import firebase from 'firebase/app'
import constant from '../constants/closure-checklist'

export default (ctx, inject) => {
  const resourceApi = axios.create({
    baseURL: process.env.RESOURCE_API_URL
  })
  // for unauthorized token issue
  const expiryDate = ctx.store.getters['auth/getExpiry']

  // check if access token has expired and set a new one if expired
  firebase.auth().onAuthStateChanged(async (user) => {
    if (user) {
      const token = await user.getIdToken()

      await ctx.store.commit('auth/setTokenId', token, { root: true })
    }
  })
  // Request interceptor for APIs V1
  resourceApi.interceptors.request.use(async (config) => {
    config.headers.Authorization = await ctx.store.getters['auth/tokenId']
    config.headers.post['Content-Type'] = 'application/json'
    config.headers.post.Accept = 'application/json, text/plain, */*'
    const { url } = config

    if (url === '/invoice-status' || url === '/resource-summary' || url === '/timesheet-summary') {
      ctx.store.dispatch('project/updateOverlayAction', false)
    }
    ctx.store.dispatch('project/updateOverlayAction', true)
    if (new Date() > new Date(expiryDate) || expiryDate === '') {
      firebase.auth().onAuthStateChanged(async (user) => {
        if (user) {
          const token = await user.getIdToken()

          await ctx.store.commit('auth/setTokenId', token, { root: true })
        }
      })
    }

    return config
  }, (err) => {
    return Promise.reject(err)
  })

  // Response interceptor for APIs V1
  resourceApi.interceptors.response.use((response) => {
    ctx.store.dispatch('project/updateOverlayAction', false)

    return response
  }, (error) => {
    ctx.store.dispatch('project/updateOverlayAction', false)
    let errorResponse = {}
    const { response } = error || {}
    const { status } = response || 0

    switch (status) {
    case 422:
      // code block
      errorResponse = {
        data: {},
        status: true,
        title: 'Error',
        message: constant.ERROR_MESSAGES.VALIDATION_ERROR,
        errormessage: error,
        nextRoute: constant.ROUTES.PROJECT_DASHBOARD_ROUTE
      }// message = 'Validation Error.'
      break
    case 401:
      // code block
      errorResponse = {
        data: {},
        status: true,
        title: 'Error',
        message: constant.ERROR_MESSAGES.AUTHORIZATION_ERROR,
        errormessage: error,
        nextRoute: constant.ROUTES.PROJECT_DASHBOARD_ROUTE
      }//  message = 'Unauthorized.'
      break
    default:
      // code block
      errorResponse = {
        data: {},
        status: true,
        title: 'Error',
        message: constant.ERROR_MESSAGES.SOMETHING_WRONG_ERROR,
        nextRoute: constant.ROUTES.PROJECT_DASHBOARD_ROUTE
      }
    }
    if (status === 401) {
      firebase.auth().onAuthStateChanged(async (user) => {
        if (user) {
          const token = await user.getIdToken()

          await ctx.store.commit('auth/setTokenId', token, { root: true })
          // this.$router.push('/login')
          window.location.reload(true)
        }
      })
    }

    return Promise.resolve(errorResponse)
  })

  inject('resourceApi', resourceApi)

  const resourceApiV3 = axios.create({
    baseURL: process.env.PROJECT_API_URL
  })

  // Request interceptor for APIs V3
  resourceApiV3.interceptors.request.use(async (config) => {
    config.headers.Authorization = await ctx.store.getters['auth/tokenId']
    config.headers.post['Content-Type'] = 'application/json'
    config.headers.post.Accept = 'application/json, text/plain, */*'
    ctx.store.dispatch('project/updateOverlayAction', true)
    if (new Date() > new Date(expiryDate) || expiryDate === '') {
      firebase.auth().onAuthStateChanged(async (user) => {
        if (user) {
          const token = await user.getIdToken()

          await ctx.store.commit('auth/setTokenId', token, { root: true })
        }
      })
    }

    return config
  }, (err) => {
    return Promise.reject(err)
  })
  // Response interceptor for APIs V3
  resourceApiV3.interceptors.response.use((response) => {
    ctx.store.dispatch('project/updateOverlayAction', false)

    return response
  }, (error) => {
    ctx.store.dispatch('project/updateOverlayAction', false)
    let errorResponse = {}
    const { response } = error || {}
    const { status } = response || 0

    switch (status) {
    case 422:
    // code block
      errorResponse = {
        data: {},
        status: true,
        title: 'Error',
        message: constant.ERROR_MESSAGES.VALIDATION_ERROR,
        errormessage: error,
        nextRoute: constant.ROUTES.PROJECT_DASHBOARD_ROUTE
      }// message = 'Validation Error.'
      break
    case 401:
    // code block
      errorResponse = {
        data: {},
        status: true,
        title: 'Error',
        message: constant.ERROR_MESSAGES.AUTHORIZATION_ERROR,
        errormessage: error,
        nextRoute: constant.ROUTES.PROJECT_DASHBOARD_ROUTE
      }//  message = 'Unauthorized.'
      break
    default:
    // code block
      errorResponse = {
        data: {},
        status: true,
        title: 'Error',
        message: constant.ERROR_MESSAGES.SOMETHING_WRONG_ERROR,
        nextRoute: constant.ROUTES.PROJECT_DASHBOARD_ROUTE
      }
    }
    if (status === 401) {
      firebase.auth().onAuthStateChanged(async (user) => {
        if (user) {
          const token = await user.getIdToken()

          await ctx.store.commit('auth/setTokenId', token, { root: true })
          // this.$router.push('/login')
          window.location.reload(true)
        }
      })
    }

    return Promise.resolve(errorResponse)
  })
  inject('resourceApiV3', resourceApiV3)

  const formattedDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    })
  }

  inject('formatDate', formattedDate)

  const getInitialEndDate = () => {
    const todaysDate = new Date()
    const endDate = new Date(Date.UTC(todaysDate.getFullYear(), todaysDate.getMonth() + 2, todaysDate.getDate()))
    const formatedDate = endDate.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })
    const formattedStringDate = endDate.toISOString().substr(0, 10)

    return { formatedDate, formattedStringDate }
  }

  inject('getInitialEndDate', getInitialEndDate)
}
