import Vue from 'vue'
import { ValidationProvider, ValidationObserver, extend } from 'vee-validate'
import {
  required,
  email,
  max,
  alpha,
  alpha_num as alphaNum,
  alpha_spaces as alphaSpaces,
  numeric,
  regex,
  ext,
  between
} from 'vee-validate/dist/rules'

// Register it globally
extend('required', {
  ...required,
  message: 'This field is required'
})

extend('between', {
  ...between,
  message: 'This field must be greater than 0 and less than {max}'
})

extend('max', {
  ...max,
  message: 'This field must be {length} characters or less'
})

extend('email', {
  ...email,
  message: 'This field must be a valid email'
})
extend('ext', {
  ...ext,
  message: 'File types must be in (jpg, jpeg, png, pdf, docx, doc, xlsx, xls, zip) only'
})

extend('min', {
  validate (value, args) {
    return value.length >= args.length
  },
  params: ['length']
})
extend('alpha', {
  ...alpha,
  message: 'This field must contain alphabets'
})

extend('alpha_num', {
  ...alphaNum,
  message: 'This field must contain alpha numeric'
})

extend('alpha_spaces', {
  ...alphaSpaces,
  message: 'This field must contain alphabet and spaces'
})

extend('numeric', {
  ...numeric,
  message: 'This field required only positive integer value'
})
extend('regex', {
  ...regex,
  message: 'This field required only positive number value'
})
extend('min', {
  validate (value, args) {
    return value.length >= args.length
  },
  params: ['length']
})
extend('counter', {
  validate (value, args) {
    return value.length <= args.length
  },
  params: ['length'],
  message: 'You can upload maximum 3 files only'
})
extend('alpha_num_whitespace', {
  validate (value) {
    const re = /^[\w|\s|\d]/
    const matches = value.match(re) // = null

    if (matches === null || !matches.length) { // Error: Cannot read property 'length' of null
      return false
    }

    return true
  },
  message: 'This value must be word, digit, whitespace and cannot start with special characters.'
})

extend('alpha_num_whitespace_special', {
  validate (value) {
    const re = /^[a-zA-Z0-9!@#"}{|?/$:;%\\^&*)(+=. _'-s]*$/
    const matches = value.match(re) // = null

    if (matches === null || !matches.length) { // Error: Cannot read property 'length' of null
      return false
    }

    return true
  },
  message: 'This value must be word, digit, whitespace and special characters'
})

extend('alpha_num_whitespace_special_line_break', {
  validate (value) {
    const re = /^[a-zA-Z0-9!@#"}{|?/$:/\n/;%\\^&*)(+=. _'-s]*$/
    const matches = value.match(re) // = null

    if (matches === null || !matches.length) { // Error: Cannot read property 'length' of null
      return false
    }

    return true
  },
  message: 'This value must be word, digit, whitespace and special characters'
})

extend('required_checkbox', {
  validate (value) {
    if (value === false) { // Error: Cannot read property 'length' of null
      return false
    }

    return true
  },
  message: 'Checkbox must be checked.'
})

extend('check_efforts', {
  validate (value) {
    if (parseFloat(value) < 0.1) {
      return false
    } else if (parseFloat(value) === 8 && value !== '8.' && /^[0-9]*[.]?[0-9]*$/.test(value)) {
      return true
    }
    const regexQuery = /^((\s*([0-7])(\.[0-9]{1,2})?\s*)|(\s*8\s*))$/
    const url = new RegExp(regexQuery, 'i')

    return url.test(value)
  },
  message: 'Please input between 1-8.'
})

extend('check_deallocate_efforts', {
  validate (value) {
    if (parseFloat(value) < 0.1) {
      return false
    } else if (parseFloat(value) === 8 && value !== '8.' && /^[0-9]*[.]?[0-9]*$/.test(value)) {
      return true
    }
    const regexQuery = /^((\s*([0-7])(\.[0-9]{1,2})?\s*)|(\s*8\s*))$/
    const url = new RegExp(regexQuery, 'i')

    return url.test(value)
  },
  message: 'Please input valid efforts upto 2 decimal'
})

extend('check_experience', {
  validate (value) {
    const regexQuery = /^((\s*(([0-9]|1[0-9]|2[0-9]|3[0-4])(\.[0-9]{1,2})?)\s*)|(\s*35\s*))$/
    const url = new RegExp(regexQuery, 'i')

    return url.test(value)
  },
  message: 'Please input valid experience between 0-35 and upto 2 decimal.'
})

extend('check_experience_range', {
  validate (value) {
    const regexQuery = /^((\s*(([0-9]|1[0-9]|2[0-9]|3[0-4])(\.[0-9]{1,2})?)\s*)|(\s*35\s*))$/
    const url = new RegExp(regexQuery, 'i')

    return url.test(value)
  },
  message: 'Please input valid experience between 0-35 and upto 2 digits.'
})

extend('check_url', {
  validate (value) {
    const regexQuery = '^(https?://)?(www\\.)?([-a-z0-9]{1,63}\\.)*?[a-z0-9][-a-z0-9]{0,61}[a-z0-9]\\.[a-z]{2,6}(/[-\\w@\\+\\.~#\\?&/=%]*)?$'
    const url = new RegExp(regexQuery, 'i')

    return url.test(value)
  },
  message: 'This value must be a valid URL.'
})
Vue.component('ValidationProvider', ValidationProvider)
Vue.component('ValidationObserver', ValidationObserver)
