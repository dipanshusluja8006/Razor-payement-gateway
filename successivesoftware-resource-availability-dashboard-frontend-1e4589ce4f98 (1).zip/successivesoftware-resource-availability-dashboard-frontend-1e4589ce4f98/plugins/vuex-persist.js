import VuexPersistence from 'vuex-persist'

export default ({ store }) => {
  new VuexPersistence({
    storage: window.localStorage,
    reducer: (state) => ({
      auth: state.auth,
      project: {
        newProject: state.project.newProject,
        technology: state.project.technology,
        department: state.project.department,
        billingTypes: state.project.billingTypes,
        billingMediums: state.project.billingMediums,
        // projectList: state.project.projectList,
        // projectDetail: state.project.projectDetail,
        users: state.project.users,
        customDialog: state.project.customDialog,
        projectSearchString: state.project.projectSearchString,
        projectWsrDefaultFilter: state.project.projectWsrDefaultFilter,
        projectType: state.project.projectType,
        governanceCategories: state.project.governanceCategories,
        projectNames: state.project.projectNames,
        activityProjectType: state.project.activityProjectType,
        projectActivityLog: state.project.projectActivityLog,
        activityLogAccordion: state.project.activityLogAccordion,
        projectDashboardPagination: state.project.projectDashboardPagination,
        projectReport: state.project.projectReport,
        directCreatedAllocation: state.project.directCreatedAllocation
      },
      dashboard: {
        locations: state.dashboard.locations,
        invoiceSummary: state.dashboard.invoiceSummary,
        resourceSummary: state.dashboard.invoiceSummary,
        timesheetSummary: state.dashboard.timesheetSummary
      },
      roles: {
        globalRole: state.roles.globalRole,
        hasProjectDashboardAccess: state.roles.hasProjectDashboardAccess,
        hasProjectInititationAccess: state.roles.hasProjectInititationAccess,
        hasGlobalTeam: state.roles.hasGlobalTeam,
        rolesAvailable: state.roles.rolesAvailable
      }
    })
    /* your options */
  }).plugin(store)
}
