const PROJECT_MANAGEMENT = [
  'Every line of code is pushed on dev/staging/prod environment  - After Payment confirmation from BD/Accounts team',
  'Product is demonstrated to the client and the client has accepted the product.',
  'Hours are logged properly in respective project boards and tools',
  'Test accounts are deleted from the live system if there will not be any support required',
  'Successive SMTP/SMS API/Hosting accounts ETC are removed from the system',
  'Client’s hosting and other accounts are enabled and checked',
  'Training is given to the client to use Admin/feature or any other thing in the system',
  'The project board(JIRA/Redmine/Slack ETC) is closed and resources are free from that particular project.',
  'The respective  RMs for the resources are informed about the resource alignment',
  'All the stakeholders are well informed about the project closure',
  'Post closure support plan is ready in case it is required'
]

const POST_BILLING_CONFIRMATION = [
  'Requirement documents (BRs/FRs/Stories/CRs)',
  'Release notes (technical/functional)',
  'Deployment documents',
  'User Manual',
  'Test cases',
  'UAT documents',
  'Effort sheet (billing related information) - Tentative',
  'Design/branding guidelines',
  'Mockups',
  'Actual designs and source files',
  'HTML and Code files',
  'Repository/branch and related access',
  'Test accounts and credentials',
  'Admin panel URL and related access',
  'Server details and required access',
  'License related information (if any)',
  'Feedback form  - This is mandatory and only then things will be moved forward.'
]

const RECEIVING_FROM_CLIENT = [
  'Sign off on all the milestones of the project.',
  'Filled feedback form',
  'Post closure support plan/requirements'
]

const PROJECT_STATUS = {
  NEW: 1,
  CREATION: 2,
  ON_HOLD: 12,
  CLOSED: 13,
  RESOURCE_ALLOCATION_RESPONSE_APPROVE: 14,
  RESOURCE_ALLOCATION_RESPONSE_DECLINE: 15,
  REQUISITION: 3,
  ALLOCATION_APPROVAL_REQUESTED: 4,
  ALLOCATION_DECLINED: 6,
  DEALLOCATION_REQUESTED: 8,
  DEALLOCATION_APPROVED: 9,
  DEALLOCATION_DECLINED: 10,
  ON_HOLD_REQUESTED: 11,
  RESOURCES_MAPPED: 7,
  DEALLOCATION_MAPPING_REQUESTED: 16,
  INITIATION_REQUEST: 17
}

const ROLES = {
  ADMIN: 'Admin',
  GLOBAL_OPERATION: 'Global Operation',
  SALES: 'Sales'
}

const ROLE_ID = {
  ADMIN: 1,
  GLOBAL_OPERATION: 2,
  SALES: 3,
  RESOURCE_MANAGER: 4,
  ACCOUNT_MANAGER: 5,
  PROJECT_MANAGER: 6,
  BU_HEAD: 7,
  GO_TEAM: 8
}
const SECTIONS = {
  PARTIALLY: 'partially',
  FULLY: 'fully',
  OVER: 'over'
}

const ACTION_LIST = [
  {
    full_name: 'Project Creation',
    id: 1
  },
  {
    full_name: 'Resource Requisition',
    id: 2
  },
  {
    full_name: 'Resource Allocation',
    id: 3
  },
  {
    full_name: 'Resource Mapping',
    id: 4
  },
  {
    full_name: 'Resource De-allocation',
    id: 5
  },
  {
    full_name: 'Close',
    id: 6
  },
  {
    full_name: 'Restart Project',
    id: 7
  },
  {
    full_name: 'Project on Hold Request',
    id: 8
  },
  {
    full_name: 'Project Hold Approval',
    id: 9
  },
  {
    full_name: 'No action available for you.',
    id: 10
  },
  {
    full_name: 'Resource Allocation Changes Approve / Decline',
    id: 11
  },
  {
    full_name: 'Resource Re-Allocation',
    id: 12
  },
  {
    full_name: 'Resource Mapping after De-allocation',
    id: 13
  }
]
const TITLES = {
  SUCCESS: 'success',
  ERROR: 'error'
}

const BU_HEAD_IDS = [1, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17]
const ACTION_STATUS = {
  INPROGESS: '0',
  COMPLETED: '1',
  AVAILABLE: '2'
}
const STATUS = {
  NEW: '1',
  ON_HOLD: '12',
  CLOSED: '13',
  INPROGRESS: '3',
  INITIATION: '17',
  DRAFT: '0'
}
const USER_ACTION_CODE = {
  RESTART: 'restart',
  CLOSE: 'project-closure',
  HOLD: 'hold-request'
}
const ERROR_MESSAGES = {
  VALIDATION_ERROR: 'Validation Error.',
  AUTHORIZATION_ERROR: 'Unauthorized',
  SOMETHING_WRONG_ERROR: 'Something went wrong!'
}

const ROUTES = {
  PROJECT_DASHBOARD_ROUTE: '/project-dashboard'
}
const TOKEN_EXPIRY_MINUTES = 60

const BILLING_TYPE = {
  FIXED_COST: 1,
  HOURLY: 2,
  RETAINER: 3,
  INTERNAL: 4,
  POC: 5
}
const WSR_TYPE = {
  PENDING: 0,
  SUBMITTED: 1
}
const PRIORITY = {
  LOW: 1,
  MEDIUM: 2,
  HIGH: 3
}
const ALL_WSR_STATUS = [0, 1]
const ALL_BILLING_ID = [1, 4, 5]
const BILLABLE_ID = [1, 2, 3]
const NEW_PROJECT_STATUS = ['1', '17']
const NON_INPROGRESS_STATUS = [1, 12, 13, 17]
const ALL_STATUS = ['1', '3', '12', '13', '0']
const PYRAMID_COLOUR_PATTERN = ['#7BB5EC', '#434348', '#90EC7D', '#F5A35C', '#8085E9', '#EB5B7F', '#E4D354', '#409090', '#EC595B', '#C5F3F0']
const ACTIVITY_CODE = {
  initiation_project: 'initiation_project',
  update_project: 'update_project',
  creation_project: 'creation_project',
  creation_requisition: 'creation_requisition',
  edit_requisition: 'edit_requisition',
  delete_requisition: 'delete_requisition',
  edit_extension_requisition: 'edit_extension_requisition',
  delete_extension_requisition: 'delete_extension_requisition',
  creation_allocation: 'creation_allocation',
  edit_allocation: 'edit_allocation',
  delete_allocation: 'delete_allocation',
  edit_direct_allocation: 'edit_direct_allocation',
  delete_direct_allocation: 'delete_direct_allocation',
  resource_allocation_response_accept: 'resource_allocation_response_accept',
  resource_allocation_response_decline: 'resource_allocation_response_decline',
  resource_reallocation: 'resource_reallocation',
  resource_mapping: 'resource_mapping',
  resource_deallocation: 'resource_deallocation',
  resource_unmapping: 'resource_unmapping',
  hold_request: 'hold_request',
  project_on_hold_request_accept: 'project_on_hold_request_accept',
  project_on_hold_rejection: 'project_on_hold_rejection',
  project_close: 'project_close',
  project_restart: 'project_restart',
  resource_modification: 'resource_modification',
  resource_extension: 'resource_extension',
  creation_rca: 'creation_rca',
  update_project_closure_checklist: 'update_project_closure_checklist',
  direct_resource_allocation: 'direct_resource_allocation',
  delete_reallocation: 'delete_reallocation',
  initiation_request: 'initiation_request',
  initiation_approval: 'initiation_approval',
  initiation_request_edit: 'initiation_request_edit',
  initiation_decline: 'initiation_decline',
  reject_requisition: 'reject_requisition'
}
const CHANGE_RM_STATUS = {
  ASSISGNED: 'Assigned',
  INPROGRESS: 'inProgress'
}

const ALERT_ACTION = {
  PR: 'creation-request',
  IA: 'initiation-approval',
  ID: 'initiation-decline',
  RA: 'resource-allocation',
  RR: 'resource-reallocation',
  RARA: 'resource-allocation-response-accept',
  RARD: 'resource-allocation-response-decline',
  PHRA: 'project-on-hold-request-accept',
  PHR: 'project-on-hold-rejection',
  IR: 'initiation-request'
}

const WSR_STATUS = [
  { text: 'Red', id: 1, color: 'btn red' },
  { text: 'Amber', id: 2, color: 'btn Amber' },
  { text: 'Green', id: 3, color: 'btn green' },
  { text: 'Not Available', id: 4, color: 'btn grey' }
]

const WSR_STATUS_PM_BU = [
  { text: 'Red', id: 1, color: 'btn red' },
  { text: 'Amber', id: 2, color: 'btn Amber' },
  { text: 'Green', id: 3, color: 'btn green' }
]

const HEALTH_STATUS = {
  RED: 1,
  AMBER: 2,
  GREEN: 3
}

const PENDING_ACTION_ITEM_PRIORITY = {
  LOW: 1,
  MEDIUM: 2,
  HIGH: 3
}
const PENDING_ACTION_ITEM_STATUS = {
  TODO: 0,
  DPNE: 1
}

const WSR_CATEGORY = [
  { text: 'Schedule', value: 1, escalation: 'switch-one', radioOne: 'yes-one', radioTwo: 'no-one' },
  { text: 'Quality', value: 2, escalation: 'switch-two', radioOne: 'yes-two', radioTwo: 'no-two' },
  { text: 'Staffing', value: 3, escalation: 'switch-three', radioOne: 'yes-three', radioTwo: 'no-three' },
  { text: 'Invoices', value: 4, escalation: 'switch-four', radioOne: 'yes-four', radioTwo: 'no-four' },
  { text: 'Risk', value: 5, escalation: 'switch-five', radioOne: 'yes-five', radioTwo: 'no-five' },
  { text: 'Effort', value: 6, escalation: 'switch-six', radioOne: 'yes-six', radioTwo: 'no-six' }
]

const constant = {
  PROJECT_MANAGEMENT,
  POST_BILLING_CONFIRMATION,
  RECEIVING_FROM_CLIENT,
  PROJECT_STATUS,
  ROLES,
  SECTIONS,
  ROLE_ID,
  ACTION_LIST,
  ALL_STATUS,
  BU_HEAD_IDS,
  TITLES,
  ACTION_STATUS,
  USER_ACTION_CODE,
  TOKEN_EXPIRY_MINUTES,
  STATUS,
  ERROR_MESSAGES,
  ROUTES,
  BILLING_TYPE,
  BILLABLE_ID,
  ALL_BILLING_ID,
  PRIORITY,
  PYRAMID_COLOUR_PATTERN,
  ACTIVITY_CODE,
  NON_INPROGRESS_STATUS,
  CHANGE_RM_STATUS,
  NEW_PROJECT_STATUS,
  ALERT_ACTION,
  WSR_STATUS,
  WSR_CATEGORY,
  HEALTH_STATUS,
  PENDING_ACTION_ITEM_PRIORITY,
  PENDING_ACTION_ITEM_STATUS,
  WSR_TYPE,
  ALL_WSR_STATUS,
  WSR_STATUS_PM_BU
}

export default constant
