const TITLE_COLOR = {
  unSchedule: 'green--text text--lighter-2',
  fullySch: 'yellow--text text--darken-3',
  partiallySch: 'blue--text text--lighter-2',
  overSch: 'red--text text--lighter-2'
}
const ICON_COLOR = {
  unSchedule: 'green lighter-2',
  fullySch: '#FFBB33',
  partiallySch: 'blue lighter-2',
  overSch: 'red lighter-2'
}
const LABLES = {
  unSchTabeleTitle: 'Unscheduled',
  fullySchTabeleTitle: 'Fully-Scheduled',
  partiallySchTabelTitle: 'Partially-Scheduled',
  overSchTabeleTitle: 'Over-Scheduled'
}
const VALUES = {
  fully: 'fully',
  partially: 'partially',
  over: 'over'
}

const dashboardConstant = {
  TITLE_COLOR,
  ICON_COLOR,
  LABLES,
  VALUES
}

export default dashboardConstant
