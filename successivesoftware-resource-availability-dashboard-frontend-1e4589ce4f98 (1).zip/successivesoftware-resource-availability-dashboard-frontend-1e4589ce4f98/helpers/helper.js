import * as XLSX from 'xlsx'
import constant from '@/constants/closure-checklist.js'

export const compareArrays = {
  isEqual (oldDetails, newDetails) {
    // Get the value type
    const type = Object.prototype.toString.call(oldDetails)

    // If the two objects are not the same type, return false
    if (type !== Object.prototype.toString.call(newDetails)) { return false }

    // If item are not an object or array, return false
    if (!['[object Array]', '[object Object]'].includes(type)) {return false }

    // Compare the length of the length of the two items
    const valueLen = type === '[object Array]' ? oldDetails.length : Object.keys(oldDetails).length
    const otherLen = type === '[object Array]' ? newDetails.length : Object.keys(newDetails).length

    if (valueLen !== otherLen) {return false }

    // Compare properties
    if (type === '[object Array]') {
      for (let i = 0; i < valueLen; i++) {
        if (this.compare(oldDetails[i], newDetails[i]) === false) {return false }
      }
    } else {
      for (const key in oldDetails) {
        // eslint-disable-next-line no-prototype-builtins
        if (oldDetails.hasOwnProperty(key)) {
          // for (let i = 0; i < valueLen; i++) {
          const itemType = Object.prototype.toString.call(oldDetails[key])

          // If the two objects are not the same type, return false
          if (itemType !== Object.prototype.toString.call(newDetails[key])) { return false }

          // Compare the length of the length of the two items
          if (itemType === '[object Null]' || itemType === '[object Undefined]') {
            oldDetails[key] = ''
            newDetails[key] = ''
          }
          const valueItemLen = type === '[object Array]' ? oldDetails[key].length : Object.keys(oldDetails[key]).length
          const otherItemLen = type === '[object Array]' ? newDetails[key].length : Object.keys(newDetails[key]).length

          if (valueItemLen !== otherItemLen) {return false }
          if (itemType === '[object Array]') {
            for (let i = 0; i < valueItemLen; i++) {
              const subOldDetails = oldDetails[key][i]
              const subNewDetails = newDetails[key][i]
              const subType = Object.prototype.toString.call(subOldDetails)

              if (subType !== Object.prototype.toString.call(subNewDetails)) {return false }
              if (this.compare(subOldDetails, subNewDetails) === false) {return false }
              if (subType === '[object object]') {
                for (const key in subOldDetails) {
                  if (this.compare(subOldDetails[key], subNewDetails[key]) === false) {return false }
                }
              }
            }
          }
          if (this.compare(oldDetails[key], newDetails[key]) === false) {return false }
        }
      }
    }

    // If nothing failed, return true
    return true
  },
  // Compare two items
  compare (item1, item2) {
  // Get the object type
    const itemType = Object.prototype.toString.call(item1)

    // If an object or array, compare recursively
    if (['[object Array]', '[object Object]'].includes(itemType)) {
      if (!this.isEqual(item1, item2)) {return false }
    } else {
      // If the two items are not the same type, return false
      if (itemType !== Object.prototype.toString.call(item2)) {return false }

      // Else if it's a function, convert to a string and compare
      // Otherwise, just compare
      if (itemType === '[object Function]') {
        if (item1.toString() !== item2.toString()) {return false }
      } else if (item1 !== item2) {return false }
    }
  }
}

export const excelSheet = {
  createExcelSheet (excelParams) {
    const { sheetData, headers, sheetName, fileName } = excelParams
    /* create new workbook */
    const workbook = XLSX.utils.book_new()

    for (let i = 0; i < sheetName.length; i++) {
      const ws = XLSX.utils.json_to_sheet(sheetData[i], { header: headers[i] })
      const range = XLSX.utils.decode_range(ws['!ref'])

      for (let C = range.s.r; C <= range.e.c; ++C) {
        const address = XLSX.utils.encode_col(C) + '1' // <-- first row, column number C

        if (!ws[address]) { continue }
        if (ws[address].v.length <= 3 && ws[address].v !== 'to') {
          ws[address].v = ws[address].v.toUpperCase()
        } else {
          ws[address].v = this.toTitleCase(ws[address].v)
        }
      }
      XLSX.utils.book_append_sheet(workbook, ws, sheetName[i])
    }
    XLSX.writeFile(workbook, fileName)
  },
  toTitleCase (str) {
    const words = str.split('_')
    const fullHeaderName = words.join(' ')

    return fullHeaderName.replace(
      /\w\S*/g,
      (txt) => {
        return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase()
      }
    )
  }
}

export const projectHelpers = {
  randomColors () {
    const letters = '0123456789ABCDEF'.split('')
    let color = '#'

    for (let i = 0; i < 6; i++) {
      color += letters[Math.round(Math.random() * 15)]
    }

    return color
  },
  avatarNames (fullName) {
    try {
      if (fullName !== null) {
        fullName = fullName.replace(/\s+/g, ' ')
        let nameparts = []
        let fetchString = ''

        nameparts = fullName.split(' ')
        if (nameparts.length === 2) {
          fetchString = nameparts[0].charAt(0).toUpperCase() + nameparts[1].charAt(0).toUpperCase()
        } else if (nameparts.length < 2) {
          fetchString = nameparts[0].charAt(0).toUpperCase()
        } else {
          fetchString = nameparts[0].charAt(0).toUpperCase() + nameparts[2].charAt(0).toUpperCase()
        }

        return fetchString
      }
    } catch (e) {
      return ''
    }
  },
  formatDate (date) {
    const d = new Date(date)
    let month = '' + (d.getMonth() + 1)
    let day = '' + d.getDate()
    const year = d.getFullYear()

    if (month.length < 2) month = '0' + month
    if (day.length < 2) day = '0' + day

    return [year, month, day].join('-')
  },
  listDateFormat (date) {
    if (date) {
      const d = new Date(date)
      let month = '' + (d.getMonth() + 1)
      let day = '' + d.getDate()
      const year = d.getFullYear()

      if (month.length < 2) month = '0' + month
      if (day.length < 2) day = '0' + day

      return [day, month, year].join('-')

    } else {
      return ''
    }

  },
  setResignArray (newCountryData, companyCountry) {
    try {
      const countryData = newCountryData.find((country) => {
        if (country.regions.length !== 0 && country.countryName === companyCountry) {
          return country
        }
      })

      return countryData.regions
    } catch (e) {
      return []
    }

  },

  nonExistCountryData (newCountryData, projectDetail) {
    try {
      const notExistState = []
      const State = {
        name: projectDetail.state,
        shortCode: projectDetail.state
      }

      notExistState.push(State)
      const notExistCountry = {
        countryName: projectDetail.country,
        countryShortCode: projectDetail.country,
        regions: notExistState
      }

      newCountryData.push(notExistCountry)

      return newCountryData
    } catch (e) {
      return {}
    }

  },

  totalDays(toTimelineDate, fromTimelineDate) {
    // const diffTime = Math.abs(date1 - date2)
    try {
      const diffTime = Math.abs(toTimelineDate - fromTimelineDate)
      const totalCount = (Math.ceil(diffTime / (1000 * 60 * 60 * 24))) + 1

      return totalCount + ' Days'

    } catch (e) {

      return 0
    }
  },

  totalDaysCount(toDate, fromDate) {
    // const diffTime = Math.abs(date1 - date2)
    try {
      const diffTime = Math.abs(toDate - fromDate)
      const totalCount = (Math.ceil(diffTime / (1000 * 60 * 60 * 24))) + 1

      return totalCount

    } catch (e) {

      return 0
    }
  },

  setClient (clientDetails, getProjectClients) {
    const data = { selectedClients:[], getProjectClients:[] }

    try {
      if (Array.isArray(clientDetails) && clientDetails.length) {
        clientDetails.forEach((value, index) => {
          if (value['full_name'] !== '' || value['address'] !== '') {
            if (value['full_name'] !== null || value['address'] !== null) {

              const result = getProjectClients.filter((item) => {
                if (item['emails'] === value['address']) {
                  return item
                }
              })

              // if client info exist in client list
              if (Array.isArray(result) && result.length) {
                data.selectedClients.push(result[0].id)
              }
              else {   // if client info not exist in client list
                const clientLength = getProjectClients.length * 10
                const notExistClient = {
                  id: clientLength,
                  name: value['full_name'],
                  emails: value['address']
                }

                data.getProjectClients.push(notExistClient)
                data.selectedClients.push(notExistClient.id)
              }
            }

          }
        })
      }

      return data
    } catch (e) {
      return data
    }
  },

  setClientDetails(billingType, getProjectClients, selectedClients, companyName, companyAddress, companyState, companyCountry) {
    const data = { companyName:companyName, companyAddress:companyAddress, clientDetails:[],companyState:companyState ,companyCountry:companyCountry  }

    try {
      if (billingType === constant.BILLING_TYPE.INTERNAL || billingType === constant.BILLING_TYPE.POC) {
        data.companyName = null
        data.companyAddress = null
        data.companyState = ''
        data.companyCountry = ''
        data.clientDetails.push({ full_name: '', address: '' })
      } else {
        if (selectedClients.length === 0) {
          data.clientDetails.push({ full_name: '', address: '' })
        } else {
          selectedClients.forEach((clientId, index) => {
            const result = getProjectClients.filter((item) => {
              if (item['id'] === clientId) {
                return item
              }
            })

            if (result[0].name !== '' && result[0].emails !== '') {
              data.clientDetails.push({ full_name: result[0].name, address: result[0].emails })
            }
          })
        }
      }

      return data
    } catch (e) {
      console.warn(e)

      return data
    }
  },

  alphaNumSpecialValidation (value) {

    if (value === null) {
      value = ''
    }

    const re = /^[a-zA-Z0-9!@#"}{|?/$:;%\\^&*)(+=. _'-s]*$/
    const matches = value.match(re) // = null

    if (matches === null || !matches.length) { // Error: Cannot read property 'length' of null
      return false
    }

    return true
  },

  validateSectionValues(value) {
    let checkedValue = true

    if (value !== '' && value !== null) {
      const validValue = this.alphaNumSpecialValidation(value)

      if (!validValue) {
        checkedValue = false
      }
    } else {
      checkedValue = false
    }

    return checkedValue
  },

  alphaNumSpecialValidationLineBreak (value) {

    if (value === null) {
      value = ''
    }

    const re = /^[a-zA-Z0-9!@#"}{|?/$:/\n/;%\\^&*)(+=. _'-s]*$/
    const matches = value.match(re) // = null

    if (matches === null || !matches.length) { // Error: Cannot read property 'length' of null
      return false
    }

    return true
  },

  validateSectionValuesLineBreak(value) {
    let checkedValue = true

    if (value !== '' && value !== null) {
      const validValue = this.alphaNumSpecialValidationLineBreak(value)

      if (!validValue) {
        checkedValue = false
      }
    } else {
      checkedValue = false
    }

    return checkedValue
  }

}

export const sortBy = {
  sortByKey (field, reverse, primer) {

    const key = primer ?
      function(x) {
        return primer(x[field])
      } :
      function(x) {
        return x[field]
      }

    reverse = !reverse ? 1 : -1

    return function(a, b) {
      return a = key(a), b = key(b), reverse * ((a > b) - (b > a))
    }
  }
}
