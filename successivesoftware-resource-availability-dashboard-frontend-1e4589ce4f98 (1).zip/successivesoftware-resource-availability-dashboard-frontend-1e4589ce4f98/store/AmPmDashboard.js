function initialState () {
  return {
    addWSR: {},
    editWSR: {},
    customDialog: {
      status: false,
      title: '',
      message: '',
      nextRoute: ''
    },
    wsrList: [],
    buRagList: [],
    assignedActionList: [],
    projectWSRList: [],
    wsrDetail: {},
    projectEffortsList: [],
    riskList:[],
    projectRiskList:[],
    yearlyWeekList: [],
    AssignedUserList: [],
    AssignedPMUserList: [],
    AssignedProjectList: [],
    RiskCategories:[],
    myActionItemList: [],
    resourceTime: 0

  }
}
export const state = () => initialState()
export const getters = {
  getWSR: (state) => state.addWSR,
  getWsr: (state) => state.editWSR,
  getCustomDialog: (state) => state.customDialog,
  getWsrList: (state) => state.wsrList,
  getAssignedActionList: (state) => state.assignedActionList,
  getProjectWSRList: (state) => state.projectWSRList,
  getWSRDetail: (state) => state.wsrDetail,
  getProjectEffortsList: (state) => state.projectEffortsList,
  getRiskData: (state) => state.riskList,
  getProjectRiskData: (state) => state.projectRiskList,
  getMyActionItemList: (state) => state.myActionItemList,
  getYearlyWeeks: (state) => state.yearlyWeekList,
  getAssignedUsers: (state) => state.AssignedUserList,
  AssignedPMUserList: (state) => state.AssignedPMUserList,
  getAssignedProjectList: (state) => state.AssignedProjectList,
  getRiskCategoryList: (state) => state.RiskCategories,
  getBURagList: (state) => state.buRagList,
  getResourceTime: (state) => state.resourceTime
}
export const mutations = {
  setResourceTime (state, count) {
    state.resourceTime = count
  },
  setAddWSR (state, wsr) {
    state.addWSR = wsr
  },
  setEditWSR (state, wsr) {
    state.editWSR = wsr
  },
  setWsrList (state, wsrData) {
    state.wsrList = wsrData
  },
  setBURagList (state, wsrData) {
    state.buRagList = wsrData
  },
  setRiskList (state, riskData) {
    state.riskList = riskData
  },
  setProjectRiskList(state, projectRiskData) {
    state.projectRiskList = projectRiskData
  },
  setWSRYearWeek(state, wsrData) {
    state.yearlyWeekList = wsrData
  },
  setWSRDetail (state, wsrData) {
    state.wsrDetail = wsrData
  },
  setAssignedActionList (state, pendingActionData) {
    state.assignedActionList = pendingActionData
  },
  setMyActionItemList (state, myActionItemList) {
    state.myActionItemList = myActionItemList
  },
  setProjectEffortsList (state, projectEffortsList) {
    state.projectEffortsList = projectEffortsList
  },
  setProjectWSRList (state, projectWSRData) {
    state.projectWSRList = projectWSRData
  },
  setAssignedUsers (state, AssignedUsers) {
    state.AssignedUserList = AssignedUsers
  },
  setAssignedPMUsers (state, AssignedPMUsers) {
    state.AssignedPMUserList = AssignedPMUsers
  },
  setAssignedProjectList (state, AssignedProjectList) {
    state.AssignedProjectList = AssignedProjectList
  },
  setRiskCategories (state, RiskCategories) {
    state.RiskCategories = RiskCategories
  },

  setPendingItemDone (state, changedData) {
    const newItem = changedData.data

    if (newItem.uuid) {
      const listIndex = state.myActionItemList.findIndex((data) => data.uuid === newItem.uuid)
      const [updatedData] = state.myActionItemList.splice(listIndex, 1)

      updatedData.status = newItem.status
      state.myActionItemList.splice(listIndex, 0, updatedData)

    }
  },

  setCustomDialog (state, dialogData) {
    state.customDialog = dialogData
  }
}

export const actions = {
  /**
   * Assigned User List API
   * @param {*} param
  */

  async fetchAssignedUsers ({ commit, rootState }) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data } = await this.$resourceApi.get('/get-asssign-users', config)

      if (data.status === 200) {
        const AssignedUsers = data.data

        commit('setAssignedUsers', AssignedUsers)
      }
    } catch (e) {
      commit('setAssignedUsers', [])
      throw e
    }
  },

  async fetchAssignedPMUsers ({ commit, rootState }) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data } = await this.$resourceApi.get('get-asssign-pm-users', config)

      if (data.status === 200) {
        const AssignedUsers = data.data

        commit('setAssignedPMUsers', AssignedUsers)
      }
    } catch (e) {
      commit('setAssignedPMUsers', [])
      throw e
    }
  },

  /**
 * Assigned User List API
 * @param {*} param
*/

  async fetchAssignedProjectList ({ commit, rootState }) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data } = await this.$resourceApi.get('/pmo-project-listing', config)

      if (data.status === 200) {
        const AssignedProjectList = data.data

        commit('setAssignedProjectList', AssignedProjectList)
      }
    } catch (e) {
      commit('setAssignedProjectList', [])
      throw e
    }
  },
  async fetchRiskCategories ({ commit, rootState }) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data } = await this.$resourceApi.get('/categories', config)

      if (data.status === 200) {
        const RiskCategories = data.data

        commit('setRiskCategories', RiskCategories)
      }
    } catch (e) {
      commit('setRiskCategories', [])
      throw e
    }
  },

  /**
   * Add WSR API
   * @param {*} param
   */

  async addPendingActionItems ({ commit, rootState }, requestData) {
    try {
      const requestPayload = {
        'assiged_user_id' : requestData.assiged_user_id,
        'project_id' : requestData.project_id,
        'target_closure_date' : requestData.target_closure_date,
        'priority' : requestData.priority,
        'status' : requestData.status,
        'description' : requestData.description
      }

      await this.$resourceApi.post('/add-action-items', { }, {
        data: requestPayload,
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 200000
      }).then((response) => {
        let actionItem = {}
        let dialogData = {}
        const { data: responseData, status } = response || {}

        if (status === 201) {
          actionItem = responseData
          dialogData = {
            status: true,
            title: 'Success',
            message: 'Yay! Action Item Added Successfully',
            nextRoute: '/dashboard',
            sameRoute: false
          }
        }
        commit('setCustomDialog', dialogData)
      }).catch((error) => {
        const message = 'Something went wrong!'

        commit('setCustomDialog', {
          status: true,
          title: 'Error',
          message,
          errormessage: error,
          nextRoute: '/dashboard'
        })
      })
    } catch (e) {
      console.log('error', e)
    }
  },

  /**
   * Add WSR API
   * @param {*} param
   */

  async addWsrInfo ({ commit, rootState }, requestData) {
    try {
      const requestPayload = {
        'project_id' : requestData.project_id,
        'sch_cat_status' : requestData.sch_cat_status,
        'sch_cat_remark' : requestData.sch_cat_remark,
        'qlt_cat_status' : requestData.qlt_cat_status,
        'qlt_cat_remark' : requestData.qlt_cat_remark,
        'stf_cat_status' : requestData.stf_cat_status,
        'stf_cat_remark' : requestData.stf_cat_remark,
        'inv_cat_status' : requestData.inv_cat_status,
        'inv_cat_remark' : requestData.inv_cat_remark,
        'rsk_cat_status' : requestData.rsk_cat_status,
        'rsk_cat_remark' : requestData.rsk_cat_remark,
        'eft_cat_status' : requestData.eft_cat_status,
        'eft_cat_remark' : requestData.eft_cat_remark,
        'highlights_remark' : requestData.highlights_remark,
        'lowlights_remark' : requestData.lowlights_remark,
        'customer_happiness_remark' : requestData.customer_happiness_remark,
        'people_happiness_remark' : requestData.people_happiness_remark,
        'sch_cat_clt_esclation': requestData.scheduleEs,
        'qlt_cat_clt_esclation': requestData.qualityEs,
        'stf_cat_clt_esclation': requestData.staffingEs,
        'inv_cat_clt_esclation': requestData.invoiceEs,
        'rsk_cat_clt_esclation': requestData.riskEs,
        'eft_cat_clt_esclation': requestData.effortEs
      }

      await this.$resourceApi.post('/weekly-status-report', { }, {
        data: requestPayload,
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 200000
      }).then((response) => {
        let wsrData = {}
        let dialogData = {}

        const { data: responseData, status } = response || {}

        if (status === 201) {
          wsrData = responseData
          dialogData = {
            status: true,
            title: 'Success',
            message: 'Yay! WSR Added Successfully',
            nextRoute: '/wsr/wsr-list',
            sameRoute: false
          }
          commit('setAddWSR', wsrData)
        } else  {
          dialogData = {
            status: true,
            title: 'Error',
            message: 'WSR already exists for this week!',
            nextRoute: '/wsr/wsr-list' ,
            sameRoute: false
          }
        }
        commit('setCustomDialog', dialogData)
      }).catch((error) => {

        let message = 'Something went wrong!'
        const { response } = error || {}
        const { status } = response || 0

        if (status === 422) {
          message = 'Validation Error.'
        } else if (status === 401) {
          message = 'Unauthorized.'
        }

        commit('setCustomDialog', {
          status: true,
          title: 'Error',
          message,
          errormessage: error,
          nextRoute: '/project-dashboard'
        })
      })
    } catch (e) {
      commit('setAddWSR', {})
    }
  },
  async editWsrInfo ({ commit, rootState }, { id, requestData }) {
    try {
      const requestPayload = {
        'project_id' : requestData.project_id,
        'sch_cat_status' : requestData.sch_cat_status,
        'sch_cat_remark' : requestData.sch_cat_remark,
        'qlt_cat_status' : requestData.qlt_cat_status,
        'qlt_cat_remark' : requestData.qlt_cat_remark,
        'stf_cat_status' : requestData.stf_cat_status,
        'stf_cat_remark' : requestData.stf_cat_remark,
        'inv_cat_status' : requestData.inv_cat_status,
        'inv_cat_remark' : requestData.inv_cat_remark,
        'rsk_cat_status' : requestData.rsk_cat_status,
        'rsk_cat_remark' : requestData.rsk_cat_remark,
        'eft_cat_status' : requestData.eft_cat_status,
        'eft_cat_remark' : requestData.eft_cat_remark,
        'highlights_remark' : requestData.highlights_remark,
        'lowlights_remark' : requestData.lowlights_remark,
        'customer_happiness_remark' : requestData.customer_happiness_remark,
        'people_happiness_remark' : requestData.people_happiness_remark,
        'sch_cat_clt_esclation': requestData.scheduleEs,
        'qlt_cat_clt_esclation': requestData.qualityEs,
        'stf_cat_clt_esclation': requestData.staffingEs,
        'inv_cat_clt_esclation': requestData.invoiceEs,
        'rsk_cat_clt_esclation': requestData.riskEs,
        'eft_cat_clt_esclation': requestData.effortEs
      }

      await this.$resourceApi.put(`/weekly-status-report-update/${id}`, { }, {

        data: requestPayload,
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 200000
      })
        .then((response) => {
          let wsrData = {}
          let dialogData = {}

          const { data: responseData, status } = response || {}

          if (status === 200) {
            wsrData = responseData
            dialogData = {
              status: true,
              title: 'Success',
              message: 'Yay! WSR Updated Successfully',
              nextRoute: '/wsr/wsr-list',
              sameRoute: false
            }
            commit('setEditWSR', wsrData)
          } else  {
            dialogData = {
              status: true,
              title: 'Error',
              message: 'Err!',
              nextRoute: '/wsr/wsr-list' ,
              sameRoute: false
            }
          }
          commit('setCustomDialog', dialogData)

        }).catch((error) => {

          let message = 'Something went wrong!'
          const { response } = error || {}
          const { status } = response || 0

          if (status === 422) {
            message = 'Validation Error.'
          } else if (status === 401) {
            message = 'Unauthorized.'
          }

          commit('setCustomDialog', {
            status: true,
            title: 'Error',
            message,
            errormessage: error,
            nextRoute: '/project-dashboard'
          })
        })
    } catch (e) {
      commit('setEditWSR', {})
    }
  },
  async setPendingItemMarkDone ({ commit, rootState }, requestData) {
    try {

      const setRoute = requestData.route

      await this.$resourceApi.put(`/action-item-mark-done/${requestData.uuid}`, { }, {
        data: requestData,
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }).then((response) => {

        let itemData = {}
        let dialogData = {}
        const { data: responseData, status } = response || {}

        if (status === 201) {
          itemData = responseData
          dialogData = {
            status: true,
            title: 'Success',
            message: 'Yay! Action Item Status Updated Successfully',
            nextRoute: setRoute,
            sameRoute: false
          }
        }

        commit('setPendingItemDone', itemData)
        commit('setCustomDialog', dialogData)

      }).catch((error) => {
        const message = 'Something went wrong!'

        commit('setCustomDialog', {
          status: true,
          title: 'Error',
          message,
          errormessage: error,
          nextRoute: setRoute
        })
      })
    } catch (e) {
      commit('setRejectRequisition', {})
    }
  },
  /**
   * WSR List API
   * @param {*} param
  */
  async fetchBuProjectRag ({ commit, rootState }, requestData) {
    try {

      const reqData = requestData !== undefined ? requestData : ''
      const requestPayload = {
        'billing_id':reqData.billing_id,
        'week_id': reqData.week_id,
        'pm_id': reqData.pm_id,
        'health_id': reqData.health_id,
        'client_exclation': reqData.client_exclation,
        'dept_id':reqData.dept_id
      }

      await this.$resourceApi
        .post(
          '/department-wise-rag-listing',
          {},
          {
            data: requestPayload,
            headers: { Authorization: rootState.auth.tokenId },
            timeout: 200000
          }
        )
        .then((response) => {

          const { data: responseData } = response || {}

          commit('setBURagList', responseData.data)
        })
        .catch((error) => {
          const message = 'Something went wrong!'

          commit('setCustomDialog', {
            status: true,
            title: 'Error',
            message,
            errormessage: error,
            nextRoute: '/project-dashboard'
          })
        })
    } catch (e) {
      commit('setBURagList', {})
    }
  },
  async fetchResourceTime({ commit, rootState }, requestParams) {

    try {

      const config = {

        headers: { Authorization: rootState.auth.tokenId },

        params: {

          user_id: requestParams.selectedUser,

          dept_id: requestParams.departmentId

        },

        timeout: 20000

      }

      const { data } = await this.$resourceApiV3.get(

        '/resource-time-bu',

        config

      )

      const { status, data: resourceData } = data || {}

      if (status === 200) {

        commit('setResourceTime', resourceData.TotalTimelog)

      }

    } catch (e) {

      commit('setResourceTime', [])
    }
  },
  async fetchWSR ({ commit, rootState }, requestData) {
    try {
      const reqData = requestData !== undefined ? requestData : ''
      const requestPayload = {
        'billing_type':reqData.billing_type,
        'week_no': reqData.week_no,
        'pmuser_id': reqData.pmuser_id,
        'overall_health_status': reqData.overall_health_status,
        'client_exclation': reqData.client_exclation,
        'project_name':reqData.project_name
      }

      await this.$resourceApi
        .post(
          '/weekly-status-report-list',
          {},
          {
            data: requestPayload,
            headers: { Authorization: rootState.auth.tokenId },
            timeout: 200000
          }
        )
        .then((response) => {
          const { data: responseData } = response || {}

          commit('setWsrList', responseData)
        })
        .catch((error) => {
          const message = 'Something went wrong!'

          commit('setCustomDialog', {
            status: true,
            title: 'Error',
            message,
            errormessage: error,
            nextRoute: '/project-dashboard'
          })
        })

    }
    catch (e) {
      commit('setWsrList', [])
      throw e
    }
  },
  async fetchRisk ({ commit, rootState }) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data } = await this.$resourceApi.get('/project-active-risk-data', config)

      if (data.status === 200) {
        const riskData = data.data

        commit('setRiskList', riskData)
      }
    } catch (e) {
      commit('setRiskList', [])
      throw e
    }
  },
  async fetchProjectRisk ({ commit, rootState }) {

    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data }  = await this.$resourceApi.get('/project-at-risk-data', config)

      if (data.status === 200) {
        const projectRiskData = data.data

        commit('setProjectRiskList', projectRiskData)

      }
    } catch (e) {
      commit('setProjectRiskList', ['nav'])
      throw e
    }
  },

  /**
* WSR weeks API
* @param {*} param
*/

  async fetchWeeks ({ commit, rootState }) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data } = await this.$resourceApi.get('/current-year-week-list', config)

      if (data.status === 200) {
        const wsrData = data.data

        commit('setWSRYearWeek', wsrData)
      }
    } catch (e) {
      commit('setWSRYearWeek', [])
      throw e
    }
  },

  async fetchProjectEffortsList ({ commit, rootState }) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data } = await this.$resourceApi.get('/project-efforts-list', config)

      if (data.status === 200) {
        const projectEffortsList = data.data

        commit('setProjectEffortsList', projectEffortsList)
      }
    } catch (e) {
      commit('setProjectEffortsList', [])
      throw e
    }
  },
  /**
   * WSR Detail View API
   * @param {*} param
   */
  async fetchWSRDetail ({ commit, rootState }, id) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data } = await this.$resourceApi.get(`/view-weekly-status-details/${id}`, config)

      if (data.status === 200) {
        const wsrData = data.data

        commit('setWSRDetail', wsrData)
      }
    } catch (e) {
      commit('setWSRDetail', [])
      throw e
    }
  },
  async fetchAssignedActionList ({ commit, rootState }) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data } = await this.$resourceApi.get('/assigned-action-item-list', config)

      if (data.status === 200) {
        const pendingListData = data.data

        commit('setAssignedActionList', pendingListData)
      }
    } catch (e) {
      commit('setAssignedActionList', [])
      throw e
    }
  },
  async fetchMyActionItemList ({ commit, rootState }) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data } = await this.$resourceApi.get('/action-item-list', config)

      if (data.status === 200) {
        const myActionItemList = data.data

        commit('setMyActionItemList', myActionItemList)
      }
    } catch (e) {
      commit('setMyActionItemList', [])
      throw e
    }
  },
  async fetchProjectWSRData ({ commit, rootState }) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data } = await this.$resourceApi.get('/project-wsr-data', config)

      if (data.status === 200) {
        const ProjectWSRData = data.data

        commit('setProjectWSRList', ProjectWSRData)
      }
    } catch (e) {
      commit('setProjectWSRList', [])
      throw e
    }
  },
  setCustomDialog ({ commit }, dialogData) {
    try {
      commit('setCustomDialog', dialogData)
    } catch (e) {
      commit('setCustomDialog', {
        status: false,
        title: '',
        message: '',
        nextRoute: ''
      })
    }
  }
}
