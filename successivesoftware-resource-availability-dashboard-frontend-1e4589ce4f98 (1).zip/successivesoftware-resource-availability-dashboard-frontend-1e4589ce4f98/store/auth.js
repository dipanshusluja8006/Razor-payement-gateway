import constants from '@/constants/closure-checklist'

function initialState () {
  return {
    isAuthenticated: false,
    user: null,
    tokenId: null,
    expiryDate: ''
  }
}
export const state = () => initialState()

export const getters = {
  isAuthenticated: (state) => state.isAuthenticated,
  user: (state) => state.user,
  tokenId: (state) => state.tokenId,
  getExpiry: (state) => state.expiryDate
}

export const mutations = {
  updateAuthentication (state, data) {
    state.isAuthenticated = data
  },
  setUser (state, userData) {
    state.user = userData
  },
  setTokenId (state, token) {
    const date = new Date()
    
    date.setMinutes(date.getMinutes() + constants.TOKEN_EXPIRY_MINUTES)
    state.tokenId = token
    state.expiryDate = date
  },
  resetState (state) {
    // acquire initial state
    const s = initialState()

    Object.keys(s).forEach((key) => {
      state[key] = s[key]
    })
  }
}

export const actions = {
  updateAuthentication ({ commit }, data) {
    commit('updateAuthentication', data)
  },

  setUserDetails ({ commit }, data) {
    commit('setUser', data)
  },

  setUserToken ({ commit }, data) {
    commit('setTokenId', data)
  },

  resetAuthState ({ commit }) {
    commit('resetState')
  }
}
