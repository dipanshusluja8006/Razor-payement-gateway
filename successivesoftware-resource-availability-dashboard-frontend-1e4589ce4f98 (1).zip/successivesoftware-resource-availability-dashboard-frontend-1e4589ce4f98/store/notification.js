function initialState () {
  return {
    projectNotifications: []
  }
}
export const state = () => initialState()
export const getters = {
  getNotification: (state) => state.projectNotifications
}
export const mutations = {
  setNotification (state, notifications) {
    state.projectNotifications = notifications
  },
  resetState (state) {
    // acquire initial state
    const s = initialState()

    Object.keys(s).forEach((key) => {
      state[key] = s[key]
    })
  }
}

export const actions = {
  resetCartState ({ commit }) {
    commit('resetState')
  },
  async fetchNotification ({ commit, rootState }) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data } = await this.$resourceApi.get('/show-activity-user', config)

      if (data.status === 200) {
        commit('setNotification', data.data)
      }
    } catch (e) {
      commit('setNotification', [])
      throw e
    }
  }
}
