function initialState () {
  return {
    snackbarValue: false,
    globalRole: [],
    rolesAvailable: [],
    hasProjectDashboardAccess: false,
    hasProjectInititationAccess: false,
    hasGlobalTeam: false,
    userManagementList: [],
    editableRoles: [],
    changeUserRoleData: {}
  }
}
export const state = () => initialState()

export const getters = {
  snackbarValue: (state) => state.snackbarValue,
  getGlobalRole: (state) => state.globalRole,
  getDashboardAccess: (state) => state.hasProjectDashboardAccess,
  getGlobalTeamRole: (state) => state.hasGlobalTeam,
  getInitiationAccess: (state) => state.hasProjectInititationAccess,
  availableRoles: (state) => state.rolesAvailable,
  getUserManagementList: (state) => state.userManagementList,
  getEditableRoles: (state) => state.editableRoles,
  getChangeUserRoleData: (state) => state.changeUserRoleData
}

export const mutations = {
  setGlobalRole (state, roleData) {
    const { userRole, projectDashboard, projectInitiation, go_team: goTeam } = roleData || {}

    state.globalRole = userRole
    state.hasProjectDashboardAccess = projectDashboard
    state.hasProjectInititationAccess = projectInitiation
    state.hasGlobalTeam = goTeam
  },
  setAvailableRoles (state, roles) {
    state.rolesAvailable = roles
  },
  setEditableRole (state, roles) {
    state.editableRoles = roles
  },
  setUserManagement (state, roles) {
    state.userManagementList = roles
  },
  setChangeUserRole (state, roleData) {
    state.changeUserRoleData = roleData
  },
  resetState (state) {
    // acquire initial state
    const s = initialState()

    Object.keys(s).forEach((key) => {
      state[key] = s[key]
    })
  }
}

export const actions = {
  resetCartState ({ commit }) {
    commit('resetState')
  },
  async fetchGlobalRole ({ commit, rootState }) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data } = await this.$resourceApi.get('/user-role', config)

      if (data.status === 200) {
        commit('setGlobalRole', data.data)
      }
    } catch (e) {
      commit('setGlobalRole', [])
      throw e
    }
  },
  async fetchAllRoles ({ commit, rootState }) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 60000
      }
      const { data } = await this.$resourceApi.get('/designation', config)

      if (data.status === 200) {
        commit('setAvailableRoles', data.data)
      }
    } catch (e) {
      commit('setAvailableRoles', [])
      throw e
    }
  },
  // get  user management list and other APIs
  async fetchUserManagement ({ commit, rootState }) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data } = await this.$resourceApi.get('/user-management', config)

      if (data.status === 200) {
        commit('setUserManagement', data.data)
      }
    } catch (e) {
      commit('setUserManagement', [])
      throw e
    }
  },
  async fetchEditableRoles ({ commit, rootState }) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data } = await this.$resourceApi.get('/all-roles', config)

      if (data.status === 200) {
        commit('setEditableRole', data.data)
      }
    } catch (e) {
      commit('setEditableRole', [])
      throw e
    }
  },
  async updateUserRole ({ commit, rootState }, requestData) {
    try {
      const requestPayload = {
        'user_id': requestData.userId,
        'add_role_ids':requestData.addRoleIds,
        'remove_role_ids':requestData.removeRoleIds,
        'add_dept_ids':requestData.addDeptIds,
        'remove_dept_ids':requestData.removeDeptIds
      }

      await this.$resourceApi.post('/update-roles', { }, {
        data: requestPayload,
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 60000
      }).then((response) => {
        const { data: responseData, status } = response || {}

        if (status === 201) {
          commit('setChangeUserRole', responseData)
        }
      }).catch((error) => {
        commit('setChangeUserRole', error)
      })
    } catch (e) {
      commit('setChangeUserRole', {})
    }
  }
}
