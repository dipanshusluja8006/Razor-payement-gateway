import Vuetify from '../plugins/vuetify'
import configs from '../configs'
const { product, time, theme, currencies } = configs

const { globalTheme, menuTheme, toolbarTheme, isToolbarDetached, isContentBoxed, isRTL, changeTableView } = theme
const { currency, availableCurrencies } = currencies

function initialState () {
  return {
    product,
    time,
    // currency
    currency,
    availableCurrencies,
    // themes and layout configurations
    globalTheme,
    menuTheme,
    toolbarTheme,
    isToolbarDetached,
    isContentBoxed,
    isRTL,
    changeTableView,

    // App.vue main toast
    toast: {
      show: false,
      color: 'black',
      message: '',
      timeout: 3000
    }
  }
}
export const state = () => initialState()

export const getters = {
  currency: (state) => state.currency,
  product: (state) => state.product,
  time: (state) => state.time,
  availableCurrencies: (state) => state.availableCurrencies,
  globalTheme: (state) => state.globalTheme,
  menuTheme: (state) => state.menuTheme,
  toolbarTheme: (state) => state.toolbarTheme,
  isToolbarDetached: (state) => state.isToolbarDetached,
  isContentBoxed: (state) => state.isContentBoxed,
  isRTL: (state) => state.isRTL,
  toast: (state) => state.toast,
  changeTableView: (state) => state.changeTableView
}

export const mutations = {
  /**
     * Main Toast
     */
  showToast (state, toast) {
    const { color, timeout, message } = toast

    state.toast = {
      message,
      color,
      timeout,
      show: true
    }
  },
  hideToast (state) {
    state.toast.show = false
  },
  resetToast (state) {
    state.toast = {
      show: false,
      color: 'black',
      message: '',
      timeout: 3000
    }
  },

  /**
     * Theme and Layout
     */
  setGlobalTheme (state, theme) {
    Vuetify.framework.theme.dark = theme === 'dark'
    state.globalTheme = theme
  },
  setRTL (state, isRTL) {
    Vuetify.framework.rtl = isRTL
    state.isRTL = isRTL
  },
  setChangeTableView (state, changeTable) {
    state.changeTableView = changeTable
  },
  setContentBoxed (state, isBoxed) {
    state.isContentBoxed = isBoxed
  },
  setMenuTheme (state, theme) {
    state.menuTheme = theme
  },
  setToolbarTheme (state, theme) {
    state.toolbarTheme = theme
  },
  setTimeZone (state, zone) {
    state.time.zone = zone
  },
  setTimeFormat (state, format) {
    state.time.format = format
  },
  setCurrency (state, currency) {
    state.currency = currency
  },
  setToolbarDetached (state, isDetached) {
    state.isToolbarDetached = isDetached
  }
}

export const actions = {
  showToast ({ state, commit }, message) {
    if (state.toast.show) { commit('hideToast') }
    setTimeout(() => {
      commit('showToast', {
        color: 'black',
        message,
        timeout: 3000
      })
    })
  },
  showError ({ state, commit }, { message = 'Failed!', error }) {
    if (state.toast.show) { commit('hideToast') }
    setTimeout(() => {
      commit('showToast', {
        color: 'error',
        message: message + ' ' + error.message,
        timeout: 10000
      })
    })
  },
  showSuccess ({ state, commit }, message) {
    if (state.toast.show) { commit('hideToast') }
    setTimeout(() => {
      commit('showToast', {
        color: 'success',
        message,
        timeout: 3000
      })
    })
  },
  resetToast ({ state, commit }, message) {
    commit('resetToast')
    setTimeout(() => {
      commit('showToast', {
        color: 'success',
        message,
        timeout: 3000
      })
    })
  },
  setGlobalTheme ({ commit }, data) {
    commit('setGlobalTheme', data)
  },
  setRTL ({ commit }, data) {
    commit('setRTL', data)
  },
  setChangeTableView ({ commit }, data) {
    commit('setChangeTableView', data)
  },
  setContentBoxed ({ commit }, data) {
    commit('setContentBoxed', data)
  },
  setMenuTheme ({ commit }, data) {
    commit('setMenuTheme', data)
  },
  setToolbarTheme ({ commit }, data) {
    commit('setToolbarTheme', data)
  },
  setTimeZone ({ commit }, data) {
    commit('setTimeZone', data)
  },
  setTimeFormat ({ commit }, data) {
    commit('setTimeFormat', data)
  },
  setCurrency ({ commit }, data) {
    commit('setCurrency', data)
  },
  setToolbarDetached ({ commit }, data) {
    commit('setToolbarDetached', data)
  }
}
