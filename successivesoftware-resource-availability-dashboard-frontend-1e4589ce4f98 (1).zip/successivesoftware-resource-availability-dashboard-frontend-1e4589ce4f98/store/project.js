/* eslint-disable no-useless-catch */
function initialState () {
  return {
    newProject: {},
    technology: [],
    projectLifeCycleModel: [],
    projectType: [],
    governanceCategories: [],
    department: [],
    billingTypes: [],
    billingMediums: [],
    projectList: [],
    projectDetail: {},
    manageReportingDetail: {},
    inititationRequest: {},
    users: [],
    projectSearchString: '',
    projectWsrDefaultFilter: null,
    progressStageGraphFilter:null,
    projectDashboardPagination: 10,
    activityLogAccordion: { date: null, month: null },
    createdProjectRedmine: {},
    createdDraftProject: {},
    projectRequisition: {},
    createdRequisition: {},
    createdAllocation: {},
    directCreatedAllocation: {},
    createdAllocationApproval: {},
    allocatedResources: [],
    deAllocatedResources: [],
    extensionResources: [],
    requestedReportingData: [],
    mappedResources: [],
    deAllocationMapping: [],
    customDialog: {
      status: false,
      title: '',
      message: '',
      nextRoute: ''
    },
    projectClosureList: {
      uuid: false,
      checkboxIds: {
        projectManagement: [],
        postBilling: [],
        clientReceiving: []
      }
    },
    projectDetailWithHoldRequest: {},
    activityProjectType: [],
    projectActivityLog: {},
    declinedResourceAllocation: {},
    isButtonLoading: false,
    overlay: false,
    overlayLoading: false,
    allocationLog: {},
    deallocationLog: {},
    resourceUnMappedRecord: [],
    projectSpecificAction: {},
    projectNames: [],
    projectBillingTypes: [],
    projectRequisitionDepartment: {},
    projectDomainList: [],
    redminProjectNameList: [],
    projectNameList: [],
    addedDomain: {},
    allocatedResourceData: [],
    rcaDetail: {},
    newRca: {},
    rcaList: [],
    kekaResourceDetail: {},
    pyramidSettingDetail: {},
    resourcePyramidSettingDetail: {},
    rcaReporterUser: [],
    kedbList: [],
    kedbDetail: {},
    kedbTagList: [],
    addedTag: {},
    newKedb: {},
    newAttachment: {},
    kedbProjectList: [],
    kedbRcaList: [],
    projectRestart: [],
    newTechnology: {},
    managerRequestList: [],
    deptWiseReportingList: [],
    managerApprovals: [],
    changeDirectRm: {},
    directReportingListToRM: [],
    projectReport: [],
    addedClient: {},
    projectClientList: [],
    calendarReport: [],
    rejectList: [],
    rejectedData: {},
    departmentWiseRagStatus: []
  }
}
export const state = () => initialState()
export const getters = {
  getCreatedProject: (state) => state.newProject,
  getTechnologies: (state) => state.technology,
  getProjectLifeCycleModel: (state) => state.projectLifeCycleModel,
  getProjectType: (state) => state.projectType,
  getGovernanceCategories: (state) => state.governanceCategories,
  getDepartments: (state) => state.department,
  getBillingTypes: (state) => state.billingTypes,
  getBillingMediums: (state) => state.billingMediums,
  getProjectList: (state) => state.projectList,
  getUserList: (state) => state.users,
  getProjectSearchString: (state) => state.projectSearchString,
  getProjectWsrDefaultFilter: (state) => state.projectWsrDefaultFilter,
  getProjectDashboardPagination: (state) => state.projectDashboardPagination,
  getActivityLogAccordion: (state) => state.activityLogAccordion,
  getProjectDetail: (state) => state.projectDetail,
  getManageReportingDetail: (state) => state.manageReportingDetail,
  getCreatedProjectRedmine: (state) => state.createdProjectRedmine,
  getCreatedDraftProject: (state) => state.createdDraftProject,
  getProjectRequisition: (state) => state.projectRequisition,
  getCreatedRequisition: (state) => state.createdRequisition,
  getCreatedAllocation: (state) => state.createdAllocation,
  getDirectCreatedAllocation: (state) => state.directCreatedAllocation,
  getCreatedAllocationApproval: (state) => state.createdAllocationApproval,
  getProjectAllocatedResources: (state) => state.allocatedResources,
  getDeAllocatedResources: (state) => state.deAllocatedResources,
  getExtensionResources: (state) => state.extensionResources,
  getRequestedReportingData: (state) => state.requestedReportingData,
  getMappedResources: (state) => state.mappedResources,
  getDeAllocationMapping: (state) => state.deAllocationMapping,
  getCustomDialog: (state) => state.customDialog,
  getProjectClosureList: (state) => state.projectClosureList,
  getProjectHoldRequest: (state) => state.projectDetailWithHoldRequest,
  getActivityProjectType: (state) => state.activityProjectType,
  getProjectActivityLog: (state) => state.projectActivityLog,
  getInititationRequest: (state) => state.inititationRequest,
  getDeclinedResourceAllocationData: (state) => state.declinedResourceAllocation,
  isButtonLoading: (state) => state.isButtonLoading,
  overlay: (state) => state.overlay,
  getOverlayLoading: (state) => state.overlayLoading,
  getAllocationLog: (state) => state.allocationLog,
  getDeAllocationLog: (state) => state.deallocationLog,
  getResourceUnMappedRecord: (state) => state.resourceUnMappedRecord,
  getProjectSpecificAction: (state) => state.projectSpecificAction,
  getProjectNames: (state) => state.projectNames,
  getProjectBillingTypes: (state) => state.projectBillingTypes,
  getProjectRequisitionDepartment: (state) => state.projectRequisitionDepartment,
  getProjectDomains: (state) => state.projectDomainList,
  getRedminProjectNameList: (state) => state.redminProjectNameList,
  getProjectNameListing: (state) => state.projectNameList,
  getAddedDomain: (state) => state.addedDomain,
  getAllocatedResourceData: (state) => state.allocatedResourceData,
  getRcaDetail: (state) => state.rcaDetail,
  getCreatedRca: (state) => state.newRca,
  getRcaList: (state) => state.rcaList,
  getKekaResourceDetailByDepartment: (state) => state.kekaResourceDetail,
  getPyramidSettingDetail: (state) => state.pyramidSettingDetail,
  getResourcePyramidSettingDetail: (state) => state.resourcePyramidSettingDetail,
  getRcaReporterUsers: (state) => state.rcaReporterUser,
  getKedbList: (state) => state.kedbList,
  getKedbDetail: (state) => state.kedbDetail,
  getKedbTags: (state) => state.kedbTagList,
  getAddedTag: (state) => state.addedTag,
  getCreatedKedb: (state) => state.newKedb,
  getKedbProjectList: (state) => state.kedbProjectList,
  getKedbRcaList: (state) => state.kedbRcaList,
  getCreatedAttachment: (state) => state.newAttachment,
  getRestartProject: (state) => state.projectRestart,
  getNewTechnology: (state) => state.newTechnology,
  getManagerRequests: (state) => state.managerRequestList,
  getDeptWiseReporting: (state) => state.deptWiseReportingList,
  getDirectReportingListToRM: (state) => state.directReportingListToRM,
  getManagerApprovals: (state) => state.managerApprovals,
  getChangeDirectRm: (state) => state.changeDirectRm,
  getProjectReport: (state) => state.projectReport,
  getAddedClient: (state) => state.addedClient,
  getProjectClients: (state) => state.projectClientList,
  getResourceCalendarReport: (state) => state.calendarReport,
  getRejectList: (state) => state.rejectList,
  getRejectedData: (state) => state.rejectedData,
  getDepartmentWiseRagStatus: (state) => state.departmentWiseRagStatus,
  getProgressStageGraphFilter: (state) => state.progressStageGraphFilter
}

export const mutations = {
  setRejectList (state, rejectData) {
    state.rejectList = rejectData
  },
  setRejectRequisition (state, responeData) {
    state.rejectedData = responeData
  },
  setCreatedProject (state, projectData) {
    state.newProject = projectData
  },
  setResourceCalendarReport (state, calendarData) {
    state.calendarReport = calendarData
  },
  setTechnologies (state, technologyData) {
    state.technology = technologyData
  },
  setProjectLifeCycleModel (state, data) {
    state.projectLifeCycleModel = data
  },
  setNewTechnology (state, technologyData) {
    state.newTechnology = technologyData
    state.technology.push(technologyData)
  },
  setProjectType (state, projectTypeData) {
    state.projectType = projectTypeData
  },
  setGovernanceCategories (state, governanceCategoryData) {
    state.governanceCategories = governanceCategoryData
  },
  setDepartments (state, deptData) {
    state.department = deptData
  },
  setBillingTypes (state, billingTypeData) {
    state.billingTypes = billingTypeData
  },
  setBillingMediums (state, billingMediumData) {
    state.billingMediums = billingMediumData
  },
  setProjectList (state, projectListData) {
    state.projectList = projectListData
  },
  setUsersList (state, userListData) {
    state.users = userListData
  },
  setProjectSearchString (state, value) {
    state.projectSearchString = value
  },
  setProjectWsrDefaultFilter (state, value) {
    state.projectWsrDefaultFilter = value
  },
  setProgressStageGraphFilter (state, value) {
    state.progressStageGraphFilter = value
  },
  setProjectDashboardPagination (state, value) {
    state.projectDashboardPagination = value
  },
  setActivityLogAccordion (state, value) {
    state.activityLogAccordion = value
  },
  setProjectDetail (state, projectData) {
    state.projectDetail = projectData
  },
  setManageReportingDetail (state, data) {
    state.manageReportingDetail = data
  },
  setActivityProjectTypes (state, projectType) {
    state.activityProjectType = projectType
  },
  setProjectActivityLogs (state, activityLog) {
    state.projectActivityLog = activityLog
  },
  setInititationRequest (state, projectData) {
    state.inititationRequest = projectData
  },
  setCreatedProjectRedmine (state, projectData) {
    state.createdProjectRedmine = projectData
  },
  setCreatedDraftProject (state, projectData) {
    state.createdDraftProject = projectData
  },
  setProjectRequisition (state, projectData) {
    state.projectRequisition = projectData
  },
  setCreatedRequisitionData (state, requisitionData) {
    state.createdRequisition = requisitionData
  },
  setCreatedAllocationData (state, allocationData) {
    state.createdAllocation = allocationData
  },
  setDirectCreatedAllocationData (state, allocationData) {
    state.directCreatedAllocation = allocationData
  },
  setCreatedAllocationApproval (state, allocationApprovalData) {
    state.createdAllocationApproval = allocationApprovalData
    if (allocationApprovalData) {
      state.allocatedResources = state.allocatedResources.map((resource) => {
        resource.resource_allocation = resource.resource_allocation.map((allocated) => {
          if (allocated.uuid === allocationApprovalData.uuid) {
            allocated.allocation_status = allocationApprovalData.status
          }

          return allocated
        })

        return resource
      })
    }
  },
  setCreatedDeAllocationData (state, deallocationData) {
    state.deAllocatedResources = deallocationData
  },
  setCreatedExtensionData (state, extensionData) {
    state.extensionResources = extensionData
  },
  setRequestedReportingManagerData (state, requestedData) {
    state.requestedReportingData = requestedData
  },
  setProjectAllocatedResources (state, allocatedResourceData) {
    state.allocatedResources = allocatedResourceData
  },
  setResourceMappingData (state, mappedResourceData) {
    state.mappedResources = mappedResourceData
  },
  setDeAllocationMappingData (state, DeAllocatedmappedResourceData) {
    state.deAllocationMapping = DeAllocatedmappedResourceData
  },
  setCustomDialog (state, dialogData) {
    state.customDialog = dialogData
  },
  setProjectClosureList (state, closureData) {
    state.projectClosureList.uuid = closureData.uuid
    const { project_checklist: projectChecklist, project_close_status: projectCloseStatus, project_redmine_id: redmineId } = closureData

    if (projectChecklist !== null) {
      const checkBoxIds = JSON.parse(projectChecklist)

      state.projectClosureList.checkboxIds.projectManagement = checkBoxIds.projectManagement
      state.projectClosureList.checkboxIds.postBilling = checkBoxIds.postBilling
      state.projectClosureList.checkboxIds.clientReceiving = checkBoxIds.clientReceiving
      state.projectClosureList.project_close_status = projectCloseStatus
      state.projectClosureList.project_redmine_id = redmineId
    } else {
      state.projectClosureList.checkboxIds.projectManagement = []
      state.projectClosureList.checkboxIds.postBilling = []
      state.projectClosureList.checkboxIds.clientReceiving = []
    }
  },
  setProjectHoldRequest (state, projectHoldData) {
    state.projectDetailWithHoldRequest = projectHoldData
  },
  setDeclinedResourceAllocationData (state, data) {
    state.declinedResourceAllocation = data
  },
  setAllocationLogs (state, data) {
    state.allocationLog = data
  },
  setDeallocationLogs (state, data) {
    state.deallocationLog = data
  },
  setProjectRequisitionByDepartment (state, projectData) {
    state.projectRequisitionDepartment = projectData
  },
  resetState (state) {
    // acquire initial state
    const s = initialState()

    Object.keys(s).forEach((key) => {
      state[key] = s[key]
    })
  },
  setLoading (state) {
    state.isButtonLoading = !state.isButtonLoading
    state.overlay = !state.overlay
  },
  setOverlayLoading (state, value) {
    state.overlayLoading = value
  },
  setResourceUnMappedRecord (state, resourceUnMappedRecord) {
    state.resourceUnMappedRecord = resourceUnMappedRecord
  },
  setProjectSpecificAction (state, projectActions) {
    state.projectSpecificAction = projectActions
  },
  setProjectNames (state, projectNamesData) {
    state.projectNames = projectNamesData
  },
  setProjectBillingTypes (state, projectBillingTypesData) {
    state.projectBillingTypes = projectBillingTypesData
  },
  setProjectDomainList (state, projectDomain) {
    state.projectDomainList = projectDomain
  },
  setProjectClientList (state, projectClient) {
    state.projectClientList = projectClient
  },
  setCreatedClient (state, projectClient) {
    state.addedClient = projectClient

    state.projectClientList.push(projectClient)
  },
  setProjectNameListing (state, projectList) {
    state.projectNameList = projectList
  },
  setRedminProjectNameListing (state, projectList) {
    state.redminProjectNameList = projectList
  },
  setCreatedDomain (state, projectDomain) {
    state.addedDomain = projectDomain
    state.projectDomainList.push(projectDomain)
  },
  setAllocatedResourceData (state, resourceData) {
    state.allocatedResourceData = resourceData
  },
  setRcaDetail (state, rcaData) {
    state.rcaDetail = rcaData
  },
  setCreatedRca (state, rcaData) {
    state.newRca = rcaData
  },
  setRcaList (state, rcaListData) {
    state.rcaList = rcaListData
  },
  setKekaResourceDetail (state, resourceDetail) {
    state.kekaResourceDetail = resourceDetail
  },
  setDepartmentWiseRagStatus (state, RagData) {
    state.departmentWiseRagStatus = RagData
  },
  setPyramidSetting (state, settingDetails) {
    state.pyramidSettingDetail = settingDetails
  },
  setResourcePyramidSettings (state, resourcePyramidSettingsData) {
    state.resourcePyramidSettingDetail = resourcePyramidSettingsData
  },
  setRcaReporterUsers (state, rcaReporterUserData) {
    state.rcaReporterUser = rcaReporterUserData
  },
  setKedbList (state, kedbListData) {
    state.kedbList = kedbListData
  },
  setKedbDetail (state, kedbData) {
    state.kedbDetail = kedbData
  },
  setKedbTagList (state, kedbTag) {
    state.kedbTagList = kedbTag
  },
  setCreatedTag (state, kedbTag) {
    state.addedTag = kedbTag
    state.kedbTagList.push(kedbTag)
  },
  setCreatedKedb (state, kedbData) {
    state.newKedb = kedbData
  },
  setKedbProjectList (state, KedbProjectListData) {
    state.kedbProjectList = KedbProjectListData
  },
  setKedbRcaList (state, kedbRcaListData) {
    state.kedbRcaList = kedbRcaListData
  },
  setCreatedAttachment (state, attachmentData) {
    state.newAttachment = attachmentData
  },
  setRestartProject (state, restartData) {
    state.projectRestart = restartData
  },
  setManagerRequests (state, managerRequestData) {
    state.managerRequestList = managerRequestData
  },
  setDeptWiseReporting (state, deptWiseReportingData) {
    state.deptWiseReportingList = deptWiseReportingData
  },
  setDirectReportingListToRM (state, directReportingListToRmData) {
    state.directReportingListToRM = directReportingListToRmData
  },
  setManagerApproval (state, managerApprovalData) {
    state.managerApprovals = managerApprovalData
  },
  setChangeDirectRM (state, changeDirectRmData) {
    state.changeDirectRm = changeDirectRmData
  },
  setProjectReportData (state, projectReportData) {
    state.projectReport = projectReportData
  }
}

export const actions = {
  async setCreatedProjectData ({ commit, rootState }, requestData) {
    try {
      const setRoute = requestData.createInitiation ? '/project-initiation' : `/project/${requestData.project_id}/draft-edit`
      const requestPayload = {
        'project_name': requestData.project_name,
        'company_name': requestData.company_name,
        'company_address': requestData.company_address,
        'project_domain': requestData.project_domain,
        'billing_type': requestData.billing_type,
        'approved_hours': requestData.approved_hours,
        'project_components': JSON.stringify(requestData.project_components),
        'maximum_hours_billed': requestData.maximum_hours_billed,
        'initiation_date': requestData.initiation_date,
        'status': '1',
        'project_documents_link': JSON.stringify(requestData.project_documents_link),
        'project_manager_id': requestData.project_manager_id,
        'account_manager_id': requestData.account_manager_id,
        'technologies': requestData.technologies,
        'estimated_timeline_to': requestData.estimated_timeline_to,
        'estimated_timeline_from': requestData.estimated_timeline_from,
        'client_detail': JSON.stringify(requestData.client_detail),
        'project_type_id': requestData.project_type_id,
        'gov_category_id': requestData.gov_category_id,
        'subProject': requestData.subProject,
        'parent_id': requestData.parent_id,
        'lifecycle_model_id': requestData.lifecycle_model_id,
        'state': requestData.companyState,
        'country': requestData.companyCountry,
        'billing_interval': requestData.billingInterval,
        'project_id': requestData.project_id,
        'billing_medium': requestData.billing_medium,
        'project_summary': requestData.project_summary
      }

      await this.$resourceApi.post('/project', { }, {
        data: requestPayload,
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }).then((response) => {
        let projectData = {}
        let dialogData = {}
        const { data: responseData, status } = response || {}

        if (status === 201) {
          projectData = responseData
          dialogData = {
            status: true,
            title: 'Success',
            message: `Cheers Captain! Project has been Initiated Successfully
            All project stakeholders will be notified about the project initiation`,
            nextRoute: setRoute,
            sameRoute: false
          }
        }
        commit('setCreatedProject', projectData.data)
        commit('setCustomDialog', dialogData)
      }).catch((error) => {
        const message = 'Something went wrong!'

        commit('setCustomDialog', {
          status: true,
          title: 'Error',
          message,
          errormessage: error,
          nextRoute: '/'
        })
      })
    } catch (e) {
      commit('setCreatedProject', {})
    }
  },
  // export resource calendar report
  async fetchResourceCalendarReport ({ commit, rootState }, projectIds) {
    try {
      const requestPayload = {
        'project_ids': projectIds
      }
      const config = {
        data: requestPayload,
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 900000
      }
      const { data } = await this.$resourceApi.put('/resource-calendar', config)

      if (data.status === 200) {
        const resourceCalReportData = data.data

        commit('setResourceCalendarReport', resourceCalReportData)
      }
    } catch (e) {
      throw e
    }
  },
  async setCreatedDraftProjectData ({ commit, rootState }, requestData) {
    try {
      const setRoute = requestData.createInitiation ? '/project-initiation' : `/project/${requestData.project_id}/draft-edit`
      const requestPayload = {
        'project_name': requestData.project_name,
        'company_name': requestData.company_name,
        'company_address': requestData.company_address,
        'project_domain': requestData.project_domain,
        'billing_type': requestData.billing_type,
        'approved_hours': requestData.approved_hours,
        'project_components': JSON.stringify(requestData.project_components),
        'maximum_hours_billed': requestData.maximum_hours_billed,
        'initiation_date': requestData.initiation_date,
        'status': '1',
        'project_documents_link': JSON.stringify(requestData.project_documents_link),
        'project_manager_id': requestData.project_manager_id,
        'account_manager_id': requestData.account_manager_id,
        'technologies': requestData.technologies,
        'estimated_timeline_to': requestData.estimated_timeline_to,
        'estimated_timeline_from': requestData.estimated_timeline_from,
        'client_detail': JSON.stringify(requestData.client_detail),
        'project_type_id': requestData.project_type_id,
        'gov_category_id': requestData.gov_category_id,
        'subProject': requestData.subProject,
        'parent_id': requestData.parent_id,
        'lifecycle_model_id': requestData.lifecycle_model_id,
        'state': requestData.companyState,
        'country': requestData.companyCountry,
        'billing_interval': requestData.billingInterval,
        'project_id': requestData.project_id,
        'billing_medium': requestData.billing_medium,
        'project_summary': requestData.project_summary
      }

      await this.$resourceApi.post('/project-draft', { }, {
        data: requestPayload,
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }).then((response) => {
        let projectData = {}
        let dialogData = {}
        const { data: responseData, status } = response || {}

        if (status === 201) {

          projectData = responseData
          dialogData = {
            status: true,
            title: 'Success',
            message: `No Worries Captain! We will take things slow and steady
            Project has been saved as draft successfully.`,
            nextRoute: setRoute,
            sameRoute: false
          }

        }
        commit('setCreatedDraftProject', projectData.data)
        commit('setCustomDialog', dialogData)
      }).catch((error) => {
        const message = 'Something went wrong!'

        commit('setCustomDialog', {
          status: true,
          title: 'Error',
          message,
          errormessage: error,
          nextRoute: '/'
        })
      })
    } catch (e) {
      commit('setCreatedDraftProject', {})
    }
  },
  async fetchTechnologies ({ commit, rootState }) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 60000
      }
      const { data, status } = await this.$resourceApi.get('/technology', config)

      if (status === 200 && data.data !== null) {
        commit('setTechnologies', data.data)
      }
    } catch (e) {
      commit('setTechnologies', [])
    }
  },
  async fetchProjectLifeCycleModel ({ commit, rootState }) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data, status } = await this.$resourceApi.get('/lifecycle-model', config)

      if (status === 200 && data.data !== null) {
        commit('setProjectLifeCycleModel', data.data)
      }
    } catch (e) {
      commit('setProjectLifeCycleModel', [])
    }
  },
  async createTechnologies ({ commit, rootState }, requestData) {
    try {
      const requestPayload = {
        'name': requestData.techName
      }

      await this.$resourceApi.post('/technology', { }, {
        data: requestPayload,
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }).then((response) => {
        let dialogData = {}
        const { status, data } = response || {}

        if (status === 201) {
          dialogData = {
            status: false,
            title: 'Success',
            message: 'You have successfully created a new technology.',
            nextRoute: '/project-dashboard'
          }
          commit('setNewTechnology', data.data)
        } else {
          dialogData = {
            status: false,
            title: 'Error',
            message: 'Technology name is duplicate please try a different name!',
            errormessage: 'Invalid Status code returned.',
            nextRoute: '/project-dashboard'
          }
        }
        commit('setCustomDialog', dialogData)
        commit('setNewTechnology', [])
      }).catch((error) => {
        const message = 'Something went wrong!'

        commit('setCustomDialog', {
          status: false,
          title: 'Error',
          message,
          errormessage: error,
          nextRoute: '/project-dashboard'
        })
      })
    } catch (e) {
      commit('setNewTechnology', [])
    }
  },
  async fetchProjectType ({ commit, rootState }) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 60000
      }
      const { data } = await this.$resourceApi.get('/project-type', config)

      commit('setProjectType', data.data)
    } catch (e) {
      commit('setProjectType', [])
    }
  },
  async fetchGovernanceCategories ({ commit, rootState }) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 60000
      }
      const { data } = await this.$resourceApi.get('/governance-category', config)

      commit('setGovernanceCategories', data.data)
    } catch (e) {
      commit('setGovernanceCategories', [])
    }
  },
  async fetchDepartments ({ commit, rootState }) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 60000
      }
      const { data } = await this.$resourceApi.get('/department', config)

      commit('setDepartments', data.data)
    } catch (e) {
      commit('setDepartments', [])
    }
  },
  async fetchBillingTypes ({ commit, rootState }) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data } = await this.$resourceApi.get('/billing-type', config)

      commit('setBillingTypes', data.data)
    } catch (e) {
      commit('setBillingTypes', [])
    }
  },
  async fetchBillingMediums ({ commit, rootState }) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data } = await this.$resourceApi.get('/billing-medium', config)

      commit('setBillingMediums', data.data)
    } catch (e) {
      commit('setBillingMediums', [])
    }
  },
  async fetchProjectList ({ commit, rootState }) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId }
      }
      const { data, status } = await this.$resourceApi.get('/project', config)

      if (status === 200) {
        commit('setProjectList', data.data)
      }
    } catch (e) {
      commit('setProjectList', [])
    }
  },
  // get reject reason list for requisition rejection
  async fetchRejectList ({ commit, rootState }) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId }
      }
      const { data, status } = await this.$resourceApi.get('/get-reject-reason', config)

      if (status === 200) {
        commit('setRejectList', data.data)
      }
    } catch (e) {
      commit('setRejectList', [])
    }
  },
  async rejectReuisition ({ commit, rootState }, requestData) {
    try {
      await this.$resourceApi.put('/reject-requisition', { }, {
        data: requestData,
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }).then((response) => {
        const { data: responseData, status } = response || {}

        if (status === 200) {
          commit('setRejectRequisition', responseData)
        }
      }).catch((error) => {
        console.log(error)
      })
    } catch (e) {
      commit('setRejectRequisition', {})
    }
  },
  async fetchUserList ({ commit, rootState }) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 60000
      }
      const { data } = await this.$resourceApi.get('/user', config)

      commit('setUsersList', data.data)
    } catch (e) {
      commit('setUsersList', [])
    }
  },

  async fetchProjectDetail ({ commit, rootState }, id) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data, status } = await this.$resourceApi.get(`/project/${id}`, config)

      if (status === 200) {
        commit('setProjectDetail', data.data)
      }
    } catch (e) {
      commit('setProjectDetail', {})
    }
  },
  async fetchManageReportingDetail ({ commit, rootState }, id) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 100000
      }
      const { data, status } = await this.$resourceApi.get(`/manager-requests/${id}`, config)

      if (status === 200) {
        commit('setManageReportingDetail', data.data)
      }
    } catch (e) {
      commit('setManageReportingDetail', {})
    }
  },
  async fetchActivityProjectTypes ({ commit, rootState }, id) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 60000
      }
      const { data, status } = await this.$resourceApi.get('/project-actiontypes', config)

      if (status === 200) {
        commit('setActivityProjectTypes', data.data)
      }
    } catch (e) {
      commit('setActivityProjectTypes', {})
    }
  },
  async fetchProjectActivityLogs ({ commit, rootState }, id) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data, status } = await this.$resourceApi.get(`/show-project-activity/${id}`, config)

      if (status === 200) {
        commit('setProjectActivityLogs', data.data)
      }
    } catch (e) {
      commit('setProjectActivityLogs', {})
    }
  },
  async fetchResourceUnMappedRecord ({ commit, rootState }, id) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data } = await this.$resourceApi.get(`/allocation-map/${id}`, config)

      commit('setResourceUnMappedRecord', data.data)
    } catch (e) {
      commit('setResourceUnMappedRecord', {})
    }
  },
  async fetchProjectSpecificAction ({ commit, rootState }, id) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data } = await this.$resourceApi.get(`/project-action/${id}`, config)

      commit('setProjectSpecificAction', data.data)
    } catch (e) {
      commit('setProjectSpecificAction', {})
    }
  },
  async fetchProjectNames ({ commit, rootState }) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data } = await this.$resourceApi.get('/projects', config)

      commit('setProjectNames', data.data)
    } catch (e) {
      commit('setProjectNames', {})
    }
  },
  async fetchProjectBillingTypes ({ commit, rootState }) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data } = await this.$resourceApi.get('/billing-types', config)

      commit('setProjectBillingTypes', data.data)
    } catch (e) {
      commit('setProjectBillingTypes', {})
    }
  },
  setCustomDialog ({ commit, rootState }, dialogData) {
    try {
      commit('setCustomDialog', dialogData)
    } catch (e) {
      commit('setCustomDialog', {
        status: false,
        title: '',
        message: '',
        nextRoute: ''
      })
    }
  },
  async updateProjectDetails ({ commit, rootState }, { id, requestData }) {
    try {
      const requestPayload = {
        'project_name': requestData.project_name,
        'company_name': requestData.company_name,
        'company_address': requestData.company_address,
        'project_domain': requestData.project_domain,
        'billing_type': requestData.billing_type,
        'approved_hours': requestData.approved_hours,
        'project_components': JSON.stringify(requestData.project_components),
        'maximum_hours_billed': requestData.maximum_hours_billed,
        'initiation_date': requestData.initiation_date,
        'status': requestData.status,
        'project_documents_link': JSON.stringify(requestData.project_documents_link),
        'project_manager_id': requestData.project_manager_id,
        'account_manager_id': requestData.account_manager_id,
        // 'specific_requests': requestData.specific_requests,
        'technologies': requestData.technologies,
        'estimated_timeline_to': requestData.estimated_timeline_to,
        'estimated_timeline_from': requestData.estimated_timeline_from,
        'client_detail': JSON.stringify(requestData.client_detail),
        'project_type_id': requestData.project_type_id,
        'gov_category_id': requestData.gov_category_id,
        'subProject': requestData.subProject,
        'parent_id': requestData.parent_id,
        'lifecycle_model_id': requestData.lifecycle_model_id,
        'state': requestData.state,
        'country': requestData.country,
        'billing_interval': requestData.billing_interval,
        'billing_medium': requestData.billing_medium,
        'project_summary': requestData.project_summary
      }

      await this.$resourceApi.put(`/project/${id}`, { }, {
        data: requestPayload,
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }).then((response) => {
        let projectData = {}
        let dialogData = {}
        const { data: responseData, status } = response || {}

        if (status === 200) {
          projectData = responseData
          dialogData = {
            status: true,
            title: 'Success',
            message: `Yay! Project Details Updated Successfully, ${projectData.data.project_name} We will notify the project stakeholders about the updated details.`,
            nextRoute: '/project-dashboard'
          }
        }
        commit('setProjectDetail', projectData)
        commit('setCustomDialog', dialogData)
      }).catch((error) => {
        const message = 'Something went wrong!'

        commit('setCustomDialog', {
          status: true,
          title: 'Error',
          message,
          errormessage: error,
          nextRoute: '/project-dashboard'
        })
      })
    } catch (e) {
      commit('setProjectDetail', {})
    }
  },
  async updateInititationDetails ({ commit, rootState }, { id, requestData }) {
    try {
      const requestPayload = {
        'project_name': requestData.project_name,
        'company_name': requestData.company_name,
        'company_address': requestData.company_address,
        'project_domain': requestData.project_domain,
        'billing_type': requestData.billing_type,
        'approved_hours': requestData.approved_hours,
        'project_components': JSON.stringify(requestData.project_components),
        'maximum_hours_billed': requestData.maximum_hours_billed,
        'initiation_date': requestData.initiation_date,
        'status': requestData.status,
        'project_documents_link': JSON.stringify(requestData.project_documents_link),
        'project_manager_id': requestData.project_manager_id,
        'account_manager_id': requestData.account_manager_id,
        // 'specific_requests': requestData.specific_requests,
        'project_summary': requestData.project_summary,
        'technologies': requestData.technologies,
        'estimated_timeline_to': requestData.estimated_timeline_to,
        'estimated_timeline_from': requestData.estimated_timeline_from,
        'client_detail': JSON.stringify(requestData.client_detail),
        'project_type_id': requestData.project_type_id,
        'gov_category_id': requestData.gov_category_id,
        'comment': requestData.comment,
        'is_accept': requestData.is_accept,
        'subProject': requestData.subProject,
        'parent_id': requestData.parent_id,
        'lifecycle_model_id': requestData.lifecycle_model_id,
        'state': requestData.state,
        'country': requestData.country,
        'billing_interval': requestData.billing_interval,
        'billing_medium': requestData.billing_medium
      }

      await this.$resourceApi.put(`/initiation-approval/${id}`, { }, {
        data: requestPayload,
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }).then((response) => {
        let projectData = {}
        let dialogData = {}
        const { data: responseData, status } = response || {}

        if (status === 200) {
          projectData = responseData
          if (requestData.is_accept === true) {
            dialogData = {
              status: true,
              title: 'Success',
              message: `Cheers Captain! Project has been Initiated Successfully
              All project stakeholders will be notified about the project initiation`,
              nextRoute: '/project-dashboard',
              sameRoute: false
            }
          }
          else {
            dialogData = {
              status: true,
              title: 'Success',
              message:`Nothing is perfect at the first attempt, Captain!
                      Project Initiation form has been declined,
                      The Project Initiator will be notified about the same...`,
              nextRoute: '/project-dashboard',
              sameRoute: false
            }
          }
        }
        commit('setInititationRequest', projectData)
        commit('setCustomDialog', dialogData)
      }).catch((error) => {
        const message = 'Something went wrong!'

        commit('setCustomDialog', {
          status: true,
          title: 'Error',
          message,
          errormessage: error,
          nextRoute: '/project-dashboard'
        })
      })
    } catch (e) {
      commit('setInititationRequest', {})
    }
  },
  async updateInititationRequestDetails ({ commit, rootState }, { id, requestData }) {
    try {
      const requestPayload = {
        'project_name': requestData.project_name,
        'company_name': requestData.company_name,
        'company_address': requestData.company_address,
        'project_domain': requestData.project_domain,
        'billing_type': requestData.billing_type,
        'approved_hours': requestData.approved_hours,
        'project_components': JSON.stringify(requestData.project_components),
        'maximum_hours_billed': requestData.maximum_hours_billed,
        'initiation_date': requestData.initiation_date,
        'status': requestData.status,
        'project_documents_link': JSON.stringify(requestData.project_documents_link),
        'project_manager_id': requestData.project_manager_id,
        'account_manager_id': requestData.account_manager_id,
        // 'specific_requests': requestData.specific_requests,
        'project_summary': requestData.project_summary,
        'technologies': requestData.technologies,
        'estimated_timeline_to': requestData.estimated_timeline_to,
        'estimated_timeline_from': requestData.estimated_timeline_from,
        'client_detail': JSON.stringify(requestData.client_detail),
        'project_type_id': requestData.project_type_id,
        'gov_category_id': requestData.gov_category_id,
        'lifecycle_model_id': requestData.lifecycle_model_id,
        'state': requestData.state,
        'country': requestData.country,
        'comment': requestData.comment,
        'is_accept': requestData.is_accept,
        'billing_interval': requestData.billing_interval,
        'subProject': requestData.subProject,
        'parent_id': requestData.parent_id,
        'billing_medium': requestData.billing_medium
      }

      await this.$resourceApi.put(`/initiation-request-edit/${id}`, { }, {
        data: requestPayload,
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }).then((response) => {
        let projectData = {}
        let dialogData = {}
        const { data: responseData, status } = response || {}

        if (status === 200) {
          projectData = responseData
          dialogData = {
            status: true,
            title: 'Success',
            message: 'The project details have been successfully updated.',
            nextRoute: '/project-dashboard'
          }
        }
        commit('setInititationRequest', projectData)
        commit('setCustomDialog', dialogData)
      }).catch((error) => {
        const message = 'Something went wrong!'

        commit('setCustomDialog', {
          status: true,
          title: 'Error',
          message,
          errormessage: error,
          nextRoute: '/project-dashboard'
        })
      })
    } catch (e) {
      commit('setInititationRequest', {})
    }
  },

  async setProjectCreationData ({ commit, rootState }, requestData) {
    try {
      const requestPayload = {
        'project_id': requestData.project_id,
        'status': requestData.status,
        'project_status': requestData.project_status
      }

      await this.$resourceApi.put('/project-creation', { }, {
        data: requestPayload,
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }).then((response) => {
        let creationData = {}
        let dialogData = {}
        const { data: responseData, status } = response || {}

        if (status === 200) {
          creationData = responseData
          dialogData = {
            status: true,
            title: 'Success',
            message: `Cheers Captain!
                      Project has been Created Successfully
                      We will notify the project stakeholders about the creation of the project on Redmine`,
            nextRoute: '/project-dashboard'
          }
        }
        commit('setCustomDialog', dialogData)
      }).catch((error) => {
        const message = 'Something went wrong!'

        commit('setCustomDialog', {
          status: true,
          title: 'Error',
          message,
          errormessage: error,
          nextRoute: '/project-dashboard'
        })
      })
    } catch (e) {
      commit('setProjectDetail', {})
    }
  },

  async setResourceRequisitionData ({ commit, rootState }, requestData) {
    try {
      const requestPayload = {
        'project_id': requestData.project_id,
        'resource_data': requestData.resource_data,
        'project_status': requestData.project_status
      }

      await this.$resourceApi.post('/resource-requisition', { }, {
        data: requestPayload,
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }).then((response) => {
        let creationData = {}
        let dialogData = {}
        const { data: responseData, status } = response || {}

        if (status === 201) {
          creationData = responseData
          dialogData = {
            status: true,
            title: 'Success',
            message: requestData.message,
            nextRoute: `/project/${requestData.project_id}/resource-requisition`,
            sameRoute: true
          }
        }
        commit('setCreatedRequisitionData', creationData)
        commit('setCustomDialog', dialogData)
      }).catch((error) => {
        const message = 'Something went wrong!'

        commit('setCustomDialog', {
          status: true,
          title: 'Error',
          message,
          errormessage: error,
          nextRoute: '/project-dashboard'
        })
      })
    } catch (e) {
      commit('setCreatedRequisitionData', {})
    }
  },

  async setDirectResourceAllocationData ({ commit, rootState }, requestData) {
    try {
      const requestPayload = {
        'project_id': requestData.project_id,
        'allocation_data': requestData.allocation_data
      }

      await this.$resourceApi.post('/direct-resource-allocation', { }, {
        data: requestPayload,
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }).then((response) => {
        let allocationData = {}
        let dialogData = {}
        const { data: responseData, status } = response || {}

        if (status === 201) {
          allocationData = responseData
          dialogData = {
            status: true,
            title: 'Success',
            message: requestData.message,
            nextRoute: `/project/${requestData.project_id}/resource-requisition`,
            sameRoute: true
          }
        }
        commit('setDirectCreatedAllocationData', allocationData)
        commit('setCustomDialog', dialogData)
      }).catch((error) => {
        const message = 'Something went wrong!'

        commit('setCustomDialog', {
          status: true,
          title: 'Error',
          message,
          errormessage: error,
          nextRoute: '/project-dashboard'
        })
      })
    } catch (e) {
      commit('setDirectCreatedAllocationData', {})
    }
  },

  async setResourceAllocationData ({ commit, rootState }, requestData) {
    try {
      const requestPayload = {
        'project_id': requestData.project_id,
        'allocation_data': requestData.allocation_data,
        'project_status': requestData.project_status
      }

      await this.$resourceApi.post('/resource-allocation', { }, {
        data: requestPayload,
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }).then((response) => {
        let allocationData = {}
        let dialogData = {}
        const { data: responseData, status } = response || {}

        if (status === 201) {
          allocationData = responseData
          dialogData = {
            status: true,
            title: 'Success',
            message: requestData.popup_message,
            nextRoute: `/project/${requestData.project_id}/resource-allocation`,
            sameRoute: true
          }
        }
        commit('setCreatedAllocationData', allocationData)
        commit('setCustomDialog', dialogData)
      }).catch((error) => {
        const message = 'Something went wrong!'

        commit('setCustomDialog', {
          status: true,
          title: 'Error',
          message,
          errormessage: error,
          nextRoute: '/project-dashboard'
        })
      })
    } catch (e) {
      commit('setCreatedAllocationData', {})
    }
  },

  async setResourceAllocationApproval ({ commit, rootState }, requestData) {
    try {
      const requestPayload = {
        'approve_status': requestData.approve_status
      }

      await this.$resourceApi.put(`/resource-allocation-approve/${requestData.uuid}`, { }, {
        data: requestPayload,
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }).then((response) => {
        let allocationApprovalData
        const { data, status } = response || {}

        if (status === 200) {
          allocationApprovalData = { ...data, uuid: requestData.uuid, status: requestData.approve_status }
        }

        commit('setCreatedAllocationApproval', allocationApprovalData)

        return data
      }).catch((error) => {
        const message = 'Something went wrong!'

        commit('setCustomDialog', {
          status: true,
          title: 'Error',
          message,
          errormessage: error,
          nextRoute: '/project-dashboard'
        })
      })
    } catch (e) {
      commit('setCreatedAllocationApproval', {})
    }
  },
  async setResourceDeAllocationData ({ commit, rootState }, requestData) {
    try {
      const requestPayload = {
        'project_id': requestData.project_id,
        'de_allocation_data': requestData.de_allocation_data
      }

      await this.$resourceApi.post('/resource-deallocation', { }, {
        data: requestPayload,
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }).then((response) => {
        let deallocationData = {}
        let dialogData = {}
        const { data: responseData, status } = response || {}

        if (status === 201) {
          deallocationData = responseData
          dialogData = {
            status: true,
            title: 'Success',
            message: 'The resource deallocation request has been successfully submitted. An email about resource deallocation has been sent to Resource Manager, Business Unit Heads, Account Manager & Project Manager.',
            nextRoute: `/project/${requestData.project_id}/resource-requisition`,
            sameRoute: true
          }
        }
        commit('setCreatedDeAllocationData', deallocationData)
        commit('setCustomDialog', dialogData)
      }).catch((error) => {
        const message = 'Something went wrong!'

        commit('setCustomDialog', {
          status: true,
          title: 'Error',
          message,
          errormessage: error,
          nextRoute: '/project-dashboard'
        })
      })
    } catch (e) {
      commit('setCreatedDeAllocationData', {})
    }
  },
  async setResourceExtensionData ({ commit, rootState }, requestData) {
    try {
      const requestPayload = {
        'project_id': requestData.project_id,
        'resource_data': requestData.extension_data
      }

      await this.$resourceApi.post('/extension-request', { }, {
        data: requestPayload,
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }).then((response) => {
        let extensionData = {}
        let dialogData = {}
        const { data: responseData, status } = response || {}

        if (status === 201) {
          extensionData = responseData
          dialogData = {
            status: true,
            title: 'Success',
            message: 'The resource extension request has been successfully submitted. An email about the resource booking extension has been sent to Business Unit Heads, Account Manager & Project Manager.',
            nextRoute: `/project/${requestData.project_id}/resource-requisition`,
            sameRoute: true
          }
        }
        commit('setCreatedExtensionData', extensionData)
        commit('setCustomDialog', dialogData)
      }).catch((error) => {
        const message = 'Something went wrong!'

        commit('setCustomDialog', {
          status: true,
          title: 'Error',
          message,
          errormessage: error,
          nextRoute: '/project-dashboard'
        })
      })
    } catch (e) {
      commit('setCreatedExtensionData', {})
    }
  },
  async setManageReportingData ({ commit, rootState }, requestData) {
    try {
      const requestPayload = {
        'project_id': requestData.project_id,
        'resource_data': requestData.resource_data
      }

      await this.$resourceApi.post('/manager-request', { }, {
        data: requestPayload,
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }).then((response) => {
        let requestedReportingData = {}
        let dialogData = {}
        const { data: responseData, status } = response || {}

        if (status === 201) {
          requestedReportingData = responseData
          dialogData = {
            status: true,
            title: 'Success',
            message: 'The reporting manager change request has been successfully submitted. An email about reporting manager change request has been sent to Business Unit Head(s), Account Manager, Project Manager.',
            nextRoute: `/project/${requestData.project_id}/resource-requisition`,
            sameRoute: true
          }
        }
        commit('setRequestedReportingManagerData', requestedReportingData)
        commit('setCustomDialog', dialogData)
      }).catch((error) => {
        const message = 'Something went wrong!'

        commit('setCustomDialog', {
          status: true,
          title: 'Error',
          message,
          errormessage: error,
          nextRoute: '/project-dashboard'
        })
      })
    } catch (e) {
      commit('setRequestedReportingManagerData', {})
    }
  },

  async fetchDeAllocatedMapping ({ commit, rootState }, projectId) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 100000
      }
      const { data } = await this.$resourceApi.get(`/de-allocation-map/${projectId}`, config)
      const { data: responseData } = data || {}
      const { de_allocation_mapping: deAllocationMapping } = responseData

      commit('setProjectAllocatedResources', deAllocationMapping)
    } catch (e) {
      commit('setProjectAllocatedResources', [])
    }
  },

  async setDeAllocatedMapping ({ commit, rootState }, requestData) {
    try {
      const requestPayload = {
        'de_allocation_map_data': requestData.de_allocation_map_data,
        'project_id': requestData.project_id
      }

      await this.$resourceApi.put('/de-allocation-map', { }, {
        data: requestPayload,
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 100000
      }).then((response) => {
        let mappingData = {}
        let dialogData = {
          status: true,
          title: 'Error',
          message: 'Something went wrong!',
          nextRoute: '/project-dashboard'
        }
        const { data: responseData, status } = response || {}

        if (status === 200) {
          mappingData = responseData
          dialogData = {
            status: true,
            title: 'Success',
            message: 'The project unmapping request has been successfully marked done. An email about project unmapping has been sent to Business Unit Heads, Account Manager & Project Manager.',
            nextRoute: '/project-dashboard',
            sameRoute: false
          }
        } else if (status === 422) {
          dialogData = {
            status: true,
            title: 'Error',
            message: 'Validation Error.',
            nextRoute: '/project-dashboard'
          }
        }
        commit('setDeAllocationMappingData', mappingData)
        commit('setCustomDialog', dialogData)
      }).catch((error) => {
        let message = 'Something went wrong!'
        const { response } = error || {}
        const { status } = response || 0

        if (status === 422) {
          message = 'Validation Error.'
        } else if (status === 401) {
          message = 'Unauthorized.'
        }
        const dialogData = {
          status: true,
          title: 'Error',
          message,
          errormessage: error,
          nextRoute: '/project-dashboard'
        }

        commit('setCustomDialog', dialogData)
      })
    } catch (e) {
      commit('setDeAllocationMappingData', {})
    }
  },
  async setResourceMapping ({ commit, rootState }, requestData) {
    try {
      const requestPayload = {
        'project_id': requestData.project_id,
        'map_data': requestData.map_data,
        'project_status': requestData.project_status
      }

      await this.$resourceApi.put('/map-resource', { }, {
        data: requestPayload,
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }).then((response) => {
        let mappingData = {}
        let dialogData = {}
        const { data: responseData, status } = response || {}

        if (status === 201) {
          mappingData = responseData
          dialogData = {
            status: true,
            title: 'Success',
            message: 'The project mapping request has been successfully marked done. An email about resource mapping has been sent to Business Unit Heads, Account Manager & Project Manager.',
            nextRoute: '/project-dashboard',
            sameRoute: false
          }
        }
        commit('setResourceMappingData', mappingData)
        commit('setCustomDialog', dialogData)
      }).catch((error) => {
        const message = 'Something went wrong!'

        commit('setCustomDialog', {
          status: true,
          title: 'Error',
          message,
          errormessage: error,
          nextRoute: '/project-dashboard'
        })
      })
    } catch (e) {
      commit('setResourceMappingData', {})
    }
  },

  async fetchProjectResourceRequisition ({ commit, rootState }, id) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data } = await this.$resourceApi.get(`/resource-requisition/${id}`, config)

      commit('setProjectRequisition', data.data)
    } catch (e) {
      commit('setProjectRequisition', {})
    }
  },
  async fetchProjectResourceRequisitionByDepartment ({ commit, rootState }, id) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data } = await this.$resourceApi.get(`/resource-requiestion-by-dept/${id}`, config)

      commit('setProjectRequisitionByDepartment', data.data)
    } catch (e) {
      commit('setProjectRequisitionByDepartment', {})
    }
  },
  async fetchProjectAllocationResources ({ commit, rootState }, id) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data } = await this.$resourceApi.get(`/resource-allocation/${id}/all`, config)

      commit('setProjectAllocatedResources', data.data)
    } catch (e) {
      commit('setProjectAllocatedResources', {})
    }
  },
  async fetchProjectClosureChecklist ({ commit, rootState }, id) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data, status } = await this.$resourceApi.get(`/project-closure/${id}`, config)

      if (status === 200 && Object.keys(data.data).length !== 0) {
        commit('setProjectClosureList', data.data)
      }
    } catch (e) {
      const checkboxIds = {
        projectManagement: [],
        postBilling: [],
        clientReceiving: []
      }

      JSON.stringify(checkboxIds)
      commit('setProjectClosureList', {
        uuid: false,
        project_checklist: checkboxIds
      })
    }
  },
  async setProjectCloseOnRedmine ({ commit, rootState }, id) {
    await this.$resourceApi.put(`/project-close-redmine/${id}`, {}, {
      headers: { 'Authorization': rootState.auth.tokenId },
      timeout: 20000
    }).then((response) => {
      let dialogData = {}
      const { status } = response || {}

      if (status === 200) {
        dialogData = {
          status: true,
          title: 'Success',
          message: 'Project closed on redmine successfully!',
          nextRoute: '/project-dashboard'
        }
      }
      commit('setCustomDialog', dialogData)
    }).catch((error) => {
      const message = 'Something went wrong!'

      commit('setCustomDialog', {
        status: true,
        title: 'Error',
        message,
        errormessage: error,
        nextRoute: '/project-dashboard'
      })
    })
  },
  async addProjectClosureChecklist ({ commit, rootState }, requestData) {
    try {
      const requestPayload = {
        'projectId': requestData.project_id,
        'checkboxIds': requestData.checkboxIds
      }

      await this.$resourceApi.post('/project-closure', { }, {
        data: requestPayload,
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }).then((response) => {
        let creationData = {}
        const { data: responseData, status } = response || {}

        if (status === 201) {
          creationData = responseData.data
        }
        commit('setProjectClosureList', creationData)
      }).catch((error) => {
        throw error
      })
    } catch (e) {
      const checkboxIds = {
        projectManagement: [],
        postBilling: [],
        clientReceiving: []
      }

      JSON.stringify(checkboxIds)
      commit('setProjectClosureList', {
        uuid: false,
        project_checklist: checkboxIds
      })
    }
  },

  async updateProjectClosureChecklist ({ commit, rootState }, requestData) {
    try {
      const requestPayload = {
        'checkboxIds': requestData.checkboxIds
      }

      await this.$resourceApi.put(`/project-closure/${requestData.project_id}`, { }, {
        data: requestPayload,
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }).then((response) => {
        let closureData = {}
        const { data, status } = response || {}
        const { data: responseData } = data

        if (status === 200) {
          closureData = responseData
          commit('setProjectClosureList', closureData)
        }
      }).catch((error) => {
        throw error
      })
    } catch (e) {
      const checkboxIds = {
        projectManagement: [],
        postBilling: [],
        clientReceiving: []
      }

      JSON.stringify(checkboxIds)
      commit('setProjectClosureList', {
        uuid: false,
        project_checklist: checkboxIds
      })
    }
  },
  async addProjectOnHoldRequest ({ commit, rootState }, requestData) {
    const requestPayload = {
      'status_id': requestData.status_id,
      'to': requestData.to,
      'from': requestData.from,
      'reason': requestData.reason
    }

    await this.$resourceApi.put(`/on-hold/${requestData.project_id}`, { }, {
      data: requestPayload,
      headers: { 'Authorization': rootState.auth.tokenId },
      timeout: 20000
    }).then((response) => {
      let dialogData = {}
      const { status } = response || {}

      if (status === 200) {
        dialogData = {
          status: true,
          title: 'Success',
          message: 'The project on hold request has been successfully submitted. An email for project on hold confirmation has been sent to Global Operations, Sales, Account Manager & Project Manager.',
          nextRoute: '/project-dashboard',
          sameRoute: false
        }
      }
      commit('setCustomDialog', dialogData)
    }).catch((error) => {
      const message = 'Something went wrong!'

      commit('setCustomDialog', {
        status: true,
        title: 'Error',
        message,
        errormessage: error,
        nextRoute: '/project-dashboard'
      })
    })
  },
  async projectRestart ({ commit, rootState }, requestData) {
    const requestPayload = {
      'message': requestData.message
    }

    await this.$resourceApi.put(`/project-restart/${requestData.project_id}`, { }, {
      data: requestPayload,
      headers: { 'Authorization': rootState.auth.tokenId },
      timeout: 20000
    }).then((response) => {
      let dialogData = {
        status: true,
        title: 'Error',
        message: 'Something went wrong!',
        nextRoute: '/project-dashboard'
      }
      const { status, data } = response || {}

      if (status === 200) {
        dialogData = {
          status: true,
          title: 'Success',
          message: 'Project Restarted successfully',
          nextRoute: '/project-dashboard'
        }
        commit('setRestartProject', data.data)
      } else if (status === 422) {
        dialogData = {
          status: true,
          title: 'Error',
          message: 'Validation Error.',
          nextRoute: '/project-dashboard'
        }
      }
      commit('setCustomDialog', dialogData)
    }).catch((error) => {
      let message = 'Something went wrong!'
      const { response } = error || {}
      const { status } = response || 0

      if (status === 422) {
        message = 'Validation Error.'
      } else if (status === 401) {
        message = 'Unauthorized.'
      }
      const dialogData = {
        status: true,
        title: 'Error',
        message,
        errormessage: error,
        nextRoute: '/project-dashboard'
      }

      commit('setCustomDialog', dialogData)
    })
  },
  async fetchProjectHoldRequest ({ commit, rootState }, id) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data, status } = await this.$resourceApi.get(`/on-hold/${id}`, config)

      if (status === 200 && data.data !== null) {
        commit('setProjectHoldRequest', data.data)
      }
    } catch (e) {
      commit('setProjectHoldRequest', {})
    }
  },
  async updateProjectHoldApproval ({ commit, rootState }, requestData) {
    const requestPayload = {
      'status_id': requestData.status_id,
      'to': requestData.to,
      'from': requestData.from,
      'reason': requestData.reason,
      'requested_by': requestData.requested_by
    }

    await this.$resourceApi.put(`/on-hold-action/${requestData.project_id}`, { }, {
      data: requestPayload,
      headers: { 'Authorization': rootState.auth.tokenId },
      timeout: 20000
    }).then((response) => {
      let dialogData = {}
      const { status } = response || {}

      if (status === 200) {
        if (requestData.send_type === 'approve') {
          dialogData = {
            status: true,
            title: 'Success',
            message: 'The response to the project on hold request has been successfully submitted. An email about the acceptance of a project on hold request has been sent to Account Manager & Project Manager.',
            nextRoute: '/project-dashboard'
          }
        } else {
          dialogData = {
            status: true,
            title: 'Success',
            message: 'The response to the project on hold request has been successfully submitted. An email about the rejection of a project on hold request has been sent to Account Manager & Project Manager.',
            nextRoute: '/project-dashboard'
          }
        }
      }
      commit('setCustomDialog', dialogData)
    }).catch((error) => {
      const message = 'Something went wrong!'

      commit('setCustomDialog', {
        status: true,
        title: 'Error',
        message,
        errormessage: error,
        nextRoute: '/project-dashboard'
      })
    })
  },
  async closeProjectAction ({ commit, rootState }, requestData) {
    const requestPayload = {
      'checkboxIds': requestData.checkboxIds,
      'status_id': requestData.status_id
    }

    await this.$resourceApi.put(`/project-close/${requestData.project_id}`, { }, {
      data: requestPayload,
      headers: { 'Authorization': rootState.auth.tokenId },
      timeout: 20000
    }).then((response) => {
      let dialogData = {}
      const { status } = response || {}

      if (status === 200) {
        dialogData = {
          status: true,
          title: 'Success',
          message: 'The project close request has been successfully submitted. An email about the closure of the project has been sent to Account Manager, Project Manager, Global Operations, Sales & Resource Manager.',
          nextRoute: '/project-dashboard',
          sameRoute: false
        }
      }
      commit('setCustomDialog', dialogData)
    }).catch((error) => {
      const message = 'Something went wrong!'

      commit('setCustomDialog', {
        status: true,
        title: 'Error',
        message,
        errormessage: error,
        nextRoute: '/project-dashboard'
      })
    })
  },

  async declinedResourceAllocationData ({ commit, rootState }, id) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data, status } = await this.$resourceApi.get(`/resource-allocation-dept/${id}/resource_allocation_response_decline`, config)

      if (status === 200 && data.data !== null) {
        commit('setDeclinedResourceAllocationData', data.data)
      }
    } catch (e) {
      commit('setDeclinedResourceAllocationData', {})
    }
  },

  async reallocateResourceAction ({ commit, rootState }, requestData) {
    const requestPayload = {
      'project_id': requestData.project_id,
      'allocation_data': requestData.allocation_data,
      'project_status': requestData.project_status,
      'deleted_allocations': requestData.deleted_allocations
    }

    await this.$resourceApi.put('/resource-re-allocation', { }, {
      data: requestPayload,
      headers: { 'Authorization': rootState.auth.tokenId },
      timeout: 20000
    }).then((response) => {
      let dialogData = {}
      const { status } = response || {}

      if (status === 200) {
        dialogData = {
          status: true,
          title: 'Success',
          message: 'You have successfully updated the reallocation data.',
          nextRoute: `/project/${requestData.project_id}/resource-reallocation`,
          sameRoute: true
        }
      }
      commit('setCustomDialog', dialogData)
    }).catch((error) => {
      const message = 'Something went wrong!'

      commit('setCustomDialog', {
        status: true,
        title: 'Error',
        message,
        errormessage: error,
        nextRoute: '/project-dashboard'
      })
    })
  },
  async fetchAllocationLogsData ({ commit, rootState }, id) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data, status } = await this.$resourceApi.get(`/resource-reallocation-log/${id}`, config)

      if (status === 200 && data.data !== null) {
        commit('setAllocationLogs', data.data)
      }
    } catch (e) {
      commit('setAllocationLogs', {})
    }
  },
  async fetchDeallocationLogsData ({ commit, rootState }, id) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data, status } = await this.$resourceApi.get(`/resource-deallocation-log/${id}`, config)

      if (status === 200 && data.data !== null) {
        commit('setDeallocationLogs', data.data)
      }
    } catch (e) {
      commit('setDeallocationLogs', {})
    }
  },
  async fetchProjectDomains ({ commit, rootState }, id) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data, status } = await this.$resourceApi.get('/project-domain', config)

      if (status === 200 && data.data !== null) {
        commit('setProjectDomainList', data.data)
      }
    } catch (e) {
      commit('setProjectDomainList', [])
    }
  },
  async fetchProjectClients ({ commit, rootState }, id) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data, status } = await this.$resourceApi.get('/client', config)

      if (status === 200 && data.data !== null) {
        commit('setProjectClientList', data.data)
      }
    } catch (e) {
      commit('setProjectClientList', [])
    }
  },
  async fetchProjectNameListing ({ commit, rootState }, id) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data, status } = await this.$resourceApi.get('/project-listings', config)

      if (status === 200) {
        commit('setProjectNameListing', data.data)
      }
    } catch (e) {
      commit('setProjectNameListing', [])
    }
  },
  async fetchRedmineProjectNameListing ({ commit, rootState }, id) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data, status } = await this.$resourceApi.get('/project-redmine-listings', config)

      if (status === 200) {
        commit('setRedminProjectNameListing', data.data)
      }
    } catch (e) {
      commit('setRedminProjectNameListing', [])
    }
  },
  async createProjectDomain ({ commit, rootState }, requestData) {
    const requestPayload = {
      'name': requestData.domainName
    }

    await this.$resourceApi.post('/project-domain', { }, {
      data: requestPayload,
      headers: { 'Authorization': rootState.auth.tokenId },
      timeout: 20000
    }).then((response) => {
      let dialogData = {}
      const { status, data } = response || {}

      if (status === 201) {
        dialogData = {
          status: false,
          title: 'Success',
          message: 'You have successfully created a new domain.',
          nextRoute: '/project-dashboard'
        }
        commit('setCreatedDomain', data.data)
      } else {
        dialogData = {
          status: false,
          title: 'Error',
          message: 'Domain name is duplicate please try a different name!',
          errormessage: 'Invalid Status code returned.',
          nextRoute: '/project-dashboard'
        }
      }
      commit('setCustomDialog', dialogData)
    }).catch((error) => {
      const message = 'Something went wrong!'

      commit('setCustomDialog', {
        status: false,
        title: 'Error',
        message,
        errormessage: error,
        nextRoute: '/project-dashboard'
      })
    })
  },
  async createProjectClient ({ commit, rootState }, requestData) {
    const requestPayload = {
      'name': requestData.name,
      'email': requestData.email
    }

    await this.$resourceApi.post('/client', { }, {
      data: requestPayload,
      headers: { 'Authorization': rootState.auth.tokenId },
      timeout: 20000
    }).then((response) => {
      let dialogData = {}
      const { status, data } = response || {}

      if (status === 201) {
        dialogData = {
          status: false,
          title: 'Success',
          message: 'You have successfully created a new Client.'
        }
        commit('setCreatedClient', data.data)

      } else {
        dialogData = {
          status: false,
          title: 'Error',
          message: 'Client name or email is duplicate please try a different name!',
          errormessage: 'Invalid Status code returned.'
        }
      }
      commit('setCustomDialog', dialogData)
    }).catch((error) => {
      const message = 'Something went wrong!'

      commit('setCustomDialog', {
        status: false,
        title: 'Error',
        message,
        errormessage: error
      })
    })
  },
  updateLoadingAction ({ commit }) {
    commit('setLoading')
  },
  updateProjectRequisition ({ commit }, data) {
    commit('setProjectRequisitionsArray', data)
  },
  async editRequisitionAction ({ commit, rootState }, requestData) {
    const requestPayload = {
      'project_id': requestData.project_id,
      'resource_data': requestData.resource_data
    }

    await this.$resourceApi.put('/edit-requisition', { }, {
      data: requestPayload,
      headers: { 'Authorization': rootState.auth.tokenId },
      timeout: 20000
    }).then((response) => {
      let dialogData = {}
      const { status } = response || {}

      if (status === 200) {
        dialogData = {
          status: true,
          title: 'Success',
          message: 'The resource requisition request has been updated successfully. An email has been sent to AM, PM and RM about the changes.',
          nextRoute: `/project/${requestData.project_id}/resource-requisition`,
          sameRoute: true
        }
      }
      commit('setCustomDialog', dialogData)
    }).catch((error) => {
      const message = 'Something went wrong!'

      commit('setCustomDialog', {
        status: true,
        title: 'Error',
        message,
        errormessage: error,
        nextRoute: '/project-dashboard'
      })
    })
  },
  async fetchAllocationsForEdit ({ commit, rootState }, id) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data, status } = await this.$resourceApi.get(`/edit-allocation-list/${id}`, config)

      if (status === 200 && data.data !== null) {
        commit('setAllocatedResourceData', data.data)
      }
    } catch (e) {
      commit('setAllocatedResourceData', [])
    }
  },
  async editAllocationAction ({ commit, rootState }, requestData) {
    const requestPayload = {
      'project_id': requestData.project_id,
      'allocation_data': requestData.allocation_data
    }

    await this.$resourceApi.put('/edit-allocation', { }, {
      data: requestPayload,
      headers: { 'Authorization': rootState.auth.tokenId },
      timeout: 20000
    }).then((response) => {
      let dialogData = {}
      const { status } = response || {}

      if (status === 200) {
        dialogData = {
          status: true,
          title: 'Success',
          message: requestData.popup_message,
          nextRoute: `/project/${requestData.project_id}/edit-allocation`,
          sameRoute: true
        }
      }
      commit('setCustomDialog', dialogData)
    }).catch((error) => {
      const message = 'Something went wrong!'

      commit('setCustomDialog', {
        status: true,
        title: 'Error',
        message,
        errormessage: error,
        nextRoute: '/project-dashboard'
      })
    })
  },
  /**
   * RCA APIs create , get all details and view RCA information
   */
  async setCreatedRcaData ({ commit, rootState }, requestData) {
    try {
      const requestPayload = {
        'issue_detail': requestData.issue_detail,
        'date_of_issue_reported_first': requestData.date_of_issue_reported_first,
        'date_of_action_reported_first': requestData.date_of_action_reported_first,
        'issue_reported_by': requestData.issue_reported_by,
        'resolve_issue_type': requestData.resolve_issue_type,
        'time_taken_to_fix': requestData.time_taken_to_fix,
        'issue_priority': requestData.issue_priority,
        'prevent_for_future': requestData.prevent_for_future,
        'fixed_by': requestData.fixed_by,
        'attachments': requestData.attachments
      }

      await this.$resourceApi.post(`/rca/${requestData.project_id}`, { }, {
        data: requestPayload,
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }).then((response) => {
        let projectData = {}
        let dialogData = {}
        const { data: responseData, status } = response || {}

        if (status === 201) {
          projectData = responseData
          dialogData = {
            status: true,
            title: 'Success',
            message: 'The RCA form has been successfully submitted.',
            nextRoute: `/rca/${requestData.project_id}`,
            sameRoute: true
          }
        }
        commit('setCreatedRca', projectData)
        commit('setCustomDialog', dialogData)
      }).catch((error) => {
        const message = 'Something went wrong!'

        commit('setCustomDialog', {
          status: true,
          title: 'Error',
          message,
          errormessage: error,
          nextRoute: `/rca/${requestData.project_id}`
        })
      })
    } catch (e) {
      commit('setCreatedRca', {})
    }
  },
  async fetchRcaDetail ({ commit, rootState }, Id) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data, status } = await this.$resourceApi.get(`rca-details/${Id}`, config)

      if (status === 200) {
        commit('setRcaDetail', data.data)
      }
    } catch (e) {
      commit('setRcaDetail', {})
    }
  },
  async fetchRcaList ({ commit, rootState }, id) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data, status } = await this.$resourceApi.get(`rca-listing/${id}`, config)

      if (status === 200) {
        commit('setRcaList', data.data)
      }
    } catch (e) {
      commit('setRcaList', {})
    }
  },
  async fetchDepartmentWiseRagStatus ({ commit, rootState }, id) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data, status } = await this.$resourceApi.get(`department-wise-rag-status/${id}`, config)

      if (status === 200) {
        commit('setDepartmentWiseRagStatus', data.data)
      }
    } catch (e) {
      commit('setDepartmentWiseRagStatus', {})
    }
  },
  async fetchKekaResourceDetailByDepartment ({ commit, rootState }, id) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data, status } = await this.$resourceApi.get(`pyramid-employee/${id}`, config)

      if (status === 200) {
        commit('setKekaResourceDetail', data.data)
      }
    } catch (e) {
      commit('setKekaResourceDetail', {})
    }
  },
  async fetchAllPyramidSetting ({ commit, rootState }, id) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data, status } = await this.$resourceApi.get('pyramid', config)

      if (status === 200) {
        commit('setPyramidSetting', data.data)
      }
    } catch (e) {
      commit('setPyramidSetting', {})
    }
  },
  async setResourcePyramidSettingsByDepartment ({ commit, rootState }, requestData) {
    try {
      const requestPayload = {
        'experience_data': requestData.experience_data,
        'dept_id': requestData.dept_id,
        'employee_count': requestData.employee_count
      }

      await this.$resourceApi.post('/pyramid', { }, {
        data: requestPayload,
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }).then((response) => {
        let projectData = {}
        let dialogData = {}
        const { data: responseData, status } = response || {}

        if (status === 201) {
          projectData = responseData
          dialogData = {
            status: true,
            title: 'Success',
            message: 'The Resource Pyramid Settings has been successfully submitted.',
            nextRoute: '/resource-pyramid'
          }
        }
        commit('setResourcePyramidSettings', projectData)
        commit('setCustomDialog', dialogData)
      }).catch((error) => {
        const message = 'Something went wrong!'

        commit('setCustomDialog', {
          status: true,
          title: 'Error',
          message,
          errormessage: error,
          nextRoute: '/resource-pyramid'
        })
      })
    } catch (e) {
      commit('setResourcePyramidSettings', {})
    }
  },
  async updateResourcePyramidSettingsByDepartment ({ commit, rootState }, { id, requestData }) {
    try {
      const requestPayload = {
        'experience_data': requestData.experience_data,
        'dept_id': requestData.dept_id,
        'employee_count': requestData.employee_count
      }

      await this.$resourceApi.put(`/pyramid/${id}`, { }, {
        data: requestPayload,
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }).then((response) => {
        let projectData = {}
        let dialogData = {}
        const { data: responseData, status } = response || {}

        if (status === 200) {
          projectData = responseData
          dialogData = {
            status: true,
            title: 'Success',
            message: 'The Resource Pyramid Settings has been successfully submitted.',
            nextRoute: '/resource-pyramid'
          }
        }
        commit('setResourcePyramidSettings', projectData)
        commit('setCustomDialog', dialogData)
      }).catch((error) => {
        const message = 'Something went wrong!'

        commit('setCustomDialog', {
          status: true,
          title: 'Error',
          message,
          errormessage: error,
          nextRoute: '/resource-pyramid'
        })
      })
    } catch (e) {
      commit('setResourcePyramidSettings', {})
    }
  },
  async fetchRcaReporterUsers ({ commit, rootState }) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data } = await this.$resourceApi.get('/rca-reporter-users', config)

      commit('setRcaReporterUsers', data.data)
    } catch (e) {
      commit('setRcaReporterUsers', [])
    }
  },
  /**
   * KEDB APIs create , get all details and view kedb information
   */
  async setCreatedKedbData ({ commit, rootState }, requestData) {
    try {
      const requestPayload = {
        'project_id': requestData.project_id,
        'project_rca_id': requestData.project_rca_id,
        'tags': requestData.tags,
        'description_of_known_error': requestData.description_of_known_error,
        'description_of_workaround': requestData.description_of_workaround,
        'attachments': requestData.attachments
      }

      await this.$resourceApi.post('/kedb', { }, {
        data: requestPayload,
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }).then((response) => {
        let projectData = {}
        let dialogData = {}
        const { data: responseData, status } = response || {}

        if (status === 201) {
          projectData = responseData
          dialogData = {
            status: true,
            title: 'Success',
            message: 'The KEDB form has been successfully submitted.',
            nextRoute: '/kedb',
            sameRoute: true
          }
        }
        commit('setCreatedKedb', projectData)
        commit('setCustomDialog', dialogData)
      }).catch((error) => {
        const message = 'Something went wrong!'

        commit('setCustomDialog', {
          status: true,
          title: 'Error',
          message,
          errormessage: error,
          nextRoute: '/kedb'
        })
      })
    } catch (e) {
      commit('setCreatedKedb', {})
    }
  },
  async fetchKedbList ({ commit, rootState }) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId }
      }
      const { data, status } = await this.$resourceApi.get('/kedb', config)

      if (status === 200) {
        commit('setKedbList', data.data)
      }
    } catch (e) {
      commit('setKedbList', [])
    }
  },
  async fetchKedbDetail ({ commit, rootState }, kedbId) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data, status } = await this.$resourceApi.get(`kedb/${kedbId}`, config)

      if (status === 200) {
        commit('setKedbDetail', data.data)
      }
    } catch (e) {
      commit('setKedbDetail', {})
    }
  },
  async fetchKedbTags ({ commit, rootState }, id) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data, status } = await this.$resourceApi.get('/tag', config)

      if (status === 200 && data.data !== null) {
        commit('setKedbTagList', data.data)
      }
    } catch (e) {
      commit('setKedbTagList', [])
    }
  },
  async createKedbTag ({ commit, rootState }, requestData) {
    const requestPayload = {
      'name': requestData.tagName
    }

    await this.$resourceApi.post('/tag', { }, {
      data: requestPayload,
      headers: { 'Authorization': rootState.auth.tokenId },
      timeout: 20000
    }).then((response) => {
      let dialogData = {}
      const { status, data } = response || {}

      if (status === 201) {
        dialogData = {
          status: false,
          title: 'Success',
          message: 'You have successfully created a new tag.',
          nextRoute: '/project-dashboard'
        }
        commit('setCreatedTag', data.data)
      } else {
        dialogData = {
          status: false,
          title: 'Error',
          message: 'Tag name is duplicate please try a different name!',
          errormessage: 'Invalid Status code returned.',
          nextRoute: '/kedb'
        }
      }
      commit('setCustomDialog', dialogData)
    }).catch((error) => {
      const message = 'Something went wrong!'

      commit('setCustomDialog', {
        status: false,
        title: 'Error',
        message,
        errormessage: error,
        nextRoute: '/kedb'
      })
    })
  },
  async fetchKedbProjectList ({ commit, rootState }) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId }
      }
      const { data, status } = await this.$resourceApi.get('/all-assigned-project', config)

      if (status === 200) {
        commit('setKedbProjectList', data.data)
      }
    } catch (e) {
      commit('setKedbProjectList', [])
    }
  },
  async fetchKedbRcaList ({ commit, rootState }, id) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data, status } = await this.$resourceApi.get(`rca-listing-for-kedb/${id}`, config)

      if (status === 200) {
        commit('setKedbRcaList', data.data)
      }
    } catch (e) {
      commit('setKedbRcaList', {})
    }
  },
  /**
   * Attachment APIs upload , download and delete attachemnt
   */
  async uploadAttachmentData ({ commit, rootState }, attachments) {
    try {
      document.getElementById('upload-file').value = []
      await this.$resourceApi.post('/attachment', attachments, {
        headers: { 'Authorization': rootState.auth.tokenId,
          'Content-Type': 'multipart/form-data' },
        timeout: 20000
      }).then((response) => {
        let uploadedData
        const { data, status } = response || {}

        if (status === 201) {
          uploadedData = { ...data }
          commit('setCreatedAttachment', uploadedData)

          return data
        }
      }).catch((error) => {
        const message = 'Something went wrong!'

        commit('setCustomDialog', {
          status: true,
          title: 'Error',
          message,
          errormessage: error,
          nextRoute: '/project-dashboard'
        })
      })
    } catch (e) {
      commit('setCreatedAttachment', {})
    }
  },
  async downloadAttachment ({ commit, rootState }, requestData) {
    try {
      await this.$resourceApi.get(`attachment/${requestData.id}`, { responseType: 'arraybuffer' }, {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }).then((response) => {
        const url = window.URL.createObjectURL(new Blob([response.data]))
        const link = document.createElement('a')

        link.href = url
        link.setAttribute('download', `${requestData.name}`)
        document.body.appendChild(link)
        link.click()
      }).catch((error) => {
        const message = 'Something went wrong!'

        commit('setCustomDialog', {
          status: true,
          title: 'Error',
          message,
          errormessage: error,
          nextRoute: '/kedb'
        })
      })
    } catch (e) {
      commit('setCreatedAttachment', {})
    }
  },
  async deleteAttachment ({ rootState }, requestData) {
    const config = {
      headers: { 'Authorization': rootState.auth.tokenId },
      timeout: 20000
    }

    await this.$resourceApi.delete(`attachment/${requestData.id}`, config)
  },
  // BU Head Teams APIs
  async fetchManagerRequests ({ commit, rootState }) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 100000
      }
      const { data } = await this.$resourceApi.get('/manager-requests', config)
      const { data: responseData } = data || {}

      commit('setManagerRequests', responseData)
    } catch (e) {
      commit('setManagerRequests', [])
    }
  },
  async fetchDeptWiseReporting ({ commit, rootState }) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 100000
      }
      const { data } = await this.$resourceApi.get('/department-wise-reporting', config)
      const { data: responseData } = data || {}

      commit('setDeptWiseReporting', responseData)
    } catch (e) {
      commit('setDeptWiseReporting', [])
    }
  },
  async fetchDirectReportingListToRM ({ commit, rootState }) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }
      const { data, status } = await this.$resourceApi.get('/direct-reporting', config)

      if (status === 200) {
        commit('setDirectReportingListToRM', data.data)
      }
    } catch (e) {
      commit('setDirectReportingListToRM', {})
    }
  },
  async setManagerApprovalOrRejection ({ commit, rootState }, finalData) {
    try {
      const requestPayload = {
        'resource_data': finalData.resource_data,
        'is_approved': finalData.is_approved
      }

      await this.$resourceApi.put('/manager-approval', { }, {
        data: requestPayload,
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 100000
      }).then((response) => {
        let projectData = {}
        let dialogData = {}
        const { data: responseData, status } = response || {}

        if (status === 200) {
          projectData = responseData
          if (finalData.is_approved === true) {
            dialogData = {
              status: true,
              title: 'Success',
              message: 'The selected reporting manager change requests have successfully approved. An email about reporting manager changes has been sent to Human Resource(s), Account Manager, Project Manager, Bu Head(s), Last Reporting Manager.',
              nextRoute: '/teams/team-list'
            }
          } else {
            dialogData = {
              status: true,
              title: 'Success',
              message: 'The selected reporting manager change requests have successfully rejected. An email about reporting manager changes has been sent to Account Manager, Project Manager, Bu Head(s).',
              nextRoute: '/teams/team-list'
            }
          }
        }
        commit('setManagerApproval', projectData)
        commit('setCustomDialog', dialogData)
      }).catch((error) => {
        const message = 'Something went wrong!'

        commit('setCustomDialog', {
          status: true,
          title: 'Error',
          message,
          errormessage: error,
          nextRoute: '/project-dashboard'
        })
      })
    } catch (e) {
      commit('setManagerApproval', {})
    }
  },
  async setChangeDirectReportingManager ({ commit, rootState }, changeRmDirectly) {
    try {
      const requestPayload = {
        'resource_data': changeRmDirectly
      }

      await this.$resourceApi.post('/direct-change-reporting', { }, {
        data: requestPayload,
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 20000
      }).then((response) => {
        let projectData = {}
        let dialogData = {}
        const { data: responseData, status } = response || {}

        if (status === 201) {
          projectData = responseData
          dialogData = {
            status: true,
            title: 'Success',
            message: 'The reporting manager has been successfully updated for the selected records. An email about reporting manager changes has been sent to Human Resource(s), Account Manager(s), Project Manager(s), Bu Head(s).',
            nextRoute: '/project-dashboard'
          }
        }
        commit('setChangeDirectRM', projectData)
        commit('setCustomDialog', dialogData)
      }).catch((error) => {
        const message = 'Something went wrong!'

        commit('setCustomDialog', {
          status: true,
          title: 'Error',
          message,
          errormessage: error,
          nextRoute: '/project-dashboard'
        })
      })
    } catch (e) {
      commit('setChangeDirectRM', {})
    }
  },
  // export all redmine/pmo report related to project dashboard or resources
  async fetchProjectReport ({ commit, rootState }) {
    try {
      const config = {
        headers: { 'Authorization': rootState.auth.tokenId },
        timeout: 900000
      }
      const { data } = await this.$resourceApi.get('/project-export', config)

      if (data.status === 200) {
        const projectReportData = data.data

        commit('setProjectReportData', projectReportData)
      }
    } catch (e) {
      throw e
    }
  },
  updateOverlayAction ({ commit }, value) {
    commit('setOverlayLoading', value)
  },
  updateProjectSearchString ({ commit }, value) {
    commit('setProjectSearchString', value)
  },

  updateProjectWsrDefaultFilter ({ commit }, value) {
    commit('setProjectWsrDefaultFilter', value)
  },
  updateProgressStageGraphFilter ({ commit }, value) {
    commit('setProgressStageGraphFilter', value)
  },
  updateProjectDashboardPagination ({ commit }, value) {
    commit('setProjectDashboardPagination', value)
  },
  storeActivityLogAccordion ({ commit }, value) {
    commit('setActivityLogAccordion', value)
  },
  resetProjectState ({ commit }) {
    commit('resetState')
  }

}
