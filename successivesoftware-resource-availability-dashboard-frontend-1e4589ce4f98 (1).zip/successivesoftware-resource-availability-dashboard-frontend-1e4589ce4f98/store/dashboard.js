function initialState() {
  return {
    locations: ['All'],
    departments: ['All'],
    categories: ['All'],
    fullyScheduledDownload: [],
    partiallyScheduledDownload: [],
    unscheduledDownload: [],
    benchReportData: [],
    overScheduledDownload: [],
    snackbarText: null,
    snackbarValue: false,
    timesheetSummary: [],
    resourceSummary: [],
    buWiseProjectRagStatus: {},
    monthsArray: [],
    invoiceSummary: {},
    timesheetReminder: {},
    invoiceReminder: {},
    utilizationOverView: [],
    benchUtilized: [],
    optimallyUtilized: [],
    overUtilized: [],
    underUtilized: [],
    topProject: {},
    projectWiseRagStatus: [],
    pmWiseRagStatus: {},
    accountRagStatus: [],
    newProjectKiffOff: {},
    riskData: [],
    projectAtRisk:[],
    newCollaboration: {},
    projectRagStatus:null,
    projectRagBillingStatus:null,
    projectRagWeek:null

  }
}
export const state = () => initialState()

export const getters = {
  locations: (state) => state.locations,
  departments: (state) => state.departments,
  getCategories: (state) => state.categories,
  fullyScheduledDownload: (state) => state.fullyScheduledDownload,
  partiallyScheduledDownload: (state) => state.partiallyScheduledDownload,
  unscheduledDownload: (state) => state.unscheduledDownload,
  benchReportData: (state) => state.benchReportData,
  overScheduledDownload: (state) => state.overScheduledDownload,
  snackbarText: (state) => state.snackbarText,
  snackbarValue: (state) => state.snackbarValue,
  getTimesheetSummary: (state) => state.timesheetSummary,
  getResourceSummary: (state) => state.resourceSummary,
  getBuWiseProjectRagStatus: (state) => state.buWiseProjectRagStatus,
  getPmWiseRagStatus: (state) => state.pmWiseRagStatus,
  getMonthsArray: (state) => state.monthsArray,
  getInvoiceSummary: (state) => state.invoiceSummary,
  utilizationOverView: (state) => state.utilizationOverView,
  benchUtilized: (state) => state.benchUtilized,
  optimallyUtilized: (state) => state.optimallyUtilized,
  overUtilized: (state) => state.overUtilized,
  underUtilized: (state) => state.underUtilized,
  getProjectWiseRagStatus: (state) => state.projectWiseRagStatus,
  getTopProject: (state) => state.topProject,
  getAccountRagStatus: (state) => state.accountRagStatus,
  getNewProjectKiffOff: (state) => state.newProjectKiffOff,
  getProjectAtRisk: (state) => state.projectAtRisk,
  getNewCollaboration: (state) => state.newCollaboration,
  getRiskData: (state) => state.riskData,
  getProjectRagStatus: (state) => state.projectRagStatus,
  getProjectRagBillingStatus: (state) => state.projectRagBillingStatus,
  getprojectRagWeek: (state) => state.projectRagWeek
}

export const mutations = {
  setUtilizationOverView(state, overViewData) {
    state.utilizationOverView = overViewData
  },
  setBenchUtilized(state, benchUtilized) {
    state.benchUtilized = benchUtilized
  },
  setOptimallyUtilized(state, optimallyUtilizedData) {
    state.optimallyUtilized = optimallyUtilizedData
  },
  setOverUtilized(state, overUtilizedData) {
    state.overUtilized = overUtilizedData
  },
  setUnderUtilized(state, underUtilizedData) {
    state.underUtilized = underUtilizedData
  },

  setLocation(state, locationData) {
    state.locations = locationData
  },
  setMonthsArray(state, monthData) {
    state.monthsArray = monthData
  },
  setDepartments(state, departmentData) {
    state.departments = departmentData
  },
  setCategories(state, categoriesData) {
    state.categories = categoriesData
  },
  setFullyScheduledDownload(state, fullyScheduledData) {
    state.fullyScheduledDownload = fullyScheduledData
  },

  setOverScheduledDownload(state, overScheduledData) {
    state.overScheduledDownload = overScheduledData
  },

  setUnscheduledDownload(state, unscheduledData) {
    state.unscheduledDownload = unscheduledData
  },
  setBenchReportDownload(state, benchData) {
    state.benchReportData = benchData
  },
  setPartiallyScheduledDownload(state, partiallyScheduledDate) {
    state.partiallyScheduledDownload = partiallyScheduledDate
  },

  setSnackbarValue(state, snackbarValue) {
    state.snackbarValue = snackbarValue
  },

  setSnackbarText(state, snackbarText) {
    state.snackbarText = snackbarText
  },

  setResourceDataState(state, { data, key }) {
    state[key] = data
  },
  setTimesheetSummary(state, resourceData) {
    state.timesheetSummary = resourceData
  },
  setTimesheetReminder(state, resourceData) {
    state.timesheetReminder = resourceData
  },
  setInvoiceReminder(state, resourceData) {
    state.invoiceReminder = resourceData
  },
  setResourceSummary(state, resourceData) {
    state.resourceSummary = resourceData
  },
  setBuWiseProjectRagStatus(state, resourceData) {
    state.buWiseProjectRagStatus = resourceData
  },
  setPmWiseRagStatus(state, resourceData) {
    state.pmWiseRagStatus = resourceData
  },
  setProjectWiseRagStatus(state, resourceData) {
    state.projectWiseRagStatus = resourceData
  },
  setInvoiceSummary(state, resourceData) {
    state.invoiceSummary = resourceData
  },
  setRiskData(state, resourceData) {
    state.riskData = resourceData
  },
  setTopProject(state, resourceData) {
    state.topProject = resourceData
  },
  setAccountRagStatus(state, resourceData) {
    state.accountRagStatus = resourceData
  },
  setNewProjectKiffOff(state, resourceData) {
    state.newProjectKiffOff = resourceData
  },
  setProjectAtRisk(state, resourceData) {
    state.projectAtRisk = resourceData
  },

  setNewCollaboration(state, resourceData) {
    state.newCollaboration = resourceData
  },
  setProjectRagStatus (state, value) {
    state.projectRagStatus = value
  },
  setProjectRagBillingStatus(state, value) {
    state.projectRagBillingStatus = value
   
  },
  setProjectRagWeek(state, value) {
    state.projectRagWeek = value
   
  },
  resetState(state) {
    // acquire initial state
    const s = initialState()

    Object.keys(s).forEach((key) => {
      state[key] = s[key]
    })
  }
}

export const actions = {
  /**
   * Project Dasboard Tiles APIs
   * @param {*} param
   */

  async fetchTimesheetSummary({ commit, rootState }) {
    try {
      await this.$resourceApi
        .get(
          '/timesheet-summary',
          {},
          {
            headers: { Authorization: rootState.auth.tokenId },
            timeout: 200000
          }
        )
        .then((response) => {
          const { data: responseData } = response || {}

          commit('setTimesheetSummary', responseData)
        })
        .catch((error) => {
          const message = 'Something went wrong!'

          commit('setCustomDialog', {
            status: true,
            title: 'Error',
            message,
            errormessage: error,
            nextRoute: '/project-dashboard'
          })
        })
    } catch (e) {
      commit('setTimesheetSummary', {})
    }
  },
  async sendTimeSheetReminder({ commit, rootState }, userIds) {
    try {
      const requestPayload = {
        user_ids: userIds
      }

      await this.$resourceApi
        .post(
          '/timesheet-reminder',
          {},
          {
            data: requestPayload,
            headers: { Authorization: rootState.auth.tokenId },
            timeout: 200000
          }
        )
        .then((response) => {
          const { data: responseData } = response || {}

          commit('setTimesheetReminder', responseData)
        })
        .catch((error) => {
          const message = 'Something went wrong!'

          commit('setCustomDialog', {
            status: true,
            title: 'Error',
            message,
            errormessage: error,
            nextRoute: '/project-dashboard'
          })
        })
    } catch (e) {
      commit('setTimesheetReminder', {})
    }
  },
  async fetchResourceSummary({ commit, rootState }) {
    try {
      await this.$resourceApi
        .get(
          '/resource-summary',
          {},
          {
            headers: { Authorization: rootState.auth.tokenId },
            timeout: 200000
          }
        )
        .then((response) => {
          const { data: responseData } = response || {}

          commit('setResourceSummary', responseData)
        })
        .catch((error) => {
          const message = 'Something went wrong!'

          commit('setCustomDialog', {
            status: true,
            title: 'Error',
            message,
            errormessage: error,
            nextRoute: '/project-dashboard'
          })
        })
    } catch (e) {
      commit('setResourceSummary', {})
    }
  },
  async fetchInvoiceSummary({ commit, rootState }) {
    try {
      await this.$resourceApi
        .get(
          '/invoice-status',
          {},
          {
            headers: { Authorization: rootState.auth.tokenId },
            timeout: 200000
          }
        )
        .then((response) => {
          const { data: responseData } = response || {}

          commit('setInvoiceSummary', responseData)
        })
        .catch((error) => {
          const message = 'Something went wrong!'

          commit('setCustomDialog', {
            status: true,
            title: 'Error',
            message,
            errormessage: error,
            nextRoute: '/org-dashboard'
          })
        })
    } catch (e) {
      commit('setInvoiceSummary', {})
    }
  },
  async fetchRiskData({ commit, rootState }, requestData) {
    try {
      const requestPayload = {
        'category_id': requestData.category_id !== '' ? requestData.category_id : ['All'],
        'project_id': requestData.project_id
      }

      await this.$resourceApi.post('/active-risk',{},
        {
          data: requestPayload,
          headers: { Authorization: rootState.auth.tokenId },
          timeout: 200000
        }
      )
        .then((response) => {
          const { data: responseData } = response || {}

          commit('setRiskData', responseData)
        })
        .catch((error) => {
          const message = 'Something went wrong!'

          commit('setCustomDialog', {
            status: true,
            title: 'Error',
            message,
            errormessage: error,
            nextRoute: '/org-dashboard'
          })
        })
    } catch (e) {
      commit('setRiskData', {})
    }
  },
  async fetchProjectWiseRagStatus({ commit, rootState }, requestData) {
    try {
      const requestPayload = {
        'week_no': requestData.week_no,
        'billing_id': requestData.billing_id
      }

      await this.$resourceApi
        .post(
          '/project-wise-rag-status',
          {},
          {
            data: requestPayload,
            headers: { Authorization: rootState.auth.tokenId },
            timeout: 200000
          }
        )
        .then((response) => {
          const { data: responseData } = response || {}

          commit('setProjectWiseRagStatus', responseData)
        })
        .catch((error) => {
          const message = 'Something went wrong!'

          commit('setCustomDialog', {
            status: true,
            title: 'Error',
            message,
            errormessage: error,
            nextRoute: '/org-dashboard'
          })
        })
    } catch (e) {
      commit('setProjectWiseRagStatus', {})
    }
  },
  async fetchAccountRagStatus({ commit, rootState }) {
    try {
      await this.$resourceApi
        .get(
          '/project-wise-rag-status',
          {},
          {
            headers: { Authorization: rootState.auth.tokenId },
            timeout: 200000
          }
        )
        .then((response) => {
          const { data: responseData } = response || {}

          commit('setAccountRagStatus', responseData)
        })
        .catch((error) => {
          const message = 'Something went wrong!'

          commit('setCustomDialog', {
            status: true,
            title: 'Error',
            message,
            errormessage: error,
            nextRoute: '/org-dashboard'
          })
        })
    } catch (e) {
      commit('setAccountRagStatus', {})
    }
  },
  async fetchTopProject({ commit, rootState }) {
    try {
      await this.$resourceApi
        .get(
          '/top-project-graph',
          {},
          {
            headers: { Authorization: rootState.auth.tokenId },
            timeout: 200000
          }
        )
        .then((response) => {
          const { data: responseData } = response || {}

          commit('setTopProject', responseData)
        })
        .catch((error) => {
          const message = 'Something went wrong!'

          commit('setCustomDialog', {
            status: true,
            title: 'Error',
            message,
            errormessage: error,
            nextRoute: '/org-dashboard'
          })
        })
    } catch (e) {
      commit('setTopProject', {})
    }
  },
  async fetchNewProjectKiffOff({ commit, rootState }) {
    try {
      await this.$resourceApi
        .get(
          '/project-kick-off',
          {},
          {
            headers: { Authorization: rootState.auth.tokenId },
            timeout: 200000
          }
        )
        .then((response) => {
          const { data: responseData } = response || {}

          commit('setNewProjectKiffOff', responseData)
        })
        .catch((error) => {
          const message = 'Something went wrong!'

          commit('setCustomDialog', {
            status: true,
            title: 'Error',
            message,
            errormessage: error,
            nextRoute: '/org-dashboard'
          })
        })
    } catch (e) {
      commit('setNewProjectKiffOff', {})
    }
  },
  async fetchNewCollaboration({ commit, rootState }) {
    try {
      await this.$resourceApi
        .get(
          '/partner-collaboration',
          {},
          {
            headers: { Authorization: rootState.auth.tokenId },
            timeout: 200000
          }
        )
        .then((response) => {
          const { data: responseData } = response || {}

          commit('setNewCollaboration', responseData)
        })
        .catch((error) => {
          const message = 'Something went wrong!'

          commit('setCustomDialog', {
            status: true,
            title: 'Error',
            message,
            errormessage: error,
            nextRoute: '/org-dashboard'
          })
        })
    } catch (e) {
      commit('setNewCollaboration', {})
    }
  },
  async fetchBuWiseProjectRagStatus({ commit, rootState }, requestData) {
    try {
      const requestPayload = {
        'week_no': requestData.week_no,
        'department_id': requestData.dept_id
      }

      await this.$resourceApi
        .post(
          '/bu-wise-rag-status',
          {},
          {
            data: requestPayload,
            headers: { Authorization: rootState.auth.tokenId },
            timeout: 200000
          }
        )
        .then((response) => {
          const { data: responseData } = response || {}

          commit('setBuWiseProjectRagStatus', responseData)
        })
        .catch((error) => {
          const message = 'Something went wrong!'

          commit('setCustomDialog', {
            status: true,
            title: 'Error',
            message,
            errormessage: error,
            nextRoute: '/project-dashboard'
          })
        })
    } catch (e) {
      commit('setBuWiseProjectRagStatus', {})
    }
  },

  async fetchPmWiseRagStatus({ commit, rootState }, requestData) {
    try {

      const requestPayload = {
        'week_no': requestData.week_no,
        'user_id': requestData.user_id
      }

      await this.$resourceApi
        .post(
          '/pm-wise-rag-status',
          {},
          {
            data: requestPayload,
            headers: { Authorization: rootState.auth.tokenId },
            timeout: 200000
          }
        )
        .then((response) => {

          const { data: responseData } = response || {}

          commit('setPmWiseRagStatus', responseData)
        })
        .catch((error) => {
          const message = 'Something went wrong!'

          commit('setCustomDialog', {
            status: true,
            title: 'Error',
            message,
            errormessage: error,
            nextRoute: '/project-dashboard'
          })
        })
    } catch (e) {
      commit('setPmWiseRagStatus', {})
    }
  },

  async fetchProjectAtRisk({ commit, rootState }) {
    try {
      await this.$resourceApi
        .get(
          '/project-at-risk-data',
          {},
          {
            headers: { Authorization: rootState.auth.tokenId },
            timeout: 200000
          }
        )
        .then((response) => {
          const { data: responseData } = response || {}

          commit('setProjectAtRisk', responseData)
        })
        .catch((error) => {
          const message = 'Something went wrong!'

          commit('setCustomDialog', {
            status: true,
            title: 'Error',
            message,
            errormessage: error,
            nextRoute: '/org-dashboard'
          })
        })
    } catch (e) {
      commit('setProjectAtRisk', {})
    }
  },

  async sendInvoiceReminder({ commit, rootState }, projectIds) {
    try {
      const requestPayload = {
        redmine_project_ids: projectIds
      }

      await this.$resourceApi
        .post(
          '/invoice-reminder',
          {},
          {
            data: requestPayload,
            headers: { Authorization: rootState.auth.tokenId },
            timeout: 200000
          }
        )
        .then((response) => {
          const { data: responseData } = response || {}

          commit('setInvoiceReminder', responseData)
        })
        .catch((error) => {
          const message = 'Something went wrong!'

          commit('setCustomDialog', {
            status: true,
            title: 'Error',
            message,
            errormessage: error,
            nextRoute: '/project-dashboard'
          })
        })
    } catch (e) {
      commit('setInvoiceReminder', {})
    }
  },
  updateMonthsArray({ commit }, data) {
    commit('setMonthsArray', data)
  },
  async fetchLocations({ commit, rootState }) {
    try {
      const config = {
        headers: { Authorization: rootState.auth.tokenId },
        timeout: 20000
      }
      const { data } = await this.$resourceApi.get('/locations', config)

      if (data.status === 200) {
        const locationData = data.data

        locationData.unshift('All')
        commit('setLocation', locationData)
      }
    } catch (e) {
      commit('setLocation', ['All'])
      throw e
    }
  },
  async fetchDepartments({ commit, rootState }) {
    try {
      const config = {
        headers: { Authorization: rootState.auth.tokenId },
        timeout: 60000
      }
      const { data } = await this.$resourceApi.get('/departments', config)

      if (data.status === 200) {
        const departmentData = data.data

        departmentData.unshift('All')
        commit('setDepartments', departmentData)
      }
    } catch (e) {
      commit('setDepartments', ['All'])
      throw e
    }
  },
  async fetchCategories({ commit, rootState }) {
    try {
      const config = {
        headers: { Authorization: rootState.auth.tokenId },
        timeout: 60000
      }
      const { data } = await this.$resourceApi.get('/categories', config)

      if (data.status === 200) {
        const categoriesData = data.data

        //categoriesData.unshift('All')
        commit('setCategories', categoriesData)
      }
    } catch (e) {
      commit('setCategories', [])
      throw e
    }
  },
  async fetchResourceUtilizationSummary({ commit, rootState }, requestParams) {
    try {
      const config = {
        headers: { Authorization: rootState.auth.tokenId },
        params: {
          start_date: requestParams.startDate,
          end_date: requestParams.endDate,
          location: requestParams.location,
          department: requestParams.department,
          availability: requestParams.availability,
          billing: requestParams.billing,
          projects: requestParams.project,
          exclude_trainee: requestParams.exclude_trainee,
          name: requestParams.name
        },
        timeout: 6000000
      }
      const { data } = await this.$resourceApiV3.get(
        '/resourceutilization-summary',
        config
      )
      const { status, data: resourceData } = data || {}

      if (status === 200) {
        const {
          overview = [],
          bench = [],
          optimallyUtilized = [],
          overUtilized = [],
          underUtilized = []
        } = resourceData || {}

        commit('setUtilizationOverView', overview)
        commit('setBenchUtilized', bench)
        commit('setOptimallyUtilized', optimallyUtilized)
        commit('setOverUtilized', overUtilized)
        commit('setUnderUtilized', underUtilized)
      }
    } catch (e) {
      commit('setUtilizationOverView', [])
      commit('setBenchUtilized', [])
      commit('setOptimallyUtilized', [])
      commit('setOverUtilized', [])
      commit('setUnderUtilized', [])
    }
  },

  async fetchResourceDataForDownload({ commit, rootState }, requestParams) {
    try {
      const config = {
        headers: { Authorization: rootState.auth.tokenId },
        params: {
          start_date: requestParams.startDate,
          end_date: requestParams.endDate,
          location: requestParams.location,
          department: requestParams.department,
          availability: requestParams.availability,
          billing: requestParams.billing,
          projects: requestParams.project,
          exclude_trainee: requestParams.exclude_trainee,
          name: requestParams.name
        },
        timeout: 3000000
      }
      const { data } = await this.$resourceApiV3.get(
        '/resources-availability-download',
        config
      )
      const { status, data: resourceData } = data || {}
      const {
        unScheduled = [],
        fullyScheduled = [],
        partiallyScheduled = [],
        overScheduled = [],
        reportsData = []
      } = resourceData || {}

      if (status === 200) {
        const unScheduledData = []
        const fullyScheduledData = []
        const partiallyScheduledData = []
        const overScheduledData = []
        const benchData = []

        unScheduled.map((resource) => {
          resource.startDate = new Date(resource.startDate).toLocaleDateString(
            'en-US',
            {
              year: 'numeric',
              month: 'short',
              day: 'numeric'
            }
          )
          resource.endDate = new Date(resource.endDate).toLocaleDateString(
            'en-US',
            {
              year: 'numeric',
              month: 'short',
              day: 'numeric'
            }
          )
          unScheduledData.push(resource)
        })
        reportsData.map((resource) => {
          resource.startDate = new Date(resource.startDate).toLocaleDateString(
            'en-US',
            {
              year: 'numeric',
              month: 'short',
              day: 'numeric'
            }
          )
          resource.endDate = new Date(resource.endDate).toLocaleDateString(
            'en-US',
            {
              year: 'numeric',
              month: 'short',
              day: 'numeric'
            }
          )
          benchData.push(resource)
        })
        fullyScheduled.map((resource) => {
          resource.startDate = new Date(resource.startDate).toLocaleDateString(
            'en-US',
            {
              year: 'numeric',
              month: 'short',
              day: 'numeric'
            }
          )
          resource.endDate = new Date(resource.endDate).toLocaleDateString(
            'en-US',
            {
              year: 'numeric',
              month: 'short',
              day: 'numeric'
            }
          )
          fullyScheduledData.push(resource)
        })
        partiallyScheduled.map((resource) => {
          resource.startDate = new Date(resource.startDate).toLocaleDateString(
            'en-US',
            {
              year: 'numeric',
              month: 'short',
              day: 'numeric'
            }
          )
          resource.endDate = new Date(resource.endDate).toLocaleDateString(
            'en-US',
            {
              year: 'numeric',
              month: 'short',
              day: 'numeric'
            }
          )
          partiallyScheduledData.push(resource)
        })
        overScheduled.map((resource) => {
          resource.startDate = new Date(resource.startDate).toLocaleDateString(
            'en-US',
            {
              year: 'numeric',
              month: 'short',
              day: 'numeric'
            }
          )
          resource.endDate = new Date(resource.endDate).toLocaleDateString(
            'en-US',
            {
              year: 'numeric',
              month: 'short',
              day: 'numeric'
            }
          )
          overScheduledData.push(resource)
        })
        commit('setFullyScheduledDownload', fullyScheduledData)
        commit('setOverScheduledDownload', overScheduledData)
        commit('setPartiallyScheduledDownload', partiallyScheduledData)
        commit('setUnscheduledDownload', unScheduledData)
        commit('setBenchReportDownload', benchData)
      }
    } catch (e) {
      commit('setFullyScheduledDownload', [])
      commit('setOverScheduledDownload', [])
      commit('setPartiallyScheduledDownload', [])
      commit('setUnscheduledDownload', [])
      commit('setBenchReportDownload', [])
    }
  },
  resetCartState({ commit }) {
    commit('resetState')
  },
  resetSectionData({ commit }, { data, key }) {
    commit('setResourceDataState', { data, key })
  },
  setSnackbarText({ commit }, text) {
    commit('setSnackbarText', text)
  },
  setSnackbarValue({ commit }, value) {
    commit('setSnackbarValue', value)
  },
  updateProjectRagStatus ({ commit }, value) {
    commit('setProjectRagStatus', value)
  },
  updateProjectRagBillingStatus ({ commit }, value) {
    commit('setProjectRagBillingStatus', value)
  },
  updateProjectRagWeek ({ commit }, value) {
    commit('setProjectRagWeek', value)
  }
}
