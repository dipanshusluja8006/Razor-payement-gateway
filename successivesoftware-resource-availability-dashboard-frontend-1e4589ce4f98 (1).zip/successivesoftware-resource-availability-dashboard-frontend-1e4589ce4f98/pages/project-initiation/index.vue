<template>
  <div id="projectInitiation">
    <Dialog />
    <common-snackbar :text-for-snackbar="snackbarText" :snackbar="snackbarValue" />
    <div class="projectInitHWrp">
      <v-row align="center">
        <v-col class="text-left" cols="12" sm="9">
          <h3 class="projectInitHeading">
            Project Initiation
            <span v-if="e6 === 1">
              <v-img
                :src="stepOne"
                class="projectInitGraph"
                contain
              />
            </span>
            <span v-else-if="e6 === 2">
              <v-img
                :src="stepTwo"
                class="projectInitGraph"
                contain
              />
            </span>
            <span v-else-if="e6 === 3">
              <v-img
                :src="stepThree"
                class="projectInitGraph"
                contain
              />
            </span>
            <span v-else>
              <v-img
                :src="stepfour"
                class="projectInitGraph"
                contain
              />
            </span>
          </h3>
        </v-col>
        <v-col class="text-right pr-6" cols="12" sm="3">
          <div class="actionWrp">
            <v-btn
              small
              class="cancleBtn"
              outlined
              color="grey"
              @click="$router.push('/project-dashboard')"
            >
              Cancel
            </v-btn>
            <v-btn
              :disabled="submitted === true || (projectName === '')"
              small
              color="white"
              class="saveDrft"
              @click="saveDraft"
            >
              Save As Draft
            </v-btn>
          </div>
        </v-col>
      </v-row>
    </div>
    <template>
      <ValidationObserver ref="projectInitObserver" v-slot="{ valid }" class="projectInitiationFormWrp">
        <v-stepper v-model="e6" vertical>
          <!-- <v-stepper v-model="e6" vertical style="background: rgba(237, 237, 237, 0); box-shadow: none;"> -->

          <div :sm="e6 ===5 ? '3' : '12'" class="text-left" cols="12">
            <div v-if="!Step1Error">
              <span v-if="customStep1Message === ''">
                <v-stepper-step :complete="e6 > generalDetailTab" :step="generalDetailTab">
                  General Details
                </v-stepper-step>
              </span>
              <span v-else>
                <span v-if="customStep1Message === 'success'">
                  <v-stepper-step :complete="true" :step="generalDetailTab">
                    General Details
                    <span class="completed"><v-icon dark>mdi-check</v-icon> Completed</span>
                  </v-stepper-step>
                </span>
              </span>
            </div>
            <div v-else>
              <v-stepper-step :rules="[() => false]" :step="generalDetailTab">
                General Details
                <span>
                  <v-btn
                    class="ml-2 custom-message-icon"
                    fab
                    dark
                    x-small
                    color="error"
                  >
                    <v-icon>mdi-alert-circle-outline</v-icon>
                  </v-btn><span class="missingDtl">Details Missing</span></span>
              </v-stepper-step>
            </div>
            <v-stepper-content :step="generalDetailTab">
              <v-card class="projectInitiationFormInner">
                <div class="content bottomSpace">
                  <v-card-text class="cardContent">
                    <v-row>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Project Name *</strong>
                        </div>
                        <ValidationProvider v-slot="{ errors }" :rules="'required|alpha_num_whitespace_special'" name="projectName">
                          <v-text-field
                            v-model.trim="projectName"
                            :error-messages="errors"
                            dense
                            placeholder="Please enter project name"
                          />
                        </ValidationProvider>
                      </v-col>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Project Type *</strong>
                        </div>
                        <ValidationProvider
                          v-slot="{ errors }"
                          :rules="'required'"
                          name="projectTypeId"
                        >
                          <v-autocomplete
                            v-model="projectTypeId"
                            :items="projectTypes"
                            :error-messages="errors"
                            clearable
                            placeholder="Please select project type"
                            item-text="name"
                            item-value="id"
                            dense
                          />
                        </ValidationProvider>
                      </v-col>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Governance Category *</strong>
                          <v-tooltip max-width="350px" bottom>
                            <template v-slot:activator="{ on, attrs }">
                              <v-icon
                                v-bind="attrs"
                                class="mdi-18px btn-color"
                                dark
                                v-on="on"
                              >
                                mdi-information
                              </v-icon>
                            </template>
                            <div>
                              <strong><i><u>Managed Services</u></i></strong> <br>
                              Engagement where successive have full control of the project. like: Estimation, Management, Engineering & Monitoring, etc.
                              <br><strong><i><u>Extension</u></i></strong><br>
                              Support and Maintenance project where task Estimation and Planning drive by the client.
                              <br><strong><i><u>Staff Augmentation</u></i></strong> <br>
                              Engagement where successive only provide staff to client and rest is managed by the client.
                            </div>
                          </v-tooltip>
                        </div>
                        <ValidationProvider
                          v-slot="{ errors }"
                          :rules="'required'"
                          name="governanceCategoryId"
                        >
                          <v-autocomplete
                            v-model="governanceCategoryId"
                            :items="governanceCategories"
                            :error-messages="errors"
                            clearable
                            item-text="name"
                            item-value="id"
                            placeholder="Please select the governance category"
                            dense
                          />
                        </ValidationProvider>
                      </v-col>
                    </v-row>
                    <v-row>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Project Lifecycle Model *</strong>
                        </div>
                        <ValidationProvider v-slot="{ errors }" :rules="'required'" name="projectLifeCycleModel">
                          <v-autocomplete
                            v-model="projectLifeCycleModel"
                            :items="getProjectLifeCycleModel"
                            :error-messages="errors"
                            placeholder="Please select project lifecycle model"
                            item-text="name"
                            item-value="id"
                            dense
                            clearable
                          />
                        </ValidationProvider>
                      </v-col>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Project Domain *</strong>
                        </div>
                        <ValidationProvider v-slot="{ errors }" :rules="'required'" name="projectDomain">
                          <v-autocomplete
                            v-model="selectedDomains"
                            :filter="filter"
                            :hide-no-data="!searchDomain"
                            :items="getProjectDomains"
                            :error-messages="errors"
                            :search-input.sync="searchDomain"
                            item-text="name"
                            item-value="id"
                            hide-selected
                            placeholder="Please select project domains"
                            dense
                            multiple
                            attach
                            @change="searchDomain=''"
                            @keyup.enter="submitNewDomain(searchDomain)"
                          >
                            <template v-slot:no-data />
                            <template v-slot:prepend-item>
                              <v-list-item v-if="searchDomain !== null && searchDomain !== '' && !domainNameArray.includes(searchDomain)">
                                <span class="subheading">Create</span>
                                <v-chip
                                  color="teal lighten-3"
                                  label
                                  small
                                  @click="createNewDomain(searchDomain)"
                                >
                                  {{ searchDomain }}
                                </v-chip>
                              </v-list-item>
                            </template>
                            <template v-slot:selection="{ attrs, item, parent, selected, index}">
                              <v-tooltip top>
                                <template v-slot:activator="{ on }">
                                  <v-chip
                                    v-if="item === Object(item) && index <= 1"
                                    v-bind="attrs"
                                    :input-value="selected"
                                    color="blue lighten-3"
                                    label
                                    small
                                    v-on="on"
                                  >
                                    <span class="pr-2">
                                      {{ item.name.length >= 47? item.name.slice(0,47) + '...': item.name }}
                                    </span>
                                    <v-icon
                                      small
                                      @click="parent.selectItem(item)"
                                    >
                                      mdi-close
                                    </v-icon>
                                  </v-chip>

                                  <v-menu
                                    bottom
                                    origin="center center"
                                    transition="scale-transition"
                                  >
                                    <template v-slot:activator="{ on }">
                                      <v-btn
                                        v-if="index === 2"
                                        class="ml-1 mr-1 text-capitalize"
                                        outlined
                                        rounded
                                        fab
                                        small
                                        height="30"
                                        width="30"
                                        color="blue"
                                        v-on="on"
                                        @click="listData.openProjectDomainList = !listData.openProjectDomainLis"
                                      >
                                        <v-icon x-small style="height: 10px; width: 10px">
                                          mdi-plus
                                        </v-icon>
                                        {{ selectedDomains.length - 2 }}
                                      </v-btn>
                                    </template>
                                    <v-card
                                      v-show="listData.openProjectDomainList"
                                      class="mx-auto"
                                      max-width="300"
                                      raised
                                    >
                                      <v-list
                                        v-if="selectedDomainData.length > 2"
                                        disabled
                                        shaped
                                      >
                                        <v-list-item-group
                                          v-model="selectedDomainData"
                                        >
                                          <v-list-item
                                            v-for="projectDomain in selectedDomainData.slice(2,selectedDomainData.length)"
                                            v-show="listData.openProjectDomainList"
                                            :key="projectDomain.id"
                                          >
                                            <v-avatar
                                              :color="`${randomColors()}`"
                                              size="30"
                                              style="padding:4px"
                                            >
                                              <strong class="white--text headline">{{ avatarNames(projectDomain.name) }}</strong>
                                            </v-avatar>
                                            <v-list-item-content class="ml-2">
                                              <v-list-item-title v-text="projectDomain.name" />
                                            </v-list-item-content>
                                          </v-list-item>
                                        </v-list-item-group>
                                      </v-list>
                                    </v-card>
                                  </v-menu>

                                </template>
                                <span>{{ item.name }}</span>
                              </v-tooltip>
                            </template>
                            <template v-slot:item="{ index, item }">
                              <v-tooltip top>
                                <template v-slot:activator="{ on }">
                                  <v-chip
                                    color="blue lighten-3"
                                    dark
                                    label
                                    small
                                    v-on="on"
                                  >
                                    {{ item.name.length >= 47? item.name.slice(0,47) + '...': item.name }}
                                  </v-chip>
                                  <v-spacer />
                                </template>
                                <span>{{ item.name }}</span>
                              </v-tooltip>
                            </template>
                          </v-autocomplete>
                        </ValidationProvider>
                      </v-col>
                      <v-col md="4" class="p-b-0">
                        <div class="field" style="padding-bottom: 0px;">
                          <v-checkbox
                            v-model="subProject"
                            dense
                            class="shrink mr-2 mt-0"
                            style="padding-top:0px; margin-right: 0px !important; width: 24px; display: inline-flex"
                            hide-details
                          />
                          <div style="display: inline-flex">
                            <strong>Sub-Project</strong>
                          </div>
                        </div>
                        <div v-if="subProject">
                          <ValidationProvider v-slot="{ errors }" :rules="(subProject) ? 'required' : ''" name="subProjectId">
                            <v-autocomplete
                              v-model="subProjectId"
                              :items="getRedminProjectNameList"
                              :disabled="!subProject"
                              :error-messages="errors"
                              item-text="project_name"
                              item-value="uuid"
                              placeholder="Please select project sub project *"
                              dense
                              clearable
                            />
                          </ValidationProvider>
                        </div>
                      </v-col>
                    </v-row>
                    <v-row>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Billing Medium</strong>
                        </div>
                        <v-autocomplete
                          v-model="billingMediumId"
                          :items="billingMediums"
                          clearable
                          placeholder="Billing medium"
                          item-text="name"
                          item-value="redmine_billing_medium_id"
                          dense
                        />
                      </v-col>
                      <v-col md="8" class="p-b-0">
                        <div class="field">
                          <strong>Billing Type *</strong>
                        </div>
                        <v-chip-group
                          v-model="billingType"
                          mandatory
                          active-class="deep-purple accent-4 white--text"
                          column
                        >
                          <div v-for="(billing, index) in billingTypes" :key="index">
                            <v-chip
                              :value="billing.id"
                              class="ml-2"
                              @click="setTabValues(billing.id)"
                            >
                              {{ billing.name }}
                            </v-chip>
                          </div>
                        </v-chip-group>
                      </v-col>
                    </v-row>
                    <v-row class="mb-0">
                      <v-col md="8" class="p-b-0">
                        <div class="field">
                          <strong>Project Summary *</strong>
                        </div>
                        <ValidationProvider v-slot="{ errors }" :rules="'required|alpha_num_whitespace_special_line_break'" name="projectSummary">
                          <v-textarea
                            v-model.trim="projectSummary"
                            :error-messages="errors"
                            :auto-grow="true"
                            dense
                            placeholder="Please enter project summary.."
                            rows="1"
                          />
                        </ValidationProvider>
                      </v-col>
                    </v-row>

                  </v-card-text>
                </div>
              </v-card>
              <v-col class="text-right continueBtnWrp">
                <v-btn v-if="(billingType === 1 || billingType === 2 || billingType === 3)" class="continueBtn" @click="checkCompleteStep(1)">
                  Continue
                </v-btn>
                <v-btn v-else class="continueBtn" @click="checkCompleteStep(1)">
                  Continue
                </v-btn>
              </v-col>
            </v-stepper-content>
            <div v-if="!Step2Error" v-show="(billingType === 1 || billingType === 2 || billingType === 3)">
              <span v-if="customStep2Message === ''">
                <v-stepper-step :complete="e6 > clientDetailTab" :step="clientDetailTab">
                  Client Details
                </v-stepper-step>
              </span>
              <span v-else>
                <span v-if="customStep2Message === 'success'">
                  <v-stepper-step :complete="true" :step="clientDetailTab">
                    Client Details
                    <span class="completed"><v-icon dark>mdi-check</v-icon> Completed</span>
                  </v-stepper-step>
                </span>
              </span>
            </div>
            <div v-else v-show="(billingType === 1 || billingType === 2 || billingType === 3)">
              <v-stepper-step :rules="[() => false]" :step="clientDetailTab">
                Client Details
                <span >
                  <v-btn
                    class="ml-2 custom-message-icon"
                    fab
                    dark
                    x-small
                    color="error"
                  >
                    <v-icon>mdi-alert-circle-outline</v-icon>
                  </v-btn><span class="missingDtl">Details Missing</span></span>
              </v-stepper-step>
            </div>
            <v-stepper-content v-show="(billingType === 1 || billingType === 2 || billingType === 3)" :step="clientDetailTab">
              <v-card class="projectInitiationFormInner">
                <div v-if="billingType === 1 || billingType === 2 || billingType === 3" class="content bottomSpace">
                  <v-card-text class="cardContent">
                    <v-row>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Company Name *</strong>
                        </div>
                        <ValidationProvider v-slot="{ errors }" :rules="(billingType === 1 || billingType === 2 || billingType === 3) ? 'required|alpha_num_whitespace_special' : ''" name="companyName">
                          <v-text-field
                            v-model.trim="companyName"
                            :disabled="!(billingType === 1 || billingType === 2 || billingType === 3)"
                            :error-messages="errors"
                            placeholder="Please enter company's name"
                            dense
                          />
                        </ValidationProvider>
                      </v-col>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Country *</strong>
                        </div>
                        <ValidationProvider v-slot="{ errors }" :rules="(billingType === 1 || billingType === 2 || billingType === 3) ? 'required' : ''" name="companyCountry">
                          <v-autocomplete
                            v-model="companyCountry"
                            :disabled="!(billingType === 1 || billingType === 2 || billingType === 3)"
                            :items="newCountryData"
                            placeholder="Please enter country"
                            item-text="countryName"
                            item-value="countryName"
                            :error-messages="errors"
                            dense
                            clearable
                            @change="setResignValues(companyCountry)"
                          />
                        </ValidationProvider>
                      </v-col>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>State *</strong>
                        </div>
                        <ValidationProvider v-slot="{ errors }" :rules="(billingType === 1 || billingType === 2 || billingType === 3) ? 'required' : ''" name="companyState">
                          <v-autocomplete
                            v-model="companyState"
                            :disabled="!(billingType === 1 || billingType === 2 || billingType === 3)"
                            :items="newStateData"
                            placeholder="Please enter state"
                            item-text="name"
                            item-value="name"
                            :error-messages="errors"
                            dense
                            clearable
                          />
                        </ValidationProvider>
                      </v-col>
                    </v-row>
                    <v-row>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Company Address *</strong>
                        </div>
                        <ValidationProvider v-slot="{ errors }" :rules="(billingType === 1 || billingType === 2 || billingType === 3) ? 'required|alpha_num_whitespace_special_line_break' : ''" name="companyAddress">
                          <v-textarea
                            v-model.trim="companyAddress"
                            :disabled="!(billingType === 1 || billingType === 2 || billingType === 3)"
                            :error-messages="errors"
                            placeholder="Enter enter company's address"
                            rows="1"
                            dense
                            auto-grow
                          />
                        </ValidationProvider>
                      </v-col>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Client Name and Email Address *</strong>
                        </div>
                        <v-autocomplete
                          v-model="selectedClients"
                          :hide-no-data="!searchClients"
                          :items="getProjectClients"
                          :search-input.sync="searchClients"
                          item-text="name"
                          item-value="id"
                          :error="validateClientDetails"
                          :error-messages="errorMsg"
                          placeholder="Select existing client"
                          attach
                          chips
                          dense
                          multiple
                          clearable
                          @click="validateField"
                          @change="validateField"
                        >
                          <template v-slot:selection="data">
                            <v-tooltip max-width="350px" top>
                              <template v-slot:activator="{ on }">
                                <span
                                  v-if="data.index <= 2"
                                  v-bind="data.attrs"
                                  :input-value="data.selected"
                                  close
                                  style="padding-left: 10px;"
                                  v-on="on"
                                  @click="data.select"
                                  @click:close="removeItemFromArray(data.item, 'selectedClients')"
                                >
                                  <v-avatar
                                    :color="`${randomColors()}`"
                                    size="30"
                                    style="padding:4px"
                                    v-on="on"
                                  >
                                    <span class="white--text headline">{{ avatarNames(data.item.name) }}</span>
                                  </v-avatar>
                                </span>
                                <v-menu
                                  bottom
                                  origin="center center"
                                  transition="scale-transition"
                                >
                                  <template v-slot:activator="{ on }">
                                    <v-btn
                                      v-if="data.index === 3"
                                      class="ml-1 mr-1 text-capitalize"
                                      outlined
                                      rounded
                                      fab
                                      small
                                      height="30"
                                      width="30"
                                      color="blue"
                                      v-on="on"
                                      @click="listData.openProjectClientList = !listData.openProjectClientLis"
                                    >
                                      <v-icon x-small style="height: 10px; width: 10px">
                                        mdi-plus
                                      </v-icon>
                                      {{ selectedClients.length - 3 }}
                                    </v-btn>
                                  </template>
                                  <v-card
                                    v-show="listData.openProjectClientList"
                                    class="mx-auto"
                                    max-width="300"
                                    raised
                                  >
                                    <v-list
                                      v-if="selectedClientsData.length > 3"
                                      disabled
                                      shaped
                                    >
                                      <v-list-item-group
                                        v-model="selectedClientsData"
                                      >
                                        <v-list-item
                                          v-for="clientData in selectedClientsData.slice(3,selectedClientsData.length)"
                                          v-show="listData.openProjectClientList"
                                          :key="clientData.id"
                                        >
                                          <v-avatar
                                            :color="`${randomColors()}`"
                                            size="30"
                                            style="padding:4px"
                                          >
                                            <strong class="white--text headline">{{ avatarNames(clientData.name) }}</strong>
                                          </v-avatar>
                                          <v-list-item-content class="ml-2">
                                            <v-list-item-title v-text="clientData.name" />
                                          </v-list-item-content>
                                        </v-list-item>
                                      </v-list-item-group>
                                    </v-list>
                                  </v-card>
                                </v-menu>
                              </template>
                              <div>
                                <strong>{{ (data.item.emails && data.item.emails !== '') ? data.item.emails : '' }}</strong>
                              </div>
                            </v-tooltip>
                          </template>
                          <template v-slot:item="data">
                            <v-list-item-content>
                              <v-list-item-title v-html="data.item.name" />
                              <v-list-item-subtitle>{{ (data.item.emails && data.item.emails !== '') ? data.item.emails : '' }}</v-list-item-subtitle>
                            </v-list-item-content>
                          </template>
                        </v-autocomplete>
                      </v-col>
                    </v-row>
                    <v-row>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                        </div>
                      </v-col>
                      <v-col md="8" class="p-b-0 addNewClient mb-4" >
                        <div class="field">
                          <strong>Add New</strong>
                        </div>
                        <v-row>
                          <v-col md="5" class="pb-0">
                            <v-text-field
                              v-model.trim="clientName"
                              placeholder="Enter client's name"
                              dense
                              solo-inverted
                              rounded
                            />
                          </v-col>
                          <v-col md="5" class="pb-0">
                            <v-text-field
                              v-model.trim="clientEmail"
                              placeholder="Enter client's email id"
                              dense
                              solo-inverted
                              rounded
                              class="error--text"
                            />
                          </v-col>
                          <v-col md="2" class="pb-0">
                            <v-btn
                              v-if="clientName != '' && clientEmail != ''"
                              class="btn-color"
                              depressed
                              @click="createMoreClientDetails"
                            >
                              Save
                            </v-btn>
                            <v-btn
                              v-else
                              class="btn-color"
                              depressed
                              disabled
                              @click="createMoreClientDetails"
                            >
                              Save
                            </v-btn>
                          </v-col>
                        </v-row>
                      </v-col>
                    </v-row>
                  </v-card-text>
                </div>
              </v-card>
              <v-col class="text-right continueBtnWrp">
                <v-btn text class="backtoPrev" @click="e6 = generalDetailTab">
                  Back
                </v-btn>
                <v-btn class="continueBtn" @click="checkCompleteStep(2)">
                  Continue
                </v-btn>
              </v-col>
            </v-stepper-content>
            <div v-if="!Step3Error">
              <span v-if="customStep3Message === ''">
                <v-stepper-step :complete="e6 > timelineTab" :step="timelineTab">
                  Timeline
                </v-stepper-step>
              </span>
              <span v-else>
                <span v-if="customStep3Message === 'success'">
                  <v-stepper-step :complete="true" :step="timelineTab">
                    Timeline
                    <span class="completed"><v-icon dark>mdi-check</v-icon> Completed</span>
                  </v-stepper-step>
                </span>
              </span>
            </div>
            <div v-else>
              <v-stepper-step :rules="[() => false]" :step="timelineTab">
                Timeline
                <span >
                  <v-btn
                    class="ml-2 custom-message-icon"
                    fab
                    dark
                    x-small
                    color="error"
                  >
                    <v-icon>mdi-alert-circle-outline</v-icon>
                  </v-btn><span class="missingDtl">Details Missing</span></span>
              </v-stepper-step>
            </div>
            <v-stepper-content :step="timelineTab">
              <v-card class="projectInitiationFormInner">
                <div class="content bottomSpace">
                  <v-card-text class="cardContent">
                    <v-row>
                      <v-col md="4" class="p-b-0">
                        <div class="field"><strong>Project Duration *</strong></div>
                        <v-row class="pt-3">
                          <v-col cols="12" md="8" class="projectDurationFld pt-0 pr-0">
                            <v-menu
                              ref="TimelineMenu"
                              v-model="menu"
                              :close-on-content-click="false"
                              offset-y
                              transition="scale-transition"
                            >
                              <template v-slot:activator="{ on }">
                                <v-text-field
                                  slot="activator"
                                  v-model="dates"
                                  multiple
                                  readonly
                                  dense
                                  solo-inverted
                                  filled
                                  v-on="on"
                                >
                                  <template v-slot:append>
                                    <v-icon v-on="on">
                                      mdi-calendar
                                    </v-icon>
                                  </template>
                                </v-text-field>
                              </template>
                              <v-date-picker
                                v-model="datePicker"
                                range
                                no-title
                                scrollable
                                @change="changeTimelineFromDateString"
                              />
                            </v-menu>
                          </v-col>
                          <v-col cols="12" md="4" class="projectDurationFld pt-0 pl-1">
                            <v-text-field
                              v-model="totalDays"
                              label="Days"
                              solo-inverted
                              dense
                              readonly
                            />
                          </v-col>
                        </v-row>
                      </v-col>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>{{ (billingType === 1) ? 'Total Approved Hours *' : 'Maximum Hours Billed *' }}</strong>
                        </div>
                        <ValidationProvider
                          v-if="billingType === 1"
                          v-slot="{ errors }"
                          :rules="'required|numeric|max:10'"
                          name="approvedHours"
                        >
                          <v-text-field
                            v-model="approvedHours"
                            :error-messages="errors"
                            placeholder="Approved hours"
                            dense
                          />
                        </ValidationProvider>
                        <ValidationProvider
                          v-else
                          v-slot="{ errors }"
                          :rules="'required|numeric|max:10'"
                          name="maximumHoursBilled"
                        >
                          <v-text-field
                            v-model="maximumHoursBilled"
                            :error-messages="errors"
                            placeholder="Approved Hours "
                            dense
                          />
                        </ValidationProvider>
                      </v-col>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Billing Interval{{ (billingType === 1 || billingType === 2|| billingType === 3) ? ' *' : '' }}</strong>
                        </div>
                        <div v-if="billingType === 1 || billingType === 2 || billingType === 3">
                          <ValidationProvider
                            v-slot="{ errors }"
                            :rules="'required'"
                            name="billingInterval"
                          >
                            <v-autocomplete
                              v-model="billingInterval"
                              :items="billingIntervalArray"
                              :error-messages="errors"
                              clearable
                              placeholder="Please select billing interval"
                              item-text="name"
                              item-value="value"
                              dense
                            />
                          </ValidationProvider>
                        </div>
                        <div
                          v-else
                        >
                          <v-autocomplete
                            v-model="billingInterval"
                            :items="billingIntervalArray"
                            clearable
                            placeholder="Please select billing interval"
                            item-text="name"
                            item-value="value"
                            dense
                          />
                        </div>
                      </v-col>
                    </v-row>
                  </v-card-text>
                </div>
              </v-card>
              <v-col class="text-right continueBtnWrp">
                <v-btn v-if="billingType === 1 || billingType === 2 || billingType === 3" class="backtoPrev" text @click="e6 = clientDetailTab">
                  Back
                </v-btn>
                <v-btn v-else class="backtoPrev" text @click="e6 = generalDetailTab">
                  Back
                </v-btn>
                <v-btn class="continueBtn" @click="checkCompleteStep(3)">
                  Continue
                </v-btn>
              </v-col>
            </v-stepper-content>
            <div v-if="!Step4Error">
              <span v-if="customStep4Message === ''">
                <v-stepper-step :step="projectComponentTab">
                  Project Components
                </v-stepper-step>
              </span>
              <span v-else>
                <span v-if="customStep4Message === 'success'">
                  <v-stepper-step :complete="true" :step="projectComponentTab">
                    Project Components
                    <span class="completed"><v-icon dark>mdi-check</v-icon> Completed</span>
                  </v-stepper-step>
                </span>
              </span>
            </div>
            <div v-else>
              <v-stepper-step :rules="[() => false]" :step="projectComponentTab">
                Project Components
                <span >
                  <v-btn
                    class="ml-2 custom-message-icon"
                    fab
                    dark
                    x-small
                    color="error"
                  >
                    <v-icon>mdi-alert-circle-outline</v-icon>
                  </v-btn><span class="missingDtl">Details Missing</span></span>
              </v-stepper-step>
            </div>
            <v-stepper-content :step="projectComponentTab">
              <v-card class="projectInitiationFormInner">
                <div class="content bottomSpace">
                  <v-card-text class="cardContent">
                    <v-row>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Project Components *</strong>
                        </div>
                        <ValidationProvider v-slot="{ errors }" :rules="'required'" name="selected">
                          <v-chip-group
                            v-model="selected"
                            :mandatory="false"
                            :error-messages="errors"
                            active-class="deep-purple accent-4 white--text"
                            column
                            multiple
                            @change="checkCompleteStep(4)"
                          >
                            <div class="projectComp">
                              <v-chip
                                value="web"
                                class="ml-2"
                                hide-details
                              >
                                Web Application
                              </v-chip>
                              <v-chip
                                value="mobile"
                                class="ml-2"
                                hide-details
                              >
                                Mobile Application
                              </v-chip>
                              <v-chip
                                value="design"
                                class="ml-2"
                                hide-details
                              >
                                Designing
                              </v-chip>
                              <v-chip
                                value="other"
                                class="ml-2"
                                hide-details
                                @mousedown="clearOtherComponent()"
                              >
                                others
                              </v-chip>
                              <ValidationProvider v-if="selected.includes('other')" v-slot="{ errors }" :rules="`required|alpha_num_whitespace_special`" name="otherComponents">
                                <span class="otherProjComp">
                                  <v-text-field
                                    v-if="selected.includes('other')"
                                    v-model.trim="otherComponents"
                                    :error-messages="errors"
                                    :placeholder="`Type Here...`"
                                    outlined
                                    dense
                                    @change="checkCompleteStep(4)"
                                  />
                                </span>
                              </ValidationProvider>
                            </div>
                          </v-chip-group>
                        </ValidationProvider>
                      </v-col>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Account Manager *</strong>
                        </div>
                        <ValidationProvider v-slot="{ errors }" :rules="'required'" name="selectedManager">
                          <v-autocomplete
                            v-model="selectedManager"
                            :error-messages="errors"
                            :items="users"
                            :search-input.sync="searchPm"
                            item-text="full_name"
                            item-value="id"
                            attach
                            chips
                            dense
                            placeholder="Select account manager(s)"
                            multiple
                            @change="searchPm='', checkCompleteStep(4)"
                          >
                            <template v-slot:selection="data">
                              <v-tooltip max-width="350px" top>
                                <template v-slot:activator="{ on }">
                                  <v-chip
                                    v-if="data.index === 0"
                                    v-bind="data.attrs"
                                    :input-value="data.selected"
                                    close
                                    v-on="on"
                                    @click="data.select"
                                    @click:close="removeItemFromArray(data.item, 'selectedManager')"
                                  >
                                    <strong>{{ data.item.full_name }}</strong>
                                  </v-chip>
                                  <v-menu
                                    bottom
                                    origin="center center"
                                    transition="scale-transition"
                                  >
                                    <template v-slot:activator="{ on }">
                                      <v-btn
                                        v-if="data.index === 1"
                                        class="ml-1 mr-1 text-capitalize"
                                        outlined
                                        rounded
                                        fab
                                        small
                                        height="30"
                                        width="30"
                                        color="blue"
                                        v-on="on"
                                        @click="listData.openProjectAMList = !listData.openProjectAMLis"
                                      >
                                        <v-icon x-small style="height: 10px; width: 10px">
                                          mdi-plus
                                        </v-icon>
                                        {{ selectedManager.length - 1 }}
                                      </v-btn>
                                    </template>
                                    <v-card
                                      v-show="listData.openProjectAMList"
                                      class="mx-auto"
                                      max-width="300"
                                      raised
                                    >
                                      <v-list
                                        v-if="selectedAMData.length > 1"
                                        disabled
                                        shaped
                                      >
                                        <v-list-item-group
                                          v-model="selectedAMData"
                                        >
                                          <v-list-item
                                            v-for="accountManager in selectedAMData.slice(1, selectedAMData.length)"
                                            v-show="listData.openProjectAMList"
                                            :key="accountManager.id"
                                          >
                                            <v-avatar
                                              :color="`${randomColors()}`"
                                              size="30"
                                              style="padding:4px"
                                            >
                                              <strong>{{ avatarNames(accountManager.full_name) }}</strong>
                                            </v-avatar>
                                            <v-list-item-content class="ml-2">
                                              <v-list-item-title v-text="accountManager.full_name" />
                                            </v-list-item-content>
                                          </v-list-item>
                                        </v-list-item-group>
                                      </v-list>
                                    </v-card>
                                  </v-menu>
                                </template>
                                <div>
                                  <strong>{{ (data.item.job_title && data.item.job_title !== '') ? data.item.job_title : '' }}</strong><br>
                                  {{ `Emp # ${data.item.employee_id} | ${(data.item.dept[0]) ? data.item.dept[0].name : ''}` }}
                                </div>
                              </v-tooltip>
                            </template>
                            <template v-slot:item="data">
                              <v-list-item-content>
                                <v-list-item-title v-html="data.item.full_name" />
                                <v-list-item-subtitle>{{ (data.item.job_title && data.item.job_title !== '') ? data.item.job_title : '' }}</v-list-item-subtitle>
                                <v-list-item-subtitle>{{ `Emp # ${data.item.employee_id} | ${(data.item.dept[0]) ? data.item.dept[0].name : ''}` }}</v-list-item-subtitle>
                              </v-list-item-content>
                            </template>
                          </v-autocomplete>
                        </ValidationProvider>
                      </v-col>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Project Manager *</strong>
                        </div>
                        <ValidationProvider v-slot="{ errors }" :rules="'required'" name="projectManager">
                          <v-autocomplete
                            v-model="selectedProjectManager"
                            :error-messages="errors"
                            :items="users"
                            :search-input.sync="searchAm"
                            item-text="full_name"
                            item-value="id"
                            attach
                            chips
                            dense
                            placeholder="Select project manager(s)"
                            multiple
                            @change="searchAm='', checkCompleteStep(4)"
                          >
                            <template v-slot:selection="data">
                              <v-tooltip max-width="350px" top>
                                <template v-slot:activator="{ on }">
                                  <v-chip
                                    v-if="data.index === 0"
                                    v-bind="data.attrs"
                                    :input-value="data.selected"
                                    close
                                    v-on="on"
                                    @click="data.select"
                                    @click:close="removeItemFromArray(data.item, 'selectedProjectManager')"
                                  >
                                    <strong>{{ data.item.full_name }}</strong>
                                  </v-chip>
                                  <v-menu
                                    bottom
                                    origin="center center"
                                    transition="scale-transition"
                                  >
                                    <template v-slot:activator="{ on }">
                                      <v-btn
                                        v-if="data.index === 1"
                                        class="ml-1 mr-1 text-capitalize"
                                        outlined
                                        rounded
                                        fab
                                        small
                                        height="30"
                                        width="30"
                                        color="blue"
                                        v-on="on"
                                        @click="listData.openProjectPMList = !listData.openProjectPMLis"
                                      >
                                        <v-icon x-small style="height: 10px; width: 10px">
                                          mdi-plus
                                        </v-icon>
                                        {{ selectedProjectManager.length - 1 }}
                                      </v-btn>
                                    </template>
                                    <v-card
                                      v-show="listData.openProjectPMList"
                                      class="mx-auto"
                                      max-width="300"
                                      raised
                                    >
                                      <v-list
                                        v-if="selectedPMData.length > 1"
                                        disabled
                                        shaped
                                      >
                                        <v-list-item-group
                                          v-model="selectedPMData"
                                        >
                                          <v-list-item
                                            v-for="projectManager in selectedPMData.slice(1, selectedPMData.length)"
                                            v-show="listData.openProjectPMList"
                                            :key="projectManager.id"
                                          >
                                            <v-avatar
                                              :color="`${randomColors()}`"
                                              size="30"
                                              style="padding:4px"
                                            >
                                              <strong class="white--text headline">{{ avatarNames(projectManager.full_name) }}</strong>
                                            </v-avatar>
                                            <v-list-item-content class="ml-2">
                                              <v-list-item-title v-text="projectManager.full_name" />
                                            </v-list-item-content>
                                          </v-list-item>
                                        </v-list-item-group>
                                      </v-list>
                                    </v-card>
                                  </v-menu>
                                </template>
                                <div>
                                  <strong>{{ (data.item.job_title && data.item.job_title !== '') ? data.item.job_title : '' }}</strong><br>
                                  {{ `Emp # ${data.item.employee_id} | ${(data.item.dept[0]) ? data.item.dept[0].name : ''}` }}
                                </div>
                              </v-tooltip>
                            </template>
                            <template v-slot:item="data">
                              <v-list-item-content>
                                <v-list-item-title v-html="data.item.full_name" />
                                <v-list-item-subtitle>{{ (data.item.job_title && data.item.job_title !== '') ? data.item.job_title : '' }}</v-list-item-subtitle>
                                <v-list-item-subtitle>{{ `Emp # ${data.item.employee_id} | ${(data.item.dept[0]) ? data.item.dept[0].name : ''}` }}</v-list-item-subtitle>
                              </v-list-item-content>
                            </template>
                          </v-autocomplete>
                        </ValidationProvider>
                      </v-col>
                    </v-row>
                    <v-row>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Tech Stack *</strong>
                        </div>
                        <ValidationProvider v-slot="{ errors }" :rules="'required'" name="selectedTechnologies">
                          <v-autocomplete
                            v-model="selectedTechnologies"
                            :filter="filter"
                            :hide-no-data="!searchTech"
                            :error-messages="errors"
                            :items="technologies"
                            :search-input.sync="searchTech"
                            item-text="name"
                            item-value="id"
                            attach
                            chips
                            dense
                            placeholder="Please select tech stack"
                            multiple
                            @change="searchTech='', checkCompleteStep(4)"
                            @keyup.enter="submitNewTech(searchTech)"
                          >
                            <template v-slot:no-data />
                            <template v-slot:prepend-item>
                              <v-list-item v-if="searchTech !== null && searchTech !== '' && techNameArray.findIndex(item => ((searchTech) ? searchTech.toLowerCase() : searchTech) === ((item) ? item.toLowerCase() : item)) < 0">
                                <span class="subheading">Create</span>
                                <v-chip
                                  color="teal lighten-3"
                                  label
                                  small
                                  @click="createNewTech(searchTech)"
                                >
                                  {{ searchTech }}
                                </v-chip>
                              </v-list-item>
                            </template>
                            <template v-slot:selection="data">
                              <v-chip
                                v-bind="data.attrs"
                                :input-value="data.selected"
                                close
                                @click="data.select"
                                @click:close="removeItemFromArray(data.item, 'selectedTechnologies')"
                              >
                                <strong>{{ data.item.name }}</strong>&nbsp;
                              </v-chip>
                            </template>
                            <template v-slot:selection="{ attrs, item, parent, selected, index }">
                              <v-tooltip top>
                                <template v-slot:activator="{ on }">
                                  <v-chip
                                    v-if="item === Object(item) && index === 0"
                                    v-bind="attrs"
                                    :input-value="selected"
                                    label
                                    small
                                    v-on="on"
                                  >
                                    <span class="pr-2">
                                      {{ item.name.length >= 47? item.name.slice(0,47) + '...': item.name }}
                                    </span>
                                    <v-icon
                                      small
                                      @click="parent.selectItem(item)"
                                    >
                                      mdi-close
                                    </v-icon>
                                  </v-chip>
                                  <v-menu
                                    bottom
                                    origin="center center"
                                    transition="scale-transition"
                                  >
                                    <template v-slot:activator="{ on }">
                                      <v-btn
                                        v-if="index === 1"
                                        class="ml-1 mr-1 text-capitalize"
                                        outlined
                                        rounded
                                        fab
                                        small
                                        height="30"
                                        width="30"
                                        color="blue"
                                        v-on="on"
                                        @click="listData.openProjectTechList = !listData.openProjectTechLis"
                                      >
                                        <v-icon x-small style="height: 10px; width: 10px">
                                          mdi-plus
                                        </v-icon>
                                        {{ selectedTechnologies.length - 1 }}
                                      </v-btn>
                                    </template>
                                    <v-card
                                      v-show="listData.openProjectTechList"
                                      class="mx-auto"
                                      max-width="300"
                                      raised
                                    >
                                      <v-list
                                        v-if="selectedTechData.length > 1"
                                        disabled
                                        shaped
                                      >
                                        <v-list-item-group
                                          v-model="selectedTechData"
                                        >
                                          <v-list-item
                                            v-for="technologie in selectedTechData.slice(1,selectedTechData.length)"
                                            v-show="listData.openProjectTechList"
                                            :key="technologie.id"
                                          >
                                            <v-avatar
                                              :color="`${randomColors()}`"
                                              size="30"
                                              style="padding:4px"
                                            >
                                              <strong class="white--text headline">{{ avatarNames(technologie.name) }}</strong>
                                            </v-avatar>
                                            <v-list-item-content class="ml-2">
                                              <v-list-item-title v-text="technologie.name" />
                                            </v-list-item-content>
                                          </v-list-item>
                                        </v-list-item-group>
                                      </v-list>
                                    </v-card>
                                  </v-menu>
                                </template>
                                <span>{{ item.name }}</span>
                              </v-tooltip>
                            </template>
                          </v-autocomplete>
                        </ValidationProvider>
                      </v-col>
                      <v-col md="8" class="p-b-0 addNewClient">
                        <div class="field">
                          <strong>Project Document Links *</strong>
                        </div>
                        <v-row v-for="(project, index) in projectDocuments" :key="index" class="align-center pt-0 mt-0">
                          <v-col
                            md="10"
                            class="pt-0"
                          >
                            <ValidationProvider v-slot="{ errors }" :name="`projectLink-${++index}`" :rules="'required|alpha_num_whitespace_special'">
                              <v-text-field
                                v-model.trim="project.link"
                                :error-messages="errors"
                                :placeholder="`Paste url here`"
                                dense
                                solo-inverted
                                rounded
                                @change="checkCompleteStep(4)"
                              />
                            </ValidationProvider>
                          </v-col>
                          <v-col
                            cols="12"
                            md="2"
                            class="pt-0"
                          >
                            <span v-if="projectDocuments.length === index" class="d-inline mr-1">
                              <v-btn
                                class="addMoreBtn"
                                fab
                                x-small
                                @click="addMoreProjectDocsField"
                              >
                                <v-icon>
                                  mdi-plus
                                </v-icon>
                              </v-btn>
                            </span>
                            <span v-if="index > 1" class="d-inline">
                              <v-btn
                                class="minusBtn"
                                fab
                                color="error"
                                x-small
                                @click="removeDocumentsLink(index)"
                              >
                                <v-icon>
                                  mdi-minus
                                </v-icon>
                              </v-btn>
                            </span>
                          </v-col>
                        </v-row>
                      </v-col>
                    </v-row>
                  </v-card-text>
                </div>
              </v-card>
              <v-col class="text-right continueBtnWrp">
                <v-btn class="backtoPrev" text @click="e6 = timelineTab">
                  Back
                </v-btn>
                <v-btn
                  v-if="!valid"
                  class="continueBtn"
                  :disabled="!valid"
                  @click="submit"
                >
                  Submit Project
                  <v-icon
                    small
                  >
                    mdi-chevron-right
                  </v-icon>
                </v-btn>
                <v-btn v-else :disabled="submitted" class="continueBtn" @click="submit">
                  Submit Project <v-icon
                    middle
                  >
                    mdi-chevron-right
                  </v-icon>
                </v-btn>
              </v-col>
            </v-stepper-content>
          </div>
          <div :class="e6 === 5 ? '' : 'd-none'" class="projectInitiatedAlertWrp">
            <template v-if="e6 === 5">
              <v-card
                color="white lighten-1"
                class="mb-12 pa-3"
              >
                <v-row align="center">
                  <v-col class="text-left" cols="5">
                    <v-img v-if="submitType === 'Draft'" :src="saveInDraft" max-height="250" contain />
                    <v-img v-else :src="cardImg" max-height="250" contain />
                  </v-col>
                  <v-col class="text-left" cols="7" style="padding: 0px">
                    <v-card v-if="submitType === 'Draft'" class="pa-3" style="box-shadow: none;">
                      <h4 class="headline text-center">
                        Project "{{ projectData.project_name }}" has been saved in drafts
                      </h4>
                      <v-row>
                        <v-col cols="12" class="text-center">
                          <v-btn to="/project-dashboard" depressed class="doneBtn">
                            Done
                          </v-btn>
                        </v-col>
                      </v-row>
                    </v-card>
                    <v-card v-else class="pa-3 projectInitiatedAlert" style="box-shadow: none;">
                      <h4 v-if="projectData.status = 1" class="headline mb-1" color="grey">
                        The Project "{{ projectData.project_name }}" has Been Initiated
                      </h4>
                      <h4 v-if="projectData.status = 0" class="headline mb-1" color="grey">
                        Your Project has been submited to global operation for approval
                      </h4>
                      <div>
                        <p style="display: inline-flex">The Account Manager(s) are: </p>
                        <span
                          v-for="accountManager in projectData.account_managers.slice(0,3)"
                          :key="accountManager.user_id"
                          class="ma-1"
                          text-color="white"
                        >
                          <v-tooltip top>
                            <template v-slot:activator="{ on }">
                              <v-avatar
                                :color="`${randomColors()}`"
                                size="30"
                                style="padding:4px"
                                v-on="on"
                              >
                                <span class="white--text headline">{{ avatarNames(accountManager.user.display_name) }}</span>
                              </v-avatar>
                            </template>
                            {{ accountManager.user.display_name }}
                          </v-tooltip>
                        </span>
                        <v-menu
                          bottom
                          origin="center center"
                          transition="scale-transition"
                        >
                          <template v-slot:activator="{ on }">
                            <v-btn
                              v-if="projectData.account_managers.length > 3"
                              class="moreThanOne"
                              outlined
                              fab
                              color="blue"
                              v-on="on"
                              @click="!false"
                            >
                              <v-icon>
                                mdi-plus
                              </v-icon>
                              {{ projectData.account_managers.slice(3,projectData.account_managers.length).length }}
                            </v-btn>
                          </template>
                          <v-card
                            v-show="!false"
                            class="mx-auto"
                            max-width="300"
                            raised
                          >
                            <v-list
                              v-if="projectData.account_managers.length > 3"
                              disabled
                              shaped
                            >
                              <v-list-item-group
                                v-model="projectData.account_managers"
                              >
                                <v-list-item
                                  v-for="accountManager in projectData.account_managers.slice(3,projectData.account_managers.length)"
                                  v-show="!false"
                                  :key="accountManager.user_id"
                                >
                                  <v-avatar
                                    :color="`${randomColors()}`"
                                    size="30"
                                    style="padding:4px"
                                  >
                                    <strong class="white--text headline">{{ avatarNames(accountManager.user.display_name) }}</strong>
                                  </v-avatar>
                                  <v-list-item-content class="ml-2">
                                    <v-list-item-title v-text="accountManager.user.display_name" />
                                  </v-list-item-content>
                                </v-list-item>
                              </v-list-item-group>
                            </v-list>
                          </v-card>
                        </v-menu>
                      </div>
                      <div>
                        <p style="display: inline-flex">The Project Manager(s) are: </p>
                        <span
                          v-for="projectManager in projectData.project_managers.slice(0,3)"
                          :key="projectManager.user_id"
                          class="ma-1"
                          text-color="white"
                        >
                          <v-tooltip top>
                            <template v-slot:activator="{ on }">
                              <v-avatar
                                :color="`${randomColors()}`"
                                size="30"
                                style="padding:4px"
                                v-on="on"
                              >
                                <span class="white--text headline">{{ avatarNames(projectManager.user.display_name) }}</span>
                              </v-avatar>
                            </template>
                            {{ projectManager.user.display_name }}
                          </v-tooltip>
                        </span>
                        <v-menu
                          bottom
                          origin="center center"
                          transition="scale-transition"
                        >
                          <template v-slot:activator="{ on }">
                            <v-btn
                              v-if="projectData.project_managers.length > 3"
                              class="moreThanOne"
                              outlined
                              fab
                              color="blue"
                              v-on="on"
                              @click="!false"
                            >
                              <v-icon>
                                mdi-plus
                              </v-icon>
                              {{ projectData.project_managers.slice(3,projectData.project_managers.length).length }}
                            </v-btn>
                          </template>
                          <v-card
                            v-show="!false"
                            class="mx-auto"
                            max-width="300"
                            raised
                          >
                            <v-list
                              v-if="projectData.project_managers.length > 3"
                              disabled
                              shaped
                            >
                              <v-list-item-group
                                v-model="projectData.project_managers"
                              >
                                <v-list-item
                                  v-for="projectManager in projectData.project_managers.slice(3,projectData.project_managers.length)"
                                  v-show="!false"
                                  :key="projectManager.user_id"
                                >
                                  <v-avatar
                                    :color="`${randomColors()}`"
                                    size="30"
                                    style="padding:4px"
                                  >
                                    <strong class="white--text headline">{{ avatarNames(projectManager.user.display_name) }}</strong>
                                  </v-avatar>
                                  <v-list-item-content class="ml-2">
                                    <v-list-item-title v-text="projectManager.user.display_name" />
                                  </v-list-item-content>
                                </v-list-item>
                              </v-list-item-group>
                            </v-list>
                          </v-card>
                        </v-menu>
                      </div>
                      <v-row>
                        <v-col cols="12">
                          <v-btn to="/project-dashboard" depressed class="doneBtn">
                            Done
                          </v-btn>
                        </v-col>
                      </v-row>
                    </v-card>
                  </v-col>
                </v-row>
              </v-card>
            </template>
          </div>

        </v-stepper>
      </ValidationObserver>
    </template>
  </div>
</template>

<script>
import Vue from 'vue'
import VueScrollTo from 'vue-scrollto'
import { mapActions, mapGetters } from 'vuex'
import Dialog from '@/components/Dialog.vue'
import CommonSnackbar from '@/components/CommonSnackbar'
import constant from '@/constants/closure-checklist.js'
import CountryData from '@/configs/countryData.js'
import { projectHelpers } from '@/helpers/helper.js'
Vue.use(CountryData)
Vue.use(VueScrollTo)

export default {
  name: 'Index',
  layout: 'authenticated',
  middleware: 'authenticated',
  components: {
    CommonSnackbar,
    Dialog
  },
  data () {
    return {
      reg: /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,24}))$/,
      openProjectManagerList: false,
      openAccountManagerList: false,
      openProjectDomainList: false,
      openProjectClientList: false,
      openProjectAMList: false,
      openProjectPMList: false,
      openProjectTechList: false,
      clientName:'',
      clientEmail:'',
      companyName: '',
      companyState: '',
      companyCountry: '',
      validateClientDetails: false,
      errorMsg: '',
      country: '',
      clientDetails: [],
      searchClients: null,
      selectedClients: [],
      companyAddress: '',
      newCountryData: CountryData,
      newStateData: [],
      selectedDomains: [],
      subProject: false,
      subProjectId: null,
      searchTech: '',
      searchAm: '',
      searchPm: '',
      snackbarValue: false,
      submitted: false,
      snackbarText: '',
      projectName: '',
      approvedHours: '',
      maximumHoursBilled: '',
      billingType: 1,
      projectDomain: [],
      projectTypeId: null,
      projectLifeCycleModel: null,
      billingIntervalArray: [{ name: 'Weekly', value: 0 }, { name: 'Monthly', value: 1 }, { name: 'Fortnightly', value: 2 }],
      billingInterval: null,
      governanceCategoryId: null,
      max: 0,
      model: 'Foobar',
      selected: [],
      otherComponents: '',
      selectedTechnologies: [],
      selectedManager: [],
      selectedProjectManager: [],
      items: ['foo', 'bar', 'fizz', 'buzz'],
      value: ['foo', 'bar', 'fizz', 'buzz'],
      projectDocuments: [
        {
          link: ''
        }
      ],
      searchDomain: null,
      domainNameArray: [],
      techNameArray: [],
      fab: false,
      datePicker: [new Date().toISOString().substr(0, 10), this.getInitialEndDate().formattedStringDate],
      TimelineMenu: false,
      fromTimelineDateString: null,
      toTimelineDateString: null,
      totalDays: '',
      dates: '',
      menu: '',
      projectData: null,
      submitType: 'Saved',
      toTimelineDatePicker: '',
      fromTimelineDatePicker: '',
      generalDetailTab: 1,
      clientDetailTab: 2,
      timelineTab: 3,
      projectComponentTab: 4,
      e6: 1,
      Step1Error: false,
      Step2Error: false,
      Step3Error: false,
      Step4Error: false,
      customStep1Message: '',
      customStep2Message: '',
      customStep3Message: '',
      customStep4Message: '',
      listData:{},
      billingMediumId:null,
      projectSummary:''
    }
  },
  computed: {
    ...mapGetters({
      technologies: 'project/getTechnologies',
      departments: 'project/getDepartments',
      billingTypes: 'project/getBillingTypes',
      users: 'project/getUserList',
      isButtonLoading: 'project/isButtonLoading',
      getCustomDialog: 'project/getCustomDialog',
      getProjectDomains: 'project/getProjectDomains',
      projectTypes: 'project/getProjectType',
      governanceCategories: 'project/getGovernanceCategories',
      getProjectNameListing: 'project/getProjectNameListing',
      getRedminProjectNameList: 'project/getRedminProjectNameList',
      getProjectLifeCycleModel: 'project/getProjectLifeCycleModel',
      getProjectClients: 'project/getProjectClients',
      getAddedClient: 'project/getAddedClient',
      getCreatedDraftProject: 'project/getCreatedDraftProject',
      getCreatedProject: 'project/getCreatedProject',
      billingMediums: 'project/getBillingMediums'
    }),
    cardImg () {
      return require('@/assets/images/custom/card.png')
    },
    stepOne () {
      return require('@/assets/images/custom/progress1.png')
    },
    stepTwo () {
      return require('@/assets/images/custom/progress2.png')
    },
    stepThree () {
      return require('@/assets/images/custom/progress3.png')
    },
    stepfour () {
      return require('@/assets/images/custom/progress4.png')
    },
    saveInDraft () {
      return require('@/assets/images/dashboard/save-in-drafts.png')
    }
  },
  watch: {
    selectedDomains () {
      this.selectedDomainData = []
      this.selectedDomains.forEach((id) => {
        const domains = this.getProjectDomains.filter((item) => { return item.id === id })

        this.selectedDomainData.push(domains[0])
      })
    },
    selectedTechnologies () {
      this.selectedTechData = []
      this.selectedTechnologies.forEach((id) => {
        const tech = this.technologies.filter((item) => { return item.id === id })

        this.selectedTechData.push(tech[0])
      })
    },
    selectedProjectManager () {
      this.selectedPMData = []
      this.selectedProjectManager.forEach((id) => {
        const tech = this.users.filter((item) => { return item.id === id })

        this.selectedPMData.push(tech[0])
      })
      this.checkCompleteStep(4)
    },
    selectedManager () {
      this.selectedAMData = []
      this.selectedManager.forEach((id) => {
        const tech = this.users.filter((item) => { return item.id === id })

        this.selectedAMData.push(tech[0])
      })
      this.checkCompleteStep(4)
    },
    selectedClients () {
      this.selectedClientsData = []
      this.selectedClients.forEach((id) => {
        const tech = this.getProjectClients.filter((item) => { return item.id === id })

        this.selectedClientsData.push(tech[0])
      })
    }
  },
  async fetch ({ app, store }) {
    // eslint-disable-next-line no-useless-catch
    try {
      await Promise.all([
        store.dispatch('project/fetchProjectDomains'),
        store.dispatch('project/fetchTechnologies'),
        store.dispatch('project/fetchProjectNameListing'),
        store.dispatch('project/fetchRedmineProjectNameListing'),
        store.dispatch('project/fetchProjectLifeCycleModel'),
        store.dispatch('project/fetchProjectClients'),
        store.dispatch('project/fetchBillingTypes')
      ])
    } catch (error) {
      throw (error)
    }
  },
  mounted () {
    this.getProjectDomains.forEach((item) => {
      this.domainNameArray.push(item.name)
    })
    this.technologies.forEach((item) => {
      this.techNameArray.push(item.name)
    })
    this.listData.openProjectDomainList = this.openProjectDomainList
    this.listData.openProjectClientList = this.openProjectClientList
    this.listData.openProjectAMList = this.openProjectAMList
    this.listData.openProjectPMList = this.openProjectPMList
    this.listData.openProjectTechList = this.openProjectTechList
  },
  methods: {
    ...mapActions({
      setCreatedProjectData: 'project/setCreatedProjectData',
      setCreatedDraftProjectData: 'project/setCreatedDraftProjectData',
      setCustomDialog: 'project/setCustomDialog',
      updateLoadingAction: 'project/updateLoadingAction',
      createProjectDomain: 'project/createProjectDomain',
      createTechnologies: 'project/createTechnologies',
      fetchTechnologies: 'project/fetchTechnologies',
      createProjectClient: 'project/createProjectClient'
    }),
    validateField () {
      if (this.selectedClients.length > 0) {
        this.errorMsg = ''
        this.validateClientDetails = false
      } else {
        this.errorMsg = 'This field is required'
        this.validateClientDetails = true
      }
    },
    onScroll (e) {
      if (typeof window === 'undefined') {
        return
      }
      const top = window.pageYOffset || e.target.scrollTop || 0

      this.fab = top > 20
    },
    toTop () {
      this.$vuetify.goTo(0)
    },
    setResignValues () {
      this.newStateData = projectHelpers.setResignArray(this.newCountryData, this.companyCountry)
      if (!this.companyCountry) {
        this.newStateData = []
      }
      this.companyState = ''
    },
    changeTimelineFromDateString (selected) {
      let { startRange, endRange } = selected

      if (selected[0] > selected[1]) {
        endRange = selected[0]
        startRange = selected[1]
      } else {
        endRange = selected[1]
        startRange = selected[0]
      }
      this.fromTimelineDateString = new Date(startRange).toLocaleDateString({
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      })
      this.toTimelineDateString = new Date(endRange).toLocaleDateString({
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      })
      let dateRange = []

      this.fromTimelineDatePicker = projectHelpers.formatDate(startRange)
      this.toTimelineDatePicker = projectHelpers.formatDate(endRange)
      dateRange = [this.fromTimelineDateString, this.toTimelineDateString]
      this.dates = dateRange.join(' - ')
      this.totalDays = projectHelpers.totalDays(new Date(startRange), new Date(endRange))

      return this.dates
    },
    checkCompleteStep (step) {
      const projectNameVal = projectHelpers.validateSectionValues(this.projectName)
      const projectSummaryVal = projectHelpers.validateSectionValuesLineBreak(this.projectSummary)
      const companyNameVal = projectHelpers.validateSectionValues(this.companyName)
      const companyAddressVal = projectHelpers.validateSectionValuesLineBreak(this.companyAddress)
      const approvedHoursVal = projectHelpers.validateSectionValues(this.approvedHours)
      const maximumHoursBilledVal = projectHelpers.validateSectionValues(this.maximumHoursBilled)

      let projectDocumentsVal = true
      let flag = false

      if (this.projectDocuments[0].link !== '') {

        this.projectDocuments.forEach((item) => {
          if (item.link !== '') {
            const docVal = projectHelpers.validateSectionValues(item.link)

            if (docVal === false) {
              flag = true // flag is true if validation fails
            }
          } else {
            flag = true
          }
        })
      } else {
        flag = true
      }

      //check if flag true
      if (flag === true) {
        projectDocumentsVal = false
      }

      if (step === 1) {
        if (this.projectTypeId === undefined) {
          this.projectTypeId = null
        }
        if (this.projectLifeCycleModel === undefined) {
          this.projectLifeCycleModel = null
        }
        if (this.governanceCategoryId === undefined) {
          this.governanceCategoryId = null
        }

        let subProjectValidation = false

        if (this.subProject) {

          subProjectValidation = (this.subProjectId === null) ? true : false
        }

        if (projectNameVal  === false || projectSummaryVal  === false || this.projectTypeId === null || this.projectLifeCycleModel === null || this.selectedDomains.length === 0  || this.governanceCategoryId === null || subProjectValidation === true) {
          this.Step1Error = true
          this.customStep1Message = 'error'

        } else {
          this.Step1Error = false
          this.customStep1Message = 'success'

        }
        if (this.billingType === constant.BILLING_TYPE.INTERNAL || this.billingType === constant.BILLING_TYPE.POC) {
          this.e6 = this.timelineTab
        } else {
          this.e6 = this.clientDetailTab
        }
      }
      else if (step === 2) {
        if (this.companyState === undefined || this.companyState === null) {
          this.companyState = ''
        }
        if (this.companyCountry === undefined || this.companyCountry === null) {
          this.companyCountry = ''
        }
        if (companyNameVal === false || companyAddressVal === false || this.companyState === '' || this.companyCountry === '' || this.selectedClients.length === 0) {
          this.Step2Error = true
          this.customStep2Message = 'error'
        } else {
          this.Step2Error = false
          this.customStep2Message = 'success'
        }
        this.e6 = this.timelineTab
      }
      else if (step === 3) {

        let billingIntervalCheck = true

        if (this.billingInterval === undefined) {
          this.billingInterval = null
        }
        if (this.billingType === 1 || this.billingType === 2 || this.billingType === 3) {
          billingIntervalCheck = false
          if (this.billingInterval !== null) {
            billingIntervalCheck = true
          }
        } else {
          billingIntervalCheck = true
        }

        let hoursCheck = false

        if (this.billingType === 1) {
          hoursCheck = approvedHoursVal
        } else {
          hoursCheck = maximumHoursBilledVal
        }
        if (this.fromTimelineDateString === null || this.toTimelineDateString === null || hoursCheck === false || billingIntervalCheck === false) {
          this.Step3Error = true
          this.customStep3Message = 'error'
        } else {
          this.Step3Error = false
          this.customStep3Message = 'success'
        }
        this.e6 = this.projectComponentTab
      }
      else if (step === 4) {
        let projectComponents = false

        if (this.selected.length === 0) {
          projectComponents = true
        }
        if (this.selected.includes('other')) {
          const otherVal = projectHelpers.validateSectionValues(this.otherComponents)

          if (otherVal === false) {
            projectComponents = true  //invalid other value
          }
        }

        if (this.selectedTechnologies.length === 0 || this.selectedProjectManager.length === 0 || this.selectedManager.length === 0 || projectComponents === true || projectDocumentsVal === false) {

          this.Step4Error = true
          this.customStep4Message = 'error'
        } else {
          this.Step4Error = false
          this.customStep4Message = 'success'
        }
      }
    },
    setTabValues (id) {
      if (id === constant.BILLING_TYPE.INTERNAL || id === constant.BILLING_TYPE.POC) {
        this.clientDetailTab = 0
        this.timelineTab = 2
        this.projectComponentTab = 3
      } else {
        this.clientDetailTab = 2
        this.timelineTab = 3
        this.projectComponentTab = 4
      }
    },
    addMoreProjectDocsField () {
      if (this.projectDocuments.length >= 5) {
        this.snackbarValue = true
        this.snackbarText = 'Cannot add more than 5 documents.'

        return
      }
      this.projectDocuments.push({ link: '' })
    },
    removeDocumentsLink (index) {
      this.projectDocuments.splice(index - 1, 1)
    },
    getInitialEndDate () {
      const endDate = new Date()
      const formattedDate = endDate.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })
      const formattedStringDate = endDate.toISOString().substr(0, 10)

      return { formattedDate, formattedStringDate }
    },
    clearOtherComponent () {
      if (this.selected !== 'other') {
        this.otherComponents = ''
      }
    },
    async saveDraft () {
      await this.updateLoadingAction()
      const selectedDomainIds = []
      const projectNameExist = this.getProjectNameListing.some((item) => item.project_name.toLowerCase() === this.projectName.toLowerCase())

      if (projectNameExist) {
        this.snackbarText = 'Project Name Already Exists !!'
        this.snackbarValue = true
        setTimeout(() => {
          this.snackbarValue = false
        }, 3000)

        return
      }
      this.selectedDomains.forEach((item) => (Number.isInteger(item)) ? selectedDomainIds.push(item) : selectedDomainIds.push(item.id))
      let approvedHrs = null
      let maxHrs = null

      if (this.billingType === constant.BILLING_TYPE.FIXED_COST) {
        approvedHrs = this.approvedHours
      } else {
        maxHrs = this.maximumHoursBilled
      }

      //set client details
      const data = projectHelpers.setClientDetails(this.billingType, this.getProjectClients, this.selectedClients, this.companyName, this.companyAddress, this.companyState, this.companyCountry)

      this.companyName = data.companyName
      this.companyAddress = data.companyAddress
      this.clientDetails = data.clientDetails
      this.companyState = data.companyState
      this.companyCountry = data.companyCountry

      this.checkCompleteStep(1)
      this.checkCompleteStep(2)
      this.checkCompleteStep(3)
      this.checkCompleteStep(4)
      const requestData = {
        'project_name': this.projectName,
        'company_name': this.companyName,
        'company_address': this.companyAddress,
        'project_domain': selectedDomainIds,
        'billing_type': this.billingType,
        'approved_hours': approvedHrs,
        'project_components': this.otherComponents && this.selected.includes('other') ? [...this.selected, this.otherComponents] : this.selected,
        'maximum_hours_billed': maxHrs,
        'initiation_date': this.toDatePicker,
        'estimated_timeline_to': this.toTimelineDatePicker,
        'estimated_timeline_from': this.fromTimelineDatePicker,
        'project_documents_link': this.projectDocuments,
        'client_detail': this.clientDetails,
        'account_manager_id': this.selectedManager,
        'project_manager_id': this.selectedProjectManager,
        'technologies': this.selectedTechnologies,
        'project_type_id': (this.projectTypeId) ? this.projectTypeId : null,
        'gov_category_id': (this.governanceCategoryId) ? this.governanceCategoryId : null,
        'subProject': this.subProject,
        'parent_id': this.subProjectId,
        'lifecycle_model_id': this.projectLifeCycleModel,
        'billingInterval': this.billingInterval,
        'companyState': this.companyState,
        'companyCountry': this.companyCountry,
        'project_id': null,
        'createInitiation': true,
        'billing_medium': (this.billingMediumId) ? this.billingMediumId : null,
        'project_summary' : this.projectSummary
      }

      await this.setCreatedDraftProjectData(requestData)
      this.projectData = this.getCreatedDraftProject
      this.projectData.openProjectManagerList = this.openProjectManagerList
      this.projectData.openAccountManagerList = this.openAccountManagerList
      this.submitType = 'Draft'
      this.updateLoadingAction()
      this.submitted = true
      this.e6 = 5
    },
    async submit () {
      await this.updateLoadingAction()
      const selectedDomainIds = []
      const projectNameExist = this.getProjectNameListing.some((item) => item.project_name.toLowerCase() === this.projectName.toLowerCase())

      if (projectNameExist) {
        this.snackbarText = 'Project Name Already Exists !!'
        this.snackbarValue = true
        setTimeout(() => {
          this.snackbarValue = false
        }, 3000)

        return
      }
      this.selectedDomains.forEach((item) => (Number.isInteger(item)) ? selectedDomainIds.push(item) : selectedDomainIds.push(item.id))
      let approvedHrs = null
      let maxHrs = null

      if (this.billingType === constant.BILLING_TYPE.FIXED_COST) {
        approvedHrs = this.approvedHours
      } else {
        maxHrs = this.maximumHoursBilled
      }

      //set client details
      const data = projectHelpers.setClientDetails(this.billingType, this.getProjectClients, this.selectedClients, this.companyName, this.companyAddress, this.companyState, this.companyCountry)

      this.companyName = data.companyName
      this.companyAddress = data.companyAddress
      this.clientDetails = data.clientDetails
      this.companyState = data.companyState
      this.companyCountry = data.companyCountry
      this.checkCompleteStep(1)
      this.checkCompleteStep(2)
      this.checkCompleteStep(3)
      this.checkCompleteStep(4)
      const requestData = {
        'project_name': this.projectName,
        'company_name': this.companyName,
        'company_address': this.companyAddress,
        'project_domain': selectedDomainIds,
        'billing_type': this.billingType,
        'approved_hours': approvedHrs,
        'project_components': this.otherComponents && this.selected.includes('other') ? [...this.selected, this.otherComponents] : this.selected,
        'maximum_hours_billed': maxHrs,
        'initiation_date': this.toDatePicker,
        'estimated_timeline_to': this.toTimelineDatePicker,
        'estimated_timeline_from': this.fromTimelineDatePicker,
        'project_documents_link': this.projectDocuments,
        'client_detail': this.clientDetails,
        'account_manager_id': this.selectedManager,
        'project_manager_id': this.selectedProjectManager,
        'technologies': this.selectedTechnologies,
        'project_type_id': (this.projectTypeId) ? this.projectTypeId : null,
        'gov_category_id': (this.governanceCategoryId) ? this.governanceCategoryId : null,
        'subProject': this.subProject,
        'parent_id': this.subProjectId,
        'lifecycle_model_id': this.projectLifeCycleModel,
        'billingInterval': this.billingInterval,
        'companyState': this.companyState,
        'companyCountry': this.companyCountry,
        'project_id': null,
        'createInitiation': true,
        'billing_medium': (this.billingMediumId) ? this.billingMediumId : null,
        'project_summary' : this.projectSummary
      }

      await this.setCreatedProjectData(requestData)

      this.projectData = this.getCreatedProject
      this.projectData.openProjectManagerList = this.openProjectManagerList
      this.projectData.openAccountManagerList = this.openAccountManagerList
      this.updateLoadingAction()
      this.submitted = true
      this.e6 = 5
    },

    async createMoreClientDetails () {

      const validValue = projectHelpers.alphaNumSpecialValidation(this.clientName)
      const clientvalidValue = projectHelpers.alphaNumSpecialValidation(this.clientEmail)

      if (!validValue) {
        this.snackbarText = 'Client Name value must be word, digit, whitespace and special characters'
        this.snackbarValue = true
        setTimeout(() => {
          this.snackbarValue = false
        }, 3000)
      } else {
        const result = this.getProjectClients.filter((item) => {
          if (item['name'] === this.clientName || item['emails'] === this.clientEmail ) {
            return item
          }
        })

        if (!this.reg.test(this.clientEmail) || clientvalidValue === false) {
          this.snackbarText = 'Email Address Not Valid !!'
          this.snackbarValue = true
          setTimeout(() => {
            this.snackbarValue = false
          }, 3000)
        } else {
          if (result.length > 0) {
            this.snackbarText = 'Client Already Exists !!'
            this.snackbarValue = true
            setTimeout(() => {
              this.snackbarValue = false
            }, 3000)
          } else {
            await this.updateLoadingAction()
            const requestData = {
              'name': this.clientName,
              'email': this.clientEmail
            }

            await this.createProjectClient(requestData)
            this.selectedClients.push(this.getAddedClient.id)
            if (this.selectedClients.length > 0) {
              this.validateClientDetails = false
              this.errorMsg = ''
            }
            this.clientName = ''
            this.clientEmail = ''
            this.updateLoadingAction()
          }
        }
      }
    },

    removeItemFromArray (item, searchString) {
      this.$data[searchString] = this.$data[searchString].filter((arrayItem) => arrayItem !== item.id)
      this.$data[searchString] = [...this.$data[searchString]]
    },
    filter (item, queryText, itemText) {
      const hasValue = (val) => val !== null ? val : ''
      const text = hasValue(itemText)
      const query = hasValue(queryText)

      return text.toString()
        .toLowerCase()
        .includes(query.toString().toLowerCase())
    },
    async submitNewDomain (domainName) {
      if (domainName !== null && domainName !== '' && !this.domainNameArray.includes(domainName)) {
        await this.createProjectDomain({ domainName })
        const createdDomain = this.getProjectDomains.filter((item) => item.name === domainName)

        this.selectedDomains = this.selectedDomains.concat(createdDomain)
        this.searchDomain = ''
        this.snackbarText = this.getCustomDialog.message
        this.snackbarValue = true
        this.domainNameArray = []
        this.getProjectDomains.forEach((item) => {
          this.domainNameArray.push(item.name)
        })
        setTimeout(() => {
          this.snackbarValue = false
        }, 3000)
      }
    },
    async createNewDomain (domainName) {
      const existingRecord = this.getProjectDomains.filter((item) => item.name === domainName)

      const validValue = projectHelpers.alphaNumSpecialValidation(domainName)

      if (!validValue) {
        this.snackbarText = 'This value must be word, digit, whitespace and special characters'
        this.snackbarValue = true
        setTimeout(() => {
          this.snackbarValue = false
        }, 3000)
      } else {
        if (existingRecord.length > 0) {
          this.snackbarText = 'Domain name is duplicate please try a different name!'
          this.snackbarValue = true
          setTimeout(() => {
            this.snackbarValue = false
          }, 3000)
        } else {
          await this.createProjectDomain({ domainName })
          const createdDomain = this.getProjectDomains.filter((item) => item.name === domainName)

          this.selectedDomains = this.selectedDomains.concat(createdDomain)
          this.searchDomain = ''
          this.snackbarText = this.getCustomDialog.message
          this.snackbarValue = true
          this.domainNameArray = []
          this.getProjectDomains.forEach((item) => {
            this.domainNameArray.push(item.name)
          })
          setTimeout(() => {
            this.snackbarValue = false
          }, 3000)
        }
      }

    },
    async submitNewTech (techName) {
      if (techName !== null && techName !== '' && this.techNameArray.findIndex((item) => ((techName) ? techName.toLowerCase() : techName) === ((item) ? item.toLowerCase() : item)) < 0) {
        await this.createTechnologies({ techName })
        if (this.fetchTechnologies()) {
          let techId = []

          this.technologies.filter((item) => {
            if (item.name === techName) {
              techId = item.id
            }
          })
          this.selectedTechnologies = this.selectedTechnologies.concat(techId)
          this.searchTech = ''
          this.snackbarText = this.getCustomDialog.message
          this.snackbarValue = true
          this.techNameArray = []
          this.technologies.forEach((item) => {
            this.techNameArray.push(item.name)
          })
          setTimeout(() => {
            this.snackbarValue = false
          }, 3000)
        }
      }
    },
    async createNewTech (techName) {

      const validValue = projectHelpers.alphaNumSpecialValidation(techName)

      if (!validValue) {
        this.snackbarText = 'This value must be word, digit, whitespace and special characters'
        this.snackbarValue = true
        setTimeout(() => {
          this.snackbarValue = false
        }, 3000)
      } else {
        const existingRecord = this.technologies.filter((item) => item.name === techName)

        if (existingRecord.length > 0) {
          this.snackbarText = 'Technology name is duplicate please try a different name!'
          this.snackbarValue = true
          setTimeout(() => {
            this.snackbarValue = false
          }, 3000)
        } else {
          await this.createTechnologies({ techName })
          if (this.fetchTechnologies()) {
            let techId = []

            this.technologies.filter((item) => {
              if (item.name === techName) {
                techId = item.id
              }
            })
            this.selectedTechnologies = this.selectedTechnologies.concat(techId)
            this.searchTech = ''
            this.snackbarText = this.getCustomDialog.message
            this.snackbarValue = true
            this.techNameArray = []
            this.technologies.forEach((item) => {
              this.techNameArray.push(item.name)
            })
            setTimeout(() => {
              this.snackbarValue = false
            }, 3000)
          }
        }
      }
    },

    randomColors () {
      return projectHelpers.randomColors()
    },
    avatarNames (fullName) {
      return projectHelpers.avatarNames(fullName)
    }
  }
}
</script>

<style scoped>

>>>.v-input--selection-controls .v-input__slot > .v-label, .v-input--selection-controls .v-radio >>> .v-label {
    flex: none !important;
 }
>>>.v-select.v-text-field input {
    flex: auto !important;
}
>>>.v-select.v-text-field input {
  flex: inherit !important;
}
>>>.v-input input {
  font-size: 14px !important;
}
.rootContainer {
  width: -webkit-fill-available !important;
  height: 100%;
  max-width: 100%;
  padding-left: 0px !important;
  padding-right: 0px !important;
}
.headingRow {
  background-color: white;
  margin-bottom: 10px;
}
.grayColor {
  color: gray;
}
>>> .mdi-file {
  font-size: 20px !important;
}
.navigationButton {
  min-width: 22% !important;
}
.field {
  padding-bottom: 5px;
}
.billingDiv {
  border:1px solid gray;
  padding:2px;
  margin-left:8px;
  margin-bottom:8px;
}
>>>.v-input--selection-controls .v-radio[data-v-29e9c86c] .v-label {
  font-size: 14px !important;
}
.v-application .iconCol {
  padding-left: 0px;
}
.bg-blue {
  background-color: lightblue !important;
}
>>>.v-chip.v-size--default {
    border-radius: 6px;
    font-size: 12px;
    height: 27px;
}
>>>.v-chip-group .v-chip {
    margin: 4px 3px 4px 3px !important;
}
.m-b-0 {
    margin-bottom: 0px!important;
}
.p-b-0 {
    padding-top: 0px!important;
    padding-bottom: 0px !important;
}
.theme--light.v-stepper {
    background: #f3f4f7;
}
.btn-color {
    background-color: #1976d2!important;
    color: #ffffff!important;
}

</style>
