<template>
  <div>
    <Dialog />
    <v-card>
      <v-col cols="12" class="pt-0 pb-0">
        <project-operation :project-details="projects" :selected-project-name="projectDetail.uuid" :project-action-selected="projectActionSelected"/>
      </v-col>
      <ValidationObserver ref="holdRequestObserver" v-slot="{ valid }">
        <v-card-text>
          <v-row>
            <v-col cols="12" md="6">
              <v-text-field
                v-model="projectName"
                :class="{'v-text-field__slot' : projectName}"
                label="Project Name"
                disabled
              />
            </v-col>
            <v-col cols="12" md="6">
              <v-text-field
                v-model="projectStatus"
                :class="{'v-text-field__slot' : projectStatus}"
                label="Project Status"
                disabled
              />
            </v-col>
          </v-row>
          <v-row>
            <v-col cols="12" md="12">
              <ValidationProvider v-slot="{ errors }" :rules="'required'" name="comment">
                <v-textarea
                  v-model.trim="comment"
                  :error-messages="errors"
                  auto-grow
                  label="Reason for Project On Hold *"
                  rows="1"
                />
              </ValidationProvider>
            </v-col>
          </v-row>
          <v-row>
            <v-col
              cols="12"
              md="4"
            >
              <v-card flat>
                <v-menu
                  ref="fromTimelineMenu"
                  v-model="fromTimelineMenu"
                  :close-on-content-click="false"
                  offset-y
                  transition="scale-transition"
                >
                  <template v-slot:activator="{ on }">
                    <v-text-field
                      :value="new Date(fromTimelineDatePicker).toLocaleDateString('en-US', {
                        year: 'numeric',
                        month: 'short',
                        day: 'numeric'
                      })"
                      label="Estimated Timeline (From)"
                      prepend-icon="mdi-calendar"
                      readonly
                      v-on="on"
                    />
                  </template>
                  <v-col cols="12" class="pa-0">
                    <v-date-picker v-model="fromTimelineDatePicker" :min="currentDateString" @change="changeTimelineFromDateString" @input="fromTimelineMenu = false" />
                  </v-col>
                </v-menu>
              </v-card>
            </v-col>
            <v-col
              cols="12"
              md="4"
            >
              <v-card flat>
                <v-menu
                  ref="toTimelineMenu"
                  v-model="toTimelineMenu"
                  :close-on-content-click="false"
                  offset-y
                  transition="scale-transition"
                >
                  <template v-slot:activator="{ on }">
                    <v-text-field
                      :value="new Date(toTimelineDatePicker).toLocaleDateString('en-US', {
                        year: 'numeric',
                        month: 'short',
                        day: 'numeric'
                      })"
                      label="Estimated Timeline (To)"
                      prepend-icon="mdi-calendar"
                      readonly
                      v-on="on"
                    />
                  </template>
                  <v-col cols="12" class="pa-0">
                    <v-date-picker
                      v-model="toTimelineDatePicker"
                      :min="fromTimelineDatePicker"
                      @change="changeTimelineToDateString"
                      @input="toTimelineMenu = false"
                    />
                  </v-col>
                </v-menu>
              </v-card>
            </v-col>
            <v-col
              cols="12"
              md="4"
            >
              <v-text-field
                v-model="currentUser.username"
                :class="{'v-text-field__slot' : currentUser.username}"
                label="Requested By"
                disabled
              />
            </v-col>
          </v-row>
          <v-row align="end" justify="end">
            <v-col v-if="!valid" cols="12">
              <v-btn
                class="text-capitalize ma-2 white--text"
                color="blue-grey"
                @click="$router.push('/project-dashboard')"
              >
                <v-icon dark left>
                  mdi-arrow-left
                </v-icon>Back
              </v-btn>
              <v-btn :disabled="!valid" class="text-capitalize" color="primary" @click="submit">
                Submit
              </v-btn>
            </v-col>
            <v-col v-else cols="12">
              <v-btn
                class="text-capitalize ma-2 white--text"
                color="blue-grey"
                @click="$router.push('/project-dashboard')"
              >
                <v-icon dark left>
                  mdi-arrow-left
                </v-icon>Back
              </v-btn>
              <v-btn :disabled="submitted" class="text-capitalize" color="primary" @click="submit">
                Submit
              </v-btn>
            </v-col>
          </v-row>
        </v-card-text>
      </ValidationObserver>
    </v-card>
  </div>
</template>

<script>
import { mapActions, mapGetters } from 'vuex'
import ProjectOperation from '@/components/ProjectOperation'
import Dialog from '@/components/Dialog.vue'
export default {
  name: 'HoldRequest',
  layout: 'authenticated',
  middleware: 'authenticated',
  components: {
    Dialog,
    ProjectOperation
  },
  data () {
    return {
      projectName: '',
      projectStatus: 'In progress',
      comment: '',
      toTimelineDatePicker: '',
      toTimelineMenu: false,
      toTimelineDateString: '',
      fromTimelineDatePicker: '',
      fromTimelineMenu: false,
      fromTimelineDateString: '',
      submitted: false,
      currentDateString: null,
      projectActionSelected: 'hold-request'
    }
  },
  computed: {
    ...mapGetters({
      projectDetail: 'project/getProjectDetail',
      technologies: 'project/getTechnologies',
      departments: 'project/getDepartments',
      projects: 'project/getProjectList',
      users: 'project/getUserList',
      currentUser: 'auth/user',
      isButtonLoading: 'project/isButtonLoading'
    })
  },
  async fetch ({ app, store, route }) {
  // eslint-disable-next-line no-useless-catch
    try {
      await Promise.all([
        store.dispatch('project/fetchProjectList'),
        store.dispatch('project/fetchProjectDetail', route.params.id)
      ])
    } catch (error) {
      throw (error)
    }
  },
  mounted () {
    this.$nuxt.$emit('headerTitle', 'Project On Hold Request')
    let today = new Date()
    const dd = String(today.getDate()).padStart(2, '0')
    const mm = String(today.getMonth() + 1).padStart(2, '0')
    const yyyy = today.getFullYear()

    today = yyyy + '-' + mm + '-' + dd
    this.currentDateString = today
    this.projectName = this.projectDetail.project_name
    if (this.projectDetail.status === 1) {
      this.projectStatus = 'New'
    }
    const currentDate = new Date()
    const timelineFrom = new Date(this.projectDetail.estimated_timeline_from)

    if (this.projectDetail.estimated_timeline_from && timelineFrom.getTime() >= currentDate.getTime()) {
      this.fromTimelineDatePicker = this.projectDetail.estimated_timeline_from
    } else {
      this.fromTimelineDatePicker = new Date().toISOString().substr(0, 10)
    }
    const fromDate = new Date(this.fromTimelineDatePicker)

    this.fromTimelineDateString = fromDate.toISOString().substr(0, 10)
    const timelineTo = new Date(this.projectDetail.estimated_timeline_to)

    if (this.projectDetail.estimated_timeline_to && timelineTo.getTime() >= timelineFrom.getTime()) {
      this.toTimelineDatePicker = this.projectDetail.estimated_timeline_to
    } else if (timelineFrom.getTime() > currentDate.getTime()) {
      this.toTimelineDatePicker = this.fromTimelineDateString
    } else {
      this.toTimelineDatePicker = new Date().toISOString().substr(0, 10)
    }
    if (this.toTimelineDatePicker < this.fromTimelineDatePicker) {
      this.toTimelineDatePicker = this.fromTimelineDatePicker
    }
    const toDate = new Date(this.toTimelineDatePicker)

    this.toTimelineDateString = toDate.toISOString().substr(0, 10)
  },
  methods: {
    ...mapActions({
      setCreatedProjectData: 'project/setCreatedProjectData',
      addProjectOnHoldRequest: 'project/addProjectOnHoldRequest',
      setCustomDialog: 'project/setCustomDialog',
      updateLoadingAction: 'project/updateLoadingAction'
    }),
    changeTimelineToDateString (selected) {
      this.toTimelineDateString = new Date(selected).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      })
    },
    changeTimelineFromDateString (selected) {
      this.fromTimelineDateString = new Date(selected).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      })
      const fromDateString = new Date(this.fromTimelineDatePicker)
      const toDateString = new Date(this.toTimelineDatePicker)

      if (fromDateString.getTime() > toDateString.getTime()) {
        this.toTimelineDatePicker = this.fromTimelineDatePicker
        this.toTimelineDateString = this.fromTimelineDateString
      }
    },
    async submit () {
      this.updateLoadingAction()
      const requestData = {
        'project_id': this.$route.params.id,
        'to': this.toTimelineDatePicker,
        'from': this.fromTimelineDatePicker,
        'reason': this.comment,
        'status_id': 11
      }

      await this.addProjectOnHoldRequest(requestData)
      this.updateLoadingAction()
      this.submitted = true
    }
  }
}
</script>

<style scoped>
.v-text-field__slot >>> .theme--light.v-label--is-disabled {
   color: rgba(0, 0, 0, 0.6);
   font-size: 18px
}
.v-picker--date {
  width: 100%
}
.container {
    max-width: 1250px;
}
</style>
