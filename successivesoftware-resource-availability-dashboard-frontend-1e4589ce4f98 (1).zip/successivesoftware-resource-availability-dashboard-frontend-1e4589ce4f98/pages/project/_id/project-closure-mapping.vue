<template>
  <div>
    <Dialog />
    <common-snackbar :text-for-snackbar="snackbarText" :snackbar="snackbarValue" />
    <v-card
      class="mx-auto"
      max-width="100%"
    >
      <v-card-text>
        <v-row>
          <v-col cols="12" md="12">
            <v-stepper :value="e1">
              <v-stepper-header>
                <v-stepper-step :step="1" editable>
                  Project Management
                </v-stepper-step>
                <v-divider />
                <v-stepper-step :step="2" editable>
                  After Billing Confirmation
                </v-stepper-step>
                <v-divider />
                <v-stepper-step :step="3" editable>
                  Receiving from client
                </v-stepper-step>
              </v-stepper-header>
              <v-stepper-items>
                <ValidationObserver ref="obs" v-slot="{ valid }">
                  <v-stepper-content
                    :step="1"
                    class="pa-1 ma-2"
                  >
                    <v-row>
                      <v-col cols="2">
                        <v-row>
                          <v-col cols="4">
                            <b>N/A</b>
                          </v-col>
                          <v-col cols="8">
                            <b>Completed</b>
                          </v-col>
                        </v-row>
                      </v-col>
                      <v-col cols="10" />
                      <v-col cols="12">
                        <ValidationProvider
                          v-for="(projectManagementData, index) in projectManagement"
                          :key="index"
                          :vid="`project-${index}`"
                          rules="required"
                        >
                          <v-radio-group v-model="selectedProjectManagementChecklist[index]" row readonly>
                            <v-radio :id="index" label="" value="NA" />
                            <v-radio :label="projectManagementData" :value="index" />
                          </v-radio-group>
                        </ValidationProvider>
                      </v-col>
                    </v-row>
                    <v-btn :value="e1" class="text-capitalize" text @click="e1 = 2">
                      Next
                    </v-btn>
                  </v-stepper-content>
                  <v-stepper-content
                    :step="2"
                    class="pa-1 ma-2"
                  >
                    <v-row>
                      <v-col cols="2">
                        <v-row>
                          <v-col cols="4">
                            <b>N/A</b>
                          </v-col>
                          <v-col cols="8">
                            <b>Completed</b>
                          </v-col>
                        </v-row>
                      </v-col>
                      <v-col cols="10" />
                      <v-col cols="12">
                        <ValidationProvider
                          v-for="(postBillingData, index) in postBillingConfirmation"
                          :key="index"
                          :vid="`billing-${index}`"
                          rules="required"
                        >
                          <v-radio-group v-model="selectedPostBillingChecklist[index]" row readonly>
                            <v-radio :id="index" label="" value="NA" />
                            <v-radio :label="postBillingData" :value="index" />
                          </v-radio-group>
                        </ValidationProvider>
                      </v-col>
                    </v-row>
                    <v-btn :value="e1" class="text-capitalize" text @click="e1 = 3">
                      Next
                    </v-btn>
                    <v-btn :value="e1" class="text-capitalize" text @click="e1 = 1">
                      Back
                    </v-btn>
                  </v-stepper-content>
                  <v-stepper-content
                    :step="3"
                    class="pa-1 ma-2"
                  >
                    <v-row>
                      <v-col cols="2">
                        <v-row>
                          <v-col cols="4">
                            <b>N/A</b>
                          </v-col>
                          <v-col cols="8">
                            <b>Completed</b>
                          </v-col>
                        </v-row>
                      </v-col>
                      <v-col cols="10" />
                      <v-col cols="12">
                        <ValidationProvider
                          v-for="(receivingFromClientData, index) in receivingFromClient"
                          :key="index"
                          :vid="`receiving-${index}`"
                          rules="required"
                        >
                          <v-radio-group v-model="selectedReceivingChecklist[index]" row readonly>
                            <v-radio :id="index" label="" value="NA" />
                            <v-radio :label="receivingFromClientData" :value="index" />
                          </v-radio-group>
                        </ValidationProvider>
                      </v-col>
                    </v-row>
                    <v-col v-if="!valid" cols="12">
                      <v-btn
                        :disabled="!valid || projectCloseStatus"
                        :value="e1"
                        color="primary"
                        class="text-capitalize"
                        @click="submitChanges"
                      >
                        Submit
                      </v-btn>
                      <v-btn :value="e1" class="text-capitalize" text @click="e1 = 2">
                        Back
                      </v-btn>
                    </v-col>
                    <v-col v-else cols="12">
                      <v-btn
                        :disabled="submitted || projectCloseStatus"
                        :value="e1"
                        color="primary"
                        class="text-capitalize"
                        @click="submitChanges"
                      >
                        Submit
                      </v-btn>
                      <v-btn :value="e1" class="text-capitalize" text @click="e1 = 2">
                        Back
                      </v-btn>
                    </v-col>
                  </v-stepper-content>
                </ValidationObserver>
              </v-stepper-items>
            </v-stepper>
          </v-col>
        </v-row>
      </v-card-text>
    </v-card>
  </div>
</template>

<script>
import { mapActions, mapGetters } from 'vuex'
import constant from '@/constants/closure-checklist.js'
import CommonSnackbar from '@/components/CommonSnackbar.vue'
import Dialog from '@/components/Dialog.vue'
export default {
  name: 'ProjectClosure',
  layout: 'authenticated',
  middleware: 'authenticated',
  components: {
    CommonSnackbar,
    Dialog
  },
  data () {
    return {
      row: [],
      e1: 1,
      projectManagement: constant.PROJECT_MANAGEMENT,
      postBillingConfirmation: constant.POST_BILLING_CONFIRMATION,
      receivingFromClient: constant.RECEIVING_FROM_CLIENT,
      selectedProjectManagementChecklist: [],
      selectedPostBillingChecklist: [],
      selectedReceivingChecklist: [],
      projectName: '',
      snackbarValue: false,
      snackbarText: 'Closure checklist saved successfully.',
      submitted: false,
      projectCloseStatus: false

    }
  },
  computed: {
    ...mapGetters({
      getProjectClosureList: 'project/getProjectClosureList',
      isButtonLoading: 'project/isButtonLoading'
    })
  },
  async fetch ({ app, store, route }) {
  // eslint-disable-next-line no-useless-catch
    try {
      await store.dispatch('project/fetchProjectClosureChecklist', route.params.id)
    } catch (error) {
      throw (error)
    }
  },
  mounted () {
    this.$nuxt.$emit('headerTitle', 'Project Closure Mapping')
    this.selectedProjectManagementChecklist = [...this.getProjectClosureList.checkboxIds.projectManagement]
    this.selectedPostBillingChecklist = [...this.getProjectClosureList.checkboxIds.postBilling]
    this.selectedReceivingChecklist = [...this.getProjectClosureList.checkboxIds.clientReceiving]
    this.projectCloseStatus = this.getProjectClosureList.project_close_status
  },
  methods: {
    ...mapActions({
      setProjectCloseOnRedmine: 'project/setProjectCloseOnRedmine',
      updateLoadingAction: 'project/updateLoadingAction'
    }),
    async submitChanges () {
      this.updateLoadingAction()
      const id = this.getProjectClosureList.project_redmine_id

      await this.setProjectCloseOnRedmine(id)
      this.updateLoadingAction()
    }
  }
}
</script>

<style scoped>
>>>.v-input--selection-controls .v-radio >>> .v-label {
  flex: none !important;
}
.v-input--radio-group__input .v-radio >>> label {
  padding-left: 35px;
}
.container {
  max-width: 1250px;
}
</style>
