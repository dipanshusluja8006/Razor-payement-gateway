<template>
  <div>
    <Dialog />
    <confirm-dialog ref="confirm" />
    <common-snackbar :snackbar="snackbarValue" :text-for-snackbar="snackbarText" />
    <v-dialog
      v-model="validationDialog"
      :persistent="true"
    >
      <div class="successPopup">
        <div class="successImg">
          <v-img :src="popupImage" />
        </div>
        <div class="successText d-flex align-center justify-center">
          <div class="sureTextWrp">
            <h1><v-icon color="red" class="mdi-48px">
              mdi-alert-circle
            </v-icon></h1>
            <p>{{ dialogText }}</p>
            <v-card-actions>
              <v-btn class="yesBtn" text @click="submit(constant.PROJECT_STATUS.ALLOCATION_APPROVAL_REQUESTED, partialAllocationMessage)">
                Yes
              </v-btn>
              <v-btn class="cancleBtn" text @click="validationDialog = false">
                Cancel
              </v-btn>
            </v-card-actions>
          </div>
        </div>
      </div>

    </v-dialog>
    <v-dialog
      v-model="overBookDialog"
      :persistent="true"
    >

      <div class="successPopup">
        <div class="successImg">
          <v-img :src="popupImage" />
        </div>
        <div class="successText d-flex align-center justify-center">
          <div class="sureTextWrp">
            <h1><v-icon color="red" class="mdi-48px">
              mdi-alert-circle
            </v-icon></h1>
            <p>{{ overBookText }}</p>
            <v-card-actions>
              <v-btn class="yesBtn" text @click="checkValidationBeforeSubmit(true)">
                Yes
              </v-btn>
              <v-btn class="cancleBtn" text @click="overBookDialog = false">
                Cancel
              </v-btn>
            </v-card-actions>
          </div>
        </div>
      </div>

    </v-dialog>
    <v-card
      class="mx-auto"
      max-width="100%"
    >
      <v-card-text>
        <v-row v-if="checkDeletedAll === true">
          <v-col cols="12" class="pt-3 pb-0"><project-operation :project-details="projectList" :selected-project-name="projectDetail.uuid" :project-action-selected="projectActionSelected"/>
          </v-col>
        </v-row>
        <v-row v-if="checkDeletedAll === false">
          <v-col cols="12" class="pt-3 pb-0"><project-operation :project-details="projectList" :selected-project-name="projectDetail.uuid" :project-action-selected="projectActionSelected"/>
          </v-col>
          <v-col
            v-if="allocationRecordExists"
            cols="12"
            class="pt-0 pb-0"
          >
            <h2>Resource Requisition Form</h2>
          </v-col>
          <v-col
            v-if="allocationRecordExists"
            cols="12"
          >
            <v-data-table
              :headers="headers"
              :items="requisitionItems"
              :hide-default-footer="requisitionItems.length ? false : true"
              class="elevation-1"
              style="width: 100%"
            >
              <template v-slot:item.department="{ item }">
                {{ item.department.name }}
              </template>
              <template v-slot:item.technology="{ item }">
                {{ item.technology.name }}
              </template>
              <template v-slot:item.designation="{ item }">
                {{ item.designation.name }}
              </template>
              <template v-slot:item.start_date="{ item }">
                {{ new Date(item.start_date.substr(0,10)).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }) }}
              </template>
              <template v-slot:item.end_date="{ item }">
                {{ new Date(item.end_date.substr(0,10)).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }) }}
              </template>
              <template v-slot:item.requested_by="{ item }">
                {{ (item.requested_user) ? item.requested_user.display_name : '' }}
              </template>
              <template v-slot:item.billing_type="{ item }">
                {{ (item.billing_type && item.billing_type === 1) ? 'Billable' : (item.billing_type === 0) ? 'Non-Billable' : '' }}
              </template>
              <template v-slot:item.requested_on="{ item }">
                {{ new Date(item.created_at).toLocaleDateString('en-US', {
                  year: 'numeric', month: 'short', day: 'numeric'
                }) }}
              </template>
              <template v-slot:item.suggested_resource="{ item }">
                <span
                  v-for="resource in item.suggested_resource.slice(0,2)"
                  :key="resource.id"
                  class="ma-2"
                  text-color="white"
                >
                  <v-tooltip top>
                    <template v-slot:activator="{ on }">
                      <v-avatar
                        color="blue lighten-1"
                        size="30"
                        v-on="on"
                      >
                        <span class="white--text headline">{{ avatarNames(resource.full_name) }}</span>
                      </v-avatar>
                    </template>
                    {{ resource.full_name }}
                  </v-tooltip>
                </span>
                <v-menu
                  bottom
                  origin="center center"
                  transition="scale-transition"
                >
                  <template v-slot:activator="{ on }">
                    <v-btn
                      v-if="item.suggested_resource.length > 2"
                      outlined
                      fab
                      x-small
                      color="blue"
                      v-on="on"
                      @click="!false"
                    >
                      <v-icon x-small>
                        mdi-plus
                      </v-icon>
                      {{ item.suggested_resource.slice(2,item.suggested_resource.length).length }}
                    </v-btn>
                  </template>
                  <v-card
                    v-show="!false"
                    class="mx-auto"
                    max-width="300"
                    raised
                  >
                    <v-list
                      v-if="item.suggested_resource.length > 2"
                      disabled
                      shaped
                    >
                      <v-list-item-group
                        v-model="item.suggested_resource"
                        color="primary"
                      >
                        <v-list-item
                          v-for="resource in item.suggested_resource.slice(2,item.suggested_resource.length)"
                          v-show="!false"
                          :key="resource.id"
                        >
                          <v-avatar
                            color="blue"
                            size="30"
                          >
                            <strong class="white--text headline">{{ avatarNames(resource.full_name) }}</strong>
                          </v-avatar>
                          <v-list-item-content class="ml-2">
                            <v-list-item-title v-text="resource.full_name" />
                          </v-list-item-content>
                        </v-list-item>
                      </v-list-item-group>
                    </v-list>
                  </v-card>
                </v-menu>
              </template>
            </v-data-table>
          </v-col>
          <v-col
            v-if="extensionAllocationRecordExists"
            cols="12"
          >
            Resource Extension Form
          </v-col>
          <v-col
            v-if="extensionAllocationRecordExists"
            cols="12"
          >
            <v-data-table
              :headers="headersForExtensionTable"
              :items="extensionRequisitionData"
              :hide-default-footer="extensionRequisitionData.length ? false : true"
              class="elevation-1"
              style="width: 100%"
            >
              <template v-slot:item.resource="{ item }">
                {{ item.resource.display_name }}
              </template>
              <template v-slot:item.department="{ item }">
                {{ item.department.name }}
              </template>
              <template v-slot:item.technology="{ item }">
                {{ item.technology.name }}
              </template>
              <template v-slot:item.designation="{ item }">
                {{ item.designation.name }}
              </template>
              <template v-slot:item.start_date="{ item }">
                {{ new Date(item.start_date.substr(0,10)).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }) }}
              </template>
              <template v-slot:item.end_date="{ item }">
                {{ new Date(item.end_date.substr(0,10)).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }) }}
              </template>
              <template v-slot:item.requested_by="{ item }">
                {{ (item.requested_user) ? item.requested_user.display_name : '' }}
              </template>
              <template v-slot:item.billing_type="{ item }">
                {{ (item.billing_type && item.billing_type === 1) ? 'Billable' : (item.billing_type === 0) ? 'Non-Billable' : '' }}
              </template>
              <template v-slot:item.requested_on="{ item }">
                {{ new Date(item.created_at).toLocaleDateString('en-US', {
                  year: 'numeric', month: 'short', day: 'numeric'
                }) }}
              </template>
            </v-data-table>
          </v-col>
          <ValidationObserver ref="projectEditObserver" v-slot="{ valid }" class="w-full">
            <v-col
              v-if="allocationRecordExists"
              cols="12"
              class="pb-0"
            >

              <h2>Resource Allocation Form</h2>
            </v-col>
            <v-col
              v-if="allocationRecordExists"
              cols="12"
            >
              <v-data-table
                :headers="headersForAllocationTable"
                :items="allocationTableData.filter(item => !item.isDelete && item.manager_approve_allocation === null)"
                :hide-default-footer="allocationTableData.length ? false : true"
                class="elevation-1 dableResourceNameInc"
                style="width: 100%"
              >
                <template v-slot:item.efforts="{ item }">
                  <ValidationProvider v-slot="{ errors }" :rules="'required|check_efforts'" :name="item.efforts">
                    <v-text-field
                      v-model.trim="item.efforts"
                      :error-messages="errors"
                      @input="editAllocationEfforts"
                      @keyup="checkValidation(errors)"
                    />
                  </ValidationProvider>
                </template>
                <template v-slot:item.experience="{ item }">
                  <ValidationProvider v-slot="{ errors }" :rules="'required|check_experience'" :name="item.experience">
                    <v-text-field
                      v-model.trim="item.experience"
                      :error-messages="errors"
                      @input="editAllocationEfforts"
                      @keyup="checkValidation(errors)"
                    />
                  </ValidationProvider>
                </template>
                <template v-slot:item.start_date="{item}">
                  <v-menu
                    ref="item.resource_req_id"
                    v-model="item.start_date_menu"
                    :close-on-content-click="false"
                  >
                    <template v-slot:activator="{ on }">
                      <v-text-field
                        :value="new Date(item.start_date).toLocaleDateString('en-US', {
                          year: 'numeric',
                          month: 'short',
                          day: 'numeric'
                        })"
                        readonly
                        v-on="on"
                      />
                    </template>
                    <v-col cols="12" class="pa-0">
                      <v-date-picker v-model="item.start_date" :min="item.requisition_start_date" @change="changeStartDate(item)" @input="item.start_date_menu = false" />
                    </v-col>
                  </v-menu>
                </template>
                <template v-slot:item.end_date="{item}">
                  <v-menu
                    ref="item.resource_req_id"
                    v-model="item.end_date_menu"
                    :close-on-content-click="false"
                  >
                    <template v-slot:activator="{ on }">
                      <v-text-field
                        :value="new Date(item.end_date).toLocaleDateString('en-US', {
                          year: 'numeric',
                          month: 'short',
                          day: 'numeric'
                        })"
                        readonly
                        v-on="on"
                      />
                    </template>
                    <v-col cols="12" class="pa-0">
                      <v-date-picker v-model="item.end_date" :min="item.start_date" @input="item.end_date_menu = false" />
                    </v-col>
                  </v-menu>
                </template>
                <template v-slot:item.resource_name="{ item }">
                  <ValidationProvider v-slot="{ errors }" :rules="'required'" :name="actionSelected[item.resource_id]">
                    <v-autocomplete
                      v-model="item.resource_name"
                      :error-messages="errors"
                      :items="usersData.filter((user) => { return user.dept.length !== 0 && user.dept.some(value => value.id === item.dept) })"
                      item-text="full_name"
                      item-value="id"
                      label="Select Resource"
                    />
                  </ValidationProvider>
                </template>
                <template v-slot:item.action="{ item }">
                  <v-row class="align-baseline justify-center ma-0">
                    <v-col cols="6" class="pb-1 pr-0 pl-0">
                      <v-icon
                        small
                        @click="deleteItem(item)"
                      >
                        mdi-delete
                      </v-icon>
                    </v-col>
                    <v-col cols="6" class="pb-1 pr-0 pl-0">
                      <v-tooltip v-if="overBookResourceArray.includes(item.resource_name) ? true : false" top>
                        <template v-slot:activator="{ on, attrs }">
                          <span v-bind="attrs" v-on="on">
                            <v-icon color="red">mdi-alert-circle-outline</v-icon>
                          </span>
                        </template>
                        <span>Resource Overbooked</span>
                      </v-tooltip>
                    </v-col>
                  </v-row>
                </template>
              </v-data-table>
            </v-col>
            <v-col
              v-if="directAllocationRecordExists"
              cols="12"
              class="pb-0"
            >
              <!-- <v-divider class="pa-2" /> -->
              <h2>Direct Resource Allocation Form</h2>
            </v-col>
            <v-col
              v-if="directAllocationRecordExists"
              cols="12"
            >
              <v-data-table
                :headers="headersForAllocationTable"
                :items="directAllocationTableData.filter(item => !item.isDelete && item.manager_approve_allocation === null)"
                :hide-default-footer="directAllocationTableData.length ? false : true"
                class="elevation-1"
                style="width: 100%"
              >
                <template v-slot:item.efforts="{ item }">
                  <ValidationProvider v-slot="{ errors }" :rules="'required|check_efforts'" :name="item.efforts">
                    <v-text-field
                      v-model.trim="item.efforts"
                      :error-messages="errors"
                      @input="editAllocationEfforts"
                    />
                  </ValidationProvider>
                </template>
                <template v-slot:item.experience="{ item }">
                  <ValidationProvider v-slot="{ errors }" :rules="'required|check_experience'" :name="item.experience">
                    <v-text-field
                      v-model.trim="item.experience"
                      :error-messages="errors"
                      @input="editAllocationEfforts"
                    />
                  </ValidationProvider>
                </template>
                <template v-slot:item.start_date="{item}">
                  <v-menu
                    ref="item.resource_req_id"
                    v-model="item.start_date_menu"
                    :close-on-content-click="false"
                  >
                    <template v-slot:activator="{ on }">
                      <v-text-field
                        :value="new Date(item.start_date).toLocaleDateString('en-US', {
                          year: 'numeric',
                          month: 'short',
                          day: 'numeric'
                        })"
                        readonly
                        v-on="on"
                      />
                    </template>
                    <v-col cols="12" class="pa-0">
                      <v-date-picker v-model="item.start_date" :min="item.requisition_start_date" @change="changeStartDate(item)" @input="item.start_date_menu = false" />
                    </v-col>
                  </v-menu>
                </template>
                <template v-slot:item.end_date="{item}">
                  <v-menu
                    ref="item.resource_req_id"
                    v-model="item.end_date_menu"
                    :close-on-content-click="false"
                  >
                    <template v-slot:activator="{ on }">
                      <v-text-field
                        :value="new Date(item.end_date).toLocaleDateString('en-US', {
                          year: 'numeric',
                          month: 'short',
                          day: 'numeric'
                        })"
                        readonly
                        v-on="on"
                      />
                    </template>
                    <v-col cols="12" class="pa-0">
                      <v-date-picker v-model="item.end_date" :min="item.start_date" @input="item.end_date_menu = false" />
                    </v-col>
                  </v-menu>
                </template>
                <template v-slot:item.resource_name="{ item }">
                  <ValidationProvider v-slot="{ errors }" :rules="'required'" :name="actionSelected[item.resource_id]">
                    <v-autocomplete
                      v-model="item.resource_name"
                      :error-messages="errors"
                      :items="usersData.filter((user) => { return user.dept.length !== 0 && user.dept.some(value => value.id === item.dept) })"
                      item-text="full_name"
                      item-value="id"
                      label="Select Resource"
                    />
                  </ValidationProvider>
                </template>
                <template v-slot:item.action="{ item }">
                  <div class="text-center">
                    <v-icon
                      small
                      @click="directAllocationdelete(item)"
                    >
                      mdi-delete
                    </v-icon>
                    <v-tooltip v-if="overBookResourceArray.includes(item.resource_name) ? true : false" top>
                      <template v-slot:activator="{ on, attrs }">
                        <span v-bind="attrs" v-on="on">
                          <v-icon color="red">mdi-alert-circle-outline</v-icon>
                        </span>
                      </template>
                      <span>Resource Overbooked</span>
                    </v-tooltip>
                  </div>
                </template>
              </v-data-table>
            </v-col>
            <v-col
              v-show="getAllocatedResourceData.length"
              v-if="!valid || !validInput"
              cols="12"
              md="5"
            >
              <v-btn
                class="text-capitalize ma-2 white--text"
                color="blue-grey"
                @click="$router.push('/project-dashboard')"
              >
                <v-icon dark left>
                  mdi-arrow-left
                </v-icon>Back
              </v-btn>
              <v-btn :disabled="!valid || !validInput" class="text-capitalize" color="primary" @click="checkValidationBeforeSubmit(false)">
                Submit
              </v-btn>
            </v-col>
            <v-col
              v-else
              cols="12"
              md="5"
            >
              <v-btn
                class="text-capitalize ma-2 white--text"
                color="blue-grey"
                @click="$router.push('/project-dashboard')"
              >
                <v-icon dark left>
                  mdi-arrow-left
                </v-icon>Back
              </v-btn>
              <v-btn :disabled="submitted" class="text-capitalize" color="primary" @click="checkValidationBeforeSubmit(false)">
                Submit
              </v-btn>
            </v-col>
          </ValidationObserver>
        </v-row>
        <v-row v-else>
          <v-card
            class="mx-auto"
            width="100%"
          >
            <v-card-text style="text-align:center">
              <h3>
                <v-icon class="mdi-48px">
                  mdi-information-outline
                </v-icon><br> Edit Allocation data is no more available!
              </h3>
            </v-card-text>
          </v-card>
        </v-row>
      </v-card-text>
    </v-card>
  </div>
</template>

<script>
import { mapActions, mapGetters } from 'vuex'
import Dialog from '@/components/Dialog.vue'
import constant from '@/constants/closure-checklist.js'
import CommonSnackbar from '@/components/CommonSnackbar'
import ConfirmDialog from '@/components/ConfirmDialog'
import ProjectOperation from '@/components/ProjectOperation'
import { projectHelpers } from '@/helpers/helper.js'

export default {
  name: 'EditAllocation',
  layout: 'authenticated',
  middleware: 'authenticated',
  components: {
    ConfirmDialog,
    CommonSnackbar,
    Dialog,
    ProjectOperation
  },
  data () {
    return {
      constant,
      dialogText: '',
      snackbarValue: false,
      snackbarText: 'At least one resource must be Edit or Delete',
      resourceAllocationMeta: [],
      overBookResourceArray: [],
      overBookText: '',
      overBookDialog: false,
      validationDialog: false,
      requestedBy: '',
      requestedOn: '',
      projectName: '',
      headers: [
        { text: 'Department', sortable: false, value: 'department' },
        { text: 'Technology', value: 'technology' },
        { text: 'Role', sortable: false, value: 'designation' },
        { text: 'No. of Resources', value: 'no_of_resource' },
        { text: 'Daily Efforts (Hours)', value: 'efforts' },
        { text: 'Experience', value: 'experience', sortable: false },
        { text: 'Start Date', value: 'start_date', sortable: false, width: '8%' },
        { text: 'End Date', value: 'end_date', sortable: false, width: '7%' },
        { text: 'Billing Type', value: 'billing_type', sortable: false },
        { text: 'Suggested Resource', value: 'suggested_resource', sortable: false, width: '15%' },
        { text: 'Requested by', value: 'requested_user', sortable: false },
        { text: 'Requested on', value: 'requested_on', sortable: false }
      ],
      headersForExtensionTable: [
        { text: 'Resource Name', sortable: false, value: 'resource' },
        { text: 'Department', sortable: false, value: 'department' },
        { text: 'Technology', value: 'technology', width: '12%' },
        { text: 'Role', sortable: false, value: 'designation' },
        { text: 'No. of Resources', value: 'no_of_resource', width: '12%' },
        { text: 'Daily Efforts (Hours)', value: 'efforts', width: '12%' },
        { text: 'Experience', value: 'experience', sortable: false },
        { text: 'Start Date', value: 'start_date', sortable: false, width: '10%' },
        { text: 'End Date', value: 'end_date', sortable: false, width: '10%' },
        { text: 'Billing Type', value: 'billing_type', sortable: false },
        { text: 'Requested by', value: 'requested_by', sortable: false },
        { text: 'Requested on', value: 'requested_on', sortable: false }
      ],
      headersForAllocationTable: [
        { text: 'Resource Name', sortable: false, value: 'resource_name' },
        { text: 'Department', sortable: false, value: 'department' },
        { text: 'Technology', value: 'technology', width: '10%' },
        { text: 'Role', sortable: false, value: 'designation' },
        { text: 'Daily Efforts (Hours)', value: 'efforts', width: '10%' },
        { text: 'Experience', value: 'experience', sortable: false, width: '10%' },
        { text: 'Start Date', value: 'start_date', sortable: false, width: '11%' },
        { text: 'End Date', value: 'end_date', sortable: false, width: '11%' },
        { text: 'Action', value: 'action', sortable: false },
        { divider: true, inset: true }
      ],
      requisitionData: [],
      extensionRequisitionData: [],
      allocationTableData: [],
      directAllocationTableData: [],
      directAllocationRecordExists: false,
      extensionAllocationTableData: [],
      extensionAllocationRecordExists: false,
      allocationRecordExists: false,
      showAllocation: false,
      actionSelected: [],
      usersData: [],
      editableResourceData: [],
      editAllocationPayload: [],
      partialAllocationMessage: 'The resource allocation form has been successfully submitted. An email about resource allocation confirmation has been sent to the Account Manager & Project Manager of the project.',
      fullAllocationMessage: 'The present resource allocation matches the resources requested by the Account Manager/Project Manager. An email about full/partial resource allocation has been sent to Account Manager, Project Manager & Resource Manager.',
      submitted: false,
      validInput: true,
      projectActionSelected: 'edit-allocation',
      checkDeletedAll: false,
      requisitionItems: []
    }
  },
  computed: {
    ...mapGetters({
      users: 'project/getUserList',
      projectList: 'project/getProjectList',
      getAllocatedResourceData: 'project/getAllocatedResourceData',
      isButtonLoading: 'project/isButtonLoading',
      projectDetail: 'project/getProjectDetail'
    }),
    popupImage () {
      return require('@/assets/images/custom/ErrorDialog.png')
    }
  },
  async fetch ({ app, store, route }) {
    // eslint-disable-next-line no-useless-catch
    try {
      await Promise.all([
        store.dispatch('project/fetchProjectList'),
        store.dispatch('project/fetchAllocationsForEdit', route.params.id),
        store.dispatch('project/fetchProjectDetail', route.params.id)
      ])
    } catch (error) {
      throw (error)
    }
  },
  mounted () {
    this.$nuxt.$emit('headerTitle', 'Resource Allocation')
    const projectDetails = this.projectList.filter((item) => item.uuid === this.$route.params.id)

    this.projectName = projectDetails[0].project_name
    this.requestedOn = new Date(projectDetails[0].initiation_date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    })
    this.requisitionData = [...this.getAllocatedResourceData.filter((item) => (item.resource_allocation.length > 0 && item.type === 0 && item.direct_requisition === null && item.resource_allocation.some((element) => element.manager_approve_allocation === null)))]
    this.extensionRequisitionData = [...this.getAllocatedResourceData.filter((item) => (item.resource_allocation.length > 0 && item.type === 1 && item.direct_requisition === null && item.resource_allocation.some((element) => element.manager_approve_allocation === null)))]
    const requisitionRecord = [...this.getAllocatedResourceData.filter((item) => (item.resource_allocation.length > 0 && item.resource_allocation.some((element) => element.manager_approve_allocation === null)))]

    requisitionRecord.forEach((reqItem) => {
      reqItem.resource_allocation.forEach((allocatedItem) => {
        allocatedItem.resource_allocation_meta.forEach((allocatedItemMeta) => {
          this.editableResourceData.push({
            uuid: allocatedItemMeta.uuid,
            resource_req_id: reqItem.uuid,
            allocated_resource_id: allocatedItem.uuid,
            resource_name: allocatedItemMeta.resource.id,
            resource_id: allocatedItemMeta.resource_id,
            efforts: allocatedItemMeta.hours.toString(),
            experience: allocatedItem.experience,
            start_date: allocatedItemMeta.start_date.substr(0, 10),
            end_date: allocatedItemMeta.end_date.substr(0, 10),
            isDelete: false,
            directAllocateResource: (reqItem.direct_requisition !== null)
          })
          if (reqItem.direct_requisition !== null) {
            this.directAllocationTableData.push({
              uuid: allocatedItemMeta.uuid,
              resource_req_id: reqItem.uuid,
              allocated_resource_id: allocatedItem.uuid,
              resource_name: allocatedItemMeta.resource.id,
              resource_id: allocatedItemMeta.resource_id,
              technology: reqItem.technology.name,
              tech: reqItem.technology.id,
              department: reqItem.department.name,
              designation: reqItem.designation.name,
              dept: reqItem.department.id,
              efforts: allocatedItemMeta.hours.toString(),
              experience: allocatedItem.experience,
              start_date: allocatedItemMeta.start_date.substr(0, 10),
              end_date: allocatedItemMeta.end_date.substr(0, 10),
              requisition_start_date: reqItem.start_date.substr(0, 10),
              requisition_end_date: reqItem.end_date.substr(0, 10),
              no_of_hours: reqItem.efforts,
              allocation_status: allocatedItem.allocation_status,
              manager_approve_allocation: allocatedItem.manager_approve_allocation,
              start_date_menu: false,
              end_date_menu: false,
              isDelete: false
            })
          } else {
            this.allocationTableData.push({
              uuid: allocatedItemMeta.uuid,
              resource_req_id: reqItem.uuid,
              allocated_resource_id: allocatedItem.uuid,
              resource_name: allocatedItemMeta.resource.id,
              resource_id: allocatedItemMeta.resource_id,
              technology: reqItem.technology.name,
              tech: reqItem.technology.id,
              department: reqItem.department.name,
              designation: reqItem.designation.name,
              dept: reqItem.department.id,
              efforts: allocatedItemMeta.hours.toString(),
              experience: allocatedItem.experience,
              start_date: allocatedItemMeta.start_date.substr(0, 10),
              end_date: allocatedItemMeta.end_date.substr(0, 10),
              requisition_start_date: reqItem.start_date.substr(0, 10),
              requisition_end_date: reqItem.end_date.substr(0, 10),
              no_of_hours: reqItem.efforts,
              allocation_status: allocatedItem.allocation_status,
              manager_approve_allocation: allocatedItem.manager_approve_allocation,
              start_date_menu: false,
              end_date_menu: false,
              isDelete: false
            })
          }
        })
      })
    })
    if (this.directAllocationTableData.length > 0) {
      this.directAllocationRecordExists = true
    }
    if (this.extensionRequisitionData.length > 0) {
      this.extensionAllocationRecordExists = true
    }
    if (this.allocationTableData.length > 0) {
      this.allocationRecordExists = true
    }
    this.usersData = this.users
    const metaRecord = []

    this.projectDetail.resource_requisition.forEach((item) => {
      item.resource_allocation.forEach((element) => {
        if (element.mapped_resource !== null) {
          element.resource_allocation_meta.forEach((meta) => {
            if (metaRecord[meta.resource_id]) {
              metaRecord[meta.resource_id].push(meta)
            } else {
              metaRecord[meta.resource_id] = [meta]
            }
          })
        }
      })
    })
    if (this.requisitionData.length === 0 && this.extensionRequisitionData.length === 0 && this.allocationTableData.length === 0 && this.directAllocationTableData.length === 0) {
      this.checkDeletedAll = true
    }
    this.mutateRequisition(this.requisitionData)
    this.resourceAllocationMeta = metaRecord
  },
  methods: {
    ...mapActions({
      setResourceAllocationData: 'project/setResourceAllocationData',
      setCustomDialog: 'project/setCustomDialog',
      updateLoadingAction: 'project/updateLoadingAction',
      editAllocationAction: 'project/editAllocationAction'
    }),
    avatarNames (fullName) {
      return projectHelpers.avatarNames(fullName)
    },
    mutateRequisition (data) {
      let suggestedResources = []

      this.requisitionItems = []
      if (data) {
        data.forEach((value) => {
          let suggested = []
          const type = Object.prototype.toString.call(value.suggested_resource)

          if (value.suggested_resource && value.suggested_resource !== null && value.suggested_resource !== '' && type !== '[object Number]') {
            if (value.suggested_resource.startsWith('[') && value.suggested_resource.endsWith(']')) {
              suggested = JSON.parse(value.suggested_resource)
            }
          }

          const type2 = Object.prototype.toString.call(suggested)

          suggestedResources = []
          if (suggested && suggested !== null && (type2 !== '[object Number]' && type2 !== '[object String]')) {
            suggested.map((id) => {
              this.users.forEach((item) => {
                if (id === item.id && value.type === 0) {
                  suggestedResources.push({
                    full_name: item.full_name,
                    id: item.id
                  })
                }
              })
            })
          }
          this.users.forEach((item) => {
            if (value.extension_resource_id !== null && value.extension_resource_id === item.id && value.type === 1) {
              suggestedResources.push({
                full_name: item.full_name,
                id: item.id
              })
            }
          })
          this.requisitionItems.push({
            uuid: value.uuid,
            technology: value.technology,
            designation: value.designation,
            created_at: value.created_at,
            start_date: value.start_date,
            end_date: value.end_date,
            extension_resource_id: value.extension_resource_id,
            experience: value.experience,
            department: value.department,
            billing_type: value.billing_type,
            efforts: value.efforts,
            no_of_resource: value.no_of_resource,
            requested_user: value.requested_user.display_name,
            type: value.type,
            edit: false,
            resource_allocation: value.resource_allocation,
            isDeleted: value.isDeleted,
            suggested_resource: suggestedResources
          })
        })
      }
    },
    deleteItem (item) {
      this.$refs.confirm.open('Delete Requisition', 'Are you sure you want to delete?', { color: 'red' }).then((confirm) => {
        if (confirm) {
          this.allocationTableData.map((allocationItem) => {
            if (allocationItem.uuid === item.uuid) {
              allocationItem.isDelete = true
            }
          })
        }
      })
    },
    checkValidation (errors) {
      if (errors.length > 0) {
        this.validInput = false
      } else {
        this.validInput = true
      }

      return this.validInput
    },
    editAllocationEfforts (val) {
      let flag = false
      const allEditAllocation = this.allocationTableData.concat(this.directAllocationTableData)

      if (allEditAllocation.length > 0) {
        allEditAllocation.forEach((item) => {
          if (item.efforts === '' || item.experience === '') {
            flag = true
          }
        })
        this.submitted = flag
      }
    },
    directAllocationdelete (item) {
      this.$refs.confirm.open('Delete Requisition', 'Are you sure?', { color: 'red' }).then((confirm) => {
        if (confirm) {
          this.directAllocationTableData.map((allocationItem) => {
            if (allocationItem.uuid === item.uuid) {
              allocationItem.isDelete = true
            }
          })
        }
      })
    },
    changeStartDate (item) {
      if (item.start_date > item.end_date) {
        item.end_date = item.start_date
      }
    },
    checkResourceOverbooking (data, resourceId, startDate, endDate, hours) {
      let response = false
      let allocatedHours = parseFloat(hours)

      if (data[resourceId]) {
        data[resourceId].forEach((item) => {
          if (item.resource_id === resourceId) {
            if ((new Date(startDate)).getTime() >= (new Date(item.start_date)).getTime() && (new Date(startDate)).getTime() <= (new Date(item.end_date)).getTime()) {
              allocatedHours = allocatedHours + parseFloat(item.hours)
            } else if ((new Date(endDate)).getTime() >= (new Date(item.start_date)).getTime() && (new Date(endDate)).getTime() <= (new Date(item.end_date)).getTime()) {
              allocatedHours = allocatedHours + parseFloat(item.hours)
            }
          }
        })
        if (allocatedHours > 8) {
          response = true
        }
      }

      return response
    },
    async checkValidationBeforeSubmit (type = false) {
      this.editAllocationPayload = []
      let abort = false
      const { PROJECT_STATUS } = constant || {}
      const allocatedResource = [...this.allocationTableData.filter((item) => !item.isDelete)]
      const { RESOURCE_ALLOCATION_RESPONSE_APPROVE } = PROJECT_STATUS || {}
      let totalResourceRequired = 0
      let normalEditAllocation = false
      const assignedHours = { }
      const editRequisitionArray = []
      let hasPartialAllocation = false
      let hasFullAllocation = false
      let hasNoAllocation = false
      const totalEditAllocation = this.allocationTableData.concat(this.directAllocationTableData)
      const assignedResourcesPerReq = { }

      this.editableResourceData.forEach((allocattedResource) => {
        totalEditAllocation.forEach((initialAllocation) => {
          if (initialAllocation.uuid === allocattedResource.uuid &&
            (initialAllocation.start_date.substr(0, 10) !== allocattedResource.start_date.substr(0, 10) ||
                initialAllocation.end_date.substr(0, 10) !== allocattedResource.end_date.substr(0, 10) ||
                initialAllocation.resource_name !== allocattedResource.resource_name ||
                initialAllocation.efforts !== allocattedResource.efforts ||
                initialAllocation.experience !== allocattedResource.experience ||
                initialAllocation.isDelete
            )) {
            editRequisitionArray.push(initialAllocation.resource_req_id)
            this.editAllocationPayload.push({
              'uuid': initialAllocation.uuid,
              'resource_req_id': initialAllocation.resource_req_id,
              'allocated_resource_id': initialAllocation.allocated_resource_id,
              'resource_name': initialAllocation.resource_name,
              'resource_id': initialAllocation.resource_name,
              'department': initialAllocation.department,
              'designation': initialAllocation.designation,
              'efforts': initialAllocation.efforts,
              'experience': initialAllocation.experience,
              'start_date': initialAllocation.start_date.substr(0, 10),
              'end_date': initialAllocation.end_date.substr(0, 10),
              'isDelete': initialAllocation.isDelete,
              'directAllocateResource': allocattedResource.directAllocateResource
            })
            if (!allocattedResource.directAllocateResource) {
              normalEditAllocation = true
            }
          }
        })
      })
      if (!this.editAllocationPayload.length) {
        this.snackbarText = 'At least one resource must be Edit or Delete'
        this.snackbarValue = true
        setTimeout(() => {
          this.snackbarValue = false
        }, 3000)

        return
      }
      let editRequisitionRecord = this.requisitionData.concat(this.extensionRequisitionData)

      editRequisitionRecord = editRequisitionRecord.filter((item) => editRequisitionArray.includes(item.uuid))
      editRequisitionRecord.map((reqItem) => {
        totalResourceRequired = totalResourceRequired + reqItem.no_of_resource
        assignedHours[reqItem.uuid] = 0
        assignedResourcesPerReq[reqItem.uuid] = 0
        allocatedResource.map((item) => {
          // To calculate the time difference of two dates
          let dateDiff = false

          if (item.resource_req_id === reqItem.uuid) {
            ++assignedResourcesPerReq[reqItem.uuid]
            assignedHours[reqItem.uuid] += parseFloat(item.efforts)
            const diffInTimeForStartDate = new Date(item.start_date.substr(0, 10)).getTime() -
              new Date(reqItem.start_date.substr(0, 10)).getTime()

            // To calculate the no. of days between two dates
            const diffInDaysForStartDate = diffInTimeForStartDate / (1000 * 3600 * 24)
            const diffInTimeForEndDate = new Date(item.end_date.substr(0, 10)).getTime() -
              new Date(reqItem.end_date.substr(0, 10)).getTime()

            // To calculate the no. of days between two dates
            const diffInDaysForEndDate = diffInTimeForEndDate / (1000 * 3600 * 24)

            if (diffInDaysForEndDate !== 0 || diffInDaysForStartDate !== 0) {
              dateDiff = true
            }
          }
          if (item.manager_approve_allocation === null && ((item.resource_req_id === reqItem.uuid &&
            item.efforts !== reqItem.efforts && item.manager_approve_allocation === null && normalEditAllocation) || dateDiff || (item.resource_req_id === reqItem.uuid && item.experience !== reqItem.experience && normalEditAllocation))
          ) {
            this.dialogText = 'The present resource allocation doesn’t match with the resources requested by the Account Manager/Project Manager and they may turn down the allocation. Do you still want to continue?'
            abort = true

            return false
          } else if (item.manager_approve_allocation === null && item.resource_req_id === reqItem.uuid && reqItem.type === 1 && item.resource_name !== reqItem.extension_resource_id) {
            this.dialogText = 'The present resource allocation doesn’t match with the resources requested by the Account Manager/Project Manager and they may turn down the allocation. Do you still want to continue ?'
            abort = true

            return false
          }
        })
        if (assignedResourcesPerReq[reqItem.uuid] === 0) {
          hasNoAllocation = true
          assignedResourcesPerReq[`${reqItem.uuid}-status`] = 'none'
        } else if (assignedResourcesPerReq[reqItem.uuid] === reqItem.no_of_resource) {
          hasFullAllocation = true
          assignedResourcesPerReq[`${reqItem.uuid}-status`] = 'fully'
        } else if (assignedResourcesPerReq[reqItem.uuid] !== reqItem.no_of_resource &&
          assignedResourcesPerReq[reqItem.uuid] !== 0) {
          hasPartialAllocation = true
          assignedResourcesPerReq[`${reqItem.uuid}-status`] = 'partially'
        }
      })
      const resourceIdArray = []
      let isSameResource = false
      const resourceOverbookResource = []
      const filterTotalEditAllocation = totalEditAllocation.filter((alloc) => { return alloc.manager_approve_allocation === null })

      filterTotalEditAllocation.forEach((record) => {
        if (!record.isDelete) {
          if (!resourceIdArray.includes(record.resource_name)) {
            resourceIdArray.push(record.resource_name)
          } else {
            isSameResource = true
          }
          const overbook = this.checkResourceOverbooking(this.resourceAllocationMeta, record.resource_name, record.start_date, record.end_date, record.efforts)

          if (overbook) {
            resourceOverbookResource.push(record.resource_name)
          }
        }
      })
      if (isSameResource) {
        this.snackbarText = 'Same Resource exist in multiple allocation'
        this.snackbarValue = true
        setTimeout(() => {
          this.snackbarValue = false
        }, 3000)

        return
      }
      this.overBookResourceArray = resourceOverbookResource
      if (this.overBookResourceArray.length > 0 && !type) {
        this.overBookText = 'The selected resource is already allocated on the project for the same duration and efforts which may lead to creating duplicate bookings. Do you still want to continue?'
        this.overBookDialog = true
        abort = true

        return false
      } else {
        this.overBookDialog = false
      }
      if (abort) {
        this.validationDialog = true

        return false
      }
      if (hasPartialAllocation && normalEditAllocation) {
        this.dialogText = 'The present resource allocation doesn’t match with the resources requested by the Account Manager/Project Manager and they may turn down the allocation. Do you still want to continue?'
        this.validationDialog = true
        abort = true

        return false
      }
      if (hasNoAllocation && hasFullAllocation && normalEditAllocation) {
        this.dialogText = 'The resource allocation has not been performed for one or more resource requisition requests which you may need to perform later. Do you still want to continue?'
        this.validationDialog = true
        abort = true

        return false
      }
      if (!abort) {
        await this.submit(RESOURCE_ALLOCATION_RESPONSE_APPROVE, this.fullAllocationMessage)
      }
    },
    async submit (projectStatus, popupMessage) {
      this.updateLoadingAction()
      this.validationDialog = false
      let i = 0

      for (i; i < this.allocationTableData.length; i++) {
        this.allocationTableData[i].resource_id = this.allocationTableData[i].resource_name
      }
      const requestData = {
        allocation_data: this.editAllocationPayload,
        project_id: this.$route.params.id,
        popup_message: popupMessage
      }

      await this.editAllocationAction(requestData)
      this.updateLoadingAction()
      this.submitted = true
    }
  }
}
</script>

<style scoped>
.v-text-field__slot >>> .theme--light.v-label--is-disabled {
    color: rgba(0, 0, 0, 0.6);
    font-size: 18px
  }
.container {
    max-width: 1250px !important
}
.v-chip.v-size--default {
    font-size: smaller;
    height: auto;
}
.v-application .headline {
    font-size: 1rem !important;
    font-weight: 400;
    line-height: 2rem;
    letter-spacing: normal !important;
    font-family: "Open Sans", sans-serif !important;
}
</style>
