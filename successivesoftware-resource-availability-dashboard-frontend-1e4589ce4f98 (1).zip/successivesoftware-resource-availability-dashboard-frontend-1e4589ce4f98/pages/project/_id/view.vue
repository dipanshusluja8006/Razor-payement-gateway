<template>
  <div id="projectInitiation">
    <div class="projectInitHWrp">
      <v-row align="center">
        <v-col class="text-left" cols="12" sm="9">
          <h3 class="projectInitHeading">
            Project Details
          </h3>
        </v-col>
        <v-col class="text-right pr-6" cols="12" sm="3">
          <div class="actionWrp">
            <v-btn class="btn-color" @click="$router.push('/project-dashboard')">Done</v-btn>
          </div>
        </v-col>
      </v-row>
    </div>
    <ValidationObserver ref="projectInitObserver" v-slot="{ }" class="projectInitiationFormWrp">
      <v-stepper v-model="e6" vertical >
        <div align="center" class="">
          <div sm="12" class="text-left" cols="12">
            <div v-if="!Step1Error">
              <v-stepper-step complete :step="generalDetailTab" >
                General Details
              </v-stepper-step>
            </div>
            <v-stepper-content step="1">
              <v-card class="projectInitiationFormInner">
                <div class="content bottomSpace">
                  <v-card-text class="cardContent">
                    <v-row>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Project Name *</strong>
                        </div>
                        <ValidationProvider v-slot="{ errors }" :rules="'required'" name="projectName">
                          <v-text-field
                            v-model.trim="projectName"
                            :error-messages="errors"
                            dense
                            :readonly="true"
                            placeholder="Please enter project name"
                          />
                        </ValidationProvider>
                      </v-col>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Project Type *</strong>
                        </div>
                        <ValidationProvider
                          v-slot="{ errors }"
                          :rules="'required'"
                          name="projectTypeId"
                        >
                          <v-autocomplete
                            v-model="projectTypeId"
                            :items="projectTypes"
                            :error-messages="errors"
                            readonly
                            placeholder="Please select project type"
                            item-text="name"
                            item-value="id"
                            dense
                          />
                        </ValidationProvider>
                      </v-col>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Governance Category *</strong>
                          <v-tooltip max-width="350px" bottom>
                            <template v-slot:activator="{ on, attrs }">
                              <v-icon
                                v-bind="attrs"
                                class="mdi-16px btn-color"
                                dark
                                v-on="on"
                              >
                                mdi-information
                              </v-icon>
                            </template>
                            <div>
                              <strong><i><u>Managed Services</u></i></strong> <br>
                              Engagement where successive have full control of the project. like: Estimation, Management, Engineering & Monitoring, etc.
                              <br><strong><i><u>Extension</u></i></strong><br>
                              Support and Maintenance project where task Estimation and Planning drive by the client.
                              <br><strong><i><u>Staff Augmentation</u></i></strong> <br>
                              Engagement where successive only provide staff to client and rest is managed by the client.
                            </div>
                          </v-tooltip>
                        </div>
                        <ValidationProvider
                          v-slot="{ errors }"
                          :rules="'required'"
                          name="governanceCategoryId"
                        >
                          <v-autocomplete
                            v-model="governanceCategoryId"
                            :items="governanceCategories"
                            :error-messages="errors"
                            item-text="name"
                            item-value="id"
                            placeholder="Please select the governance category"
                            dense
                            readonly
                          />
                        </ValidationProvider>
                      </v-col>
                    </v-row>
                    <v-row>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Project Lifecycle Model *</strong>
                        </div>
                        <ValidationProvider v-slot="{ errors }" :rules="'required'" name="projectLifeCycleModel">
                          <v-autocomplete
                            v-model="projectLifeCycleModel"
                            :items="getProjectLifeCycleModel"
                            :error-messages="errors"
                            :readonly="true"
                            placeholder="Please select project lifecycle model"
                            item-text="name"
                            item-value="id"
                            dense
                          />
                        </ValidationProvider>
                      </v-col>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Project Domain *</strong>
                        </div>
                        <ValidationProvider v-slot="{ errors }" :rules="'required'" name="projectDomain">
                          <v-autocomplete
                            v-model="selectedDomains"
                            :hide-no-data="!searchDomain"
                            :items="getProjectDomains"
                            :error-messages="errors"
                            :search-input.sync="searchDomain"
                            item-text="name"
                            item-value="id"
                            hide-selected
                            :readonly="true"
                            placeholder="Please select project domains"
                            dense
                            multiple
                            attach
                            @change="searchDomain=''"
                            @keyup.enter="submitNewDomain(searchDomain)"
                          >
                            <template v-slot:no-data />
                            <template v-slot:prepend-item>
                              <v-list-item v-if="searchDomain !== null && searchDomain !== '' && !domainNameArray.includes(searchDomain)">
                                <span class="subheading">Create</span>
                                <v-chip
                                  color="teal lighten-3"
                                  label
                                  small
                                >
                                  {{ searchDomain }}
                                </v-chip>
                              </v-list-item>
                            </template>
                            <template v-slot:selection="{ attrs, item, parent, selected, index}">
                              <v-tooltip top>
                                <template v-slot:activator="{ on }">
                                  <v-chip
                                    v-if="item === Object(item) && index <= 1"
                                    v-bind="attrs"
                                    :input-value="selected"
                                    color="blue lighten-3"
                                    label
                                    small
                                    v-on="on"
                                  >
                                    <span class="pr-2">
                                      {{ item.name.length >= 47? item.name.slice(0,47) + '...': item.name }}
                                    </span>
                                  </v-chip>
                                  <v-menu
                                    bottom
                                    origin="center center"
                                    transition="scale-transition"
                                  >
                                    <template v-slot:activator="{ on }">
                                      <v-btn
                                        v-if="index === 2"
                                        class="ml-1 mr-1 text-capitalize"
                                        outlined
                                        rounded
                                        fab
                                        small
                                        height="30"
                                        width="30"
                                        color="blue"
                                        v-on="on"
                                        @click="projectDetail.openProjectDomainList = !projectDetail.openProjectDomainLis"
                                      >
                                        <v-icon x-small style="height: 10px; width: 10px">
                                          mdi-plus
                                        </v-icon>
                                        {{ selectedDomains.length - 2 }}
                                      </v-btn>
                                    </template>
                                    <v-card
                                      v-show="projectDetail.openProjectDomainList"

                                      raised
                                    >
                                      <v-list
                                        v-if="projectDetail.project_domains.length > 2"
                                        disabled
                                        shaped
                                      >
                                        <v-list-item-group
                                          v-model="projectDetail.project_domains"
                                        >
                                          <v-list-item
                                            v-for="projectDomain in projectDetail.project_domains.slice(2,projectDetail.project_domains.length)"
                                            v-show="projectDetail.openProjectDomainList"
                                            :key="projectDomain.id"
                                          >
                                            <v-avatar
                                              :color="`${randomColors()}`"
                                              size="30"
                                              style="padding:4px"
                                            >
                                              <strong class="white--text headline">{{ avatarNames(projectDomain.name) }}</strong>
                                            </v-avatar>
                                            <v-list-item-content class="ml-2">
                                              <v-list-item-title v-text="projectDomain.name" />
                                            </v-list-item-content>
                                          </v-list-item>
                                        </v-list-item-group>
                                      </v-list>
                                    </v-card>
                                  </v-menu>
                                </template>
                                <span>{{ item.name }}</span>
                              </v-tooltip>

                            </template>
                            <template v-slot:item="{ index, item }">
                              <v-tooltip top>
                                <template v-slot:activator="{ on }">
                                  <v-chip
                                    color="blue lighten-3"
                                    dark
                                    label
                                    small
                                    v-on="on"
                                  >
                                    {{ item.name.length >= 47? item.name.slice(0,47) + '...': item.name }}
                                  </v-chip>
                                  <v-spacer />
                                </template>
                                <span>{{ item.name }}</span>
                              </v-tooltip>
                            </template>
                          </v-autocomplete>
                        </ValidationProvider>
                      </v-col>
                      <v-col md="4" class="p-b-0">
                        <div class="field" style="padding-bottom: 0px;">
                          <v-checkbox
                            v-model="subProject"
                            dense
                            :readonly="true"
                            class="shrink mr-2 mt-0"
                            style="padding-top:0px; margin-right: 0px !important; width: 24px; display: inline-flex"
                            hide-details
                          />
                          <div style="display: inline-flex">
                            <strong>Sub-Project</strong>
                          </div>
                        </div>
                        <div v-if="subProject">
                          <ValidationProvider v-slot="{ errors }" :rules="(subProject) ? 'required' : ''" name="subProjectId">
                            <v-autocomplete
                              v-model="subProjectId"
                              :items="getRedminProjectNameList"
                              :disabled="!subProject"
                              :error-messages="errors"
                              item-text="project_name"
                              item-value="uuid"
                              placeholder="Please select project sub project"
                              :readonly="true"
                              dense
                            />
                          </ValidationProvider>
                        </div>
                      </v-col>
                    </v-row>
                    <v-row>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Billing Medium</strong>
                        </div>
                        <v-autocomplete
                          v-model="billingMediumId"
                          :items="billingMediums"
                          placeholder="Billing Medium"
                          item-text="name"
                          item-value="redmine_billing_medium_id"
                          readonly
                          dense
                        />
                      </v-col>
                      <v-col md="8" class="p-b-0">
                        <div class="field">
                          <strong>Billing Type *</strong>
                        </div>
                        <v-chip-group
                          v-model="billingType"
                          mandatory
                          active-class="deep-purple accent-4 white--text"
                          column
                        >
                          <div v-for="(billing, index) in billingTypes" :key="index">
                            <v-chip
                              disabled
                              :value="billing.id"
                              class="ml-2"
                            >
                              {{ billing.name }}
                            </v-chip>
                          </div>
                        </v-chip-group>
                      </v-col>
                    </v-row>
                    <v-row>
                      <v-col md="8" class="p-b-0">
                        <div class="field">
                          <strong>Project Summary *</strong>
                        </div>
                        <ValidationProvider v-slot="{ errors }" :rules="'required'" name="projectSummary">
                          <v-textarea
                            v-model.trim="projectSummary"
                            :error-messages="errors"
                            :auto-grow="true"
                            dense
                            :readonly="true"
                            placeholder="Please enter project summary.."
                            rows="1"
                          />
                        </ValidationProvider>
                      </v-col>
                    </v-row>
                  </v-card-text>
                </div>
              </v-card>
            </v-stepper-content>
            <v-stepper-step v-if="(billingType === 1 || billingType === 2 || billingType === 3)" complete :step="clientDetailTab">
              Client Details
            </v-stepper-step>
            <v-stepper-content v-show="(billingType === 1 || billingType === 2 || billingType === 3)" step="1">
              <v-card class="projectInitiationFormInner">
                <div v-if="billingType === 1 || billingType === 2 || billingType === 3" class="content bottomSpace">
                  <v-card-text class="cardContent">
                    <v-row>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Company Name *</strong>
                        </div>
                        <ValidationProvider v-slot="{ errors }" :rules="(billingType === 1 || billingType === 2 || billingType === 3) ? 'required' : ''" name="companyName">
                          <v-text-field
                            v-model.trim="companyName"
                            :disabled="!(billingType === 1 || billingType === 2 || billingType === 3)"
                            :error-messages="errors"
                            :readonly="true"
                            placeholder="Please enter company's name"
                            dense
                          />
                        </ValidationProvider>
                      </v-col>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Country *</strong>
                        </div>
                        <ValidationProvider v-slot="{ errors }" :rules="(billingType === 1 || billingType === 2 || billingType === 3) ? 'required' : ''" name="companyCountry">
                          <v-autocomplete
                            v-model="companyCountry"
                            :disabled="!(billingType === 1 || billingType === 2 || billingType === 3)"
                            :items="newCountryData"
                            placeholder="Please enter Country"
                            item-text="countryName"
                            item-value="countryName"
                            :readonly="true"
                            :error-messages="errors"
                            dense
                            @change="setResignValues(companyCountry)"
                          />
                        </ValidationProvider>
                      </v-col>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>State *</strong>
                        </div>
                        <ValidationProvider v-slot="{ errors }" :rules="(billingType === 1 || billingType === 2 || billingType === 3) ? 'required' : ''" name="companyState">
                          <v-autocomplete
                            v-model="companyState"
                            :disabled="!(billingType === 1 || billingType === 2 || billingType === 3)"
                            :items="newStateData"
                            placeholder="Please enter state"
                            item-text="name"
                            :readonly="true"
                            item-value="name"
                            :error-messages="errors"
                            dense
                          />
                        </ValidationProvider>
                      </v-col>
                    </v-row>
                    <v-row>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Company Address *</strong>
                        </div>
                        <ValidationProvider v-slot="{ errors }" :rules="(billingType === 1 || billingType === 2 || billingType === 3) ? 'required|alpha_num_whitespace' : ''" name="companyAddress">
                          <v-textarea
                            v-model.trim="companyAddress"
                            :disabled="!(billingType === 1 || billingType === 2 || billingType === 3)"
                            :error-messages="errors"
                            placeholder="Enter enter company's address"
                            rows="1"
                            :readonly="true"
                            dense
                            hide-details
                            auto-grow
                          />
                        </ValidationProvider>
                      </v-col>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Client Name And Email Address *</strong>
                        </div>
                        <ValidationProvider v-slot="{ errors }" :rules="'required'" name="selectedClients">
                          <v-autocomplete
                            v-model="selectedClients"
                            :error-messages="errors"
                            :hide-no-data="!searchClients"
                            :items="getProjectClients"
                            :search-input.sync="searchClients"
                            item-text="name"
                            :readonly="true"
                            item-value="id"
                            attach
                            chips
                            dense
                            placeholder="Select Existing Client"
                            multiple
                          >
                            <template v-slot:selection="data">
                              <v-tooltip max-width="350px" top>
                                <template v-slot:activator="{ on }">
                                  <span
                                    v-if="data.index <= 2"
                                    v-bind="data.attrs"
                                    :input-value="data.selected"
                                    close
                                    style="padding-left: 10px;"
                                    v-on="on"
                                    @click="data.select"
                                    @click:close="removeItemFromArray(data.item, 'selectedClients')"
                                  >
                                    <v-avatar
                                      :color="`${randomColors()}`"
                                      size="30"
                                      style="padding:4px"
                                      v-on="on"
                                    >
                                      <span class="white--text headline">{{ avatarNames(data.item.name) }}</span>
                                    </v-avatar>
                                  </span>
                                  <v-menu
                                    bottom
                                    origin="center center"
                                    transition="scale-transition"
                                  >
                                    <template v-slot:activator="{ on }">
                                      <v-btn
                                        v-if="data.index === 3"
                                        class="ml-1 mr-1 text-capitalize"
                                        outlined
                                        rounded
                                        fab
                                        small
                                        height="30"
                                        width="30"
                                        color="blue"
                                        v-on="on"
                                        @click="projectDetail.openProjectClientList = !projectDetail.openProjectClientLis"
                                      >
                                        <v-icon x-small style="height: 10px; width: 10px">
                                          mdi-plus
                                        </v-icon>
                                        {{ selectedClients.length - 3 }}
                                      </v-btn>
                                    </template>
                                    <v-card
                                      v-show="projectDetail.openProjectClientList"
                                      class="mx-auto"
                                      max-width="300"
                                      raised
                                    >
                                      <v-list
                                        v-if="projectDetail.clientsArray.length > 3"
                                        disabled
                                        shaped
                                      >
                                        <v-list-item-group
                                          v-model="projectDetail.clientsArray"
                                        >
                                          <v-list-item
                                            v-for="clientData in projectDetail.clientsArray.slice(3,projectDetail.clientsArray.length)"
                                            v-show="projectDetail.openProjectClientList"
                                            :key="clientData.id"
                                          >
                                            <v-avatar
                                              :color="`${randomColors()}`"
                                              size="30"
                                              style="padding:4px"
                                            >
                                              <strong class="white--text headline">{{ avatarNames(clientData.name) }}</strong>
                                            </v-avatar>
                                            <v-list-item-content class="ml-2">
                                              <v-list-item-title v-text="clientData.name" />
                                            </v-list-item-content>
                                          </v-list-item>
                                        </v-list-item-group>
                                      </v-list>
                                    </v-card>
                                  </v-menu>

                                </template>
                                <div>
                                  <strong>{{ (data.item.emails && data.item.emails !== '') ? data.item.emails : '' }}</strong>
                                </div>
                              </v-tooltip>
                            </template>
                            <template v-slot:item="data">
                              <v-list-item-content>
                                <v-list-item-title v-html="data.item.name" />
                                <v-list-item-subtitle>{{ (data.item.emails && data.item.emails !== '') ? data.item.emails : '' }}</v-list-item-subtitle>
                              </v-list-item-content>
                            </template>
                          </v-autocomplete>
                        </ValidationProvider>
                      </v-col>
                    </v-row>
                  </v-card-text>
                </div>
              </v-card>
            </v-stepper-content>
            <v-stepper-step complete :step="timelineTab">
              Timeline
            </v-stepper-step>
            <v-stepper-content step="1">
              <v-card class="projectInitiationFormInner">
                <div class="content bottomSpace">
                  <v-card-text class="cardContent">
                    <v-row>
                      <v-col md="4" class="p-b-0">
                        <div class="field"><strong>Project Duration *</strong></div>
                        <v-row>
                          <v-col cols="12" md="8" class="projectDurationFld pr-0">
                            <v-menu
                              ref="TimelineMenu"
                              v-model="menu"
                              :close-on-content-click="false"
                              offset-y
                              transition="scale-transition"
                            >
                              <template v-slot:activator="{ on }">
                                <v-text-field
                                  slot="activator"
                                  v-model="dates"
                                  multiple
                                  :readonly="true"
                                  dense
                                  solo-inverted
                                  filled
                                  v-on="on"
                                >
                                  <template v-slot:prepend-inner>
                                    <v-icon v-on="on">
                                      mdi-calendar
                                    </v-icon>
                                  </template>
                                </v-text-field>
                              </template>
                              <v-date-picker
                                v-model="datePicker"
                                range
                                no-title
                                :readonly="true"
                                scrollable
                              />
                            </v-menu>
                          </v-col>
                          <v-col cols="12" md="4" class="projectDurationFld pl-1">
                            <v-text-field
                              v-model="totalDays"
                              label="Days"
                              solo-inverted
                              dense
                              :readonly="true"
                            />
                          </v-col>
                        </v-row>
                      </v-col>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>{{ (billingType === 1) ? 'Total Approved Hours *' : 'Maximum Hours Billed *' }}</strong>
                        </div>
                        <ValidationProvider
                          v-if="billingType === 1"
                          v-slot="{ errors }"
                          :rules="'required|numeric'"
                          name="approvedHours"
                        >
                          <v-text-field
                            v-model="approvedHours"
                            :error-messages="errors"
                            placeholder="Approved Hours"
                            dense
                            :readonly="true"
                          />
                        </ValidationProvider>
                        <ValidationProvider
                          v-else
                          v-slot="{ errors }"
                          :rules="'numeric'"
                          name="maximumHoursBilled"
                        >
                          <v-text-field
                            v-model="maximumHoursBilled"
                            :error-messages="errors"
                            placeholder="Approved Hours "
                            dense
                            :readonly="true"
                          />
                        </ValidationProvider>
                      </v-col>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Billing Interval{{ (billingType === 1 || billingType === 2 || billingType === 3) ? ' *' : '' }}</strong>
                        </div>
                        <v-autocomplete
                          v-model="billingInterval"
                          :items="billingIntervalArray"
                          :readonly="true"
                          placeholder="Please select billing interval"
                          item-text="name"
                          item-value="value"
                          dense
                        />
                      </v-col>
                    </v-row>
                  </v-card-text>
                </div>
              </v-card>
            </v-stepper-content>
            <v-stepper-step complete :step="projectComponentTab">
              Project Components
            </v-stepper-step>
            <v-stepper-content step="1">
              <v-card class="projectInitiationFormInner">
                <div class="content bottomSpace">
                  <v-card-text class="cardContent">
                    <v-row>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Project Components *</strong>
                        </div>
                        <ValidationProvider>
                          <v-chip-group
                            v-model="selected"
                            :mandatory="false"
                            active-class="deep-purple accent-4 white--text"
                            column
                            multiple
                            disabled
                          >
                            <div class="projectComp">
                              <v-chip
                                value="web"
                                class="ml-2"
                                hide-details
                                disabled
                              >
                                Web Application
                              </v-chip>
                              <v-chip
                                value="mobile"
                                class="ml-2"
                                hide-details
                                disabled
                              >
                                Mobile Application
                              </v-chip>
                              <v-chip
                                value="design"
                                class="ml-2"
                                hide-details
                                disabled
                              >
                                Designing
                              </v-chip>
                              <v-chip
                                value="other"
                                class="ml-2"
                                hide-details
                                disabled
                              >
                                other
                              </v-chip>
                              <ValidationProvider v-if="selected.includes('other')" v-slot="{ errors }" :rules="`required`" name="otherComponents">
                                <div class="otherProjComp">
                                  <v-text-field
                                    v-if="selected.includes('other')"
                                    v-model.trim="otherComponents"
                                    :error-messages="errors"
                                    :placeholder="`Type Here...`"
                                    outlined
                                    dense
                                    :readonly="true"
                                    height="20"
                                  />
                                </div>
                              </ValidationProvider>
                            </div>
                          </v-chip-group>
                        </ValidationProvider>
                      </v-col>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Account Manager *</strong>
                        </div>
                        <ValidationProvider v-slot="{ errors }" :rules="'required'" name="selectedManager">
                          <v-autocomplete
                            v-model="selectedManager"
                            :error-messages="errors"
                            :items="userDetail"
                            :search-input.sync="searchPm"
                            item-text="full_name"
                            item-value="id"
                            attach
                            :readonly="true"
                            chips
                            dense
                            placeholder="Select Account Manager(s)"
                            multiple
                          >
                            <template v-slot:selection="data">
                              <v-tooltip max-width="350px" top>
                                <template v-slot:activator="{ on }">
                                  <v-chip
                                    v-if="data.index === 0"
                                    v-bind="data.attrs"
                                    :input-value="data.selected"
                                    close
                                    v-on="on"
                                  >
                                    <strong>{{ data.item.full_name }}</strong>
                                  </v-chip>
                                  <v-menu
                                    bottom
                                    origin="center center"
                                    transition="scale-transition"
                                  >
                                    <template v-slot:activator="{ on }">
                                      <v-btn
                                        v-if="data.index === 1"
                                        class="ml-1 mr-1 text-capitalize"
                                        outlined
                                        rounded
                                        fab
                                        small
                                        height="30"
                                        width="30"
                                        color="blue"
                                        v-on="on"
                                        @click="projectDetail.openProjectAMList = !projectDetail.openProjectAMLis"
                                      >
                                        <v-icon x-small style="height: 10px; width: 10px">
                                          mdi-plus
                                        </v-icon>
                                        {{ selectedManager.length - 1 }}
                                      </v-btn>
                                    </template>
                                    <v-card
                                      v-show="projectDetail.openProjectAMList"
                                      class="mx-auto"
                                      max-width="300"
                                      raised
                                    >
                                      <v-list
                                        v-if="projectDetail.account_managers.length > 1"
                                        disabled
                                        shaped
                                      >
                                        <v-list-item-group
                                          v-model="projectDetail.account_managers"
                                        >
                                          <v-list-item
                                            v-for="accountManager in projectDetail.account_managers.slice(1,projectDetail.account_managers.length)"
                                            v-show="projectDetail.openProjectAMList"
                                            :key="accountManager.user_id"
                                          >
                                            <v-avatar
                                              :color="`${randomColors()}`"
                                              size="30"
                                              style="padding:4px"
                                            >
                                              <strong class="white--text headline">{{ avatarNames(accountManager.user.display_name) }}</strong>
                                            </v-avatar>
                                            <v-list-item-content class="ml-2">
                                              <v-list-item-title v-text="accountManager.user.display_name" />
                                            </v-list-item-content>
                                          </v-list-item>
                                        </v-list-item-group>
                                      </v-list>
                                    </v-card>
                                  </v-menu>
                                </template>
                                <div>
                                  <strong>{{ (data.item.job_title && data.item.job_title !== '') ? data.item.job_title : '' }}</strong><br>
                                  {{ `Emp # ${data.item.employee_id} | ${(data.item.dept[0]) ? data.item.dept[0].name : ''}` }}
                                </div>
                              </v-tooltip>
                            </template>
                            <template v-slot:item="data">
                              <v-list-item-content>
                                <v-list-item-title v-html="data.item.full_name" />
                                <v-list-item-subtitle>{{ (data.item.job_title && data.item.job_title !== '') ? data.item.job_title : '' }}</v-list-item-subtitle>
                                <v-list-item-subtitle>{{ `Emp # ${data.item.employee_id} | ${(data.item.dept[0]) ? data.item.dept[0].name : ''}` }}</v-list-item-subtitle>
                              </v-list-item-content>
                            </template>
                          </v-autocomplete>
                        </ValidationProvider>
                      </v-col>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Project Manager *</strong>
                        </div>
                        <ValidationProvider v-slot="{ errors }" :rules="'required'" name="projectManager">
                          <v-autocomplete
                            v-model="selectedProjectManager"
                            :error-messages="errors"
                            :items="userDetail"
                            :search-input.sync="searchAm"
                            item-text="full_name"
                            item-value="id"
                            attach
                            chips
                            :readonly="true"
                            dense
                            placeholder="Select Project Manager(s)"
                            multiple
                          >
                            <template v-slot:selection="data">
                              <v-tooltip max-width="350px" top>
                                <template v-slot:activator="{ on }">
                                  <v-chip
                                    v-if="data.index === 0"
                                    v-bind="data.attrs"
                                    :input-value="data.selected"
                                    close
                                    v-on="on"
                                  >
                                    <strong>{{ data.item.full_name }}</strong>
                                  </v-chip>
                                  <v-menu
                                    bottom
                                    origin="center center"
                                    transition="scale-transition"
                                  >
                                    <template v-slot:activator="{ on }">
                                      <v-btn
                                        v-if="data.index === 1"
                                        class="ml-1 mr-1 text-capitalize"
                                        outlined
                                        rounded
                                        fab
                                        small
                                        height="30"
                                        width="30"
                                        color="blue"
                                        v-on="on"
                                        @click="projectDetail.openProjectPMList = !projectDetail.openProjectPMLis"
                                      >
                                        <v-icon x-small style="height: 10px; width: 10px">
                                          mdi-plus
                                        </v-icon>
                                        {{ selectedProjectManager.length - 1 }}
                                      </v-btn>
                                    </template>
                                    <v-card
                                      v-show="projectDetail.openProjectPMList"
                                      class="mx-auto"
                                      max-width="300"
                                      raised
                                    >
                                      <v-list
                                        v-if="projectDetail.project_managers.length > 1"
                                        disabled
                                        shaped
                                      >
                                        <v-list-item-group
                                          v-model="projectDetail.project_managers"
                                        >
                                          <v-list-item
                                            v-for="projectManager in projectDetail.project_managers.slice(1,projectDetail.project_managers.length)"
                                            v-show="projectDetail.openProjectPMList"
                                            :key="projectManager.user_id"
                                          >
                                            <v-avatar
                                              :color="`${randomColors()}`"
                                              size="30"
                                              style="padding:4px"
                                            >
                                              <strong class="white--text headline">{{ avatarNames(projectManager.user.display_name) }}</strong>
                                            </v-avatar>
                                            <v-list-item-content class="ml-2">
                                              <v-list-item-title v-text="projectManager.user.display_name" />
                                            </v-list-item-content>
                                          </v-list-item>
                                        </v-list-item-group>
                                      </v-list>
                                    </v-card>
                                  </v-menu>
                                </template>
                                <div>
                                  <strong>{{ (data.item.job_title && data.item.job_title !== '') ? data.item.job_title : '' }}</strong><br>
                                  {{ `Emp # ${data.item.employee_id} | ${(data.item.dept[0]) ? data.item.dept[0].name : ''}` }}
                                </div>
                              </v-tooltip>
                            </template>
                            <template v-slot:item="data">
                              <v-list-item-content>
                                <v-list-item-title v-html="data.item.full_name" />
                                <v-list-item-subtitle>{{ (data.item.job_title && data.item.job_title !== '') ? data.item.job_title : '' }}</v-list-item-subtitle>
                                <v-list-item-subtitle>{{ `Emp # ${data.item.employee_id} | ${(data.item.dept[0]) ? data.item.dept[0].name : ''}` }}</v-list-item-subtitle>
                              </v-list-item-content>
                            </template>
                          </v-autocomplete>
                        </ValidationProvider>
                      </v-col>
                    </v-row>
                    <v-row>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Tech Stack *</strong>
                        </div>
                        <ValidationProvider v-slot="{ errors }" :rules="'required'" name="selectedTechnologies">
                          <v-autocomplete
                            v-model="selectedTechnologies"
                            :hide-no-data="!searchTech"
                            :error-messages="errors"
                            :items="technologies"
                            :search-input.sync="searchTech"
                            item-text="name"
                            item-value="id"
                            attach
                            chips
                            :readonly="true"
                            dense
                            placeholder="Please select tech stack"
                            multiple
                          >
                            <template v-slot:no-data />
                            <template v-slot:prepend-item>
                              <v-list-item v-if="searchTech !== null && searchTech !== '' && techNameArray.findIndex(item => ((searchTech) ? searchTech.toLowerCase() : searchTech) === ((item) ? item.toLowerCase() : item)) < 0">
                                <span class="subheading">Create</span>
                                <v-chip
                                  color="teal lighten-3"
                                  label
                                  small
                                >
                                  {{ searchTech }}
                                </v-chip>
                              </v-list-item>
                            </template>
                            <template v-slot:selection="data">
                              <v-chip
                                v-bind="data.attrs"
                                :input-value="data.selected"
                                close
                              >
                                <strong>{{ data.item.name }}</strong>&nbsp;
                              </v-chip>
                            </template>
                            <template v-slot:selection="{ attrs, item, parent, selected, index }">
                              <v-tooltip top>
                                <template v-slot:activator="{ on }">
                                  <v-chip
                                    v-if="item === Object(item) && index <= 1"
                                    v-bind="attrs"
                                    :input-value="selected"
                                    label
                                    small
                                    v-on="on"
                                  >
                                    <span class="pr-2">
                                      {{ item.name.length >= 47? item.name.slice(0,47) + '...': item.name }}
                                    </span>
                                  </v-chip>

                                  <v-menu
                                    bottom
                                    origin="center center"
                                    transition="scale-transition"
                                  >
                                    <template v-slot:activator="{ on }">
                                      <v-btn
                                        v-if="index === 2"
                                        class="ml-1 mr-1 text-capitalize"
                                        outlined
                                        rounded
                                        fab
                                        small
                                        height="30"
                                        width="30"
                                        color="blue"
                                        v-on="on"
                                        @click="projectDetail.openProjectTechList = !projectDetail.openProjectTechLis"
                                      >
                                        <v-icon x-small style="height: 10px; width: 10px">
                                          mdi-plus
                                        </v-icon>
                                        {{ selectedTechnologies.length - 2 }}
                                      </v-btn>
                                    </template>
                                    <v-card
                                      v-show="projectDetail.openProjectTechList"
                                      class="mx-auto"
                                      max-width="300"
                                      raised
                                    >
                                      <v-list
                                        v-if="projectDetail.technologies.length > 2"
                                        disabled
                                        shaped
                                      >
                                        <v-list-item-group
                                          v-model="projectDetail.technologies"
                                        >
                                          <v-list-item
                                            v-for="technologie in projectDetail.technologies.slice(2,projectDetail.technologies.length)"
                                            v-show="projectDetail.openProjectTechList"
                                            :key="technologie.id"
                                          >
                                            <v-avatar
                                              :color="`${randomColors()}`"
                                              size="30"
                                              style="padding:4px"
                                            >
                                              <strong class="white--text headline">{{ avatarNames(technologie.name) }}</strong>
                                            </v-avatar>
                                            <v-list-item-content class="ml-2">
                                              <v-list-item-title v-text="technologie.name" />
                                            </v-list-item-content>
                                          </v-list-item>
                                        </v-list-item-group>
                                      </v-list>
                                    </v-card>
                                  </v-menu>

                                </template>
                                <span>{{ item.name }}</span>
                              </v-tooltip>
                            </template>
                          </v-autocomplete>
                        </ValidationProvider>
                      </v-col>
                      <v-col md="8" class="p-b-0 addNewClient">

                        <div class="field">
                          <strong>Project Document Links *</strong>
                        </div>
                        <v-row v-for="(project, index) in projectDocuments" :key="index">
                          <v-col
                            md="12"
                          >
                            <ValidationProvider v-slot="{ errors }" :name="`projectLink-${++index}`" :rules="'required'">
                              <v-text-field
                                v-model.trim="project.link"
                                :error-messages="errors"
                                :placeholder="`Paste url here`"
                                dense
                                solo-inverted
                                :readonly="true"
                                rounded
                                hide-details
                              />
                            </ValidationProvider>
                          </v-col>
                        </v-row>
                      </v-col>
                    </v-row>
                  </v-card-text>
                </div>
              </v-card>
            </v-stepper-content>
          </div>
        </div>
      </v-stepper>
    </ValidationObserver>
  </div>
</template>

<script>
import Vue from 'vue'
import VueScrollTo from 'vue-scrollto'
import { mapGetters, mapActions } from 'vuex'
import Dialog from '@/components/Dialog.vue'
import CommonSnackbar from '@/components/CommonSnackbar'
import { projectHelpers } from '@/helpers/helper.js'
import CountryData from '@/configs/countryData.js'
Vue.use(CountryData)
Vue.use(VueScrollTo)

export default {
  name: 'CreationRequest',
  layout: 'authenticated',
  middleware: 'authenticated',
  components: {
  },
  data () {
    return {
      companyName: '',
      projectName: '',
      projectTypeId: null,
      governanceCategoryId: null,
      approvedHours: '',
      maximumHoursBilled: '',
      companyAddress: '',
      billingType: '',
      selectedDomains: [],
      userDetail: [],
      activeUserId: [],
      projectDocumentsLink: '',
      projectSummary: '',
      concerns: '',
      max: 0,
      model: 'Foobar',
      selected: [],
      selectedTechnologies: [],
      searchTech: '',
      searchAm: '',
      searchPm: '',
      fab: false,
      selectedManager: [],
      selectedProjectManager: [],
      projectDocuments: [],
      projectStatus: '',
      domainNameArray: [],
      searchDomain: null,
      newArray: [],
      formattedStringDate: null,
      editableProjectDetails: [],
      selectedArray: ['web', 'mobile', 'design', 'other'],
      techNameArray: [],
      projectLifeCycleModel: null,
      billingIntervalArray: [{ name: 'Weekly', value: 0 }, { name: 'Monthly', value: 1 }, { name: 'Fortnightly', value: 2 }],
      billingInterval: null,
      subProject: false,
      subProjectId: null,
      identifier: '',
      menu: '',
      Step1Error: false,
      Step2Error: false,
      Step3Error: false,
      Step4Error: false,
      generalDetailTab: 1,
      clientDetailTab: 2,
      timelineTab: 3,
      projectComponentTab: 4,
      e6: 1,
      toDatePicker: '',
      toTimelineDatePicker: null,
      toTimelineDateString: null,
      fromTimelineDatePicker: null,
      fromTimelineDateString: null,
      datePicker: [],
      dates: '',
      totalDays: '',
      newCountryData: CountryData,
      newStateData: [],
      companyState: '',
      companyCountry: '',
      searchClients: null,
      selectedClients: [],
      clientDetails: [],
      clientName: '',
      openProjectDomainList: false,
      openProjectClientList: false,
      openProjectAMList: false,
      openProjectPMList: false,
      openProjectTechList: false,
      billingMediumId: null
    }
  },
  computed: {
    ...mapGetters({
      projectDetail: 'project/getProjectDetail',
      technologies: 'project/getTechnologies',
      departments: 'project/getDepartments',
      projects: 'project/getProjectList',
      users: 'project/getUserList',
      isButtonLoading: 'project/isButtonLoading',
      getCustomDialog: 'project/getCustomDialog',
      getProjectDomains: 'project/getProjectDomains',
      billingTypes: 'project/getBillingTypes',
      projectTypes: 'project/getProjectType',
      governanceCategories: 'project/getGovernanceCategories',
      getProjectNameListing: 'project/getProjectNameListing',
      getRedminProjectNameList: 'project/getRedminProjectNameList',
      getProjectLifeCycleModel: 'project/getProjectLifeCycleModel',
      getProjectClients: 'project/getProjectClients',
      billingMediums: 'project/getBillingMediums'
    }),
    cardImg () {
      return require('@/assets/images/custom/creationCard.png')
    }
  },
  async fetch ({ app, store, route }) {
    // eslint-disable-next-line no-useless-catch
    try {
      await Promise.all([
        store.dispatch('project/fetchProjectList'),
        store.dispatch('project/fetchProjectDetail', route.params.id),
        store.dispatch('project/fetchProjectDomains'),
        store.dispatch('project/fetchTechnologies'),
        store.dispatch('project/fetchProjectNameListing'),
        store.dispatch('project/fetchRedmineProjectNameListing'),
        store.dispatch('project/fetchProjectLifeCycleModel'),
        store.dispatch('project/fetchProjectClients')
      ])
    } catch (error) {
      throw (error)
    }
  },

  mounted () {
    const initiationDate = new Date(this.projectDetail.initiation_date)

    this.formattedStringDate = initiationDate.toISOString().substr(0, 10)
    const formattedDate = initiationDate.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })
    let toTimelineDate = null
    let fromTimelineDate = null
    const domainIds = []

    if (this.projectDetail.estimated_timeline_to !== null) {
      toTimelineDate = new Date(this.projectDetail.estimated_timeline_to)
      this.toTimelineDatePicker = toTimelineDate.toISOString().substr(0, 10)
      this.toTimelineDateString = toTimelineDate.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })
    }
    if (this.projectDetail.estimated_timeline_from !== null) {
      fromTimelineDate = new Date(this.projectDetail.estimated_timeline_from)
      this.fromTimelineDatePicker = fromTimelineDate.toISOString().substr(0, 10)
      this.fromTimelineDateString = fromTimelineDate.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })
    }

    if (this.projectDetail.estimated_timeline_to !== null && this.projectDetail.estimated_timeline_from !== null) {
      let dateRange = []

      dateRange = [this.fromTimelineDateString, this.toTimelineDateString]
      this.dates = dateRange.join(' - ')
      this.totalDays = projectHelpers.totalDays(toTimelineDate, fromTimelineDate)
      this.datePicker = [this.toTimelineDatePicker, this.fromTimelineDatePicker]
    }
    this.projectDetail.project_domains.forEach((value) => domainIds.push(value.id))
    this.newArray = this.projectDetail.technologies.map(({ id, ...keepAttrs }) => id)
    const projectComponents = JSON.parse(this.projectDetail.project_components)
    const checkboxComponents = []

    JSON.parse(this.projectDetail.project_components).filter((value) => {
      if (this.selectedArray.includes(value)) {
        checkboxComponents.push(value)
      }
    })
    this.billingType = this.projectDetail.billing_type.id
    this.companyName = this.projectDetail.company_name
    this.projectName = this.projectDetail.project_name
    this.approvedHours = this.projectDetail.approved_hours
    this.companyAddress = this.projectDetail.company_address
    this.selected = checkboxComponents
    this.otherComponents = this.selected.includes('other') ? projectComponents[projectComponents.length - 1] : ''
    this.clientName = this.projectDetail.client_name
    this.selectedTechnologies = this.newArray
    this.selectedDomains = this.projectDetail.project_domains
    this.maximumHoursBilled = this.projectDetail.maximum_hours_billed
    this.toDatePicker = this.formattedStringDate
    this.projectDocumentsLink = this.projectDetail.project_documents_link
    this.concerns = this.projectDetail.specific_requests
    this.projectSummary = this.projectDetail.project_summary
    this.selectedManager = this.projectDetail.account_managers.map(({ user_id: id, ...keepAttrs }) => id)
    this.selectedProjectManager = this.projectDetail.project_managers.map(({ user_id: id, ...keepAttrs }) => id)
    this.clientDetails = JSON.parse(this.projectDetail.client_detail)
    this.setClientDeatil()
    this.projectDocuments = JSON.parse(this.projectDetail.project_documents_link)
    this.projectStatus = this.projectDetail.status
    this.projectTypeId = this.projectDetail.project_type_id
    this.governanceCategoryId = this.projectDetail.gov_category_id
    if (this.projectDetail.parent_id) {
      this.subProject = true
    } else {
      this.subProject = false
    }
    this.subProjectId = parseInt(this.projectDetail.parent_id)
    this.identifier = this.projectDetail.identifier
    this.projectLifeCycleModel = this.projectDetail.lifecycle_model_id
    this.companyCountry = this.projectDetail.country
    this.setResignValues ()
    this.companyState = this.projectDetail.state
    this.billingInterval = this.projectDetail.billing_interval
    this.billingMediumId = this.projectDetail.billing_medium
    this.getProjectDomains.forEach((item) => {
      this.domainNameArray.push(item.name)
    })
    this.technologies.forEach((item) => {
      this.techNameArray.push(item.name)
    })
    this.userDetail = this.users
    this.users.forEach((user) => {
      this.activeUserId.push(user.id)
    })
    const allManagers = this.projectDetail.account_managers.concat(this.projectDetail.project_managers)
    const inactiveUserDetail = []

    this.projectDetail.openProjectDomainList = this.openProjectDomainList
    this.projectDetail.openProjectClientList = this.openProjectClientList
    this.projectDetail.openProjectAMList = this.openProjectAMList
    this.projectDetail.openProjectPMList = this.openProjectPMList
    this.projectDetail.openProjectTechList = this.openProjectTechList

    allManagers.forEach((item) => {
      if (!this.activeUserId.includes(item.user_id)) {
        const userRecord = {
          id: item.user.id,
          full_name: item.user.display_name,
          email: item.user.email,
          employee_id: item.user.employee_id,
          job_title: null,
          dept: [],
          user_department:null
        }

        inactiveUserDetail.push(userRecord)
      }
    })
    this.userDetail = this.userDetail.concat(inactiveUserDetail)
  },
  methods: {
    ...mapActions({
      setProjectCreationData: 'project/setProjectCreationData',
      setCustomDialog: 'project/setCustomDialog',
      updateLoadingAction: 'project/updateLoadingAction'
    }),
    onScroll (e) {
      if (typeof window === 'undefined') {
        return
      }
      const top = window.pageYOffset || e.target.scrollTop || 0

      this.fab = top > 20
    },
    toTop () {
      this.$vuetify.goTo(0)
    },

    back () {
      this.$router.push('/project-dashboard')
    },
    randomColors () {
      return projectHelpers.randomColors()
    },
    avatarNames (fullName) {
      return projectHelpers.avatarNames(fullName)
    },
    setClientDeatil () {
      this.projectDetail.clientsArray = []
      if (Array.isArray(this.clientDetails) && this.clientDetails.length) {
        this.clientDetails.forEach((value, index) => {
          if (value['full_name'] !== '' || value['address'] !== '') {
            if (value['full_name'] !== null || value['address'] !== null) {
              const result = this.getProjectClients.filter((item) => {
                if (item['name'] === value['full_name'] && item['emails'] === value['address']) {
                  return item
                }
              })

              // if client info exist in client list
              if (Array.isArray(result) && result.length) {
                this.selectedClients.push(result[0].id)
                this.projectDetail.clientsArray.push(result[0])
              }
              else {   // if client info not exist in client list
                const clientLength = this.getProjectClients.length * 10
                const notExistClient = {
                  id: clientLength,
                  name: value['full_name'],
                  emails: value['address']
                }

                this.getProjectClients.push(notExistClient)
                this.selectedClients.push(notExistClient.id)
                this.projectDetail.clientsArray.push(notExistClient)
              }
            }
          }
        })
      }
    },

    setResignValues () {
      this.newStateData = projectHelpers.setResignArray(this.newCountryData, this.companyCountry)
      if (!this.companyCountry) {
        this.newStateData = []
      }
    }
  }
}
</script>

<style scoped>
.theme--light.v-stepper {
    background: #f2f5f8;
    box-shadow: none;
}
.v-application .mb-12 {
    margin-bottom: 16px !important;
}
.m-b-0 {
    margin-bottom: 0px!important;
}
.p-b-0 {
    padding-top: 0px!important;
    padding-bottom: 0px !important;
}
.theme--light.v-stepper {
    background: #f3f4f7;
}
.btn-color {
    background-color: #1976d2!important;
    color: #ffffff!important;
}
</style>
