<template>
  <div class="pt-4">
    <v-card
      class="mx-auto rounded-lg"
      style="padding:0px 10px 0px 10px"
    >
      <v-row>
        <v-col cols="12" md="3" style="margin-left:2%">
          <div class="filterHeading">
            Search Bar
          </div>
          <div style="width:85%">
            <v-text-field
              v-model="search"
              dense
              label="Type to search"
              solo
              append-icon="mdi-magnify"
              @input="filterActivityLog('search')"
            />
          </div>
        </v-col>
        <v-col cols="12" md="4" class="pl-0">
          <div class="filterHeading">
            Date Filter
          </div>
          <div>
            <v-row>
              <v-col class="filterPadding pr-1" cols="5">
                <v-menu
                  v-model="startDateMenu"
                  :close-on-content-click="false"
                >
                  <template v-slot:activator="{ on, attrs }">
                    <v-text-field
                      :value="(startDate) ? new Date(startDate).toLocaleDateString('en-US', {
                        year: 'numeric',
                        month: 'short',
                        day: 'numeric'
                      }) : ''"
                      v-bind="attrs"
                      dense
                      solo
                      label="Start Date"                      
                      readonly
                      v-on="on"
                    >
                      <template v-slot:append>
                        <v-icon v-on="on">
                          mdi-calendar
                        </v-icon>
                      </template>
                    </v-text-field>
                  </template>
                  <v-date-picker v-model="startDate" @change="filterActivityLog" @input="startDateMenu = false" />
                </v-menu>
              </v-col>
              <v-col class="filterPadding pl-1" cols="5">
                <v-menu
                  v-model="endDateMenu"
                  :close-on-content-click="false"
                >
                  <template v-slot:activator="{ on, attrs }">
                    <v-text-field
                      :value="(endDate) ? new Date(endDate).toLocaleDateString('en-US', {
                        year: 'numeric',
                        month: 'short',
                        day: 'numeric'
                      }) : ''"
                      v-bind="attrs"
                      dense
                      solo
                      label="End Date"                      
                      readonly
                      v-on="on"
                    >
                      <template v-slot:append>
                        <v-icon v-on="on">
                          mdi-calendar
                        </v-icon>
                      </template>
                    </v-text-field>
                  </template>
                  <v-date-picker v-model="endDate" :min="this.startDate" @change="filterActivityLog" @input="endDateMenu = false" />
                </v-menu>
              </v-col>
              <v-col style="padding-left:0px" class="filterPadding" cols="2">
                <v-btn
                  width="20px"
                  class="ma-2 reset"
                  tile
                  large
                  icon  
                  @click="filterActivityLog('reset')"
                >
                  <v-icon color="blue" class="mdi-24px">
                    mdi-refresh
                  </v-icon>
                </v-btn>
              </v-col>
            </v-row>
          </div>
        </v-col>
        <v-col cols="12" md="3">
          <div class="filterHeading">
            Action Type
          </div>
          <div>
            <v-select
              v-model="actionTypeId"
              :items="getActivityProjectType.filter((element) => { return element.active })"
              item-text="name"
              item-value="id"
              dense
              solo
              clearable
              label="Select Action Type"
              @change="filterActivityLog"
            />
          </div>
        </v-col>
      </v-row>
    </v-card>
    <v-card
      class="mx-auto rounded-lg pl-1 pr-1 mt-5"
    >
      <v-card-text>
        <div v-if="projectFormattedActivityLog.length">
          <v-expansion-panels :value="expandMonthAccordion" accordion hover flat>
            <v-expansion-panel
              v-for="(month, index) in projectFormattedActivityLog"
              :key="index"
              @click="updateSelectedAccordion('month', index)"
            >
              <v-expansion-panel-header expand-icon="mdi-arrow-down-drop-circle mdi-16px" style="width:auto">
                <span>{{ dayTitle(index, 'month') }}&nbsp;</span>
              </v-expansion-panel-header>
              <v-expansion-panel-content>
                <v-expansion-panels :value="expandDayAccordion" flat>
                  <v-expansion-panel
                    v-for="(day, point) in month"
                    :key="point"
                    @click="updateSelectedAccordion('date', point)"
                  >
                    <v-expansion-panel-header v-if="projectFormattedActivityLog[index][point]" style="width:auto">
                      <span><v-icon color="blue" class="mdi-24px">mdi-calendar</v-icon>&nbsp;{{ dayTitle(point, 'date') }}</span>
                    </v-expansion-panel-header>
                    <v-expansion-panel-content v-if="projectFormattedActivityLog[index][point]">
                      <div class="activityDiv">
                        <template v-for="(activity, ref) in day">
                          <v-list-item :key="ref" two-line>
                            <v-list-item-content>
                              <v-list-item-title><span style="color:#228FFB;font-size:15px">{{ activityTitle(activity) }}</span></v-list-item-title>
                              <v-list-item-subtitle v-if="activity.action_id !== 23">
                                <a class="detailAnchor" @click="viewDetailRedirect(activity.id)">View Details</a>
                              </v-list-item-subtitle>
                            </v-list-item-content>
                          </v-list-item>
                        </template>
                      </div>
                    </v-expansion-panel-content>
                  </v-expansion-panel>
                </v-expansion-panels>
              </v-expansion-panel-content>
            </v-expansion-panel>
          </v-expansion-panels>
        </div>
        <div v-else>
          <v-card
            class="mx-auto"
            width="100%"
          >
            <v-card-text style="text-align:center">
              <h3>
                <v-icon class="mdi-48px">
                  mdi-database
                </v-icon><br> No Activity Log Available.
              </h3>
            </v-card-text>
          </v-card>
        </div>
      </v-card-text>
    </v-card>
  </div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex'

export default {
  name: 'ActivityLOg',
  layout: 'authenticated',
  middleware: 'authenticated',
  data () {
    return {
      startDate: null,
      startDateMenu: false,
      endDate: null,
      endDateMenu: false,
      search: '',
      actionTypeId: null,
      projectFormattedActivityLog: [],
      monthMap: [],
      dateMap: [],
      expandMonthAccordion: null,
      expandDayAccordion: null,
      tempExpandMonthAccordionId: null,
      globalMonthName: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']
    }
  },
  computed: {
    ...mapGetters({
      getActivityProjectType: 'project/getActivityProjectType',
      getProjectActivityLog: 'project/getProjectActivityLog',
      getActivityLogAccordion: 'project/getActivityLogAccordion'
    })
  },
  async fetch ({ app, store, route }) {
    // eslint-disable-next-line no-useless-catch
    try {
      await store.dispatch('project/fetchProjectActivityLogs', route.params.id)
      await store.dispatch('project/fetchActivityProjectTypes')
    } catch (error) {
      throw (error)
    }
  },
  mounted () {
    const activityLog = [...this.getProjectActivityLog]
    const formatActivityLog = this.formatProjectActivityLogRecord(activityLog)

    this.projectFormattedActivityLog = formatActivityLog
    if (this.getActivityLogAccordion.month !== null) {
      this.expandMonthAccordion = this.getActivityLogAccordion.month
      this.tempExpandMonthAccordionId = this.expandMonthAccordion
    }
    if (this.getActivityLogAccordion.date !== null) {
      this.expandDayAccordion = this.getActivityLogAccordion.date
    }
  },
  methods: {
    ...mapActions({
      storeActivityLogAccordion: 'project/storeActivityLogAccordion'
    }),
    updateSelectedAccordion (type, index) {
      let accordion = {}

      if (type === 'month') {
        accordion = {
          'date': null,
          'month': index
        }
        this.tempExpandMonthAccordionId = index
      } else {
        accordion = {
          'date': index,
          'month': this.tempExpandMonthAccordionId
        }
      }
      this.storeActivityLogAccordion(accordion)
    },
    filterActivityLog (type) {
      if (type && type === 'reset') {
        this.startDate = null
        this.endDate = null
      }
      const activityLog = [...this.getProjectActivityLog]
      let filterRecord = activityLog

      if (!this.startDate && this.endDate) {
        this.startDate = this.endDate
      } else if (this.endDate && new Date(this.startDate).getTime() > new Date(this.endDate).getTime()) {
        this.endDate = this.startDate
      }
      if (this.actionTypeId && this.actionTypeId > 0) {
        filterRecord = filterRecord.filter((item) => { return parseInt(item.action_id) === this.actionTypeId })
      }
      if (this.startDate) {
        filterRecord = filterRecord.filter((item) => { return new Date(item.created_at).getTime() >= new Date(this.startDate).getTime() })
      }
      if (this.endDate) {
        filterRecord = filterRecord.filter((item) => { return new Date(this.parseDate(item.created_at, 'fullDate')).getTime() <= new Date(this.endDate).getTime() })
      }
      if (this.search !== '') {
        filterRecord = filterRecord.filter((item) => { return item.project_action_type.name.toLowerCase().includes(this.search.toLowerCase()) || item.action_id === this.search || item.created_by.display_name.toLowerCase().includes(this.search.toLowerCase()) })
      }
      const formatActivityLog = this.formatProjectActivityLogRecord(filterRecord)

      this.projectFormattedActivityLog = formatActivityLog
      if (type && type === 'search') {
        this.expandMonthAccordion = 0
        this.expandDayAccordion = 0
      }
    },
    viewDetailRedirect (activityId) {
      this.$router.push(`/project/${this.$route.params.id}/activity-log/${activityId}`)
    },
    dayTitle (index, day = 'date') {
      let title = ''

      if (day === 'month') {
        const month = String(this.monthMap[index]).padStart(6, 0)
        const mm = this.globalMonthName[parseInt(month.substring(0, 2)) - 1]
        const yy = parseInt(month.substring(2, 6))

        title = `${mm}, ${yy}`
      } else {
        const date = String(this.dateMap[index]).padStart(8, 0)
        const dd = date.substring(0, 2)
        const mm = this.globalMonthName[parseInt(date.substring(2, 4)) - 1]
        const yy = parseInt(date.substring(4, 8))

        title = `${dd} ${mm}, ${yy}`
      }

      return title
    },
    activityTitle (activity) {
      let title = ''
      const time = this.parseDate(activity.created_at, 'timeAmPm')

      if (activity.created_by !== null) {
        title = `${activity.project_action_type.name} by ${activity.created_by.display_name} | ${time}`
      } else {
        title = `${activity.project_action_type.name} | ${time}`
      }

      return title
    },
    formatProjectActivityLogRecord (data) {
      const formatRecord = []
      const finalResponse = []
      const existMonth = []
      const existDate = []

      if (data && data.length > 0) {
        let i = 0
        let ref = 0

        data.forEach((item) => {
          const createdMonth = this.parseDate(item.created_at, 'month')
          const createdYear = this.parseDate(item.created_at, 'year')
          const monthYear = parseInt(`${createdMonth}${createdYear}`)

          if (existMonth.includes(monthYear)) {
            const point = existMonth.indexOf(monthYear)

            formatRecord[point].push(item)
          } else {
            formatRecord[i] = [item]
            existMonth.push(monthYear)
            this.monthMap[i] = monthYear
            i++
          }
        })
        formatRecord.forEach((element, index) => {
          element.forEach((item) => {
            const dd = this.parseDate(item.created_at, 'date')
            const mm = this.parseDate(item.created_at, 'month')
            const yy = this.parseDate(item.created_at, 'year')
            const ddmmyy = parseInt(`${dd}${mm}${yy}`)

            if (finalResponse[index] && existDate.includes(ddmmyy)) {
              const point = existDate.indexOf(ddmmyy)

              finalResponse[index][point].push(item)
            } else if (finalResponse[index] && !existDate.includes(ddmmyy)) {
              existDate.push(ddmmyy)
              this.dateMap[ref] = ddmmyy
              finalResponse[index][ref] = [item]
              ref = ref + 1
            } else {
              const temp = []

              temp[ref] = [item]
              finalResponse[index] = temp
              existDate.push(ddmmyy)
              this.dateMap[ref] = ddmmyy
              ref = ref + 1
            }
          })
        })
      }

      return finalResponse
    },
    parseDate (date, type = 'fullDate') {
      let parseDate = new Date(date)
      const hour = String(parseDate.getHours()).padStart(2, '0')
      const min = String(parseDate.getMinutes()).padStart(2, '0')
      const dd = String(parseDate.getDate()).padStart(2, '0')
      const mm = String(parseDate.getMonth() + 1).padStart(2, '0')
      const yyyy = parseDate.getFullYear()
      let timeHour = parseInt(hour)
      let mid = 'AM'

      if (timeHour === 0) {
        timeHour = 12
      } else if (timeHour > 12) {
        timeHour = timeHour - 12
        mid = 'PM'
      }
      timeHour = String(timeHour).padStart(2, '0')
      if (type === 'time') {
        parseDate = hour + ':' + min
      } else if (type === 'timeAmPm') {
        parseDate = timeHour + ':' + min + ' ' + mid
      } else if (type === 'month') {
        parseDate = mm
      } else if (type === 'year') {
        parseDate = yyyy
      } else if (type === 'date') {
        parseDate = dd
      } else {
        parseDate = yyyy + '-' + mm + '-' + dd
      }

      return parseDate
    }
  }
}
</script>
<style scoped>
.v-application .filterHeading {
  margin-bottom: 6px;
  font-size:14px;
}
/* .v-application .filterPadding {
  padding-right: 5px;
  padding-top: 0px;
} */
.v-application .activityDiv {
  margin: 1%;
  border: 1px solid darkgray;
  border-radius: 25px;
  padding: 1%;
}
.v-application .detailAnchor {
  font-size: 13px;
  color: gray;
  text-decoration: none;
}
.divContainer {
  padding:0% 4% 4% 4%;
}
.v-application .activityDiv .v-list-item__title {
    line-height: normal;
}
>>>.v-expansion-panel-content__wrap {
  padding-bottom: 0% !important;
}
>>>.mdi-arrow-down-drop-circle::before {
  color:dodgerblue;
}
.reset {
  margin-left: 0px !important;
  margin-top: 0px !important;
}
>>>.v-text-field.v-text-field--solo .v-label {
  font-size: 15px;
}
>>> input {
  font-size: 15px;
}
>>>.v-select.v-input--dense .v-select__selection--comma {
  font-size: 15px;
}
</style>
