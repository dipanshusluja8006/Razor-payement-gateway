<template>
  <div class="divContainer">
    <v-row>
      <v-col cols="12">
        <v-card class="rounded-xl cardAlignment">
          <v-btn rounded color="primary" dark @click="redirectBack">
            <span style="font-size:13px">
              <v-icon class="mdi-18px">
                mdi-calendar
              </v-icon>
              {{ pageTitleDate }}
            </span>
          </v-btn>&nbsp;
          <span style="font-size:14px;color:#228FFB">{{ pageTitle }}</span>
        </v-card>
      </v-col>
    </v-row>
    <div v-if="(activeAction === constant.ACTIVITY_CODE.initiation_project || activeAction === constant.ACTIVITY_CODE.creation_project || activeAction === constant.ACTIVITY_CODE.initiation_request)">
      <common-activity-log :custom-data="projectActivityResponse" :header="(activeAction === constant.ACTIVITY_CODE.initiation_project) ? 'Project Initiation Details' : (activeAction === constant.ACTIVITY_CODE.creation_project) ? 'Project Creation Details' : 'Project Initiation Request Details'" />
    </div>
    <div v-else-if="(activeAction === constant.ACTIVITY_CODE.initiation_approval || activeAction === constant.ACTIVITY_CODE.initiation_request_edit || activeAction === constant.ACTIVITY_CODE.initiation_decline)">
      <common-activity-log :custom-data="projectActivityResponse" :header="(activeAction === constant.ACTIVITY_CODE.initiation_approval) ? 'Project Initiation Approval Details' : (activeAction === constant.ACTIVITY_CODE.initiation_request_edit) ? 'Project Initiation Request Edit Details' : 'Project Initiation Decline Details'" />
    </div>
    <div v-else-if="(activeAction === constant.ACTIVITY_CODE.update_project)">
      <common-activity-log :custom-data="projectActivityResponse" column="3" header="Updated Project Fields" />
    </div>
    <div v-else-if="(activeAction === constant.ACTIVITY_CODE.creation_requisition || activeAction === constant.ACTIVITY_CODE.edit_requisition)">
      <custom-data-table :header="(activeAction === constant.ACTIVITY_CODE.creation_requisition) ? 'Resource Requisition' : 'Edit Resource Requisition'" :table-header="requisitionHeader" :table-data="requisitionData" />
    </div>
    <div v-else-if="(activeAction === constant.ACTIVITY_CODE.edit_requisition || activeAction === constant.ACTIVITY_CODE.delete_requisition)">
      <custom-data-table :header="(activeAction === constant.ACTIVITY_CODE.edit_requisition) ? 'Edit Requisition' : 'Delete Requisition'" :table-header="requisitionHeader" :table-data="requisitionData" />
    </div>
    <div v-else-if="(activeAction === constant.ACTIVITY_CODE.edit_extension_requisition || activeAction === constant.ACTIVITY_CODE.delete_extension_requisition)">
      <custom-data-table :header="(activeAction === constant.ACTIVITY_CODE.edit_extension_requisition) ? 'Edit Extension Requisition' : 'Delete Extension Resource'" :table-header="mappingHeader" :table-data="mappingTableData" />
    </div>
    <div v-else-if="(activeAction === constant.ACTIVITY_CODE.creation_allocation || activeAction === constant.ACTIVITY_CODE.resource_reallocation || activeAction === constant.ACTIVITY_CODE.delete_reallocation)">
      <custom-data-table v-if="requisitionData.length" header="Resource Requisition" :table-header="requisitionAllocationHeader" :table-data="requisitionData" />
      <custom-data-table v-if="mappingTableData.length" header="Resource Extension Requisition" :table-header="extensionAllocationHeader" :table-data="mappingTableData" />
      <custom-data-table v-if="reAllocationTableData.length" header="Resource Allocation" :table-header="reAllocationHeader" :table-data="reAllocationTableData" />
      <custom-data-table :header="(activeAction === constant.ACTIVITY_CODE.creation_allocation ? 'Resource Allocation' : (activeAction === constant.ACTIVITY_CODE.resource_reallocation) ? 'Resource Re-Allocation' : 'Delete Reallocation')" :table-header="allocationHeader" :table-data="allocationTableData" />
    </div>
    <div v-else-if="(activeAction === constant.ACTIVITY_CODE.edit_allocation || activeAction === constant.ACTIVITY_CODE.edit_direct_allocation)">
      <custom-data-table v-if="requisitionData.length" header="Resource Requisition" :table-header="requisitionAllocationHeader" :table-data="requisitionData" />
      <custom-data-table v-if="mappingTableData.length" header="Resource Extension Requisition" :table-header="extensionAllocationHeader" :table-data="mappingTableData" />
      <custom-data-table v-if="allocationTableData.length" :header="(activeAction === constant.ACTIVITY_CODE.edit_allocation ? 'Edit Resource Allocation' : 'N/A')" :table-header="allocationHeader" :table-data="allocationTableData" />
      <custom-data-table v-if="directAllocationTableData.length" header="Edit Direct Allocation" :table-header="directAllocationHeader" :table-data="directAllocationTableData" />
    </div>
    <div v-else-if="(activeAction === constant.ACTIVITY_CODE.delete_allocation || activeAction === constant.ACTIVITY_CODE.delete_direct_allocation)">
      <custom-data-table v-if="requisitionData.length" header="Resource Requisition" :table-header="requisitionAllocationHeader" :table-data="requisitionData" />
      <custom-data-table v-if="mappingTableData.length" header="Resource Extension Requisition" :table-header="extensionAllocationHeader" :table-data="mappingTableData" />
      <custom-data-table v-if="allocationTableData.length" :header="(activeAction === constant.ACTIVITY_CODE.delete_allocation ? 'Delete Resource Allocation' : 'N/A')" :table-header="allocationHeader" :table-data="allocationTableData" />
      <custom-data-table v-if="directAllocationTableData.length" header="Delete Direct Allocation" :table-header="directAllocationHeader" :table-data="directAllocationTableData" />
    </div>
    <div v-else-if="(activeAction === constant.ACTIVITY_CODE.resource_allocation_response_accept || activeAction === constant.ACTIVITY_CODE.resource_allocation_response_decline)">
      <custom-data-table v-if="requisitionData.length" header="Resource Requisition" :table-header="requisitionAllocationHeader" :table-data="requisitionData" />
      <custom-data-table v-if="extensionAllocationHeaderData.length" header="Resource Extension Requisition" :table-header="extensionAllocationHeader" :table-data="extensionAllocationHeaderData" />
      <custom-data-table :header="(activeAction === constant.ACTIVITY_CODE.resource_allocation_response_accept ? 'Approved Resource' : 'Declined Resource')" :table-header="mappingHeader" :table-data="mappingTableData" />
    </div>
    <div v-else-if="(activeAction === constant.ACTIVITY_CODE.resource_extension)">
      <custom-data-table header="Extended Resource" :table-header="extensionHeader" :table-data="mappingTableData" />
    </div>
    <div v-else-if="(activeAction === constant.ACTIVITY_CODE.resource_mapping)">
      <custom-data-table :header="(activeAction === constant.ACTIVITY_CODE.resource_mapping) ? 'Resource Mapped' : 'N/A'" :table-header="mappingHeader" :table-data="mappingTableData" />
    </div>
    <div v-else-if="(activeAction === constant.ACTIVITY_CODE.resource_deallocation || activeAction === constant.ACTIVITY_CODE.resource_unmapping)">
      <custom-data-table :header="(activeAction === constant.ACTIVITY_CODE.resource_deallocation) ? 'Resource Deallocate' : 'Resource Unmapped'" :table-header="deallocationHeader" :table-data="deallocateTableData" />
    </div>
    <div v-else-if="(activeAction === constant.ACTIVITY_CODE.hold_request || activeAction === constant.ACTIVITY_CODE.project_on_hold_request_accept || activeAction === constant.ACTIVITY_CODE.project_on_hold_rejection)">
      <common-activity-log :custom-data="projectActivityResponse" column="4" :header="(activeAction === constant.ACTIVITY_CODE.hold_request) ? 'On-Hold Request Detail' : (activeAction === constant.ACTIVITY_CODE.project_on_hold_request_accept) ? 'On-Hold Approval Detail' : 'On-Hold Decline Detail'" />
    </div>
    <div v-else-if="(activeAction === constant.ACTIVITY_CODE.project_restart)">
      <common-activity-log :custom-data="projectActivityResponse" column="6" header="Project Restart Details" />
    </div>
    <div v-else-if="(activeAction === constant.ACTIVITY_CODE.direct_resource_allocation)">
      <custom-data-table header="Direct Allocation" :table-header="directAllocationHeader" :table-data="directAllocationTableData" />
    </div>
    <div v-else-if="(activeAction === constant.ACTIVITY_CODE.auto_extension)">
      <custom-data-table header="Project Auto Extension" :table-header="autoExtensionHeader" :table-data="autoExtensionTableData" />
    </div>
    <div v-else-if="(activeAction === constant.ACTIVITY_CODE.reject_requisition)">
      <custom-data-table header="Reject Requisition" :table-header="rejectRequisitionHeader" :table-data="rejectRequisitionTableData" />
    </div>
    <div v-else>
      <v-card
        class="mx-auto"
      >
        <v-card-text style="text-align:center">
          <h3>
            <v-icon class="mdi-48px">
              mdi-database
            </v-icon><br> No Data Available to display for the Activity Log
          </h3>
        </v-card-text>
      </v-card>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import CommonActivityLog from '@/components/CommonActivityLog'
import CustomDataTable from '@/components/CustomDataTable'
import constant from '@/constants/closure-checklist.js'

export default {
  name: 'ActivityLogDetail',
  layout: 'authenticated',
  middleware: 'authenticated',
  components: {
    CommonActivityLog,
    CustomDataTable
  },
  data () {
    return {
      constant,
      activeAction: null,
      projectActivityDetail: null,
      pageTitle: '',
      pageTitleDate: '',
      projectActivityResponse: null,
      requisitionHeader: [
        { text: 'Department', value: 'department', sortable: true, width: '10%' },
        { text: 'Role', value: 'role', sortable: true },
        { text: 'Technology', value: 'technology', sortable: true, width: '10%' },
        { text: 'No of Resources', value: 'no_of_resource', sortable: true, width: '9%' },
        { text: 'Daily Efforts (Hours)', value: 'efforts', sortable: true, width: '8%' },
        { text: 'Experience', value: 'experience', sortable: true },
        { text: 'Start Date', value: 'start_date', sortable: true },
        { text: 'End Date', value: 'end_date', sortable: true },
        { text: 'Billing Type', value: 'billing_type', sortable: false },
        { text: 'Suggested Resource', value: 'suggested', sortable: false }
      ],
      requisitionData: [],
      requisitionAllocationHeader: [
        { text: 'Department', value: 'department', sortable: true, width: '10%' },
        { text: 'Role', value: 'role', sortable: true },
        { text: 'Technology', value: 'technology', sortable: true, width: '10%' },
        { text: 'No of Resources', value: 'no_of_resource', sortable: true, width: '9%' },
        { text: 'Daily Efforts (Hours)', value: 'efforts', sortable: true, width: '8%' },
        { text: 'Experience', value: 'experience', sortable: true, width: '9%' },
        { text: 'Start Date', value: 'start_date', sortable: true, width: '8%' },
        { text: 'End Date', value: 'end_date', sortable: true, width: '8%' },
        { text: 'Billing Type', value: 'billing_type', sortable: false },
        { text: 'Suggested Resource', value: 'suggested', sortable: false },
        { text: 'Requested By', value: 'requested_by', sortable: false },
        { text: 'Requested On', value: 'requested_on', sortable: false }
      ],
      extensionAllocationHeader: [
        { text: 'Resource Name', sortable: true, value: 'resource_name', width: '11%' },
        { text: 'Department', value: 'department', sortable: true, width: '9%' },
        { text: 'Role', value: 'role', sortable: true },
        { text: 'Technology', value: 'technology', sortable: true, width: '10%' },
        { text: 'No of Resources', value: 'no_of_resource', sortable: true },
        { text: 'Daily Efforts (Hours)', value: 'efforts', sortable: true, width: '8%' },
        { text: 'Experience', value: 'experience', sortable: true, width: '9%' },
        { text: 'Start Date', value: 'start_date', sortable: true, width: '8%' },
        { text: 'End Date', value: 'end_date', sortable: true, width: '8%' },
        { text: 'Billing Type', value: 'billing_type', sortable: false },
        { text: 'Requested By', value: 'requested_by', sortable: false },
        { text: 'Requested On', value: 'requested_on', sortable: false }
      ],
      extensionAllocationHeaderData: [],
      allocationHeader: [
        { text: 'Resource Name', sortable: true, value: 'resource_name' },
        { text: 'Department', sortable: true, value: 'department' },
        { text: 'Technology', value: 'technology', sortable: true },
        { text: 'Role', sortable: true, value: 'role' },
        { text: 'Daily Efforts (Hours)', value: 'efforts', sortable: true },
        { text: 'Experience', value: 'experience', sortable: true },
        { text: 'Start Date', value: 'start_date', sortable: true },
        { text: 'End Date', value: 'end_date', sortable: true }
      ],
      allocationTableData: [],
      reAllocationHeader: [
        { text: 'Resource Name', sortable: true, value: 'resource_name' },
        { text: 'Department', sortable: true, value: 'department' },
        { text: 'Technology', value: 'technology', sortable: true },
        { text: 'Role', sortable: true, value: 'role' },
        { text: 'Daily Efforts (Hours)', value: 'efforts', sortable: true },
        { text: 'Experience', value: 'experience', sortable: true },
        { text: 'Start Date', value: 'start_date', sortable: true },
        { text: 'End Date', value: 'end_date', sortable: true },
        { text: 'Status', value: 'status', sortable: false }
      ],
      reAllocationTableData: [],
      mappingHeader: [
        { text: 'Resource Name', sortable: true, value: 'resource_name' },
        { text: 'Department', sortable: true, value: 'department' },
        { text: 'Technology', value: 'technology', sortable: true },
        { text: 'Role', sortable: true, value: 'role' },
        { text: 'Daily Efforts (Hours)', value: 'efforts', sortable: true },
        { text: 'Experience', value: 'experience', sortable: true },
        { text: 'Start Date', value: 'start_date', sortable: true },
        { text: 'End Date', value: 'end_date', sortable: true },
        { text: 'Billing Type', value: 'billing_type', sortable: false }
      ],
      mappingTableData: [],
      deallocationHeader: [
        { text: 'Resource Name', sortable: true, value: 'resource_name' },
        { text: 'Department', sortable: true, value: 'department' },
        { text: 'Technology', value: 'technology', sortable: true },
        { text: 'Role', sortable: true, value: 'role' },
        { text: 'Daily Efforts (Hours)', value: 'efforts', sortable: true, width: '8%' },
        { text: 'Start Date', value: 'start_date', sortable: true },
        { text: 'End Date', value: 'end_date', sortable: true },
        { text: 'Billing Type', value: 'billing_type', sortable: false },
        { text: 'Deallocate For (In Hours)', value: 'deallocate_for', sortable: false, width: '8%' },
        { text: 'Deallocate From (date)', value: 'deallocate_from', sortable: false, width: '8%' }
      ],
      deallocateTableData: [],
      directAllocationHeader: [
        { text: 'Resource Name', value: 'resource_name', sortable: true },
        { text: 'Department', value: 'department', sortable: true },
        { text: 'Role', value: 'role', sortable: true },
        { text: 'Technology', value: 'technology', sortable: true },
        { text: 'Daily Efforts (Hours)', value: 'efforts', sortable: true, width: '8%' },
        { text: 'Experience', value: 'experience', sortable: true },
        { text: 'Start Date', value: 'start_date', sortable: true },
        { text: 'End Date', value: 'end_date', sortable: true },
        { text: 'Billing Type', value: 'billing_type', sortable: false }
      ],
      directAllocationTableData: [],
      extensionHeader: [
        { text: 'Resource Name', sortable: true, value: 'resource_name' },
        { text: 'Department', sortable: true, value: 'department' },
        { text: 'Technology', value: 'technology', sortable: true },
        { text: 'Role', sortable: true, value: 'role' },
        { text: 'Daily Efforts (Hours)', value: 'efforts', sortable: true },
        { text: 'Experience', value: 'experience', sortable: true },
        { text: 'Start Date', value: 'start_date', sortable: true },
        { text: 'End Date', value: 'end_date', sortable: true },
        { text: 'Billing Type', value: 'billing_type', sortable: false },
        { text: 'Extend For', value: 'extend_for', sortable: false },
        { text: 'Extend From', value: 'extend_from', sortable: false },
        { text: 'Extend To', value: 'extend_to', sortable: false }
      ],
      autoExtensionHeader: [
        { text: 'Project Name', value: 'projectName', sortable: true },
        { text: 'Resource Name', value: 'resourceName', sortable: true },
        { text: 'Booking ExpiredOn', value: 'PlanedEndDate', sortable: true },
        { text: 'Extended Days', value: 'ExtendedDays', sortable: true },
        { text: 'Extended End Date', value: 'ExtendedEndDate', sortable: true, width: '8%' },
        { text: 'Department', value: 'department', sortable: true }
      ],
      autoExtensionTableData: [],
      rejectRequisitionTableData: [],
      rejectRequisitionHeader: [
        { text: 'Rejected By', value: 'rejected_by', sortable: false },
        { text: 'Department', value: 'department', sortable: true },
        { text: 'Role', value: 'role', sortable: true },
        { text: 'Technology', value: 'technology', sortable: true },
        { text: 'Daily Efforts (Hours)', value: 'efforts', sortable: true, width: '8%' },
        { text: 'Experience', value: 'experience', sortable: true },
        { text: 'Start Date', value: 'start_date', sortable: true },
        { text: 'End Date', value: 'end_date', sortable: true },
        { text: 'Billing Type', value: 'billing_type', sortable: false },
        { text: 'Suggested Resource', value: 'suggested', sortable: false },
        { text: 'Reason', value: 'reason', sortable: false },
        { text: 'Other Reason', value: 'other_reason', sortable: false },
        { text: 'Tentative Date', value: 'tentative_date', sortable: false }

      ],
      rejectedBy: '',
      globalMonthName: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']
    }
  },
  computed: {
    ...mapGetters({
      getProjectActivityLog: 'project/getProjectActivityLog'
    })
  },
  mounted () {
    this.$nuxt.$emit('headerTitle', 'Activity Logs')
    const activityDetail = this.getProjectActivityLog.find((item) => { return item.id === parseInt(this.$route.params.id) })

    this.activeAction = activityDetail.project_action_type.code
    this.rejectedBy = activityDetail.created_by.display_name
    this.projectActivityDetail = activityDetail
    this.pageTitle = this.activityTitle(activityDetail)
    const dd = this.parseDate(activityDetail.created_at, 'date')
    const mm = this.globalMonthName[parseInt(this.parseDate(activityDetail.created_at, 'month')) - 1]
    const yy = this.parseDate(activityDetail.created_at, 'year')

    this.pageTitleDate = `${dd} ${mm}, ${yy}`
    const responseLog = JSON.parse(activityDetail.response)

    if (this.activeAction === constant.ACTIVITY_CODE.initiation_project || this.activeAction === constant.ACTIVITY_CODE.creation_project || this.activeAction === constant.ACTIVITY_CODE.initiation_request || this.activeAction === constant.ACTIVITY_CODE.initiation_approval || this.activeAction === constant.ACTIVITY_CODE.initiation_request_edit || this.activeAction === constant.ACTIVITY_CODE.initiation_decline) {
      const domains = Array.prototype.map.call(responseLog.project_domains, (s) => s.name).join(' , ')
      const technologies = Array.prototype.map.call(responseLog.technologies, (s) => s.name).join(' , ')
      const accountManager = Array.prototype.map.call(responseLog.account_managers, (s) => s.user.display_name).join(' , ')
      const projectManager = Array.prototype.map.call(responseLog.project_managers, (s) => s.user.display_name).join(' , ')
      const clientDetail = JSON.parse(responseLog.client_detail)
      const documentLink = JSON.parse(responseLog.project_documents_link)
      const record = {
        'Project Name': responseLog.project_name,
        'Project Summary': responseLog.project_summary,
        'Project Type': (responseLog.project_type) ? responseLog.project_type.name : '',
        'Governance Category': (responseLog.governance_category) ? responseLog.governance_category.name : '',
        'Project Domain': domains,
        'Total Approved Hours': (responseLog.approved_hours) ? responseLog.approved_hours : '',
        'Maximum Hours Billed': (responseLog.maximum_hours_billed) ? responseLog.maximum_hours_billed : '',
        'Company Name': responseLog.company_name,
        'Company Address': responseLog.company_address,
        'Technologies': technologies,
        'Estimated Timeline From': (responseLog.estimated_timeline_from) ? responseLog.estimated_timeline_from : '',
        'Estimated Timeline To': (responseLog.estimated_timeline_to) ? responseLog.estimated_timeline_to : '',
        'Initiation Date': (responseLog.initiation_date) ? responseLog.initiation_date : '',
        'Client Name': (clientDetail && clientDetail[0].full_name) ? clientDetail[0].full_name : '',
        'Client Email Address': (clientDetail && clientDetail[0].address) ? clientDetail[0].address : '',
        'Project Document Link': (documentLink) ? documentLink[0].link : '',
        'Any Specific Set of requests/concerns': responseLog.specific_requests,
        'Assigned Account Manager(s)': accountManager,
        'Assigned Project Manager(s)': projectManager,
        'Comment': (responseLog.comment) ? responseLog.comment : ''
      }

      this.projectActivityResponse = record
    } else if (this.activeAction === constant.ACTIVITY_CODE.update_project) {
      this.projectActivityResponse = responseLog
    } else if (this.activeAction === constant.ACTIVITY_CODE.creation_requisition) {
      const requisition = []
      
      if (responseLog.length) {
        responseLog.forEach((record) => {
          const suggestedResources = record.suggested_resource.length ? record.suggested_resource.replace(/[^a-zA-Z ]/g, ',').split(',') : []
          const suggestedArray = []

          suggestedResources.forEach((item) => {
            if (item.length > 0) {
              suggestedArray.push(item)
            }
          })
          requisition.push({
            department: record.department,
            role: record.role_name,
            technology: record.tech_name,
            no_of_resource: record.no_of_resource,
            efforts: record.efforts,
            experience: record.experience,
            start_date: new Date(record.start_date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
            end_date: new Date(record.end_date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
            billing_type: record.billing_type,
            suggested: suggestedArray.length ? suggestedArray : 'NA'
          })
        })
      }
      this.requisitionData = requisition
    } else if (this.activeAction === constant.ACTIVITY_CODE.creation_allocation || this.activeAction === constant.ACTIVITY_CODE.resource_reallocation || this.activeAction === constant.ACTIVITY_CODE.delete_reallocation) {
      const allocationData = []
      const requisitionRecord = []
      const extensionRequisition = []
      const requisitionExists = []
      const reallocation = []

      if (responseLog.length) {
        responseLog.forEach((allocation) => {
          const suggestedResources = allocation.resource_requisition.suggested_resource.length ? allocation.resource_requisition.suggested_resource.replace(/[^a-zA-Z ]/g, ',').split(',') : []
          const suggestedArray = []

          suggestedResources.forEach((item) => {
            if (item.length > 0) {
              suggestedArray.push(item)
            }
          })
          if (!requisitionExists.includes(allocation.resource_req_id)) {
            if (allocation.type === 1) {
              extensionRequisition.push({
                resource_name: (allocation.resource_requisition.resource) ? allocation.resource_requisition.resource.display_name : 'N/A',
                department: (typeof (allocation.department) === 'object') ? allocation.department.name : allocation.department,
                role: allocation.role_name,
                technology: allocation.tech_name,
                no_of_resource: allocation.resource_requisition.no_of_resource,
                efforts: allocation.resource_requisition.efforts,
                experience: allocation.resource_requisition.experience,
                start_date: new Date(allocation.resource_requisition.start_date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
                end_date: new Date(allocation.resource_requisition.end_date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
                billing_type: (allocation.resource_requisition.billing_type === 1) ? 'Billable' : 'Non-Billable',
                requested_by: (allocation.resource_requisition.requested_user) ? allocation.resource_requisition.requested_user.display_name : '',
                requested_on: new Date(allocation.resource_requisition.created_at).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })
              })
            } else {
              requisitionRecord.push({
                department: (typeof (allocation.department) === 'object') ? allocation.department.name : allocation.department,
                role: allocation.role_name,
                technology: allocation.tech_name,
                no_of_resource: allocation.resource_requisition.no_of_resource,
                efforts: allocation.resource_requisition.efforts,
                experience: allocation.resource_requisition.experience,
                start_date: new Date(allocation.resource_requisition.start_date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
                end_date: new Date(allocation.resource_requisition.end_date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
                billing_type: (allocation.resource_requisition.billing_type === 1) ? 'Billable' : 'Non-Billable',
                suggested: suggestedArray.length ? suggestedArray : 'NA',
                requested_by: (allocation.resource_requisition.requested_user) ? allocation.resource_requisition.requested_user.display_name : '',
                requested_on: new Date(allocation.resource_requisition.created_at).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })
              })
            }
            requisitionExists.push(allocation.resource_req_id)
          }
          if (this.activeAction === constant.ACTIVITY_CODE.resource_reallocation) {
            if (allocation.resource_allocation && allocation.resource_allocation.resource_allocation.length) {
              allocation.resource_allocation.resource_allocation.forEach((element) => {
                if (element.allocation_status !== constant.PROJECT_STATUS.RESOURCE_ALLOCATION_RESPONSE_DECLINE) {
                  reallocation.push({
                    resource_name: element.resource_allocation_meta[0].resource.display_name,
                    department: (typeof (allocation.department) === 'object') ? allocation.department.name : allocation.department,
                    technology: allocation.tech_name,
                    role: allocation.role_name,
                    efforts: element.resource_allocation_meta[0].hours,
                    experience: element.experience,
                    start_date: new Date(element.resource_allocation_meta[0].start_date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
                    end_date: new Date(element.resource_allocation_meta[0].end_date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
                    status: (element.allocation_status === 14) ? 'Fully Allocated' : 'Partial Allocated'
                  })
                }
              })
            }
          }
          allocationData.push({
            resource_name: allocation.resource_name,
            department: (typeof (allocation.department) === 'object') ? allocation.department.name : allocation.department,
            technology: allocation.tech_name,
            role: allocation.role_name,
            efforts: allocation.efforts,
            experience: allocation.experience,
            start_date: new Date(allocation.start_date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
            end_date: new Date(allocation.end_date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })
          })
        })
      }
      this.allocationTableData = allocationData
      this.requisitionData = requisitionRecord
      this.mappingTableData = extensionRequisition
      this.reAllocationTableData = reallocation
    } else if (this.activeAction === constant.ACTIVITY_CODE.edit_allocation || this.activeAction === constant.ACTIVITY_CODE.delete_allocation || this.activeAction === constant.ACTIVITY_CODE.edit_direct_allocation || this.activeAction === constant.ACTIVITY_CODE.delete_direct_allocation) {
      const directResource = []
      const allocationData = []
      const requisitionRecord = []
      const extensionRequisition = []
      const requisitionExists = []

      if (responseLog.length) {
        responseLog.forEach((allocation) => {
          const suggestedResources = allocation.resource_requisition.suggested_resource.length ? allocation.resource_requisition.suggested_resource.replace(/[^a-zA-Z ]/g, ',').split(',') : []
          const suggestedArray = []

          suggestedResources.forEach((item) => {
            if (item.length > 0) {
              suggestedArray.push(item)
            }
          })
          if (allocation.directAllocateResource) {
            directResource.push({
              resource_name: allocation.resource_name,
              department: allocation.department,
              role: allocation.role_name,
              technology: allocation.tech_name,
              efforts: allocation.efforts,
              experience: allocation.experience,
              start_date: new Date(allocation.start_date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
              end_date: new Date(allocation.end_date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
              billing_type: allocation.billing_type
            })
          } else {
            if (!requisitionExists.includes(allocation.resource_req_id)) {
              if (allocation.resource_requisition.type === 1) {
                extensionRequisition.push({
                  resource_name: (allocation.resource_requisition.resource) ? allocation.resource_requisition.resource.display_name : 'N/A',
                  department: (typeof (allocation.department) === 'object') ? allocation.department.name : allocation.department,
                  role: allocation.role_name,
                  technology: allocation.tech_name,
                  no_of_resource: allocation.resource_requisition.no_of_resource,
                  efforts: allocation.resource_requisition.efforts,
                  experience: allocation.resource_requisition.experience,
                  start_date: new Date(allocation.resource_requisition.start_date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
                  end_date: new Date(allocation.resource_requisition.end_date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
                  billing_type: (allocation.resource_requisition.billing_type === 1) ? 'Billable' : 'Non-Billable',
                  requested_by: (allocation.resource_requisition.requested_user) ? allocation.resource_requisition.requested_user.display_name : '',
                  requested_on: new Date(allocation.resource_requisition.created_at).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })
                })
              } else {
                requisitionRecord.push({
                  department: (typeof (allocation.department) === 'object') ? allocation.department.name : allocation.department,
                  role: allocation.role_name,
                  technology: allocation.tech_name,
                  no_of_resource: allocation.resource_requisition.no_of_resource,
                  efforts: allocation.resource_requisition.efforts,
                  experience: allocation.resource_requisition.experience,
                  start_date: new Date(allocation.resource_requisition.start_date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
                  end_date: new Date(allocation.resource_requisition.end_date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
                  billing_type: (allocation.resource_requisition.billing_type === 1) ? 'Billable' : 'Non-Billable',
                  suggested: suggestedArray.length ? suggestedArray : 'NA',
                  requested_by: (allocation.resource_requisition.requested_user) ? allocation.resource_requisition.requested_user.display_name : '',
                  requested_on: new Date(allocation.resource_requisition.created_at).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })
                })
              }
              requisitionExists.push(allocation.resource_req_id)
            }
            allocationData.push({
              resource_name: allocation.resource_name,
              department: (typeof (allocation.department) === 'object') ? allocation.department.name : allocation.department,
              technology: allocation.tech_name,
              role: allocation.role_name,
              efforts: allocation.efforts,
              experience: allocation.experience,
              start_date: new Date(allocation.start_date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
              end_date: new Date(allocation.end_date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })
            })
          }
        })
      }
      this.allocationTableData = allocationData
      this.requisitionData = requisitionRecord
      this.mappingTableData = extensionRequisition
      this.directAllocationTableData = directResource
    } else if (this.activeAction === constant.ACTIVITY_CODE.resource_mapping) {
      const mapResource = []

      if (responseLog.length) {
        responseLog.forEach((item) => {
          mapResource.push({
            resource_name: item.resource_name,
            department: item.dept,
            technology: item.tech,
            role: item.designation,
            efforts: item.efforts,
            experience: item.experience,
            billing_type: item.billing_type,
            start_date: item.start_date,
            end_date: item.end_date
          })
        })
      }
      this.mappingTableData = mapResource
    } else if (this.activeAction === constant.ACTIVITY_CODE.resource_allocation_response_accept || this.activeAction === constant.ACTIVITY_CODE.resource_allocation_response_decline) {
      const suggestedResources = responseLog.resource_requisition.suggested_resource.length ? responseLog.resource_requisition.suggested_resource.replace(/[^a-zA-Z ]/g, ',').split(',') : []
      const suggestedArray = []

      suggestedResources.forEach((item) => {
        if (item.length > 0) {
          suggestedArray.push(item)
        }
      })
      const requisition = {
        resource_name: (responseLog.resource_requisition.resource) ? responseLog.resource_requisition.resource.display_name : '',
        department: responseLog.deptartment,
        role: responseLog.role_name,
        technology: responseLog.tech_name,
        no_of_resource: responseLog.resource_requisition.no_of_resource,
        efforts: responseLog.resource_requisition.efforts,
        experience: responseLog.resource_requisition.experience,
        start_date: new Date(responseLog.resource_requisition.start_date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
        end_date: new Date(responseLog.resource_requisition.end_date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
        billing_type: (responseLog.resource_requisition.billing_type === 1) ? 'Billable' : 'Non-Billable',
        suggested: suggestedArray.length ? suggestedArray : 'NA',
        requested_by: (responseLog.resource_requisition.requested_user) ? responseLog.resource_requisition.requested_user.display_name : '',
        requested_on: new Date(responseLog.resource_requisition.created_at).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })
      }
      const allocation = {
        resource_name: responseLog.resource_name,
        department: responseLog.deptartment,
        technology: responseLog.tech_name,
        role: responseLog.role_name,
        efforts: responseLog.efforts,
        experience: responseLog.experience,
        billing_type: responseLog.billing_type,
        start_date: new Date(responseLog.start_date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
        end_date: new Date(responseLog.end_date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })
      }

      this.mappingTableData = [allocation]
      if (responseLog.resource_requisition.type === 1) {
        this.extensionAllocationHeaderData = [requisition]
      } else {
        this.requisitionData = [requisition]
      }
    } else if (this.activeAction === constant.ACTIVITY_CODE.resource_extension) {
      const requisition = []

      if (responseLog.length) {
        responseLog.forEach((record) => {
          requisition.push({
            resource_name: record.resource_name,
            department: record.department,
            role: record.role,
            technology: record.technology,
            extend_for: record.efforts,
            experience: record.experience,
            extend_from: new Date(record.start_date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
            extend_to: new Date(record.end_date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
            billing_type: record.billing_type,
            efforts: record.allocation_efforts,
            start_date: new Date(record.allocation_start_date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
            end_date: new Date(record.allocation_end_date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })
          })
        })
      }
      this.mappingTableData = requisition
    } else if (this.activeAction === constant.ACTIVITY_CODE.resource_deallocation || this.activeAction === constant.ACTIVITY_CODE.resource_unmapping) {
      const deallocate = []

      if (responseLog.length) {
        responseLog.forEach((record) => {
          deallocate.push({
            resource_name: record.resource_name,
            department: record.dept,
            role: record.designation,
            technology: record.tech,
            efforts: record.efforts,
            start_date: new Date(record.start_date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
            end_date: new Date(record.end_date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
            billing_type: record.billing_type,
            deallocate_for: record.deallocate_for,
            deallocate_from: new Date(record.deallocate_from).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })
          })
        })
      }
      this.deallocateTableData = deallocate
    } else if (this.activeAction === constant.ACTIVITY_CODE.edit_requisition || this.activeAction === constant.ACTIVITY_CODE.delete_requisition) {
      const requisition = []

      if (responseLog.length) {
        responseLog.forEach((record) => {
          const suggestedResources = record.suggested_resource.length ? record.suggested_resource.replace(/[^a-zA-Z ]/g, ',').split(',') : []
          const suggestedArray = []

          suggestedResources.forEach((item) => {
            if (item.length > 0) {
              suggestedArray.push(item)
            }
          })
          requisition.push({
            department: record.department,
            role: record.Designation,
            technology: record.Tech,
            no_of_resource: record.no_of_resource,
            efforts: record.efforts,
            experience: record.experience,
            start_date: new Date(record.start_date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
            end_date: new Date(record.end_date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
            billing_type: record.billing_type,
            suggested: suggestedArray.length ? suggestedArray : 'NA'
          })
        })
      }
      this.requisitionData = requisition
    } else if (this.activeAction === constant.ACTIVITY_CODE.edit_extension_requisition || this.activeAction === constant.ACTIVITY_CODE.delete_extension_requisition) {
      const requisition = []

      if (responseLog.length) {
        responseLog.forEach((record) => {
          const suggestedResources = record.suggested_resource.length ? record.suggested_resource.replace(/[^a-zA-Z ]/g, ',').split(',') : []
          const suggestedArray = []

          suggestedResources.forEach((item) => {
            if (item.length > 0) {
              suggestedArray.push(item)
            }
          })
          requisition.push({
            resource_name: record.extension_resource_name,
            department: record.department,
            role: record.Designation,
            technology: record.Tech,
            no_of_resource: record.no_of_resource,
            efforts: record.efforts,
            experience: record.experience,
            start_date: new Date(record.start_date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
            end_date: new Date(record.end_date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
            billing_type: record.billing_type,
            suggested: suggestedArray.length ? suggestedArray : 'NA'
          })
        })
      }
      this.mappingTableData = requisition
    } else if (this.activeAction === constant.ACTIVITY_CODE.direct_resource_allocation) {
      const directAllocation = []

      if (responseLog.length) {
        responseLog.forEach((record) => {
          directAllocation.push({
            resource_name: record.resource_name,
            department: record.department,
            role: record.role_name,
            technology: record.tech_name,
            efforts: record.efforts,
            experience: record.experience,
            start_date: new Date(record.start_date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
            end_date: new Date(record.end_date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
            billing_type: record.billing_type
          })
        })
      }
      this.directAllocationTableData = directAllocation
    } else if (this.activeAction === constant.ACTIVITY_CODE.hold_request || this.activeAction === constant.ACTIVITY_CODE.project_on_hold_request_accept || this.activeAction === constant.ACTIVITY_CODE.project_on_hold_rejection) {
      const onHold = {
        'On-Hold Reason': responseLog.comment,
        'On-Hold From': new Date(responseLog.from).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
        'On-Hold To': new Date(responseLog.to).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })
      }

      this.projectActivityResponse = onHold
    } else if (this.activeAction === constant.ACTIVITY_CODE.project_restart) {
      const restart = {
        'Project Restart Reason': responseLog.comment
      }

      this.projectActivityResponse = restart
    } else if (this.activeAction === constant.ACTIVITY_CODE.auto_extension) {
      const autoExtension = {
        projectName: responseLog.projectName,
        resourceName: responseLog.resourceName,
        PlanedEndDate: new Date(responseLog.PlanedEndDate).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
        ExtendedDays: responseLog.finaldaysToAdd,
        ExtendedEndDate: new Date(responseLog.date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
        department: responseLog.department
      }

      this.autoExtensionTableData = [autoExtension]
    } else if (this.activeAction === constant.ACTIVITY_CODE.reject_requisition) {
      const rejectRequisition = []

      if (responseLog.length) {
        responseLog.forEach((record) => {
          const suggestedResources = record.suggested_resource.length ? record.suggested_resource.replace(/[^a-zA-Z ]/g, ',').split(',') : []
          const suggestedArray = []

          suggestedResources.forEach((item) => {
            if (item.length > 0) {
              suggestedArray.push(item)
            }
          })
          rejectRequisition.push({
            resource_name: record.resource_name,
            department: record.department,
            role: record.role_name,
            technology: record.tech_name,
            efforts: record.efforts,
            experience: record.experience,
            start_date: new Date(record.start_date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
            end_date: new Date(record.end_date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
            billing_type: record.billing_type,
            reason: record.reason,
            other_reason: record.other_reason,
            tentative_date: new Date(record.tentative_date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
            rejected_by: this.rejectedBy,
            suggested: suggestedArray.length ? suggestedArray : 'NA'
          })
        })
      }
      this.rejectRequisitionTableData = rejectRequisition
    }
  },
  methods: {
    parseDate (date, type = 'fullDate') {
      let parseDate = new Date(date)
      const hour = String(parseDate.getHours()).padStart(2, '0')
      const min = String(parseDate.getMinutes()).padStart(2, '0')
      const dd = String(parseDate.getDate()).padStart(2, '0')
      const mm = String(parseDate.getMonth() + 1).padStart(2, '0')
      const yyyy = parseDate.getFullYear()
      let timeHour = parseInt(hour)
      let mid = 'AM'

      if (timeHour === 0) {
        timeHour = 12
      } else if (timeHour > 12) {
        timeHour = timeHour - 12
        mid = 'PM'
      }
      timeHour = String(timeHour).padStart(2, '0')
      if (type === 'time') {
        parseDate = hour + ':' + min
      } else if (type === 'timeAmPm') {
        parseDate = timeHour + ':' + min + ' ' + mid
      } else if (type === 'month') {
        parseDate = mm
      } else if (type === 'year') {
        parseDate = yyyy
      } else if (type === 'date') {
        parseDate = dd
      } else {
        parseDate = yyyy + '-' + mm + '-' + dd
      }

      return parseDate
    },
    activityTitle (activity) {
      let title = ''
      const time = this.parseDate(activity.created_at, 'timeAmPm')

      if (activity.created_by !== null) {
        title = `${activity.project_action_type.name} by ${activity.created_by.display_name} | ${time}`
      } else {
        title = `${activity.project_action_type.name} | ${time}`
      }

      return title
    },
    redirectBack () {
      const splitPath = this.$route.path.split('/')

      this.$router.push(`/project/${splitPath[2]}/activity-log`)
    }
  }
}
</script>
<style scoped>
.v-application .cardAlignment {
  width: fit-content;
  padding-right: 1%;
}
.divContainer {
  padding:0% 4% 4% 4%;
}
>>>.v-data-table > .v-data-table__wrapper > table > thead > tr > th {
    padding: 0 6px;
    text-align: center
}
>>>.v-data-table > .v-data-table__wrapper > table > tbody > tr > td {
    padding: 0 6px;
    font-size: smaller !important;
    text-align: center
}
</style>
