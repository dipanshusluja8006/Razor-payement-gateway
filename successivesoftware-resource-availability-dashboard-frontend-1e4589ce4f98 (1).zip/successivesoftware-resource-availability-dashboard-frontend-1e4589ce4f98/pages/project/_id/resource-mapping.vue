<template>
  <div>
    <Dialog />
    <v-dialog
      v-model="validationDialog"
    >

      <div class="successPopup">
        <div class="successImg">
          <v-img :src="popupImage" />
        </div>
        <div class="successText d-flex align-center justify-center">
          <div class="sureTextWrp">
            <h1><v-icon color="red" class="mdi-48px">
              mdi-alert-circle
            </v-icon></h1>
            <p>{{ dialogText }}</p>
            <v-card-actions>
              <v-btn class="cancleBtn" text @click="validationDialog = false">
                OK
              </v-btn>
            </v-card-actions>
          </div>
        </div>
      </div>

    </v-dialog>
    <v-card
      class="mx-auto"
      max-width="100%"
    >
      <v-card-text>
        <v-row>
          <v-col cols="12" class="pb-0">
            <project-operation :project-details="projectList" :selected-project-name="projectDetail.uuid" :project-action-selected="projectActionSelected"/>
          </v-col>
          <v-col
            cols="12"
            md="8"
            class="pt-0"
          />
          <v-col
            cols="12"
            md="6"
          >
            <v-autocomplete
              v-model="selectedAccountManager"
              :items="users"
              :class="{'v-text-field__slot' : selectedAccountManager}"
              item-text="full_name"
              item-value="id"
              multiple
              attach
              chips
              label="Assigned Account Manager(s)"
              class="lableIssue"
              disabled
            />
          </v-col>
          <v-col
            cols="12"
            md="6"
          >
            <v-autocomplete
              v-model="selectedProjectManager"
              :items="users"
              :class="{'v-text-field__slot' : selectedProjectManager}"
              item-text="full_name"
              item-value="id"
              multiple
              attach
              chips
              label="Assigned Project Manager(s)"
              class="lableIssue"
              disabled
            />
          </v-col>
          <ValidationObserver ref="projectEditObserver" v-slot="{ valid }" class="tblwrp">
            <v-col
              cols="12"
            >
              <v-data-table
                :headers="headersForAllocationTable"
                :items="allocationTableData"
                :hide-default-footer="allocationTableData.length ? false : true"
                class="elevation-1"
                style="width: 100%"
              >
                <template v-slot:item.action="{ item }">
                  <ValidationProvider v-slot="{ errors }" :rules="'required_checkbox'" :name="item.text">
                    <v-checkbox v-model="item.action" :error-messages="errors" />
                  </ValidationProvider>
                </template>
              </v-data-table>
            </v-col>
            <v-col
              cols="12"
              md="5"
            >
              <v-row align="end" justify="center">
                <v-col v-if="!valid" cols="12">
                  <v-btn
                    class="text-capitalize ma-2 white--text"
                    color="blue-grey"
                    @click="$router.push('/project-dashboard')"
                  >
                    <v-icon dark left>
                      mdi-arrow-left
                    </v-icon>Back
                  </v-btn>
                  <v-btn class="text-capitalize" color="primary" @click="submit">
                    Submit
                  </v-btn>
                </v-col>
                <v-col v-else cols="12">
                  <v-btn
                    class="text-capitalize ma-2 white--text"
                    color="blue-grey"
                    @click="$router.push('/project-dashboard')"
                  >
                    <v-icon dark left>
                      mdi-arrow-left
                    </v-icon>Back
                  </v-btn>
                  <v-btn :disabled="submitted" class="text-capitalize" color="primary" @click="submit">
                    Submit
                  </v-btn>
                </v-col>
              </v-row>
            </v-col>
          </ValidationObserver>
        </v-row>
      </v-card-text>
    </v-card>
  </div>
</template>

<script>
import { mapActions, mapGetters } from 'vuex'
import Dialog from '@/components/Dialog.vue'
import constant from '@/constants/closure-checklist.js'
import ProjectOperation from '@/components/ProjectOperation'
export default {
  name: 'ResourceMapping',
  layout: 'authenticated',
  middleware: 'authenticated',
  components: {
    Dialog,
    ProjectOperation
  },
  data () {
    return {
      requestedBy: '',
      requestedOn: '',
      projectName: '',
      selectedProjectManager: [],
      selectedAccountManager: [],
      headersForAllocationTable: [
        { text: 'Resource Name', sortable: false, value: 'resource_name', width: '12%' },
        { text: 'Department', sortable: false, value: 'dept' },
        { text: 'Technology', value: 'tech', sortable: false, width: '12%' },
        { text: 'Role', value: 'designation', sortable: false },
        { text: 'Daily Efforts (Hours)', value: 'efforts', sortable: false },
        { text: 'Experience', value: 'experience', sortable: false },
        { text: 'Start Date', value: 'start_date', sortable: false },
        { text: 'End Date', value: 'end_date', sortable: false },
        { text: 'Billing Type', value: 'billing_type', sortable: false, width: '10%' },
        { text: 'Requested by', value: 'requested_by', sortable: false, width: '8%' },
        { text: 'Requested on', value: 'requested_on', sortable: false }
      ],
      allocationTableData: [],
      actionSelected: [],
      checkbox1: false,
      validationDialog: false,
      dialogText: '',
      constant,
      submitted: false,
      projectExistOnRedmine: true,
      projectActionSelected: 'resource-mapping'
    }
  },
  computed: {
    ...mapGetters({
      resourceUnMappedRecord: 'project/getResourceUnMappedRecord',
      projectList: 'project/getProjectList',
      projectDetail: 'project/getProjectDetail',
      isButtonLoading: 'project/isButtonLoading',
      users: 'project/getUserList'
    }),
    popupImage () {
      return require('@/assets/images/custom/ErrorDialog.png')
    }
  },
  async fetch ({ app, store, route }) {
    // eslint-disable-next-line no-useless-catch
    try {
      await Promise.all([
        store.dispatch('project/fetchProjectList'),
        store.dispatch('project/fetchResourceUnMappedRecord', route.params.id),
        store.dispatch('project/fetchProjectDetail', route.params.id)
      ])
    } catch (error) {
      throw (error)
    }
  },
  mounted () {
    this.$nuxt.$emit('headerTitle', 'Resource Mapping Request')
    const allocationData = []
    const resourceUnMappedRecord = this.resourceUnMappedRecord.resource_mapping || []

    this.projectExistOnRedmine = this.resourceUnMappedRecord.project_exist_redmine
    resourceUnMappedRecord.forEach((mapped, index) => {
      const startDate = new Date(mapped.start_date).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      })
      const endDate = new Date(mapped.end_date).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      })

      if (mapped.resource_allocation !== null) {
        const billingType = mapped.resource_allocation.resource_requisition.billing_type
        const allocationTuple = {
          id: mapped.uuid,
          resource_name: mapped.resource.display_name,
          dept: mapped.resource_allocation.resource_requisition.department.name,
          tech: mapped.resource_allocation.resource_requisition.technology.name,
          designation: mapped.resource_allocation.resource_requisition.designation.name,
          efforts: mapped.hours,
          experience: mapped.resource_allocation.experience,
          start_date: startDate,
          end_date: endDate,
          billing_type: (billingType && billingType === 1) ? 'Billable' : (billingType === 0) ? 'Non-Billable' : '',
          requested_by: (mapped.resource_allocation.resource_requisition.requested_user) ? mapped.resource_allocation.resource_requisition.requested_user.display_name : '',
          requested_on: new Date(mapped.resource_allocation.resource_requisition.created_at).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
          action: false
        }

        allocationData.push(allocationTuple)
      }
    })
    this.projectName = this.resourceUnMappedRecord.project_name
    this.requestedBy = this.resourceUnMappedRecord.initiated_by.display_name
    this.requestedOn = this.resourceUnMappedRecord.initiation_date
    this.allocationTableData = allocationData
    this.selectedProjectManager = this.resourceUnMappedRecord.project_managers.map(({ user_id: id, ...keepAttrs }) => id)
    this.selectedAccountManager = this.resourceUnMappedRecord.account_managers.map(({ user_id: id, ...keepAttrs }) => id)
    if (this.allocationTableData.length > 0) {
      this.IsShow = false
    }
  },
  methods: {
    ...mapActions({
      setResourceMapping: 'project/setResourceMapping',
      setCustomDialog: 'project/setCustomDialog',
      updateLoadingAction: 'project/updateLoadingAction'
    }),
    async submit () {
      const { PROJECT_STATUS:
        { RESOURCES_MAPPED } } = this.constant

      this.updateLoadingAction()
      this.allocationTableData.map((allocationTuple) => {
        allocationTuple.status = '1'
        allocationTuple.resource_mapping_id = allocationTuple.id
      })
      if (!this.projectExistOnRedmine) {
        this.dialogText = 'The requested project does not exist on Redmine, please connect with IT and PMO support team.'
        this.validationDialog = true

        return false
      }
      const requestData = {
        map_data: this.allocationTableData,
        project_id: this.$route.params.id,
        project_status: RESOURCES_MAPPED
      }

      await this.setResourceMapping(requestData)
      this.updateLoadingAction()
      this.submitted = true
    }
  }
}
</script>

<style scoped>
.v-text-field__slot >>> .theme--light.v-label--is-disabled {
   color: rgba(0, 0, 0, 0.6);
   font-size: 18px
}
.container {
    max-width: 1250px;
}
span.tblwrp {
    width: 100%;
}

</style>
