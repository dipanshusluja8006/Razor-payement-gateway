<template>
  <div class="requisitionOuterWrp">
    <v-row>
      <v-col cols="10">
        <project-operation :project-details="projects" :selected-project-name="projectDetail.uuid" :project-action-selected="projectActionSelected"/>
      </v-col>
      <v-col cols="2" class="pl-0 pt-5 pr-6">
        <div class="exportBtnWrp">
          <v-btn
            class="exportBtn"
            small
            @click="exportExcelSheet"
          >
            Export <v-icon small>
              mdi-download
            </v-icon>
          </v-btn>
        </div>
      </v-col>
    </v-row>
    <confirm-dialog ref="confirm"/>
    <Dialog />
    <v-card>
      <v-chip-group
        v-model="chipType"
        mandatory
        active-class="blue darken-2 white--text"
        column
        class="reuisitionTabeWrp"
      >
        <div class="tabeWrp">
          <div class="tabeOtpWrp">
            <div v-for="(chip, index) in chipTypes" :key="index">
              <v-chip
                :value="chip.id"
                @click="changeView(chip.id)"
              >
                {{ chip.name }}
              </v-chip>
            </div>
          </div>

          <div v-if="chipType!=1">
            <div class="searchFilterWrp">
              <div class="searchFieldS">
                <v-text-field
                  v-model="search"
                  append-icon="mdi-magnify"
                  label="Search"
                  outlined
                  rounded
                  dense
                  single-line
                  hide-details
                  @keyup="globalSearch"
                />
              </div>
              <div class="filterWrp">
                <v-menu
                  :close-on-content-click="false"
                  offset-y
                >
                  <template v-slot:activator="{ on }">
                    <v-btn
                      class="text-capitalize"
                      color=""
                      v-on="on"
                    >
                      <v-icon color="grey" dark left>
                        mdi-filter
                      </v-icon> Filter
                    </v-btn>
                  </template>
                  <template>
                    <v-card
                      v-show="true"
                      exact
                      rounded
                      class="mx-auto"
                      max-width="400"
                    >
                      <div class="extendfilterWrp">
                        <div class="extHeadingWrp">
                          <div class="extHeading">
                            <h4>Filter Data</h4>
                          </div>
                          <div class="extResetBtn">
                            <v-btn
                              @click="resetFilter('extend')"
                            >
                              Reset
                            </v-btn>
                          </div>
                        </div>
                        <div class="extFilterFieldWrp">
                          <div class="extFilterFieldL">
                            <v-select
                              v-model="effortOperator"
                              :items="operatorList"
                              item-text="name"
                              item-value="value"
                              placeholder="Efforts"
                              dense
                              solo
                            />
                          </div>
                          <div class="extFilterFieldR">
                            <v-select
                              v-model="filterEffort"
                              :disabled="(!effortOperator)"
                              :items="numberList"
                              dense
                              solo
                              placeholder="Efforts"
                            />
                          </div>
                        </div>
                        <div class="extFilterFieldWrp">
                          <div class="extFilterFieldL">
                            <v-select
                              v-model="startDateOperator"
                              :items="operatorList"
                              style="width:100%"
                              item-text="name"
                              item-value="value"
                              placeholder="Start Date"
                              dense
                              solo
                            />
                          </div>
                          <div class="extFilterFieldR">
                            <v-menu
                              v-model="startDateMenu"
                              :close-on-content-click="false"
                            >
                              <template v-slot:activator="{ on, attrs }">
                                <v-text-field
                                  :disabled="(startDateOperator === null)"
                                  :value="(filterStartDate) ? new Date(filterStartDate).toLocaleDateString('en-US', {
                                    year: 'numeric',
                                    month: 'short',
                                    day: 'numeric'
                                  }) : ''"
                                  v-bind="attrs"
                                  dense
                                  solo
                                  readonly
                                  placeholder="Choose Start Date"
                                  v-on="on"
                                >
                                  <template v-slot:prepend-inner>
                                    <v-icon v-if="(filterStartDate === null)" :disabled="(startDateOperator === null)" v-bind="attrs" v-on="on">
                                      mdi-calendar
                                    </v-icon>
                                  </template>
                                </v-text-field>
                              </template>
                              <v-date-picker v-model="filterStartDate" @input="startDateMenu = false" />
                            </v-menu>
                          </div>
                        </div>
                        <div class="extFilterFieldWrp">
                          <div class="extFilterFieldL">
                            <v-select
                              v-model="endDateOperator"
                              :items="operatorList"
                              style="width:100%"
                              item-text="name"
                              placeholder="End Date"
                              item-value="value"
                              dense
                              solo
                            />
                          </div>
                          <div class="extFilterFieldR">
                            <v-menu
                              v-model="endDateMenu"
                              :close-on-content-click="false"
                            >
                              <template v-slot:activator="{ on, attrs }">
                                <v-text-field
                                  :disabled="(endDateOperator === null)"
                                  :value="(filterEndDate) ? new Date(filterEndDate).toLocaleDateString('en-US', {
                                    year: 'numeric',
                                    month: 'short',
                                    day: 'numeric'
                                  }) : ''"
                                  v-bind="attrs"
                                  dense
                                  solo
                                  readonly
                                  placeholder="Choose End Date"
                                  v-on="on"
                                >
                                  <template v-slot:prepend-inner>
                                    <v-icon v-if="(filterEndDate === null)" :disabled="(endDateOperator === null)" v-bind="attrs" v-on="on">
                                      mdi-calendar
                                    </v-icon>
                                  </template>
                                </v-text-field>
                              </template>
                              <v-date-picker v-model="filterEndDate" :min="filterStartDate" @input="endDateMenu = false" />
                            </v-menu>
                          </div>
                        </div>
                        <div class="roleDeprtWrp">
                          <v-autocomplete
                            v-model="filterRole"
                            :items="availableRoles"
                            item-text="name"
                            item-value="id"
                            placeholder="Select Role"
                            dense
                            solo
                            clearable
                          />
                        </div>
                        <div class="roleDeprtWrp">
                          <v-autocomplete
                            v-model="filterDepartment"
                            :items="departments"
                            item-text="name"
                            item-value="id"
                            placeholder="Department"
                            dense
                            solo
                            clearable
                          />
                        </div>
                        <div class="applayBtnWrp">
                          <v-btn
                            @click="applyFilter('extend', true)"
                          >
                            Apply
                          </v-btn>
                        </div>
                      </div>
                    </v-card>
                  </template>
                </v-menu>
              </div>
            </div>
          </div>
        </div>
      </v-chip-group>
      <div v-if="chipType===1">
        <requisition-operation />
      </div>
      <div v-else-if="chipType===2">
        <extend-operation
          :extension-list-data="allocationTableData"
          :common-search="search"
        />
      </div>
      <div v-else-if="chipType===3">
        <deallocation-operation
          :deallocate-list-data="allocationTableData"
          :common-search="search"
        />
        <!-- <span class="ma-9"> Deallocation Tab</span> -->
      </div>
      <div v-else-if="chipType===4">

        <reporting-operation
          :reporting-list-data="allocationTableData"
          :common-search="search"
          :reporting-records="reportingManagerRecord"
        />
        <!-- <span class="ma-9"> Manage Reporting Tab</span> -->
      </div>
    </v-card>
  </div>
</template>
<script>
import { mapGetters, mapActions } from 'vuex'
import Dialog from '@/components/Dialog.vue'
import ConfirmDialog from '@/components/ConfirmDialog'
import ProjectOperation from '@/components/ProjectOperation'
import RequisitionOperation from '../../../components/resource/RequisitionOperation.vue'
import constant from '@/constants/closure-checklist.js'
import ExtendOperation from '../../../components/resource/ExtendOperation.vue'
import DeallocationOperation from '../../../components/resource/DeallocationOperation.vue'
import ReportingOperation from '../../../components/resource/ReportingOperation.vue'
import { excelSheet, projectHelpers } from '@/helpers/helper.js'
export default {
  name: 'ResourceRequistion',
  layout: 'authenticated',
  middleware: 'authenticated',
  components: {
    ConfirmDialog,
    Dialog,
    ProjectOperation,
    RequisitionOperation,
    ExtendOperation,
    DeallocationOperation,
    ReportingOperation
  },
  data () {
    return {
      chipTypes: [{
        name: 'Requisition',
        id: 1
      },
      {
        name: 'Extend',
        id: 2
      },
      {
        name: 'Deallocate',
        id: 3
      },
      {
        name: 'Manage Reporting',
        id: 4
      }],
      chipType: 1,
      projectActionSelected: 'resource-requisition',
      projectName: '',
      page: 1,
      search: '',
      operatorList: [{ name: 'is', value: '===' }, { name: '<=', value: '<=' }, { name: '>=', value: '>=' }],
      numberList: [1, 2, 3, 4, 5, 6, 7, 8],
      filterEffort: null,
      filterDepartment: null,
      filterRole: null,
      effortOperator: null,
      startDateOperator: null,
      endDateOperator: null,
      filterStartDate: null,
      startDateMenu: false,
      filterEndDate: null,
      endDateMenu: false,
      commonExtendFrom: null,
      commonExtendTo: null,
      commonDeallocateFrom: null,
      commonExtendFromMenu: false,
      reportingManagerRecord: [],
      selected: [],
      deallocationSelected: [],
      manageReportingSelected: [],
      allocationTableData: [],
      filterAllocationTableData: [],
      storeAllocation: [],
      extensionTableData: [],
      reportingMangaerTableData: [],
      extensionValidationPass: false,
      manageReportingValidationPass: false,
      validationPass: false,
      itemsPerPage: 10,
      resourceAllocationMeta: [],
      allDataRowsSelected: false,
      unSelectAllExtensionRows: false,
      unSelectAllDeallocationRows: false,
      unSelectAllManageReportingnRows: false,
      allDeallocationDataRowsSelected: false,
      allManageReportingDataRowsSelected: false,
      allSelected: false,
      allDeallocationSelected: false,
      allManageReportingSelected: false,
      currentDate: null,
      dialog: false,
      actionSelected: [],
      constant,
      departmentSelected: '',
      departmentList: [],
      exportData: [],
      isSameNames: false,
      actions:['auto-deallocation', 'auto extension'],
      max: 8,
      min: 1
    }
  },
  computed: {
    ...mapGetters({
      technologies: 'project/getTechnologies',
      departments: 'project/getDepartments',
      projects: 'project/getProjectList',
      users: 'project/getUserList',
      projectDetail: 'project/getProjectDetail',
      isButtonLoading: 'project/isButtonLoading',
      availableRoles: 'roles/availableRoles',
      getManageReportingDetail: 'project/getManageReportingDetail'
    })
  },
  async fetch ({ store, route }) {
    // eslint-disable-next-line no-useless-catch
    try {
      await Promise.all([
        store.dispatch('project/fetchProjectList'),
        store.dispatch('project/fetchProjectDetail', route.params.id),
        store.dispatch('project/fetchManageReportingDetail', route.params.id)
      ])
    } catch (error) {
      throw (error)
    }
  },
  mounted () {
    let today = new Date()
    const dd = String(today.getDate()).padStart(2, '0')
    const mm = String(today.getMonth() + 1).padStart(2, '0')
    const yyyy = today.getFullYear()

    today = yyyy + '-' + mm + '-' + dd
    this.currentDate = today
    const manageReportingArray = []

    if (this.getManageReportingDetail) {
      this.getManageReportingDetail.forEach((element) => {
        if (element) {
          const manager = {
            kekaRmEmail: (element.keka_rm_email) ? element.keka_rm_email : null,
            kekaRmName: (element.keka_rm) ? element.keka_rm : null,
            currentRm: (element.current_rm) ? element.current_rm : null,
            status: element.status,
            requestedRm: (element.requested_rm) ? element.requested_rm.id : null,
            resourceId: element.id,
            resourceName: element.display_name,
            status_id: (element.status_meg_id !== null) ? element.status_meg_id : 3
          }

          manageReportingArray[element.id] = manager
        }
      })
    }
    this.reportingManagerRecord = manageReportingArray
    const allocationData = []
    let resourceReqData = null

    resourceReqData = this.projectDetail.resource_requisition || []
    for (let i = 0; i < resourceReqData.length; i++) {
      for (let j = 0; j < resourceReqData[i].resource_allocation.length; j++) {
        if (resourceReqData[i].resource_allocation[j].mapped_resource === null) {
          continue
        }
        const billingType = resourceReqData[i].billing_type

        for (let k = 0; k < resourceReqData[i].resource_allocation[j].resource_allocation_meta.length; k++) {
          const startDate = resourceReqData[i].resource_allocation[j].resource_allocation_meta[k].start_date
          const endDate = resourceReqData[i].resource_allocation[j].resource_allocation_meta[k].end_date
          const minDeallocateDate = startDate
          let maxDeallocateDate = endDate

          if (new Date(startDate).getTime() > new Date(today).getTime() && new Date(startDate).getTime() === new Date(endDate).getTime()) {
            maxDeallocateDate = endDate
          } else {
            maxDeallocateDate = new Date(endDate)
            maxDeallocateDate.setDate(maxDeallocateDate.getDate() - 1)
            maxDeallocateDate = `${maxDeallocateDate.getFullYear()}-${String(maxDeallocateDate.getMonth() + 1).padStart(2, '0')}-${String(maxDeallocateDate.getDate()).padStart(2, '0')}`
          }
          const allocateResourceId = resourceReqData[i].resource_allocation[j].resource_allocation_meta[k].resource_id
          const allocationTuple = {
            allocation_id: resourceReqData[i].resource_allocation[j].uuid,
            meta_id: resourceReqData[i].resource_allocation[j].resource_allocation_meta[k].uuid,
            resource_name: resourceReqData[i].resource_allocation[j].resource_allocation_meta[k].resource.display_name,
            email: resourceReqData[i].resource_allocation[j].resource_allocation_meta[k].resource.email,
            employee_id: resourceReqData[i].resource_allocation[j].resource_allocation_meta[k].resource.employee_id,
            dept: resourceReqData[i].department.name,
            tech: resourceReqData[i].technology.name,
            dept_id: resourceReqData[i].department.id,
            tech_id: resourceReqData[i].technology.id,
            role_id: resourceReqData[i].designation.id,
            designation: resourceReqData[i].designation.name,
            resource_id: resourceReqData[i].resource_allocation[j].resource_allocation_meta[k].resource_id,
            efforts: resourceReqData[i].resource_allocation[j].resource_allocation_meta[k].hours,
            experience: resourceReqData[i].resource_allocation[j].experience,
            start_date: startDate,
            end_date: endDate,
            billing_value: billingType,
            billing_type: (billingType && billingType === 1) ? 'Billable' : (billingType === 0) ? 'Non-Billable' : '',
            deallocate_hrs: (resourceReqData[i].resource_allocation[j].resource_allocation_meta[k].hours).toString(),
            status: resourceReqData[i].resource_allocation[j].status,
            deallocate_from: null,
            deallocate_to: null,
            deallocateAlert: false,
            minDeallocateFromDate: minDeallocateDate,
            maxDeallocateFromDate: maxDeallocateDate,
            newDate: false,
            deallocate: false,
            extend: false,
            manageReporting: false,
            current_date: today,
            requestedManager: (manageReportingArray[allocateResourceId]) ? manageReportingArray[allocateResourceId].requestedRm : null,
            requestedManagerStatusId: (manageReportingArray[allocateResourceId]) ? manageReportingArray[allocateResourceId].status_id : 3,
            assignedReportingManagerNameKeka: (manageReportingArray[allocateResourceId] && manageReportingArray[allocateResourceId].kekaRmName) ? manageReportingArray[allocateResourceId].kekaRmName : '',
            assignedReportingManagerEmailKeka: (manageReportingArray[allocateResourceId] && manageReportingArray[allocateResourceId].kekaRmEmail) ? manageReportingArray[allocateResourceId].kekaRmEmail : null,
            expireFlag: this.checkExpireInFlag(endDate),
            expireDays: this.checkExpireInValue(endDate),
            extend_date_duration: null,
            action: resourceReqData[i].auto_extn_deallocation
          }

          allocationData.push(allocationTuple)
        }
      }
    }

    const filteredAllocationData = []

    if (this.reportingManagerRecord && allocationData) {
      this.reportingManagerRecord.forEach((item) => {
        allocationData.forEach((value) => {
          if (item.resourceId === value.resource_id) {
            filteredAllocationData.push(value)
          }
        })
      })
    }
    this.projectName = this.projectDetail.project_name
    this.allocationTableData = filteredAllocationData.filter((allocationItem) => allocationItem.efforts > 0)

    const metaRecord = []

    this.projectDetail.resource_requisition.forEach((item) => {
      item.resource_allocation.forEach((element) => {
        if (element.mapped_resource !== null) {
          element.resource_allocation_meta.forEach((meta) => {
            if (metaRecord[meta.resource_id]) {
              metaRecord[meta.resource_id].push(meta)
            } else {
              metaRecord[meta.resource_id] = [meta]
            }
          })
        }
      })
    })
    this.resourceAllocationMeta = metaRecord
    this.departments.map((item) => {
      this.departmentList.push(item.name)
    })

    this.exportData = [...this.allocationTableData]
    this.storeAllocation = [...this.allocationTableData]
  },
  methods: {
    ...mapActions({
      setResourceDeAllocationData: 'project/setResourceDeAllocationData',
      setResourceExtensionData: 'project/setResourceExtensionData',
      setManageReportingData: 'project/setManageReportingData',
      setCustomDialog: 'project/setCustomDialog',
      updateLoadingAction: 'project/updateLoadingAction'
    }),
    checkExpireInFlag (endDate) {
      const today = new Date()
      const lastDate = new Date(endDate)
      const totalDays = projectHelpers.totalDaysCount(today, lastDate)

      if (today > lastDate) {
        return true
      } else if (totalDays <= 7) {
        return true
      } else {
        return false
      }

    },

    globalSearch() {
      if (this.search !== '') {
        const res = this.storeAllocation.filter((item) =>
          item.resource_name.toUpperCase().includes(this.search.toString().toUpperCase())
        || item.dept.toUpperCase().includes(this.search.toString().toUpperCase())
        || item.billing_type.toUpperCase().includes(this.search.toString().toUpperCase())
        || item.tech.toUpperCase().includes(this.search.toString().toUpperCase())
        || item.designation.toUpperCase().includes(this.search.toString().toUpperCase())
        )

        this.allocationTableData = res
        this.exportData = res
      } else {
        this.allocationTableData = this.storeAllocation
      }
    },

    checkExpireInValue (endDate) {
      const today = new Date()
      const lastDate = new Date(endDate)

      const isSameDay = (today.getDate() === lastDate.getDate()
      && today.getMonth() === lastDate.getMonth()
      && today.getFullYear() === lastDate.getFullYear())

      if (isSameDay) {
        return 'Booking Expires in 1 Day'
      }

      if (today > lastDate) {
        return  'Booking Expired'
      } else {
        const totalCount = projectHelpers.totalDaysCount(today, lastDate)

        if (totalCount < 7) {
          return 'Booking Expires in ' + totalCount + ' Days'
        } else {
          const remainder = totalCount % 7
          const totalWeeks = Math.round(totalCount / 7 )

          // const totalWeeks = remainder > 3 ? totalCount / 7 + 1 : totalCount / 7
          return 'Booking Expires in ' + totalWeeks + ' Weeks'
        }
      }

    },
    /**
     * Filter for department column.
     * @param value Value to be tested.
     * @returns {boolean}
     */
    departmenetFilter (value) {
      if (!this.departmentSelected || !value) {
        return true
      }
      value = value.toString()
      if (this.departmentSelected.length && this.departmentSelected === value) {
        return true
      }
      if (this.departmentSelected.length < 1) {
        return true
      }

      return false
    },
    /**
     *  Download allocated resource details in excel sheet.
     */
    exportExcelSheet () {
      /* create new workbook */
      const dataForExcel = []

      this.exportData.map((tableData) => {
        const rowData = {
          resource_name: tableData.resource_name,
          employee_id: tableData.employee_id,
          email: tableData.email,
          dept: tableData.dept,
          tech: tableData.tech,
          role: tableData.designation,
          efforts: tableData.efforts,
          start_date: new Date(tableData.start_date).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
          }),
          end_date: new Date(tableData.end_date).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
          }),
          billing_type: tableData.billing_type
        }

        dataForExcel.push(rowData)
      })
      const excelParams = {
        'sheetData': [dataForExcel],
        'headers': [['resource_name', 'employee_id', 'email', 'dept', 'tech', 'role', 'efforts', 'start_date', 'end_date', 'billing_type']],
        'sheetName': ['Resource-Details'],
        'fileName': 'new-workbook.xls'
      }

      excelSheet.createExcelSheet(excelParams)
    },
    resetFilter (tab) {
      if (tab === 'extend') {
        this.effortOperator = this.startDateOperator = this.endDateOperator = null
        this.filterEffort = this.filterDepartment = this.filterStartDate = this.filterEndDate = this.filterRole = null
      }
    },
    applyFilter (tab, applyAll = false) {
      let tableData = this.storeAllocation

      if (tab === 'extend') {
        if (this.filterEffort) {
          tableData = tableData.filter((item) => { return (this.effortOperator === '===') ? parseInt(item.efforts) === parseInt(this.filterEffort) : (this.effortOperator === '<=') ? parseInt(item.efforts) <= parseInt(this.filterEffort) : parseInt(item.efforts) >= parseInt(this.filterEffort) })
        }
        if (this.filterStartDate) {
          const parseFilterStartDate = new Date(this.filterStartDate).getTime()

          tableData = tableData.filter((item) => { return (this.startDateOperator === '===') ? new Date(item.start_date).getTime() === parseFilterStartDate : (this.startDateOperator === '<=') ? new Date(item.start_date).getTime() <= parseFilterStartDate : new Date(item.start_date).getTime() >= parseFilterStartDate })
        }
        if (this.filterEndDate) {
          const parseFilterEndDate = new Date(this.filterEndDate).getTime()

          tableData = tableData.filter((item) => { return (this.endDateOperator === '===') ? new Date(item.end_date).getTime() === parseFilterEndDate : (this.endDateOperator === '<=') ? new Date(item.end_date).getTime() <= parseFilterEndDate : new Date(item.end_date).getTime() >= parseFilterEndDate })
        }
        if (this.filterRole) {
          tableData = tableData.filter((item) => { return this.filterRole === item.role_id })
        }
        if (this.filterDepartment) {
          tableData = tableData.filter((item) => { return this.filterDepartment === item.dept_id })
        }

        if (!applyAll) {
          this.allocationTableData = tableData
        } else {
          this.filterEffort1 = this.filterEffort2 = this.filterEffort
          this.effortOperator1 = this.effortOperator2 = this.effortOperator
          this.startDateOperator1 = this.startDateOperator
          this.filterStartDate1 = this.filterStartDate
          this.endDateOperator1 = this.endDateOperator
          this.filterEndDate1 = this.filterEndDate
          this.filterRole1 = this.filterRole2 = this.filterRole
          this.filterDepartment1 = this.filterDepartment2 = this.filterDepartment
          this.allocationTableData = tableData
        }
      }
    },
    changeView (selected1) {
      this.chipType = selected1
    }
  }
}
</script>

<style scoped>
.v-text-field__slot >>> .theme--light.v-label--is-disabled {
   color: rgba(0, 0, 0, 0.6);
   font-size: 18px
}
</style>
