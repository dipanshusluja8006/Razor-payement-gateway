<template>
  <div>
    <Dialog />
    <v-card>
      <v-card-text>
        <v-row>
          <v-col cols="12" class="pt-2 pb-0">
            <project-operation :project-details="projects" :selected-project-name="projectDetail.uuid" :project-action-selected="projectActionSelected"/>
          </v-col>
          <v-col cols="12" md="6">
            <v-text-field
              v-model="projectDetail.project_name"
              :class="{'v-text-field__slot' : projectDetail.project_name}"
              label="Project Name"
              disabled
            />
          </v-col>
          <v-col cols="12" md="6">
            <v-autocomplete
              v-model="selectedManager"
              :items="users"
              :class="{'v-text-field__slot' : selectedManager}"
              item-text="full_name"
              item-value="id"
              multiple
              attach
              chips
              label="Account Manager(s)"
              disabled
            />
          </v-col>
        </v-row>
        <v-row>
          <v-col
            cols="12"
            md="12"
          >
            <v-textarea
              v-model="projectDetail.project_action.comment"
              :class="{'v-text-field__slot' : projectDetail.project_action.comment}"
              label="Reason for On Hold"
              rows="1"
              auto-grow
              disabled
            />
          </v-col>
        </v-row>
        <v-row>
          <v-col cols="12" md="6">
            <v-text-field
              v-model="fromDateString"
              :class="{'v-text-field__slot' : fromDateString}"
              label="On Hold from date"
              disabled
            />
          </v-col>
          <v-col cols="12" md="6">
            <v-text-field
              v-model="toDateString"
              :class="{'v-text-field__slot' : toDateString}"
              label="On Hold till date"
              disabled
            />
          </v-col>
        </v-row>
        <v-row>
          <v-col cols="12" md="6">
            <v-text-field
              v-model="requestedBy"
              :class="{'v-text-field__slot' : requestedBy}"
              label="Project On Hold Requested By"
              disabled
            />
          </v-col>
          <v-col cols="12" md="6">
            <v-text-field
              v-model="requestedAtDateString"
              :class="{'v-text-field__slot' : requestedAtDateString}"
              label="Requested On"
              disabled
            />
          </v-col>
        </v-row>
        <v-row>
          <v-col cols="12" class="pb-6" md="6">
            <v-btn
              :disabled="submitted"
              class="mx-2 text-capitalize"
              color="success"
              medium
              @click="holdAction(holdApproveStatus)"
            >
              <v-icon dark>
                mdi-check
              </v-icon>Approve
            </v-btn>
            <v-btn
              :disabled="submitted"
              class="mx-2 text-capitalize"
              color="error"
              medium
              @click="holdAction(holdDeclineStatus)"
            >
              <v-icon dark>
                mdi-close
              </v-icon>Decline
            </v-btn>
          </v-col>
        </v-row>
      </v-card-text>
    </v-card>
  </div>
</template>

<script>
import { mapActions, mapGetters } from 'vuex'
import Dialog from '@/components/Dialog.vue'
import constant from '@/constants/closure-checklist.js'
import ProjectOperation from '@/components/ProjectOperation'

export default {
  name: 'HoldRequestAction',
  layout: 'authenticated',
  middleware: 'authenticated',
  components: {
    Dialog,
    ProjectOperation
  },
  data () {
    return {
      toDateString: '',
      fromDateString: '',
      requestedAtDateString: '',
      requestedBy: '',
      constant,
      holdApproveStatus: '',
      holdDeclineStatus: '',
      submitted: false,
      selectedManager: [],
      projectActionSelected: 'hold-request-approval'
    }
  },
  computed: {
    ...mapGetters({
      projectDetail: 'project/getProjectHoldRequest',
      projects: 'project/getProjectList',
      isButtonLoading: 'project/isButtonLoading',
      users: 'project/getUserList'
    })
  },
  async fetch ({ app, store, route }) {
    // eslint-disable-next-line no-useless-catch
    try {
      await Promise.all([
        store.dispatch('project/fetchProjectList'),
        store.dispatch('project/fetchProjectHoldRequest', route.params.id),
        store.dispatch('project/fetchProjectDetail', route.params.id)
      ])

    } catch (error) {
      throw (error)
    }
  },
  mounted () {
    this.$nuxt.$emit('headerTitle', 'Project On Hold Request')
    const { PROJECT_STATUS } = constant || {}
    const { ON_HOLD, RESOURCE_ALLOCATION_RESPONSE_APPROVE } = PROJECT_STATUS || {}

    this.holdApproveStatus = ON_HOLD
    this.selectedManager = this.projectDetail.account_managers.map(({ user_id: id, ...keepAttrs }) => id)
    this.holdDeclineStatus = RESOURCE_ALLOCATION_RESPONSE_APPROVE
    this.requestedBy = this.projectDetail.project_action.requested_by.display_name
    this.toDateString = new Date(this.projectDetail.project_action.to)
      .toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })
    this.fromDateString = new Date(this.projectDetail.project_action.from)
      .toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })
    this.requestedAtDateString = new Date(
      this.projectDetail.project_action.created_at.substr(0, 10))
      .toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })
  },
  methods: {
    ...mapActions({
      updateProjectHoldApproval: 'project/updateProjectHoldApproval',
      setCustomDialog: 'project/setCustomDialog',
      updateLoadingAction: 'project/updateLoadingAction'
    }),
    async holdAction (actionId) {
      this.updateLoadingAction()
      if (actionId === this.holdApproveStatus) {
        const requestPayload = {
          'project_id': this.$route.params.id,
          'status_id': actionId,
          'to': this.projectDetail.project_action.to,
          'from': this.projectDetail.project_action.from,
          'reason': this.projectDetail.project_action.comment,
          'requested_by': this.projectDetail.project_action.requested_by.id,
          'send_type': 'approve'
        }

        await this.updateProjectHoldApproval(requestPayload)
      } else {
        const requestPayload = {
          'project_id': this.$route.params.id,
          'status_id': actionId,
          'to': this.projectDetail.project_action.to,
          'from': this.projectDetail.project_action.from,
          'reason': this.projectDetail.project_action.comment,
          'requested_by': this.projectDetail.project_action.requested_by.id,
          'send_type': 'reject'
        }

        await this.updateProjectHoldApproval(requestPayload)
      }
      this.updateLoadingAction()
      this.submitted = true
    }
  }
}
</script>

<style scoped>
.v-text-field__slot >>> .theme--light.v-label--is-disabled {
   color: rgba(0, 0, 0, 0.6);
   font-size: 18px
}
.container {
    max-width: 1250px;
}
</style>
