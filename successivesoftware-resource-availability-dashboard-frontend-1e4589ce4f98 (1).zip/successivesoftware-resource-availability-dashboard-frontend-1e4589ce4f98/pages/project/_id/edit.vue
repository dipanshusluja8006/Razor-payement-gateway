<template>
  <div id="projectInitiationEdit">
    <Dialog />
    <common-snackbar :text-for-snackbar="snackbarText" :snackbar="snackbarValue" />
    <ValidationObserver ref="projectInitObserver" v-slot="{ valid }" class="projectInitiationFormWrp">
      <div class="projectInitHWrp">
        <v-row align="center">
          <v-col class="text-left" cols="12" sm="9">
            <h3 class="projectInitHeading">Project Details</h3>
          </v-col>
          <v-col class="text-right pr-6" cols="12" sm="3">
            <div class="actionWrp">
              <v-btn
                outlined
                class="cancleBtn"
                color="grey"
                @click="back()"
              >Cancel</v-btn>

              <v-btn v-if="!valid || validateClientDetails" :disabled="!valid || validateClientDetails" class="btn-color" @click="saveChanges">Update
              </v-btn>

              <v-btn v-else :disabled="submitted" class="btn-color" @click="saveChanges"> Update
              </v-btn>
            </div>
          </v-col>

        </v-row>
      </div>
      <v-stepper v-model="e6" vertical>
        <div align="center">
          <div class="text-left">
            <div v-if="!Step1Error">
              <v-stepper-step complete :step="generalDetailTab" >
                General Details
              </v-stepper-step>
            </div>
            <v-stepper-content step="1">
              <v-card color="lighten-1" class="projectInitiationFormInner">
                <div class="content bottomSpace">
                  <v-card-text class="cardContent">
                    <v-row>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Project Name *</strong>
                        </div>
                        <ValidationProvider v-slot="{ errors }" :rules="'required|alpha_num_whitespace_special'" name="projectName">
                          <v-text-field
                            v-model.trim="projectName"
                            :error-messages="errors"
                            dense
                            placeholder="Please enter project name"
                          />
                        </ValidationProvider>
                      </v-col>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Project Type *</strong>
                        </div>
                        <ValidationProvider
                          v-slot="{ errors }"
                          :rules="'required'"
                          name="projectTypeId"
                        >
                          <v-autocomplete
                            v-model="projectTypeId"
                            :items="projectTypes"
                            :error-messages="errors"
                            clearable
                            placeholder="Please select project type"
                            item-text="name"
                            item-value="id"
                            dense
                          />
                        </ValidationProvider>
                      </v-col>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Governance Category *</strong>
                          <v-tooltip max-width="350px" bottom>
                            <template v-slot:activator="{ on, attrs }">
                              <v-icon
                                v-bind="attrs"
                                class="mdi-16px btn-color"
                                dark
                                v-on="on"
                              >
                                mdi-information
                              </v-icon>
                            </template>
                            <div>
                              <strong><i><u>Managed Services</u></i></strong> <br>
                              Engagement where successive have full control of the project. like: Estimation, Management, Engineering & Monitoring, etc.
                              <br><strong><i><u>Extension</u></i></strong><br>
                              Support and Maintenance project where task Estimation and Planning drive by the client.
                              <br><strong><i><u>Staff Augmentation</u></i></strong> <br>
                              Engagement where successive only provide staff to client and rest is managed by the client.
                            </div>
                          </v-tooltip>
                        </div>
                        <ValidationProvider
                          v-slot="{ errors }"
                          :rules="'required'"
                          name="governanceCategoryId"
                        >
                          <v-autocomplete
                            v-model="governanceCategoryId"
                            :items="governanceCategories"
                            :error-messages="errors"
                            clearable
                            item-text="name"
                            item-value="id"
                            placeholder="Please select the governance category"
                            dense
                          />
                        </ValidationProvider>
                      </v-col>
                    </v-row>
                    <v-row>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Project Lifecycle Model *</strong>
                        </div>
                        <ValidationProvider v-slot="{ errors }" :rules="'required'" name="projectLifeCycleModel">
                          <v-autocomplete
                            v-model="projectLifeCycleModel"
                            :items="getProjectLifeCycleModel"
                            :error-messages="errors"
                            placeholder="Please select project lifecycle model"
                            item-text="name"
                            item-value="id"
                            dense
                            clearable
                          />
                        </ValidationProvider>
                      </v-col>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Project Domain *</strong>
                        </div>
                        <ValidationProvider v-slot="{ errors }" :rules="'required'" name="projectDomain">
                          <v-autocomplete
                            v-model="selectedDomains"
                            :filter="filter"
                            :hide-no-data="!searchDomain"
                            :items="getProjectDomains"
                            :error-messages="errors"
                            :search-input.sync="searchDomain"
                            item-text="name"
                            item-value="id"
                            hide-selected
                            placeholder="Please select project domains"
                            dense
                            multiple
                            attach
                            @change="searchDomain=''"
                            @keyup.enter="submitNewDomain(searchDomain)"
                          >
                            <template v-slot:no-data />
                            <template v-slot:prepend-item>
                              <v-list-item v-if="searchDomain !== null && searchDomain !== '' && !domainNameArray.includes(searchDomain)">
                                <span class="subheading">Create</span>
                                <v-chip
                                  color="teal lighten-3"
                                  label
                                  small
                                  @click="createNewDomain(searchDomain)"
                                >
                                  {{ searchDomain }}
                                </v-chip>
                              </v-list-item>
                            </template>
                            <template v-slot:selection="{ attrs, item, parent, selected, index}">
                              <v-tooltip top>
                                <template v-slot:activator="{ on }">
                                  <v-chip
                                    v-if="item === Object(item) && index <= 1"
                                    v-bind="attrs"
                                    :input-value="selected"
                                    color="blue lighten-3"
                                    label
                                    small
                                    v-on="on"
                                  >
                                    <span class="pr-2">
                                      {{ item.name.length >= 47? item.name.slice(0,47) + '...': item.name }}
                                    </span>
                                    <v-icon
                                      small
                                      @click="parent.selectItem(item)"
                                    >
                                      mdi-close
                                    </v-icon>
                                  </v-chip>
                                  <v-menu
                                    bottom
                                    origin="center center"
                                    transition="scale-transition"
                                  >
                                    <template v-slot:activator="{ on }">
                                      <v-btn
                                        v-if="index === 2"
                                        class="ml-1 mr-1 text-capitalize"
                                        outlined
                                        rounded
                                        fab
                                        small
                                        height="30"
                                        width="30"
                                        color="blue"
                                        v-on="on"
                                        @click="projectDetail.openProjectDomainList = !projectDetail.openProjectDomainLis"
                                      >
                                        <v-icon x-small style="height: 10px; width: 10px">
                                          mdi-plus
                                        </v-icon>
                                        {{ selectedDomains.length - 2 }}
                                      </v-btn>
                                    </template>
                                    <v-card
                                      v-show="projectDetail.openProjectDomainList"
                                      class="mx-auto"
                                      max-width="300"
                                      raised
                                    >
                                      <v-list
                                        v-if="selectedDomainData.length > 2"
                                        disabled
                                        shaped
                                      >
                                        <v-list-item-group
                                          v-model="selectedDomainData"
                                        >
                                          <v-list-item
                                            v-for="projectDomain in selectedDomainData.slice(2,selectedDomainData.length)"
                                            v-show="projectDetail.openProjectDomainList"
                                            :key="projectDomain.id"
                                          >
                                            <v-avatar
                                              :color="`${randomColors()}`"
                                              size="30"
                                            >
                                              <strong class="white--text " >{{ avatarNames(projectDomain.name) }}</strong>
                                            </v-avatar>
                                            <v-list-item-content class="ml-2">
                                              <v-list-item-title v-text="projectDomain.name" />
                                            </v-list-item-content>
                                          </v-list-item>
                                        </v-list-item-group>
                                      </v-list>
                                    </v-card>
                                  </v-menu>
                                </template>
                                <span>{{ item.name }}</span>
                              </v-tooltip>

                            </template>
                            <template v-slot:item="{ index, item }">
                              <v-tooltip top>
                                <template v-slot:activator="{ on }">
                                  <v-chip
                                    color="blue lighten-3"
                                    dark
                                    label
                                    small
                                    v-on="on"
                                  >
                                    {{ item.name.length >= 47? item.name.slice(0,47) + '...': item.name }}
                                  </v-chip>
                                  <v-spacer />
                                </template>
                                <span>{{ item.name }}</span>
                              </v-tooltip>
                            </template>
                          </v-autocomplete>
                        </ValidationProvider>
                      </v-col>
                      <v-col md="4" class="p-b-0">
                        <div class="field" style="padding-bottom: 0px;">
                          <v-checkbox
                            v-model="subProject"
                            dense
                            class="shrink mr-2 mt-0"
                            style="padding-top:0px; margin-right: 0px !important; width: 24px; display: inline-flex"
                            hide-details
                          />
                          <div style="display: inline-flex">
                            <strong>Sub-Project</strong>
                          </div>
                        </div>
                        <div v-if="subProject">
                          <ValidationProvider v-slot="{ errors }" :rules="(subProject) ? 'required' : ''" name="subProjectId">
                            <v-autocomplete
                              v-model="subProjectId"
                              :items="getRedminProjectNameList"
                              :disabled="!subProject"
                              :error-messages="errors"
                              item-text="project_name"
                              item-value="uuid"
                              placeholder="Please select project sub project"
                              dense
                            />
                          </ValidationProvider>
                        </div>
                      </v-col>
                    </v-row>
                    <v-row>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Billing Medium</strong>
                        </div>
                        <v-autocomplete
                          v-model="billingMediumId"
                          :items="billingMediums"
                          clearable
                          placeholder="Billing Medium"
                          item-text="name"
                          item-value="redmine_billing_medium_id"
                          dense
                        />
                      </v-col>
                      <v-col md="8" class="p-b-0">
                        <div class="field">
                          <strong>Billing Type *</strong>
                        </div>
                        <v-chip-group
                          v-model="billingType"
                          mandatory
                          active-class="deep-purple accent-4 white--text"
                          column
                        >
                          <div v-for="(billing, index) in billingTypes" :key="index">
                            <v-chip
                              :value="billing.id"
                              class="ml-2"
                            >
                              {{ billing.name }}
                            </v-chip>
                          </div>
                        </v-chip-group>
                      </v-col>
                    </v-row>
                    <v-row>
                      <v-col md="8" class="p-b-0">
                        <div class="field">
                          <strong>Project Summary *</strong>
                        </div>
                        <ValidationProvider v-slot="{ errors }" :rules="'required|alpha_num_whitespace_special_line_break'" name="projectSummary">
                          <v-textarea
                            v-model.trim="projectSummary"
                            :error-messages="errors"
                            :auto-grow="true"
                            dense
                            placeholder="Please enter project summary.."
                            rows="1"
                          />
                        </ValidationProvider>
                      </v-col>
                    </v-row>
                  </v-card-text>
                </div>
              </v-card>
            </v-stepper-content>
            <v-stepper-step v-if="(billingType === 1 || billingType === 2 || billingType === 3)" complete :step="clientDetailTab">
              Client Details
            </v-stepper-step>
            <v-stepper-content v-show="(billingType === 1 || billingType === 2 || billingType === 3)" step="1">
              <v-card class="projectInitiationFormInner">
                <div v-if="billingType === 1 || billingType === 2 || billingType === 3" class="content bottomSpace">
                  <v-card-text class="cardContent">
                    <v-row>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Company Name *</strong>
                        </div>
                        <ValidationProvider v-slot="{ errors }" :rules="(billingType === 1 || billingType === 2 || billingType === 3) ? 'required|alpha_num_whitespace_special' : ''" name="companyName">
                          <v-text-field
                            v-model.trim="companyName"
                            :disabled="!(billingType === 1 || billingType === 2 || billingType === 3)"
                            :error-messages="errors"
                            placeholder="Please enter company's name"
                            dense
                          />
                        </ValidationProvider>
                      </v-col>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Country *</strong>
                        </div>
                        <ValidationProvider v-slot="{ errors }" :rules="(billingType === 1 || billingType === 2 || billingType === 3) ? 'required' : ''" name="companyCountry">
                          <v-autocomplete
                            v-model="companyCountry"
                            :disabled="!(billingType === 1 || billingType === 2 || billingType === 3)"
                            :items="newCountryData"
                            placeholder="Please enter Country"
                            item-text="countryName"
                            item-value="countryName"
                            :error-messages="errors"
                            dense
                            clearable
                            @change="setResignValues(companyCountry)"
                          />
                        </ValidationProvider>
                      </v-col>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>State *</strong>
                        </div>
                        <ValidationProvider v-slot="{ errors }" :rules="(billingType === 1 || billingType === 2 || billingType === 3) ? 'required' : ''" name="companyState">
                          <v-autocomplete
                            v-model="companyState"
                            :disabled="!(billingType === 1 || billingType === 2 || billingType === 3)"
                            :items="newStateData"
                            placeholder="Please enter state"
                            item-text="name"
                            item-value="name"
                            :error-messages="errors"
                            dense
                            clearable
                          />
                        </ValidationProvider>
                      </v-col>
                    </v-row>
                    <v-row>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Company Address *</strong>
                        </div>
                        <ValidationProvider v-slot="{ errors }" :rules="(billingType === 1 || billingType === 2 || billingType === 3) ? 'required|alpha_num_whitespace_special_line_break' : ''" name="companyAddress">
                          <v-textarea
                            v-model.trim="companyAddress"
                            :disabled="!(billingType === 1 || billingType === 2 || billingType === 3)"
                            :error-messages="errors"
                            placeholder="Enter enter company's address"
                            rows="1"
                            dense
                            auto-grow
                          />
                        </ValidationProvider>
                      </v-col>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Client Name and Email Address *</strong>
                        </div>
                        <v-autocomplete
                          v-model="selectedClients"
                          :hide-no-data="!searchClients"
                          :items="getProjectClients"
                          :search-input.sync="searchClients"
                          item-text="name"
                          item-value="id"
                          attach
                          chips
                          dense
                          placeholder="Select Existing Client"
                          multiple
                          clearable
                          :error="validateClientDetails"
                          :error-messages="errorMsg"
                          @click="validateField"
                          @change="validateField"
                        >
                          <template v-slot:selection="data">
                            <v-tooltip max-width="350px" top>
                              <template v-slot:activator="{ on }">
                                <span
                                  v-if="data.index <= 2"
                                  v-bind="data.attrs"
                                  :input-value="data.selected"
                                  close
                                  style="padding-left: 10px;"
                                  v-on="on"
                                  @click="data.select"
                                  @click:close="removeItemFromArray(data.item, 'selectedClients')"
                                >
                                  <v-avatar
                                    :color="`${randomColors()}`"
                                    size="30"
                                    style="padding:4px"
                                    v-on="on"
                                  >
                                    <span class="white--text headline">{{ avatarNames(data.item.name) }}</span>
                                  </v-avatar>
                                </span>

                                <v-menu
                                  bottom
                                  origin="center center"
                                  transition="scale-transition"
                                >
                                  <template v-slot:activator="{ on }">
                                    <v-btn
                                      v-if="data.index === 3"
                                      class="ml-1 mr-1 text-capitalize"
                                      outlined
                                      rounded
                                      fab
                                      small
                                      height="30"
                                      width="30"
                                      color="blue"
                                      v-on="on"
                                      @click="projectDetail.openProjectClientList = !projectDetail.openProjectClientLis"
                                    >
                                      <v-icon x-small style="height: 10px; width: 10px">
                                        mdi-plus
                                      </v-icon>
                                      {{ selectedClients.length - 3 }}
                                    </v-btn>
                                  </template>
                                  <v-card
                                    v-show="projectDetail.openProjectClientList"
                                    class="mx-auto"
                                    max-width="300"
                                    raised
                                  >
                                    <v-list
                                      v-if="selectedClientsData.length > 3"
                                      disabled
                                      shaped
                                    >
                                      <v-list-item-group
                                        v-model="selectedClientsData"
                                      >
                                        <v-list-item
                                          v-for="clientData in selectedClientsData.slice(3,selectedClientsData.length)"
                                          v-show="projectDetail.openProjectClientList"
                                          :key="clientData.id"
                                        >
                                          <v-avatar
                                            :color="`${randomColors()}`"
                                            size="30"
                                            style="padding:4px"
                                          >
                                            <strong class="white--text headline">{{ avatarNames(clientData.name) }}</strong>
                                          </v-avatar>
                                          <v-list-item-content class="ml-2">
                                            <v-list-item-title v-text="clientData.name" />
                                          </v-list-item-content>
                                        </v-list-item>
                                      </v-list-item-group>
                                    </v-list>
                                  </v-card>
                                </v-menu>

                              </template>
                              <div>
                                <strong>{{ (data.item.emails && data.item.emails !== '') ? data.item.emails : '' }}</strong>
                              </div>
                            </v-tooltip>
                          </template>
                          <template v-slot:item="data">
                            <v-list-item-content>
                              <v-list-item-title v-html="data.item.name" />
                              <v-list-item-subtitle>{{ (data.item.emails && data.item.emails !== '') ? data.item.emails : '' }}</v-list-item-subtitle>
                            </v-list-item-content>
                          </template>
                        </v-autocomplete>
                        <!-- </ValidationProvider> -->
                      </v-col>
                    </v-row>
                    <v-row>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                        </div>
                      </v-col>
                      <v-col md="8" class="p-b-0 addNewClient" >
                        <div class="field">
                          <strong>Add New</strong>
                        </div>
                        <v-row>
                          <v-col md="5" class="pb-0">
                            <v-text-field
                              v-model.trim="clientName"
                              placeholder="Enter client's name"
                              dense
                              solo-inverted
                              rounded
                            />
                          </v-col>
                          <v-col md="5" class="pb-0">
                            <v-text-field
                              v-model.trim="clientEmail"
                              placeholder="Enter client's email id"
                              dense
                              solo-inverted
                              rounded
                              class="error--text"
                            />
                          </v-col>
                          <v-col md="2" class="pb-0">
                            <v-btn
                              v-if="clientName != '' && clientEmail != ''"
                              class="btn-color"
                              depressed
                              @click="createMoreClientDetails"
                            >
                              Save
                            </v-btn>
                            <v-btn
                              v-else
                              class="btn-color"
                              depressed
                              disabled
                              @click="createMoreClientDetails"
                            >
                              Save
                            </v-btn>
                          </v-col>
                        </v-row>
                      </v-col>
                    </v-row>
                  </v-card-text>
                </div>
              </v-card>
            </v-stepper-content>
            <v-stepper-step complete :step="timelineTab">
              Timeline
            </v-stepper-step>
            <v-stepper-content step="1">
              <v-card class="projectInitiationFormInner">
                <div class="content bottomSpace">
                  <v-card-text class="cardContent">
                    <v-row>
                      <v-col md="4" class="p-b-0">
                        <div class="field"><strong>Project Duration *</strong></div>
                        <v-row>
                          <v-col cols="12" md="8" class="projectDurationFld pr-0">
                            <v-menu
                              ref="TimelineMenu"
                              v-model="menu"
                              :close-on-content-click="false"
                              offset-y
                              transition="scale-transition"
                            >
                              <template v-slot:activator="{ on }">
                                <v-text-field
                                  slot="activator"
                                  v-model="dates"
                                  multiple
                                  readonly
                                  dense
                                  solo-inverted
                                  filled
                                  v-on="on"
                                >
                                  <template v-slot:prepend-inner>
                                    <v-icon v-on="on">
                                      mdi-calendar
                                    </v-icon>
                                  </template>
                                </v-text-field>
                              </template>
                              <v-date-picker
                                v-model="datePicker"
                                range
                                no-title
                                scrollable
                                @change="changeTimelineFromDateString"
                              />
                            </v-menu>
                          </v-col>
                          <v-col cols="12" md="4" class="projectDurationFld pl-1">
                            <v-text-field
                              v-model="totalDays"
                              label="Days"
                              solo-inverted
                              dense
                              readonly
                            />
                          </v-col>
                        </v-row>
                      </v-col>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>{{ (billingType === 1) ? 'Total Approved Hours *' : 'Maximum Hours Billed *' }}</strong>
                        </div>
                        <ValidationProvider
                          v-if="billingType === 1"
                          v-slot="{ errors }"
                          :rules="'required|numeric|max:10'"
                          name="approvedHours"
                        >
                          <v-text-field
                            v-model="approvedHours"
                            :error-messages="errors"
                            placeholder="Approved Hours"
                            dense
                          />
                        </ValidationProvider>
                        <ValidationProvider
                          v-else
                          v-slot="{ errors }"
                          :rules="'required|numeric|max:10'"
                          name="maximumHoursBilled"
                        >
                          <v-text-field
                            v-model="maximumHoursBilled"
                            :error-messages="errors"
                            placeholder="Approved Hours "
                            dense
                          />
                        </ValidationProvider>
                      </v-col>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Billing Interval{{ (billingType === 1 || billingType === 2 || billingType === 3) ? ' *' : '' }}</strong>
                        </div>
                        <div v-if="billingType === 1 || billingType === 2 || billingType === 3">
                          <ValidationProvider
                            v-slot="{ errors }"
                            :rules="'required'"
                            name="billingInterval"
                          >
                            <v-autocomplete
                              v-model="billingInterval"
                              :items="billingIntervalArray"
                              :error-messages="errors"
                              clearable
                              placeholder="Please select billing interval"
                              item-text="name"
                              item-value="value"
                              dense
                            />
                          </ValidationProvider></div>
                        <div v-else >
                          <v-autocomplete
                            v-model="billingInterval"
                            :items="billingIntervalArray"
                            clearable
                            placeholder="Please select billing interval"
                            item-text="name"
                            item-value="value"
                            dense
                          />
                        </div>
                      </v-col>
                    </v-row>
                  </v-card-text>
                </div>
              </v-card>
            </v-stepper-content>
            <v-stepper-step complete :step="projectComponentTab">
              Project Components
            </v-stepper-step>
            <v-stepper-content step="1">
              <v-card class="projectInitiationFormInner">
                <div class="content bottomSpace">
                  <v-card-text class="cardContent">
                    <v-row>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Project Components *</strong>
                        </div>
                        <ValidationProvider :rules="'required'" name="selected">
                          <v-chip-group
                            v-model="selected"
                            :mandatory="false"
                            active-class="deep-purple accent-4 white--text"
                            column
                            multiple
                          >
                            <div class="projectComp">
                              <v-chip
                                value="web"
                                class="ml-2"
                                hide-details
                              >
                                Web Application
                              </v-chip>
                              <v-chip
                                value="mobile"
                                class="ml-2"
                                hide-details
                              >
                                Mobile Application
                              </v-chip>
                              <v-chip
                                value="design"
                                class="ml-2"
                                hide-details
                              >
                                Designing
                              </v-chip>
                              <v-chip
                                value="other"
                                class="ml-2"
                                hide-details
                              >
                                other
                              </v-chip>
                              <ValidationProvider v-if="selected.includes('other')" v-slot="{ errors }" :rules="`required|alpha_num_whitespace_special`" name="otherComponents">
                                <div class="otherProjComp">
                                  <v-text-field
                                    v-if="selected.includes('other')"
                                    v-model.trim="otherComponents"
                                    :error-messages="errors"
                                    :placeholder="`Type Here...`"
                                    outlined
                                    dense
                                  />
                                </div>
                              </ValidationProvider>
                            </div>
                          </v-chip-group>
                        </ValidationProvider>
                      </v-col>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Account Manager *</strong>
                        </div>
                        <ValidationProvider v-slot="{ errors }" :rules="'required'" name="selectedManager">
                          <v-autocomplete
                            v-model="selectedManager"
                            :error-messages="errors"
                            :items="userDetail"
                            :search-input.sync="searchPm"
                            item-text="full_name"
                            item-value="id"
                            attach
                            chips
                            dense
                            placeholder="Select Account Manager(s)"
                            multiple
                            @change="searchPm=''"
                          >
                            <template v-slot:selection="data">
                              <v-tooltip max-width="350px" top>
                                <template v-slot:activator="{ on }">
                                  <v-chip
                                    v-if="data.index === 0"
                                    v-bind="data.attrs"
                                    :input-value="data.selected"
                                    close
                                    v-on="on"
                                    @click="data.select"
                                    @click:close="removeItemFromArray(data.item, 'selectedManager')"
                                  >
                                    <strong>{{ data.item.full_name }}</strong>
                                  </v-chip>
                                  <v-menu
                                    bottom
                                    origin="center center"
                                    transition="scale-transition"
                                  >
                                    <template v-slot:activator="{ on }">
                                      <v-btn
                                        v-if="data.index === 1"
                                        class="ml-1 mr-1 text-capitalize"
                                        outlined
                                        rounded
                                        fab
                                        small
                                        height="30"
                                        width="30"
                                        color="blue"
                                        v-on="on"
                                        @click="projectDetail.openProjectAMList = !projectDetail.openProjectAMLis"
                                      >
                                        <v-icon x-small style="height: 10px; width: 10px">
                                          mdi-plus
                                        </v-icon>
                                        {{ selectedManager.length - 1 }}
                                      </v-btn>
                                    </template>
                                    <v-card
                                      v-show="projectDetail.openProjectAMList"
                                      class="mx-auto"
                                      max-width="300"
                                      raised
                                    >
                                      <v-list
                                        v-if="selectedAMData.length > 1"
                                        disabled
                                        shaped
                                      >
                                        <v-list-item-group
                                          v-model="selectedAMData"
                                        >
                                          <v-list-item
                                            v-for="accountManager in selectedAMData.slice(1, selectedAMData.length)"
                                            v-show="projectDetail.openProjectAMList"
                                            :key="accountManager.id"
                                          >
                                            <v-avatar
                                              :color="`${randomColors()}`"
                                              size="30"
                                              style="padding:4px"
                                            >
                                              <strong class="white--text headline">{{ avatarNames(accountManager.full_name) }}</strong>
                                            </v-avatar>
                                            <v-list-item-content class="ml-2">
                                              <v-list-item-title v-text="accountManager.full_name" />
                                            </v-list-item-content>
                                          </v-list-item>
                                        </v-list-item-group>
                                      </v-list>
                                    </v-card>
                                  </v-menu>
                                </template>
                                <div>
                                  <strong>{{ (data.item.job_title && data.item.job_title !== '') ? data.item.job_title : '' }}</strong><br>
                                  {{ `Emp # ${data.item.employee_id} | ${(data.item.dept[0]) ? data.item.dept[0].name : ''}` }}
                                </div>
                              </v-tooltip>
                            </template>
                            <template v-slot:item="data">
                              <v-list-item-content>
                                <v-list-item-title v-html="data.item.full_name" />
                                <v-list-item-subtitle>{{ (data.item.job_title && data.item.job_title !== '') ? data.item.job_title : '' }}</v-list-item-subtitle>
                                <v-list-item-subtitle>{{ `Emp # ${data.item.employee_id} | ${(data.item.dept[0]) ? data.item.dept[0].name : ''}` }}</v-list-item-subtitle>
                              </v-list-item-content>
                            </template>
                          </v-autocomplete>
                        </ValidationProvider>
                      </v-col>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Project Manager *</strong>
                        </div>
                        <ValidationProvider v-slot="{ errors }" :rules="'required'" name="projectManager">
                          <v-autocomplete
                            v-model="selectedProjectManager"
                            :error-messages="errors"
                            :items="userDetail"
                            :search-input.sync="searchAm"
                            item-text="full_name"
                            item-value="id"
                            attach
                            chips
                            dense
                            placeholder="Select Project Manager(s)"
                            multiple
                            @change="searchAm=''"
                          >
                            <template v-slot:selection="data">
                              <v-tooltip max-width="350px" top>
                                <template v-slot:activator="{ on }">
                                  <v-chip
                                    v-if="data.index === 0"
                                    v-bind="data.attrs"
                                    :input-value="data.selected"
                                    close
                                    v-on="on"
                                    @click="data.select"
                                    @click:close="removeItemFromArray(data.item, 'selectedProjectManager')"
                                  >
                                    <strong>{{ data.item.full_name }}</strong>
                                  </v-chip>
                                  <v-menu
                                    bottom
                                    origin="center center"
                                    transition="scale-transition"
                                  >
                                    <template v-slot:activator="{ on }">
                                      <v-btn
                                        v-if="data.index === 1"
                                        class="ml-1 mr-1 text-capitalize"
                                        outlined
                                        rounded
                                        fab
                                        small
                                        height="30"
                                        width="30"
                                        color="blue"
                                        v-on="on"
                                        @click="projectDetail.openProjectPMList = !projectDetail.openProjectPMLis"
                                      >
                                        <v-icon x-small style="height: 10px; width: 10px">
                                          mdi-plus
                                        </v-icon>
                                        {{ selectedProjectManager.length - 1 }}
                                      </v-btn>
                                    </template>
                                    <v-card
                                      v-show="projectDetail.openProjectPMList"
                                      class="mx-auto"
                                      max-width="300"
                                      raised
                                    >
                                      <v-list
                                        v-if="selectedPMData.length > 1"
                                        disabled
                                        shaped
                                      >
                                        <v-list-item-group
                                          v-model="selectedPMData"
                                        >
                                          <v-list-item
                                            v-for="projectManager in selectedPMData.slice(1, selectedPMData.length)"
                                            v-show="projectDetail.openProjectPMList"
                                            :key="projectManager.id"
                                          >
                                            <v-avatar
                                              :color="`${randomColors()}`"
                                              size="30"
                                              style="padding:4px"
                                            >
                                              <strong class="white--text headline">{{ avatarNames(projectManager.full_name) }}</strong>
                                            </v-avatar>
                                            <v-list-item-content class="ml-2">
                                              <v-list-item-title v-text="projectManager.full_name" />
                                            </v-list-item-content>
                                          </v-list-item>
                                        </v-list-item-group>
                                      </v-list>
                                    </v-card>
                                  </v-menu>
                                </template>
                                <div>
                                  <strong>{{ (data.item.job_title && data.item.job_title !== '') ? data.item.job_title : '' }}</strong><br>
                                  {{ `Emp # ${data.item.employee_id} | ${(data.item.dept[0]) ? data.item.dept[0].name : ''}` }}
                                </div>
                              </v-tooltip>
                            </template>
                            <template v-slot:item="data">
                              <v-list-item-content>
                                <v-list-item-title v-html="data.item.full_name" />
                                <v-list-item-subtitle>{{ (data.item.job_title && data.item.job_title !== '') ? data.item.job_title : '' }}</v-list-item-subtitle>
                                <v-list-item-subtitle>{{ `Emp # ${data.item.employee_id} | ${(data.item.dept[0]) ? data.item.dept[0].name : ''}` }}</v-list-item-subtitle>
                              </v-list-item-content>
                            </template>
                          </v-autocomplete>
                        </ValidationProvider>
                      </v-col>
                    </v-row>
                    <v-row>
                      <v-col md="4" class="p-b-0">
                        <div class="field">
                          <strong>Tech Stack *</strong>
                        </div>
                        <ValidationProvider v-slot="{ errors }" :rules="'required'" name="selectedTechnologies">
                          <v-autocomplete
                            v-model="selectedTechnologies"
                            :filter="filter"
                            :hide-no-data="!searchTech"
                            :error-messages="errors"
                            :items="technologies"
                            :search-input.sync="searchTech"
                            item-text="name"
                            item-value="id"
                            attach
                            chips
                            dense
                            placeholder="Please select tech stack"
                            multiple
                            clearable
                            @change="searchTech=''"
                            @keyup.enter="submitNewTech(searchTech)"
                          >
                            <template v-slot:no-data />
                            <template v-slot:prepend-item>

                              <v-list-item v-if="searchTech !== null && searchTech !== '' && techNameArray.findIndex(item => ((searchTech) ? searchTech.toLowerCase() : searchTech) === ((item) ? item.toLowerCase() : item)) < 0">
                                <span class="subheading">Create</span>
                                <v-chip
                                  color="teal lighten-3"
                                  label
                                  small
                                  @click="createNewTech(searchTech)"
                                >
                                  {{ searchTech }}
                                </v-chip>
                              </v-list-item>

                            </template>
                            <template v-slot:selection="data">
                              <v-chip
                                v-bind="data.attrs"
                                :input-value="data.selected"
                                close
                                @click="data.select"
                                @click:close="removeItemFromArray(data.item, 'selectedTechnologies')"
                              >
                                <strong>{{ data.item.name }}</strong>&nbsp;
                              </v-chip>
                            </template>
                            <template v-slot:selection="{ attrs, item, parent, selected, index }">
                              <v-tooltip top>
                                <template v-slot:activator="{ on }">
                                  <v-chip
                                    v-if="item === Object(item) && index <= 1"
                                    v-bind="attrs"
                                    :input-value="selected"
                                    label
                                    small
                                    v-on="on"
                                  >
                                    <span class="pr-2">
                                      {{ item.name.length >= 47? item.name.slice(0,47) + '...': item.name }}
                                    </span>
                                  </v-chip>

                                  <v-menu
                                    bottom
                                    origin="center center"
                                    transition="scale-transition"
                                  >
                                    <template v-slot:activator="{ on }">
                                      <v-btn
                                        v-if="index === 2"
                                        class="ml-1 mr-1 text-capitalize"
                                        outlined
                                        rounded
                                        fab
                                        small
                                        height="30"
                                        width="30"
                                        color="blue"
                                        v-on="on"
                                        @click="projectDetail.openProjectTechList = !projectDetail.openProjectTechLis"
                                      >
                                        <v-icon x-small style="height: 10px; width: 10px">
                                          mdi-plus
                                        </v-icon>
                                        {{ selectedTechnologies.length - 2 }}
                                      </v-btn>
                                    </template>
                                    <v-card
                                      v-show="projectDetail.openProjectTechList"
                                      class="mx-auto"
                                      max-width="300"
                                      raised
                                    >
                                      <v-list
                                        v-if="selectedTechData.length > 2"
                                        disabled
                                        shaped
                                      >
                                        <v-list-item-group
                                          v-model="selectedTechData"
                                        >
                                          <v-list-item
                                            v-for="technologie in selectedTechData.slice(2,selectedTechData.length)"
                                            v-show="projectDetail.openProjectTechList"
                                            :key="technologie.id"
                                          >
                                            <v-avatar
                                              :color="`${randomColors()}`"
                                              size="30"
                                              style="padding:4px"
                                            >
                                              <strong class="white--text headline">{{ avatarNames(technologie.name) }}</strong>
                                            </v-avatar>
                                            <v-list-item-content class="ml-2">
                                              <v-list-item-title v-text="technologie.name" />
                                            </v-list-item-content>
                                          </v-list-item>
                                        </v-list-item-group>
                                      </v-list>
                                    </v-card>
                                  </v-menu>
                                </template>
                                <span>{{ item.name }}</span>
                              </v-tooltip>
                            </template>
                          </v-autocomplete>
                        </ValidationProvider>
                      </v-col>
                      <v-col md="8" class="p-b-0 addNewClient">

                        <div class="field">
                          <strong>Project Document Links *</strong>
                        </div>

                        <v-row v-for="(project, index) in projectDocuments" :key="index">
                          <v-col
                            md="10"
                          >
                            <ValidationProvider v-slot="{ errors }" :name="`projectLink-${++index}`" :rules="'required|alpha_num_whitespace_special'">
                              <v-text-field
                                v-model.trim="project.link"
                                :error-messages="errors"
                                :placeholder="`Paste url here`"
                                dense
                                solo-inverted
                                rounded
                              />
                            </ValidationProvider>
                          </v-col>
                          <v-col
                            cols="12"
                            md="2"
                          >
                            <span v-if="projectDocuments.length === index" class="d-inline">
                              <v-btn
                                class="addMoreBtn"
                                fab
                                x-small
                                @click="addMoreProjectDocsField"
                              >
                                <v-icon>
                                  mdi-plus
                                </v-icon>
                              </v-btn>
                            </span>
                            <span v-if="index > 1" class="d-inline">
                              <v-btn
                                class="minusBtn"
                                fab
                                color="error"
                                x-small
                                @click="removeDocumentsLink(index)"
                              >
                                <v-icon>
                                  mdi-minus
                                </v-icon>
                              </v-btn>
                            </span>
                          </v-col>
                        </v-row>
                      </v-col>
                    </v-row>
                  </v-card-text>
                </div>
              </v-card>
            </v-stepper-content>
          </div>
        </div>
      </v-stepper>
    </ValidationObserver>
  </div>
</template>

<script>
import Vue from 'vue'
import VueScrollTo from 'vue-scrollto'
import { mapGetters, mapActions } from 'vuex'
import Dialog from '@/components/Dialog.vue'
import CommonSnackbar from '@/components/CommonSnackbar'
import constant from '@/constants/closure-checklist.js'
import { projectHelpers, compareArrays } from '@/helpers/helper.js'
import CountryData from '@/configs/countryData.js'
Vue.use(CountryData)
Vue.use(VueScrollTo)

export default {
  name: 'CreationRequest',
  layout: 'authenticated',
  middleware: 'authenticated',
  components: {
    Dialog,
    CommonSnackbar
  },
  data () {
    return {
      reg: /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,24}))$/,
      Step1Error: false,
      Step2Error: false,
      Step3Error: false,
      Step4Error: false,
      snackbarValue: false,
      snackbarText: '',
      projectName: '',
      projectTypeId: null,
      governanceCategoryId: null,
      approvedHours: '',
      maximumHoursBilled: '',
      companyAddress: '',
      billingType: '',
      selectedDomains: [],
      userDetail: [],
      activeUserId: [],
      projectDocumentsLink: '',
      projectSummary: '',
      max: 0,
      model: 'Foobar',
      selected: [],
      selectedTechnologies: [],
      searchTech: '',
      searchAm: '',
      searchPm: '',
      fab: false,
      selectedManager: [],
      selectedProjectManager: [],
      projectDocuments: [],
      projectStatus: '',
      validateClientDetails: false,
      errorMsg: '',
      submitted: false,
      domainNameArray: [],
      searchDomain: null,
      newArray: [],
      formattedStringDate: null,
      editableProjectDetails: [],
      selectedArray: ['web', 'mobile', 'design', 'other'],
      techNameArray: [],
      projectLifeCycleModel: null,
      billingIntervalArray: [{ name: 'Weekly', value: 0 }, { name: 'Monthly', value: 1 }, { name: 'Fortnightly', value: 2 }],
      billingInterval: null,
      subProject: false,
      subProjectId: null,
      identifier: '',
      menu: '',
      generalDetailTab: 1,
      clientDetailTab: 2,
      timelineTab: 3,
      projectComponentTab: 4,
      e6: 1,
      toDatePicker: '',
      toTimelineDatePicker: null,
      toTimelineDateString: null,
      fromTimelineDatePicker: null,
      fromTimelineDateString: null,
      datePicker: [],
      dates: '',
      totalDays: '',
      newCountryData: CountryData,
      newStateData: [],
      companyState: '',
      companyCountry: '',
      searchClients: null,
      selectedClients: [],
      clientDetails: [],
      companyName: '',
      clientName: '',
      clientEmail: '',
      openProjectDomainList: false,
      openProjectClientList: false,
      openProjectAMList: false,
      openProjectPMList: false,
      openProjectTechList: false,
      openProjectManagerList: false,
      openAccountManagerList: false,
      selectedDomainData: [],
      selectedTechData: [],
      selectedAMData: [],
      selectedPMData: [],
      selectedClientsData: [],
      projectDetail: '',
      billingMediumId: null
    }
  },
  computed: {
    ...mapGetters({
      getProjectDetail: 'project/getProjectDetail',
      technologies: 'project/getTechnologies',
      departments: 'project/getDepartments',
      // projects: 'project/getProjectList',
      users: 'project/getUserList',
      isButtonLoading: 'project/isButtonLoading',
      getCustomDialog: 'project/getCustomDialog',
      getProjectDomains: 'project/getProjectDomains',
      billingTypes: 'project/getBillingTypes',
      projectTypes: 'project/getProjectType',
      governanceCategories: 'project/getGovernanceCategories',
      getProjectNameListing: 'project/getProjectNameListing',
      getRedminProjectNameList: 'project/getRedminProjectNameList',
      getProjectLifeCycleModel: 'project/getProjectLifeCycleModel',
      getProjectClients: 'project/getProjectClients',
      billingMediums: 'project/getBillingMediums',
      getAddedClient: 'project/getAddedClient'
    }),
    cardImg () {
      return require('@/assets/images/custom/creationCard.png')
    }
  },
  watch: {
    selectedDomains () {

      this.selectedDomainData = []
      this.selectedDomains.forEach((id) => {
        const domains = this.getProjectDomains.filter((item) => { return item.id === id })

        this.selectedDomainData.push(domains[0])
      })
    },

    selectedTechnologies () {
      this.selectedTechData = []
      this.selectedTechnologies.forEach((id) => {
        const tech = this.technologies.filter((item) => { return item.id === id })

        this.selectedTechData.push(tech[0])
      })
    },

    selectedProjectManager () {
      this.selectedPMData = []
      this.selectedProjectManager.forEach((id) => {
        const tech = this.userDetail.filter((item) => { return item.id === id })

        this.selectedPMData.push(tech[0])
      })
    },

    selectedManager () {
      this.selectedAMData = []
      this.selectedManager.forEach((id) => {
        const tech = this.userDetail.filter((item) => { return item.id === id })

        this.selectedAMData.push(tech[0])
      })
    },
    selectedClients () {
      this.selectedClientsData = []
      this.selectedClients.forEach((id) => {
        const tech = this.getProjectClients.filter((item) => { return item.id === id })

        this.selectedClientsData.push(tech[0])
      })
    }

  },
  async fetch ({ app, store, route }) {
    // eslint-disable-next-line no-useless-catch
    try {
      await Promise.all([
        store.dispatch('project/fetchProjectDetail', route.params.id),
        store.dispatch('project/fetchProjectDomains'),
        store.dispatch('project/fetchTechnologies'),
        store.dispatch('project/fetchProjectNameListing'),
        store.dispatch('project/fetchRedmineProjectNameListing'),
        store.dispatch('project/fetchProjectLifeCycleModel'),
        store.dispatch('project/fetchProjectClients')
      ])
    } catch (error) {
      throw (error)
    }
  },

  mounted () {
    this.projectDetail = this.getProjectDetail
    const initiationDate = new Date(this.projectDetail.initiation_date)

    this.formattedStringDate = initiationDate.toISOString().substr(0, 10)
    const formattedDate = initiationDate.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })
    let toTimelineDate = null
    let fromTimelineDate = null
    const domainIds = []

    if (this.projectDetail.estimated_timeline_to !== null) {
      toTimelineDate = new Date(this.projectDetail.estimated_timeline_to)
      this.toTimelineDatePicker = toTimelineDate.toISOString().substr(0, 10)
      this.toTimelineDateString = toTimelineDate.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })
    }
    if (this.projectDetail.estimated_timeline_from !== null) {
      fromTimelineDate = new Date(this.projectDetail.estimated_timeline_from)
      this.fromTimelineDatePicker = fromTimelineDate.toISOString().substr(0, 10)
      this.fromTimelineDateString = fromTimelineDate.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })
    }

    if (this.projectDetail.estimated_timeline_to !== null && this.projectDetail.estimated_timeline_from !== null) {
      let dateRange = []

      dateRange = [this.fromTimelineDateString, this.toTimelineDateString]
      this.dates = dateRange.join(' - ')
      this.totalDays = projectHelpers.totalDays(toTimelineDate, fromTimelineDate)
      this.datePicker = [this.toTimelineDatePicker, this.fromTimelineDatePicker]
    }
    this.projectDetail.project_domains.forEach((value) => domainIds.push(value.id))
    this.newArray = this.projectDetail.technologies.map(({ id, ...keepAttrs }) => id)
    const projectComponents = JSON.parse(this.projectDetail.project_components)
    const checkboxComponents = []

    JSON.parse(this.projectDetail.project_components).filter((value) => {
      if (this.selectedArray.includes(value)) {
        checkboxComponents.push(value)
      }
    })
    this.billingType = this.projectDetail.billing_type.id
    this.companyName = this.projectDetail.company_name
    this.projectName = this.projectDetail.project_name
    this.approvedHours = this.projectDetail.approved_hours
    this.companyAddress = this.projectDetail.company_address
    this.selected = checkboxComponents
    this.otherComponents = this.selected.includes('other') ? projectComponents[projectComponents.length - 1] : ''
    this.clientName = this.projectDetail.client_name
    this.selectedTechnologies = this.newArray
    const domainsArray = []

    this.projectDetail.project_domains.forEach((item) => domainsArray.push(item.id))
    this.selectedDomains = domainsArray
    this.maximumHoursBilled = this.projectDetail.maximum_hours_billed
    this.toDatePicker = this.formattedStringDate
    this.projectDocumentsLink = this.projectDetail.project_documents_link
    this.projectSummary = this.projectDetail.project_summary
    this.clientDetails = JSON.parse(this.projectDetail.client_detail)
    this.setClient()
    this.projectDocuments = JSON.parse(this.projectDetail.project_documents_link)
    this.projectStatus = this.projectDetail.status
    this.projectTypeId = this.projectDetail.project_type_id
    this.governanceCategoryId = this.projectDetail.gov_category_id
    if (this.projectDetail.parent_id) {
      this.subProject = true
    } else {
      this.subProject = false
    }
    this.subProjectId = parseInt(this.projectDetail.parent_id)
    this.identifier = this.projectDetail.identifier
    this.projectLifeCycleModel = this.projectDetail.lifecycle_model_id
    this.companyCountry = (this.projectDetail.country === '') ?  null : this.projectDetail.country
    this.setResign ()
    this.companyState = this.projectDetail.state
    this.billingInterval = this.projectDetail.billing_interval
    this.billingMediumId = this.projectDetail.billing_medium
    this.getProjectDomains.forEach((item) => {
      this.domainNameArray.push(item.name)
    })
    this.technologies.forEach((item) => {
      this.techNameArray.push(item.name)
    })
    this.userDetail = this.users
    this.users.forEach((user) => {
      this.activeUserId.push(user.id)
    })

    const allManagers = this.projectDetail.account_managers.concat(this.projectDetail.project_managers)
    const inactiveUserDetail = []

    allManagers.forEach((item) => {
      if (!this.activeUserId.includes(item.user_id)) {
        const userRecord = {
          id: item.user.id,
          full_name: item.user.display_name,
          email: item.user.email,
          employee_id: item.user.employee_id,
          job_title: null,
          dept: [],
          user_department:null
        }

        inactiveUserDetail.push(userRecord)
      }
    })

    this.userDetail = this.userDetail.concat(inactiveUserDetail)

    this.selectedManager = this.projectDetail.account_managers.map(({ user_id: id, ...keepAttrs }) => id)
    this.selectedProjectManager = this.projectDetail.project_managers.map(({ user_id: id, ...keepAttrs }) => id)

    this.editableProjectDetails = {
      'project_name': this.projectDetail.project_name,
      'company_name': this.projectDetail.company_name,
      'company_address': this.projectDetail.company_address,
      'project_domain': domainIds,
      'billing_type': this.projectDetail.billing_type.id,
      'approved_hours': this.projectDetail.approved_hours,
      'project_components': projectComponents,
      'maximum_hours_billed': this.projectDetail.maximum_hours_billed,
      'initiation_date': this.formattedStringDate,
      'estimated_timeline_to': toTimelineDate !== null ? toTimelineDate.toISOString().substr(0, 10) : toTimelineDate,
      'estimated_timeline_from': fromTimelineDate !== null ? fromTimelineDate.toISOString().substr(0, 10) : fromTimelineDate,
      'project_documents_link': JSON.parse(this.projectDetail.project_documents_link),
      'client_detail': JSON.parse(this.projectDetail.client_detail),
      'account_manager_id': this.projectDetail.account_managers.map(({ user_id: id, ...keepAttrs }) => id),
      'project_manager_id': this.projectDetail.project_managers.map(({ user_id: id, ...keepAttrs }) => id),
      'project_summary': this.projectDetail.project_summary,
      'technologies': this.newArray,
      'status': this.projectDetail.status,
      'project_type_id': this.projectDetail.project_type_id,
      'gov_category_id': this.projectDetail.gov_category_id,
      'subProject': this.subProject,
      'parent_id': parseInt(this.projectDetail.parent_id),
      'lifecycle_model_id': this.projectDetail.lifecycle_model_id,
      'state': this.projectDetail.state,
      'country': this.projectDetail.country,
      'billing_interval': this.projectDetail.billing_interval,
      'billing_medium' : this.projectDetail.billing_medium
    }
    this.projectDetail.openProjectManagerList = this.openProjectManagerList
    this.projectDetail.openAccountManagerList = this.openAccountManagerList
    this.projectDetail.openProjectDomainList = this.openProjectDomainList
    this.projectDetail.openProjectClientList = this.openProjectClientList
    this.projectDetail.openProjectAMList = this.openProjectAMList
    this.projectDetail.openProjectPMList = this.openProjectPMList
    this.projectDetail.openProjectTechList = this.openProjectTechList

  },
  methods: {
    ...mapActions({
      updateProjectDetails: 'project/updateProjectDetails',
      setCustomDialog: 'project/setCustomDialog',
      updateLoadingAction: 'project/updateLoadingAction',
      createProjectDomain: 'project/createProjectDomain',
      createTechnologies: 'project/createTechnologies',
      fetchTechnologies: 'project/fetchTechnologies',
      createProjectClient: 'project/createProjectClient',
      setProjectDetail: 'project/setProjectDetail',
      setProjectClientList: 'project/setProjectClientList'

    }),

    validateField () {
      if (this.selectedClients.length > 0) {
        this.errorMsg = ''
        this.validateClientDetails = false
      } else {
        this.errorMsg = 'This field is required'
        this.validateClientDetails = true
      }
    },

    back () {
      this.$router.push('/project-dashboard')
    },

    setResignValues () {
      this.newStateData = projectHelpers.setResignArray(this.newCountryData, this.companyCountry)
      if (!this.companyCountry) {
        this.newStateData = []
      }
      this.companyState = ''
    },
    setResign () {
      this.newStateData = projectHelpers.setResignArray(this.newCountryData, this.companyCountry)
      if (this.newStateData.length === 0 || this.newStateData === null) {
        this.newCountryData = projectHelpers.nonExistCountryData(this.newCountryData, this.projectDetail)

        this.newStateData = projectHelpers.setResignArray(this.newCountryData, this.companyCountry)

      }
      if (!this.companyCountry) {
        this.newStateData = []
      }
    },
    setClient () {
      const data = projectHelpers.setClient(this.clientDetails, this.getProjectClients)

      this.selectedClients = data.selectedClients
      if (Array.isArray(data.getProjectClients) && data.getProjectClients.length) {
        data.getProjectClients.forEach((value, index) => {
          this.getProjectClients.push(value)
        })
      }
    },

    changeTimelineFromDateString (selected) {

      let { startRange, endRange } = selected

      if (selected[0] > selected[1]) {
        endRange = selected[0]
        startRange = selected[1]
      } else {
        endRange = selected[1]
        startRange = selected[0]
      }
      this.fromTimelineDateString = new Date(startRange).toLocaleDateString({
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      })
      this.toTimelineDateString = new Date(endRange).toLocaleDateString({
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      })
      let dateRange = []

      this.fromTimelineDatePicker = projectHelpers.formatDate(startRange)
      this.toTimelineDatePicker = projectHelpers.formatDate(endRange)
      dateRange = [this.fromTimelineDateString, this.toTimelineDateString]
      this.dates = dateRange.join(' - ')
      this.totalDays = projectHelpers.totalDays(new Date(startRange), new Date(endRange))

      return this.dates
    },

    addMoreProjectDocsField () {
      if (this.projectDocuments.length >= 5) {
        this.snackbarValue = true
        this.snackbarText = 'Cannot add more than 5 documents.'

        return
      }
      this.projectDocuments.push({ link: '' })
    },
    removeDocumentsLink (index) {
      this.projectDocuments.splice(index - 1, 1)
    },
    getInitialEndDate () {
      const endDate = new Date()
      const formattedDate = endDate.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })
      const formattedStringDate = endDate.toISOString().substr(0, 10)

      return { formattedDate, formattedStringDate }
    },
    clearOtherComponent () {
      if (this.selected !== 'other') {
        this.otherComponents = ''
      }
    },

    async createMoreClientDetails () {
      const validValue = projectHelpers.alphaNumSpecialValidation(this.clientName)
      const clientvalidValue = projectHelpers.alphaNumSpecialValidation(this.clientEmail)

      if (!validValue) {
        this.snackbarText = 'Client Name value must be word, digit, whitespace and special characters'
        this.snackbarValue = true
        setTimeout(() => {
          this.snackbarValue = false
        }, 3000)
      } else {

        const result = this.getProjectClients.filter((item) => {
          if (item['name'] === this.clientName || item['emails'] === this.clientEmail ) {
            return item
          }
        })

        if (!this.reg.test(this.clientEmail) || clientvalidValue === false) {
          this.snackbarText = 'Email Address Not Valid !!'
          this.snackbarValue = true
          setTimeout(() => {
            this.snackbarValue = false
          }, 3000)
        } else {
          if (result.length > 0) {
            this.snackbarText = 'Client Already Exists !!'
            this.snackbarValue = true
            setTimeout(() => {
              this.snackbarValue = false
            }, 3000)
          } else {
            await this.updateLoadingAction()
            const requestData = {
              'name': this.clientName,
              'email': this.clientEmail
            }

            await this.createProjectClient(requestData)
            this.selectedClients.push(this.getAddedClient.id)
            if (this.selectedClients.length > 0) {
              this.validateClientDetails = false
              this.errorMsg = ''
            }
            this.clientName = ''
            this.clientEmail = ''
            this.updateLoadingAction()
          }
        }

      }

    },
    removeItemFromArray (item, searchString) {
      this.$data[searchString] = this.$data[searchString].filter((arrayItem) => arrayItem !== item.id)
      this.$data[searchString] = [...this.$data[searchString]]
    },
    filter (item, queryText, itemText) {
      const hasValue = (val) => val !== null ? val : ''
      const text = hasValue(itemText)
      const query = hasValue(queryText)

      return text.toString()
        .toLowerCase()
        .includes(query.toString().toLowerCase())
    },
    async submitNewDomain (domainName) {
      if (domainName !== null && domainName !== '' && !this.domainNameArray.includes(domainName)) {
        await this.createProjectDomain({ domainName })
        const createdDomain = this.getProjectDomains.filter((item) => item.name === domainName)

        this.selectedDomains = this.selectedDomains.concat(createdDomain)
        this.searchDomain = ''
        this.snackbarText = this.getCustomDialog.message
        this.snackbarValue = true
        this.domainNameArray = []
        this.getProjectDomains.forEach((item) => {
          this.domainNameArray.push(item.name)
        })
        setTimeout(() => {
          this.snackbarValue = false
        }, 3000)
      }
    },
    async createNewDomain (domainName) {

      const validValue = projectHelpers.alphaNumSpecialValidation(domainName)

      if (!validValue) {
        this.snackbarText = 'This value must be word, digit, whitespace and special characters'
        this.snackbarValue = true
        setTimeout(() => {
          this.snackbarValue = false
        }, 3000)
      } else {
        const existingRecord = this.getProjectDomains.filter((item) => item.name === domainName)

        if (existingRecord.length > 0) {
          this.snackbarText = 'Domain name is duplicate please try a different name!'
          this.snackbarValue = true
          setTimeout(() => {
            this.snackbarValue = false
          }, 3000)
        } else {
          await this.createProjectDomain({ domainName })
          const createdDomain = this.getProjectDomains.filter((item) => item.name === domainName)

          this.selectedDomains = this.selectedDomains.concat(createdDomain)
          this.searchDomain = ''
          this.snackbarText = this.getCustomDialog.message
          this.snackbarValue = true
          this.domainNameArray = []
          this.getProjectDomains.forEach((item) => {
            this.domainNameArray.push(item.name)
          })
          setTimeout(() => {
            this.snackbarValue = false
          }, 3000)
        }
      }
    },
    async submitNewTech (techName) {
      if (techName !== null && techName !== '' && this.techNameArray.findIndex((item) => ((techName) ? techName.toLowerCase() : techName) === ((item) ? item.toLowerCase() : item)) < 0) {
        await this.createTechnologies({ techName })
        if (this.fetchTechnologies()) {
          let techId = []

          this.technologies.filter((item) => {
            if (item.name === techName) {
              techId = item.id
            }
          })
          this.selectedTechnologies = this.selectedTechnologies.concat(techId)
          this.searchTech = ''
          this.snackbarText = this.getCustomDialog.message
          this.snackbarValue = true
          this.techNameArray = []
          this.technologies.forEach((item) => {
            this.techNameArray.push(item.name)
          })
          setTimeout(() => {
            this.snackbarValue = false
          }, 3000)
        }
      }
    },
    async createNewTech (techName) {
      const validValue = projectHelpers.alphaNumSpecialValidation(techName)

      if (!validValue) {
        this.snackbarText = 'This value must be word, digit, whitespace and special characters'
        this.snackbarValue = true
        setTimeout(() => {
          this.snackbarValue = false
        }, 3000)
      } else {
        const existingRecord = this.technologies.filter((item) => item.name === techName)

        if (existingRecord.length > 0) {
          this.snackbarText = 'Technology name is duplicate please try a different name!'
          this.snackbarValue = true
          setTimeout(() => {
            this.snackbarValue = false
          }, 3000)
        } else {
          await this.createTechnologies({ techName })
          if (this.fetchTechnologies()) {
            let techId = []

            this.technologies.filter((item) => {
              if (item.name === techName) {
                techId = item.id
              }
            })
            this.selectedTechnologies = this.selectedTechnologies.concat(techId)
            this.searchTech = ''
            this.snackbarText = this.getCustomDialog.message
            this.snackbarValue = true
            this.techNameArray = []
            this.technologies.forEach((item) => {
              this.techNameArray.push(item.name)
            })
            setTimeout(() => {
              this.snackbarValue = false
            }, 3000)
          }
        }
      }
    },
    randomColors () {
      return projectHelpers.randomColors()
    },
    avatarNames (fullName) {
      return projectHelpers.avatarNames(fullName)

    },

    async saveChanges () {
      this.updateLoadingAction()
      const projectNameExist = this.getProjectNameListing.some((item) => item.project_name.toLowerCase() === this.projectName.toLowerCase())

      if (projectNameExist && this.editableProjectDetails.project_name.toLowerCase() !== this.projectName.toLowerCase()) {
        this.snackbarText = 'Project Name Already Exists !!'
        this.snackbarValue = true
        setTimeout(() => {
          this.snackbarValue = false
        }, 3000)

        return
      }
      if (this.editableProjectDetails.estimated_timeline_to === '') {
        this.editableProjectDetails.estimated_timeline_to = null
      }
      if (this.editableProjectDetails.estimated_timeline_from === '') {
        this.editableProjectDetails.estimated_timeline_from = null
      }
      const selectedDomainIds = []

      this.selectedDomains.forEach((item) => (Number.isInteger(item)) ? selectedDomainIds.push(item) : selectedDomainIds.push(item.id))
      const selectedComponents = []

      if (this.selected.includes('other')) {
        this.selected.filter((value) => {
          if (this.selectedArray.includes(value)) {
            selectedComponents.push(value)
          }
        })
      }
      if (!this.editableProjectDetails.project_type_id || this.editableProjectDetails.project_type_id === '') {
        this.editableProjectDetails.project_type_id = null
      }
      if (!this.editableProjectDetails.gov_category_id || this.editableProjectDetails.gov_category_id === '') {
        this.editableProjectDetails.gov_category_id = null
      }
      if (!this.editableProjectDetails.company_address || this.editableProjectDetails.company_address === '') {
        this.editableProjectDetails.company_address = null
      }
      if (!this.editableProjectDetails.company_name || this.editableProjectDetails.company_name === '') {
        this.editableProjectDetails.company_name = null
      }
      if (!this.editableProjectDetails.maximum_hours_billed || this.editableProjectDetails.maximum_hours_billed === '') {
        this.editableProjectDetails.maximum_hours_billed = null
      }
      if (!this.editableProjectDetails.approved_hours || this.editableProjectDetails.approved_hours === '') {
        this.editableProjectDetails.approved_hours = null
      }
      if (!this.editableProjectDetails.billing_medium || this.editableProjectDetails.billing_medium === '') {
        this.editableProjectDetails.billing_medium = null
      }
      let approvedHrs = null
      let maxHrs = null

      if (this.billingType === constant.BILLING_TYPE.FIXED_COST) {
        approvedHrs = this.approvedHours
      } else {
        maxHrs = this.maximumHoursBilled
      }

      //set client details
      const data = projectHelpers.setClientDetails(this.billingType, this.getProjectClients, this.selectedClients, this.companyName, this.companyAddress, this.companyState, this.companyCountry)

      this.companyName = data.companyName
      this.companyAddress = data.companyAddress
      this.clientDetails = data.clientDetails
      this.companyState = data.companyState
      this.companyCountry = data.companyCountry

      const requestData = {
        'project_name': this.projectName,
        'company_name': (this.companyName === '') ? null : this.companyName,
        'company_address': (this.companyAddress === '') ? null : this.companyAddress,
        'project_domain': selectedDomainIds,
        'billing_type': this.billingType,
        'approved_hours': (approvedHrs === '') ? null : approvedHrs,
        'project_components': this.otherComponents && this.selected.includes('other') ? [...selectedComponents, this.otherComponents] : this.selected,
        'maximum_hours_billed': (maxHrs === '') ? null : maxHrs,
        'initiation_date': this.toDatePicker,
        'estimated_timeline_to': this.toTimelineDatePicker,
        'estimated_timeline_from': this.fromTimelineDatePicker,
        'project_documents_link': this.projectDocuments,
        'client_detail': this.clientDetails,
        'account_manager_id': this.selectedManager,
        'project_manager_id': this.selectedProjectManager,
        'project_summary': this.projectSummary,
        'technologies': this.selectedTechnologies,
        'status': this.projectStatus,
        'project_type_id': (this.projectTypeId && this.projectTypeId !== '') ? this.projectTypeId : null,
        'gov_category_id': (this.governanceCategoryId && this.governanceCategoryId !== '') ? this.governanceCategoryId : null,
        'subProject': this.subProject,
        'parent_id': parseInt(this.subProjectId),
        'lifecycle_model_id': this.projectLifeCycleModel,
        'state': this.companyState,
        'country': this.companyCountry,
        'billing_interval': this.billingInterval,
        'billing_medium': (this.billingMediumId) ? this.billingMediumId : null
      }

      if (isNaN(this.editableProjectDetails.parent_id)) {
        this.editableProjectDetails.parent_id = null
      }
      if (isNaN(requestData.parent_id)) {
        requestData.parent_id = null
      }
      if ((this.editableProjectDetails.parent_id === '' || this.editableProjectDetails.parent_id === null) &&
      (requestData.parent_id === '' || requestData.parent_id === null) ) {
        this.editableProjectDetails.parent_id = requestData.parent_id
      }
      if (this.editableProjectDetails.client_detail.length === 1 && (this.billingType === constant.BILLING_TYPE.INTERNAL || this.billingType === constant.BILLING_TYPE.POC)) {
        this.editableProjectDetails.client_detail[0].full_name = ''
        this.editableProjectDetails.client_detail[0].address = ''
      }
      if (compareArrays.isEqual(this.editableProjectDetails, requestData)) {
        this.snackbarText = 'Please edit at least one record'
        this.snackbarValue = true
        setTimeout(() => {
          this.snackbarValue = false
        }, 3000)

        return
      }

      const allProjectManager = requestData.account_manager_id.concat(requestData.project_manager_id)
      const inActiveUsers = allProjectManager.filter((x) => !this.activeUserId.includes(x))

      if (inActiveUsers.length > 0) {
        const inActiveUserDetail = this.userDetail.filter((item) => { return item.id === inActiveUsers[0] })

        this.snackbarText = `${inActiveUserDetail[0].full_name} is no longer in this organization. Please change the AM/PM.`
        this.snackbarValue = true
        setTimeout(() => {
          this.snackbarValue = false
        }, 3000)

        return
      }

      await this.updateProjectDetails({ id: this.$route.params.id, requestData })
      this.updateLoadingAction()
      this.submitted = true
    }

  }
}
</script>

<style scoped>
.theme--light.v-stepper {
    background: #f2f5f8;
    box-shadow: none;
}

.v-application .mb-12 {
    margin-bottom: 16px !important;
}
.m-b-0 {
    margin-bottom: 0px!important;
}
.p-b-0 {
    padding-top: 0px!important;
    padding-bottom: 0px !important;
}
.theme--light.v-stepper {
    background: #f3f4f7;
}
.btn-color {
    background-color: #1976d2!important;
    color: #ffffff!important;
}
</style>
