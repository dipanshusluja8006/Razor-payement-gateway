<template>
  <div>
    <Dialog />
    <v-dialog
      v-model="validationDialog"
      width="500"
    >
      <v-card>
        <v-spacer />
        <v-card-text align="center" class="iconcenter">
          <v-spacer />
          <v-icon style="margin-top:2%" color="red" class="mdi-48px">
            mdi-alert-circle
          </v-icon>
        </v-card-text>
        <v-card-text align="center">
          {{ dialogText }}
        </v-card-text>

        <v-card-actions>
          <v-col cols="5" />
          <v-col cols="3">
            <v-btn
              color="primary"
              @click="validationDialog = false"
            >
              Ok
            </v-btn>
          </v-col>
          <v-col cols="3" />
        </v-card-actions>
      </v-card>
    </v-dialog>
    <v-card
      class="mx-auto"
      max-width="100%"
    >
      <v-card-text>
        <v-row>
          <v-col cols="12">
            <project-operation :project-details="projectList" :selected-project-name="projectDetail.uuid" :project-action-selected="projectActionSelected"/>
          </v-col>
          <v-col
            cols="12"
          >
            <v-data-table
              :headers="headersForAllocationTable"
              :items="allocationTableData"
              :hide-default-footer="allocationTableData.length ? false : true"
              class="elevation-1"
            >
              <template v-slot:item.start_date="{ item }">
                {{ new Date(item.start_date).toLocaleDateString('en-US', {
                  year: 'numeric',
                  month: 'short',
                  day: 'numeric'
                }) }}
              </template>
              <template v-slot:item.end_date="{ item }">
                {{ new Date(item.end_date).toLocaleDateString('en-US', {
                  year: 'numeric',
                  month: 'short',
                  day: 'numeric'
                }) }}
              </template>
              <template v-slot:item.deallocate_from="{ item }">
                {{ new Date(item.deallocate_from).toLocaleDateString('en-US', {
                  year: 'numeric',
                  month: 'short',
                  day: 'numeric'
                }) }}
              </template>
              <template v-slot:item.action="{ item }">
                <v-checkbox v-model="actionSelected" :value="item.id" />
              </template>
            </v-data-table>
          </v-col>
          <v-col
            cols="12"
            md="5"
          >
            <v-row align="end" justify="center">
              <v-col cols="12">
                <v-btn
                  class="text-capitalize ma-2 white--text"
                  color="blue-grey"
                  @click="$router.push('/project-dashboard')"
                >
                  <v-icon dark left>
                    mdi-arrow-left
                  </v-icon>Back
                </v-btn>
                <v-btn :disabled="submitted" class="text-capitalize" color="primary" @click="submit">
                  Submit
                </v-btn>
              </v-col>
            </v-row>
          </v-col>
        </v-row>
      </v-card-text>
    </v-card>
  </div>
</template>

<script>
import { mapActions, mapGetters } from 'vuex'
import Dialog from '@/components/Dialog.vue'
import ProjectOperation from '@/components/ProjectOperation'

export default {
  name: 'ResourceDeAllocation',
  layout: 'authenticated',
  middleware: 'authenticated',
  components: {
    Dialog,
    ProjectOperation
  },
  data () {
    return {
      projectName: '',
      headersForAllocationTable: [
        { text: 'Resource Name', sortable: false, value: 'resource_name', width: '12%' },
        { text: 'Department', sortable: false, value: 'dept' },
        { text: 'Technology', value: 'tech', sortable: false },
        { text: 'Role', value: 'designation', sortable: false, width: '10%' },
        { text: 'Daily Efforts (Hours)', value: 'efforts', sortable: false },
        { text: 'Deallocate For (Hours)', value: 'deallocate_for', sortable: false },
        { text: 'Start Date', value: 'start_date', sortable: false },
        { text: 'End Date', value: 'end_date', sortable: false },
        { text: 'Billing Type', value: 'billing_type', sortable: false },
        { text: 'De-allocate From', value: 'deallocate_from', sortable: false, width: '8%' },
        { text: 'Requested by', value: 'requested_by', sortable: false },
        { text: 'Requested on', value: 'requested_on', sortable: false }
      ],
      allocationTableData: [],
      fromDateString: '',
      checkbox1: true,
      validationDialog: false,
      dialogText: '',
      projectExistOnRedmine: true,
      actionSelected: [],
      submitted: false,
      projectActionSelected: 'resource-deallocation-resource-manager'
    }
  },
  computed: {
    ...mapGetters({
      projectDetail: 'project/getProjectDetail',
      projectList: 'project/getProjectList',
      getProjectAllocatedResources: 'project/getProjectAllocatedResources',
      isButtonLoading: 'project/isButtonLoading'
    })
  },
  async fetch ({ app, store, route }) {
    // eslint-disable-next-line no-useless-catch
    try {
      await Promise.all([
        store.dispatch('project/fetchProjectList'),
        store.dispatch('project/fetchDeAllocatedMapping', route.params.id),
        store.dispatch('project/fetchProjectDetail', route.params.id)
      ])
    } catch (error) {
      throw (error)
    }
  },
  mounted () {
    this.$nuxt.$emit('headerTitle', 'Resource Deallocate Manager')
    const allocationData = []
    const resourceReqData = this.getProjectAllocatedResources || []

    this.projectExistOnRedmine = this.projectDetail.project_exist_redmine
    resourceReqData.map((deallocatedResource) => {
      const billingType = deallocatedResource.resource_allocation.resource_requisition.billing_type

      if (deallocatedResource.status === '0') {
        allocationData.push({
          id: deallocatedResource.uuid,
          allocation_id: deallocatedResource.allocated_resource_id,
          resource_name: deallocatedResource.resource.display_name,
          resource_id: deallocatedResource.resource.id,
          dept: deallocatedResource.resource_allocation.resource_requisition.department.name,
          tech: deallocatedResource.resource_allocation.resource_requisition.technology.name,
          designation: deallocatedResource.resource_allocation.resource_requisition.designation.name,
          efforts: deallocatedResource.efforts,
          experience: deallocatedResource.resource_allocation.experience,
          deallocate_for: deallocatedResource.hours,
          start_date: deallocatedResource.start_date,
          end_date: deallocatedResource.end_date,
          billing_type: (billingType && billingType === 1) ? 'Billable' : (billingType === 0) ? 'Non-Billable' : '',
          deallocate_from: deallocatedResource.de_allocation_from,
          requested_by: (deallocatedResource.requested_by) ? deallocatedResource.requested_by.display_name : '',
          requested_on: new Date(deallocatedResource.created_at).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
          status: false
        })
      }
    })
    this.projectName = this.projectDetail.project_name
    this.allocationTableData = allocationData
  },
  methods: {
    ...mapActions({
      setDeAllocatedMapping: 'project/setDeAllocatedMapping',
      setCustomDialog: 'project/setCustomDialog',
      updateLoadingAction: 'project/updateLoadingAction'
    }),
    async submit () {
      this.updateLoadingAction()
      if (!this.projectExistOnRedmine) {
        this.dialogText = 'The requested project does not exist on Redmine, please connect with IT and PMO support team.'
        this.validationDialog = true

        return false
      }
      this.allocationTableData.map((allocationTuple) => {
        allocationTuple.status = '1'
        allocationTuple.de_allocation_map_id = allocationTuple.id
      })
      const requestData = {
        de_allocation_map_data: this.allocationTableData,
        project_id: this.$route.params.id
      }

      await this.setDeAllocatedMapping(requestData)
      this.updateLoadingAction()
      this.submitted = true
    }
  }
}
</script>

<style scoped>
.v-text-field__slot >>> .theme--light.v-label--is-disabled {
   color: rgba(0, 0, 0, 0.6);
   font-size: 18px
}
.container {
    max-width: 1250px;
}
</style>
