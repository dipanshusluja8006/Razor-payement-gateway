<template>
  <div>
    <confirm-dialog ref="confirm" />
    <CustomDialog />
    <v-card
      class="mx-auto"
      max-width="100%"
    >
      <common-snackbar :snackbar="snackbarValue" :text-for-snackbar="snackbarText" />
      <v-dialog
        v-model="validationDialog"
        :persistent="true"
      >
        <div class="successPopup">
          <div class="successImg">
            <img src="../../../assets/images/custom/ErrorDialog.png" />
          </div>
          <div class="successText d-flex align-center justify-center">
            <div class="sureTextWrp">
              <h1><v-icon color="red" class="mdi-48px">
                mdi-alert-circle
              </v-icon></h1>
              <p>{{ dialogText }}</p>
              <v-card-actions>
                <v-btn class="yesBtn" text @click="submit(constant.PROJECT_STATUS.ALLOCATION_APPROVAL_REQUESTED)">
                  Yes
                </v-btn>
                <v-btn class="cancleBtn" text @click="validationDialog = false">
                  Cancel
                </v-btn>
              </v-card-actions>
            </div>
          </div>
        </div>
      </v-dialog>
      <v-dialog
        v-model="overBookDialog"
        :persistent="true"
      >
        <div class="successPopup">
          <div class="successImg">
            <v-img :src="popupImage" />
          </div>
          <div class="successText d-flex align-center justify-center">
            <div class="sureTextWrp">
              <h1><v-icon color="red" class="mdi-48px">
                mdi-alert-circle
              </v-icon></h1>
              <p>{{ overBookText }}</p>
              <v-card-actions>
                <v-btn class="yesBtn" text @click="checkValidationBeforeSubmit(true)">
                  Yes
                </v-btn>
                <v-btn class="cancleBtn" text @click="overBookDialog = false">
                  Cancel
                </v-btn>
              </v-card-actions>
            </div>
          </div>
        </div>

      </v-dialog>
      <v-card-text>
        <v-row>
          <v-col cols="12">
            <project-operation :project-details="projectList" :selected-project-name="projectDetail.uuid" :project-action-selected="projectActionSelected"/>
          </v-col>
          <ValidationObserver ref="projectEditObserver" v-slot="{ valid }" class="flWtbl">
            <v-col
              cols="12"
              class="pb-0"
            >
              <h2>Resource Requisition Form</h2>
            </v-col>
            <v-col
              cols="12"
            >
              <v-data-table
                :headers="headersForRequisitionTable"
                :items="requisitionItems"
                :hide-default-footer="requisitionItems.length ? false : true"
                class="elevation-1"
              >
                <!-- <template v-slot:top>
                  <v-toolbar flat>
                    <v-toolbar-title class="font-weight-normal headerTable">
                      Resource Requisition Form
                    </v-toolbar-title>
                    <v-spacer />
                  </v-toolbar>
                </template> -->
                <template v-slot:item.department="{ item }">
                  {{ item.department.name }}
                </template>
                <template v-slot:item.technology="{ item }">
                  {{ item.technology.name }}
                </template>
                <template v-slot:item.designation="{ item }">
                  {{ item.designation.name }}
                </template>
                <template v-slot:item.start_date="{ item }">
                  {{ new Date(item.start_date.substr(0,10)).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }) }}
                </template>
                <template v-slot:item.end_date="{ item }">
                  {{ new Date(item.end_date.substr(0,10)).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }) }}
                </template>
                <template v-slot:item.requested_by="{ item }">
                  {{ (item.requested_user) ? item.requested_user.display_name : '' }}
                </template>
                <template v-slot:item.billing_type="{ item }">
                  {{ (item.billing_type && item.billing_type === 1) ? 'Billable' : (item.billing_type === 0) ? 'Non-Billable' : '' }}
                </template>
                <template v-slot:item.requested_on="{ item }">
                  {{ new Date(item.created_at).toLocaleDateString('en-US', {
                    year: 'numeric', month: 'short', day: 'numeric'
                  }) }}
                </template>
                <template v-slot:item.suggested_resource="{ item }">
                  <span
                    v-for="resource in item.suggested_resource.slice(0,2)"
                    :key="resource.id"
                    class="ma-2"
                    text-color="white"
                  >
                    <v-tooltip top>
                      <template v-slot:activator="{ on }">
                        <v-avatar
                          color="blue lighten-1"
                          size="30"
                          v-on="on"
                        >
                          <span class="white--text headline">{{ avatarNames(resource.full_name) }}</span>
                        </v-avatar>
                      </template>
                      {{ resource.full_name }}
                    </v-tooltip>
                  </span>
                  <v-menu
                    bottom
                    origin="center center"
                    transition="scale-transition"
                  >
                    <template v-slot:activator="{ on }">
                      <v-btn
                        v-if="item.suggested_resource.length > 2"
                        outlined
                        fab
                        x-small
                        color="blue"
                        v-on="on"
                        @click="!false"
                      >
                        <v-icon x-small>
                          mdi-plus
                        </v-icon>
                        {{ item.suggested_resource.slice(2,item.suggested_resource.length).length }}
                      </v-btn>
                    </template>
                    <v-card
                      v-show="!false"
                      class="mx-auto"
                      max-width="300"
                      raised
                    >
                      <v-list
                        v-if="item.suggested_resource.length > 2"
                        disabled
                        shaped
                      >
                        <v-list-item-group
                          v-model="item.suggested_resource"
                          color="primary"
                        >
                          <v-list-item
                            v-for="resource in item.suggested_resource.slice(2,item.suggested_resource.length)"
                            v-show="!false"
                            :key="resource.id"
                          >
                            <v-avatar
                              color="blue"
                              size="30"
                            >
                              <strong class="white--text headline">{{ avatarNames(resource.full_name) }}</strong>
                            </v-avatar>
                            <v-list-item-content class="ml-2">
                              <v-list-item-title v-text="resource.full_name" />
                            </v-list-item-content>
                          </v-list-item>
                        </v-list-item-group>
                      </v-list>
                    </v-card>
                  </v-menu>
                </template>
                <template v-slot:item.action="{ item }">
                  <span v-if="item.status === '1'">
                    Approved
                  </span>
                  <span v-else>
                    <v-btn
                      v-if="showAllocation"
                      rounded
                      class="text-capitalize"
                      color="yellow lighten-3"
                      @click="addAllocationData(item)"
                    >
                      Add
                    </v-btn>
                    <v-btn
                      v-else
                      rounded
                      class="text-capitalize"
                      color="yellow lighten-3"
                      @click="addAllocationData(item)"
                    >
                      Allocate
                    </v-btn>
                  </span>
                </template>
              </v-data-table>
              <v-divider class="pa-2" />
              <v-data-table
                v-if="extensionFormActive"
                :headers="headersForExtensionRequisitionTable"
                :items="extensionData"
                :hide-default-footer="extensionData.length ? false : true"
                class="elevation-1"
              >
                <template v-slot:top>
                  <v-toolbar flat>
                    <v-toolbar-title class="font-weight-normal headerTable">
                      Resource Extension Form
                    </v-toolbar-title>
                    <v-spacer />
                  </v-toolbar>
                </template>
                <template v-slot:item.department="{ item }">
                  {{ item.department.name }}
                </template>
                <template v-slot:item.technology="{ item }">
                  {{ item.technology.name }}
                </template>
                <template v-slot:item.designation="{ item }">
                  {{ item.designation.name }}
                </template>
                <template v-slot:item.start_date="{ item }">
                  {{ new Date(item.start_date.substr(0,10)).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }) }}
                </template>
                <template v-slot:item.end_date="{ item }">
                  {{ new Date(item.end_date.substr(0,10)).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }) }}
                </template>
                <template v-slot:item.billing_type="{ item }">
                  {{ (item.billing_type && item.billing_type === 1) ? 'Billable' : (item.billing_type === 0) ? 'Non-Billable' : '' }}
                </template>
                <template v-slot:item.requested_by="{ item }">
                  {{ (item.requested_user) ? item.requested_user.display_name : '' }}
                </template>
                <template v-slot:item.requested_on="{ item }">
                  {{ new Date(item.created_at).toLocaleDateString('en-US', {
                    year: 'numeric', month: 'short', day: 'numeric'
                  }) }}
                </template>
                <template v-slot:item.action="{ item }">
                  <span v-if="item.status === '1'">
                    Approved
                  </span>
                  <span v-else>
                    <v-btn
                      :disabled="!item.showButton"
                      rounded
                      class="text-capitalize"
                      color="yellow lighten-3"
                      @click="addAllocationData(item)"
                    >
                      Allocate
                    </v-btn>
                  </span>
                </template>
              </v-data-table>
              <v-divider class="pa-2" />
              <div
                cols="12"
                class="pb-3"
              >
                <h2>Resource Allocation Form</h2>
              </div>
              <v-data-table
                :headers="headersForAllocationTable"
                :items="allocationTableData"
                :hide-default-footer="allocationTableData.length ? false : true"
                class="elevation-1"
              >
                <!-- <template v-slot:top>
                  <v-toolbar flat>
                    <v-toolbar-title class="font-weight-normal headerTable">
                      Resource Allocation Form
                    </v-toolbar-title>
                    <v-spacer />
                  </v-toolbar>
                </template> -->
                <template v-slot:item.technology="{ item }">
                  {{ item.technology.name }}
                </template>
                <template v-slot:item.department="{ item }">
                  {{ item.department.name }}
                </template>
                <template v-slot:item.efforts="{ item }">
                  <v-row>
                    <v-col v-if="item.allocation_status === 14 || item.allocation_status === 4" cols="12">
                      {{ item.efforts }}
                    </v-col>
                    <v-col v-else cols="12">
                      <ValidationProvider v-slot="{ errors }" :rules="'required|check_efforts'" :name="item.efforts">
                        <v-text-field
                          v-model.trim="item.efforts"
                          :error-messages="errors"
                          @keyup="checkValidation(errors)"
                        />
                      </ValidationProvider>
                    </v-col>
                  </v-row>
                </template>

                <template v-slot:item.experience="{ item }">
                  <v-row>
                    <v-col v-if="item.allocation_status === 14 || item.allocation_status === 4" cols="12">
                      {{ item.experience }}
                    </v-col>
                    <v-col v-else cols="12">
                      <ValidationProvider v-slot="{ errors }" :rules="`required|check_experience`" :name="item.experience">
                        <v-text-field
                          v-model.trim="item.experience"
                          :error-messages="errors"
                          @keyup="checkValidation(errors)"
                        />
                      </ValidationProvider>
                    </v-col>
                  </v-row>
                </template>

                <template v-slot:item.start_date="{ item }">
                  <v-row>
                    <v-col v-if="item.allocation_status === 14 || item.allocation_status === 4" cols="12">
                      {{ new Date(item.start_date).toLocaleDateString('en-US', {
                        year: 'numeric',
                        month: 'short',
                        day: 'numeric'
                      }) }}
                    </v-col>
                    <v-col v-else cols="12">
                      <v-menu
                        ref="item.resource_req_id"
                        v-model="item.start_date_menu"
                      >
                        <template v-slot:activator="{ on }">
                          <v-text-field
                            :value="new Date(item.start_date).toLocaleDateString('en-US', {
                              year: 'numeric',
                              month: 'short',
                              day: 'numeric'
                            })"
                            readonly
                            v-on="on"
                          />
                        </template>
                        <v-col cols="12" class="pa-0">
                          <v-date-picker v-model="item.start_date" :min="item.requisition_start_date" @change="changeStartDate(item)" @input="item.start_date_menu = false" />
                        </v-col>
                      </v-menu>
                    </v-col>
                  </v-row>
                </template>

                <template v-slot:item.end_date="{ item }">
                  <v-row>
                    <v-col v-if="item.allocation_status === 14 || item.allocation_status === 4" cols="12">
                      {{ new Date(item.end_date).toLocaleDateString('en-US', {
                        year: 'numeric',
                        month: 'short',
                        day: 'numeric'
                      }) }}
                    </v-col>
                    <v-col v-else cols="12">
                      <v-menu
                        ref="item.resource_req_id"
                        v-model="item.end_date_menu"
                      >
                        <template v-slot:activator="{ on }">
                          <v-text-field
                            :value="new Date(item.end_date).toLocaleDateString('en-US', {
                              year: 'numeric',
                              month: 'short',
                              day: 'numeric'
                            })"
                            readonly
                            v-on="on"
                          />
                        </template>
                        <v-col cols="12" class="pa-0">
                          <v-date-picker v-model="item.end_date" :min="item.start_date" @input="item.end_date_menu = false" />
                        </v-col>
                      </v-menu>
                    </v-col>
                  </v-row>
                </template>
                <template v-slot:item.resource_name="{ item }">
                  <v-row>
                    <v-col v-if="item.allocation_status === 14 || item.allocation_status === 4" cols="12">
                      <v-autocomplete
                        v-model="item.resource_name"
                        :items="usersData"
                        :class="{'v-text-field__slot' : item.resource_name}"
                        item-text="full_name"
                        item-value="id"
                        label="Select Resource"
                        disabled
                      />
                    </v-col>
                    <v-col v-else cols="12">
                      <ValidationProvider v-slot="{ errors }" :rules="'required'" :name="actionSelected[item.resource_id]">
                        <v-autocomplete
                          v-model="item.resource_name"
                          :error-messages="errors"
                          :items="usersData.filter((user) => { return user.dept.length !== 0 && user.dept.some(value => value.id === item.department.id) })"
                          item-text="full_name"
                          item-value="id"
                          label="Select Resource"
                        />
                      </ValidationProvider>
                    </v-col>
                  </v-row>
                </template>
                <template v-show="reallocateResource === 0" v-slot:item.action="{ item }">
                  <v-row>
                    <v-col v-if="item.allocation_status === 14" cols="12">
                      Allocated Fully
                    </v-col>
                    <v-col v-else-if="item.allocation_status === 4" cols="12">
                      Partially Allocated
                    </v-col>
                    <v-col v-else cols="12">
                      <v-row>
                        <v-col cols="4">
                          <v-icon
                            small
                            @click="deleteItem(item)"
                          >
                            mdi-delete
                          </v-icon>
                        </v-col>
                        <v-col cols="2">
                          <v-tooltip v-if="overBookResourceArray.includes(item.resource_name) ? true : false" top>
                            <template v-slot:activator="{ on, attrs }">
                              <span v-bind="attrs" v-on="on">
                                <v-icon color="red">mdi-alert-circle-outline</v-icon>
                              </span>
                            </template>
                            <span>Resource Overbooked</span>
                          </v-tooltip>
                        </v-col>
                      </v-row>
                    </v-col>
                  </v-row>
                </template>
              </v-data-table>
            </v-col>
            <v-col
              cols="12"
              md="5"
            >
              <v-btn
                class="text-capitalize ma-2 white--text"
                color="blue-grey"
                @click="$router.push('/project-dashboard')"
              >
                <v-icon dark left>
                  mdi-arrow-left
                </v-icon>Back
              </v-btn>
              <v-btn :disabled="!valid || submitted || !validInput" class="text-capitalize" color="primary" @click="checkValidationBeforeSubmit(false)">
                Submit
              </v-btn>
            </v-col>
          </ValidationObserver>
        </v-row>
      </v-card-text>
    </v-card>
  </div>
</template>

<script>
import { mapActions, mapGetters } from 'vuex'
import CustomDialog from '@/components/Dialog'
import constant from '@/constants/closure-checklist.js'
import CommonSnackbar from '@/components/CommonSnackbar'
import ConfirmDialog from '@/components/ConfirmDialog'
import ProjectOperation from '@/components/ProjectOperation'
import { projectHelpers } from '@/helpers/helper.js'

export default {
  name: 'ResourceReallocation',
  components: { ConfirmDialog, CommonSnackbar, CustomDialog, ProjectOperation },
  layout: 'authenticated',
  middleware: 'authenticated',
  data () {
    return {
      requestedBy: '',
      dialogText: '',
      requestedOn: '',
      projectName: '',
      reallocateResource: 0,
      requisitionItems: [],
      headersForRequisitionTable: [
        { text: 'Department', value: 'department', sortable: false },
        { text: 'Technology', value: 'technology', sortable: false },
        { text: 'Role', sortable: false, value: 'designation' },
        { text: 'No of Resources', value: 'no_of_resource', sortable: false },
        { text: 'Daily Efforts (Hours)', value: 'efforts', sortable: false },
        { text: 'Experience', value: 'experience', sortable: false },
        { text: 'Start Date', value: 'start_date', sortable: false, width: '10%' },
        { text: 'End Date', value: 'end_date', sortable: false, width: '10%' },
        { text: 'Billing Type', value: 'billing_type', sortable: false },
        { text: 'Suggested Resource', value: 'suggested_resource', sortable: false, width: '15%' },
        { text: 'Requested by', value: 'requested_user', sortable: false },
        { text: 'Requested on', value: 'requested_on', sortable: false },
        { text: 'Action', value: 'action', sortable: false }
      ],
      headersForExtensionRequisitionTable: [
        { text: 'Resource Name', sortable: false, value: 'extension_resource_name' },
        { text: 'Department', value: 'department', sortable: false },
        { text: 'Technology', value: 'technology', sortable: false },
        { text: 'Role', sortable: false, value: 'designation' },
        { text: 'No of Resources', value: 'no_of_resource', sortable: false },
        { text: 'Daily Efforts (Hours)', value: 'efforts', sortable: false },
        { text: 'Experience', value: 'experience', sortable: false },
        { text: 'Start Date', value: 'start_date', sortable: false, width: '10%' },
        { text: 'End Date', value: 'end_date', sortable: false, width: '10%' },
        { text: 'Billing Type', value: 'billing_type', sortable: false },
        { text: 'Requested by', value: 'requested_by', sortable: false },
        { text: 'Requested on', value: 'requested_on', sortable: false },
        { text: 'Action', value: 'action', sortable: false }
      ],
      headersForAllocationTable: [
        { text: 'Resource Name', sortable: false, value: 'resource_name' },
        { text: 'Department', sortable: false, value: 'department' },
        { text: 'Technology', value: 'technology', sortable: false },
        { text: 'Role', sortable: false, value: 'designation' },
        { text: 'Daily Efforts (Hours)', value: 'efforts', sortable: false, width: '10%' },
        { text: 'Experience', value: 'experience', sortable: false, width: '10%' },
        { text: 'Start Date', value: 'start_date', sortable: false, width: '11%' },
        { text: 'End Date', value: 'end_date', sortable: false, width: '11%' },
        { text: 'Action', value: 'action', sortable: false }
      ],
      validationDialog: false,
      resourceAllocationMeta: [],
      overBookResourceArray: [],
      overBookText: '',
      overBookDialog: false,
      allocationTableData: [],
      requisitionData: [],
      extensionData: [],
      extensionFormActive: false,
      actionSelected: [],
      projectRequisitionArray: [],
      checkbox1: false,
      dialog: false,
      snackbarValue: false,
      snackbarText: '',
      showAllocation: false,
      submitted: false,
      deletedAllocations: [],
      usersData: [],
      constant,
      validInput: true,
      projectActionSelected: 'resource-reallocation'
    }
  },
  computed: {
    ...mapGetters({
      users: 'project/getUserList',
      projectDetail: 'project/getProjectDetail',
      projectList: 'project/getProjectList',
      projectRequisition: 'project/getProjectRequisitionDepartment',
      getDeclinedResourceAllocationData: 'project/getDeclinedResourceAllocationData',
      isButtonLoading: 'project/isButtonLoading'
    }),
    popupImage () {
      return require('@/assets/images/custom/ErrorDialog.png')
    }
  },
  async fetch ({ app, store, route }) {
    // eslint-disable-next-line no-useless-catch
    try {
      await Promise.all([
        store.dispatch('project/fetchProjectList'),
        store.dispatch('project/fetchProjectDetail', route.params.id),
        store.dispatch('project/fetchProjectResourceRequisitionByDepartment', route.params.id),
        store.dispatch('project/declinedResourceAllocationData', route.params.id)
      ])
    } catch (error) {
      throw (error)
    }
  },
  mounted () {
    this.$nuxt.$emit('headerTitle', 'Resource Reallocation')
    this.requisitionData = this.projectRequisition.resource_requisition.filter((reqItem) => {
      return reqItem.status === '0' && reqItem.resource_allocation.some((element) => element.allocation_status === 15) && reqItem.type === 0
    })
    this.extensionData = this.getDeclinedResourceAllocationData.filter((reqItem) => {
      return reqItem.status === '0' && reqItem.resource_allocation.length > 0 && reqItem.type === 1
    })
    if (this.extensionData.length > 0) {
      this.extensionData.map((item) => {
        item.showButton = false
        item.extension_resource_name = item.resource.display_name

        return item
      })
      this.extensionFormActive = true
    }
    const allocationData = []
    const resourceReqData = this.requisitionData.concat(this.extensionData) || []
    const allocatedResources = []

    for (let i = 0; i < resourceReqData.length; i++) {
      for (let j = 0; j < resourceReqData[i].resource_allocation.length; j++) {
        for (let k = 0; k < resourceReqData[i].resource_allocation[j].resource_allocation_meta.length; k++) {
          if (resourceReqData[i].resource_allocation[j].allocation_status === 14) {
            allocatedResources.push(resourceReqData[i].resource_allocation[j].resource_allocation_meta[k].resource_id)
          }
          const startDate = resourceReqData[i].start_date.substr(0, 10)
          const endDate = resourceReqData[i].end_date.substr(0, 10)
          const allocationTuple = {
            resource_req_id: resourceReqData[i].uuid,
            allocated_resources_uuid: resourceReqData[i].resource_allocation[j].uuid,
            uuid: resourceReqData[i].resource_allocation[j].uuid,
            resource_name: resourceReqData[i].resource_allocation[j].resource_allocation_meta[k].resource.id,
            department: resourceReqData[i].department,
            technology: resourceReqData[i].technology,
            designation: resourceReqData[i].designation.name,
            efforts: resourceReqData[i].resource_allocation[j].resource_allocation_meta[k].hours.toString(),
            experience: resourceReqData[i].resource_allocation[j].experience,
            start_date: resourceReqData[i].resource_allocation[j].resource_allocation_meta[k].start_date.substr(0, 10),
            requisition_start_date: startDate,
            requisition_end_date: endDate,
            end_date: resourceReqData[i].resource_allocation[j].resource_allocation_meta[k].end_date.substr(0, 10),
            status: resourceReqData[i].resource_allocation[j].status,
            allocation_status: resourceReqData[i].resource_allocation[j].allocation_status,
            allocation_id: resourceReqData[i].resource_allocation[j].uuid,
            deallocate_from: new Date().toISOString().substr(0, 10),
            newDate: false,
            action: false,
            start_date_menu: false,
            end_date_menu: false,
            no_of_hours: resourceReqData[i].efforts,
            experience_reqd: resourceReqData[i].experience,
            is_new_resource: false,
            type: resourceReqData[i].type,
            billing_type: resourceReqData[i].billing_type
          }

          allocationData.push(allocationTuple)
        }
      }
    }
    this.projectName = this.projectDetail.project_name
    this.requestedBy = this.projectDetail.initiated_by.display_name
    this.requestedOn = new Date(this.projectDetail.initiation_date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    })
    this.allocationTableData = allocationData
    this.usersData = this.users
    const metaRecord = []

    this.projectRequisition.resource_requisition.forEach((item) => {
      item.resource_allocation.forEach((element) => {
        if (element.mapped_resource !== null) {
          element.resource_allocation_meta.forEach((meta) => {
            if (metaRecord[meta.resource_id]) {
              metaRecord[meta.resource_id].push(meta)
            } else {
              metaRecord[meta.resource_id] = [meta]
            }
          })
        }
      })
    })
    this.mutateRequisition(this.requisitionData)
    this.resourceAllocationMeta = metaRecord
  },
  methods: {
    ...mapActions({
      reallocateResourceAction: 'project/reallocateResourceAction',
      updateLoadingAction: 'project/updateLoadingAction'
    }),
    avatarNames (fullName) {
      return projectHelpers.avatarNames(fullName)
    },
    mutateRequisition (data) {
      let suggestedResources = []

      this.requisitionItems = []
      if (data) {
        data.forEach((value) => {
          let suggested = []
          const type = Object.prototype.toString.call(value.suggested_resource)

          if (value.suggested_resource && value.suggested_resource !== null && value.suggested_resource !== '' && type !== '[object Number]') {
            if (value.suggested_resource.startsWith('[') && value.suggested_resource.endsWith(']')) {
              suggested = JSON.parse(value.suggested_resource)
            }          }

          const type2 = Object.prototype.toString.call(suggested)

          suggestedResources = []
          if (suggested && suggested !== null && (type2 !== '[object Number]' && type2 !== '[object String]')) {
            suggested.map((id) => {
              this.users.forEach((item) => {
                if (id === item.id && value.type === 0) {
                  suggestedResources.push({
                    full_name: item.full_name,
                    id: item.id
                  })
                }
              })
            })
          }
          this.users.forEach((item) => {
            if (value.extension_resource_id !== null && value.extension_resource_id === item.id && value.type === 1) {
              suggestedResources.push({
                full_name: item.full_name,
                id: item.id
              })
            }
          })
          this.requisitionItems.push({
            uuid: value.uuid,
            technology: value.technology,
            designation: value.designation,
            created_at: value.created_at,
            start_date: value.start_date,
            end_date: value.end_date,
            extension_resource_id: value.extension_resource_id,
            experience: value.experience,
            department: value.department,
            billing_type: value.billing_type,
            efforts: value.efforts,
            no_of_resource: value.no_of_resource,
            requested_user: value.requested_user.display_name,
            type: value.type,
            edit: false,
            resource_allocation: value.resource_allocation,
            isDeleted: value.isDeleted,
            suggested_resource: suggestedResources
          })
        })
      }
    },
    addAllocationData (item) {
      this.allocationTableData.push({
        resource_req_id: item.uuid,
        resource_name: '',
        technology: item.technology,
        tech: item.technology.id,
        department: item.department,
        designation: item.designation.name,
        dept: item.department.id,
        efforts: item.efforts,
        experience: item.experience,
        start_date: item.start_date.substr(0, 10),
        end_date: item.end_date.substr(0, 10),
        requisition_start_date: item.start_date.substr(0, 10),
        requisition_end_date: item.end_date.substr(0, 10),
        no_of_hours: item.efforts,
        experience_reqd: item.experience,
        start_date_menu: false,
        status: 0,
        end_date_menu: false,
        is_new_resource: true,
        type: item.type
      })
      this.showAllocation = true
    },
    checkValidation (errors) {
      if (errors.length > 0) {
        this.validInput = false
      } else {
        this.validInput = true
      }

      return this.validInput
    },
    checkResourceOverbooking (data, resourceId, startDate, endDate, hours) {
      let response = false
      let allocatedHours = parseFloat(hours)

      if (data[resourceId]) {
        data[resourceId].forEach((item) => {
          if (item.resource_id === resourceId) {
            if ((new Date(startDate)).getTime() >= (new Date(item.start_date)).getTime() && (new Date(startDate)).getTime() <= (new Date(item.end_date)).getTime()) {
              allocatedHours = allocatedHours + parseFloat(item.hours)
            } else if ((new Date(endDate)).getTime() >= (new Date(item.start_date)).getTime() && (new Date(endDate)).getTime() <= (new Date(item.end_date)).getTime()) {
              allocatedHours = allocatedHours + parseFloat(item.hours)
            }
          }
        })
        if (allocatedHours > 8) {
          response = true
        }
      }

      return response
    },
    deleteItem (item) {
      let isApproved = false

      this.allocationTableData.map((item) => {
        if (item.allocation_status === 14) {
          isApproved = true
        }
      })
      let cloneAllocation = [...this.allocationTableData]

      if (!isApproved) {
        cloneAllocation.splice(cloneAllocation.indexOf(item), 1)
        cloneAllocation = cloneAllocation.filter((allocationItem) => {
          return (allocationItem.status === 0 ||
          allocationItem.allocation_status === 15) &&
          allocationItem.resource_req_id === item.resource_req_id
        })
      }
      if (!cloneAllocation.length) {
        this.snackbarText = 'There must be atleast one allocation per requisition.'
        this.snackbarValue = true
        setTimeout(() => {
          this.snackbarValue = false
        }, 3000)

        return
      }
      const index = this.allocationTableData.indexOf(item)

      if (!item.is_new_resource) {
        this.deletedAllocations.push({
          allocated_id: item.allocated_resources_uuid,
          dept_id: item.department.id,
          resource_req_id: item.resource_req_id,
          resource_name: item.resource_name,
          technology: item.technology,
          tech: item.technology.id,
          department: item.department,
          designation: item.designation.name,
          efforts: item.efforts,
          experience: item.experience,
          start_date: item.start_date.substr(0, 10),
          end_date: item.end_date.substr(0, 10),
          requisition_start_date: item.start_date.substr(0, 10),
          requisition_end_date: item.end_date.substr(0, 10),
          no_of_hours: item.efforts,
          experience_reqd: item.experience,
          start_date_menu: false,
          status: item.status,
          end_date_menu: false,
          is_new_resource: true,
          type: item.type,
          action: item.action,
          allocation_status: item.allocation_status,
          billing_type: item.billing_type,
          deallocate_from: item.deallocate_from,
          newDate: item.newDate,
          uuid: item.uuid
        })
      }
      this.$refs.confirm.open('Delete Requisition', 'Are you sure?', { color: 'red' }).then((confirm) => {
        if (confirm) {
          if (item.type === 1) {
            this.extensionData = this.extensionData.map((element) => {
              if (element.uuid === item.resource_req_id) {
                element.showButton = true
              }

              return element
            })
          }
          this.allocationTableData.splice(index, 1)
          if (this.allocationTableData.length === 0) {
            this.showAllocation = false
          }
        }
      })
    },
    changeStartDate (item) {
      if (item.start_date > item.end_date) {
        item.end_date = item.start_date
      }
    },
    async checkValidationBeforeSubmit (type = false) {
      let abort = false
      let totalResourceRequired = 0
      const { PROJECT_STATUS } = constant || {}
      const { RESOURCE_ALLOCATION_RESPONSE_APPROVE, RESOURCE_ALLOCATION_RESPONSE_DECLINE } = PROJECT_STATUS || {}
      const assignedHours = { }
      let hasPartialAllocation = false
      let hasFullAllocation = false
      let hasNoAllocation = false
      const assignedResourcesPerReq = { }
      const allRequisitionArray = this.requisitionData.concat(this.extensionData)

      allRequisitionArray.forEach((item) => {
        this.projectRequisitionArray.push(item.uuid)
      })
      const requisitionRecord = this.projectRequisition.resource_requisition.filter((item) => this.projectRequisitionArray.includes(item.uuid))

      requisitionRecord.map((reqItem) => {
        totalResourceRequired = totalResourceRequired + reqItem.no_of_resource
        assignedResourcesPerReq[reqItem.uuid] = 0
        assignedHours[reqItem.uuid] = 0
        this.allocationTableData.map((item) => {
          // To calculate the time difference of two date
          let dateDiff = false

          if (item.resource_req_id === reqItem.uuid) {
            ++assignedResourcesPerReq[reqItem.uuid]
            assignedHours[reqItem.uuid] += parseFloat(item.efforts)
            const diffInTimeForStartDate = new Date(item.start_date.substr(0, 10)).getTime() -
              new Date(reqItem.start_date.substr(0, 10)).getTime()

            // To calculate the no. of days between two dates
            const diffInDaysForStartDate = diffInTimeForStartDate / (1000 * 3600 * 24)
            const diffInTimeForEndDate = new Date(item.end_date.substr(0, 10)).getTime() -
              new Date(reqItem.end_date.substr(0, 10)).getTime()

            // To calculate the no. of days between two dates
            const diffInDaysForEndDate = diffInTimeForEndDate / (1000 * 3600 * 24)

            if (diffInDaysForEndDate !== 0 || diffInDaysForStartDate !== 0) {
              dateDiff = true
            }
          }
          if (((item.resource_req_id === reqItem.uuid &&
            item.efforts !== reqItem.efforts) ||
            dateDiff || (item.resource_req_id === reqItem.uuid && item.experience !== reqItem.experience)
          ) && (item.uuid === item.allocation_id && item.allocation_status === RESOURCE_ALLOCATION_RESPONSE_DECLINE)) {
            this.dialogText = 'Current allocation doesn’t fulfill the requirement shared by AM/PM.  AM/PM will be notified via mail and he/she might reject the allocation. Do you still want to continue?'
            abort = true

            return false
          } else if (item.resource_req_id === reqItem.uuid && item.type === 1 && item.resource_name !== reqItem.extension_resource_id) {
            this.dialogText = 'Current allocation doesn’t fulfill the requirement shared by AM/PM.  AM/PM will be notified via mail and he/she might reject the allocation. Do you still want to continue ?'
            abort = true

            return false
          }
        })
        if (assignedResourcesPerReq[reqItem.uuid] === 0) {
          hasNoAllocation = true
          assignedResourcesPerReq[`${reqItem.uuid}-status`] = 'none'
        } else if (assignedResourcesPerReq[reqItem.uuid] === reqItem.no_of_resource) {
          hasFullAllocation = true
          assignedResourcesPerReq[`${reqItem.uuid}-status`] = 'fully'
        } else if (assignedResourcesPerReq[reqItem.uuid] !== reqItem.no_of_resource &&
          assignedResourcesPerReq[reqItem.uuid] !== 0) {
          hasPartialAllocation = true
          assignedResourcesPerReq[`${reqItem.uuid}-status`] = 'partially'
        }
      })
      const resourceIdArray = []
      let isSameResource = false
      const resourceOverbookResource = []

      this.allocationTableData.forEach((row) => {
        if (!resourceIdArray.includes(row.resource_name)) {
          resourceIdArray.push(row.resource_name)
        } else {
          isSameResource = true
        }
        const overbook = this.checkResourceOverbooking(this.resourceAllocationMeta, row.resource_name, row.start_date, row.end_date, row.efforts)

        if (overbook && !row.isDelete) {
          resourceOverbookResource.push(row.resource_name)
        }
      })
      if (isSameResource) {
        this.snackbarText = 'Same Resource exist in multiple allocation'
        this.snackbarValue = true
        setTimeout(() => {
          this.snackbarValue = false
        }, 3000)

        return
      }
      this.overBookResourceArray = resourceOverbookResource
      if (resourceOverbookResource.length > 0 && !type) {
        this.overBookText = 'The selected resource is already allocated on the project for the same duration and efforts which may lead to creating duplicate bookings. Do you still want to continue?'
        this.overBookDialog = true
        abort = true

        return false
      } else {
        this.overBookDialog = false
      }
      if (abort) {
        this.validationDialog = true

        return false
      }
      if (hasPartialAllocation) {
        this.dialogText = 'The present resource allocation doesn’t match with the resources requested by the Account Manager/Project Manager and they may turn down the allocation. Do you still want to continue?'
        this.validationDialog = true
        abort = true

        return false
      }
      if (hasNoAllocation && hasFullAllocation) {
        this.dialogText = 'The resource allocation has not been performed for one or more resource requisition requests which you may need to perform later. Do you still want to continue?'
        this.validationDialog = true
        abort = true

        return false
      }
      if (!abort) {
        await this.submit(RESOURCE_ALLOCATION_RESPONSE_APPROVE)
      }
    },
    async submit (projectStatus) {
      this.updateLoadingAction()
      this.validationDialog = false
      this.filteredAllocationData = this.allocationTableData.filter((allocationItem) => {
        allocationItem.resource_id = allocationItem.resource_name
        allocationItem.dept = allocationItem.department.id
        allocationItem.tech = allocationItem.technology.id

        return allocationItem.allocation_status === 15 || allocationItem.status === 0
      })
      const requestData = {
        allocation_data: this.filteredAllocationData,
        project_id: this.$route.params.id,
        project_status: projectStatus,
        deleted_allocations: this.deletedAllocations
      }

      await this.reallocateResourceAction(requestData)
      this.updateLoadingAction()
      this.submitted = true
    }
  }
}
</script>

<style scoped>
.v-text-field__slot >>> .theme--light.v-label--is-disabled {
   color: rgba(0, 0, 0, 0.6);
   font-size: 18px
}
.v-application .headerTable {
    margin-left: 1% !important;
}
.container {
    max-width: 1250px;
}
span.flWtbl {
    width: 100%;
}
.v-chip.v-size--default {
    font-size: smaller;
    height: auto;
}
.v-application .headline {
    font-size: 1rem !important;
    font-weight: 400;
    line-height: 2rem;
    letter-spacing: normal !important;
    font-family: "Open Sans", sans-serif !important;
}
</style>
