<template>
  <div>
    <Dialog />
    <v-card
      class="mx-auto"
      max-width="100%"
    >
      <v-card-text>
        <v-row>
          <v-col cols="12">
            <project-operation :project-details="projectList" :selected-project-name="projectDetail.uuid" :project-action-selected="projectActionSelected"/>
          </v-col>
          <v-col
            cols="12"
            class="pb-0"
          >
            <!-- <v-divider class="pa-2" /> -->
            <h2>Resource Requisition</h2>
          </v-col>
          <v-col
            cols="12"
          >
            <v-data-table
              :headers="headers"
              :items="requisitionItems"
              :hide-default-footer="requisitionItems.length ? false : true"
              class="elevation-1"
            >
              <!-- <template v-slot:top>
                <v-toolbar flat>
                  <v-toolbar-title class="font-weight-normal headerTable">
                    Resource Requisition
                  </v-toolbar-title>
                  <v-spacer />
                </v-toolbar>
              </template> -->
              <template v-slot:item.department="{ item }">
                {{ item.department.name }}
              </template>
              <template v-slot:item.designation="{ item }">
                {{ item.designation.name }}
              </template>
              <template v-slot:item.technology="{ item }">
                {{ item.technology.name }}
              </template>
              <template v-slot:item.start_date="{ item }">
                {{ new Date(item.start_date.substr(0,10)).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }) }}
              </template>
              <template v-slot:item.end_date="{ item }">
                {{ new Date(item.end_date.substr(0,10)).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }) }}
              </template>
              <template v-slot:item.billing_type="{ item }">
                {{ (item.billing_type && item.billing_type === 1) ? 'Billable' : (item.billing_type === 0) ? 'Non-Billable' : '' }}
              </template>
              <template v-slot:item.requested_by="{ item }">
                {{ (item.requested_user) ? item.requested_user.display_name : '' }}
              </template>
              <template v-slot:item.requested_on="{ item }">
                {{ new Date(item.created_at).toLocaleDateString('en-US', {
                  year: 'numeric', month: 'short', day: 'numeric'
                }) }}
              </template>
              <template v-slot:item.suggested_resource="{ item }">
                <span
                  v-for="resource in item.suggested_resource.slice(0,2)"
                  :key="resource.id"
                  class="ma-2"
                  text-color="white"
                >
                  <v-tooltip top>
                    <template v-slot:activator="{ on }">
                      <v-avatar
                        color="blue lighten-1"
                        size="30"
                        v-on="on"
                      >
                        <span class="white--text headline">{{ avatarNames(resource.full_name) }}</span>
                      </v-avatar>
                    </template>
                    {{ resource.full_name }}
                  </v-tooltip>
                </span>
                <v-menu
                  bottom
                  origin="center center"
                  transition="scale-transition"
                >
                  <template v-slot:activator="{ on }">
                    <v-btn
                      v-if="item.suggested_resource.length > 2"
                      outlined
                      fab
                      x-small
                      color="blue"
                      v-on="on"
                      @click="!false"
                    >
                      <v-icon x-small>
                        mdi-plus
                      </v-icon>
                      {{ item.suggested_resource.slice(2,item.suggested_resource.length).length }}
                    </v-btn>
                  </template>
                  <v-card
                    v-show="!false"
                    class="mx-auto"
                    max-width="300"
                    raised
                  >
                    <v-list
                      v-if="item.suggested_resource.length > 2"
                      disabled
                      shaped
                    >
                      <v-list-item-group
                        v-model="item.suggested_resource"
                        color="primary"
                      >
                        <v-list-item
                          v-for="resource in item.suggested_resource.slice(2,item.suggested_resource.length)"
                          v-show="!false"
                          :key="resource.id"
                        >
                          <v-avatar
                            color="blue"
                            size="30"
                          >
                            <strong class="white--text headline">{{ avatarNames(resource.full_name) }}</strong>
                          </v-avatar>
                          <v-list-item-content class="ml-2">
                            <v-list-item-title v-text="resource.full_name" />
                          </v-list-item-content>
                        </v-list-item>
                      </v-list-item-group>
                    </v-list>
                  </v-card>
                </v-menu>
              </template>
            </v-data-table>
          </v-col>
          <v-col
            cols="12"
            class="pb-0"
          >
            <v-data-table
              v-if="extensionFormActive"
              :headers="headersForExtensionRequisitionTable"
              :items="extensionData"
              :hide-default-footer="extensionData.length ? false : true"
              class="elevation-1"
            >
              <template v-slot:top>
                <v-toolbar flat>
                  <v-toolbar-title class="font-weight-normal headerTable">
                    Resource Extension
                  </v-toolbar-title>
                  <v-spacer />
                </v-toolbar>
              </template>
              <template v-slot:item.department="{ item }">
                {{ item.department.name }}
              </template>
              <template v-slot:item.designation="{ item }">
                {{ item.designation.name }}
              </template>
              <template v-slot:item.technology="{ item }">
                {{ item.technology.name }}
              </template>
              <template v-slot:item.start_date="{ item }">
                {{ new Date(item.start_date.substr(0,10)).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }) }}
              </template>
              <template v-slot:item.end_date="{ item }">
                {{ new Date(item.end_date.substr(0,10)).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }) }}
              </template>
              <template v-slot:item.billing_type="{ item }">
                {{ (item.billing_type && item.billing_type === 1) ? 'Billable' : (item.billing_type === 0) ? 'Non-Billable' : '' }}
              </template>
              <template v-slot:item.requested_by="{ item }">
                {{ (item.requested_user) ? item.requested_user.display_name : '' }}
              </template>
              <template v-slot:item.requested_on="{ item }">
                {{ new Date(item.created_at).toLocaleDateString('en-US', {
                  year: 'numeric', month: 'short', day: 'numeric'
                }) }}
              </template>
            </v-data-table>
          </v-col>
          <v-col
            v-show="showAllocation"
            cols="12"
            class="pb-0"
          >
            <h2>Resource Allocation</h2>
          </v-col>
          <v-col
            v-show="showAllocation"
            cols="12"
          >
            <v-data-table
              :headers="headersForAllocationTable"
              :items="allocatedResources"
              :hide-default-footer="allocatedResources.length ? false : true"
              class="elevation-1"
            >
              <template v-slot:item.resource_name="{ item }">
                {{ item.display_name }}
              </template>
              <template v-slot:item.action="{ item }">
                <div v-if="item.allocation_status == ALLOCATION_APPROVAL_REQUESTED">
                  <v-tooltip top>
                    <template v-slot:activator="{ on }">
                      <v-icon class="mdi-24px green--text" dark @click="approve(item.uuid)" v-on="on">
                        mdi-checkbox-marked-circle
                      </v-icon>
                    </template>
                    <span>Approve</span>
                  </v-tooltip>
                  <v-tooltip top>
                    <template v-slot:activator="{ on }">
                      <v-icon class="mdi-24px red--text" dark @click="decline(item.uuid)" v-on="on">
                        mdi-close
                      </v-icon>
                    </template>
                    <span>Decline</span>
                  </v-tooltip>
                </div>
                <div v-else-if="item.allocation_status == RESOURCE_ALLOCATION_RESPONSE_APPROVE || item.allocation_status == RESOURCE_ALLOCATION_RESPONSE_DECLINE">
                  <span> {{ item.allocation_status == RESOURCE_ALLOCATION_RESPONSE_APPROVE ? 'Approved': 'Declined' }}</span>
                </div>
              </template>
            </v-data-table>
          </v-col>
          <v-col cols="12" class="pt-0">
            <v-btn
              class="text-capitalize ma-2 white--text"
              color="blue-grey"
              @click="$router.push('/project-dashboard')"
            >
              <v-icon dark left>
                mdi-arrow-left
              </v-icon>Back
            </v-btn>
          </v-col>
        </v-row>
        <common-snackbar :snackbar="snackbarValue" :text-for-snackbar="snackbarText" />
      </v-card-text>
    </v-card>
  </div>
</template>

<script>
import { mapActions, mapGetters } from 'vuex'
import Dialog from '@/components/Dialog.vue'
import constant from '@/constants/closure-checklist.js'
import CommonSnackbar from '@/components/CommonSnackbar'
import ProjectOperation from '@/components/ProjectOperation'
import { projectHelpers } from '@/helpers/helper.js'

export default {
  name: 'ResourceAllocation',
  layout: 'authenticated',
  middleware: 'authenticated',
  components: {
    Dialog,
    CommonSnackbar,
    ProjectOperation
  },
  async fetch ({ app, store, route }) {
    // eslint-disable-next-line no-useless-catch
    try {
      await Promise.all([
        store.dispatch('project/fetchProjectList'),
        store.dispatch('project/fetchProjectResourceRequisition', route.params.id),
        store.dispatch('project/fetchProjectAllocationResources', route.params.id),
        store.dispatch('project/fetchProjectDetail', route.params.id)
      ])

    } catch (error) {
      throw (error)
    }
  },
  data () {
    return {
      requestedBy: '',
      requestedOn: '',
      projectName: '',
      requisitionItems: [],
      headers: [
        { text: 'Department', sortable: false, value: 'department' },
        { text: 'Technology', value: 'technology' },
        { text: 'Role', sortable: false, value: 'designation' },
        { text: 'No. of Resources', value: 'no_of_resource' },
        { text: 'Daily Efforts (Hours)', value: 'efforts' },
        { text: 'Experience', value: 'experience', sortable: false },
        { text: 'Start Date', value: 'start_date', sortable: false },
        { text: 'End Date', value: 'end_date', sortable: false },
        { text: 'Billing Type', value: 'billing_type', sortable: false },
        { text: 'Suggested Resource', value: 'suggested_resource', sortable: false, width: '15%' },
        { text: 'Requested by', value: 'requested_user', sortable: false },
        { text: 'Requested on', value: 'requested_on', sortable: false }
      ],
      headersForExtensionRequisitionTable: [
        { text: 'Department', value: 'department', sortable: false },
        { text: 'Technology', value: 'technology', sortable: false },
        { text: 'Role', sortable: false, value: 'designation' },
        { text: 'No of Resources', value: 'no_of_resource', sortable: false },
        { text: 'Daily Efforts (Hours)', value: 'efforts', sortable: false },
        { text: 'Experience', value: 'experience', sortable: false },
        { text: 'Start Date', value: 'start_date', sortable: false },
        { text: 'End Date', value: 'end_date', sortable: false },
        { text: 'Billing Type', value: 'billing_type', sortable: false },
        { text: 'Requested by', value: 'requested_by', sortable: false },
        { text: 'Requested on', value: 'requested_on', sortable: false }
      ],
      headersForAllocationTable: [
        { text: 'Resource Name', sortable: false, value: 'resource_name' },
        { text: 'Department', sortable: false, value: 'department' },
        { text: 'Technology', value: 'technology' },
        { text: 'Role', sortable: false, value: 'designation' },
        { text: 'Daily Efforts (Hours)', value: 'efforts', width: '12%' },
        { text: 'Experience', value: 'experience', sortable: false },
        { text: 'Start Date', value: 'start_date', sortable: false },
        { text: 'End Date', value: 'end_date', sortable: false },
        { text: 'Action', value: 'action', sortable: false }
      ],
      requisitionData: [],
      requisitionTableData: [],
      extensionData: [],
      allocationTableData: [],
      showAllocation: true,
      actionSelected: [],
      departmentname: '',
      requisitionArray: [],
      technologyname: '',
      snackbarValue: false,
      snackbarText: '',
      extensionFormActive: false,
      projectActionSelected: 'resource-allocation-manager',
      ...constant.PROJECT_STATUS
    }
  },
  computed: {
    ...mapGetters({
      users: 'project/getUserList',
      projectList: 'project/getProjectList',
      projectDetail: 'project/getProjectDetail',
      projectRequisition: 'project/getProjectRequisition',
      projectAllocatedResources: 'project/getProjectAllocatedResources'
    }),
    allocatedResources () {
      const allocationData = []
      const resourceReqData = this.projectAllocatedResources || []

      for (let i = 0; i < resourceReqData.length; i++) {
        if (resourceReqData[i].status === '0' && this.requisitionArray.includes(resourceReqData[i].uuid)) {
          for (let j = 0; j < resourceReqData[i].resource_allocation.length; j++) {
            for (let k = 0; k < resourceReqData[i].resource_allocation[j].resource_allocation_meta.length; k++) {
              const startDate = new Date(resourceReqData[i].resource_allocation[j].resource_allocation_meta[k].start_date)
                .toLocaleDateString('en-US', {
                  year: 'numeric',
                  month: 'short',
                  day: 'numeric'
                })
              const endDate = new Date(resourceReqData[i].resource_allocation[j].resource_allocation_meta[k].end_date)
                .toLocaleDateString('en-US', {
                  year: 'numeric',
                  month: 'short',
                  day: 'numeric'
                })
              const allocationTuple = {
                allocation_id: resourceReqData[i].resource_allocation[j].uuid,
                uuid: resourceReqData[i].resource_allocation[j].uuid,
                display_name: resourceReqData[i].resource_allocation[j].resource_allocation_meta[k].resource.display_name,
                department: resourceReqData[i].department.name,
                technology: resourceReqData[i].technology.name,
                designation: resourceReqData[i].designation.name,
                efforts: resourceReqData[i].resource_allocation[j].resource_allocation_meta[k].hours,
                experience: resourceReqData[i].resource_allocation[j].experience,
                start_date: startDate,
                end_date: endDate,
                status: resourceReqData[i].resource_allocation[j].status,
                allocation_status: resourceReqData[i].resource_allocation[j].allocation_status,
                deallocate_from: new Date().toISOString().substr(0, 10),
                newDate: false
              }

              allocationData.push(allocationTuple)
            }
          }
        }
      }

      return allocationData
    }
  },
  mounted () {
    this.$nuxt.$emit('headerTitle', 'Resource Allocation Manager')
    this.projectName = this.projectRequisition.project_name
    this.requestedBy = this.projectRequisition.initiated_by.display_name
    this.requestedOn = this.projectRequisition.initiation_date
    this.requisitionData = this.projectRequisition.resource_requisition.filter((item) => {
      return item.status === '0' && item.resource_allocation.some((element) => element.allocation_status === 4)
    })
    this.requisitionData.forEach((item) => {
      if (item.type === 1) {
        this.extensionFormActive = true
        this.extensionData.push(item)
      } else {
        this.requisitionTableData.push(item)
      }
      this.requisitionArray.push(item.uuid)
    })
    this.mutateRequisition(this.requisitionTableData)
  },
  methods: {
    ...mapActions({
      setResourceAllocationApproval: 'project/setResourceAllocationApproval',
      setCustomDialog: 'project/setCustomDialog'
    }),
    avatarNames (fullName) {
      return projectHelpers.avatarNames(fullName)
    },
    mutateRequisition (data) {
      let suggestedResources = []

      this.requisitionItems = []
      if (data) {
        data.forEach((value) => {
          let suggested = []
          const type = Object.prototype.toString.call(value.suggested_resource)

          if (value.suggested_resource && value.suggested_resource !== null && value.suggested_resource !== '' && type !== '[object Number]') {
            if (value.suggested_resource.startsWith('[') && value.suggested_resource.endsWith(']')) {
              suggested = JSON.parse(value.suggested_resource)
            }          }

          const type2 = Object.prototype.toString.call(suggested)

          suggestedResources = []
          if (suggested && suggested !== null && (type2 !== '[object Number]' && type2 !== '[object String]')) {
            suggested.map((id) => {
              this.users.forEach((item) => {
                if (id === item.id && value.type === 0) {
                  suggestedResources.push({
                    full_name: item.full_name,
                    id: item.id
                  })
                }
              })
            })
          }
          this.users.forEach((item) => {
            if (value.extension_resource_id !== null && value.extension_resource_id === item.id && value.type === 1) {
              suggestedResources.push({
                full_name: item.full_name,
                id: item.id
              })
            }
          })
          this.requisitionItems.push({
            uuid: value.uuid,
            technology: value.technology,
            designation: value.designation,
            created_at: value.created_at,
            start_date: value.start_date,
            end_date: value.end_date,
            extension_resource_id: value.extension_resource_id,
            experience: value.experience,
            department: value.department,
            billing_type: value.billing_type,
            efforts: value.efforts,
            no_of_resource: value.no_of_resource,
            requested_user: value.requested_user.display_name,
            type: value.type,
            edit: false,
            resource_allocation: value.resource_allocation,
            isDeleted: value.isDeleted,
            suggested_resource: suggestedResources
          })
        })
      }
    },
    async approve (uuid) {
      const { PROJECT_STATUS } = constant || {}
      const {
        RESOURCE_ALLOCATION_RESPONSE_APPROVE
      } = PROJECT_STATUS || {}
      const requestData = {
        uuid,
        approve_status: RESOURCE_ALLOCATION_RESPONSE_APPROVE,
        send_type: 'approve'
      }

      await this.setResourceAllocationApproval(requestData)
      this.showPopup('Approved')
    },
    async decline (uuid) {
      const { PROJECT_STATUS } = constant || {}
      const {
        RESOURCE_ALLOCATION_RESPONSE_DECLINE
      } = PROJECT_STATUS || {}
      const requestData = {
        uuid,
        approve_status: RESOURCE_ALLOCATION_RESPONSE_DECLINE,
        send_type: 'decline'
      }

      await this.setResourceAllocationApproval(requestData)
      this.showPopup('Declined')
    },
    showPopup (msg) {
      this.snackbarValue = true
      this.snackbarText = `Resource has been ${msg}`
    }
  }
}
</script>

<style scoped>
.v-text-field__slot >>> .theme--light.v-label--is-disabled {
   color: rgba(0, 0, 0, 0.6);
   font-size: 18px
}
.container {
    max-width: 1250px;
}
.v-chip.v-size--default {
    font-size: smaller;
    height: auto;
}
.v-application .headline {
    font-size: 1rem !important;
    font-weight: 400;
    line-height: 2rem;
    letter-spacing: normal !important;
    font-family: "Open Sans", sans-serif !important;
}
</style>
