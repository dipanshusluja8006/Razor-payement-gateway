<template>
  <div id="projectDashboard">
    <div class="text-center">
      <v-dialog v-model="timesheetDialog" width="50%">
        <v-card>
          <card-heading
            :title="tsCardHeading.title"
            :ts-data="tsQuickTable"
            :sub-title="tsCardHeading.subTitle"
            :show-btn="tsCardHeading.showBtn"
            :button-text="tsCardHeading.btnText"
            :btn-access="timesheetReminderAccess"
          />
          <v-card-text>
            <quick-table
              :quick-tables="tsQuickTable"
              :headers="tsHeaders"
              :main-title="'Timesheet Status'"
              :single-expand="true"
              :expand-row="true"
            />
          </v-card-text>
        </v-card>
      </v-dialog>
    </div>
    <div class="text-center">
      <v-dialog v-model="resourceDialog" width="50%">
        <v-card>
          <card-heading
            :title="rsCardHeading.title"
            :sub-title="rsCardHeading.subTitle"
            :show-btn="rsCardHeading.showBtn"
            :button-text="rsCardHeading.btnText"
          />
          <v-divider class="pb-1" />
          <v-card-text>
            <quick-table
              :quick-tables="rsQuickTable"
              :headers="rsHeaders"
              :main-title="'Project Name'"
            />
          </v-card-text>
        </v-card>
      </v-dialog>
    </div>
    <div class="text-center">
      <v-dialog v-model="invoiceDialog" width="50%">
        <v-card>
          <card-heading
            :title="isCardHeading.title"
            :is-data="isQuickTable"
            :sub-title="isCardHeading.subTitle"
            :show-btn="isCardHeading.showBtn"
            :button-text="isCardHeading.btnText"
            :btn-access="invoiceReminderAccess"
          />
          <v-divider class="pb-1" />
          <v-card-text>
            <quick-table
              :quick-tables="isQuickTable"
              :headers="isHeaders"
              :main-title="'Invoice Status'"
            />
          </v-card-text>
        </v-card>
      </v-dialog>
    </div>
    <span
      class="title font-weight-bold text-capitalize black--text text--secondary"
    >
      <div v-show="showTiles">
        <v-row>
          <v-col cols="6" lg="6" xl="12" class="dashboardHeading pb-3">
            <h1>Project Dashboard</h1>
          </v-col>
          <v-col cols="6" lg="6" xl="12" class="selectProjectWrp pb-3 pt-1">
            <v-autocomplete
              v-model="selectedProject"
              :items="projectNameArray"
              :search-input.sync="searchProjectName"
              item-text="name"
              item-value="id"
              label="Project Name"
              multiple
              chips
              clearable
              @click:clear="clearItem(selectedProject)"
              @change="searchProjectName = ''"
              @input="filterTiles(selectedProject)"
            /> </v-col></v-row>
      </div>
    </span>
    <div>
      <v-row class="mb-10">
        <v-col
          v-for="card in cards"
          :key="card.cardNumber"
          :cols="card.flex"
          class="pb-0 projCardWrp"
        >
          <v-card
            exact
            rounded
            :width="card.width"
            :height="card.height"
            @click="onTileClick(card.cardNumber)"
          >
            <div>
              <div v-if="card.cardNumber === 1" class="addProjectCWrp">
                <div class="addProjectTitleWrp">
                  <v-img :src="cardImg" class="img" />
                  <v-card-title
                    class="addProjectTitle"
                  ><h3 v-text="card.title"></h3></v-card-title>
                </div>
                <div class="addProjectDescription">
                  <p>Please click to initiate <br /><b> New Project </b></p>
                  <v-btn class="plushBtn" fab dark x-small>
                    <v-icon dark>
                      mdi-plus
                    </v-icon>
                  </v-btn>
                </div>
              </div>

              <a style="text-decoration: none;" href="#projectDashboardForm">
                <div v-if="card.cardNumber === 2">
                  <div class="cardWrp">
                    <div class="cardLeftcol pdashboardLeft">
                      <v-img :src="cardImgOne" class="img" />
                      <v-card-title><h3 v-text="card.title"></h3></v-card-title>
                    </div>
                    <div class="cardRightcol pdashboardRight">
                      <v-skeleton-loader
                        :loading="loadingPA"
                        :transition="transition"
                        height="180"
                        type="list-item-three-line"
                      >
                        <v-list two-line>
                          <v-list-item
                            v-for="(assist, index) in projectAssisting"
                            :key="index"
                          >
                            <v-icon dark small>{{ assist.icon }}</v-icon>
                            <v-list-item-content>
                              <v-list-item-title
                                v-text="assist.title"
                              ></v-list-item-title>
                              <v-list-item-subtitle
                                v-text="assist.subtitle"
                              ></v-list-item-subtitle>
                            </v-list-item-content>
                          </v-list-item>
                        </v-list>
                      </v-skeleton-loader>
                    </div>
                  </div>
                </div>
              </a>
              <div v-if="card.cardNumber === 3" :style="disabledTile">
                <v-skeleton-loader
                  :loading="loadingTS"
                  :transition="transition"
                  height="200"
                  type="list-item-three-line"
                >
                  <div class="cardWrp">
                    <div class="cardLeftcol pdashboardLeft">
                      <v-img :src="cardImgTwo" class="img" />
                      <v-card-title><h3 v-text="card.title"></h3></v-card-title>
                    </div>
                    <div class="cardRightcol pdashboardRight">
                      <v-list two-line>
                        <v-list-item
                          v-for="(summary, index) in timeSheetSummary"
                          :key="index"
                          class="timeSheetSumL"
                        >
                          <v-list-item-content>
                            <v-list-item-title
                              v-text="summary.title"
                            ></v-list-item-title>
                            <v-list-item-subtitle
                              v-text="summary.statusCount"
                            ></v-list-item-subtitle>
                          </v-list-item-content>
                        </v-list-item>
                      </v-list>
                    </div>
                  </div>
                </v-skeleton-loader>
              </div>
              <div v-if="card.cardNumber === 4">
                <v-skeleton-loader
                  :loading="loadingRS"
                  :transition="transition"
                  height="200"
                  type="list-item-three-line"
                >
                  <div class="resourceSummry">
                    <div class="">
                      <div class="resourceSummryTableWrp">
                        <div class="resourceSummryTableH">
                          <div class="pjctNme">
                            <h4>Project Name</h4>
                          </div>
                          <div class="noResorc">
                            <h4>Number of Resources</h4>
                          </div>
                        </div>
                        <div class="resourceSummryTableData">
                          <ul>
                            <li
                              v-for="(item, index) in resourceSummary"
                              :key="index"
                            >
                              <div class="pName">
                                {{ item.project_name }}
                              </div>
                              <div class="noreorcVal">
                                {{ item.number_of_resource }}
                              </div>
                            </li>
                          </ul>
                        </div>
                      </div>

                      <v-row>
                        <v-col cols="7" class="pt-0 pb-1">
                          <v-card-title
                            class="resourceSummaryH"
                          ><h3 v-text="card.title"></h3></v-card-title>
                        </v-col>
                        <v-col cols="5" class="pt-1 pb-0 pr-4 text-right">
                          <v-btn
                            class="dnlodSummary"
                            @click.stop.prevent="downloadExcel"
                          >Download<v-icon small>mdi-download</v-icon></v-btn>
                        </v-col>
                      </v-row>
                    </div>
                  </div>
                </v-skeleton-loader>
              </div>
              <v-col
                v-if="card.cardNumber === 5"
                :style="disabledTile"
                class="resourceUtilizationWrp"
              >
                <v-row class="pl-2 pr-2">
                  <v-col cols="12" class="pr-0 pt-0 pb-0 pl-2">
                    <sources-card
                      :offset="-10"
                      :series="[40, 50, 120, 100]"
                      :color-array="utilizeColors"
                      :fill-array="utilizeFill"
                      :label-array="utilizeLabels"
                      :legend-position="'right'"
                      :show-labels="false"
                      :show-legend="true"
                      :pie-width="'75%'"
                      percentage-label="lastweek"
                      color="#8c9eff"
                    />
                    <v-card-title
                      class="pt-0 pr-1 pb-0 pl-0"
                    ><h3 v-text="card.title"></h3></v-card-title>
                  </v-col>
                </v-row>
              </v-col>
              <div v-if="card.cardNumber === 6">
                <v-skeleton-loader
                  :loading="loadingIS"
                  :transition="transition"
                  height="200"
                  type="list-item-three-line"
                >
                  <div class="cardWrp">
                    <div class="cardLeftcol pdashboardLeft">
                      <v-img :src="cardImgThree" class="img" />
                      <v-card-title><h3 v-text="card.title"></h3></v-card-title>
                    </div>
                    <div
                      v-if="
                        selectedProject.length > 1 ||
                          selectedProject === 0 ||
                          selectedProject.includes(0)
                      "
                      class="cardRightcol pdashboardRight"
                    >
                      <div class="resourceSummryTableWrp invoiceTable">
                        <div class="resourceSummryTableH">
                          <div class="pjctNme">
                            <h4>Invoice Status</h4>
                          </div>
                          <div class="noResorc">
                            <h4>Number of Projects</h4>
                          </div>
                        </div>
                        <div class="resourceSummryTableData">
                          <ul>
                            <li
                              v-for="(item, index) in invoiceStatus"
                              :key="index"
                            >
                              <div class="pName">
                                {{ item.title }}
                              </div>
                              <div class="noreorcVal">
                                {{ item.invoice_count }}
                              </div>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div v-else>
                      <v-list two-line>
                        <v-list-item
                          v-for="(detail, index) in invoiceDetail"
                          :key="index"
                          class="timeSheetSumL"
                        >
                          <v-list-item-content>
                            <v-list-item-title
                              v-text="detail.title"
                            ></v-list-item-title>
                            <v-list-item-subtitle
                              v-text="detail.subtitle"
                            ></v-list-item-subtitle>
                          </v-list-item-content>
                        </v-list-item>
                      </v-list>
                    </div>
                  </div>
                </v-skeleton-loader>
              </div>
            </div>
          </v-card>
        </v-col>
      </v-row>
    </div>
    <div id="projectDashboardForm" class="projectMainWrp">
      <v-card outlined>
        <project-dashboard
          :project-details="projectDetails"
          :pending-action="pendingAction"
        />
      </v-card>
    </div>
  </div>
</template>
<script>
import { mapActions, mapGetters } from 'vuex'
import constant from '@/constants/closure-checklist.js'
import { excelSheet } from '@/helpers/helper.js'
import SourcesCard from '@/components/dashboard/SourcesCard'
import ProjectDashboard from '@/components/dashboard/ProjectDashboard.vue'
import CardHeading from '@/components/dialogs/CardHeading.vue'
import QuickTable from '../../components/dialogs/QuickTable.vue'

export default {
  name: 'Index',
  components: { SourcesCard, CardHeading, QuickTable, ProjectDashboard },
  layout: 'authenticated',
  middleware: 'authenticated',
  data() {
    return {
      showTiles: true,
      showDashboard: false,
      animation: 'flip-right',
      disabledTile: 'opacity: 0.2; pointer-events:none',
      // utilizeLabels: ['Fully Utilized','Partially Utilized'],
      rolesAllowed: false,
      invoiceDetail: [
        {
          title: 'Invoice Status',
          subtitle: '-'
        },
        {
          title: 'Next Generation Date',
          subtitle: 'DD/MM/YY'
        }
      ],
      selectedProject: '',
      projectNameArray: [],
      searchProjectName: '',
      cards: [
        { title: 'Add Project', flex: 4, cardNumber: 1 },
        { title: 'Project Assisting', flex: 4, cardNumber: 2 },
        { title: 'Timesheet Summary', flex: 4, cardNumber: 3 },
        { title: 'Resource Summary', flex: 4, cardNumber: 4 },
        { title: 'Resource Utilization', flex: 4, cardNumber: 5 },
        { title: 'Invoice Status', flex: 4, cardNumber: 6 }
      ],
      resourceHeader: [
        { text: 'Project Name', value: 'name' },
        { text: 'Total Resources', value: 'calories' }
      ],
      resourceSummary: [],
      utilizeLabels: [
        'Optimally-Utilized',
        'Over-Utilized',
        'Under-Utilized',
        'Bench'
      ],
      utilizeColors: ['#3fa107', '#FEAD4F', '#77CFD5', '#F6C301', '#ec6666'],
      utilizeFill: {
        colors: ['#3fa107', '#FEAD4F', '#77CFD5', '#F6C301', '#ec6666']
      },
      projectAssisting: [],
      timeSheetSummary: [],
      invoiceStatus: [],
      timesheetDialog: false,
      resourceDialog: false,
      invoiceDialog: false,
      selectedItem: null,
      projectDetails: [],
      pendingAction: [],
      redmineProjectIds: [],
      tsCardHeading: {
        showBtn: true,
        title: 'Timesheet Details',
        subTitle:
          'Please click the button to remind the resources to fill their Time Sheets.',
        btnText: 'Send Reminder'
      },
      rsCardHeading: {
        showBtn: false,
        title: 'Resource Summary',
        subTitle: '',
        btnText: ''
      },
      isCardHeading: {
        showBtn: true,
        title: 'Invoice Status Details',
        subTitle:
          'Please click the button to remind the AMs/PMs to generate invoices for their projects.',
        btnText: 'Send Reminder'
      },
      tsHeaders: [
        { text: 'Resource Name', value: 'EmployeeName' },
        { text: 'Emp ID', value: 'EmployeeCode' },
        { text: 'Hours', value: 'Hours' },
        { text: 'Spent Date', value: 'SpentDate' }
      ],
      rsHeaders: [
        { text: 'Resource Name', value: 'resourceName' },
        { text: 'Department Name', value: 'department' },
        { text: 'Alloted Time Period', value: 'allotedDate' },
        { text: 'Time Duration', value: 'hours' }
      ],
      isHeaders: [
        { text: 'project Name', value: 'ProjectName' },
        { text: 'Billing Type', value: 'BillingType' },
        { text: 'Invoice Status', value: 'InvoiceStatus' },
        { text: 'Last Invoice Date', value: 'LastInvoiceDate' },
        { text: 'Next Invoice Date', value: 'NextInvoiceDate' }
      ],
      tsQuickTable: [],
      rsQuickTable: [],
      isQuickTable: [],
      filterProject: [],
      invoiceReminderAccess: false,
      timesheetReminderAccess: false,
      invoiceSummaryData: [],
      projectListData: [],
      timesheetSummaryData: [],
      resourceSummaryData: [],
      loadingIS: true,
      loadingTS: false,
      loadingRS: true,
      loadingPA: true,
      transition: 'scale-transition'
    }
  },
  computed: {
    ...mapGetters({
      projectList: 'project/getProjectList',
      getGlobalRole: 'roles/getGlobalRole',
      getGlobalTeamRole: 'roles/getGlobalTeamRole',
      currentUser: 'auth/user',
      availableRoles: 'roles/availableRoles',
      getTimesheetSummary: 'dashboard/getTimesheetSummary',
      getResourceSummary: 'dashboard/getResourceSummary',
      getInvoiceSummary: 'dashboard/getInvoiceSummary',
      utilizationOverView: 'dashboard/utilizationOverView'
    }),
    cardImg() {
      return require('@/assets/images/dashboard/new-project.png')
    },
    cardImgOne() {
      return require('@/assets/images/dashboard/project-assisting.png')
    },
    cardImgTwo() {
      return require('@/assets/images/dashboard/timesheet-summary.png')
    },
    cardImgThree() {
      return require('@/assets/images/dashboard/invoice-status.png')
    }
  },
  watch: {
    getInvoiceSummary() {
      this.invoiceSummaryData = this.getInvoiceSummary

      const { data: datainvoice } = this.invoiceSummaryData

      this.mutateInvoiceStatus(datainvoice)
    },
    getResourceSummary() {
      this.resourceSummaryData = this.getResourceSummary

      const { data } = this.resourceSummaryData

      this.mutateResourceSummary(data)
    },
    // getTimesheetSummary () {
    //   this.timesheetSummaryData = this.getTimesheetSummary

    //   const { data: datatimesheet } = this.timesheetSummaryData

    //   this.mutateTimesheetSummary(datatimesheet)
    // },
    projectList() {
      this.projectListData = this.projectList
      this.mutateProjectList(this.projectListData)
    }
  },
  mounted() {
    this.fetchLists()
    this.tileAccess()
    /**
     * Loop Through Project List Data
     * @param details
     */
    this.projectListData = this.projectList
    this.mutateProjectList(this.projectListData)

    // const { data: datatimesheet } = this.getTimesheetSummary

    // this.mutateTimesheetSummary(datatimesheet)

    const { data } = this.getResourceSummary

    this.mutateResourceSummary(data)
    this.invoiceSummaryData = this.getInvoiceSummary
    const { data: datainvoice } = this.invoiceSummaryData

    this.mutateInvoiceStatus(datainvoice)
  },
  methods: {
    ...mapActions({
      fetchProjectList: 'project/fetchProjectList',
      fetchAllRoles: 'roles/fetchAllRoles',
      setTimesheetSummary: 'dashboard/setTimesheetSummary',
      fetchTimesheetSummary: 'dashboard/fetchTimesheetSummary',
      setResourceSummary: 'dashboard/setResourceSummary',
      fetchResourceSummary: 'dashboard/fetchResourceSummary',
      setInvoiceSummary: 'dashboard/setInvoiceSummary',
      fetchInvoiceSummary: 'dashboard/fetchInvoiceSummary',
      fetchTechnologies: 'project/fetchTechnologies',
      fetchProjectType: 'project/fetchProjectType',
      fetchGovernanceCategories: 'project/fetchGovernanceCategories',
      fetchUserList: 'project/fetchUserList',
      fetchDepartments: 'project/fetchDepartments',
      fetchProjectNames: 'project/fetchProjectNames',
      fetchBillingTypes: 'project/fetchBillingTypes'
    }),

    tileAccess() {
      /**
       * Role based display of tiles
       */
      let apTileAccess = false
      let paTileAccess = false
      let tsTileAccess = false
      let ruTileAccess = false
      let rsTileAccess = false
      let isTileAccess = false

      if (this.getGlobalRole.length) {
        this.getGlobalRole.map((role) => {
          if (
            role.role_id === constant.ROLE_ID.ADMIN ||
            this.getGlobalTeamRole === true ||
            role.role_id === constant.ROLE_ID.GLOBAL_OPERATION ||
            role.role_id === constant.ROLE_ID.SALES ||
            role.role_id === constant.ROLE_ID.BU_HEAD
          ) {
            apTileAccess = true
          }
          if (
            role.role_id === constant.ROLE_ID.ADMIN ||
            role.role_id === constant.ROLE_ID.GLOBAL_OPERATION ||
            role.role_id === constant.ROLE_ID.SALES ||
            role.role_id === constant.ROLE_ID.RESOURCE_MANAGER ||
            role.role_id === constant.ROLE_ID.PROJECT_MANAGER ||
            role.role_id === constant.ROLE_ID.ACCOUNT_MANAGER ||
            role.role_id === constant.ROLE_ID.BU_HEAD
          ) {
            paTileAccess = true
          }
          if (
            role.role_id === constant.ROLE_ID.ADMIN ||
            role.role_id === constant.ROLE_ID.GLOBAL_OPERATION ||
            role.role_id === constant.ROLE_ID.SALES ||
            role.role_id === constant.ROLE_ID.RESOURCE_MANAGER ||
            role.role_id === constant.ROLE_ID.PROJECT_MANAGER ||
            role.role_id === constant.ROLE_ID.BU_HEAD ||
            role.role_id === constant.ROLE_ID.ACCOUNT_MANAGER
          ) {
            tsTileAccess = true
            ruTileAccess = true
            isTileAccess = true
          }
          if (
            role.role_id === constant.ROLE_ID.ADMIN ||
            role.role_id === constant.ROLE_ID.GLOBAL_OPERATION ||
            role.role_id === constant.ROLE_ID.PROJECT_MANAGER ||
            role.role_id === constant.ROLE_ID.ACCOUNT_MANAGER ||
            role.role_id === constant.ROLE_ID.SALES ||
            role.role_id === constant.ROLE_ID.RESOURCE_MANAGER
          ) {
            rsTileAccess = true
          }
          if (
            role.role_id === constant.ROLE_ID.ADMIN ||
            role.role_id === constant.ROLE_ID.ACCOUNT_MANAGER ||
            role.role_id === constant.ROLE_ID.RESOURCE_MANAGER ||
            role.role_id === constant.ROLE_ID.GLOBAL_OPERATION
          ) {
            this.invoiceReminderAccess = true
          }
          if (
            role.role_id === constant.ROLE_ID.ADMIN ||
            role.role_id === constant.ROLE_ID.ACCOUNT_MANAGER ||
            role.role_id === constant.ROLE_ID.RESOURCE_MANAGER ||
            role.role_id === constant.ROLE_ID.PROJECT_MANAGER
          ) {
            this.timesheetReminderAccess = true
          }
        })

        if (apTileAccess === false) {
          this.cards = this.cards.filter((item) => item.cardNumber !== 1)
        }
        if (paTileAccess === false) {
          this.cards = this.cards.filter((item) => item.cardNumber !== 2)
        }
        if (tsTileAccess === false) {
          this.cards = this.cards.filter((item) => item.cardNumber !== 3)
        }
        if (rsTileAccess === false) {
          this.cards = this.cards.filter((item) => item.cardNumber !== 4)
        }
        if (ruTileAccess === false) {
          this.cards = this.cards.filter((item) => item.cardNumber !== 5)
        }
        if (isTileAccess === false) {
          this.cards = this.cards.filter((item) => item.cardNumber !== 6)
        }
        if (this.cards.length === 1) {
          this.cards[0].width = '1055px'
        }
      }
    },
    fetchLists() {
      Promise.all([
        this.fetchProjectList(),
        this.fetchInvoiceSummary(),
        this.fetchTimesheetSummary(),
        this.fetchResourceSummary()
      ])
    },
    /**
     * Project List data mutation
     * @param data
     */
    mutateProjectList(data) {
      this.projectDetails = []
      if (data) {
        data.map((details) => {
          if (details.redmine_project_id !== null) {
            this.redmineProjectIds.push(details.redmine_project_id)
          }
          this.pendingAction[details.uuid] = details.pending_action
            ? details.pending_action
            : {}
          this.projectDetails.push({
            account_managers: details.account_managers,
            approved_hours: details.approved_hours,
            billing_type: details.billing_type,
            client_detail: details.client_detail,
            company_address: details.company_address,
            company_name: details.company_name,
            created_at: details.created_at,
            created_by: details.created_by,
            deleted_at: details.deleted_at,
            estimated_timeline_from: details.estimated_timeline_from,
            estimated_timeline_to: details.estimated_timeline_to,
            id: details.id,
            initiated_by: details.initiated_by,
            initiation_date: details.initiation_date,
            maximum_hours_billed: details.maximum_hours_billed,
            performed_action: details.performed_action
              ? details.performed_action
              : [],
            project_components: details.project_components,
            project_closure_details: details.project_closure_details,
            project_documents_link: details.project_documents_link,
            project_domains: details.project_domains,
            project_managers: details.project_managers,
            project_name: details.project_name,
            project_summary: details.project_summary,
            resource_requisition: details.resource_requisition,
            specific_requests: details.specific_requests,
            status: details.status,
            is_draft: details.is_draft,
            technologies: details.technologies,
            updated_at: details.updated_at,
            updated_by: details.updated_by,
            user_actions: details.user_actions ? details.user_actions : [],
            user_performed_action: details.user_performed_action
              ? details.user_performed_action
              : [],
            user_role: details.user_role,
            uuid: details.uuid,
            openProjectManagerList: this.openProjectManagerList,
            openAccountManagerList: this.openAccountManagerList,
            action_pending:
              details.is_draft === 0 ? details.action_pending : false,
            roleUpdated: false,
            identifier: details.identifier,
            lifecycle_model:
              details.lifecycle_model && details.lifecycle_model !== null
                ? details.lifecycle_model.name
                : '',
            project_type:
              details.project_type && details.project_type !== null
                ? details.project_type.name
                : '',
            governance_category:
              details.governance_category &&
              details.governance_category !== null
                ? details.governance_category.name
                : '',
            project_role: details.project_role,
            sub_project_name:
              details.sub_project_name && details.sub_project_name !== null
                ? details.sub_project_name.name
                : '',
            billing_interval: details.billing_interval,
            state: details.state,
            country: details.country,
            track: details.track,
            redmine_project_id: details.redmine_project_id,
            wsr_status: this.mutateWsrStatusData(details)
          })
        })

        this.filterProject = []
        this.filterProject = this.projectDetails
        // get project name list for global filter
        this.filterProject.forEach((value) => {
          if (value.redmine_project_id !== null) {
            this.projectNameArray.push({
              id: value.redmine_project_id,
              name: value.project_name
            })
          }
        })
        this.projectNameArray.unshift({
          id: 0,
          name: 'All Project'
        })
        this.selectedProject = this.projectNameArray[0].id
        this.mutateProjectAssist(this.filterProject)
      }
    },
    /**
     * Project Assist data mutation
     * @param projectRecord
     */

    mutateWsrStatusData(value) {
      if (value.wsr_status !== null) {
        if (value.wsr_status === 1) {
          return { id: 1, name:'Submitted' }
        } else {
          return { id: 0, name:'Pending' }
        }
      } else {
        return {}
      }
    },

    mutateProjectAssist(projectRecord) {
      this.projectAssisting = []
      /**
       * Project Assisting Tile records
       * * @param item
       */
      let colosedCount = 0
      let holdCount = 0
      let onGoingCount = 0
      let newCount = 0

      projectRecord.forEach((item) => {
        if (item.track.status === constant.PROJECT_STATUS.CLOSED) {
          colosedCount = colosedCount + 1
        } else if (item.track.status === constant.PROJECT_STATUS.ON_HOLD) {
          holdCount = holdCount + 1
        } else if (
          item.track.status === constant.PROJECT_STATUS.NEW ||
          item.track.is_draft === 1 ||
          ((item.track.is_approve === 0 || item.track.is_approve === 1) &&
            item.track.status === constant.PROJECT_STATUS.INITIATION_REQUEST)
        ) {
          newCount = newCount + 1
        } else {
          onGoingCount = onGoingCount + 1
        }
      })
      this.projectAssisting.push(
        {
          subtitle: 'New/Draft Projects',
          title: newCount,
          icon: 'mdi-file'
        },
        {
          subtitle: 'Ongoing Projects',
          title: onGoingCount,
          icon: 'mdi-file-check'
        },
        {
          subtitle: 'On Hold Projects',
          title: holdCount,
          icon: 'mdi-file-hidden'
        },
        {
          subtitle: 'Closed Projects',
          title: colosedCount,
          icon: 'mdi-file-excel-box'
        }
      )
      if (
        newCount > 0 ||
        onGoingCount > 0 ||
        holdCount > 0 ||
        colosedCount > 0
      ) {
        this.loadingPA = false
      }
    },
    formatDate(date) {
      const d = new Date(date)
      let month = '' + (d.getMonth() + 1)
      let day = '' + d.getDate()
      const year = d.getFullYear()

      if (month.length < 2) month = '0' + month
      if (day.length < 2) day = '0' + day

      return [day, month, year].join('/')
    },
    /**
     * Timesheet Summary data mutation
     * @param data
     */
    mutateTimesheetSummary(data) {
      let count = 1
      let countRecord = 1

      if (data) {
        this.loadingTS = false
        this.tsQuickTable = []
        this.timeSheetSummary = []

        Object.entries(data).forEach(([keys, values]) => {
          count = Number(count) + 1
          this.timeSheetSummary.push({
            title: keys,
            statusCount: values.statusCount
          })
          if (values.resource) {
            const tsItems = []
            let disable = false

            values.resource.forEach((item) => {
              countRecord = Number(countRecord) + 1
              tsItems.push({
                EmployeeName: item.EmployeeName,
                EmployeeCode: item.EmployeeCode,
                ProjectName: item.ProjectName,
                Hours: item.Hours,
                SpentDate: item.SpentDate,
                id: countRecord,
                projectInfo: item.projectInfo,
                UsersId: item.UsersId
              })
            })
            if (tsItems.length <= 2) {
              disable = true
            }
            let color = ''

            if (keys === 'Pending') {
              color = 'yellow--text'
            } else {
              color = 'blue--text'
            }
            this.tsQuickTable.push({
              id: count,
              titleColor: color,
              status: keys,
              showCollapse: false,
              showExpand: true,
              isDisabled: disable,
              items: tsItems,
              code: 'ts'
            })
          }
        })

        return this.tsQuickTable
      }
    },
    /**
     * Resource Summary data mutation
     * @param data
     */
    mutateResourceSummary(data) {
      let count = 1
      let countRecord = 1

      if (data) {
        this.loadingRS = false
        this.rsQuickTable = []
        this.resourceSummary = []

        Object.entries(data).forEach(([keys, values]) => {
          count = Number(count) + 1
          this.resourceSummary.push({
            project_name: keys,
            number_of_resource: values.resourceCount
          })
          if (values.resource) {
            const rsItems = []
            let disable = false

            values.resource.forEach((item) => {
              const startDate = this.formatDate(item.startDate)
              const endDate = this.formatDate(item.endDate)
              const allotedDate = startDate + '-' + endDate

              countRecord = Number(countRecord) + 1
              rsItems.push({
                resourceName: item.ResourceName,
                department: item.department,
                allotedDate: allotedDate,
                hours: item.Hour,
                id: countRecord
              })
            })
            if (rsItems.length <= 2) {
              disable = true
            }
            this.rsQuickTable.push({
              id: count,
              titleColor: 'blue--text',
              status: keys,
              showCollapse: false,
              showExpand: true,
              isDisabled: disable,
              items: rsItems,
              code: 'rs'
            })
          }
        })

        return this.rsQuickTable
      }
    },
    /**
     * Invoice Status Summary data mutation
     * @param data
     */
    mutateInvoiceStatus(data) {
      let countIs = 1
      let countRecord = 1

      this.isQuickTable = []
      this.invoiceStatus = []
      if (data) {
        this.loadingIS = false
        Object.entries(data).forEach(([key, values]) => {
          countIs = Number(countIs) + 1
          this.invoiceStatus.push({
            title: key,
            invoice_count: values.statusCount,
            redmineProjectId: values.ProjectID
          })
          if (values.resource && values.resource.length >= 1) {
            const isItems = []
            let disable = false

            values.resource.forEach((item) => {
              const nextInvoiceDate = this.formatDate(item.NextInvoiceDate)
              const lastInvoiceDate = this.formatDate(item.LastInvoiceDate)

              countRecord = Number(countRecord) + 1
              isItems.push({
                ProjectName: item.ProjectName,
                BillingType: item.BillingType,
                InvoiceStatus: item.InvoiceStatus,
                LastInvoiceDate: lastInvoiceDate,
                NextInvoiceDate: nextInvoiceDate,
                ProjectID: item.ProjectID,
                id: countRecord
              })
            })
            if (isItems.length <= 2) {
              disable = true
            }
            this.isQuickTable.push({
              id: countIs,
              titleColor: 'blue--text',
              status: key,
              showCollapse: false,
              showExpand: true,
              isDisabled: disable,
              items: isItems,
              code: 'is'
            })
          }
        })

        return this.isQuickTable
      }
    },
    /**
     * Global Filter Method
     * @param projectIds
     */
    filterTiles(projectIds) {
      this.invoiceDetail = [
        {
          title: 'Invoice Status',
          subtitle: '-'
        },
        {
          title: 'Next Generation Date',
          subtitle: 'DD/MM/YY'
        }
      ]
      if (projectIds.length > 0 && !projectIds.includes(0)) {
        // filter timesheet summary tile
        // const tsArray = []
        // const { data: datatimesheet } = this.timesheetSummaryData

        // Object.entries(datatimesheet).forEach(([key, values]) =>  {
        //   if (values.resource) {
        //     const timesheet = values.resource.filter((item) => projectIds.includes(item.projectsID))
        //     const updatedValue = {}

        //     updatedValue['resource'] = timesheet
        //     updatedValue['statusCount'] = timesheet.length
        //     tsArray.push({ key: key, value: updatedValue })

        //   } else {
        //     tsArray.push({ key: key, value: values })
        //   }
        // })

        // const tsObject = this.convertToObject(tsArray)

        // this.mutateTimesheetSummary(tsObject)

        // filter resource summary tile
        const rsArray = []

        if (
          this.resourceSummaryData !== null ||
          this.resourceSummaryData !== undefined
        ) {
          const { data } = this.resourceSummaryData

          Object.entries(data).forEach(([key, values]) => {
            if (projectIds.includes(values.ProjectRedmineId)) {
              rsArray.push({ key: key, value: values })
            }
          })
          const rsObject = this.convertToObject(rsArray)

          this.mutateResourceSummary(rsObject)
        }

        // filter invoice status tile
        const isArray = []

        if (
          this.invoiceSummaryData !== null ||
          this.invoiceSummaryData !== undefined
        ) {
          const { data: invoiceData } = this.invoiceSummaryData

          Object.entries(invoiceData).forEach(([key, values]) => {
            if (values.resource) {
              const invoices = values.resource.filter((item) =>
                projectIds.includes(item.ProjectID)
              )
              const updatedValue = {}

              if (invoices.length > 0) {
                this.singleInvoiceStatus(invoices)
              }
              updatedValue['resource'] = invoices
              updatedValue['statusCount'] = invoices.length
              isArray.push({ key: key, value: updatedValue })
            } else {
              isArray.push({ key: key, value: values })
            }
          })
          const isObject = this.convertToObject(isArray)

          this.mutateInvoiceStatus(isObject)
        }

        // filter project list table and grid view
        const projectData = []

        this.filterProject.forEach((element) => {
          if (
            element.redmine_project_id !== null &&
            projectIds.includes(element.redmine_project_id)
          ) {
            projectData.push(element)
          }
        })
        this.projectDetails = projectData
      } else {
        this.selectedProject = this.projectNameArray[0].id
        if (
          this.resourceSummaryData !== null ||
          this.resourceSummaryData !== undefined
        ) {
          const { data } = this.resourceSummaryData

          this.mutateResourceSummary(data)
        }
        // const { data:  datatimesheet } = this.timesheetSummaryData

        // this.mutateTimesheetSummary(datatimesheet)
        if (
          this.invoiceSummaryData !== null ||
          this.invoiceSummaryData !== undefined
        ) {
          const { data: datainvoice } = this.invoiceSummaryData

          this.mutateInvoiceStatus(datainvoice)
        }

        this.projectDetails = this.filterProject
      }
    },
    singleInvoiceStatus(invoices) {
      invoices.forEach((element) => {
        if (
          (this.selectedProject.length <= 1 &&
            this.selectedProject.includes(element.ProjectID) &&
            this.selectedProject !== 0) ||
          (this.projectNameArray.length <= 1 && this.selectedProject === 0)
        ) {
          const singelInvoice = []

          singelInvoice.push(
            {
              title: 'Invoice Status',
              subtitle: element.InvoiceStatus
            },
            {
              title: 'Next Generation Date',
              subtitle: this.formatDate(element.NextInvoiceDate)
            }
          )
          this.invoiceDetail = singelInvoice
        }
      })

      return this.invoiceDetail
    },
    /**
     * Convert array to an object
     * @param array
     */
    convertToObject(array) {
      return array.reduce(
        (obj, item) => Object.assign(obj, { [item.key]: item.value }),
        {}
      )
    },
    /**
     * Perform action on tile click
     * @param cardNumber
     */
    onTileClick(cardNumber) {
      if (cardNumber === 3) {
        // this.timesheetDialog = true
        this.disabledTile = 'opacity: 0.2; pointer-events:none'
      } else if (cardNumber === 4) {
        this.resourceDialog = true
      } else if (cardNumber === 5) {
        this.disabledTile = 'opacity: 0.2; pointer-events:none'
      } else if (cardNumber === 6) {
        this.invoiceDialog = true
      } else if (cardNumber === 1) {
        this.$router.push('/project-initiation')
      }
    },
    clearItem(Id) {
      if (Id === 0) {
        this.selectedProject = this.projectNameArray[0].id
      }
    },
    /**
     * Download resource summary data in excel format
     */
    async downloadExcel() {
      const excelData = []

      this.rsQuickTable.forEach((value) => {
        value.items.forEach((item) => {
          excelData.push({
            project_name: value.status,
            resource_name: item.resourceName,
            department_name: item.department,
            alloted_time_period: item.allotedDate,
            time_duration: item.hours
          })
        })
      })
      const header = [
        'project_name',
        'resource_name',
        'department_name',
        'alloted_time_period',
        'time_duration'
      ]
      const excelParams = {
        sheetData: [excelData],
        headers: [header],
        sheetName: ['Resource Summary'],
        fileName: 'resource-summary.xls'
      }

      excelSheet.createExcelSheet(excelParams)
    }
  }
}
</script>
<style scoped>
.v-data-table td,
.v-data-table th {
  padding: 0 20px !important;
  font-size: 14px;
}
.v-btn.v-size--x-small {
  font-size: smaller;
}
.v-btn.v-size--default {
  font-size: small;
}
.v-chip.v-size--default {
  font-size: smaller;
  height: auto;
}
.v-chip {
  line-height: normal !important;
}
.v-data-table-header {
  box-shadow: 0px 3px 1px -2px rgba(0, 0, 0, 0.2),
    0px 2px 2px 0px rgba(0, 0, 0, 0.14), 0px 1px 5px 0px rgba(0, 0, 0, 0.12);
  color: white;
  border-radius: inherit;
}
.v-application {
  font-family: "Roboto", sans-serif;
  line-height: normal;
}
.v-label {
  font-size: 14px;
}
.v-application .noData {
  font-size: 14px;
}
.img {
  background-position: inherit;
  height: 150;
  width: 150;
}
.v-card__title {
  font-size: 0.95rem;
  font-weight: bolder;
  letter-spacing: 0.0125em;
  line-height: 2rem;
  font-family: "Product Sans";
  color: #526e7c;
}
.v-list--two-line .v-list-item,
.v-list-item--two-line {
  min-height: 40px;
}
.v-list-item__title {
  align-self: center;
  font-size: 0.6rem;
}
.v-list-item__subtitle {
  font-size: 0.75rem;
}
.scroll-box {
  overflow-y: auto;
  height: 165px;
  overflow-x: hidden;
  margin-left: 8px;
  margin-right: 8px;
}
.v-data-table > .v-data-table__wrapper > table > tbody > tr > td,
.v-data-table > .v-data-table__wrapper > table > thead > tr > td,
.v-data-table > .v-data-table__wrapper > table > tfoot > tr > td {
  font-size: smaller;
  height: 30px;
}
.v-data-table > .v-data-table__wrapper > table > tbody > tr > th,
.v-data-table > .v-data-table__wrapper > table > thead > tr > th,
.v-data-table > .v-data-table__wrapper > table > tfoot > tr > th {
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
  font-size: smaller;
  height: 30px;
}
/* .dialog-text {
  font-size: x-small;
  font-weight: 100 !important;
  color: grey
} */

/* Heading DropDown */

.selectProjectWrp .v-input {
  display: inline-block;
  width: 400px;
  margin-top: 0;
  padding-top: 0;
}

.selectProjectWrp label.v-label.v-label--active.theme--light {
  top: 0px;
  font-size: 16px;
}

.selectProjectWrp input#input-812 {
  color: #1976d2;
  font-size: 18px;
  font-weight: 600;
  text-align: left;
  font-style: normal;
  letter-spacing: normal;
  line-height: normal;
}

/* 08-02-2021 */
.addProjectCWrp {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.addProjectTitleWrp {
  padding: 20px 20px;
  width: 60%;
  border-right: 1px solid #f0f0f0;
  text-align: center;
}

.addProjectDescription {
  width: 40%;
  padding: 15px;
  text-align: center;
}

.addProjectDescription p {
  /* Style for "Please cli" */
  color: #526e7c;
  font-size: 23px;
  text-align: center;
  /* Text style for "Please cli" */
  font-weight: 400;

  /* Text style for "New Projec" */
  font-style: normal;
  letter-spacing: normal;
  line-height: normal;
}

.v-card__title.addProjectTitle {
  padding: 40px 0 0px;
  text-align: center;
  line-height: normal;
}

.addProjectTitle h3 {
  display: block;
  width: 100%;
  color: #526e7c;
  font-size: 24px;
  font-weight: 700;
  font-style: normal;
  letter-spacing: normal;
  line-height: normal;
  font-family: "ProductSans";
}

button.plushBtn {
  /* Style for "Ellipse 80" */
  width: 36px;
  height: 36px;
  box-shadow: 0 3px 6px rgba(25, 118, 210, 0.2);
  border: 3px solid #1976d2;
  background-color: #1976d2 !important;
  border-radius: 100%;
  text-align: center;
  color: #fff;
}

button.plushBtn span.v-btn__content {
  opacity: 1;
  text-align: center;
  display: block;
}

button.plushBtn span.v-btn__content i {
  color: #fff;
  text-align: center;
}
.addProjectCWrp {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.addProjectTitleWrp {
  padding: 20px 20px;
  width: 60%;
  border-right: 1px solid #f0f0f0;
  text-align: center;
}

.addProjectDescription {
  width: 40%;
  padding: 15px;
  text-align: center;
}

.addProjectDescription p {
  /* Style for "Please cli" */
  color: #526e7c;
  font-size: 23px;
  text-align: center;
  /* Text style for "Please cli" */
  font-weight: 400;

  /* Text style for "New Projec" */
  font-style: normal;
  letter-spacing: normal;
  line-height: normal;
}

.v-card__title.addProjectTitle {
  padding: 30px 0 10px;
  text-align: center;
  line-height: normal;
}

.addProjectTitle h3 {
  display: block;
  width: 100%;
  /* Style for "Add Projec" */
  color: #526e7c;
  font-size: 26px;
  font-weight: 700;

  /* Text style for "Add Projec" */
  font-style: normal;
  letter-spacing: normal;
  line-height: normal;
}

button.plushBtn {
  /* Style for "Ellipse 80" */
  width: 36px;
  height: 36px;
  box-shadow: 0 3px 6px rgba(25, 118, 210, 0.2);
  border: 3px solid #1976d2;
  background-color: #1976d2;
  border-radius: 100%;
  text-align: center;
  color: #fff;
}

button.plushBtn span.v-btn__content {
  opacity: 1;
  text-align: center;
  display: block;
}

button.plushBtn span.v-btn__content i {
  color: #fff;
  text-align: center;
}

>>> .theme--light.v-skeleton-loader .v-skeleton-loader__bone::after {
  background: linear-gradient(
    90deg,
    rgba(255, 255, 255, 0),
    rgba(255, 255, 255, 0.3),
    #add8e6
  );
}
</style>
