<template>
  <div class="projectDashboardWrp">
    <div class="projectDashboradrH">
      <v-row>
        <v-col cols="6" class="pb-0">
          <div class="heading-style"><h3>WSR</h3></div>
        </v-col>
        <v-col cols="6" class="text-right pb-0">
          <div class="submitDiv" cols="12">
            <v-btn class="backBtn" @click="$router.push('/dashboard')">
              <v-icon dark left>mdi-arrow-left</v-icon> Back
            </v-btn>
            <v-btn class="submitBtn" @click="$router.push('/wsr/add-wsr')">
              ADD WSR
            </v-btn>
          </div>
        </v-col>
      </v-row>
    </div>
    <v-row class="wsrTableListWrp">
      <v-col cols="12" class="pt-6">
        <v-data-table
          :headers="headers"
          :items="getWsrListArray"
          :hide-default-footer="getWsrListArray.length ? false : true"
          class="wsrTableList"
        >
          <template v-slot:top>
            <div class="wsrTableFilter">
              <v-row>
                <v-col cols="2" class="pt-0 pb-0 pr-0"></v-col>

                <v-col cols="2" class="pt-0 pb-0 pl-1">
                  <v-autocomplete
                    v-show="rolesAllowed"
                    v-model="assignToIds"
                    :items="assignedUsers"
                    item-text="name"
                    item-value="id"
                    class="filtersFields"
                    label="AM/PM filter"
                    outlined
                    small-chips
                    dense
                    multiple
                    :search-input.sync="assignToIdsType"
                    @click:clear="clearItem(assignToIds)"
                    @change="assignToIdsType = ''"
                    @input="commonFilter"
                  >
                    <template v-slot:selection="{ attrs, item, parent, selected, index }" class="slectedChilpSRWrp">
                      <v-tooltip top>
                        <template v-slot:activator="{ on }">
                          <v-chip
                            v-if="item === Object(item) && index === 0"
                            v-bind="attrs"
                            :input-value="selected"
                            label
                            small
                            v-on="on"
                          >
                            <span class="slectedChilpSR">
                              {{ item.name.length >= 47? item.name.slice(0,47) + '...': item.name }}
                            </span>
                            <v-icon
                              small
                              @click="parent.selectItem(item)"
                            >
                              mdi-close
                            </v-icon>
                          </v-chip>
                          <v-menu
                            bottom
                            origin="center center"
                            transition="scale-transition"
                          >
                            <template v-slot:activator="{ on }">
                              <v-btn
                                v-if="index === 1"
                                class="wsrMoreChilp"
                                outlined
                                rounded
                                fab
                                small
                                height="25"
                                width="25"
                                color="blue"
                                v-on="on"
                                @click="!false"
                              >
                                <v-icon x-small style="height: 10px; width: 10px">
                                  mdi-plus
                                </v-icon>
                                {{ assignToIds.length - 1 }}
                              </v-btn>
                            </template>
                            <v-card
                              v-show="!false"
                              class="mx-auto"
                              max-width="300"
                              raised
                            >
                              <v-list
                                v-if="selectedAssignId.length > 1"
                                disabled
                                shaped
                              >
                                <v-list-item-group
                                  v-model="selectedAssignId"
                                >
                                  <v-list-item
                                    v-for="project in selectedAssignId.slice(1,selectedAssignId.length)"
                                    v-show="!false"
                                    :key="project.id"
                                  >
                                    <v-avatar
                                      color="blue lighten-1"
                                      size="30"
                                      style="padding:4px"
                                    >
                                      <strong class="white--text headline">{{ avatarNames(project.name) }}</strong>
                                    </v-avatar>
                                    <v-list-item-content class="ml-2">
                                      <v-list-item-title v-text="project.name" />
                                    </v-list-item-content>
                                  </v-list-item>
                                </v-list-item-group>
                              </v-list>                           </v-card>
                          </v-menu>
                        </template>
                        <span>{{ item.name }}</span>                   </v-tooltip>
                    </template>
                  </v-autocomplete>
                </v-col>

                <v-col cols="2" class="pt-0 pb-0 pl-1">
                  <v-autocomplete
                    v-model="clientEscalationId"
                    :items="clientEscalation"
                    item-text="name"
                    item-value="id"
                    class="filtersFields"
                    label="Client Escalation"
                    outlined
                    small-chips
                    dense
                    clearable
                    @change="commonFilter"
                  >
                  </v-autocomplete>
                </v-col>

                <v-col cols="2" class="pt-0 pb-0 pl-1">
                  <v-autocomplete
                    v-model="selectedStatus"
                    :items="status"
                    item-text="text"
                    item-value="id"
                    class="filtersFields ovrlhlthStFld"
                    label="Overall Health Status"
                    outlined
                    small-chips
                    dense
                    multiple
                    @change="commonFilter"
                  >
                    <template v-slot:selection="{ attrs, item, parent, selected, index }" class="slectedChilpSRWrp">
                      <v-tooltip top>
                        <template v-slot:activator="{ on }">
                          <v-chip
                            v-if="item === Object(item) && index === 0"
                            v-bind="attrs"
                            :input-value="selected"
                            label
                            small
                            v-on="on"
                          >
                            <span class="slectedChilpSR">
                              {{ item.text.length >= 47? item.text.slice(0,47) + '...': item.text }}
                            </span>
                            <v-icon
                              small
                              @click="parent.selectItem(item)"
                            >
                              mdi-close
                            </v-icon>
                          </v-chip>
                          <v-menu
                            bottom
                            origin="center center"
                            transition="scale-transition"
                          >
                            <template v-slot:activator="{ on }">
                              <v-btn
                                v-if="index === 1"
                                class="ml-1 mr-1 text-capitalize"
                                outlined
                                rounded
                                fab
                                small
                                height="25"
                                width="25"
                                color="blue"
                                v-on="on"
                                @click="!false"
                              >
                                <v-icon x-small style="height: 10px; width: 10px">
                                  mdi-plus
                                </v-icon>
                                {{ selectedStatus.length - 1 }}
                              </v-btn>
                            </template>
                            <v-card
                              v-show="!false"
                              class="mx-auto"
                              max-width="300"
                              raised
                            >
                              <v-list
                                v-if="selectedStatusData.length > 1"
                                disabled
                                shaped
                              >
                                <v-list-item-group
                                  v-model="selectedStatusData"
                                >
                                  <v-list-item
                                    v-for="project in selectedStatusData.slice(1,selectedStatusData.length)"
                                    v-show="!false"
                                    :key="project.id"
                                  >
                                    <v-avatar
                                      color="blue lighten-1"
                                      size="30"
                                      style="padding:4px"
                                    >
                                      <strong class="white--text headline">{{ avatarNames(project.text) }}</strong>
                                    </v-avatar>
                                    <v-list-item-content class="ml-2">
                                      <v-list-item-title v-text="project.text" />
                                    </v-list-item-content>
                                  </v-list-item>
                                </v-list-item-group>
                              </v-list>
                            </v-card>
                          </v-menu>
                        </template>
                        <span>{{ item.text }}</span>
                      </v-tooltip>
                    </template>

                  </v-autocomplete>
                </v-col>
                <v-col cols="2" class="pa-0">
                  <v-autocomplete
                    v-model="selectedProject"
                    :items="projectNameArray"
                    item-text="name"
                    item-value="id"
                    class="filtersFields"
                    label="Project Name"
                    outlined
                    dense
                    multiple
                    :search-input.sync="searchProjectName"
                    @click:clear="clearItem(selectedProject)"
                    @change="searchProjectName = ''"
                    @input="commonFilter"
                  >
                    <template v-slot:selection="{ attrs, item, parent, selected, index }" class="slectedChilpSRWrp">
                      <v-tooltip top>
                        <template v-slot:activator="{ on }">
                          <v-chip
                            v-if="item === Object(item) && index === 0"
                            v-bind="attrs"
                            :input-value="selected"
                            label
                            small
                            v-on="on"
                          >
                            <span class="slectedChilpSR">
                              {{ item.name.length >= 47? item.name.slice(0,47) + '...': item.name }}
                            </span>
                            <v-icon
                              small
                              @click="parent.selectItem(item)"
                            >
                              mdi-close
                            </v-icon>
                          </v-chip>
                          <v-menu
                            bottom
                            origin="center center"
                            transition="scale-transition"
                          >
                            <template v-slot:activator="{ on }">
                              <v-btn
                                v-if="index === 1"
                                class="wsrMoreChilp"
                                outlined
                                rounded
                                fab
                                small
                                color="blue"
                                v-on="on"
                                @click="!false"
                              >
                                <v-icon x-small style="height: 10px; width: 10px">
                                  mdi-plus
                                </v-icon>
                                {{ selectedProject.length - 1 }}
                              </v-btn>
                            </template>
                            <v-card
                              v-show="!false"
                              class="mx-auto"
                              max-width="300"
                              raised
                            >
                              <v-list
                                v-if="selectedProjectData.length > 1"
                                disabled
                                shaped
                              >
                                <v-list-item-group
                                  v-model="selectedProjectData"
                                >
                                  <v-list-item
                                    v-for="project in selectedProjectData.slice(1,selectedProjectData.length)"
                                    v-show="!false"
                                    :key="project.id"
                                  >
                                    <v-avatar
                                      color="blue lighten-1"
                                      size="30"
                                      style="padding:4px"
                                    >
                                      <strong class="white--text headline">{{ avatarNames(project.name) }}</strong>
                                    </v-avatar>
                                    <v-list-item-content class="ml-2">
                                      <v-list-item-title v-text="project.name" />
                                    </v-list-item-content>
                                  </v-list-item>
                                </v-list-item-group>
                              </v-list>
                            </v-card>
                          </v-menu>
                        </template>
                        <span>{{ item.name }}</span>
                      </v-tooltip>
                    </template>

                  </v-autocomplete>
                </v-col>
                <v-col cols="2" class="pt-0 pb-0">
                  <v-autocomplete
                    v-model="selectedWeek"
                    :items="getYearlyWeeksArr"
                    item-text="id"
                    item-value="name"
                    class="filtersFields"
                    label="Select Week No."
                    outlined
                    dense
                    @change="commonFilter"
                  />
                </v-col>
              </v-row>
            </div>
          </template>
          <template v-slot:item.project_name="{item}">
            {{ item.project_name }}
            <v-spacer />

            <span
              v-if="item.action_req === 1"
              class="clientEscalationWsrL "
            >
              Client Escalation

            </span>
            <span
              v-else
              class="red--text"
            >

            </span>
            <!-- </v-list-item> -->
          </template>

          <template v-slot:[`item.overall_health`]="{ item }">
            <div v-if="item.overall_health === health.RED">
              <v-chip color="red" dark rounded>Red</v-chip>
            </div>
            <div v-else-if="item.overall_health === health.GREEN">
              <v-chip color="green" dark rounded>Green</v-chip>
            </div>
            <div v-else-if="item.overall_health === health.AMBER">
              <v-chip color="amber" dark rounded>Amber</v-chip>
            </div>
            <div v-else>
              NA
            </div>
          </template>
          <template v-slot:[`item.sch_status`]="{ item }">
            <div v-if="item.sch_status === health.RED">
              <div v-if="item.sch_remark.length > 0">
                <v-tooltip top>
                  <template v-slot:activator="{ on, attrs }">
                    <v-chip
                      color="red"
                      dark
                      v-bind="attrs"
                      rounded
                      v-on="on"
                    >
                      Red
                    </v-chip>
                    <span class="red--text ml-1 mt-1">{{ item.sch_esclation }}</span>
                  </template>
                  <span>{{ item.sch_remark }}</span>
                </v-tooltip>
              </div>
              <div v-else>
                <v-chip color="red" dark rounded>
                  Red
                </v-chip>
                <span class="red--text ml-1 mt-1">{{ item.sch_esclation }}</span>
              </div>
            </div>
            <div v-else-if="item.sch_status === health.GREEN">
              <div v-if="item.sch_remark.length > 0">
                <v-tooltip top>
                  <template v-slot:activator="{ on, attrs }">
                    <v-chip
                      color="green"
                      dark
                      v-bind="attrs"
                      rounded
                      v-on="on"
                    >
                      Green
                    </v-chip>
                    <span class="red--text ml-1 mt-1">{{ item.sch_esclation }}</span>
                  </template>
                  <span >{{ item.sch_remark }}</span>
                </v-tooltip>
              </div>
              <div v-else>
                <v-chip color="green" dark rounded>
                  Green
                </v-chip>
                <span class="red--text ml-1 mt-1">{{ item.sch_esclation }}</span>
              </div>
            </div>
            <div v-else-if="item.sch_status === health.AMBER">
              <div v-if="item.sch_remark.length > 0">
                <v-tooltip top>
                  <template v-slot:activator="{ on, attrs }">
                    <v-chip
                      color="amber"
                      dark
                      v-bind="attrs"
                      rounded
                      v-on="on"
                    >
                      Amber
                    </v-chip>
                    <span class="red--text ml-1 mt-1">{{ item.sch_esclation }}</span>
                  </template>
                  <span>{{ item.sch_remark }}</span>
                </v-tooltip>
              </div>
              <div v-else>
                <v-chip color="amber" dark rounded>
                  Amber
                </v-chip>
                <span class="red--text ml-1 mt-1">{{ item.sch_esclation }}</span>
              </div>
            </div>
            <div v-else>
              NA
            </div>
          </template>
          <template v-slot:[`item.qlt_status`]="{ item }">
            <div v-if="item.qlt_status === health.RED">
              <div v-if="item.qlt_remark.length > 0">
                <v-tooltip top>
                  <template v-slot:activator="{ on, attrs }">
                    <v-chip
                      color="red"
                      dark
                      v-bind="attrs"
                      rounded
                      v-on="on"
                    >
                      Red
                    </v-chip>
                    <span class="red--text ml-1 mt-1">{{ item.qlt_esclation }}</span>

                    <span class="red--text ml-1 mt-1">{{ item.sch_esclation }}</span>
                  </template>
                  <span>{{ item.qlt_remark }}</span>
                </v-tooltip>
              </div>
              <div v-else>
                <v-chip color="red" dark rounded>
                  Red
                </v-chip>
                <span class="red--text ml-1 mt-1">{{ item.qlt_esclation }}</span>
              </div>
            </div>
            <div v-else-if="item.qlt_status === health.GREEN">
              <div v-if="item.qlt_remark.length > 0">
                <v-tooltip top>
                  <template v-slot:activator="{ on, attrs }">
                    <v-chip
                      color="green"
                      dark
                      v-bind="attrs"
                      rounded
                      v-on="on"
                    >
                      Green
                    </v-chip>
                    <span class="red--text ml-1 mt-1">{{ item.qlt_esclation }}</span>
                  </template>
                  <span>{{ item.qlt_remark }}</span>
                </v-tooltip>
              </div>
              <div v-else>
                <v-chip color="green" dark rounded>
                  Green
                </v-chip>
                <span class="red--text ml-1 mt-1">{{ item.qlt_esclation }}</span>
              </div>
            </div>
            <div v-else-if="item.qlt_status === health.AMBER">
              <div v-if="item.qlt_remark.length > 0">
                <v-tooltip top>
                  <template v-slot:activator="{ on, attrs }">
                    <v-chip
                      color="amber"
                      dark
                      v-bind="attrs"
                      rounded
                      v-on="on"
                    >
                      Amber
                    </v-chip>
                    <span class="red--text ml-1 mt-1">{{ item.qlt_esclation }}</span>
                  </template>
                  <span>{{ item.qlt_remark }}</span>
                </v-tooltip>
              </div>
              <div v-else>
                <v-chip color="amber" dark rounded>
                  Amber
                </v-chip>
                <span class="red--text ml-1 mt-1">{{ item.qlt_esclation }}</span>
              </div>
            </div>
            <div v-else>
              NA
            </div>
          </template>
          <template v-slot:[`item.stf_status`]="{ item }">
            <div v-if="item.stf_status === health.RED">
              <div v-if="item.stf_remark.length > 0">
                <v-tooltip top>
                  <template v-slot:activator="{ on, attrs }">
                    <v-chip
                      color="red"
                      dark
                      v-bind="attrs"
                      rounded
                      v-on="on"
                    >
                      Red
                    </v-chip>
                    <span class="red--text ml-1 mt-1">{{ item.stf_esclation }}</span>
                  </template>
                  <span>{{ item.stf_remark }}</span>
                </v-tooltip>
              </div>
              <div v-else>
                <v-chip color="red" dark rounded>
                  Red
                </v-chip>
                <span class="red--text ml-1 mt-1">{{ item.stf_esclation }}</span>
              </div>
            </div>
            <div v-else-if="item.stf_status === health.GREEN">
              <div v-if="item.stf_remark.length > 0">
                <v-tooltip top>
                  <template v-slot:activator="{ on, attrs }">
                    <v-chip
                      color="green"
                      dark
                      v-bind="attrs"
                      rounded
                      v-on="on"
                    >
                      Green
                    </v-chip>
                    <span class="red--text ml-1 mt-1">{{ item.stf_esclation }}</span>

                  </template>
                  <span>{{ item.stf_remark }}</span>
                </v-tooltip>
              </div>
              <div v-else>
                <v-chip color="green" dark rounded>
                  Green
                </v-chip>
                <span class="red--text ml-1 mt-1">{{ item.stf_esclation }}</span>
              </div>
            </div>
            <div v-else-if="item.stf_status === health.AMBER">
              <div v-if="item.stf_remark.length > 0">
                <v-tooltip top>
                  <template v-slot:activator="{ on, attrs }">
                    <v-chip
                      color="amber"
                      dark
                      v-bind="attrs"
                      rounded
                      v-on="on"
                    >
                      Amber
                    </v-chip>
                    <span class="red--text ml-1 mt-1">{{ item.stf_esclation }}</span>
                  </template>
                  <span>{{ item.stf_remark }}</span>
                </v-tooltip>
              </div>
              <div v-else>
                <v-chip color="amber" dark rounded>
                  Amber
                </v-chip>
                <span class="red--text ml-1 mt-1">{{ item.stf_esclation }}</span>
              </div>
            </div>
            <div v-else>
              NA
            </div>
          </template>
          <template v-slot:[`item.inv_status`]="{ item }">
            <div v-if="item.inv_status === health.RED">
              <div v-if="item.inv_remark.length > 0">
                <v-tooltip top>
                  <template v-slot:activator="{ on, attrs }">
                    <v-chip
                      color="red"
                      dark
                      v-bind="attrs"
                      rounded
                      v-on="on"
                    >
                      Red
                    </v-chip>
                    <span class="red--text ml-1 mt-1">{{ item.inv_esclation }}</span>
                  </template>
                  <span>{{ item.inv_remark }}</span>
                </v-tooltip>
              </div>
              <div v-else>
                <v-chip color="red" dark rounded>
                  Red
                </v-chip>
                <span class="red--text ml-1 mt-1">{{ item.inv_esclation }}</span>
              </div>
            </div>
            <div v-else-if="item.inv_status === health.GREEN">
              <div v-if="item.inv_remark.length > 0">
                <v-tooltip top>
                  <template v-slot:activator="{ on, attrs }">
                    <v-chip
                      color="green"
                      dark
                      v-bind="attrs"
                      rounded
                      v-on="on"
                    >
                      Green
                    </v-chip>
                    <span class="red--text ml-1 mt-1">{{ item.inv_esclation }}</span>
                  </template>
                  <span>{{ item.inv_remark }}</span>
                </v-tooltip>
              </div>
              <div v-else>
                <v-chip color="green" dark rounded>
                  Green
                </v-chip>
                <span class="red--text ml-1 mt-1">{{ item.inv_esclation }}</span>
              </div>
            </div>
            <div v-else-if="item.inv_status === health.AMBER">
              <div v-if="item.inv_remark.length > 0">
                <v-tooltip top>
                  <template v-slot:activator="{ on, attrs }">
                    <v-chip
                      color="amber"
                      dark
                      v-bind="attrs"
                      rounded
                      v-on="on"
                    >
                      Amber
                    </v-chip>
                    <span class="red--text ml-1 mt-1">{{ item.inv_esclation }}</span>
                  </template>
                  <span>{{ item.inv_remark }}</span>
                </v-tooltip>
              </div>
              <div v-else>
                <v-chip color="amber" dark rounded>
                  Amber
                </v-chip>
                <span class="red--text ml-1 mt-1">{{ item.inv_esclation }}</span>
              </div>
            </div>
            <div v-else>
              NA
            </div>
          </template>
          <template v-slot:[`item.rsk_status`]="{ item }">
            <div v-if="item.rsk_status === health.RED">
              <div v-if="item.rsk_remark.length > 0">
                <v-tooltip top>
                  <template v-slot:activator="{ on, attrs }">
                    <v-chip
                      color="red"
                      dark
                      v-bind="attrs"
                      rounded
                      v-on="on"
                    >
                      Red
                    </v-chip>
                    <span class="red--text ml-1 mt-1">{{ item.rsk_esclation }}</span>
                  </template>
                  <span>{{ item.rsk_remark }}</span>
                </v-tooltip>
              </div>
              <div v-else>
                <v-chip color="red" dark rounded>
                  Red
                </v-chip>
                <span class="red--text ml-1 mt-1">{{ item.rsk_esclation }}</span>
              </div>
            </div>
            <div v-else-if="item.rsk_status === health.GREEN">
              <div v-if="item.rsk_remark.length > 0">
                <v-tooltip top>
                  <template v-slot:activator="{ on, attrs }">
                    <v-chip
                      color="green"
                      dark
                      v-bind="attrs"
                      rounded
                      v-on="on"
                    >
                      Green
                    </v-chip>
                    <span class="red--text ml-1 mt-1">{{ item.rsk_esclation }}</span>
                  </template>
                  <span>{{ item.rsk_remark }}</span>
                </v-tooltip>
              </div>
              <div v-else>
                <v-chip color="green" dark rounded>
                  Green
                </v-chip>
                <span class="red--text ml-1 mt-1">{{ item.rsk_esclation }}</span>
              </div>
            </div>
            <div v-else-if="item.rsk_status === health.AMBER">
              <div v-if="item.rsk_remark.length > 0">
                <v-tooltip top>
                  <template v-slot:activator="{ on, attrs }">
                    <v-chip
                      color="amber"
                      dark
                      v-bind="attrs"
                      rounded
                      v-on="on"
                    >
                      Amber
                    </v-chip>
                    <span class="red--text ml-1 mt-1">{{ item.rsk_esclation }}</span>
                  </template>
                  <span>{{ item.rsk_remark }}</span>
                </v-tooltip>
              </div>
              <div v-else>
                <v-chip color="amber" dark rounded>
                  Amber
                </v-chip>
                <span class="red--text ml-1 mt-1">{{ item.rsk_esclation }}</span>
              </div>
            </div>
            <div v-else>
              NA
            </div>
          </template>
          <template v-slot:[`item.eft_status`]="{ item }">
            <div v-if="item.eft_status === health.RED">
              <div v-if="item.eft_remark.length > 0">
                <v-tooltip top>
                  <template v-slot:activator="{ on, attrs }">
                    <v-chip
                      color="red"
                      dark
                      v-bind="attrs"
                      rounded
                      v-on="on"
                    >
                      Red
                    </v-chip>
                    <span class="red--text ml-1 mt-1">{{ item.eft_esclation }}</span>
                  </template>
                  <span>{{ item.eft_remark }}</span>
                </v-tooltip>
              </div>
              <div v-else>
                <v-chip color="red" dark rounded>
                  Red
                </v-chip>
                <span class="red--text ml-1 mt-1">{{ item.eft_esclation }}</span>
              </div>
            </div>
            <div v-else-if="item.eft_status === health.GREEN">
              <div v-if="item.eft_remark">
                <v-tooltip top>
                  <template v-slot:activator="{ on, attrs }">
                    <v-chip
                      color="green"
                      dark
                      v-bind="attrs"
                      rounded
                      v-on="on"
                    >
                      Green
                    </v-chip>
                    <span class="red--text ml-1 mt-1">{{ item.eft_esclation }}</span>
                  </template>
                  <span>{{ item.eft_remark }}</span>
                </v-tooltip>
              </div>
              <div v-else>
                <v-chip color="green" dark rounded>
                  Green
                </v-chip>
                <span class="red--text ml-1 mt-1">{{ item.eft_esclation }}</span>
              </div>
            </div>
            <div v-else-if="item.eft_status === health.AMBER">
              <div v-if="item.eft_remark.length > 0">
                <v-tooltip top>
                  <template v-slot:activator="{ on, attrs }">
                    <v-chip
                      color="amber"
                      dark
                      v-bind="attrs"
                      rounded
                      v-on="on"
                    >
                      Amber
                    </v-chip>
                    <span class="red--text ml-1 mt-1">{{ item.eft_esclation }}</span>
                  </template>
                  <span>{{ item.eft_remark }}</span>
                </v-tooltip>
              </div>
              <div v-else>
                <v-chip color="amber" dark rounded>
                  Amber
                </v-chip>
                <span class="red--text ml-1 mt-1">{{ item.eft_esclation }}</span>
              </div>
            </div>
            <div v-else>
              NA
            </div>
          </template>

          <template v-slot:item.action="{item}">
            <span>
              <v-tooltip top>
                <template v-slot:activator="{ on, attrs }">
                  <v-img
                    :src="viewIcon"
                    class="quickAct"
                    v-bind="attrs"
                    @click="viewProject(item.uuid)"
                    v-on="on"
                  />
                </template>
                <span>View Project</span>
              </v-tooltip>
            </span>
            <span>
              <v-tooltip top>
                <template v-slot:activator="{ on, attrs }">
                  <v-img

                    :src="editIcon"
                    class="quickAct"
                    v-bind="attrs"
                    @click="editProject(item.uuid)"
                    v-on="on"
                  />
                </template>
                <span>Edit Project</span>
              </v-tooltip>
            </span>
          </template>

        </v-data-table>
      </v-col>
    </v-row>
  </div>
</template>

<script>
import { mapActions, mapGetters } from 'vuex'
import constant from '../../constants/closure-checklist'
import { projectHelpers } from '@/helpers/helper.js'

export default {
  layout: 'default',
  middleware: 'authenticated',
  async fetch({ store,requestParam }) {

    const requestData = {
      'week_no': (this.selectedWeekArr) ? this.selectedWeekArr : [],
      'pmuser_id':  (this.assignToIds) ? this.assignToIds : [],
      'overall_health_status':  (this.selectedStatus) ? this.selectedStatus : [],
      'client_exclation':  this.clientEscalationId,
      'project_name':  (this.selectedProject) ? this.selectedProject : [],
      'billing_type': []
    }

    // eslint-disable-next-line no-useless-catch
    try {
      await Promise.all([
        store.dispatch('AmPmDashboard/fetchAssignedUsers'),
        store.dispatch('project/fetchProjectList'),
        store.dispatch('AmPmDashboard/fetchWSR',requestData),
        store.dispatch('AmPmDashboard/fetchWeeks'),
        store.dispatch('project/fetchBillingTypes')
      ])
    } catch (error) {
      throw error
    }
  },
  data() {
    return {
      assignToIds:'',
      selectedAssignId:[],
      clientEscalationIdArr:[],
      menu: false,
      selectedWeek: '',
      getYearlyWeeksArr:[],
      selectedStatus: null,
      selectedProject: '',
      projectNameArray: [],
      selectedProjectData:[],
      selectedStatusData:[],
      rolesAllowed: false,
      typeDetails: [
        { id: 2, name: 'No' },
        { id: 1, name: 'Yes' }
      ],
      headers: [
        { text: 'Project Name', align: 'center', value: 'project_name' },
        { text: 'Ending Date', align: 'center', value: 'week_end_date', sortable: false },
        { text: 'Overall Health', align: 'center', sortable: false, value: 'overall_health' },
        { text: 'Schedule', align: 'center', value: 'sch_status', sortable: false },
        { text: 'Quality', align: 'center', value: 'qlt_status', sortable: false },
        { text: 'Staffing', align: 'center', value: 'stf_status', sortable: false },
        { text: 'Invoices', align: 'center', value: 'inv_status', sortable: false },
        { text: 'Risk', align: 'center', value: 'rsk_status', sortable: false },
        {
          text: 'Effort',
          align: 'center',
          value: 'eft_status',
          sortable: false
        },
        { text: 'Quick Actions', align: 'center', value: 'action', sortable: false }
      ],
      status: constant.WSR_STATUS,
      categories: constant.WSR_CATEGORY,
      health: constant.HEALTH_STATUS,
      wsrItems: [],
      remark: '',
      searchProjectName: '',
      wsrListData: [],
      selectedProjectArray: [],
      assignedUsers:[],
      clientEscalation: [
        { id: 2, name: 'No' },
        { id: 1, name: 'Yes' }
      ],
      clientEscalationId:'',
      billingType:[],
      assignToIdsType:'',
      getWsrListArray:[],
      projectNameArr:[],
      selectedWeekArr:[]

    }

  },
  computed: {
    ...mapGetters({
      getGlobalRole: 'roles/getGlobalRole',
      getAssignedUsers: 'AmPmDashboard/getAssignedUsers',
      getProjectList: 'project/getProjectList',
      getWsrList: 'AmPmDashboard/getWsrList',
      getYearlyWeeks: 'AmPmDashboard/getYearlyWeeks',
      billingTypes: 'project/getBillingTypes'
    }),
    viewIcon() {
      return require('@/assets/icons/view-PMO.png')
    },
    editIcon () {
      return require('@/assets/icons/Edit-pmo.png')
    }
  },
  watch: {
    getProjectList() {
      this.projectNameArr = this.getProjectList
    },
    selectedProject () {
      this.selectedProjectData = []
      this.selectedProject.forEach((id) => {
        const domains = this.projectNameArray.filter((item) => { return item.id === id })

        this.selectedProjectData.push(domains[0])
      })
    },
    selectedStatus() {
      this.selectedStatusData = []
      this.selectedStatus.forEach((id) => {
        const health = this.status.filter((item) => { return item.id === id })

        this.selectedStatusData.push(health[0])
      })
    },
    assignToIds() {
      this.selectedAssignId = []
      this.assignToIds.forEach((id) => {
        const domains = this.assignedUsers.filter((item) => { return item.id === id })

        this.selectedAssignId.push(domains[0])
      })
    },
    getYearlyWeeks() {
      this.getYearlyWeeksArr = this.getYearlyWeeks
      this.mutateYearAndWeekList(this.getYearlyWeeks)
    },
    getWsrList() {
      this.getWsrListArray = this.getWsrList.data
      this.mutateWsrListData()
    }

  },
  mounted() {
    this.getYearlyWeeksArr = this.getYearlyWeeks
    this.mutateYearAndWeekList(this.getYearlyWeeks)

    this.postFetchWsr()
    this.getWsrListArray = this.getWsrList.data
    this.projectNameArr = this.getProjectList
    if (this.projectNameArr.length > 0)
    {
      this.projectNameArr.forEach((project) => {
        if (!constant.NON_INPROGRESS_STATUS.includes(project.status) && project.is_draft === 0) {
          this.projectNameArray.push({
            name: project.project_name,
            id: project.uuid
          })
        }

      })
    }

    this.mutateAssignedUsers(this.getAssignedUsers)
    this.mutateWsrListData()
    this.hasViewAccess()

  },

  methods: {
    ...mapActions({
      fetchWSR: 'AmPmDashboard/fetchWSR',
      fetchProjectList: 'project/fetchProjectList'
    }),
    async commonFilter() {

      if (this.clientEscalationId === null) {
        this.clientEscalationId = ''
      }
      this.selectedWeekArr = [this.selectedWeek]

      const requestData = {
        'week_no': (this.selectedWeekArr) ? this.selectedWeekArr : [],
        'pmuser_id':  (this.assignToIds) ? this.assignToIds : [],
        'overall_health_status':  (this.selectedStatus) ? this.selectedStatus : [],
        'client_exclation':  this.clientEscalationId,
        'project_name':  (this.selectedProject) ? this.selectedProject : [],
        'billing_type': []
      }

      await this.fetchWSR(requestData)
    },
    clearItem(id) {
      const resultb = id.filter((value) => { return  value === '' })

      if (resultb[0] === '') {
        this.assignToIds = ''

      }
    },
    async mutateYearAndWeekList (data) {
      if (data !== undefined && data.length > 0)
      {
        const currentMinusOneWeekData = this.getYearlyWeeksArr.filter((details) => details.status === 'currentWeek')

        this.selectedWeek = currentMinusOneWeekData[0].value
        const weekListArray = []

        this.getYearlyWeeksArr.map((details) => {

          weekListArray.push({
            id: details.value + ' (' + details.key + ')',
            name: details.value
          })
        })
        this.getYearlyWeeksArr = weekListArray
      }
    },

    postFetchWsr() {
      this.selectedWeekArr = [this.selectedWeek]
      const requestData = {
        'week_no': (this.selectedWeekArr) ? this.selectedWeekArr : [],
        'pmuser_id':  (this.assignToIds) ? this.assignToIds : [],
        'overall_health_status':  (this.selectedStatus) ? this.selectedStatus : [],
        'client_exclation':  this.clientEscalationId,
        'project_name':  (this.selectedProject) ? this.selectedProject : [],
        'billing_type': []
      }

      this.fetchWSR(requestData)
    },
    hasViewAccess() {
      if (this.getGlobalRole.length) {
        this.getGlobalRole.map((role) => {
          if (
            role.role_id === constant.ROLE_ID.ADMIN
          ) {
            this.rolesAllowed = true
          }
        })
      }
    },
    mutateWsrListData() {
      const obj = []

      if (this.getWsrListArray !== undefined)
      {
        this.getWsrListArray.forEach((item) => {
          if (this.projectNameArr.filter((e) => { return e.uuid === item.project_id }).length > 0) {
            let weekEndDate = 'NA'
            let displayName = ''

            if (item.week_end_date !== null) {
              weekEndDate = new Date(item.week_end_date).toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'short',
                day: 'numeric'
              })
            }

            if (item.created_by_user === null) {
              displayName = ''
            }
            else {
              displayName = item.created_by_user.display_name
            }
            obj.push({ uuid: item.uuid,
              project_id: item.project_id,
              sch_status: item.sch_cat_status,
              sch_remark: item.sch_cat_remark,
              sch_esclation: item.sch_cat_clt_esclation === 1 ? '!' : '',
              qlt_status: item.qlt_cat_status,
              qlt_remark: item.qlt_cat_remark,
              qlt_esclation: item.qlt_cat_clt_esclation === 1 ? '!' : '',
              stf_status: item.stf_cat_status,
              stf_remark: item.stf_cat_remark,
              stf_esclation: item.stf_cat_clt_esclation === 1 ? '!' : '',
              inv_status: item.inv_cat_status,
              inv_remark: item.inv_cat_remark,
              inv_esclation: item.inv_cat_clt_esclation === 1 ? '!' : '',
              rsk_status: item.rsk_cat_status,
              rsk_remark: item.rsk_cat_remark,
              rsk_esclation: item.rsk_cat_clt_esclation === 1 ? '!' : '',
              eft_status: item.eft_cat_status,
              eft_remark: item.eft_cat_remark,
              eft_esclation:item.eft_cat_clt_esclation === 1 ? '!' : '',
              highlights_remark: item.highlights_remark,
              lowlights_remark: item.lowlights_remark,
              customer_happiness_remark: item.customer_happiness_remark,
              people_happiness_remark: item.people_happiness_remark,
              created_by: item.created_by,
              created_at: item.created_at,
              updated_at: item.updated_at,
              deleted_at: item.deleted_at,
              created_by_user: displayName ,
              billing_id: item.project_name.billing_type.id,
              billing_type: item.project_name.billing_type.name,
              project_name: item.project_name.project_name,
              overall_health: item.overall_health_status,
              week_end_date: weekEndDate,
              wk_end_date: item.week_end_date,
              wk_start_date: item.week_start_date,
              week_no: item.week_no,
              action_req: this.actionRequired(item)

            })

          }
        })
        this.getWsrListArray = [...obj]
      }
    },
    avatarNames (fullName) {

      return projectHelpers.avatarNames(fullName)
    },
    viewProject (id) {
      this.$router.push(`/wsr/${id}/view-wsr`)
    },
    editProject (id) {
      this.$router.push(`/wsr/${id}/edit-wsr`)
    },

    actionRequired(item) {

      if ((item.stf_cat_clt_esclation === 1)  ||  (item.inv_cat_clt_esclation === 1) || (item.sch_cat_clt_esclation === 1) || (item.rsk_cat_clt_esclation === 1) || (item.qlt_cat_clt_esclation === 1) || (item.eft_cat_clt_esclation === 1)) {
        return 1
      } else {
        return 0
      }

    },

    mutateAssignedUsers (data) {
      if (data) {
        const listArray = []

        data.map((details) => {
          if (details.user_role_local.length) {
            const userRoles = details.user_role_local
            const am = Object.values(userRoles).filter((item) => (item.role_id === 5 || item.role_id === 6))

            if (am.length) {
              listArray.push({
                id: details.user_id,
                name: details.full_name
              })
            }
          }
        })
        this.assignedUsers = listArray
      }
    }
  }
}
</script>
<style scoped>
.v-chip.v-size--default {
font-size: smaller;
height: auto;
}
.v-application .headline {
font-size: 1rem !important;
font-weight: 400;
line-height: 2rem;
letter-spacing: normal !important;
font-family: "Open Sans", sans-serif !important;
}
.v-text-field__slot >>> .theme--light.v-label--is-disabled {
color: rgba(0, 0, 0, 0.6);
font-size: 18px
}
.icon {
background-position: inherit;
height: 50;
width: 50;
}
.projectCardCatInner .v-list-item__title {/* Style for "Project Ty" */
    color: rgb(112 112 112 / 55%);
    font-size: 18px;
    font-weight: 400;
    text-align: left;
/* Text style for "Project Ty" */
    font-style: normal;
    letter-spacing: normal;
    line-height: normal;
}

.projectCardCatInner .v-list-item__subtitle > span {/* Style for "Billable" */
    color: #1976d2;
    font-size: 22px;
    text-align: left;
    font-weight: 600;
    font-style: normal;
    letter-spacing: normal;
    line-height: normal;
}

.projectCardCatInner span.pmName {
    margin-right: 7px;
}
.v-card__actions.projectCardCatAct {
    display: block;
    padding: 0;
    width: 100%;
}

.v-card__actions.projectCardCatAct .v-text-field__details {
    margin: 0;
}

.projectCardCatAct .v-input__control {
    display: block !important;
}
</style>
