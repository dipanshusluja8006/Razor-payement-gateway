<template>
  <div>
    <Dialog />
    <ValidationObserver ref="wsr" v-slot="{ valid }">
      <v-row>
        <v-col cols="12" md="12" xl="12" class="dashboardHeading">
          <div class="wsrHeading">
            <h1>Edit Project WSR</h1>
            <p>Project Dashboard | Edit Weekly Status</p>
          </div>
          <div class="wsrProjectSercOuter">
            <div class="wsrProjectSerc">
              <label>Project*</label>

              <v-text-field
                v-model="projectName"
                placeholder="Project Name"
                outlined
                readonly
                dense
              />

            </div>
            <div class="wsrProjectWeekWrp">
              <span class="week7"><b>Week</b> {{ week_no }}</span>
              <p><b>Ending Date:</b> <span>{{ week_end_date }}</span></p>
            </div>
          </div>
        </v-col>
      </v-row>

      <div class="wsrTableWrp">
        <v-row no-gutters>
          <v-data-table
            :headers="headers"
            :items="wsrItems"
            :hide-default-footer="true"
            style="width: 100%;"
          >
            <template v-slot:item.category="{ item }">
              <span>
                {{ item.category.text }}
              </span>
            </template>
            <template v-slot:item.clientEscalation="{item}">
              <div class="switch-field">
                <input
                  :id="item.category.radioOne"
                  type="radio"
                  :name="item.category.escalation"
                  value="yes"
                  :checked="item.clientEscliationValue === 1 ? true : false"

                  @click="setClientEscalation(1,item.category.text)"
                />
                <label :for="item.category.radioOne">Yes</label>
                <input
                  :id="item.category.radioTwo"
                  type="radio"
                  :name="item.category.escalation"
                  value="no"
                  :checked="item.clientEscliationValue === 0 ? true : false "

                  @click="setClientEscalation(0,item.category.text)"
                />
                <label :for="item.category.radioTwo">No</label>
              </div>
            </template>

            <template v-slot:item.status="{ item }">
              <button :class="item.green" type="button" @click="addStatus(3, item.id)">Green</button>
              <button :class="item.amber" type="button" @click="addStatus(2, item.id)">Amber</button>
              <button :class="item.red" type="button" @click="addStatus(1, item.id)">Red</button>
            </template>
            <template v-slot:item.remark="props">
              <ValidationProvider v-slot="{ errors }" :rules="'alpha_num_whitespace_special'" name="props.item.remark">
                <v-text-field
                  v-model="props.item.remark"
                  placeholder="Add Remarks"
                  outlined
                  dense
                  :error-messages="errors"
                  @input="addRemark(props.item.remark, props.item.id)"
                ></v-text-field>
              </ValidationProvider>
            </template>
          </v-data-table>
        </v-row>
      </div>

      <v-card class="highlightsWrp">
        <v-row>
          <v-col cols="3" class="pb-0">
            <h4>Highlights</h4>
          </v-col>
          <v-col cols="9" class="pb-0">
            <ValidationProvider v-slot="{ errors }" :rules="'alpha_num_whitespace_special'" name="highRemark">
              <v-textarea
                v-model="highRemark"
                placeholder="Add Remarks"
                outlined
                :error-messages="errors"
                dense
              ></v-textarea>
            </ValidationProvider>
          </v-col>
          <v-col cols="3" class="pb-0 pt-1">
            <h4>Lowlights</h4>
          </v-col>
          <v-col cols="9" class="pb-0 pt-1">
            <ValidationProvider v-slot="{ errors }" :rules="'alpha_num_whitespace_special'" name="lowRemark">
              <v-textarea
                v-model="lowRemark"
                placeholder="Add Remarks"
                outlined
                :error-messages="errors"
                dense
              ></v-textarea>
            </ValidationProvider>
          </v-col>
          <v-col cols="3" class="pb-0 pt-1">
            <h4>Customer Happiness</h4>
          </v-col>
          <v-col cols="9" class="pb-0 pt-1">
            <ValidationProvider v-slot="{ errors }" :rules="'alpha_num_whitespace_special'" name="customerRemark">
              <v-textarea
                v-model="customerRemark"
                placeholder="Add Remarks"
                outlined
                :error-messages="errors"
                dense
              ></v-textarea>
            </ValidationProvider>
          </v-col>
          <v-col cols="3" class="pb-0 pt-1">
            <h4>People Happiness</h4>
          </v-col>
          <v-col cols="9" class="pb-0 pt-1">
            <ValidationProvider v-slot="{ errors }" :rules="'alpha_num_whitespace_special'" name="peopleRemark">
              <v-textarea
                v-model="peopleRemark"
                placeholder="Add Remarks"
                outlined
                :error-messages="errors"
                dense
              ></v-textarea>
            </ValidationProvider>
          </v-col>
        </v-row>

        <div class="submitBtnWrp">
          <div class="submitDiv" cols="12">
            <v-btn
              class="backBtn"
              @click="$router.push('/wsr/wsr-list')"
            >
              <v-icon dark left>
                mdi-arrow-left
              </v-icon>Back
            </v-btn>
            <v-btn :disabled="!valid || submitted || allStatusSelected === true" class="submitBtn" @click="submitWSR">
              Submit
            </v-btn>
          </div>
        </div>
      </v-card>
    </ValidationObserver>
  </div>
</template>

<script>
import { mapActions, mapGetters } from 'vuex'
import Dialog from '@/components/Dialog.vue'
import constant from '../../../constants/closure-checklist'

export default {
  layout: 'default',
  middleware: 'authenticated',
  components: { Dialog },
  async fetch ({ store, route }) {
    // eslint-disable-next-line no-useless-catch
    try {
      await Promise.all([
        store.dispatch('project/fetchProjectList'),
        store.dispatch('AmPmDashboard/fetchWSRDetail', route.params.id)
      ])
    } catch (error) {
      throw (error)
    }
  },
  data () {
    return {
      selectedStatus: null,
      greenStyle: 'btn green',
      amberStyle: 'btn amber',
      redStyle: 'btn red',
      highRemark: '',
      peopleRemark: '',
      customerRemark: '',
      projectName: '',
      lowRemark: '',
      selectedProject: '',
      submitted: false,
      projectNameArray: [],
      week_no: null,
      week_end_date: null,
      headers: [
        { text: 'Category', value: 'category', sortable: false },
        { text: 'Client Escalation', value: 'clientEscalation', sortable: false },
        { text: 'Status', value: 'status', sortable: false },
        { text: 'Mitigation/Remarks', value: 'remark', sortable: false, width: '35%' }
      ],
      status: constant.WSR_STATUS,
      categories: constant.WSR_CATEGORY,
      wsrItems: [],
      remark: '',
      searchProjectName: '',
      modifiedItems:[],
      allStatusSelected: true,
      scheduleId: null,
      qualityId: null,
      staffingId: null,
      invoiceId: null,
      riskId: null,
      effortId: null,
      scheduleRemark: '',
      qualityRemark: '',
      staffingRemark: '',
      invoiceRemark: '',
      riskRemark: '',
      effortRemark: '',
      scheduleEs: 0,
      qualityEs: 0,
      staffingEs: 0,
      invoiceEs: 0,
      riskEs: 0,
      effortEs: 0,
      clientEscliationValue: '',
      weeknumber: null,
      endOfWeek: null
    }
  },
  computed: {
    ...mapGetters({
      projectList: 'project/getProjectList',
      getCustomDialog: 'AmPmDashboard/getCustomDialog',
      getWSRDetail: 'AmPmDashboard/getWSRDetail'
    })
  },
  mounted() {

    this.projectList.forEach((project) => {
      if (!constant.NON_INPROGRESS_STATUS.includes(project.status) && project.is_draft === 0) {
        this.projectNameArray.push({
          name: project.project_name,
          id: project.uuid
        })
      }
    })

    this.projectName = this.getWSRDetail.project_name.project_name
    this.weeknumber = this.getWeekNumber(new Date())
    this.endOfWeek = this.getEndOfWeek(new Date())

    const { sch_cat_clt_esclation, qlt_cat_clt_esclation, stf_cat_clt_esclation, inv_cat_clt_esclation, rsk_cat_clt_esclation, eft_cat_clt_esclation } = this.getWSRDetail
    const { sch_cat_status, qlt_cat_status, stf_cat_status, inv_cat_status, rsk_cat_status, eft_cat_status } = this.getWSRDetail
    const { sch_cat_remark, qlt_cat_remark, stf_cat_remark, inv_cat_remark, rsk_cat_remark, eft_cat_remark } = this.getWSRDetail
    const { highlights_remark, customer_happiness_remark, lowlights_remark, people_happiness_remark,week_no,week_end_date } = this.getWSRDetail

    this.week_no = week_no
    this.week_end_date = this.getEndOfWeek(week_end_date)
    this.highRemark = highlights_remark
    this.customerRemark = customer_happiness_remark
    this.lowRemark = lowlights_remark
    this.peopleRemark =  people_happiness_remark
    this.categories.forEach((item) => {
      if (item.value === 1) {
        this.selectedStatus = sch_cat_status
        this.remark = sch_cat_remark
        this.clientEscliationValue = sch_cat_clt_esclation
        this.scheduleEs = sch_cat_clt_esclation
      } else if (item.value === 2) {
        this.selectedStatus = qlt_cat_status
        this.remark = qlt_cat_remark
        this.clientEscliationValue = qlt_cat_clt_esclation
        this.qualityEs = qlt_cat_clt_esclation
      } else if (item.value === 3) {
        this.selectedStatus = stf_cat_status
        this.remark = stf_cat_remark
        this.clientEscliationValue = stf_cat_clt_esclation
        this.staffingEs =  stf_cat_clt_esclation
      } else if (item.value === 4) {
        this.selectedStatus = inv_cat_status
        this.remark = inv_cat_remark
        this.clientEscliationValue = inv_cat_clt_esclation
        this.invoiceEs = inv_cat_clt_esclation
      } else if (item.value === 5) {
        this.selectedStatus = rsk_cat_status
        this.remark = rsk_cat_remark
        this.clientEscliationValue = rsk_cat_clt_esclation
        this.riskEs = rsk_cat_clt_esclation

      } else if (item.value === 6) {
        this.selectedStatus = eft_cat_status
        this.remark = eft_cat_remark
        this.clientEscliationValue = eft_cat_clt_esclation
        this.effortEs = eft_cat_clt_esclation
      }
      this.wsrItems.push({
        category: item,
        remark: this.remark,
        clientEscliationValue: this.clientEscliationValue,
        id: item.value,
        selected: this.selectedStatus,
        green: this.greenStyle,
        amber: this.amberStyle,
        red: this.redStyle
      })
      this.addStatus(this.selectedStatus, item.value)
      this.addRemark(this.remark, item.value)
    })

  },
  methods: {
    ...mapActions({
      editWsrInfo: 'AmPmDashboard/editWsrInfo',
      setCustomDialog: 'project/setCustomDialog'
    }),
    addStatus (status, id) {
      this.wsrItems.forEach((item) => {
        if (item.id !== id && this.selectedStatus === status) {
          this.selectedStatus = null
        }
      })
      if (id === 1) {
        this.scheduleId = status
        this.activeButtons(status, id)
      } else if (id === 2) {
        this.qualityId = status
        this.activeButtons(status, id)
      } else if (id === 3) {
        this.staffingId = status
        this.activeButtons(status, id)
      } else if (id === 4) {
        this.invoiceId = status
        this.activeButtons(status, id)
      } else if (id === 5) {
        this.riskId = status
        this.activeButtons(status, id)
      } else if (id === 6) {
        this.effortId = status
        this.activeButtons(status, id)
      }
      if (this.scheduleId !== null && this.qualityId !== null && this.staffingId !== null
      && this.invoiceId !== null && this.riskId !== null && this.effortId !== null) {
        this.allStatusSelected = false
      } else {
        this.allStatusSelected = true
      }
    },
    activeButtons(status, id) {
      const wsrArray =  []

      this.wsrItems.forEach((item) => {
        if (item.id === id) {
          if (status === constant.HEALTH_STATUS.GREEN) {
            this.greenStyle = this.greenStyle + ' ' + 'activeGreen'
            this.amberStyle = 'btn amber'
            this.redStyle = 'btn red'
          }
          if (status === constant.HEALTH_STATUS.AMBER) {
            this.amberStyle = this.amberStyle + ' ' + 'activeAmber'
            this.greenStyle = 'btn green'
            this.redStyle = 'btn red'
          }
          if (status === constant.HEALTH_STATUS.RED) {
            this.redStyle = this.redStyle + ' ' + 'activeRed'
            this.amberStyle = 'btn amber'
            this.greenStyle = 'btn green'
          }
          item.green = this.greenStyle
          item.amber = this.amberStyle
          item.red = this.redStyle
        }
        wsrArray.push(item)
      })

      this.wsrItems = wsrArray
    },
    addRemark (remark, id) {
      if (id === 1) {
        this.scheduleRemark = remark
      } else if (id === 2) {
        this.qualityRemark = remark
      } else if (id === 3) {
        this.staffingRemark = remark
      } else if (id === 4) {
        this.invoiceRemark = remark
      } else if (id === 5) {
        this.riskRemark = remark
      } else if (id === 6) {
        this.effortRemark = remark
      }
    },
    setClientEscalation (value,type) {

      if (type === 'Schedule') {
        this.scheduleEs = value
      } else if (type === 'Quality') {
        this.qualityEs = value
      } else if (type === 'Staffing') {
        this.staffingEs = value
      } else if (type === 'Invoices') {
        this.invoiceEs = value
      } else if (type === 'Risk') {
        this.riskEs = value
      } else if (type === 'Effort') {
        this.effortEs = value
      }
    },
    getWeekNumber(dt)
    {
      const tdt = new Date(dt.valueOf())

      const dayn = (dt.getDay() + 6) % 7

      tdt.setDate(tdt.getDate() - dayn + 3)
      const firstThursday = tdt.valueOf()

      tdt.setMonth(0, 1)
      if (tdt.getDay() !== 4)
      {
        tdt.setMonth(0, 1 + ((4 - tdt.getDay()) + 7) % 7)
      }

      return 1 + Math.ceil((firstThursday - tdt) / 604800000)
    },
    getEndOfWeek(date)
    {
      function pad(s) { return (s < 10) ? '0' + s : s }
      const d = new Date(date)

      return [pad(d.getDate()), pad(d.getMonth() + 1), d.getFullYear()].join('/')

    },
    async submitWSR () {

      const requestData = {
        'project_name' : this.selectedProject,
        'sch_cat_status' : this.scheduleId,
        'sch_cat_remark' : this.scheduleRemark,
        'qlt_cat_status' : this.qualityId,
        'qlt_cat_remark' : this.qualityRemark,
        'stf_cat_status' : this.staffingId,
        'stf_cat_remark' : this.staffingRemark,
        'inv_cat_status' : this.invoiceId,
        'inv_cat_remark' : this.invoiceRemark,
        'rsk_cat_status' : this.riskId,
        'rsk_cat_remark' : this.riskRemark,
        'eft_cat_status' : this.effortId,
        'eft_cat_remark' : this.effortRemark,
        'highlights_remark' : this.highRemark,
        'lowlights_remark' : this.lowRemark,
        'customer_happiness_remark' : this.customerRemark,
        'people_happiness_remark' : this.peopleRemark,
        'scheduleEs': this.scheduleEs,
        'qualityEs': this.qualityEs,
        'staffingEs': this.staffingEs,
        'invoiceEs': this.invoiceEs,
        'riskEs': this.riskEs,
        'effortEs': this.effortEs
      }

      await this.editWsrInfo({ id: this.$route.params.id, requestData })
      this.submitted = true
      const dialogData = this.getCustomDialog

      await this.setCustomDialog(dialogData)
    }
  }
}
</script>

<style scoped>
.switch-field {
	display: flex;
	overflow: hidden;
  align-items: center;
    justify-content: center;
}

.switch-field input {
	position: absolute !important;
	clip: rect(0, 0, 0, 0);
	height: 1px;
	width: 1px;
	border: 0;
	overflow: hidden;
}

.switch-field label {
	background-color: #fff;
	color: rgba(0, 0, 0, 0.6);
	font-size: 14px;
	line-height: 1;
	text-align: center;
	padding: 8px 16px;
	margin-right: -1px;
	border: 1px solid rgba(0, 0, 0, 0.2);
	transition: all 0.1s ease-in-out;
}

.switch-field label:hover {
	cursor: pointer;
}

.switch-field input:checked + label {
	background-color: #1976d2;
	box-shadow: none;
  color: #fff;
}
  button.btn {
    width: 100px;
    margin: 0 5px;
    padding: 6px 10px;
    border-radius: 40px;
    color: rgb(68 68 68 / 54%);
}

button.btn.green {
    background-color: rgb(0 255 60 / 32%) !important;
}

button.btn.amber {
    background-color: rgb(255 196 0 / 35%) !important;
}

button.btn.red {
    background-color: rgb(255 0 0 / 35%) !important;
}

button.activeGreen.btn.green {
    background-color: rgb(0 255 60) !important;
}

button.amber.activeAmber.btn {
    background-color: rgb(255 196 0) !important;
}

button.btn.red.activeRed {
    background-color: rgb(255 0 0) !important;
}

.wsrProjectSercOuter {
    display: flex;
    justify-content: space-between;
}

.wsrProjectWeekWrp {
    text-align: right;
    font-size: 18px;
    color: #7d7d7d;
    padding-right: 10px;
}

.wsrProjectWeekWrp span.week7 {
    display: inline-block;
    margin: 0 0 5px;
}

.wsrProjectWeekWrp p {
    margin: 0;
    color: rgb(68 68 68 / 33%);
}
</style>
