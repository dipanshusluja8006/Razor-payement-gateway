<template>
  <div>
    <v-row>
      <v-col cols="12" md="12" xl="12" class="dashboardHeading">
        <div class="wsrHeading">
          <h1>WSR Details</h1>
        </div>
        <div class="wsrProjectSercOuter">
          <div class="wsrProjectSerc mt-2">
            <label>Project Name</label>
            <v-text-field
              v-model="projectName"
              placeholder="Project Name"
              outlined
              readonly
              dense
            />
          </div>
          <div class="wsrProjectWeekWrp">
            <span class="week7"><b>Week</b> {{ week_no }}</span>
            <p><b>Ending Date:</b> <span>{{ week_end_date }}</span></p>
          </div>
        </div>
      </v-col>   
    </v-row>
    <div class="wsrTableWrp viewwsrTable">
      <v-row no-gutters>
        <v-data-table
          :headers="headers"
          :items="wsrItems"
          :hide-default-footer="true"
          style="width: 100%;"  
        >
          <template v-slot:item.category="{ item }">
            <span>
              {{ item.category.text }}
            </span>
          </template>
          <template v-slot:item.clientEscalation="{item}">
            <div class="switch-field">
              <input
                :id="item.category.radioOne"
                type="radio"
                :name="item.category.escalation"
                value="yes"
                :checked="item.clientEscliationValue === 1 ? true : false"
                :disabled="!checked"
              />
              <label :for="item.category.radioOne">Yes</label>
              <input 
                :id="item.category.radioTwo" 
                type="radio" 
                :name="item.category.escalation"
                value="no"
                :checked="item.clientEscliationValue === 0 ? true : false"
                :disabled="!checked"
              />
              <label :for="item.category.radioTwo">No</label>
            </div>
          </template>
          <template v-slot:item.status="{ item }">
            <div v-if="item.status.length > 0">
              <button v-if="item.selected===3" class="btn green activeGreen">Green</button>
              <button v-if="item.selected===2" class="btn amber activeAmber">Amber</button>
              <button v-if="item.selected===1" class="btn red activeRed">Red</button>
            </div>
          </template>
          <template v-slot:item.remark="props">
            <v-text-field
              v-model="props.item.remark"
              placeholder="Add Remarks"
              outlined
              readonly
              dense
              @input="addRemark(props.item.remark, props.item.id)"
            ></v-text-field>
          </template>
        </v-data-table>
      </v-row>
    </div>
    <v-card class="highlightsWrp">
      <v-row>
        <v-col cols="3" class="pb-0">
          <h4>Highlights</h4>
        </v-col>
        <v-col cols="9" class="pb-0">
          <v-textarea
            v-model="highRemark"
            placeholder="Add Remarks"
            outlined
            readonly
            dense
          ></v-textarea>
        </v-col>
        <v-col cols="3" class="pb-0 pt-1">
          <h4>Lowlights</h4>
        </v-col>
        <v-col cols="9" class="pb-0 pt-1">
          <v-textarea
            v-model="lowRemark"
            placeholder="Add Remarks"
            outlined
            readonly
            dense
          ></v-textarea>
        </v-col>
        <v-col cols="3" class="pb-0 pt-1">
          <h4>Customer Happiness</h4>
        </v-col>
        <v-col cols="9" class="pb-0 pt-1">
          <v-textarea
            v-model="customerRemark"
            placeholder="Add Remarks"
            outlined
            readonly
            dense
          ></v-textarea>
        </v-col>
        <v-col cols="3" class="pb-0 pt-1">
          <h4>People Happiness</h4>
        </v-col>
        <v-col cols="9" class="pb-0 pt-1">
          <v-textarea
            v-model="peopleRemark"
            placeholder="Add Remarks"
            outlined
            readonly
            dense
          ></v-textarea>
        </v-col>
      </v-row> 
      <div class="submitBtnWrp">
        <div class="submitDiv" cols="12">
          <v-btn
            class="backBtn"
            @click="$router.push('/wsr/wsr-list')"
          >
            <v-icon dark left>
              mdi-arrow-left
            </v-icon>Back
          </v-btn>
        </div>
      </div>
    </v-card>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import constant from '@/constants/closure-checklist'

export default {
  layout: 'default',
  middleware: 'authenticated',
  async fetch ({ store, route }) {
    // eslint-disable-next-line no-useless-catch
    try {
      await store.dispatch('AmPmDashboard/fetchWSRDetail', route.params.id)
    } catch (error) {
      throw (error)
    }
  },
  data () {
    return {
      selectedStatus: null,
      scheduleClient: null,
      qualityClient: null,
      staffingClient: null,
      highRemark: '',
      peopleRemark: '',
      customerRemark: '',
      lowRemark: '',
      projectName: '',
      week_no: null,
      week_end_date: null,
      headers: [
        { text: 'Category', value: 'category', sortable: false },
        { text: 'Client Escalation', value: 'clientEscalation', sortable: false },
        { text: 'Status', value: 'status', sortable: false },
        { text: 'Mitigation/Remarks', value: 'remark', sortable: false,  width: '35%' }
      ],
      status: constant.WSR_STATUS,
      categories: constant.WSR_CATEGORY,
      wsrItems: [],
      remark: '',
      clientEscliationValue:''
    }
  },
  computed: {
    ...mapGetters({
      getWSRDetail: 'AmPmDashboard/getWSRDetail'
    })
  },
  mounted() {
    this.projectName = this.getWSRDetail.project_name.project_name
    const { sch_cat_clt_esclation, qlt_cat_clt_esclation, stf_cat_clt_esclation, inv_cat_clt_esclation, rsk_cat_clt_esclation, eft_cat_clt_esclation } = this.getWSRDetail
    const { sch_cat_status, qlt_cat_status, stf_cat_status, inv_cat_status, rsk_cat_status, eft_cat_status } = this.getWSRDetail
    const { sch_cat_remark, qlt_cat_remark, stf_cat_remark, inv_cat_remark, rsk_cat_remark, eft_cat_remark } = this.getWSRDetail
    const { highlights_remark, customer_happiness_remark, lowlights_remark, people_happiness_remark,week_no,week_end_date } = this.getWSRDetail
    
    this.week_no = week_no
    this.week_end_date = this.getEndOfWeek(week_end_date)
    this.highRemark = highlights_remark
    this.customerRemark = customer_happiness_remark
    this.lowRemark = lowlights_remark
    this.peopleRemark =  people_happiness_remark
    this.categories.forEach((item) => {
      if (item.value === 1) {
        this.selectedStatus = sch_cat_status
        this.remark = sch_cat_remark
        this.clientEscliationValue = sch_cat_clt_esclation
      } else if (item.value === 2) {
        this.selectedStatus = qlt_cat_status
        this.remark = qlt_cat_remark
        this.clientEscliationValue = qlt_cat_clt_esclation
      } else if (item.value === 3) {
        this.selectedStatus = stf_cat_status
        this.remark = stf_cat_remark
        this.clientEscliationValue = stf_cat_clt_esclation
      } else if (item.value === 4) {
        this.selectedStatus = inv_cat_status
        this.remark = inv_cat_remark
        this.clientEscliationValue = inv_cat_clt_esclation
      } else if (item.value === 5) {
        this.selectedStatus = rsk_cat_status
        this.remark = rsk_cat_remark
        this.clientEscliationValue = rsk_cat_clt_esclation
      } else if (item.value === 6) {
        this.selectedStatus = eft_cat_status
        this.remark = eft_cat_remark
        this.clientEscliationValue = eft_cat_clt_esclation
      }
      this.wsrItems.push({
        category: item,
        status: this.status,
        remark: this.remark,
        clientEscliationValue: this.clientEscliationValue,
        id: item.value,
        selected: this.selectedStatus
      })
    })
  },
  methods: {
    getEndOfWeek(date)
    {
      function pad(s) { return (s < 10) ? '0' + s : s }
      const d = new Date(date)

      return [pad(d.getDate()), pad(d.getMonth() + 1), d.getFullYear()].join('/')
 
    },
    async submitWSR () {
      const requestData = {
        'project_id' : this.selectedProject,
        'sch_cat_status' : this.scheduleId,
        'sch_cat_remark' : this.scheduleRemark,
        'qlt_cat_status' : this.qualityId,
        'qlt_cat_remark' : this.qualityRemark,
        'stf_cat_status' : this.staffingId,
        'stf_cat_remark' : this.staffingRemark,
        'inv_cat_status' : this.invoiceId,
        'inv_cat_remark' : this.invoiceRemark,
        'rsk_cat_status' : this.riskId,
        'rsk_cat_remark' : this.riskRemark,
        'eft_cat_status' : this.effortId,
        'eft_cat_remark' : this.effortRemark,
        'highlights_remark' : this.highRemark,
        'lowlights_remark' : this.lowRemark,
        'customer_happiness_remark' : this.customerRemark,
        'people_happiness_remark' : this.peopleRemark,
        'scheduleEs': this.scheduleEs,
        'qualityEs': this.qualityEs,
        'staffingEs': this.staffingEs,
        'invoiceEs': this.invoiceEs,
        'riskEs': this.riskEs,
        'effortEs': this.effortEs
      }

      await this.addWsrInfo(requestData)
      this.submitted = true   
      const dialogData = this.getCustomDialog
 
      await this.setCustomDialog(dialogData)
    }
  }
}
</script>

<style scoped>
 .switch-field {
	display: flex;
	overflow: hidden;
  align-items: center;
    justify-content: center;
}

.switch-field input {
	position: absolute !important;
	clip: rect(0, 0, 0, 0);
	height: 1px;
	width: 1px;
	border: 0;
	overflow: hidden;
}

.switch-field label {
	background-color: #fff;
	color: rgba(0, 0, 0, 0.6);
	font-size: 14px;
	line-height: 1;
	text-align: center;
	padding: 8px 16px;
	margin-right: -1px;
	border: 1px solid rgba(0, 0, 0, 0.2);
	transition: all 0.1s ease-in-out;
}

.switch-field label:hover {
	cursor: pointer;
}

.switch-field input:checked + label {
	background-color: #1976d2;
	box-shadow: none;
  color: #fff;
}
  button.btn {
    width: 100px;
    margin: 0 5px;
    padding: 6px 10px;
    border-radius: 40px;
    color: rgb(68 68 68 / 54%);
}

button.btn.green {
    background-color: rgb(0 255 60 / 32%) !important;
}

button.btn.amber {
    background-color: rgb(255 196 0 / 35%) !important;
}

button.btn.red {
    background-color: rgb(255 0 0 / 35%) !important;
}

button.activeGreen.btn.green {
    background-color: rgb(0 255 60) !important;
}

button.amber.activeAmber.btn {
    background-color: rgb(255 196 0) !important;
}

button.btn.red.activeRed {
    background-color: rgb(255 0 0) !important;
}

.wsrProjectSercOuter {
    display: flex;
    justify-content: space-between;
}

.wsrProjectWeekWrp {
    text-align: right;
    font-size: 18px;
    color: #7d7d7d;
    padding-right: 10px;
}

.wsrProjectWeekWrp span.week7 {
    display: inline-block;
    margin: 0 0 5px;
}

.wsrProjectWeekWrp p {
    margin: 0;
    color: rgb(68 68 68 / 33%);
}
.wsrProjectSerc .theme--light.v-input .v-input__slot fieldset {
    border: 0;
}

</style>