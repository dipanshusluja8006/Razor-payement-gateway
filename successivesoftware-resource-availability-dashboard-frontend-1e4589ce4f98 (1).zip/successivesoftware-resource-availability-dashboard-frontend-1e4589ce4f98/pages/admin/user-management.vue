<template>
  <div>
    <v-row>
      <v-col cols="12" md="6" xl="6" class="dashboardHeading">
        <h1>User Management</h1>
      </v-col>
      <v-col cols="12">
        <v-data-table
          :headers="headers"
          :items="userManagementList"
          :items-per-page="5"
          :search="search"
          :sort-desc="false"
          :hide-default-footer="userManagementList.length ? false : true"
          class="h-full userManagmmentTbl"
        >
          <template v-slot:top>
            <div class="userSearchFWrp">
              <div class="searchFieldS">
                <v-text-field
                  v-model.trim="search"
                  append-icon="mdi-magnify"
                  label="Search"
                  outlined
                  rounded
                  clearable
                  dense
                  single-line
                  hide-details
                />
              </div>
              <div>
              </div></div></template>
          <template v-slot:item.role="{ item }">
            <div v-if="item.role.length > 0">
              <span
                v-for="(roleName, index) in item.role"
                :key="index"
                text-color="white"
                class="roleAvatarWrp"
              >
                <v-tooltip top>
                  <template v-slot:activator="{ on }">
                    <v-avatar
                      color="blue lighten-1"
                      size="30"
                      class="roleAvatar"
                      v-on="on"
                    >
                      <span class="white--text headline">{{ avatarNames(roleName) }}</span>
                    </v-avatar>
                  </template>
                  {{ roleName }}
                </v-tooltip>
              </span>
            </div>
            <div v-else>
              NA
            </div>
          </template>
          <template v-slot:item.action="{ item }">
            <v-img
              :src="viewIcon"
              class="quickAct"
              @click="viewProject(item)"
            />
            <v-img
              :src="editIcon"
              class="quickAct"
              @click="editProject(item)"
            />
          </template>
        </v-data-table>
      </v-col>
      <div class="text-center">
        <v-dialog v-model="showViewDialog" width="40%">
          <v-card>
            <admin-dialog :user-data="userRole" :title="'View User Role'" :show-btn="false" :action="action"/>
          </v-card>
        </v-dialog>
      </div>
      <div class="text-center">
        <v-dialog v-model="showEditDialog" width="40%">
          <v-card>
            <admin-dialog
              :user-data="userRole"
              :title="'Edit User Role'"
              :show-btn="true"
              :button-text="'Save'"
              :roles="editableRoles"
              :action="action"
            />
          </v-card>
        </v-dialog>
      </div>
    </v-row>
  </div>
</template>

<script>
import { mapActions, mapGetters } from 'vuex'
import { projectHelpers } from '@/helpers/helper.js'
import AdminDialog from '@/components/dialogs/AdminDialog.vue'
import constant from '../../constants/closure-checklist'

export default {
  components: { AdminDialog },
  layout: 'default',
  middleware: 'authenticated',
  async fetch ({ store }) {
    // eslint-disable-next-line no-useless-catch
    try {
      await store.dispatch('roles/fetchUserManagement')
      await store.dispatch('roles/fetchEditableRoles')
      await store.dispatch('roles/fetchGlobalRole')
    } catch (error) {
      throw (error)
    }
  },
  data () {
    return {
      headers: [
        { text: 'Name', value: 'name' },
        { text: 'Email', value: 'email' },
        { text: 'Role (s)', value: 'role' },
        { text: 'Department', value: 'department' },
        { text: 'Quick Actions', value: 'action', sortable: false }
      ],
      search:'',
      userManagementList: [],
      userRole: {},
      action: '',
      showViewDialog: false,
      showEditDialog: false,
      editableRoles: []
    }
  },
  computed: {
    ...mapGetters({
      getUserManagementList: 'roles/getUserManagementList',
      getEditableRoles: 'roles/getEditableRoles',
      departments: 'project/getDepartments'
    }),
    editIcon () {
      return require('@/assets/icons/Edit-pmo.png')
    },
    viewIcon () {
      return require('@/assets/icons/view-PMO.png')
    }
  },
  mounted() {
    if (this.departments.length === 0) {
      this.fetchDepartments()
    }
    const data = this.getUserManagementList

    data.forEach((element) => {
      const roles = []
      const defaultRoleNames = ['Employee']
      const globalRoleNames = []
      const assignedRoleNames = ['Employee']
      const deptIds = []
      const depts = []
      const roleIds = []
      let defaultRole = element.default_role
      let editRole = element.editable_role

      // Add Go Team Role
      const goDept = 'Global Operations'

      element.dept.forEach((dept) => {
        if (dept.name.replace(/\s+/g, '').toLowerCase() === goDept.replace(/\s+/g, '').toLowerCase()) {
          defaultRoleNames.push('GO Team')
          assignedRoleNames.push('GO Team')
        }
      })
      // fetch all departmentn IDs of a particular BU Head
      element.editable_role.forEach((item) => {
        if (item.role_id === constant.ROLE_ID.BU_HEAD) {
          let deptName = ''

          this.departments.forEach((dept) => {
            if (item.dept_id === dept.id) {
              deptName = dept.name
            }
          })
          depts.push({
            id: item.dept_id,
            name: deptName
          })
          deptIds.push(item.dept_id)
        }
      })
      defaultRole = [...new Map(defaultRole.map((item) => [item['role_id'], item])).values()]
      editRole =  [...new Map(editRole.map((item) => [item['role_id'], item])).values()]

      if (defaultRole) {
        defaultRole.forEach((item) => {
          item.role.type = 0
          roles.push(item.role)
        })
      }
      if (editRole) {
        editRole.forEach((item) => {
          item.role.type = 1
          roles.push(item.role)
          roleIds.push(item.role_id)
        })
      }
      // Separate Role Names
      roles.forEach((name) => {
        if (name.type === 0) {
          defaultRoleNames.push(name.role)
        } else {
          globalRoleNames.push(name.role)
        }
        assignedRoleNames.push(name.role)
      })
      this.userManagementList.push({
        name: element.full_name.trim(),
        email: element.email,
        id: element.id,
        department: element.dept[0] ? element.dept[0].name : 'NA',
        role: assignedRoleNames,
        all_roles: roles,
        defaultRole: defaultRoleNames,
        globalRole: globalRoleNames,
        deptIds,
        depts,
        editableRoleIds: roleIds
      })
    })
  },
  methods: {
    ...mapActions({
      sendTimeSheetReminder: 'dashboard/sendTimeSheetReminder',
      fetchDepartments: 'project/fetchDepartments'
    }),
    editProject (item) {
      this.editableRoles = []
      this.action = 'edit'
      this.getEditableRoles.forEach((value) => {
        value.flex = 4
        if (value.id === constant.ROLE_ID.BU_HEAD) {
          value.dept = item.depts
        } else {
          value.dept = []
        }
        this.editableRoles.push(value)
      })
      this.userRole = item
      this.showEditDialog = true
    },
    viewProject (item) {
      this.userRole = {}
      this.action = 'view'
      this.userRole = item
      this.showViewDialog = true
    },
    avatarNames (fullName) {
      fullName =  fullName.replace(/[^a-zA-Z]/g, ' ')

      return projectHelpers.avatarNames(fullName.trim())
    }
  }
}
</script>
<style scoped>
.v-image.v-responsive.quickAct.theme--light {
    display: inline-block;
    cursor: pointer;
    margin: 0 6px;
    width: 24px;
}
.v-image.v-responsive.quickAct.theme--light div {
    background-size: auto !important;
}

/* Card View */

.v-image.v-responsive.quickAct.theme--light {
    display: inline-block;
    padding: 6px 6px;
    cursor: pointer;
    margin: 0 2px;
}

.v-image.v-responsive.quickAct.theme--light .v-image__image.v-image__image--cover {
    background-size: auto;
}
.v-chip.v-size--default {
    font-size: smaller;
    height: auto;
}
.v-application .headline {
    font-size: 1rem !important;
    font-weight: 400;
    line-height: 2rem;
    letter-spacing: normal !important;
    font-family: "Open Sans", sans-serif !important;
}
</style>
