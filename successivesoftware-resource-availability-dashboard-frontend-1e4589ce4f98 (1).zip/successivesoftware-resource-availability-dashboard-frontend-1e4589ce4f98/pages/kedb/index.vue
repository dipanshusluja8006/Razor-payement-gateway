<template>
  <div>
    <Dialog />
    <common-snackbar :snackbar="snackbarValue" :text-for-snackbar="snackbarText" />
    <v-tabs
      v-model="tab"
    >
      <v-tabs-slider />
      <v-tab href="#tab-1" class="text-capitalize">
        New Known Error
      </v-tab>

      <v-tab href="#tab-2" class="text-capitalize">
        Known Error List
      </v-tab>
    </v-tabs>
    <v-tabs-items v-model="tab">
      <v-tab-item
        :value="'tab-1'"
      >
        <ValidationObserver ref="projectInitObserver" v-slot="{ valid }">
          <v-card
            class="mx-auto pt-2 pb-2"
            max-width="100%"
            rasied
          >
            <v-card-text>
              <v-row justify="center">
                <v-col
                  cols="12"
                  md="4"
                  class="pb-0"
                >
                  <v-autocomplete
                    v-model="selectedProjectName"
                    :items="kedbProjectList"
                    :search-input.sync="searchProjectName"
                    item-text="project_name"
                    item-value="uuid"
                    outlined
                    label="Project Name"
                    @change="searchProjectName=''"
                    @input="callRcaList"
                  />
                </v-col>
                <v-col
                  cols="12"
                  md="4"
                  class="pb-0"
                >
                  <v-autocomplete
                    v-show="showRcaDropdown"
                    v-model="selectedRCA"
                    :items="rcaList.map(rca => rca.number)"
                    :search-input.sync="searchRCA"
                    item-text="full_name"
                    item-value="id"
                    label="Select RCA"
                    outlined
                    @change="searchRCA=''"
                  />
                </v-col>
              </v-row>
              <v-row justify="center">
                <v-col
                  cols="12"
                  md="4"
                  class="pb-0"
                >
                  <ValidationProvider v-slot="{ errors }" :rules="'required|alpha_num_whitespace'" name="WorkaroundDesc">
                    <v-textarea
                      v-model.trim="WorkaroundDesc"
                      :error-messages="errors"
                      label="Description of Workaround *"
                      rows="1"
                      auto-grow
                      outlined
                    />
                  </ValidationProvider>
                </v-col>
                <v-col
                  cols="12"
                  md="4"
                  class="pb-0"
                >
                  <ValidationProvider v-slot="{ errors }" :rules="'required|alpha_num_whitespace'" name="kedbDescription">
                    <v-textarea
                      v-model.trim="kedbDescription"
                      :error-messages="errors"
                      label="Description of Known Error *"
                      rows="1"
                      auto-grow
                      outlined
                    />
                  </ValidationProvider>
                </v-col>
              </v-row>
              <v-row justify="center">
                <v-col
                  cols="12"
                  md="4"
                  class="pb-0"
                >
                  <ValidationProvider v-slot="{ errors }" :rules="'required'" name="selectedTags">
                    <v-autocomplete
                      v-model="selectedTags"
                      :filter="filter"
                      :hide-no-data="!searchTag"
                      :items="getKedbTags"
                      :error-messages="errors"
                      :search-input.sync="searchTag"
                      item-text="name"
                      item-value="id"
                      hide-selected
                      label="Select Tags *"
                      multiple
                      outlined
                      attach
                      auto-grow
                      @change="searchTag=''"
                      @keyup.enter="submitNewTag(searchTag)"
                    >
                      <template v-slot:no-data />
                      <template v-slot:prepend-item>
                        <v-list-item v-if="searchTag !== null && searchTag !== '' && !tagNameArray.includes(searchTag)">
                          <span class="subheading">Create</span>
                          <v-chip
                            color="teal lighten-3"
                            label
                            small
                            @click="createNewTag(searchTag)"
                          >
                            {{ searchTag }}
                          </v-chip>
                        </v-list-item>
                      </template>
                      <template v-slot:selection="{ attrs, item, parent, selected }">
                        <v-tooltip top>
                          <template v-slot:activator="{ on }">
                            <v-chip
                              v-if="item === Object(item)"
                              v-bind="attrs"
                              :input-value="selected"
                              color="blue lighten-3"
                              label
                              small
                              v-on="on"
                            >
                              <span class="pr-2">
                                {{ item.name.length >= 30? item.name.slice(0,30) + '...': item.name }}
                              </span>
                              <v-icon
                                small
                                @click="parent.selectItem(item)"
                              >
                                mdi-close
                              </v-icon>
                            </v-chip>
                          </template>
                          <span>{{ item.name }}</span>
                        </v-tooltip>
                      </template>
                      <template v-slot:item="{ item }">
                        <v-tooltip top>
                          <template v-slot:activator="{ on }">
                            <v-chip
                              color="blue lighten-3"
                              dark
                              label
                              small
                              v-on="on"
                            >
                              {{ item.name.length >= 30? item.name.slice(0,30) + '...': item.name }}
                            </v-chip>
                            <v-spacer />
                          </template>
                          <span>{{ item.name }}</span>
                        </v-tooltip>
                      </template>
                    </v-autocomplete>
                  </ValidationProvider>
                </v-col>
                <v-col
                  cols="12"
                  md="4"
                  class="pb-0"
                >
                  <ValidationProvider
                    v-slot="{ errors }"
                    :rules="'counter:3|ext:jpg,jpeg,png,pdf,docx,doc,xlsx,xls,zip'"
                    name="ext_field"
                    type="file"
                  >
                    <v-file-input
                      id="upload-file"
                      v-model="files"
                      :error-messages="errors"
                      :show-size="1000"
                      :persistent-hint="true"
                      color="primary"
                      counter="3"
                      label="Attachment(s)"
                      multiple
                      placeholder="Select your files"
                      prepend-icon="mdi-paperclip"
                      outlined
                      small-chips
                      hint="*File types must be in (jpg, jpeg, png, pdf, docx, doc, xlsx, xls, zip) only"
                      class="kedebAttchFiled"
                      @change="fileChange"
                      @click:clear="previousFiles = []"
                    >
                      <template v-slot:selection="data">
                        <v-chip
                          v-if="attachmentRemove"
                          close
                          @click:close="removeAttachmentFromArray(data.text, data.index)"
                        >
                          {{ data.text }}
                        </v-chip>
                      </template>
                    </v-file-input>
                  </ValidationProvider>
                </v-col>
              </v-row>
              <v-row align="center" justify="center">
                <v-col v-if="!valid" cols="12" class="text-center">
                  <v-btn
                    class="text-capitalize ma-2 white--text"
                    color="blue-grey"
                    @click="$router.push('/')"
                  >
                    <v-icon dark left>
                      mdi-arrow-left
                    </v-icon>Back
                  </v-btn>
                  <v-btn :disabled="!valid" class="text-capitalize" color="primary" @click="submit">
                    Submit
                  </v-btn>
                </v-col>
                <v-col v-else cols="12" class="text-center">
                  <v-btn
                    class="text-capitalize ma-2 white--text"
                    color="blue-grey"
                    @click="$router.push('/')"
                  >
                    <v-icon dark left>
                      mdi-arrow-left
                    </v-icon>Back
                  </v-btn>
                  <v-btn :disabled="submitted" class="text-capitalize" color="primary" @click="submit">
                    Submit
                  </v-btn>
                </v-col>
              </v-row>
            </v-card-text>
          </v-card>
        </ValidationObserver>
      </v-tab-item>
      <v-tab-item
        :value="'tab-2'"
      >
        <v-row align="center" justify="center" height="25px" max-width="100%" >
          <v-col cols="12">
            <v-data-table
              :headers="headers"
              :search="search"
              :custom-filter="customFilter"
              :items="kedbTableData"
              :hide-default-footer="kedbTableData.length ? false : true"
              max-width="100%"
              class="kedbTableWrp"
            >
              <template v-slot:top>
                <v-container fluid class="pa-0">
                  <v-row justify="end">
                    <v-col cols="3" class="pl-8 pb-6 ">
                      <div>
                        <v-menu :close-on-content-click="false" offset-y>
                          <template v-slot:activator="{ on, attrs }">
                            <v-btn
                              v-bind="attrs"
                              class="white grey--text mb-2 text-capitalize"
                              height="48px"
                              min-width="60%"
                              max-width="100%"
                              v-on="on"
                            >
                              <v-icon color="grey" dark left>
                                mdi-calendar-range
                              </v-icon> {{ anyDateText }}
                              <v-icon color="grey">
                                notranslate mdi mdi-chevron-down
                              </v-icon>
                            </v-btn>
                          </template>
                          <v-list class="pa-0 justify-center" width="320px" height="300px">
                            <v-row>
                              <v-col cols="6" class="ml-1 pa-2">
                                <v-card flat width="130px" class="ml-2 mt-2">
                                  <v-menu
                                    ref="fromDateMenu"
                                    v-model="fromDateMenu"
                                    :close-on-content-click="false"
                                    offset-y
                                    transition="scale-transition"
                                  >
                                    <template v-slot:activator="{ on }">
                                      <v-text-field
                                        slot="activator"
                                        v-model="fromDateString"
                                        label="From Date"
                                        prepend-icon="mdi-calendar"
                                        readonly
                                        v-on="on"
                                      />
                                    </template>
                                    <v-date-picker v-model="fromDatePicker" @change="changeFromDateString" @input="fromDateMenu = false" />
                                  </v-menu>
                                </v-card>
                              </v-col>
                              <v-col cols="5" class="pa-2">
                                <v-card flat width="130px" class="mt-2">
                                  <v-menu
                                    ref="toDateMenu"
                                    v-model="toDateMenu"
                                    :close-on-content-click="false"
                                    offset-y
                                    transition="scale-transition"
                                  >
                                    <template v-slot:activator="{ on }">
                                      <v-text-field
                                        v-model="toDateString"
                                        label="To Date"
                                        prepend-icon="mdi-calendar"
                                        readonly
                                        v-on="on"
                                      />
                                    </template>
                                    <v-date-picker
                                      v-model="toDatePicker"
                                      :min="fromDatePicker"
                                      :max="getEndDate"
                                      @change="changeToDateString"
                                      @input="toDateMenu = false"
                                    />
                                  </v-menu>
                                </v-card>
                              </v-col>
                            </v-row>
                            <v-divider />
                            <v-list-item class="pl-5" style="height: 50px;">
                              <v-list-item-action>
                                <v-btn
                                  :color="disabledToday"
                                  small
                                  width="240px"
                                  class="ma-2"
                                  outlined
                                  @click="todayDate"
                                >
                                  Today
                                </v-btn>
                              </v-list-item-action>
                            </v-list-item>
                            <v-list-item class="pl-5" style="height: 50px;">
                              <v-list-item-action>
                                <v-btn
                                  :color="disabledYesterday"
                                  small
                                  width="240px"
                                  class="ma-2"
                                  outlined
                                  @click="yesterdayDate"
                                >
                                  Yesterday
                                </v-btn>
                              </v-list-item-action>
                            </v-list-item>
                            <v-list-item class="pl-5" style="height: 50px;">
                              <v-list-item-action>
                                <v-btn
                                  :color="disabledPastMonth"
                                  small
                                  width="240px"
                                  class="ma-2"
                                  outlined
                                  @click="pastMonth"
                                >
                                  Past Month
                                </v-btn>
                              </v-list-item-action>
                            </v-list-item>
                            <v-list-item class="pl-5" style="height: 50px;">
                              <v-list-item-action>
                                <v-btn
                                  :color="disabledPastThreeMonths"
                                  small
                                  width="240px"
                                  class="ma-2"
                                  outlined
                                  @click="pastThreeMonths"
                                >
                                  Past 3 Months
                                </v-btn>
                              </v-list-item-action>
                            </v-list-item>
                          </v-list>
                        </v-menu>
                      </div>
                    </v-col>
                    <v-col cols="3">
                      <div class="pl-2 pr-4 pt-0">
                        <v-text-field
                          v-model="search"
                          append-icon="mdi-magnify"
                          label="Search"
                          solo
                          rounded
                          single-line
                          hide-details
                        />
                      </div>
                    </v-col>
                  </v-row>
                </v-container>
              </template>
              <template v-slot:body="{ items }">
                <tbody>
                  <tr v-for="item in items" :key="item.uuid" :class="{'selectedRow': item === selectedItem}" @click="viewDetails(item)">
                    <td>
                      <div style="text-align:center;">
                        <p>{{ item.number }}</p>
                      </div>
                    </td>
                    <v-tooltip max-width="250px" color="blue lighten-1" top>
                      <template v-slot:activator="{ on, attrs }">
                        <td v-bind="attrs" v-on="on">
                          <div style="text-align:center;">
                            <p>{{ item.description_of_workaround_substr }}</p>
                          </div>
                        </td>
                      </template>
                      <span>{{ item.description_of_workaround }}</span>
                    </v-tooltip>
                    <v-tooltip max-width="250px" color="blue lighten-1" top>
                      <template v-slot:activator="{ on, attrs }">
                        <td v-bind="attrs" v-on="on">
                          <div style="text-align:center;">
                            <p>{{ item.description_of_known_error_substr }}</p>
                          </div>
                        </td>
                      </template>
                      <span>{{ item.description_of_known_error }}</span>
                    </v-tooltip>
                    <td>
                      <div style="text-align:center;">
                        <v-chip
                          v-for="tag in item.tags"
                          :key="tag"
                          class="ma-2"
                          color="blue lighten-3"
                          text-color="black--text text--darken-1"
                        >
                          {{ tag }}
                        </v-chip>
                      </div>
                    </td>
                    <td>
                      <div style="text-align:center;">
                        {{ item.created_by.display_name }}
                      </div>
                    </td>
                    <td>
                      <div style="text-align:center;">
                        {{ new Date(item.created_at.substr(0,10)).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }) }}
                      </div>
                    </td>
                  </tr>
                </tbody>
              </template>
            </v-data-table>
          </v-col>
        </v-row>
      </v-tab-item>
    </v-tabs-items>
  </div>
</template>
<script>
import { mapActions, mapGetters } from 'vuex'
import constant from '@/constants/closure-checklist.js'
import CommonSnackbar from '@/components/CommonSnackbar'
import Dialog from '@/components/Dialog.vue'

export default {
  name: 'Index',
  components: { CommonSnackbar, Dialog },
  layout: 'authenticated',
  middleware: 'authenticated',
  async fetch ({ app, store }) {
    // eslint-disable-next-line no-useless-catch
    try {
      await Promise.all([
        store.dispatch('project/fetchKedbList'),
        store.dispatch('project/fetchKedbTags'),
        store.dispatch('project/fetchKedbProjectList')
      ])
    } catch (error) {
      throw (error)
    }
  },
  data () {
    return {
      search: '',
      dateFilter: false,
      fromDateMenu: false,
      fromDatePicker: null,
      toDatePicker: null,
      toDateMenu: false,
      fromDateString: new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
      toDateString: this.getInitialEndDate().formattedDate,
      searchRCA: '',
      searchProjectName: '',
      submitted: false,
      snackbarValue: false,
      snackbarText: '',
      tab: null,
      dialog: false,
      constant,
      inputDialog: false,
      projectId: null,
      projectRcaId: null,
      headers: [
        { text: 'Number', align: 'center', sortable: true, value: 'number' },
        { text: 'Workaround', align: 'center', width: '18%', value: 'description_of_workaround', sortable: false },
        { text: 'Known Error', align: 'center', width: '18%', sortable: false, value: 'description_of_known_error' },
        { text: 'Tags', align: 'center', value: 'tags', width: '20%', sortable: true },
        { text: 'Created By', align: 'center', width: '10%', value: 'created_by.display_name', sortable: true },
        { text: 'Created On', align: 'center', width: '10%', value: 'created_at', sortable: true, filter: this.datesFilter }
      ],
      selectedRCA: null,
      kedbNumber: '',
      projectNames: [],
      selectedProjectName: '',
      selectedTags: [],
      searchTag: null,
      kedbDescription: '',
      WorkaroundDesc: '',
      files: [],
      selectedItem: null,
      fav: true,
      menu: false,
      message: false,
      date: new Date(),
      attachments: [],
      form: new FormData(),
      tagSearched: false,
      attachmentRemove: true,
      kedbTableData: [],
      previousFiles: [],
      tagNameArray: [],
      disabledToday: 'blue lighten-1',
      disabledYesterday: 'blue lighten-1',
      disabledPastMonth: 'blue lighten-1',
      disabledPastThreeMonths: 'blue lighten-1',
      anyDateText: '  Any Date  ',
      showRcaDropdown: false
    }
  },
  computed: {
    ...mapGetters({
      kedbList: 'project/getKedbList',
      getGlobalRole: 'roles/getGlobalRole',
      getCustomDialog: 'project/getCustomDialog',
      currentUser: 'auth/user',
      getKedbTags: 'project/getKedbTags',
      kedbProjectList: 'project/getKedbProjectList',
      rcaList: 'project/getKedbRcaList',
      getCreatedAttachment: 'project/getCreatedAttachment'
    }),
    getEndDate () {
      const selectedDate = new Date(this.fromDatePicker)
      const endDate = new Date(selectedDate.getFullYear(), selectedDate.getMonth() + 6, selectedDate.getDate())

      return endDate.toISOString().slice(0, 10)
    }
  },
  mounted () {
    this.kedbProjectList.map((value) => {
      this.projectNames.push(value.project_name)
    })
    this.kedbList.map((value) => {
      this.kedbTableData.push({
        created_by: value.created_by,
        description_of_known_error: value.description_of_known_error,
        description_of_workaround: value.description_of_workaround,
        description_of_workaround_substr: (value.description_of_workaround.length < 40) ? value.description_of_workaround : value.description_of_workaround.substring(0, 40) + ' . . .',
        description_of_known_error_substr: (value.description_of_known_error.length < 40) ? value.description_of_known_error : value.description_of_known_error.substring(0, 40) + ' . . .',
        created_at: value.created_at,
        number: value.number,
        tags: value.tags.map((value) => value.name),
        uuid: value.uuid
      })
    })
    this.getKedbTags.forEach((item) => {
      this.tagNameArray.push(item.name)
    })
    if (this.getGlobalRole.length) {
      this.getGlobalRole.map((role) => {
        if (role.role_id === constant.ROLE_ID.ADMIN || role.role_id === constant.ROLE_ID.GLOBAL_OPERATION || role.role_id === constant.ROLE_ID.PROJECT_MANAGER || role.role_id === constant.ROLE_ID.ACCOUNT_MANAGER) {
          this.showRcaDropdown = true
        }
      })
    }
  },
  methods: {
    ...mapActions({
      fetchKedbList: 'project/fetchKedbList',
      fetchKedbRcaList: 'project/fetchKedbRcaList',
      setCustomDialog: 'project/setCustomDialog',
      updateLoadingAction: 'project/updateLoadingAction',
      createKedbTag: 'project/createKedbTag',
      setCreatedKedbData: 'project/setCreatedKedbData',
      uploadAttachmentData: 'project/uploadAttachmentData',
      setCreatedAttachment: 'project/setCreatedAttachment'
    }),
    removeAttachmentFromArray (text, ChipIndex) {
      this.files = this.files.filter((element, index) => index !== ChipIndex)
      this.previousFiles = []
    },
    filter (item, queryText, itemText) {
      const hasValue = (val) => val !== null ? val : ''

      const text = hasValue(itemText)
      const query = hasValue(queryText)

      return text.toString()
        .toLowerCase()
        .includes(query.toString().toLowerCase())
    },
    customFilter (items, search) {
      const hasValue = (val) => val !== null ? val : ''
      const text = hasValue(items)
      const query = hasValue(search)

      return text.toString()
        .toLowerCase()
        .includes(query.toString().toLowerCase())
    },
    async callRcaList () {
      this.projectId = this.selectedProjectName
      await this.fetchKedbRcaList(this.projectId)
    },
    changeFromDateString (selected) {
      this.fromDateString = new Date(selected).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      })
      if (this.fromDatePicker || this.toDatePicker) {
        this.anyDateText = this.fromDateString + ' - ' + this.toDateString
      }
      this.disabledToday = 'blue lighten-1'
      this.disabledYesterday = 'blue lighten-1'
      this.disabledPastMonth = 'blue lighten-1'
      this.disabledPastThreeMonths = 'blue lighten-1'
    },
    changeToDateString (selected) {
      this.toDateString = new Date(selected).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      })
      if (this.fromDatePicker || this.toDatePicker) {
        this.anyDateText = this.fromDateString + ' - ' + this.toDateString
      }
      this.disabledToday = 'blue lighten-1'
      this.disabledYesterday = 'blue lighten-1'
      this.disabledPastMonth = 'blue lighten-1'
      this.disabledPastThreeMonths = 'blue lighten-1'
    },
    todayDate () {
      const today = new Date().toISOString().substr(0, 10)

      this.fromDatePicker = today
      this.toDatePicker = today
      this.toDateString = new Date(today).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      })
      this.fromDateString = new Date(today).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      })
      this.anyDateText = this.fromDateString + ' - ' + this.toDateString
      this.disabledToday = 'orange'
      this.disabledYesterday = 'blue lighten-1'
      this.disabledPastMonth = 'blue lighten-1'
      this.disabledPastThreeMonths = 'blue lighten-1'
    },
    yesterdayDate () {
      let yesterday = new Date()

      yesterday.setDate(yesterday.getDate() - 1)
      yesterday = new Date(yesterday).toISOString().substr(0, 10)
      this.fromDatePicker = yesterday
      this.toDatePicker = yesterday
      this.toDateString = new Date(yesterday).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      })
      this.fromDateString = new Date(yesterday).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      })
      this.anyDateText = this.fromDateString + ' - ' + this.toDateString
      this.disabledToday = 'blue lighten-1'
      this.disabledPastMonth = 'blue lighten-1'
      this.disabledPastThreeMonths = 'blue lighten-1'
      this.disabledYesterday = 'orange'
    },
    pastMonth () {
      let prevStartDate = new Date(this.date.getFullYear(), this.date.getMonth() - 1, 1)

      prevStartDate = this.formatDate(prevStartDate)
      let preEndDate = new Date(this.date.getFullYear(), this.date.getMonth() - 1 + 1, 0)

      preEndDate = this.formatDate(preEndDate)
      this.fromDatePicker = prevStartDate
      this.toDatePicker = preEndDate
      this.toDateString = new Date(preEndDate).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      })
      this.fromDateString = new Date(prevStartDate).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      })
      this.anyDateText = this.fromDateString + ' - ' + this.toDateString
      this.disabledToday = 'blue lighten-1'
      this.disabledYesterday = 'blue lighten-1'
      this.disabledPastThreeMonths = 'blue lighten-1'
      this.disabledPastMonth = 'orange'
    },
    pastThreeMonths () {
      let prevStartDate = new Date(this.date.getFullYear(), this.date.getMonth() - 3, 1)

      prevStartDate = this.formatDate(prevStartDate)
      let preEndDate = new Date(this.date.getFullYear(), this.date.getMonth() - 1 + 1, 0)

      preEndDate = this.formatDate(preEndDate)
      this.fromDatePicker = prevStartDate
      this.toDatePicker = preEndDate
      this.toDateString = new Date(preEndDate).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      })
      this.fromDateString = new Date(prevStartDate).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      })
      this.anyDateText = this.fromDateString + ' - ' + this.toDateString
      this.disabledToday = 'blue lighten-1'
      this.disabledYesterday = 'blue lighten-1'
      this.disabledPastMonth = 'blue lighten-1'
      this.disabledPastThreeMonths = 'orange'
    },
    formatDate (date) {
      const d = new Date(date)
      let month = '' + (d.getMonth() + 1)
      let day = '' + d.getDate()
      const year = d.getFullYear()

      if (month.length < 2) { month = '0' + month }
      if (day.length < 2) { day = '0' + day }

      return [year, month, day].join('-')
    },
    /**
       * Filter for created on dates column.
       * @param value Value to be tested.
       * @returns {boolean}
       */
    datesFilter (value) {
      // If this filter has no value we just skip the entire filter.
      if (!this.fromDatePicker || !value || !this.toDatePicker) {
        return true
      }
      value = this.formatDate(value)
      if (value >= this.fromDatePicker && value <= this.toDatePicker) {
        return true
      }
    },
    fileChange () {
      this.files = this.previousFiles.concat(this.files)
      const key = 'name'

      this.files = this.files.map((e) => e[key]).map((e, i, final) => final.indexOf(e) === i && i).filter((e) => this.files[e]).map((e) => this.files[e])
      this.previousFiles = this.files
      const selectedFiles = this.files

      if (!selectedFiles.length) {
        return false
      }
      this.attachments = []
      for (let i = 0; i < selectedFiles.length; i++) {
        this.attachments.push(selectedFiles[i])
      }
    },
    async submit () {
      await this.updateLoadingAction()
      const selectedTagIds = []

      this.selectedTags.forEach((item) => (Number.isInteger(item)) ? selectedTagIds.push(item) : selectedTagIds.push(item.id))
      this.kedbProjectList.map((value) => {
        if (value.project_name === this.selectedProjectName) {
          this.projectId = value.uuid
        }
      })

      this.rcaList.map((value) => {
        if (value.number === this.selectedRCA) {
          this.projectRcaId = value.uuid
        }
      })
      for (let i = 0; i < this.attachments.length; i++) {
        this.form.append('attachments[]', this.attachments[i])
      }
      await this.uploadAttachmentData(this.form)
      const attachmentIds = []

      if (this.getCreatedAttachment.data) {
        this.getCreatedAttachment.data.map((value) => {
          attachmentIds.push(value.id)
        })
      }
      const requestData = {
        'project_id': this.projectId,
        'project_rca_id': this.projectRcaId,
        'tags': selectedTagIds,
        'description_of_known_error': this.kedbDescription,
        'description_of_workaround': this.WorkaroundDesc,
        'attachments': attachmentIds
      }

      await this.setCreatedKedbData(requestData)
      this.updateLoadingAction()
      this.submitted = true
    },
    getInitialEndDate () {
      const todaysDate = new Date()
      const endDate = new Date(Date.UTC(todaysDate.getFullYear(), todaysDate.getMonth() + 2, todaysDate.getDate()))
      const formattedDate = endDate.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })
      const formattedStringDate = endDate.toISOString().substr(0, 10)
      const maxDate = new Date(Date.UTC(todaysDate.getFullYear(), todaysDate.getMonth() + 6, todaysDate.getDate()))
        .toISOString().substr(0, 10)

      return { formattedDate, formattedStringDate, maxDate }
    },
    viewDetails (value) {
      this.selectedItem = value
      this.$router.push(`kedb/${value.uuid}/view-kedb`)
    },
    async submitNewTag (tagName) {
      if (tagName !== null && tagName !== '' && !this.tagNameArray.includes(tagName)) {
        await this.createKedbTag({ tagName })
        const createdTag = this.getKedbTags.filter((item) => item.name === tagName)

        this.selectedTags = this.selectedTags.concat(createdTag)
        this.searchTag = ''
        this.snackbarText = this.getCustomDialog.message
        this.snackbarValue = true
        this.tagNameArray = []
        this.getKedbTags.forEach((item) => {
          this.tagNameArray.push(item.name)
        })
        setTimeout(() => {
          this.snackbarValue = false
        }, 3000)
      }
    },
    async createNewTag (tagName) {
      const existingRecord = this.getKedbTags.filter((item) => item.name === tagName)

      if (existingRecord.length > 0) {
        this.snackbarText = 'Tag name is duplicate please try a different name!'
        this.snackbarValue = true
        setTimeout(() => {
          this.snackbarValue = false
        }, 3000)
      } else {
        await this.createKedbTag({ tagName })
        const createdTag = this.getKedbTags.filter((item) => item.name === tagName)

        this.selectedTags = this.selectedTags.concat(createdTag)
        this.searchTag = ''
        this.snackbarText = this.getCustomDialog.message
        this.snackbarValue = true
        this.tagNameArray = []
        this.getKedbTags.forEach((item) => {
          this.tagNameArray.push(item.name)
        })
        setTimeout(() => {
          this.snackbarValue = false
        }, 3000)
      }
    }
  }
}
</script>

<style scoped>
.v-data-table td, .v-data-table th {
    padding: 0 16px !important;
}
.selectedRow {
    background-color: #66b2ff;
    font-weight: bold;
}
.active {
  background: green;
}
.v-application .headline {
    font-size: medium !important;
    font-weight: 500;
    line-height: normal !important ;
}
.grow {
  padding: 5px 5px 5px 5px;
  border-radius: 10px;
  height: 49px;
  margin: 5px 1% 5px 1%;
  float: left;
  position: relative;
  transition: height 0.5s;
  -webkit-transition: height 0.5s;
  text-align: center;
  overflow: hidden;
}
.grow:hover {
  height: auto;
  background-color:  #91c5f8;
}
>>>.v-select.v-text-field input {
    flex: auto !important;
}
>>>.v-data-table-header {
    box-shadow: 0px 3px 1px -2px rgba(0, 0, 0, 0.2), 0px 2px 2px 0px rgba(0, 0, 0, 0.14), 0px 1px 5px 0px rgba(0, 0, 0, 0.12);
    color: white;
    border-radius: inherit;
  }
</style>
