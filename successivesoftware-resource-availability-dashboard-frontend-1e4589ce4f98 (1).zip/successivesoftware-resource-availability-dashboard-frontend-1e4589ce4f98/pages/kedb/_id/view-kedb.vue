<template>
  <div class="ma-1 pa-1">
    <v-card
      class="mx-auto"
      max-width="1000"
      rasied
    >
      <v-card-text>
        <v-row>
          <v-col
            cols="12"
            md="5"
            class="ml-5 mr-5 mt-5"
          >
            <v-text-field
              v-model.trim="kedbNumber"
              :class="{'v-text-field__slot' : kedbNumber}"
              label="Number "
              outlined
              disabled
            />
          </v-col>
          <v-col
            cols="12"
            md="5"
            class="ml-5 mr-5 mt-5"
          >
            <v-text-field
              v-model.trim="createdAt"
              :class="{'v-text-field__slot' : createdAt}"
              label="Time Stamp "
              outlined
              disabled
            />
          </v-col>
        </v-row>
        <v-row>
          <v-col
            cols="12"
            md="5"
            class="ml-5 mr-5"
          >
            <v-textarea
              v-model="selectedTags"
              :class="{'v-text-field__slot' : selectedTags}"
              rows="1"
              auto-grow
              outlined
              label="Tags"
              disabled
            />
          </v-col>
          <v-col
            cols="12"
            md="5"
            class="ml-5 mr-5"
          >
            <v-textarea
              v-model="createdBy"
              :class="{'v-text-field__slot' : createdBy}"
              rows="1"
              auto-grow
              outlined
              label="Created By"
              disabled
            />
          </v-col>
        </v-row>
        <v-row>
          <v-col
            cols="12"
            md="5"
            class="ml-5 mr-5"
          >
            <v-textarea
              v-model.trim="kedbDescription"
              :class="{'v-text-field__slot' : kedbDescription}"
              label="Description of Known Error"
              rows="1"
              auto-grow
              outlined
              disabled
            />
          </v-col>
          <v-col
            cols="12"
            md="5"
            class="ml-5 mr-5"
          >
            <v-textarea
              v-model.trim="WorkaroundDesc"
              :class="{'v-text-field__slot' : WorkaroundDesc}"
              label="Description of Workaround"
              rows="1"
              auto-grow
              outlined
              disabled
            />
          </v-col>
        </v-row>
        <v-row>
          <v-col
            cols="12"
            md="5"
            class="ml-5 mr-5 mb-5"
          >
            <label> Attachment(s) </label>
            <v-divider class="pa-1" />
            <v-btn
              v-for="item in attachement"
              :key="item.id"
              outlined
              color="blue lighten-1"
              class="ma-1"
              @click="downloadFiles(item)"
            >
              {{ item.name.length >= 20? item.name.slice(0,10) + '...': item.name }}
              <v-icon right dark>
                mdi-cloud-download
              </v-icon>
            </v-btn>
          </v-col>
        </v-row>
        <v-row align="end" justify="end">
          <v-col cols="12">
            <v-btn
              class="text-capitalize ma-2 white--text"
              color="blue-grey"
              @click="$router.push('/kedb')"
            >
              <v-icon dark left>
                mdi-arrow-left
              </v-icon>Back
            </v-btn>
          </v-col>
        </v-row>
      </v-card-text>
    </v-card>
  </div>
</template>
<script>
import { mapGetters, mapActions } from 'vuex'
export default {
  name: 'Index',
  layout: 'authenticated',
  middleware: 'authenticated',
  data () {
    return {
      selectedTags: [],
      kedbDescription: '',
      WorkaroundDesc: '',
      createdAt: null,
      createdBy: '',
      attachement: [],
      kedbNumber: '',
      attachementId: null,
      linkId: null
    }
  },
  computed: {
    ...mapGetters({
      kedbDetail: 'project/getKedbDetail'
    })
  },
  async fetch ({ app, store, route }) {
    // eslint-disable-next-line no-useless-catch
    try {
      await store.dispatch('project/fetchKedbDetail', route.params.id)
    } catch (error) {
      throw (error)
    }
  },
  mounted () {
    const tagArray = this.kedbDetail.tags.map(({ name, ...keepAttrs }) => name)
    const attachmentArray = []

    this.kedbDetail.attachment_mappings.map((value) => {
      attachmentArray.push(value.attachment)
      this.attachementId = value.attachment_id
      this.linkId = value.link_id
    })
    this.kedbNumber = this.kedbDetail.number
    let createdDate = new Date(this.kedbDetail.created_at)

    createdDate = createdDate.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })
    const createdTime = this.getInitialTime().formattedStringTime

    this.createdAt = createdDate + ' ' + createdTime
    this.selectedTags = tagArray
    this.createdBy = this.kedbDetail.created_by.display_name
    this.kedbDescription = this.kedbDetail.description_of_known_error
    this.WorkaroundDesc = this.kedbDetail.description_of_workaround
    this.attachement = attachmentArray
  },
  methods: {
    ...mapActions({
      downloadAttachment: 'project/downloadAttachment'
    }),
    getInitialTime () {
      const d = new Date()
      const hr = d.getHours()
      const min = d.getMinutes()
      const formattedTime = hr + ':' + min
      const formattedStringTime = this.tConvert(formattedTime)

      return { formattedTime, formattedStringTime }
    },
    tConvert (time) {
      // Check correct time format and split into components
      time = time.toString().match(/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [time]

      if (time.length > 1) { // If time format correct
        time = time.slice(1) // Remove full string match value
        time[5] = +time[0] < 12 ? ' AM ' : ' PM ' // Set AM/PM
        time[0] = +time[0] % 12 || 12 // Adjust hours
      }

      return time.join('') // return adjusted time or original string
    },
    async downloadFiles (download) {
      const requestData = {
        'id': download.id,
        'name': download.name
      }

      await this.downloadAttachment(requestData)
    }
  }
}
</script>

<style scoped>
.v-text-field__slot >>> .theme--light.v-label--is-disabled {
   color: rgba(0, 0, 0, 0.6);
   font-size: 18px
}

.theme--light.v-divider {
    border-color: rgba(0, 0, 0, 0.0);
}
</style>
