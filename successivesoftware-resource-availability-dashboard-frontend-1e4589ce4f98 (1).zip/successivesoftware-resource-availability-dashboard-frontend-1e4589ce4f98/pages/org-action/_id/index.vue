<template>
  <div class="projectDashboardWrp">
    <v-row class="mb-0">
      <v-col v-if="tabItems[currentTabIndex].id===1" cols="6" class="dashboardHeading ">
        <h1>Active Risks</h1>
      </v-col>
      <v-col v-if="tabItems[currentTabIndex].id===2" cols="6" class="dashboardHeading ">
        <h1>Projects At Risk</h1>
      </v-col>
      <v-col cols="6" class="text-right pb-1">
        <div class="exportBtnWrp">
          <v-btn
            class="exportBtn"
            small
            @click="exportExcelSheet"
          >
            Download Report <v-icon small>
              mdi-download
            </v-icon>
          </v-btn>
        </div>
      </v-col>
    </v-row>
    <div class="">
      <div class="addActionItemTabWrp">
        <v-tabs v-model="currentTabIndex" show-arrows>
          <v-tab
            v-for="item in tabItems"
            :key="item.id"
            class="text-capitalize"
          >
            {{ item.title }}
          </v-tab>
        </v-tabs>

        <div v-if="tabItems[currentTabIndex].id===1" class="addActionItmFilter">

          <v-autocomplete
            v-model="projectIds"
            :items="assignedProjectList"
            item-text="name"
            item-value="id"
            class="filtersFields"
            label="Project Name"
            outlined
            small-chips
            clearable
            dense
            multiple
            @change="projectNameFilter(projectIds)"
          >
            <template v-slot:selection="{ attrs, item, parent, selected, index }" class="slectedChilpSRWrp">
              <v-tooltip top>
                <template v-slot:activator="{ on }">
                  <v-chip
                    v-if="item === Object(item) && index === 0"
                    v-bind="attrs"
                    :input-value="selected"
                    label
                    small
                    v-on="on"
                  >
                    <span class="slectedChilpSR">
                      {{ item.name.length >= 47? item.name.slice(0,47) + '...': item.name }}
                    </span>
                    <v-icon
                      small
                      @click="parent.selectItem(item)"
                    >
                      mdi-close
                    </v-icon>
                  </v-chip>
                  <v-menu
                    bottom
                    origin="center center"
                    transition="scale-transition"
                  >
                    <template v-slot:activator="{ on }">
                      <v-btn
                        v-if="index === 1"
                        class="wsrMoreChilp"
                        outlined
                        rounded
                        fab
                        small
                        height="25"
                        width="25"
                        color="blue"
                        v-on="on"
                        @click="!false"
                      >
                        <v-icon x-small style="height: 10px; width: 10px">
                          mdi-plus
                        </v-icon>
                        {{ projectIds.length - 1 }}
                      </v-btn>
                    </template>
                    <v-card
                      v-show="!false"
                      class="mx-auto"
                      max-width="300"
                      raised
                    >
                      <v-list
                        v-if="selectedProjectList.length > 1"
                        disabled
                        shaped
                      >
                        <v-list-item-group
                          v-model="selectedProjectList"
                        >
                          <v-list-item
                            v-for="project in selectedProjectList.slice(1,selectedProjectList.length)"
                            v-show="!false"
                            :key="project.id"
                          >
                            <v-avatar
                              color="blue lighten-1"
                              size="30"
                              style="padding:4px"
                            >
                              <strong class="white--text headline">{{ avatarNames(project.name) }}</strong>
                            </v-avatar>
                            <v-list-item-content class="ml-2">
                              <v-list-item-title v-text="project.name" />
                            </v-list-item-content>
                          </v-list-item>
                        </v-list-item-group>
                      </v-list>
                    </v-card>
                  </v-menu>
                </template>
                <span>{{ item.name }}</span>
              </v-tooltip>
            </template>

          </v-autocomplete>

        </div>

        <div v-if="tabItems[currentTabIndex].id===2" class="addActionItmFilter">

          <v-autocomplete
            v-model="riskCategoryId"
            :items="getRiskCategoryArray"
            item-text="name"
            item-value="name"
            class="filtersFields"
            label="Risk Category"
            outlined
            small-chips
            dense
            multiple
            clearable
            @change="riskCategoryFilter(riskCategoryId)"
          >
            <template v-slot:selection="{ attrs, item, parent, selected, index }" class="slectedChilpSRWrp">
              <v-tooltip top>
                <template v-slot:activator="{ on }">
                  <v-chip
                    v-if="item === Object(item) && index === 0"
                    v-bind="attrs"
                    :input-value="selected"
                    label
                    small
                    v-on="on"
                  >
                    <span class="slectedChilpSR">
                      {{ item.name.length >= 47? item.name.slice(0,47) + '...': item.name }}
                    </span>
                    <v-icon
                      small
                      @click="parent.selectItem(item)"
                    >
                      mdi-close
                    </v-icon>
                  </v-chip>
                  <v-menu
                    bottom
                    origin="center center"
                    transition="scale-transition"
                  >
                    <template v-slot:activator="{ on }">
                      <v-btn
                        v-if="index === 1"
                        class="wsrMoreChilp"
                        outlined
                        rounded
                        fab
                        small
                        height="25"
                        width="25"
                        color="blue"
                        v-on="on"
                        @click="!false"
                      >
                        <v-icon x-small style="height: 10px; width: 10px">
                          mdi-plus
                        </v-icon>
                        {{ riskCategoryId.length - 1 }}
                      </v-btn>
                    </template>
                    <v-card
                      v-show="!false"
                      class="mx-auto"
                      max-width="300"
                      raised
                    >
                      <v-list
                        v-if="selectedriskCategoryIds.length > 1"
                        disabled
                        shaped
                      >
                        <v-list-item-group
                          v-model="selectedriskCategoryIds"
                        >
                          <v-list-item
                            v-for="project in selectedriskCategoryIds.slice(1,selectedriskCategoryIds.length)"
                            v-show="!false"
                            :key="project.name"
                          >
                            <v-avatar
                              color="blue lighten-1"
                              size="30"
                              style="padding:4px"
                            >
                              <strong class="white--text headline">{{ avatarNames(project.name) }}</strong>
                            </v-avatar>
                            <v-list-item-content class="ml-2">
                              <v-list-item-title v-text="project.name" />
                            </v-list-item-content>
                          </v-list-item>
                        </v-list-item-group>
                      </v-list>
                    </v-card>
                  </v-menu>
                </template>
                <span>{{ item.name }}</span>
              </v-tooltip>
            </template>
          </v-autocomplete>
          <v-autocomplete
            v-model="projectRiskIds"
            :items="assignedProjectList"
            item-text="name"
            item-value="id"
            class="filtersFields"
            label="Project Name"
            outlined
            small-chips
            dense
            multiple
            clearable
            @change="projectRiskNameFilter(projectRiskIds)"
          >
            <template v-slot:selection="{ attrs, item, parent, selected, index }" class="slectedChilpSRWrp">
              <v-tooltip top>
                <template v-slot:activator="{ on }">
                  <v-chip
                    v-if="item === Object(item) && index === 0"
                    v-bind="attrs"
                    :input-value="selected"
                    label
                    small
                    v-on="on"
                  >
                    <span class="slectedChilpSR">
                      {{ item.name.length >= 47? item.name.slice(0,47) + '...': item.name }}
                    </span>
                    <v-icon
                      small
                      @click="parent.selectItem(item)"
                    >
                      mdi-close
                    </v-icon>
                  </v-chip>
                  <v-menu
                    bottom
                    origin="center center"
                    transition="scale-transition"
                  >
                    <template v-slot:activator="{ on }">
                      <v-btn
                        v-if="index === 1"
                        class="wsrMoreChilp"
                        outlined
                        rounded
                        fab
                        small
                        height="25"
                        width="25"
                        color="blue"
                        v-on="on"
                        @click="!false"
                      >
                        <v-icon x-small style="height: 10px; width: 10px">
                          mdi-plus
                        </v-icon>
                        {{ projectRiskIds.length - 1 }}
                      </v-btn>
                    </template>
                    <v-card
                      v-show="!false"
                      class="mx-auto"
                      max-width="300"
                      raised
                    >
                      <v-list
                        v-if="selectedProjectRiskList.length > 1"
                        disabled
                        shaped
                      >
                        <v-list-item-group
                          v-model="selectedProjectRiskList"
                        >
                          <v-list-item
                            v-for="project in selectedProjectRiskList.slice(1,selectedProjectRiskList.length)"
                            v-show="!false"
                            :key="project.id"
                          >
                            <v-avatar
                              color="blue lighten-1"
                              size="30"
                              style="padding:4px"
                            >
                              <strong class="white--text headline">{{ avatarNames(project.name) }}</strong>
                            </v-avatar>
                            <v-list-item-content class="ml-2">
                              <v-list-item-title v-text="project.name" />
                            </v-list-item-content>
                          </v-list-item>
                        </v-list-item-group>
                      </v-list>
                    </v-card>
                  </v-menu>
                </template>
                <span>{{ item.name }}</span>
              </v-tooltip>
            </template>
          </v-autocomplete>
          <v-autocomplete
            v-model="assignToIds"
            :items="assignedPMUsers"
            item-text="name"
            item-value="id"
            class="filtersFields"
            label="PM Name"
            outlined
            small-chips
            dense
            multiple
            clearable
            @change="userNameFilter(assignToIds)"
          >
            <template v-slot:selection="{ attrs, item, parent, selected, index }" class="slectedChilpSRWrp">
              <v-tooltip top>
                <template v-slot:activator="{ on }">
                  <v-chip
                    v-if="item === Object(item) && index === 0"
                    v-bind="attrs"
                    :input-value="selected"
                    label
                    small
                    v-on="on"
                  >
                    <span class="slectedChilpSR">
                      {{ item.name.length >= 47? item.name.slice(0,47) + '...': item.name }}
                    </span>
                    <v-icon
                      small
                      @click="parent.selectItem(item)"
                    >
                      mdi-close
                    </v-icon>
                  </v-chip>
                  <v-menu
                    bottom
                    origin="center center"
                    transition="scale-transition"
                  >
                    <template v-slot:activator="{ on }">
                      <v-btn
                        v-if="index === 1"
                        class="wsrMoreChilp"
                        outlined
                        rounded
                        fab
                        small
                        height="25"
                        width="25"
                        color="blue"
                        v-on="on"
                        @click="!false"
                      >
                        <v-icon x-small style="height: 10px; width: 10px">
                          mdi-plus
                        </v-icon>
                        {{ assignToIds.length - 1 }}
                      </v-btn>
                    </template>
                    <v-card
                      v-show="!false"
                      class="mx-auto"
                      max-width="300"
                      raised
                    >
                      <v-list
                        v-if="selectedAssignId.length > 1"
                        disabled
                        shaped
                      >
                        <v-list-item-group
                          v-model="selectedAssignId"
                        >
                          <v-list-item
                            v-for="project in selectedAssignId.slice(1,selectedAssignId.length)"
                            v-show="!false"
                            :key="project.id"
                          >
                            <v-avatar
                              color="blue lighten-1"
                              size="30"
                              style="padding:4px"
                            >
                              <strong class="white--text headline">{{ avatarNames(project.name) }}</strong>
                            </v-avatar>
                            <v-list-item-content class="ml-2">
                              <v-list-item-title v-text="project.name" />
                            </v-list-item-content>
                          </v-list-item>
                        </v-list-item-group>
                      </v-list>
                    </v-card>
                  </v-menu>
                </template>
                <span>{{ item.name }}</span>
              </v-tooltip>
            </template>
          </v-autocomplete>
        </div>
      </div>

      <div v-if="tabItems[currentTabIndex].id === 1">
        <ActiveRisk :risk-details="riskDetails" />
      </div>
      <div v-else-if="tabItems[currentTabIndex].id === 2">
        <ProjectRisk :project-risk-details="projectRiskDetails"/>
      </div>
    </div>
  </div>
</template>
<script>
import { mapActions, mapGetters } from 'vuex'
import ActiveRisk from '../../../components/actionItem/ActiveRisk.vue'
import ProjectRisk from '../../../components/actionItem/ProjectRisk.vue'
import { excelSheet, projectHelpers } from '@/helpers/helper.js'

export default {
  name: 'Index',
  layout: 'authenticated',
  middleware: 'authenticated',
  components: {
    ActiveRisk,
    ProjectRisk
  },

  data() {
    return {

      projectIds: '',
      projectRiskIds:'',
      
      riskCategoryId:[],
      exportData: [],
      selectedAssignId:[],
      selectedriskCategoryIds: [],
      assignedProjectList: [],
      assignedRiskList:[],
      selectedProjectList:[],
      selectedProjectRiskList:[],
      assignToIds:'',
      projectNameArray:[],
      assignedPMUsers:[],
      currentTabIndex: 0,
      tabItems: [
        {
          id: 1,
          title: 'Active Risks'
        },
        {
          id: 2,
          title: 'Projects At Risk'
        }
      ],

      riskDetails: [],
      riskMainData: [],
      projectRiskDetails:[],
      assignedUsers:[],
      getRiskCategoryArray:[],
      getRiskCategoryArr:[]

    }
  },
  computed: {
    ...mapGetters({
      getAssignedUsers: 'AmPmDashboard/getAssignedUsers',
      getRiskData: 'AmPmDashboard/getRiskData',
      getProjectRiskData: 'AmPmDashboard/getProjectRiskData',
      getAssignedProjectList: 'AmPmDashboard/getAssignedProjectList',
      getRiskCategoryList: 'AmPmDashboard/getRiskCategoryList'
    })
  },
  watch: {

    riskItemList () {
      this.riskItemData = this.riskItemList
    },
    projectIds() {
      this.selectedProjectList = []
      this.projectIds.forEach((id) => {
        const domains = this.assignedProjectList.filter((item) => { return item.id === id })

        this.selectedProjectList.push(domains[0])
      })
    },
    projectRiskIds() {
      this.selectedProjectRiskList = []
      this.projectRiskIds.forEach((id) => {
        const domains = this.assignedProjectList.filter((item) => { return item.id === id })

        this.selectedProjectRiskList.push(domains[0])
      })
    },
    assignToIds() {
      this.selectedAssignId = []
      this.assignToIds.forEach((id) => {
        const domains = this.assignedPMUsers.filter((item) => { return item.id === id })

        this.selectedAssignId.push(domains[0])
      })
    },
    riskCategoryId() {
      this.selectedriskCategoryIds = []
      this.riskCategoryId.forEach((filterValue) => {
        const res = this.getRiskCategoryList.filter((item) => { return item.name === filterValue })

        this.selectedriskCategoryIds.push(res[0])
      })
    },
    getRiskCategoryList() {
      this.getRiskCategoryArray = this.getRiskCategoryList
    }
  },
  async fetch({ app, store, route }) {
    // eslint-disable-next-line no-useless-catch
    try {

      await store.dispatch('AmPmDashboard/fetchRisk')
      await store.dispatch('AmPmDashboard/fetchProjectRisk')
      await store.dispatch('AmPmDashboard/fetchAssignedUsers')
      await store.dispatch('AmPmDashboard/fetchAssignedProjectList')
      await store.dispatch('AmPmDashboard/fetchRiskCategories')
    } catch (error) {
      throw error
    }
  },
  mounted () {
    const paramId = this.$route.params.id

    this.getRiskCategoryArr = this.getRiskCategoryList
    this.getRiskCategoryArray = this.getRiskCategoryArr.shift()
   
    if (paramId === '2') {
      this.currentTabIndex = 1
    }

    this.mutateProjectList()
    this.exportData = this.riskDetails
    this.mutateAssignedUsers(this.getAssignedUsers)
    this.mutateProjectRiskList(this.getProjectRiskData)
    this.mutateAssignedProjectList(this.getAssignedProjectList)
  },
  methods: {

    assignedToValue(value) {
      if (value.risk_asssigned_to) {
        return value.risk_asssigned_to.display_name
      } else {
        return ''
      }
    },

    avatarNames (fullName) {

      return projectHelpers.avatarNames(fullName)
    },
    probabiltyData(value) {
      if (value.probability) {
        return value.probability.value
      } else {
        return ''
      }
    },
    impactData(value) {
      if (value.impact) {
        return value.impact.value
      } else {
        return ''
      }
    },
    categoryData(value) {
      if (value.risk_category) {
        return value.risk_category.value
      } else {
        return ''
      }
    },

    mutateAssignedProjectList (data) {
      if (data) {
        const filterListArray = []

        data.map((details) => {

          filterListArray.push({
            id: details.uuid,
            name: details.project_name

          })
        })
        this.assignedProjectList = filterListArray

      }
    },
    
    projectNameFilter(projectIds) {
      if (projectIds.length > 0 && !projectIds.includes(0)) {
        const projectData = []

        this.riskMainData.forEach((element) => {
          if (element.project_id !== null && projectIds.includes(element.project_id)) {
            projectData.push(element)
          }
        })
        this.riskDetails = projectData

      } else {
        this.riskDetails = this.riskMainData

      }
    },
    projectRiskNameFilter(projectRiskIds) {
      if (projectRiskIds.length > 0 && !projectRiskIds.includes(0)) {
        const projectRiskList = []

        this.projectRiskMainData.forEach((element) => {
          if (element.uuid !== null && projectRiskIds.includes(element.uuid)) {
            projectRiskList.push(element)
          }
        })
        this.projectRiskDetails = projectRiskList

      } else {
        this.projectRiskDetails = this.projectRiskMainData

      }
    },
    userNameFilter(assignToIds) {
      if (assignToIds.length > 0  && !assignToIds.includes(0)) {
        const projectData = []

        this.projectRiskMainData.forEach((element) => {
          if (element.project_managers.length > 0) {
            let flag = false

            element.project_managers.forEach((manager) => {
              if (assignToIds !== null && assignToIds.includes(manager.user_id)) {
                flag = true
              }
            })
            if (flag) {
              projectData.push(element)
            }
          }
        })
        this.projectRiskDetails = projectData
      } else {
        this.projectRiskDetails = this.projectRiskMainData
      }
    },
    riskCategoryFilter(riskCategoryId) {

      if (riskCategoryId.length > 0 && !riskCategoryId.includes(0)) {
      
        const projectRiskCategory = []

        this.projectRiskMainData.forEach((element) => {

          const categoryABC = element.risk_category

          if ( categoryABC !== null && categoryABC.length > 0) {
            let flag = false

            categoryABC.forEach((category) => {
              if (riskCategoryId.includes(category)) {
                flag = true
              }
            })
            if (flag) {
              projectRiskCategory.push(element)
            }

          }

        })
        this.projectRiskDetails = projectRiskCategory
      } else {
        this.projectRiskDetails = this.projectRiskMainData

      }
    },
    
    mutateAssignedUsers (data) {
      if (data) {
        const listArray = []

        data.map((details) => {
          if (details.user_role_local.length) {
            const userRoles = details.user_role_local
            const am = Object.values(userRoles).filter((item) => (item.role_id === 5 || item.role_id === 6))

            if (am.length) {
              listArray.push({
                id: details.user_id,
                name: details.full_name
              })
            }
          }
        })
        this.assignedPMUsers = listArray
      }
    },
    exportExcelSheet () {
      if (this.currentTabIndex === 0) {

        const risk = []

        this.riskDetails.forEach((riskDetail) => {

          risk.push({
            project_name: riskDetail.project_name,
            risk_number: riskDetail.risk_number,
            risk_index: riskDetail.risk_index,
            priority: riskDetail.priority_id,
            risk_category: riskDetail.risk_category,
            risk_description: riskDetail.risk_description.replace(/<\/?[^>]+>/gi, ' '),
            assigned_to: riskDetail.assigned_to,
            status: riskDetail.status
          })
        })

        const excelParams = {
          'sheetData': [risk],
          'headers': [['project_name','risk_number', 'risk_index', 'priority', 'risk_category', 'assigned_to', 'risk_description',  'status']],
          'sheetName': ['Active-Risk'],
          'fileName': 'Active Risks Report.xls'
        }

        excelSheet.createExcelSheet(excelParams)
      } else {

        const excleData = []

        this.projectRiskDetails.forEach((data) => {
          excleData.push({
            project_name: data.project_name,
            total_risk: data.total_risk,
            total_risk_index: data.totalRisk_index,
            risk_category: data.risk_category.join(),
            account_manager_name: data.account_manager_name,
            project_manager_name: data.project_manager_name,
            assignee_names: data.assignee_names
          })
        })
        const excelParams = {
          'sheetData': [excleData],
          'headers': [['project_name','total_risk', 'total_risk_index', 'risk_category','account_manager_name','project_manager_name', 'assignee_names']],
          'sheetName': ['Projects-At-Risk'],
          'fileName': 'Projects at Risk.xls'
        }

        excelSheet.createExcelSheet(excelParams)

      }

    },

    mutateProjectList () {
      const riskData = []

      if (this.getRiskData) {
        this.getRiskData.map((details) => {
          const riskObj = details.project_risk

          riskObj.forEach((riskDetail) => {

            riskData.push({
              project_name: details.project_name,
              risk_number: riskDetail.id,
              risk_index: parseFloat(this.probabiltyData(riskDetail) * this.impactData(riskDetail)).toFixed(2),
              priority_id: riskDetail.priority_id === 1 ? 'Low' : riskDetail.priority_id === 2 ? 'Normal' : riskDetail.priority_id === 3 ? ('High') : riskDetail.priority_id === 4 ? ('Blocker') : 'Immediate',
              risk_category: this.categoryData(riskDetail),
              due_date: riskDetail.due_date,
              risk_subject: riskDetail.subject,
              risk_description: riskDetail.description.replace(/<\/?[^>]+>/gi, ' '),
              assigned_to: this.assignedToValue(riskDetail),
              status:riskDetail.status_id === 1 ? 'To Do' : ((riskDetail.status_id === 2) ? ('In Progress') : ('Complete')),
              project_id: details.uuid

            })
          })
        })
        this.riskDetails = riskData
        this.riskMainData = riskData
      }
    },
    mutateProjectRiskList () {
      const projectRiskData = []
      const projectNameData = []

      if (this.getProjectRiskData) {
        this.getProjectRiskData.map((data) => {
          const projectRiskAssigneeName = []
          const projectRiskCategoryName = []
          const { simplifiedArray: { assigned_id } } = data
          const assigneeDetails = assigned_id
          const { simplifiedArray: { category_to_id } } = data
          const riskCategory = category_to_id
          const assigneeData = []
          const riskCategoryData = []

          projectNameData.push({
            id: data.uuid,
            name: data.project_name
          })

          if ((riskCategory) && riskCategory.length > 0) {

            riskCategory.forEach((category) => {
              const categoryRisk = riskCategoryData.filter((value) => (value.name === category.name))

              if (categoryRisk.length === 0) {
                projectRiskCategoryName.push(category.name)
                riskCategoryData.push({
                  id: category.id,
                  name:category.name
                })
              }
            })
          }

          if  ((assigneeDetails) && assigneeDetails.length > 0) {
            assigneeDetails.forEach((nav) => {

              const results = assigneeData.filter((value) => (value.id === nav.id))

              if (results.length === 0) {
                projectRiskAssigneeName.push(nav.name)
                assigneeData.push({
                  id: nav.id,
                  name:nav.name
                })
              }
            })
          }

          projectRiskData.push({
            uuid:data.uuid,
            project_riskId: data.redmine_project_id,
            project_name: data.project_name,
            total_risk: data.simplifiedArray.count,
            totalRisk_index: data.simplifiedArray.risk_sum,
            risk_category: projectRiskCategoryName,
            assignee_risk: assigneeDetails,
            account_managers:  data.account_managers,
            project_managers: data.project_managers,
            assignee_names_array: assigneeData,
            account_manager_name: this.createNamesForExcle(data.account_managers),
            project_manager_name: this.createNamesForExcle(data.project_managers),
            assignee_names: projectRiskAssigneeName.join()
          })
        })
        this.projectNameArray = projectNameData
        this.projectRiskDetails = projectRiskData
        this.projectRiskMainData = this.projectRiskDetails
      }
    },
    createNamesForExcle (data) {
      const name =  []

      if (data.length > 0) {
        data.forEach((item) => {
          name.push(item.user.display_name)
        })
      }

      return name.join()

    }

  }
}
</script>
<style scoped>
.projectDtopBar {
  background-color: rgb(246 247 249 / 42%);
  padding: 40px 0 30px;
  margin-bottom: 0 !important;
}
.projectDataWrp table tbody tr td:nth-child(2) {
    color: #9c9898;
    line-height: 22px;
}
</style>
