<template>
  <div>
    <v-row class="mb-0">
      <v-col v-if="tabItems[currentTabIndex].id===1" cols="6" class="dashboardHeading ">
        <h1>My Action Item</h1>
      </v-col>
      <v-col v-if="tabItems[currentTabIndex].id===2" cols="6" class="dashboardHeading ">
        <h1>Assigned Action Item</h1>
      </v-col>
      <v-col v-if="tabItems[currentTabIndex].id===3" cols="6" class="dashboardHeading ">
        <h1>Add Action Item</h1>
      </v-col>
      <v-col v-if="tabItems[currentTabIndex].id != 3" cols="6" class="text-right pb-1">
        <div class="exportBtnWrp">
          <v-btn
            class="exportBtn"
            small
            @click="exportExcelSheet"
          >
            Download Report <v-icon small>
              mdi-download
            </v-icon>
          </v-btn>
        </div>
      </v-col>
    </v-row>
    <div class="">
      <div class="addActionItemTabWrp">
        <v-tabs v-model="currentTabIndex" show-arrows>
          <v-tab
            v-for="item in tabItems"
            :key="item.id"
            class="text-capitalize"
          >
            {{ item.title }}
          </v-tab>
        </v-tabs>
        <div v-if="tabItems[currentTabIndex].id===1" class="addActionItmFilter">
          <v-text-field
            v-model="mySearch"
            append-icon="mdi-magnify"
            label="Search"
            outlined
            rounded
            dense
            class="filtersFields"
            single-line
            hide-details
          />
          <v-autocomplete
            v-model="myItemProjectIds"
            :items="projectNameArray"
            item-text="name"
            item-value="id"
            class="filtersFields"
            label="Project Name"
            outlined
            small-chips
            dense
            multiple
            @change="myItemProjectFilter(myItemProjectIds)"
          >
            <template v-slot:selection="{ attrs, item, parent, selected, index }" class="slectedChilpSRWrp">
              <v-tooltip top>
                <template v-slot:activator="{ on }">
                  <v-chip
                    v-if="item === Object(item) && index === 0"
                    v-bind="attrs"
                    :input-value="selected"
                    label
                    small
                    v-on="on"
                  >
                    <span class="slectedChilpSR">
                      {{ item.name.length >= 47? item.name.slice(0,47) + '...': item.name }}
                    </span>
                    <v-icon
                      small
                      @click="parent.selectItem(item)"
                    >
                      mdi-close
                    </v-icon>
                  </v-chip>
                  <v-menu
                    bottom
                    origin="center center"
                    transition="scale-transition"
                  >
                    <template v-slot:activator="{ on }">
                      <v-btn
                        v-if="index === 1"
                        class="wsrMoreChilp"
                        outlined
                        rounded
                        fab
                        small
                        height="25"
                        width="25"
                        color="blue"
                        v-on="on"
                        @click="!false"
                      >
                        <v-icon x-small style="height: 10px; width: 10px">
                          mdi-plus
                        </v-icon>
                        {{ myItemProjectIds.length - 1 }}
                      </v-btn>
                    </template>
                    <v-card
                      v-show="!false"
                      class="mx-auto"
                      max-width="300"
                      raised
                    >
                      <v-list
                        v-if="selectedProjectItem.length > 1"
                        disabled
                        shaped
                      >
                        <v-list-item-group
                          v-model="selectedProjectItem"
                        >
                          <v-list-item
                            v-for="project in selectedProjectItem.slice(1,selectedProjectItem.length)"
                            v-show="!false"
                            :key="project.id"
                          >
                            <v-avatar
                              color="blue lighten-1"
                              size="30"
                              style="padding:4px"
                            >
                              <strong class="white--text headline">{{ avatarNames(project.name) }}</strong>
                            </v-avatar>
                            <v-list-item-content class="ml-2">
                              <v-list-item-title v-text="project.name" />
                            </v-list-item-content>
                          </v-list-item>
                        </v-list-item-group>
                      </v-list>
                    </v-card>
                  </v-menu>
                </template>
                <span>{{ item.name }}</span>
              </v-tooltip>
            </template>

          </v-autocomplete>
        </div>
        <div v-if="tabItems[currentTabIndex].id===2" class="addActionItmFilter">
          <v-text-field
            v-model="searchData"
            append-icon="mdi-magnify"
            label="Search"
            outlined
            rounded
            dense
            class="filtersFields"
            single-line
            hide-details
          />
          <v-autocomplete
            v-model="assignToIds"
            :items="assignedUsers"
            item-text="name"
            item-value="id"
            class="filtersFields"
            label="Resource name"
            outlined
            small-chips
            dense
            multiple
            @change="userNameFilter(assignToIds)"
          >
            <template v-slot:selection="{ attrs, item, parent, selected, index }" class="slectedChilpSRWrp">
              <v-tooltip top>
                <template v-slot:activator="{ on }">
                  <v-chip
                    v-if="item === Object(item) && index === 0"
                    v-bind="attrs"
                    :input-value="selected"
                    label
                    small
                    v-on="on"
                  >
                    <span class="slectedChilpSR">
                      {{ item.name.length >= 47? item.name.slice(0,47) + '...': item.name }}
                    </span>
                    <v-icon
                      small
                      @click="parent.selectItem(item)"
                    >
                      mdi-close
                    </v-icon>
                  </v-chip>
                  <v-menu
                    bottom
                    origin="center center"
                    transition="scale-transition"
                  >
                    <template v-slot:activator="{ on }">
                      <v-btn
                        v-if="index === 1"
                        class="wsrMoreChilp"
                        outlined
                        rounded
                        fab
                        small
                        height="25"
                        width="25"
                        color="blue"
                        v-on="on"
                        @click="!false"
                      >
                        <v-icon x-small style="height: 10px; width: 10px">
                          mdi-plus
                        </v-icon>
                        {{ assignToIds.length - 1 }}
                      </v-btn>
                    </template>
                    <v-card
                      v-show="!false"
                      class="mx-auto"
                      max-width="300"
                      raised
                    >
                      <v-list
                        v-if="selectedAssignId.length > 1"
                        disabled
                        shaped
                      >
                        <v-list-item-group
                          v-model="selectedAssignId"
                        >
                          <v-list-item
                            v-for="project in selectedAssignId.slice(1,selectedAssignId.length)"
                            v-show="!false"
                            :key="project.id"
                          >
                            <v-avatar
                              color="blue lighten-1"
                              size="30"
                              style="padding:4px"
                            >
                              <strong class="white--text headline">{{ avatarNames(project.name) }}</strong>
                            </v-avatar>
                            <v-list-item-content class="ml-2">
                              <v-list-item-title v-text="project.name" />
                            </v-list-item-content>
                          </v-list-item>
                        </v-list-item-group>
                      </v-list>
                    </v-card>
                  </v-menu>
                </template>
                <span>{{ item.name }}</span>
              </v-tooltip>
            </template>
          </v-autocomplete>
          <v-autocomplete
            v-model="projectIds"
            :items="projectNameArray"
            item-text="name"
            item-value="id"
            class="filtersFields"
            label="Project Name"
            outlined
            small-chips
            dense
            multiple
            @change="projectNameFilter(projectIds)"
          >
            <template v-slot:selection="{ attrs, item, parent, selected, index }" class="slectedChilpSRWrp">
              <v-tooltip top>
                <template v-slot:activator="{ on }">
                  <v-chip
                    v-if="item === Object(item) && index === 0"
                    v-bind="attrs"
                    :input-value="selected"
                    label
                    small
                    v-on="on"
                  >
                    <span class="slectedChilpSR">
                      {{ item.name.length >= 47? item.name.slice(0,47) + '...': item.name }}
                    </span>
                    <v-icon
                      small
                      @click="parent.selectItem(item)"
                    >
                      mdi-close
                    </v-icon>
                  </v-chip>
                  <v-menu
                    bottom
                    origin="center center"
                    transition="scale-transition"
                  >
                    <template v-slot:activator="{ on }">
                      <v-btn
                        v-if="index === 1"
                        class="wsrMoreChilp"
                        outlined
                        rounded
                        fab
                        small
                        height="25"
                        width="25"
                        color="blue"
                        v-on="on"
                        @click="!false"
                      >
                        <v-icon x-small style="height: 10px; width: 10px">
                          mdi-plus
                        </v-icon>
                        {{ projectIds.length - 1 }}
                      </v-btn>
                    </template>
                    <v-card
                      v-show="!false"
                      class="mx-auto"
                      max-width="300"
                      raised
                    >
                      <v-list
                        v-if="selectedProjectData.length > 1"
                        disabled
                        shaped
                      >
                        <v-list-item-group
                          v-model="selectedProjectData"
                        >
                          <v-list-item
                            v-for="project in selectedProjectData.slice(1,selectedProjectData.length)"
                            v-show="!false"
                            :key="project.id"
                          >
                            <v-avatar
                              color="blue lighten-1"
                              size="30"
                              style="padding:4px"
                            >
                              <strong class="white--text headline">{{ avatarNames(project.name) }}</strong>
                            </v-avatar>
                            <v-list-item-content class="ml-2">
                              <v-list-item-title v-text="project.name" />
                            </v-list-item-content>
                          </v-list-item>
                        </v-list-item-group>
                      </v-list>
                    </v-card>
                  </v-menu>
                </template>
                <span>{{ item.name }}</span>
              </v-tooltip>
            </template></v-autocomplete>
        </div>
      </div>
      <div v-if="tabItems[currentTabIndex].id === 1">
        <MyItem :my-item-list="myActionItemData" :search-data="mySearch" />
      </div>
      <div v-else-if="tabItems[currentTabIndex].id === 2">
        <AssignedItem :pending-item-list="mutateAssignedActionData" :search-data="searchData" />
      </div>
      <div v-else>
        <AddItem :assigned-user-data="assignedUsers" :assigned-project-data="projectNameArray"/>
      </div>
    </div>
  </div>
</template>

<script>
import { mapActions, mapGetters } from 'vuex'
import AddItem from '../../../components/actionItem/AddItem.vue'
import MyItem from '../../../components/actionItem/MyItem.vue'
import AssignedItem from '../../../components/actionItem/AssignedItem.vue'
import constant from '@/constants/closure-checklist.js'
import { excelSheet, projectHelpers } from '@/helpers/helper.js'
export default {
  name: 'ActionItem',
  layout: 'authenticated',
  middleware: 'authenticated',
  components: {
    MyItem,
    AssignedItem,
    AddItem
  },
  async fetch ({ store, route }) {
    // eslint-disable-next-line no-useless-catch
    try {
      await Promise.all([
        store.dispatch('AmPmDashboard/fetchAssignedUsers'),
        store.dispatch('project/fetchProjectNameListing'),
        store.dispatch('AmPmDashboard/fetchAssignedActionList'),
        store.dispatch('AmPmDashboard/fetchMyActionItemList')
      ])
    } catch (error) {
      throw (error)
    }
  },

  data() {
    return {
      mySearch: '',
      projectIds:'',
      assignToIds:'',
      projectList:[],
      selectedProjectData:[],
      selectedProjectItem:[],
      selectedAssignId:[],
      assignedItemList: [],
      myItemProjectIds: [],
      myItemList: [],
      searchData: '',
      mutateAssignedActionData: [],
      myActionItemData: [],
      fetchProjectNames: [],
      projectNameArray: [],
      assignedUsers: [],
      currentTabIndex: 0,
      tabItems: [
        {
          id: 1,
          title: 'My Action Item'
        },
        {
          id: 2,
          title: 'Assigned Action Item'
        },
        {
          id: 3,
          title: 'Add Action Item'
        }
      ]
    }
  },
  computed: {
    ...mapGetters({
      getAssignedUsers: 'AmPmDashboard/getAssignedUsers',
      getProjectNames: 'project/getProjectNameListing',
      getAssignedActionList: 'AmPmDashboard/getAssignedActionList',
      getMyActionItemList: 'AmPmDashboard/getMyActionItemList'
    })
  },
  watch: {
    getMyActionItemList () {
      this.mutateMyActionItems(this.getMyActionItemList)
    },
    projectIds () {
      this.selectedProjectData = []
      this.projectIds.forEach((id) => {
        const domains = this.projectNameArray.filter((item) => { return item.id === id })

        this.selectedProjectData.push(domains[0])
      })
    },
    myItemProjectIds () {
      this.selectedProjectItem = []
      this.myItemProjectIds.forEach((id) => {
        const domains = this.projectNameArray.filter((item) => { return item.id === id })

        this.selectedProjectItem.push(domains[0])
      })
    },
    assignToIds() {
      this.selectedAssignId = []
      this.assignToIds.forEach((id) => {
        const domains = this.assignedUsers.filter((item) => { return item.id === id })

        this.selectedAssignId.push(domains[0])
      })
    }
  },

  mounted () {
    const paramId = this.$route.params.id

    if (paramId === '3') {
      this.currentTabIndex = 2
    }
    this.mutateProjectNameList(this.getProjectNames)
    this.mutateAssignedUsers(this.getAssignedUsers)
    this.mutateAssignedActionList(this.getAssignedActionList)
    this.mutateMyActionItems(this.getMyActionItemList)
  },

  methods: {
    mutateProjectNameList (data) {
      if (data) {
        const filterListArray = []

        data.map((details) => {

          filterListArray.push({
            id: details.uuid,
            name: details.project_name
          })
        })
        this.projectNameArray = filterListArray
      }
    },
    avatarNames (fullName) {

      return projectHelpers.avatarNames(fullName)
    },

    mutateMyActionItems (data) {
      if (data) {
        const mutateData = []

        data.map((details) => {
          mutateData.push({
            uuid: details.uuid,
            project_id: details.project_id,
            project: (details.project_name) ? details.project_name.project_name : '',
            priority: this.mapItemsPriority(details.priority),
            target_closure_date: projectHelpers.listDateFormat(details.target_closure_date),
            description: details.description,
            statusId: details.status,
            status: this.mapItemsStatus(details.status)
          }
          )
        })
        this.myItemList = mutateData
        this.myActionItemData = this.myItemList
      }
    },
    mutateAssignedActionList (data) {
      if (data) {
        const mutateData = []

        data.map((details) => {
          mutateData.push({
            uuid: details.uuid,
            project_id: details.project_id,
            project: (details.project_name) ? details.project_name.project_name : '',
            priority: this.mapItemsPriority(details.priority),
            target_closure_date: projectHelpers.listDateFormat(details.target_closure_date),
            description: details.description,
            statusId: details.status,
            status: this.mapItemsStatus(details.status),
            assign_to: details.assigned_to_user.display_name,
            assign_to_id: details.assigned_to_user.id,
            assign_on:projectHelpers.listDateFormat(details.created_at)
          }
          )
        })
        this.assignedItemList = mutateData
        this.mutateAssignedActionData = this.assignedItemList
      }
    },
    exportExcelSheet () {
      if (this.currentTabIndex === 0) {
        const excleData = []

        this.myActionItemData.forEach((details) => {
          excleData.push({
            project_name: details.project,
            priority: details.priority,
            target_closure_date: details.target_closure_date,
            description: details.description,
            status: details.status

          })
        })
        const excelParams = {
          'sheetData': [excleData],
          'headers': [['project_name','priority', 'target_closure_date',  'description', 'status']],
          'sheetName': ['My-Action-Item'],
          'fileName': 'my-action-item.xls'
        }

        excelSheet.createExcelSheet(excelParams)
      } else {

        const excleData = []

        this.mutateAssignedActionData.forEach((details) => {
          excleData.push({
            project_name: details.project,
            priority: details.priority,
            target_closure_date: details.target_closure_date,
            description: details.description,
            status: details.status,
            assign_to: details.assign_to,
            assign_on: details.assign_on
          })
        })
        const excelParams = {
          'sheetData': [excleData],
          'headers': [['project_name','priority', 'assign_to', 'assign_on', 'target_closure_date',  'description', 'status']],
          'sheetName': ['Assigned-Action-Item'],
          'fileName': 'assigned-action-item.xls'
        }

        excelSheet.createExcelSheet(excelParams)

      }
    },
    mutateAssignedUsers (data) {
      if (data) {
        const listArray = []

        data.map((details) => {
          listArray.push({
            id: details.user_id,
            name: details.full_name
          })
        })
        this.assignedUsers = listArray
      }
    },
    mapItemsPriority (value) {
      if (value === constant.PENDING_ACTION_ITEM_PRIORITY.HIGH) {
        return 'High'
      }
      else if (value === constant.PENDING_ACTION_ITEM_PRIORITY.MEDIUM) {
        return 'Medium'
      }
      else {
        return 'Low'
      }
    },
    mapItemsStatus (value) {
      if (value === constant.PENDING_ACTION_ITEM_STATUS.TODO) {
        return 'ToDo'
      }
      else {
        return 'Done'
      }
    },

    /**
     * Global Filter Method
     * @param projectIds
     */
    myItemProjectFilter(myItemProjectIds) {
      if (myItemProjectIds.length > 0) {
        const projectData = []

        this.myItemList.forEach((element) => {
          if (element.project_id !== null && myItemProjectIds.includes(element.project_id)) {
            projectData.push(element)
          }
        })
        this.myActionItemData = projectData
      } else {
        this.myActionItemData = this.myItemList
      }
    },
    /**
     * Global Filter Method
     * @param projectIds
     */
    projectNameFilter(projectIds) {
      if (projectIds.length > 0) {
        const projectData = []

        this.assignedItemList.forEach((element) => {
          if (element.project_id !== null && projectIds.includes(element.project_id)) {
            projectData.push(element)
          }
        })
        this.mutateAssignedActionData = projectData
      } else {
        this.mutateAssignedActionData = this.assignedItemList
      }
    },
    /**
     * Global Filter Method
     * @param projectIds
     */
    userNameFilter(userIds) {
      if (userIds.length > 0 && !userIds.includes(0)) {
        const projectData = []

        this.assignedItemList.forEach((element) => {
          if (element.assign_to_id !== null && userIds.includes(element.assign_to_id)) {
            projectData.push(element)
          }
        })
        this.mutateAssignedActionData = projectData
      } else {
        this.mutateAssignedActionData = this.assignedItemList
      }
    }
  }
}
</script>
