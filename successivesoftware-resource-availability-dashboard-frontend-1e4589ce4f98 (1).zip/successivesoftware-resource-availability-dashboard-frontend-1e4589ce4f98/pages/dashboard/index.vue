/* eslint-disable no-unreachable */
<template>
  <div id="dashboard">

    <project-manager />

  </div>

</template>
<script>
import { mapActions, mapGetters } from 'vuex'
import constant from '@/constants/closure-checklist.js'
import { excelSheet } from '@/helpers/helper.js'
import ProjectManager from '@/components/pmDashboard/ProjectManager.vue'

export default {
  name: 'Index',
  components: { ProjectManager },
  layout: 'authenticated',
  middleware: 'authenticated',

  data () {

    return {
    }
  },

  computed: {
    ...mapGetters({
    })
  },
  watch: {

  },
  mounted () {

    this.showChart = true
  },
  methods: {

  }

}

</script>
