<template>
  <div>
    <v-card class="text-center pa-1">
      <v-card-title class="justify-center display-1 mb-2">
        Welcome
      </v-card-title>
      <v-card-subtitle>Sign in to your account</v-card-subtitle>

      <v-card-text>
        <v-form ref="form">
          <v-btn
            v-for="provider in providers"
            :key="provider.id"
            :loading="provider.isLoading"
            :disabled="isSignInDisabled"
            class="mb-2 primary lighten-2 primary--text text--darken-3"
            block
            x-large
            @click="loginWithGoogle"
          >
            <v-icon small left>
              mdi-{{ provider.id }}
            </v-icon>
            {{ provider.label }}
          </v-btn>
          <common-snackbar :snackbar="snackbarValue" :text-for-snackbar="snackbarText" />
          <v-custom-overlay :show="showOverlayLoading" />
        </v-form>
      </v-card-text>
    </v-card>
  </div>
</template>
<script>
/*
|---------------------------------------------------------------------
| Sign In Page Component
|---------------------------------------------------------------------
|
| Sign in template for user authentication into the application
|
*/
import firebase from 'firebase/app'
import { mapActions, mapGetters } from 'vuex'
import CommonSnackbar from '@/components/CommonSnackbar'
import VCustomOverlay from '@/components/Overlay'

export default {
  layout: 'auth',
  components: { CommonSnackbar, VCustomOverlay },
  data () {
    return {
      snackbarValue: false,
      isLoading: false,
      isSignInDisabled: false,
      snackbarText: 'You are not authorized to view this.',
      providers: [{
        id: 'google',
        label: 'Google',
        isLoading: false
      }]
    }
  },
  computed: {
    ...mapGetters({
      showOverlayLoading: 'project/getOverlayLoading',
      product: 'theme/product'
    }),
    iconSrc () {
      return require('@/assets/images/illustrations/signin-illustration.svg')
    }
  },
  methods: {
    ...mapActions({
      updateAuthentication: 'auth/updateAuthentication',
      setUser: 'auth/setUserDetails',
      setUserToken: 'auth/setUserToken'
    }),
    loginWithGoogle () {
      this.snackbarValue = false
      this.isLoading = true
      this.isSignInDisabled = true
      const provider = new firebase.auth.GoogleAuthProvider()

      firebase.auth().signInWithPopup(provider).then((result) => {
        // The signed-in user info.
        const user = {
          username: result.user.displayName,
          email: result.user.email,
          userToken: result.credential.idToken
        }

        if (!(user.email.includes('successive.tech') ||
          user.email.includes('successivesoftwares.com'))) {
          this.snackbarValue = true
        } else {
          this.setUser(user)
          this.updateAuthentication(true)
          this.$router.push('/')
        }
      })
    },
    created () {
      this.updateAuthentication(false)
    }
  }
}
</script>
