<template>
  <div>
    <v-card
      class="mx-auto"
      max-width="1000"
      rasied
    >
      <v-card-text>
        <v-row>
          <v-col
            cols="12"
            md="6"
            class="mt-5"
          >
            <v-text-field
              v-model.trim="projectName"
              :class="{'v-text-field__slot' : projectName}"
              label="Project Name"
              outlined
              style="width:400px"
              disabled
            />
          </v-col>
        </v-row>
        <v-row no-gutters>
          <v-col
            cols="12"
            md="6"
            class="mt-5"
          >
            <label> When the issue was reported first? * </label>
          </v-col>
          <v-col
            cols="12"
            md="6"
            class="mt-5"
          >
            <label> When the first action for reported issue(s) took place? * </label>
          </v-col>
        </v-row>
        <v-row no-gutters>
          <v-col cols="2" class="ma-1 mt-2">
            <v-text-field
              slot="activator"
              v-model="issueReportedDateString"
              :class="{'v-text-field__slot' : issueReportedDateString}"
              label="Select Date"
              prepend-icon="mdi-calendar"
              disabled
            />
          </v-col>
          <v-col cols="2" class="ma-1 mt-2">
            <v-text-field
              v-model="issueReportedTime"
              :class="{'v-text-field__slot' : issueReportedTime}"
              prepend-icon="mdi-av-timer"
              label="Select Time"
              disabled
            />
          </v-col>
          <v-col cols="2" class="ma-1" />
          <v-col cols="2" class="ma-1 mt-2">
            <v-text-field
              slot="activator"
              v-model="actionDateString"
              :class="{'v-text-field__slot' : actionDateString}"
              label="Select Date"
              prepend-icon="mdi-calendar"
              disabled
            />
          </v-col>
          <v-col cols="2" class="ma-1 mt-2">
            <v-text-field
              v-model="actionTime"
              :class="{'v-text-field__slot' : actionTime}"
              prepend-icon="mdi-av-timer"
              label="Select Time"
              disabled
            />
          </v-col>
        </v-row>
        <v-row>
          <v-col
            cols="12"
            md="6"
            class="mt-5"
          >
            <v-textarea
              v-model.trim="issueDescription"
              :class="{'v-text-field__slot' : issueDescription}"
              label="What was the issue? *"
              rows="1"
              auto-grow
              style="width:400px"
              outlined
              disabled
            />
          </v-col>
          <v-col
            cols="12"
            md="6"
            class="mt-5"
          >
            <label>Who was the reporter of the issue(s)? *</label>
            <v-radio-group v-model="reporterOfIssue" :mandatory="false" class="mt-1" disabled>
              <v-radio
                v-for="(reporter, index) in rcaReporterUsers"
                :key="index"
                :label="reporter.name"
                :value="reporter.id"
                class="ml-2"
              />
            </v-radio-group>
          </v-col>
        </v-row>
        <v-row>
          <v-col
            cols="12"
            md="6"
            class="mt-5"
          >
            <v-textarea
              v-model.trim="resolveIssueDescription"
              :class="{'v-text-field__slot' : resolveIssueDescription}"
              label="What did we do to resolve the issue(s)? *"
              rows="1"
              auto-grow
              style="width:400px"
              outlined
              disabled
            />
          </v-col>
          <v-col
            cols="12"
            md="6"
            class="mt-5"
          >
            <v-textarea
              v-model.trim="fixIssueDescription"
              :class="{'v-text-field__slot' : fixIssueDescription}"
              label="How much time it took to fix the issue? *"
              rows="1"
              auto-grow
              style="width:400px"
              outlined
              disabled
            />
          </v-col>
        </v-row>
        <v-row>
          <v-col
            cols="12"
            md="6"
            class="mt-5"
          >
            <v-textarea
              v-model.trim="preventDescription"
              :class="{'v-text-field__slot' : preventDescription}"
              label="What to do in order to prevent the issue(s) in future? *"
              rows="1"
              auto-grow
              style="width:400px"
              outlined
              disabled
            />
          </v-col>
          <v-col
            cols="12"
            md="6"
            class="mt-5"
          >
            <label>What is the priority of the issue? *</label>
            <v-radio-group v-model="priorityOfIssue" :mandatory="false" class="mt-1" disabled>
              <v-radio
                v-for="(priority, index) in prioritiesOfIssue"
                :key="index"
                :label="priority.name"
                :value="priority.id"
                class="ml-2"
              />
            </v-radio-group>
          </v-col>
        </v-row>
        <v-row>
          <v-col
            cols="12"
            md="6"
            class="mt-5"
          >
            <v-textarea
              v-model="selectedFixer"
              :class="{'v-text-field__slot' : selectedFixer}"
              rows="1"
              auto-grow
              outlined
              style="width:400px"
              disabled
              attach
              chips
              label="Who fixed the issue(s) i.e. one team member or all? *"
            />
          </v-col>
          <v-col
            cols="12"
            md="6"
            class="mt-5"
          >
            <label> Attachment(s) </label>
            <v-divider />
            <v-btn
              v-for="item in attachement"
              :key="item.id"
              outlined
              color="blue lighten-1"
              class="ma-1"
              @click="downloadFiles(item)"
            >
              {{ item.name.length >= 20? item.name.slice(0,10) + '...': item.name }}
              <v-icon right dark>
                mdi-cloud-download
              </v-icon>
            </v-btn>
          </v-col>
        </v-row>
        <v-row align="end" justify="end">
          <v-col cols="12">
            <v-btn
              class="text-capitalize ma-2 white--text"
              color="blue-grey"
              @click="back"
            >
              <v-icon dark left>
                mdi-arrow-left
              </v-icon>Back
            </v-btn>
          </v-col>
        </v-row>
      </v-card-text>
    </v-card>
  </div>
</template>
<script>
import { mapGetters, mapActions } from 'vuex'
export default {
  name: 'Index',
  layout: 'authenticated',
  middleware: 'authenticated',
  data () {
    return {
      issueReportedDateString: null,
      issueReportedTime: null,
      actionDateString: null,
      actionTime: null,
      reporterOfIssue: 1,
      resolveIssueDescription: '',
      fixIssueDescription: '',
      priorityOfIssue: 1,
      selectedFixer: [],
      rcaNumbers: [],
      projectName: '',
      issueDescription: '',
      selectedItem: null,
      prioritiesOfIssue: [
        {
          'id': 1,
          'name': 'Low'
        },
        {
          'id': 2,
          'name': 'Medium'
        },
        {
          'id': 3,
          'name': 'High'
        }
      ],
      preventDescription: '',
      attachement: [],
      attachementId: null
    }
  },
  computed: {
    ...mapGetters({
      rcaDetail: 'project/getRcaDetail',
      rcaReporterUsers: 'project/getRcaReporterUsers',
      users: 'project/getUserList',
      projectDetail: 'project/getProjectDetail'
    })
  },
  async fetch ({ app, store, route }) {
    // eslint-disable-next-line no-useless-catch
    try {
      await Promise.all([
        store.dispatch('project/fetchProjectDetail', route.params.id),
        store.dispatch('project/fetchRcaDetail', route.params.id),
        store.dispatch('project/fetchRcaReporterUsers')
      ])
    } catch (error) {
      throw (error)
    }
  },
  mounted () {
    this.$nuxt.$emit('headerTitle', 'RCA')
    const attachmentArray = []
    const fixedByUsers = []

    if (this.rcaDetail) {
      this.rcaDetail.fixed_by_users.map((value) => {
        fixedByUsers.push(value.user.display_name)
      })
      this.rcaDetail.attachment_mappings.map((value) => {
        attachmentArray.push(value.attachment)
        this.attachementId = value.attachment_id
        this.linkId = value.link_id
      })
    }
    const issueReportedDate = new Date(this.rcaDetail.date_of_issue_reported_first).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    })
    const actionTakenDate = new Date(this.rcaDetail.date_of_action_reported_first).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    })
    const reportedTime = new Date(this.rcaDetail.date_of_issue_reported_first).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true })
    const actionTakenTime = new Date(this.rcaDetail.date_of_action_reported_first).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true })

    this.projectName = this.projectDetail.project_name
    this.issueDescription = this.rcaDetail.issue_detail
    this.issueReportedDateString = issueReportedDate
    this.actionDateString = actionTakenDate
    this.issueReportedTime = reportedTime
    this.actionTime = actionTakenTime
    this.reporterOfIssue = this.rcaDetail.issue_reported_by
    this.resolveIssueDescription = this.rcaDetail.resolve_issue_type
    this.fixIssueDescription = this.rcaDetail.time_taken_to_fix
    this.priorityOfIssue = this.rcaDetail.issue_priority
    this.selectedFixer = fixedByUsers
    this.preventDescription = this.rcaDetail.prevent_for_future
    this.attachement = attachmentArray
  },
  methods: {
    ...mapActions({
      downloadAttachment: 'project/downloadAttachment',
      fetchProjectDetail: 'project/fetchProjectDetail'
    }),
    async downloadFiles (download) {
      const requestData = {
        'id': download.id,
        'name': download.name
      }

      await this.downloadAttachment(requestData)
    },
    formatDate (date) {
      const d = new Date(date)
      let month = '' + (d.getMonth() + 1)
      let day = '' + d.getDate()
      const year = d.getFullYear()

      if (month.length < 2) { month = '0' + month }
      if (day.length < 2) { day = '0' + day }

      return [year, month, day].join('-')
    },
    back () {
      this.$router.push(`/rca/${this.rcaDetail.project_id}/`)
    }
  }
}
</script>
<style scoped>
.v-text-field__slot >>> .theme--light.v-label--is-disabled {
   color: rgba(0, 0, 0, 0.6);
   font-size: 18px
}
.theme--light.v-divider {
    border-color: rgba(0, 0, 0, 0.0);
}
</style>
