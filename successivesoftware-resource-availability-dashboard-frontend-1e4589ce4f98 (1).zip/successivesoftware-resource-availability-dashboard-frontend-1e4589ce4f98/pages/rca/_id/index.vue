<template>
  <div>
    <Dialog />
    <v-card outlined class="ma-1 pa-2">
      <common-snackbar :snackbar="snackbarValue" :text-for-snackbar="snackbarText" />
      <v-tabs
        v-model="tab"
      >
        <v-tabs-slider />
        <v-tab href="#tab-1" class="text-capitalize">
          New RCA
        </v-tab>

        <v-tab href="#tab-2" class="text-capitalize">
          RCA List
        </v-tab>
      </v-tabs>
      <v-tabs-items v-model="tab">
        <v-tab-item
          :value="'tab-1'"
        >
          <ValidationObserver ref="projectInitObserver" v-slot="{ valid }">
            <v-card
              class="mx-auto"
              max-width="1000"
              rasied
              style="margin: 30px 0;"
            >
              <v-card-text>
                <v-row>
                  <v-col
                    cols="12"
                    md="6"
                    class="mt-5"
                  >
                    <v-text-field
                      v-model.trim="projectName"
                      label="Project Name"
                      outlined
                      readonly
                      style="width:400px"
                    />
                  </v-col>
                </v-row>
                <v-row no-gutters>
                  <v-col
                    cols="12"
                    md="6"
                    class="mt-5"
                  >
                    <label> When the issue was reported first? * </label>
                  </v-col>
                  <v-col
                    cols="12"
                    md="6"
                    class="mt-5"
                  >
                    <label> When the first action for reported issue(s) took place? * </label>
                  </v-col>
                </v-row>
                <v-row no-gutters>
                  <v-col cols="2" class="ma-1 mt-2">
                    <v-menu
                      ref="dateMenu"
                      v-model="issueReportedDateMenu"
                      :close-on-content-click="false"
                      offset-y
                      transition="scale-transition"
                    >
                      <template v-slot:activator="{ on }">
                        <v-text-field
                          slot="activator"
                          v-model="issueReportedDateString"
                          label="Select Date"
                          prepend-icon="mdi-calendar"
                          readonly
                          v-on="on"
                        />
                      </template>
                      <v-date-picker id="1" v-model="issueReportedDatePicker" @change="changeIssueDateString" @input="issueReportedDateMenu = false" />
                    </v-menu>
                  </v-col>
                  <v-col cols="2" class="ma-1 mt-2">
                    <v-menu
                      ref="menu"
                      v-model="issueReportedTimeMenu"
                      :close-on-content-click="false"
                      :nudge-right="40"
                      transition="scale-transition"
                      offset-y
                      max-width="290px"
                      min-width="290px"
                    >
                      <template v-slot:activator="{ on }">
                        <v-text-field
                          v-model="issueReportedTimeString"
                          prepend-icon="mdi-av-timer"
                          label="Select Time"
                          readonly
                          v-on="on"
                        />
                      </template>
                      <v-time-picker
                        v-if="issueReportedTimeMenu"
                        v-model="issueReportedTime"
                        :format="format"
                        :value="format"
                        full-width
                        @change="changeIssueTimeString"
                        @click:minute="$refs.menu.save(issueReportedTime)"
                      />
                    </v-menu>
                  </v-col>
                  <v-col cols="2" class="ma-1" />
                  <v-col cols="2" class="ma-1">
                    <v-menu
                      ref="dateMenu"
                      v-model="actionDateMenu"
                      :close-on-content-click="false"
                      offset-y
                      transition="scale-transition"
                    >
                      <template v-slot:activator="{ on }">
                        <v-text-field
                          slot="activator"
                          v-model="actionDateString"
                          label="Select Date"
                          prepend-icon="mdi-calendar"
                          readonly
                          v-on="on"
                        />
                      </template>
                      <v-date-picker
                        id="2"
                        v-model="actionDatePicker"
                        :min="issueReportedDatePicker"
                        @change="changeActionDateString"
                        @input="actionDateMenu = false"
                      />
                    </v-menu>
                  </v-col>
                  <v-col cols="2" class="ma-1">
                    <v-menu
                      ref="menu1"
                      v-model="actionTimeMenu"
                      :close-on-content-click="false"
                      :nudge-right="40"
                      transition="scale-transition"
                      offset-y
                      max-width="290px"
                      min-width="290px"
                    >
                      <template v-slot:activator="{ on }">
                        <v-text-field
                          v-model="actionReportedTimeString"
                          prepend-icon="mdi-av-timer"
                          label="Select Time"
                          readonly
                          v-on="on"
                        />
                      </template>
                      <v-time-picker
                        v-if="actionTimeMenu"
                        v-model="actionTime"
                        :format="format"
                        full-width
                        @change="changeActionTimeString"
                        @click:minute="$refs.menu1.save(actionTime)"
                      />
                    </v-menu>
                  </v-col>
                </v-row>
                <v-row>
                  <v-col
                    cols="12"
                    md="6"
                    class="mt-5"
                  >
                    <ValidationProvider v-slot="{ errors }" :rules="'required|alpha_num_whitespace'" name="issueDescription">
                      <v-textarea
                        v-model.trim="issueDescription"
                        :error-messages="errors"
                        label="What was the issue? *"
                        rows="1"
                        auto-grow
                        style="width:400px"
                        outlined
                      />
                    </ValidationProvider>
                  </v-col>
                  <v-col
                    cols="12"
                    md="6"
                    class="mt-5"
                  >
                    <label>Who was the reporter of the issue(s)? *</label>
                    <v-radio-group v-model="reporterOfIssue" :mandatory="false" class="mt-1">
                      <v-radio
                        v-for="(reporter, index) in rcaReporterUsers"
                        :key="index"
                        :label="reporter.name"
                        :value="reporter.id"
                        class="ml-2"
                      />
                    </v-radio-group>
                  </v-col>
                </v-row>
                <v-row>
                  <v-col
                    cols="12"
                    md="6"
                    class="mt-5"
                  >
                    <ValidationProvider v-slot="{ errors }" :rules="'required|alpha_num_whitespace'" name="resolveIssueDescription">
                      <v-textarea
                        v-model.trim="resolveIssueDescription"
                        :error-messages="errors"
                        label="What did we do to resolve the issue(s)? *"
                        rows="1"
                        style="width:400px"
                        auto-grow
                        outlined
                      />
                    </ValidationProvider>
                  </v-col>
                  <v-col
                    cols="12"
                    md="6"
                    class="mt-5"
                  >
                    <ValidationProvider v-slot="{ errors }" :rules="'required|alpha_num_whitespace'" name="fixIssueDescription">
                      <v-textarea
                        v-model.trim="fixIssueDescription"
                        :error-messages="errors"
                        label="How much time it took to fix the issue? *"
                        rows="1"
                        auto-grow
                        outlined
                      />
                    </ValidationProvider>
                  </v-col>
                </v-row>
                <v-row>
                  <v-col
                    cols="12"
                    md="6"
                    class="mt-5"
                  >
                    <ValidationProvider v-slot="{ errors }" :rules="'required|alpha_num_whitespace'" name="preventDescription">
                      <v-textarea
                        v-model.trim="preventDescription"
                        :error-messages="errors"
                        label="What to do in order to prevent the issue(s) in future? *"
                        rows="1"
                        style="width:400px"
                        auto-grow
                        outlined
                      />
                    </ValidationProvider>
                  </v-col>
                  <v-col
                    cols="12"
                    md="6"
                    class="mt-5"
                  >
                    <label>What is the priority of the issue? *</label>
                    <v-radio-group v-model="priorityOfIssue" :mandatory="false" class="mt-1">
                      <v-radio
                        v-for="(priority, index) in prioritiesOfIssue"
                        :key="index"
                        :label="priority.name"
                        :value="priority.id"
                        class="ml-2"
                      />
                    </v-radio-group>
                  </v-col>
                </v-row>
                <v-row>
                  <v-col
                    cols="12"
                    md="6"
                    class="mt-5"
                  >
                    <ValidationProvider v-slot="{ errors }" :rules="'required'" name="selectedFixer">
                      <v-autocomplete
                        v-model="selectedFixer"
                        :error-messages="errors"
                        :items="users"
                        :search-input.sync="searchMember"
                        item-text="full_name"
                        item-value="id"
                        outlined
                        attach
                        style="width:400px"
                        chips
                        label="Who fixed the issue(s) i.e. one team member or all? *"
                        multiple
                        @change="searchMember=''"
                      >
                        <template v-slot:selection="data">
                          <v-chip
                            v-bind="data.attrs"
                            :input-value="data.selected"
                            close
                            @click="data.select"
                            @click:close="removeItemFromArray(data.item, 'selectedFixer')"
                          >
                            <strong>{{ data.item.full_name }}</strong>&nbsp;
                          </v-chip>
                        </template>
                      </v-autocomplete>
                    </ValidationProvider>
                  </v-col>
                  <v-col
                    cols="12"
                    md="6"
                    class="mt-5"
                  >
                    <template>
                      <ValidationProvider v-slot="{ errors }" :rules="'counter:3|ext:jpg,jpeg,png,pdf,docx,doc,xlsx,xls,zip'" name="ext_field" type="file">
                        <v-file-input
                          id="upload-file"
                          v-model="files"
                          :error-messages="errors"
                          :show-size="1000"
                          :persistent-hint="true"
                          color="primary"
                          counter="3"
                          label="Attachment(s)"
                          multiple
                          placeholder="Select your files"
                          prepend-icon="mdi-paperclip"
                          outlined
                          small-chips
                          hint="*File types must be in (jpg, jpeg, png, pdf, docx, doc, xlsx, xls, zip) only"
                          @change="fileChange"
                          @click:clear="previousFiles = []"
                        >
                          <template v-slot:selection="data">
                            <v-chip
                              v-if="attachmentRemove"
                              class="ma-2"
                              close
                              @click:close="removeAttachmentFromArray(data.text, data.index)"
                            >
                              {{ data.text }}
                            </v-chip>
                          </template>
                        </v-file-input>
                      </ValidationProvider>
                    </template>
                  </v-col>
                </v-row>
                <v-row align="end" justify="end">
                  <v-col v-if="!valid" cols="12">
                    <v-btn
                      class="text-capitalize ma-2 white--text"
                      color="blue-grey"
                      @click="$router.push('/project-dashboard')"
                    >
                      <v-icon dark left>
                        mdi-arrow-left
                      </v-icon>Back
                    </v-btn>
                    <v-btn :disabled="!valid" class="text-capitalize" color="primary" @click="submit">
                      Submit
                    </v-btn>
                  </v-col>
                  <v-col v-else cols="12">
                    <v-btn
                      class="text-capitalize ma-2 white--text"
                      color="blue-grey"
                      @click="$router.push('/project-dashboard')"
                    >
                      <v-icon dark left>
                        mdi-arrow-left
                      </v-icon>Back
                    </v-btn>
                    <v-btn :disabled="submitted" class="text-capitalize" color="primary" @click="submit">
                      Submit
                    </v-btn>
                  </v-col>
                </v-row>
              </v-card-text>
            </v-card>
          </ValidationObserver>
        </v-tab-item>
        <v-tab-item
          :value="'tab-2'"
        >
          <v-row align="center" justify="center" height="25px">
            <v-col cols="12">
              <v-col cols="12">
                <v-data-table
                  :headers="headers"
                  :search="search"
                  :custom-filter="customFilter"
                  :items="rcaTableData"
                  class="rcaListData"
                  :hide-default-footer="rcaTableData.length ? false : true"
                >
                  <template v-slot:top>
                    <v-container fluid class="pa-0">
                      <v-row justify="end">
                        <v-col cols="3">
                          <div>
                            <v-menu :close-on-content-click="false" offset-y>
                              <template v-slot:activator="{ on, attrs }">
                                <v-btn
                                  v-bind="attrs"
                                  class="white grey--text mb-2 text-capitalize"
                                  height="48px"
                                  min-width="60%"
                                  max-width="100%"
                                  v-on="on"
                                >
                                  <v-icon color="grey" dark left>
                                    mdi-calendar-range
                                  </v-icon> {{ anyDateText }}
                                  <v-icon color="grey">
                                    notranslate mdi mdi-chevron-down
                                  </v-icon>
                                </v-btn>
                              </template>
                              <v-list class="pa-0 justify-center" width="320px" height="300px">
                                <v-row>
                                  <v-col cols="6" class="ml-1 pa-2">
                                    <v-card flat width="130px" class="ml-1 mt-2">
                                      <v-menu
                                        ref="fromDateMenu"
                                        v-model="fromDateMenu"
                                        :close-on-content-click="false"
                                        offset-y
                                        transition="scale-transition"
                                      >
                                        <template v-slot:activator="{ on }">
                                          <v-text-field
                                            slot="activator"
                                            v-model="fromDateString"
                                            label="From Date"
                                            prepend-icon="mdi-calendar"
                                            readonly
                                            v-on="on"
                                          />
                                        </template>
                                        <v-date-picker v-model="fromDatePicker" @change="changeFromDateString" @input="fromDateMenu = false" />
                                      </v-menu>
                                    </v-card>
                                  </v-col>
                                  <v-col cols="5" class="pa-2">
                                    <v-card flat width="130px" class="mt-2">
                                      <v-menu
                                        ref="toDateMenu"
                                        v-model="toDateMenu"
                                        :close-on-content-click="false"
                                        offset-y
                                        transition="scale-transition"
                                      >
                                        <template v-slot:activator="{ on }">
                                          <v-text-field
                                            v-model="toDateString"
                                            label="To Date"
                                            prepend-icon="mdi-calendar"
                                            readonly
                                            v-on="on"
                                          />
                                        </template>
                                        <v-date-picker
                                          v-model="toDatePicker"
                                          :min="fromDatePicker"
                                          :max="getEndDate"
                                          @change="changeToDateString"
                                          @input="toDateMenu = false"
                                        />
                                      </v-menu>
                                    </v-card>
                                  </v-col>
                                </v-row>
                                <v-divider />
                                <v-list-item class="pl-5" style="height: 50px;">
                                  <v-list-item-action>
                                    <v-btn
                                      :color="disabledToday"
                                      small
                                      width="240px"
                                      class="ma-2"
                                      outlined
                                      @click="todayDate"
                                    >
                                      Today
                                    </v-btn>
                                  </v-list-item-action>
                                </v-list-item>
                                <v-list-item class="pl-5" style="height: 50px;">
                                  <v-list-item-action>
                                    <v-btn
                                      :color="disabledYesterday"
                                      small
                                      width="240px"
                                      class="ma-2"
                                      outlined
                                      @click="yesterdayDate"
                                    >
                                      Yesterday
                                    </v-btn>
                                  </v-list-item-action>
                                </v-list-item>
                                <v-list-item class="pl-5" style="height: 50px;">
                                  <v-list-item-action>
                                    <v-btn
                                      :color="disabledPastMonth"
                                      small
                                      width="240px"
                                      class="ma-2"
                                      outlined
                                      @click="pastMonth"
                                    >
                                      Past Month
                                    </v-btn>
                                  </v-list-item-action>
                                </v-list-item>
                                <v-list-item class="pl-5" style="height: 50px;">
                                  <v-list-item-action>
                                    <v-btn
                                      :color="disabledPastThreeMonths"
                                      small
                                      width="240px"
                                      class="ma-2"
                                      outlined
                                      @click="pastThreeMonths"
                                    >
                                      Past 3 Months
                                    </v-btn>
                                  </v-list-item-action>
                                </v-list-item>
                              </v-list>
                            </v-menu>
                          </div>
                        </v-col>
                        <v-col cols="3">
                          <div class="pl-2 pr-4 pt-0">
                            <v-text-field
                              v-model="search"
                              append-icon="mdi-magnify"
                              label="Search"
                              solo
                              rounded
                              single-line
                              hide-details
                            />
                          </div>
                        </v-col>
                      </v-row>
                    </v-container>
                  </template>
                  <template v-slot:body="{ items }">
                    <tbody>
                      <tr v-for="item in items" :key="item.uuid" :class="{'selectedRow': item === selectedItem}" @click="viewDetails(item)">
                        <td>
                          <div style="text-align:center;">
                            <p>{{ item.number }}</p>
                          </div>
                        </td>
                        <v-tooltip max-width="250px" color="blue lighten-1" top>
                          <template v-slot:activator="{ on, attrs }">
                            <td v-bind="attrs" v-on="on">
                              <div style="text-align:center;">
                                <p>{{ item.issue_detail_substr }}</p>
                              </div>
                            </td>
                          </template>
                          <span>{{ item.issue_detail }}</span>
                        </v-tooltip>
                        <v-tooltip max-width="250px" color="blue lighten-1" top>
                          <template v-slot:activator="{ on, attrs }">
                            <td v-bind="attrs" v-on="on">
                              <div style="text-align:center">
                                <p>{{ item.prevent_for_future_substr }}</p>
                              </div>
                            </td>
                          </template>
                          <span>{{ item.prevent_for_future }}</span>
                        </v-tooltip>
                        <td>
                          <div style="text-align:center;">
                            <v-chip
                              v-if="item.issue_priority"
                              class="ma-2"
                              color="blue lighten-3"
                              text-color="black--text text--darken-1"
                            >
                              {{ item.issue_priority }}
                            </v-chip>
                          </div>
                        </td>
                        <td>
                          <div style="text-align:center;">
                            <p>{{ item.created_by.display_name }}</p>
                          </div>
                        </td>
                        <td>
                          <div style="text-align:center;">
                            {{ new Date(item.created_at.substr(0,10)).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }) }}
                          </div>
                        </td>
                      </tr>
                    </tbody>
                  </template>
                </v-data-table>
              </v-col>
            </v-col>
          </v-row>
        </v-tab-item>
      </v-tabs-items>
    </v-card>
  </div>
</template>
<script>
import { mapActions, mapGetters } from 'vuex'
import constant from '@/constants/closure-checklist.js'
import CommonSnackbar from '@/components/CommonSnackbar'
import Dialog from '@/components/Dialog.vue'

export default {
  name: 'Index',
  components: { CommonSnackbar, Dialog },
  layout: 'authenticated',
  middleware: 'authenticated',
  async fetch ({ app, store, route }) {
    // eslint-disable-next-line no-useless-catch
    try {
      await Promise.all([
        store.dispatch('project/fetchRcaList', route.params.id),
        store.dispatch('project/fetchProjectDetail', route.params.id),
        store.dispatch('project/fetchRcaReporterUsers')
      ])
    } catch (error) {
      throw (error)
    }
  },
  data () {
    return {
      search: '',
      dateFilter: false,
      issueReportedDateMenu: false,
      issueReportedDatePicker: new Date().toISOString().substr(0, 10),
      actionDatePicker: new Date().toISOString().substr(0, 10),
      actionDateMenu: false,
      issueReportedDateString: new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
      actionDateString: new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
      issueReportedTime: this.getInitialTime().formattedTime,
      issueReportedTimeMenu: false,
      issueReportedTimeString: this.getInitialTime().formattedStringTime,
      actionTimeMenu: false,
      actionTime: this.getInitialTime().formattedTime,
      actionReportedTimeString: this.getInitialTime().formattedStringTime,
      reporterOfIssue: 1,
      resolveIssueDescription: '',
      fixIssueDescription: '',
      priorityOfIssue: 1,
      searchMember: '',
      submitted: false,
      snackbarValue: false,
      snackbarText: '',
      tab: null,
      dialog: false,
      constant,
      inputDialog: false,
      projectId: null,
      projectRcaId: null,
      headers: [
        { text: 'Number', align: 'center', width: '15%', value: 'number', sortable: true },
        { text: 'Root Cause', align: 'center', width: '20%', value: 'issue_detail', sortable: false },
        { text: 'Resolution', align: 'center', width: '20%', sortable: false, value: 'prevent_for_future' },
        { text: 'Priority', align: 'center', value: 'issue_priority', sortable: false, width: '15%' },
        { text: 'Created By', align: 'center', value: 'created_by.display_name', sortable: false, width: '15%' },
        { text: 'Created On', align: 'center', value: 'created_at', sortable: true, width: '15%', filter: this.datesFilter }
      ],
      selectedFixer: [],
      rcaNumbers: [],
      kedbNumber: '',
      projectName: '',
      searchTag: null,
      issueDescription: '',
      WorkaroundDesc: '',
      files: [],
      previousFiles: [],
      selectedItem: null,
      fav: true,
      menu: false,
      message: false,
      date: new Date(),
      attachments: [],
      form: new FormData(),
      prioritiesOfIssue: [
        {
          'id': 1,
          'name': 'Low'
        },
        {
          'id': 2,
          'name': 'Medium'
        },
        {
          'id': 3,
          'name': 'High'
        }
      ],
      priorityName: '',
      preventDescription: '',
      fromDateMenu: false,
      fromDatePicker: null,
      toDatePicker: null,
      toDateMenu: false,
      fromDateString: new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
      toDateString: this.getInitialEndDate().formattedDate,
      attachmentRemove: true,
      format: 'ampm',
      ampmInTitle: true,
      rcaTableData: [],
      disabledToday: 'blue lighten-1',
      disabledYesterday: 'blue lighten-1',
      disabledPastMonth: 'blue lighten-1',
      disabledPastThreeMonths: 'blue lighten-1',
      anyDateText: ' Any Date '
    }
  },
  computed: {
    ...mapGetters({
      getCustomDialog: 'project/getCustomDialog',
      currentUser: 'auth/user',
      projectDetail: 'project/getProjectDetail',
      rcaList: 'project/getRcaList',
      getCreatedAttachment: 'project/getCreatedAttachment',
      rcaReporterUsers: 'project/getRcaReporterUsers',
      users: 'project/getUserList'
    }),
    getEndDate () {
      const selectedDate = new Date(this.fromDatePicker)
      const endDate = new Date(selectedDate.getFullYear(), selectedDate.getMonth() + 6, selectedDate.getDate())

      return endDate.toISOString().slice(0, 10)
    }
  },

  mounted () {
    this.$nuxt.$emit('headerTitle', 'RCA')
    this.projectName = this.projectDetail.project_name
    this.rcaList.map((value) => {
      switch (value.issue_priority) {
      case constant.PRIORITY.LOW: this.priorityName = 'Low'
        break
      case constant.PRIORITY.MEDIUM: this.priorityName = 'Medium'
        break
      case constant.PRIORITY.HIGH: this.priorityName = 'High'
        break
      default: this.priorityName = ''
      }
      this.rcaTableData.push({
        created_by: value.created_by,
        issue_detail: value.issue_detail,
        issue_detail_substr: (value.issue_detail.length < 40) ? value.issue_detail : value.issue_detail.substring(0, 40) + ' . . .',
        prevent_for_future_substr: (value.prevent_for_future.length < 40) ? value.prevent_for_future : value.prevent_for_future.substring(0, 40) + ' . . .',
        prevent_for_future: value.prevent_for_future,
        created_at: value.created_at,
        number: value.number,
        issue_priority: this.priorityName,
        uuid: value.uuid
      })
    })
  },
  methods: {
    ...mapActions({
      fetchRcaList: 'project/fetchRcaList',
      setCustomDialog: 'project/setCustomDialog',
      updateLoadingAction: 'project/updateLoadingAction',
      setCreatedRcaData: 'project/setCreatedRcaData',
      fetchProjectList: 'project/fetchProjectList',
      uploadAttachmentData: 'project/uploadAttachmentData',
      setCreatedAttachment: 'project/setCreatedAttachment'
    }),
    removeAttachmentFromArray (text, ChipIndex) {
      this.files = this.files.filter((element, index) => index !== ChipIndex)
      this.previousFiles = []
    },
    filter (item, queryText, itemText) {
      const hasValue = (val) => val !== null ? val : ''

      const text = hasValue(itemText)
      const query = hasValue(queryText)

      return text.toString()
        .toLowerCase()
        .includes(query.toString().toLowerCase())
    },
    customFilter (items, search) {
      const hasValue = (val) => val !== null ? val : ''
      const text = hasValue(items)
      const query = hasValue(search)

      return text.toString()
        .toLowerCase()
        .includes(query.toString().toLowerCase())
    },
    changeIssueTimeString (selected) {
      this.issueReportedTimeString = this.tConvert(selected)
    },
    changeActionTimeString (selected) {
      this.actionReportedTimeString = this.tConvert(selected)
    },
    getInitialTime () {
      const d = new Date()
      const hr = d.getHours()
      const min = d.getMinutes()
      const formattedTime = hr + ':' + min
      const formattedStringTime = this.tConvert(formattedTime)

      return { formattedTime, formattedStringTime }
    },
    tConvert (time) {
      // Check correct time format and split into components
      time = time.toString().match(/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [time]

      if (time.length > 1) { // If time format correct
        time = time.slice(1) // Remove full string match value
        time[5] = +time[0] < 12 ? ' AM ' : ' PM ' // Set AM/PM
        time[0] = +time[0] % 12 || 12 // Adjust hours
      }

      return time.join('') // return adjusted time or original string
    },
    changeIssueDateString (selected) {
      this.issueReportedDateString = new Date(selected).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      })
      if (this.actionDatePicker < this.issueReportedDatePicker) {
        this.actionDatePicker = this.issueReportedDatePicker
        this.actionDateString = this.issueReportedDateString
      }
    },
    changeActionDateString (selected) {
      this.actionDateString = new Date(selected).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      })
    },
    changeFromDateString (selected) {
      this.fromDateString = new Date(selected).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      })
      if (this.fromDatePicker || this.toDatePicker) {
        this.anyDateText = this.fromDateString + ' - ' + this.toDateString
      }
      this.disabledToday = 'blue lighten-1'
      this.disabledYesterday = 'blue lighten-1'
      this.disabledPastMonth = 'blue lighten-1'
      this.disabledPastThreeMonths = 'blue lighten-1'
    },
    changeToDateString (selected) {
      this.toDateString = new Date(selected).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      })
      if (this.fromDatePicker || this.toDatePicker) {
        this.anyDateText = this.fromDateString + ' - ' + this.toDateString
      }
      this.disabledToday = 'blue lighten-1'
      this.disabledYesterday = 'blue lighten-1'
      this.disabledPastMonth = 'blue lighten-1'
      this.disabledPastThreeMonths = 'blue lighten-1'
    },
    todayDate () {
      const today = new Date().toISOString().substr(0, 10)

      this.fromDatePicker = today
      this.toDatePicker = today
      this.toDateString = new Date(today).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      })
      this.fromDateString = new Date(today).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      })
      this.anyDateText = this.fromDateString + ' - ' + this.toDateString
      this.disabledToday = 'orange'
      this.disabledYesterday = 'blue lighten-1'
      this.disabledPastMonth = 'blue lighten-1'
      this.disabledPastThreeMonths = 'blue lighten-1'
    },
    yesterdayDate () {
      let yesterday = new Date()

      yesterday.setDate(yesterday.getDate() - 1)
      yesterday = new Date(yesterday).toISOString().substr(0, 10)
      this.fromDatePicker = yesterday
      this.toDatePicker = yesterday
      this.toDateString = new Date(yesterday).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      })
      this.fromDateString = new Date(yesterday).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      })
      this.anyDateText = this.fromDateString + ' - ' + this.toDateString
      this.disabledToday = 'blue lighten-1'
      this.disabledPastMonth = 'blue lighten-1'
      this.disabledPastThreeMonths = 'blue lighten-1'
      this.disabledYesterday = 'orange'
    },
    pastMonth () {
      let prevStartDate = new Date(this.date.getFullYear(), this.date.getMonth() - 1, 1)

      prevStartDate = this.formatDate(prevStartDate)
      let preEndDate = new Date(this.date.getFullYear(), this.date.getMonth() - 1 + 1, 0)

      preEndDate = this.formatDate(preEndDate)
      this.fromDatePicker = prevStartDate
      this.toDatePicker = preEndDate
      this.toDateString = new Date(preEndDate).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      })
      this.fromDateString = new Date(prevStartDate).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      })
      this.anyDateText = this.fromDateString + ' - ' + this.toDateString
      this.disabledToday = 'blue lighten-1'
      this.disabledYesterday = 'blue lighten-1'
      this.disabledPastThreeMonths = 'blue lighten-1'
      this.disabledPastMonth = 'orange'
    },
    pastThreeMonths () {
      let prevStartDate = new Date(this.date.getFullYear(), this.date.getMonth() - 3, 1)

      prevStartDate = this.formatDate(prevStartDate)
      let preEndDate = new Date(this.date.getFullYear(), this.date.getMonth() - 1 + 1, 0)

      preEndDate = this.formatDate(preEndDate)
      this.fromDatePicker = prevStartDate
      this.toDatePicker = preEndDate
      this.toDateString = new Date(preEndDate).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      })
      this.fromDateString = new Date(prevStartDate).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      })
      this.anyDateText = this.fromDateString + ' - ' + this.toDateString
      this.disabledToday = 'blue lighten-1'
      this.disabledYesterday = 'blue lighten-1'
      this.disabledPastMonth = 'blue lighten-1'
      this.disabledPastThreeMonths = 'orange'
    },
    formatDate (date) {
      const d = new Date(date)
      let month = '' + (d.getMonth() + 1)
      let day = '' + d.getDate()
      const year = d.getFullYear()

      if (month.length < 2) { month = '0' + month }
      if (day.length < 2) { day = '0' + day }

      return [year, month, day].join('-')
    },
    /**
       * Filter for created on dates column.
       * @param value Value to be tested.
       * @returns {boolean}
       */
    datesFilter (value) {
      // If this filter has no value we just skip the entire filter.
      if (!this.fromDatePicker || !value || !this.toDatePicker) {
        return true
      }
      value = this.formatDate(value)
      if (value >= this.fromDatePicker && value <= this.toDatePicker) {
        return true
      }
    },
    removeItemFromArray (item, searchString) {
      this.$data[searchString] = this.$data[searchString].filter((arrayItem) => arrayItem !== item.id)
      this.$data[searchString] = [...this.$data[searchString]]
    },
    fileChange () {
      this.files = this.previousFiles.concat(this.files)
      const key = 'name'

      this.files = this.files.map((e) => e[key]).map((e, i, final) => final.indexOf(e) === i && i).filter((e) => this.files[e]).map((e) => this.files[e])
      this.previousFiles = this.files
      const selectedFiles = this.files

      if (!selectedFiles.length) {
        return false
      }
      this.attachments = []
      for (let i = 0; i < selectedFiles.length; i++) {
        this.attachments.push(selectedFiles[i])
      }
    },
    async submit () {
      const reportedDateTime = this.issueReportedDatePicker + ' ' + this.issueReportedTime + ':00'
      const actionDateTime = this.actionDatePicker + ' ' + this.actionTime + ':00'

      if (reportedDateTime > actionDateTime) {
        this.snackbarText = 'The reported date must be equal or lesser than action date.'
        this.snackbarValue = true
        setTimeout(() => {
          this.snackbarValue = false
        }, 3000)

        return
      }
      await this.updateLoadingAction()
      for (let i = 0; i < this.attachments.length; i++) {
        this.form.append('attachments[]', this.attachments[i])
      }
      await this.uploadAttachmentData(this.form)
      const attachmentIds = []

      if (this.getCreatedAttachment.data) {
        this.getCreatedAttachment.data.map((value) => {
          attachmentIds.push(value.id)
        })
      }
      const requestData = {
        'issue_detail': this.issueDescription,
        'date_of_issue_reported_first': reportedDateTime,
        'date_of_action_reported_first': actionDateTime,
        'issue_reported_by': this.reporterOfIssue,
        'resolve_issue_type': this.resolveIssueDescription,
        'time_taken_to_fix': this.fixIssueDescription,
        'issue_priority': this.priorityOfIssue,
        'prevent_for_future': this.preventDescription,
        'fixed_by': this.selectedFixer,
        'attachments': attachmentIds,
        'project_id': this.projectDetail.uuid
      }

      await this.setCreatedRcaData(requestData)
      this.updateLoadingAction()
      this.submitted = true
    },
    getInitialEndDate () {
      const todaysDate = new Date()
      const endDate = new Date(Date.UTC(todaysDate.getFullYear(), todaysDate.getMonth() + 2, todaysDate.getDate()))
      const formattedDate = endDate.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })
      const formattedStringDate = endDate.toISOString().substr(0, 10)
      const maxDate = new Date(Date.UTC(todaysDate.getFullYear(), todaysDate.getMonth() + 6, todaysDate.getDate()))
        .toISOString().substr(0, 10)

      return { formattedDate, formattedStringDate, maxDate }
    },
    viewDetails (value) {
      this.selectedItem = value
      this.$router.push(`/rca/${value.uuid}/rca-view`)
    }
  }
}
</script>

<style scoped>
/* .v-data-table td, .v-data-table th {
    padding: 0 20px !important;
} */
.rcaListData table tbody tr td {
    padding: 30px 20px !important;
    vertical-align: baseline;
}
.selectedRow {
    background-color: #66b2ff;
    font-weight: bold;
}
.active {
  background: green;
}
.v-application .headline {
    font-size: medium !important;
    font-weight: 500;
    line-height: normal !important ;
}
.grow {
  padding: 5px 5px 5px 5px;
  border-radius: 10px;
  height: 49px;
  margin: 5px 1% 5px 1%;
  float: left;
  position: relative;
  transition: height 0.5s;
  -webkit-transition: height 0.5s;
  overflow: hidden;
}
.grow:hover {
  height: auto;
  background-color:  #91c5f8;
}
.v-input--selection-controls .v-radio >>> .v-label {
    flex: none !important;
 }
 >>>.v-data-table-header {
    box-shadow: 0px 3px 1px -2px rgba(0, 0, 0, 0.2), 0px 2px 2px 0px rgba(0, 0, 0, 0.14), 0px 1px 5px 0px rgba(0, 0, 0, 0.12);
    color: white;
    border-radius: inherit;
  }
</style>
