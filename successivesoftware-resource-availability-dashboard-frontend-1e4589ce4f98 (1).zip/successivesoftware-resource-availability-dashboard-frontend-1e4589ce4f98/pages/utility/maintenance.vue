<template>
  <div>
    <v-img
      class="mb-5"
      max-height="400"
      contain
      src="/images/illustrations/maintenance-illustration.svg"
    ></v-img>

    <h1 class="display-2 font-weight-bold">In Maintenance</h1>
    <h2 class="title mt-4 mb-4">We will be back soon</h2>
    <v-btn
      block
      large
      color="primary"
      to="/"
      link
    >Send me Back</v-btn>
  </div>
</template>

<script>
export default {
  layout: 'auth'
}
</script>
