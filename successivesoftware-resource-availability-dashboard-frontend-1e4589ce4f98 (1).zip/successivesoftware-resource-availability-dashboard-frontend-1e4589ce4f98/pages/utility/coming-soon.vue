<template>
  <div class="pa-2">
    <h1 class="display-2 font-weight-bold">We are coming soon</h1>
    <h2 class="title mt-4">We are almost there! If you want to get notified when the website goes live, subscribe to our mailing list!</h2>
    <div class="mt-8">
      <v-text-field solo placeholder="Email address"></v-text-field>
      <v-btn color="primary" large block>Subscribe</v-btn>
    </div>
  </div>
</template>

<script>
export default {
  layout: 'auth'
}
</script>
