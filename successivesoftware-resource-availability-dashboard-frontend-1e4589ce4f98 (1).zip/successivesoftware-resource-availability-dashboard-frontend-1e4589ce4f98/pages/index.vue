<template>
  <div id="resourceDashboard">
    <v-row>
      <v-col cols="12" md="6" xl="6" class="dashboardHeading">
        <h1>Resource Dashboard</h1>
      </v-col>
      <v-col cols="12" md="6" xl="6" class="text-right">
        <v-autocomplete
          v-model="selectedReport"
          :items="reports"
          item-text="name"
          item-value="id"
          outlined
          small-chips
          class="DownloadReportBtn"
          label="Download Report"
          dense
          @change="downloadExcel(selectedReport)"
        >
          <template v-slot:item="{ item }">

            <span>{{ item.name }} <v-icon :class="item.pl">
              mdi-download
            </v-icon>
            </span>
          </template>
        </v-autocomplete>
      </v-col>
    </v-row>
    <v-card class="mt-3 mb-5">
      <v-row class="">
        <v-col cols="7">
          <div v-if="unscheduledTableData.length > 0 || fullyScheduledTableData.length > 0 || partiallyScheduledTableData.length > 0 || overScheduledTableData.length" class="resDshGraph" >
            <v-row>
              <v-col cols="12" class="pb-0 pt-0">
                <h3>Resource Overview & Utilization</h3>
              </v-col>
            </v-row>
            <div class="graphWrpOuter">
              <div class="graphWrp" @click="onChangeToOverview">
                <sources-card
                  :label="overview"
                  :offset="-15"
                  :label-array="overviewLabels"
                  :series="[unscheduledTableData.length, fullyScheduledTableData.length, partiallyScheduledTableData.length, overScheduledTableData.length]"
                  :color-array="overviewColors"
                  :fill-array="overviewFill"
                  :legend-position="'left'"
                  :pie-width="'90%'"
                  :show-labels="true"
                  :show-legend="true"
                  :type="'donut'"
                  percentage-label="lastweek"
                  class="h-full brRight"
                  color="#8c9eff"
                />
              </div>
              <div class="graphWrp" style="opacity: 0.2; pointer-events:none">
                <sources-card
                  :label="utilize"
                  :offset="-15"
                  :label-array="utilizeLabels"
                  :value="432"
                  :percentage="4.3"
                  :legend-position="'left'"
                  :series="[40, 50, 120, 100]"
                  :color-array="utilizeColors"
                  :fill-array="utilizeFill"
                  :show-legend="true"
                  :pie-width="'87%'"
                  :show-labels="true"
                  :type="'donut'"
                  percentage-label="lastweek"
                  class="h-full"
                  color="#8c9eff"
                />
              </div>
            </div>
          </div>
          <div v-else class="resDshGraph">
            <span>No Data Available for Resource Overview</span>
          </div>
        </v-col>
        <v-col cols="5">
          <div class="projectFltDataWrp">
            <div class="filterReading">
              <div class="filterData">
                <h5>Filter Data
                  <v-autocomplete
                    v-model="locationSelected"
                    :items="locations"
                    placeholder="Location"
                    dense
                    prepend-inner-icon="mdi-map-marker"
                    solo
                    class="blue--text"
                  />
                </h5>
                <v-checkbox
                  v-model="excludeTrainee"
                  label="Exclude Trainees"
                  class="mt-0 ml-1 mb-1"
                />
              </div>
              <div class="resetBtnWrp">
                <v-btn
                  text
                  class="resetBtn"
                  @click.prevent="reset"
                >
                  Reset
                </v-btn>
              </div>
            </div>
            <v-sheet v-show="showFilters" class="bg-color">
              <v-row v-if="filteredElements.length">
                <v-col cols="12" class="pt-0 pb-0">
                  <v-chip-group active-class="primary--text" column>
                    <v-chip
                      v-for="(tag,index) in filteredElements.slice(0,3)"
                      :key="index"
                      color="white"
                      class="blue--text selectedShip"
                      close
                      @click:close="removeFilter(tag)"
                    >
                      {{ tag.value.length >= 20? tag.value.slice(0,20) + '...': tag.value }}
                    </v-chip>
                    <v-btn
                      v-if="filteredElements.length > 3"
                      class="ma-1 text-capitalize fillterBtn"
                      outlined
                      rounded
                      small
                      size="50"
                      color="blue"
                      @click="showFilters = !showFilters"
                    >
                      <v-icon x-small>
                        mdi-plus
                      </v-icon>
                      {{ filteredElements.slice(3,filteredElements.length).length }} filters
                    </v-btn>
                  </v-chip-group>
                </v-col>
              </v-row>
              <v-row>
                <v-col cols="12" md="6" class="pt-0 pb-0 pr-1">
                  <v-autocomplete
                    v-model="departmentSelected"
                    :items="departments.filter(item => item !== 'All')"
                    label="Department"
                    dense
                    multiple
                    filled
                    rounded
                    @change="filteredResourceName(departmentSelected)"
                  >
                    <template v-slot:selection="{ index }">
                      <span v-if="index === 0" />
                      <span v-if="index === 1" />
                    </template>
                  </v-autocomplete>
                </v-col>
                <v-col cols="12" md="6" class="pt-0 pb-0 pl-1">
                  <v-autocomplete
                    v-model="selectedProjectBillingType"
                    :items="billingTypeArray"
                    item-text="name"
                    label="Resource Billing Type"
                    multiple
                    dense
                    filled
                    rounded
                    @change="filterProjectNameArray(selectedProjectBillingType)"
                  >
                    <template v-slot:selection="{ index }">
                      <span v-if="index === 0" />
                      <span v-if="index === 1" />
                    </template>
                  </v-autocomplete>
                </v-col>
              </v-row>
              <v-row>
                <v-col cols="12" md="6" class="pt-0 pb-0 pr-1">
                  <v-autocomplete
                    v-model="selectedProjectName"
                    :items="projectNameArray"
                    item-text="name"
                    label="Project Name"
                    filled
                    multiple
                    rounded
                    dense
                    @change="setDepartmentToDefault()"
                  >
                    <template v-slot:selection="{ index }">
                      <span v-if="index === 0" class="pa-0 ma-0" />
                      <span v-if="index === 1" class="pa-0 ma-0" />
                    </template>
                  </v-autocomplete>
                </v-col>
                <v-col cols="12" md="6" class="pt-0 pb-0 pl-1">
                  <v-autocomplete
                    v-model="selectedResourceName"
                    :items="resourceList"
                    item-text="full_name"
                    label="Resource Name"
                    filled
                    multiple
                    rounded
                    dense
                    @change="setResourceNameDefault()"
                  >
                    <template v-slot:selection="{ index }">
                      <span v-if="index === 0" />
                      <span v-if="index === 1" />
                    </template>
                  </v-autocomplete>
                </v-col>
              </v-row>
              <v-row>
                <v-col cols="12" md="6" class="pt-0 pb-0 pr-1">
                  <div class="resourceDateFilter">
                    <v-menu
                      ref="fromDateMenu"
                      v-model="fromDateMenu"
                      :close-on-content-click="false"
                      offset-y
                      transition="scale-transition"
                    >
                      <template v-slot:activator="{ on }">
                        <v-text-field
                          slot="activator"
                          v-model="fromDateString"
                          label="From Date"
                          readonly
                          v-on="on"
                        >
                          <template v-slot:append>
                            <v-icon v-on="on">
                              mdi-calendar
                            </v-icon>
                          </template>
                        </v-text-field>
                      </template>
                      <v-date-picker v-model="fromDatePicker" @change="changeFromDateString" @input="fromDateMenu = false" />
                    </v-menu>
                  </div>
                </v-col>
                <v-col cols="12" md="6" class="pt-0 pb-0 pl-1">
                  <div class="resourceDateFilter">
                    <v-menu
                      ref="toDateMenu"
                      v-model="toDateMenu"
                      :close-on-content-click="false"
                      offset-y
                      transition="scale-transition"
                    >
                      <template v-slot:activator="{ on }">
                        <v-text-field
                          v-model="toDateString"
                          label="To Date"
                          readonly
                          v-on="on"
                        >
                          <template v-slot:append>
                            <v-icon v-on="on">
                              mdi-calendar
                            </v-icon>
                          </template>
                        </v-text-field>
                      </template>
                      <v-date-picker
                        v-model="toDatePicker"
                        :min="fromDatePicker"
                        @change="changeToDateString"
                        @input="toDateMenu = false"
                      />
                    </v-menu>
                  </div>
                </v-col>
                <v-col cols="12" class="pt-0 pb-0 pl-1 text-center">
                  <v-btn
                    class="applyBtn"
                    small
                    rounded
                    @click="searchWithFilters"
                  >
                    Apply
                  </v-btn>
                </v-col>
              </v-row>
            </v-sheet>
            <div v-show="!showFilters" class="selectItemsWrp">
              <div v-if="filteredElements.length" class="selectItemsInner">
                <div class="selectItems">
                  <v-chip-group active-class="primary--text" scrollable column>
                    <v-chip
                      v-for="(tag,index) in filteredElements"
                      :key="index"
                      color="white"
                      class="blue--text selectedShip"
                      close
                      @click:close="removeFilter(tag)"
                    >
                      {{ tag.value.length >= 20? tag.value.slice(0,20) + '...': tag.value }}
                    </v-chip>
                  </v-chip-group>
                </div>
                <div class="backToFOrm">
                  <v-btn
                    bottom
                    fab
                    color="primary"
                    small
                    @click="showFilters = !showFilters"
                  >
                    <v-icon>mdi-chevron-up</v-icon>
                  </v-btn>
                </div>
              </div>
            </div>
          </div>
        </v-col>
      </v-row>
    </v-card>
    <v-row v-if="changeTableView === true && !showResourceUtilization" class="mt-1" dense>
      <v-col cols="12" lg="6" class="resourceDMainTableWrp unscheduledResDasboardWrp">
        <v-card-title solo class="bg-color-card-title green--text">
          <v-icon :color="iconColor.unSchedule" small>
            mdi-checkbox-blank-circle
          </v-icon>
              &nbsp; {{ labels.unSchTabeleTitle }} ({{ unscheduledTableData.length }})&nbsp;
          <v-btn
            text
            :disabled="unscheduledTableData.length === 0"
            color="primary"
            class="text-lowercase"
            style="margin-right:4%"
            @click.prevent="openTableView(unscheduledTableHeaders, labels.unSchTabeleTitle, unscheduledTableData, titleColor.unSchedule, iconColor.unSchedule, unScheduledLoading, singleExpand, showExpand = false, value = '')"
          >
            <b>view all</b>
          </v-btn>
        </v-card-title>
        <table-card
          :headers="unscheduledTableHeaders"
          :items="unscheduledTableData"
          :label="labels.unSchTabeleTitle"
          :title-color="titleColor.unSchedule"
          :icon-color="iconColor.unSchedule"
          :items-per-page="5"
          :sort-by="['name']"
          :sort-desc="false"
          :loading="unScheduledLoading"
          :loading-text="loadingText"
          :show-expand="false"
          :hide-default-footer="unscheduledTableData.length ? false : true"
          class="h-full"
        />
      </v-col>
      <v-col cols="6" class="resourceDMainTableWrp fullyScheduledResDasboardWrp">
        <v-card-title solo class="bg-color-card-title yellow--text text--darken-3">
          <v-icon :color="iconColor.fullySch" small>
            mdi-checkbox-blank-circle
          </v-icon>
            &nbsp; {{ labels.fullySchTabeleTitle }} ({{ fullyScheduledTableData.length }})&nbsp;
          <v-btn
            text
            :disabled="fullyScheduledTableData.length === 0"
            color="primary"
            class="text-lowercase"
            style="margin-right:4%"
            @click.prevent="openTableView(overScheduledTableHeaders, labels.fullySchTabeleTitle, fullyScheduledTableData, titleColor.fullySch, iconColor.fullySch, fullyScheduledLoading,
                                          singleExpand = true, showExpand = true, value = values.fully)"
          >
            <b>view all</b>
          </v-btn>
        </v-card-title>
        <table-card
          :headers="overScheduledTableHeaders"
          :items="fullyScheduledTableData"
          :label="labels.fullySchTabeleTitle"
          :title-color="titleColor.fullySch"
          :icon-color="iconColor.fullySch"
          :items-per-page="5"
          :sort-by="['name']"
          :sort-desc="false"
          :loading="fullyScheduledLoading"
          :loading-text="loadingText"
          :show-expand="true"
          :single-expand="singleExpand"
          :value="values.fully"
          :hide-default-footer="fullyScheduledTableData.length ? false : true"
          class="h-full"
        />
      </v-col>
      <v-col cols="6" class="resourceDMainTableWrp partiallyScheduledResDasboardWrp">
        <v-card-title solo class="bg-color-card-title blue--text">
          <v-icon :color="iconColor.partiallySch" small>
            mdi-checkbox-blank-circle
          </v-icon>
            &nbsp; {{ labels.partiallySchTabelTitle }} ({{ partiallyScheduledTableData.length }})&nbsp;
          <v-btn
            text
            :disabled="partiallyScheduledTableData.length === 0"
            color="primary"
            class="text-lowercase"
            style="margin-right:4%"
            @click.prevent="openTableView(overScheduledTableHeaders, labels.partiallySchTabelTitle, partiallyScheduledTableData, titleColor.partiallySch, iconColor.partiallySch, partiallyScheduledLoading,
                                          singleExpand = true, showExpand = true, value = values.partially)"
          >
            <b>view all</b>
          </v-btn>
        </v-card-title>
        <table-card
          :headers="overScheduledTableHeaders"
          :items="partiallyScheduledTableData"
          :label="labels.partiallySchTabelTitle"
          :title-color="titleColor.partiallySch"
          :icon-color="iconColor.partiallySch"
          :items-per-page="5"
          :sort-by="['name']"
          :sort-desc="false"
          :loading="partiallyScheduledLoading"
          :loading-text="loadingText"
          :show-expand="true"
          :single-expand="singleExpand"
          :value="values.partially"
          :hide-default-footer="partiallyScheduledTableData.length ? false : true"
          class="h-full"
        />
      </v-col>
      <v-col cols="6" class="resourceDMainTableWrp overScheduledResDasboardWrp">
        <v-card-title solo class="bg-color-card-title red--text">
          <v-icon :color="iconColor.overSch" small>
            mdi-checkbox-blank-circle
          </v-icon>
            &nbsp; {{ labels.overSchTabeleTitle }} ({{ overScheduledTableData.length }})&nbsp;
          <v-btn
            text
            :disabled="overScheduledTableData.length === 0"
            color="primary"
            class="text-lowercase"
            style="margin-right:4%"
            @click.prevent="openTableView(overScheduledTableHeaders, labels.overSchTabeleTitle, overScheduledTableData, titleColor.overSch, iconColor.overSch, overScheduledLoading,
                                          singleExpand = true, showExpand = true, value = values.over)"
          >
            <b>view all</b>
          </v-btn>
        </v-card-title>
        <table-card
          :headers="overScheduledTableHeaders"
          :items="overScheduledTableData"
          :label="labels.overSchTabeleTitle"
          :title-color="titleColor.overSch"
          :icon-color="iconColor.overSch"
          :items-per-page="5"
          :sort-by="['name']"
          :sort-desc="false"
          :loading="overScheduledLoading"
          :loading-text="loadingText"
          :show-expand="true"
          :single-expand="singleExpand"
          :value="values.over"
          :hide-default-footer="overScheduledTableData.length ? false : true"
          class="h-full"
        />
      </v-col>
    </v-row>
    <div v-else-if="showResourceUtilization" class="requisitionOuterWrp">
      <v-row class="mb-1">
        <v-col cols="12" md="6" xl="6" class="dashboardHeading">
          <h1>Resource Utilization</h1>
        </v-col>
        <v-col cols="12" md="6" xl="6" class="text-right">
          <v-btn
            class="downloadReportBtn"
            small
            rounded
            @click="resourceUtilizatilonReport"
          >
            Download Report
            <v-icon>mdi-download</v-icon>
          </v-btn>
        </v-col>
      </v-row>
      <v-card>
        <v-chip-group
          v-model="chipType"
          mandatory
          active-class="blue darken-2 white--text"
          column
          class="reuisitionTabeWrp"
        >
          <div class="tabeWrp">
            <div class="tabeOtpWrp">
              <div v-for="(chip, index) in chipTypes" :key="index">
                <v-chip
                  :value="chip.id"
                  @click="changeResourceUtilizationView(chip.id)"
                >
                  {{ chip.name }}
                </v-chip>
              </div>
            </div>
          </div>
        </v-chip-group>
        <div v-if="chipType===1">
          <resource-utilization-view
            :utilization-table-data="optimallyUtilized"
            :percentage="utilizationOverView.optimallyUtilizedCount"
            :inner-lable="'Optimally Utilized'"
            :series="[utilizationOverView.optimallyUtilizedCountPercentage]"
            :color="color.optimallyColor"
            :filler="filler.optimallyFiller"
          />
        </div>
        <div v-else-if="chipType===2">
          <resource-utilization-view
            :utilization-table-data="overUtilized"
            :percentage="utilizationOverView.overUtilizedCount"
            :inner-lable="'Over Utilized'"
            :series="[utilizationOverView.overUtilizedCountPercentage]"
            :color="color.overColor"
            :filler="filler.overFiller"
          />
        </div>
        <div v-else-if="chipType===3">
          <resource-utilization-view
            :utilization-table-data="underUtilized"
            :percentage="utilizationOverView.underUtilizedCount"
            :inner-lable="'Under Utilized'"
            :series="[utilizationOverView.underUtilizedCountPercentage]"
            :color="color.underColor"
            :filler="filler.underFiller"
          />
        </div>
        <div v-else-if="chipType===4">
          <resource-utilization-view
            :utilization-table-data="benchUtilized"
            :percentage="utilizationOverView.benchCount"
            :inner-lable="'Bench'"
            :series="[utilizationOverView.benchCountPercentage]"
            :color="color.benchColor"
            :filler="filler.benchFiller"
          />
        </div>
      </v-card>
    </div>
    <v-row v-else>
      <v-col cols="12" class="pb-0">
        <div class="breadcrumbWrp">
          <v-row>
            <v-col cols="12" class="pt-0 pb-0">
              <ul>
                <li>{{ roHeading }} <span class="arrow">></span></li>
                <li>
                  <v-btn
                    text
                    @click.prevent="changeView"
                  >
                    {{ detailTableLable.length? detailTableLable: 'Back' }}
                  </v-btn>
                </li>
              </ul>
            </v-col>
          </v-row>
        </div>
      </v-col>
      <v-col cols="12">
        <resource-detail-view
          :headers="detailTableHeader"
          :items="detailTableItems"
          :label="detailTableLable"
          :title-color="detailTableLableColor"
          :icon-color="detailTableIcon"
          :items-per-page="5"
          :sort-by="['name']"
          :sort-desc="false"
          :loading="detailTableLoading"
          :loading-text="loadingText"
          :show-expand="showExpand"
          :single-expand="singleExpand"
          :value="detailTableValue"
          :hide-default-footer="detailTableItems.length ? false : true"
          class="h-full"
        />
      </v-col>
    </v-row>
  </div>
</template>

<script>
import { mapActions, mapGetters } from 'vuex'
import { excelSheet, sortBy } from '@/helpers/helper'
import SourcesCard from '@/components/dashboard/SourcesCard'
import TableCard from '@/components/dashboard/TableCard'
import dashboardConstant from '@/constants/resource-dashboard.js'
import ResourceDetailView from '@/components/dashboard/ResourceDetailView.vue'
import ResourceUtilizationView from '@/components/dashboard/ResourceUtilizationView.vue'

export default {
  layout: 'default',
  middleware: 'authenticated',
  components: { SourcesCard, TableCard, ResourceDetailView, ResourceUtilizationView },
  async fetch ({ store }) {
    // eslint-disable-next-line no-useless-catch
    try {
      const requestParams = {
        'startDate': '',
        'endDate': '',
        'location': 'All',
        'department': '',
        'availability': 'All',
        'name': '',
        'billing': '',
        'project': '',
        'exclude_trainee': false
      }

      await Promise.all([
        store.dispatch('dashboard/fetchResourceDataForDownload', requestParams),
        // await store.dispatch('dashboard/fetchResourceUtilizationSummary', requestParams)
        store.dispatch('project/fetchProjectBillingTypes'),
        store.dispatch('project/fetchProjectNames'),
        store.dispatch('roles/fetchGlobalRole'),
        store.dispatch('project/fetchUserList')
      ])
    } catch (error) {
      throw (error)
    }
  },
  data () {
    return {
      selectedReport: '',
      reports: [
        { id: '1', name: 'All resources report', pl: 'pl-3' },
        { id: '2', name: 'Bench report',  pl: 'pl-8' }
      ],
      fromDateMenu: false,
      fromDatePicker: new Date().toISOString().substr(0, 10),
      toDatePicker: new Date().toISOString().substr(0, 10),
      toDateMenu: false,
      fromDateString: new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
      toDateString: new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
      excludeTrainee: false,
      roHeading:'Resource Overview',
      overview: 'Overview',
      utilize: 'Utilization',
      overviewLabels: ['Unscheduled', 'Fully Scheduled', 'Partially Scheduled', 'Over Scheduled'],
      utilizeLabels: ['Optimally Utilized', 'Over Utilized', 'Under-Utilized', 'Bench'],
      overviewColors: ['#66bb6a', '#e7b223', '#4393d4', '#ec6666', '#ea7317'],
      overviewFill: {
        colors: ['#66bb6a', '#e7b223', '#4393d4', '#ec6666', '#ea7317']
      },
      utilizeColors: ['#3fa107', '#FEAD4F', '#77CFD5', '#F6C301', '#ec6666'],
      utilizeFill: {
        colors: ['#3fa107', '#FEAD4F', '#77CFD5', '#F6C301', '#ec6666']
      },
      titleColor: dashboardConstant.TITLE_COLOR,
      iconColor: dashboardConstant.ICON_COLOR,
      labels: dashboardConstant.LABLES,
      values: dashboardConstant.VALUES,
      departmentSelected: '',
      locationSelected: 'All',
      overlay: false,
      name: '',
      loadingSkeletonForPartially: false,
      loadingSkeletonForFully: false,
      loadingSkeletonForOver: false,
      transition: 'scale-transition',
      loadingText: 'Loading... Please wait a moment',
      singleExpand: true,
      unScheduledLoading: false,
      fullyScheduledLoading: false,
      partiallyScheduledLoading: false,
      overScheduledLoading: false,
      unscheduledTableHeaders: [
        { text: 'Resource', value: 'name' },
        { text: 'Location', value: 'location' },
        { text: 'Department', value: 'department' },
        { text: 'Experience', value: 'experience' },
        { text: 'From', value: 'startDate' },
        { text: 'To', value: 'endDate' }
      ],
      overScheduledTableHeaders: [
        { text: 'Resource', value: 'name' },
        { text: 'Location', value: 'location' },
        { text: 'Department', value: 'department' },
        { text: 'Experience', value: 'experience' },
        { text: 'From', value: 'startDate' },
        { text: 'To', value: 'endDate' },
        { text: 'Sch. Hrs.', value: 'total' }
      ],
      nameRules: [
        (v) => !!v || 'Field is required'
      ],
      selectedProjectName: '',
      selectedProjectBillingType: '',
      billingTypeArray: [],
      projectNameArray: [],
      showExpand: false,
      detailTableHeader: [],
      detailTableItems: [],
      detailTableLable: '',
      detailTableIcon: '',
      detailTableLableColor: '',
      detailTableLoading: false,
      detailTableValue: '',
      detailsTableProjectDetails: [],
      selectedAllFiltersArray: [],
      selectedFilteredArray: [],
      selectedResourceName: '',
      resourceList: [],
      showFilters: true,
      color: {
        optimallyColor: ['#66bb6a'],
        overColor: ['#ec6666'],
        underColor: ['#4393d4'],
        benchColor: ['#e7b223']
      },
      filler: {
        optimallyFiller: {
          colors: ['#66bb6a']
        },
        overFiller: {
          colors: ['#ec6666']
        },
        underFiller: {
          colors: ['#4393d4']
        },
        benchFiller: {
          colors: ['#e7b223']
        }
      },
      chipTypes: [{
        name: 'Optimally Utilized',
        id: 1
      },
      {
        name: 'Over Utilized',
        id: 2
      },
      {
        name: 'Under Utilized',
        id: 3
      },
      {
        name: 'Bench',
        id: 4
      }],
      chipType: 1,
      showResourceUtilization: false
    }
  },
  computed: {
    ...mapGetters({
      locations: 'dashboard/locations',
      changeTableView: 'theme/changeTableView',
      departments: 'dashboard/departments',
      unscheduledTableData: 'dashboard/unscheduledDownload',
      benchReportData:'dashboard/benchReportData',
      fullyScheduledTableData: 'dashboard/fullyScheduledDownload',
      partiallyScheduledTableData: 'dashboard/partiallyScheduledDownload',
      overScheduledTableData: 'dashboard/overScheduledDownload',
      technologies: 'project/getTechnologies',
      getDepartments: 'project/getDepartments',
      billingTypes: 'project/getBillingTypes',
      users: 'project/getUserList',
      projectTypes: 'project/getProjectType',
      governanceCategories: 'project/getGovernanceCategories',
      getGlobalRole: 'roles/getGlobalRole',
      availableRoles: 'roles/availableRoles',
      getProjectNames: 'project/getProjectNames',
      getProjectBillingTypes: 'project/getProjectBillingTypes',
      billingMediums: 'project/getBillingMediums',
      utilizationOverView: 'dashboard/utilizationOverView',
      benchUtilized: 'dashboard/benchUtilized',
      optimallyUtilized: 'dashboard/optimallyUtilized',
      overUtilized: 'dashboard/overUtilized',
      underUtilized: 'dashboard/underUtilized',
      getTimesheetSummary: 'dashboard/getTimesheetSummary',
      getResourceSummary: 'dashboard/getResourceSummary',
      getInvoiceSummary: 'dashboard/getInvoiceSummary'
    }),
    filteredElements () {
      const allFilters = []

      if (this.departmentSelected) {
        this.departmentSelected.some((item) => {
          allFilters.push({ value: item, key: 1 })
        })
      }
      if (this.selectedProjectBillingType) {
        this.selectedProjectBillingType.some((item) => {
          allFilters.push({ value: item, key: 2 })
        })
      }
      if (this.selectedProjectName) {
        this.selectedProjectName.some((item) => {
          allFilters.push({ value: item, key: 3 })
        })
      }
      if (this.selectedResourceName) {
        this.selectedResourceName.some((item) => {
          allFilters.push({ value: item, key: 4 })
        })
      }

      return allFilters
    }
  },
  created () {
    this.fetchLists()
  },
  mounted () {
    // this.fetchLists()
    this.projectNameArray = this.getProjectNames
    this.billingTypeArray = this.getProjectBillingTypes
    this.resourceList = this.users
  },
  methods: {
    ...mapActions({
      fetchDashboardDepartments: 'dashboard/fetchDepartments',
      fetchResourceDataForDownload: 'dashboard/fetchResourceDataForDownload',
      resetSectionData: 'dashboard/resetSectionData',
      fetchLocations: 'dashboard/fetchLocations',
      fetchDepartments: 'project/fetchDepartments',
      fetchGlobalRole: 'roles/fetchGlobalRole',
      fetchTechnologies: 'project/fetchTechnologies',
      fetchBillingTypes: 'project/fetchBillingTypes',
      fetchUserList: 'project/fetchUserList',
      fetchProjectType: 'project/fetchProjectType',
      fetchGovernanceCategories: 'project/fetchGovernanceCategories',
      fetchAllRoles: 'roles/fetchAllRoles',
      fetchProjectNames: 'project/fetchProjectNames',
      fetchProjectBillingTypes: 'project/fetchProjectBillingTypes',
      setChangeTableView: 'theme/setChangeTableView',
      fetchBillingMediums: 'project/fetchBillingMediums',
      fetchResourceUtilizationSummary: 'dashboard/fetchResourceUtilizationSummary'
    }),
    changeView() {
      this.setChangeTableView(true)
    },
    changeFromDateString (selected) {
      this.fromDateString = new Date(selected).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      })
      this.toDatePicker = selected
      this.toDateString = this.fromDateString
    },
    changeToDateString (selected) {
      this.toDateString = new Date(selected).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      })
    },
    onChangeToUtilization () {
      if (!this.showResourceUtilization) {
        this.showResourceUtilization = true
      }
    },
    onChangeToOverview () {
      if (this.showResourceUtilization) {
        this.showResourceUtilization = false
      }
    },
    changeResourceUtilizationView (selected) {
      this.chipType = selected
    },
    fetchLists () {
      this.fetchTechnologies()
      if (this.locations.length <= 1) {
        this.fetchLocations()
      }
      if (this.departments.length <= 1) {
        this.fetchDashboardDepartments()
      }
      if (this.getDepartments.length === 0) {
        this.fetchDepartments()
      }
      if (this.billingTypes.length === 0) {
        this.fetchBillingTypes()
      }
      if (this.projectTypes.length === 0) {
        this.fetchProjectType()
      }
      if (this.governanceCategories.length === 0) {
        this.fetchGovernanceCategories()
      }
      if (this.availableRoles.length === 0) {
        this.fetchAllRoles()
      }
      if (this.billingMediums.length === 0) {
        this.fetchBillingMediums()
      }
      const redmineProjectIds = []

      this.getProjectNames.forEach((element) => {
        if (element.id !== null) {
          redmineProjectIds.push(element.id)
        }
      })
    },
    getInitialEndDate () {
      const endDate = new Date()
      const formattedDate = endDate.toLocaleDateString({ year: 'numeric', month: 'numeric', day: 'numeric' })
      const formattedStringDate = endDate.toISOString().substr(0, 10)

      return { formattedDate, formattedStringDate }
    },
    removeFilter (tag) {
      const idx = this.filteredElements.indexOf(tag)

      if (this.filteredElements) {
        this.filteredElements.splice(idx, 1)
        if (this.selectedProjectName && tag.key === 3) {
          const index = this.selectedProjectName.indexOf(tag.value)

          this.selectedProjectName.splice(index, 1)
        }
        if (this.selectedProjectBillingType && tag.key === 2) {
          const index = this.selectedProjectBillingType.indexOf(tag.value)

          this.selectedProjectBillingType.splice(index, 1)
          this.filterProjectNameArray(this.selectedProjectBillingType)
        }
        if (this.selectedResourceName && tag.key === 4) {
          const index = this.selectedResourceName.indexOf(tag.value)

          this.selectedResourceName.splice(index, 1)
        }
        if (this.departmentSelected && tag.key === 1) {
          const index = this.departmentSelected.indexOf(tag.value)

          this.departmentSelected.splice(index, 1)
          this.filteredResourceName(this.departmentSelected)
        }
      }
      if (this.filteredElements.length <= 0) {
        this.showFilters = true
      }
      this.selectedProjectName = [...this.selectedProjectName]
      this.departmentSelected = [...this.departmentSelected]
      this.selectedProjectBillingType = [...this.selectedProjectBillingType]
      this.selectedResourceName = [...this.selectedResourceName]
      // this.filteredElements = [...this.filteredElements]
    },
    openTableView (header, title, data, titleColor, iconColor, loading, singleExpand = false, showExpand = false, value) {
      this.setChangeTableView(false)
      this.detailTableHeader = header
      this.detailTableItems = data
      this.detailTableLable = title
      this.detailTableLableColor = titleColor
      this.detailTableIcon = iconColor
      this.detailTableLoading = loading
      this.singleExpand = singleExpand
      this.showExpand = showExpand
      this.detailTableValue = value
    },
    filterProjectNameArray (projectBillingType) {
      if (projectBillingType) {
        const billingType = []

        this.billingTypeArray.filter((item) => {
          if (projectBillingType.includes(item.name)) {
            billingType.push(item.id.toString())
          }
        })
        if (billingType.length > 0) {
          this.projectNameArray = this.getProjectNames.filter((item) => {
            if (billingType.includes(item.user_projects.value)) {

              return item
            }
          })
        } else {
          this.projectNameArray = this.getProjectNames
        }
      }
    },
    onlyUnique (value, index, self) {
      return self.indexOf(value) === index
    },
    filteredResourceName (department) {
      const departmentArray = []

      department.forEach((item) => departmentArray.push(item.toLowerCase()))
      if (departmentArray.length > 0) {
        this.resourceList = this.users.filter((user) => user.dept.length !== 0 && user.dept.some((value) => departmentArray.includes(value.name.toLowerCase())))
      } else {
        this.resourceList = this.users
      }
    },
    setDepartmentToDefault () {
      this.selectedAllFiltersArray.push({
        key: 'project',
        value: this.selectedProjectName
      })
    },
    setResourceNameDefault () {
      this.selectedAllFiltersArray.push({
        key: 'name',
        value: this.selectedResourceName
      })
    },
    async reset () {
      this.overlay = true
      this.toDatePicker = new Date().toISOString().substr(0, 10)
      this.fromDatePicker = new Date().toISOString().substr(0, 10)
      this.fromDateString = new Date(this.fromDatePicker).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      })
      this.toDateString = new Date(this.toDatePicker).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      })

      this.excludeTrainee = false
      this.projectNameArray = this.getProjectNames
      this.billingTypeArray = this.getProjectBillingTypes
      this.resourceList = this.users
      this.showFilters = true
      this.locationSelected = 'All'
      this.departmentSelected = ''
      this.selectedProjectName = ''
      this.selectedProjectBillingType = ''
      this.selectedResourceName = ''
      const requestParams = {
        'startDate': '',
        'endDate': '',
        'location': this.locationSelected,
        'department': this.departmentSelected,
        'billing': this.selectedProjectBillingType,
        'project': this.selectedProjectName,
        'exclude_trainee': this.excludeTrainee,
        'availability': 'All',
        'name': this.selectedResourceName
      }

      await this.fetchResourceDataForDownload(requestParams)
      // await this.fetchResourceUtilizationSummary(requestParams)
      this.overlay = false
    },
    async searchWithFilters () {
      this.overlay = true
      const billingTypeIds = []
      const projectNameIds = []

      this.billingTypeArray.filter((item) => {
        if (this.selectedProjectBillingType.includes(item.name)) {
          billingTypeIds.push(item.id)
        }
      })
      this.projectNameArray.filter((item) => {
        if (this.selectedProjectName.includes(item.name)) {
          projectNameIds.push(item.id)
        }
      })
      const requestParams = {
        'startDate': this.fromDatePicker,
        'endDate': this.toDatePicker,
        'location': this.locationSelected,
        'department': this.departmentSelected.length > 0 ? this.departmentSelected : '',
        'billing': this.selectedProjectBillingType.length > 0 ? billingTypeIds : '',
        'project': this.selectedProjectName.length > 0 ? projectNameIds : '',
        'exclude_trainee': this.excludeTrainee,
        'availability': 'All',
        'name': this.selectedResourceName.length > 0 ? this.selectedResourceName : ''
      }

      await this.fetchResourceDataForDownload(requestParams)
      // await this.fetchResourceUtilizationSummary(requestParams)
      this.overlay = false
    },
    async downloadExcel (selectedReport) {
      const billingTypeIds = []
      const projectNameIds = []

      this.billingTypeArray.filter((item) => {
        if (this.selectedProjectBillingType.includes(item.name)) {
          billingTypeIds.push(item.id)
        }
      })
      this.projectNameArray.filter((item) => {
        if (this.selectedProjectName.includes(item.name)) {
          projectNameIds.push(item.id)
        }
      })

      const requestParams = {
        'startDate': this.fromDatePicker,
        'endDate': this.toDatePicker,
        'location': this.locationSelected,
        'department': this.departmentSelected.length > 0 ? this.departmentSelected : '',
        'billing': this.selectedProjectBillingType.length > 0 ? billingTypeIds : '',
        'project': this.selectedProjectName.length > 0 ? projectNameIds : '',
        'exclude_trainee': this.excludeTrainee,
        'availability': 'All',
        'name': this.selectedResourceName.length > 0 ? this.selectedResourceName : ''
      }

      await this.fetchResourceDataForDownload(requestParams)
      /* create new workbook */
      const dataForExcel = []
      const unscheduledExcelData = []
      const partiallySchExcelData = []
      const fullySchExcelData = []
      const benchExcelData = []

      this.unscheduledTableData.map((tableData) => {
        const rowData = {
          name: tableData.name,
          emp_code: tableData.empcode,
          experience: tableData.experience,
          location: tableData.location,
          dept: tableData.department,
          from: tableData.startDate,
          to: tableData.endDate
        }

        unscheduledExcelData.push(rowData)
      })
      this.benchReportData.map((tableData) => {
        const rowData = {
          resource_name: tableData.name,
          location: tableData.location,
          bu: tableData.department,
          total_experience: tableData.experience,
          available_hours: tableData.availableHours,
          from: tableData.startDate,
          to: tableData.endDate
        }

        benchExcelData.push(rowData)
      })

      this.overScheduledTableData.map((tableData) => {
        if (tableData.projectInfo.length > 1) {
          tableData.projectInfo.map((project, index) => {
            let rowData = {
              name: tableData.name,
              emp_code: tableData.empcode,
              experience: tableData.experience,
              location: tableData.location,
              dept: tableData.department,
              from: tableData.startDate,
              to: tableData.endDate,
              projects: project.projectName,
              sch_hrs: project.hours
            }

            if (index > 0) {
              rowData = {
                name: tableData.name,
                emp_code: tableData.empcode,
                experience: tableData.experience,
                location: tableData.location,
                dept: tableData.department,
                from: tableData.startDate,
                to: tableData.endDate,
                projects: project.projectName,
                sch_hrs: project.hours
              }
            }

            dataForExcel.push(rowData)
          })
        }

        if (tableData.projectInfo.length === 1) {
          const rowData = {
            name: tableData.name,
            emp_code: tableData.empcode,
            experience: tableData.experience,
            location: tableData.location,
            dept: tableData.department,
            from: tableData.startDate,
            to: tableData.endDate,
            projects: tableData.projectInfo[0].projectName,
            sch_hrs: tableData.projectInfo[0].hours
          }

          dataForExcel.push(rowData)
        }
      })

      this.partiallyScheduledTableData.map((tableData) => {
        if (tableData.projectInfo.length > 1) {
          tableData.projectInfo.map((project, index) => {
            let rowData = {
              name: tableData.name,
              emp_code: tableData.empcode,
              experience: tableData.experience,
              location: tableData.location,
              dept: tableData.department,
              from: tableData.startDate,
              to: tableData.endDate,
              projects: project.projectName,
              sch_hrs: project.hours
            }

            if (index > 0) {
              rowData = {
                name: tableData.name,
                emp_code: tableData.empcode,
                experience: tableData.experience,
                location: tableData.location,
                dept: tableData.department,
                from: tableData.startDate,
                to: tableData.endDate,
                projects: project.projectName,
                sch_hrs: project.hours
              }
            }

            partiallySchExcelData.push(rowData)
          })
        }

        if (tableData.projectInfo.length === 1) {
          const rowData = {
            name: tableData.name,
            emp_code: tableData.empcode,
            experience: tableData.experience,
            location: tableData.location,
            dept: tableData.department,
            from: tableData.startDate,
            to: tableData.endDate,
            projects: tableData.projectInfo[0].projectName,
            sch_hrs: tableData.projectInfo[0].hours
          }

          partiallySchExcelData.push(rowData)
        }
      })

      this.fullyScheduledTableData.map((tableData) => {
        if (tableData.projectInfo.length > 1) {
          tableData.projectInfo.map((project, index) => {
            let rowData = {
              name: tableData.name,
              emp_code: tableData.empcode,
              experience: tableData.experience,
              location: tableData.location,
              dept: tableData.department,
              from: tableData.startDate,
              to: tableData.endDate,
              projects: project.projectName,
              sch_hrs: project.hours
            }

            if (index > 0) {
              rowData = {
                name: tableData.name,
                emp_code: tableData.empcode,
                experience: tableData.experience,
                location: tableData.location,
                dept: tableData.department,
                from: tableData.startDate,
                to: tableData.endDate,
                projects: project.projectName,
                sch_hrs: project.hours
              }
            }

            fullySchExcelData.push(rowData)
          })
        }

        if (tableData.projectInfo.length === 1) {
          const rowData = {
            name: tableData.name,
            emp_code: tableData.empcode,
            experience: tableData.experience,
            location: tableData.location,
            dept: tableData.department,
            from: tableData.startDate,
            to: tableData.endDate,
            projects: tableData.projectInfo[0].projectName,
            sch_hrs: tableData.projectInfo[0].hours
          }

          fullySchExcelData.push(rowData)
        }
      })
      const header1 = ['name', 'emp_code', 'location', 'experience','dept', 'from', 'to', 'projects', 'sch_hrs']
      const header2 = ['name', 'emp_code', 'location', 'experience','dept', 'from', 'to']
      const header3 = ['name', 'emp_code', 'location', 'experience','dept', 'from', 'to', 'projects', 'sch_hrs']
      const header4 = ['name', 'emp_code', 'location', 'experience','dept', 'from', 'to', 'projects', 'sch_hrs']
      const header5 = ['resource_name', 'location', 'bu', 'total_experience',  'available_hours', 'from', 'to']

      dataForExcel.sort(sortBy.sortByKey('name', false, (a) =>  a.toUpperCase()))
      unscheduledExcelData.sort(sortBy.sortByKey('name', false, (a) =>  a.toUpperCase()))
      partiallySchExcelData.sort(sortBy.sortByKey('name', false, (a) =>  a.toUpperCase()))
      fullySchExcelData.sort(sortBy.sortByKey('name', false, (a) =>  a.toUpperCase()))
      benchExcelData.sort(sortBy.sortByKey('resource_name', false, (a) =>  a.toUpperCase()))
      if (selectedReport === '1') {
        const allReportExcelParams = {
          'sheetData': [dataForExcel, unscheduledExcelData, partiallySchExcelData, fullySchExcelData],
          'headers': [header1, header2, header3, header4],
          'sheetName': ['Over-Scheduled', 'Un-Scheduled', 'Partially-Scheduled', 'Fully-Scheduled'],
          'fileName': 'all-resource-report.xls'
        }

        excelSheet.createExcelSheet(allReportExcelParams)
        this.selectedReport = ''
      } else if (selectedReport === '2') {
        const traineeReportExcelParams = {
          'sheetData': [benchExcelData],
          'headers': [header5],
          'sheetName': ['Bench Resource Sheet'],
          'fileName': 'bench-resource-report.xls'
        }

        excelSheet.createExcelSheet(traineeReportExcelParams)
        this.selectedReport = ''
      }
    },
    async resourceUtilizatilonReport () {
      const billingTypeIds = []
      const projectNameIds = []

      this.billingTypeArray.filter((item) => {
        if (this.selectedProjectBillingType.includes(item.name)) {
          billingTypeIds.push(item.id)
        }
      })
      this.projectNameArray.filter((item) => {
        if (this.selectedProjectName.includes(item.name)) {
          projectNameIds.push(item.id)
        }
      })

      const requestParams = {
        'startDate': this.fromDatePicker,
        'endDate': this.toDatePicker,
        'location': this.locationSelected,
        'department': this.departmentSelected.length > 0 ? this.departmentSelected : '',
        'billing': this.selectedProjectBillingType.length > 0 ? billingTypeIds : '',
        'project': this.selectedProjectName.length > 0 ? projectNameIds : '',
        'exclude_trainee': this.excludeTrainee,
        'availability': 'All',
        'name': this.selectedResourceName.length > 0 ? this.selectedResourceName : ''
      }

      await this.fetchResourceUtilizationSummary(requestParams)
      /* create new workbook */
      const benchUtilizedExcel = []
      const underUtilizedExcel = []
      const overUtilizedExcel = []
      const optimallyUtilizedExcel = []

      this.underUtilized.map((tableData) => {
        const rowData = {
          name: tableData.name,
          project_name: tableData.projectName,
          department: tableData.department,
          from: tableData.startDate,
          to: tableData.endDate,
          utilization: tableData.utilizationPercentage
        }

        underUtilizedExcel.push(rowData)
      })

      this.overUtilized.map((tableData) => {
        const rowData = {
          name: tableData.name,
          project_name: tableData.projectName,
          department: tableData.department,
          from: tableData.startDate,
          to: tableData.endDate,
          utilization: tableData.utilizationPercentage
        }

        overUtilizedExcel.push(rowData)
      })

      this.optimallyUtilized.map((tableData) => {
        const rowData = {
          name: tableData.name,
          project_name: tableData.projectName,
          department: tableData.department,
          from: tableData.startDate,
          to: tableData.endDate,
          utilization: tableData.utilizationPercentage
        }

        optimallyUtilizedExcel.push(rowData)
      })

      this.benchUtilized.map((tableData) => {
        const rowData = {
          name: tableData.name,
          project_name: tableData.projectName,
          department: tableData.department,
          from: tableData.startDate,
          to: tableData.endDate,
          utilization: tableData.utilizationPercentage
        }

        benchUtilizedExcel.push(rowData)
      })
      const header1 = ['name', 'project_name', 'department', 'from', 'to', 'utilization']
      const header2 = ['name', 'project_name', 'department', 'from', 'to', 'utilization']
      const header3 = ['name', 'project_name', 'department', 'from', 'to', 'utilization']
      const header4 = ['name', 'project_name', 'department', 'from', 'to', 'utilization']

      benchUtilizedExcel.sort(sortBy.sortByKey('name', false, (a) =>  a.toUpperCase()))
      underUtilizedExcel.sort(sortBy.sortByKey('name', false, (a) =>  a.toUpperCase()))
      optimallyUtilizedExcel.sort(sortBy.sortByKey('name', false, (a) =>  a.toUpperCase()))
      overUtilizedExcel.sort(sortBy.sortByKey('name', false, (a) =>  a.toUpperCase()))

      const excelParams = {
        'sheetData': [benchUtilizedExcel, underUtilizedExcel, optimallyUtilizedExcel, overUtilizedExcel],
        'headers': [header1, header2, header3, header4],
        'sheetName': ['bench', 'Un-Utilized', 'Otimally-Utilized', 'Over-Utilized'],
        'fileName': 'new-workbook.xls'
      }

      excelSheet.createExcelSheet(excelParams)
    }
  }
}
</script>
<style scoped>
.theme--light.v-input.DownloadReportBtn {
    width: 165px;
    border-radius: 19px;
    color: #607d8b;
    font-family: "ProductSans";
    font-size: 14px;
    font-weight: 400;
    font-style: normal;
    letter-spacing: normal;
    line-height: normal;
    border: 0;
    margin: -7px 0 0 auto;
}

.theme--light.v-input.DownloadReportBtn .v-input__slot fieldset {
    border: 0;
    box-shadow: 0 3px 8px rgba(0, 0, 0, 0.08);
    background: #f6f7f9;
}

.theme--light.v-input input, .theme--light.v-input textarea {
    font-size: small !important;
    padding-left: 5px;
}
.v-input .v-label {
    font-size: small !important;
    padding-left: 5px;
}
.v-text-field--filled.v-input--dense > .v-input__control > .v-input__slot, .v-text-field--full-width.v-input--dense > .v-input__control > .v-input__slot, .v-text-field--outlined.v-input--dense > .v-input__control > .v-input__slot {
    min-height: 10px;
    height: 40px;
    background: white;
}
.bg-color {
    background: #f2f5f8 !important;
}
.v-text-field--rounded > .v-input__control > .v-input__slot {
    padding: 0 10px;
}
.bg-color-card-title {
    background:white !important;
}
.scroll-box {
  overflow-y: auto;
  height: 320px;
  min-width: 43%;
  overflow-x: hidden;
  width: 44%;
}
.content {
  height: fit-content;
  overflow: auto;
  overflow-x: hidden;
}
</style>
