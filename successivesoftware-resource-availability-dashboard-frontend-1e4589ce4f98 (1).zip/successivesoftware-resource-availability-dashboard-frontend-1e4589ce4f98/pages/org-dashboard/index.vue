<template>
  <div id="orgdashboard">
    <div id="dashboard">
      <div class="dashboardHeading">
        <h1>Organization Dashboard</h1>
      </div>
      <div class="cardsBox">
        <v-row class="mt-0">
          <v-col
            cols="3"
            class="pr-2"
          >
            <ProjectInvoiceStatus
              :get-invoice-data="getInvoiceData"
              :is-quick-table-data="isQuickTable"
            />
          </v-col>
          <v-col
            cols="3"
            class="pl-2 pr-2"
          >
            <ProjectDifferentPhases
              :project-effort-serise="projectEffortSerise"
            />
          </v-col>
          <v-col cols="6">
            <ProjectRAGStatus />
          </v-col>
        </v-row>
        <v-row class="mt-1">
          <v-col
            cols="3"
            class="pr-2"
          >
            <TopProject :get-top-project-data="getTopProjectData" />
          </v-col>
          <v-col cols="6" class="pr-2 pl-2">
            <PMRAGStatus />
          </v-col>
          <v-col cols="3" class="pl-2">
            <NewProjectKiffOff
              :get-new-project-kiff-off="newProjectKiffOffArr"
            />
          </v-col>
        </v-row>
        <v-row class="mt-1">
          <v-col
            cols="3"
            class="pr-2"
          >
            <ProjectRAGStatusPie />
          </v-col>
          <v-col cols="9" class="pl-2">
            <Risks />
          </v-col>
        </v-row>
        <v-row class="mt-1">
          <v-col
            cols="4"
            class="pr-2"
          >
            <AccountRagStatus :get-account-rag-status="getAccountRagStatus" />
          </v-col>
          <v-col
            cols="4"
            class="pr-2 pl-2"
          >
            <ProjectAtRisk :get-project-at-risk="projectAtRisk"/>
          </v-col>
          <v-col cols="4">
            <NewCollaboration
              :get-new-collaboration="newCollaborationArr"
            />
          </v-col>
        </v-row>
      </div>
    </div>
  </div>
</template>
<script>
import { mapActions, mapGetters } from 'vuex'
import constant from '@/constants/closure-checklist.js'
import ProjectInvoiceStatus from '@/components/orgDashboard/ProjectInvoiceStatus.vue'
import ProjectDifferentPhases from '@/components/orgDashboard/ProjectDifferentPhases.vue'
import ProjectRAGStatus from '@/components/orgDashboard/ProjectRAGStatus.vue'
import ProjectRAGStatusPie from '@/components/orgDashboard/ProjectRAGStatusPie.vue'
import TopProject from '@/components/orgDashboard/TopProject.vue'
import PMRAGStatus from '@/components/orgDashboard/PMRAGStatus.vue'
import AccountRagStatus from '@/components/orgDashboard/AccountRagStatus.vue'
import NewProjectKiffOff from '@/components/orgDashboard/NewProjectKiffOff.vue'
import ProjectAtRisk from '@/components/orgDashboard/ProjectAtRisk.vue'
import Risks from '@/components/orgDashboard/Risks.vue'
import NewCollaboration from '@/components/orgDashboard/NewCollaboration.vue'

export default {
  name: 'Index',
  components: {
    ProjectRAGStatus,
    PMRAGStatus,
    ProjectInvoiceStatus,
    Risks,
    ProjectRAGStatusPie,
    ProjectDifferentPhases,
    AccountRagStatus,
    ProjectAtRisk,
    NewCollaboration,
    NewProjectKiffOff,
    TopProject
  },
  layout: 'authenticated',
  middleware: 'authenticated',

  data() {
    return {
      wsrStatusArray: [],
      projectWSRData: [],
      projectAtRiskCount: '',
      allProjectActiveRiskCount: '',
      projectWiseWSRData: [],
      ProjectFilterList: [],
      projectList: [],
      cards: [],
      newCount: 0,
      draftCount: 0,
      onGoingCount: 0,
      holdCount: 0,
      colosedCount: 0,
      projectEffortSerise: [],
      getInvoiceData:{},
      getTopProjectData:{},
      newProjectKiffOffArr:{},
      newCollaborationArr:{},
      projectAtRisk:[],
      pmWiseRagStatus:{},
      isQuickTable:[],
      projectWiseRagStatusArr:{},
      yearlyWeeks:{},
      assignedUsers:{}
    }
  },
  computed: {
    ...mapGetters({
      getInvoiceSummary: 'dashboard/getInvoiceSummary',
      getPmWiseRagStatus: 'dashboard/getPmWiseRagStatus',
      getProjectWSRList: 'AmPmDashboard/getProjectWSRList',
      getProjectWiseRagStatus: 'dashboard/getProjectWiseRagStatus',
      getTopProject: 'dashboard/getTopProject',
      getAccountRagStatus: 'dashboard/getAccountRagStatus',
      getNewProjectKiffOff: 'dashboard/getNewProjectKiffOff',
      getRiskData: 'dashboard/getRiskData',
      getProjectNames: 'project/getProjectNameListing',
      getNewCollaboration: 'dashboard/getNewCollaboration',
      getAssignedUsers: 'AmPmDashboard/getAssignedUsers',
      getProjectAtRisk: 'dashboard/getProjectAtRisk',
      getYearlyWeeks: 'AmPmDashboard/getYearlyWeeks',
      getBuWiseProjectRagStatus: 'dashboard/getBuWiseProjectRagStatus'
    })
  },
  watch: {
    getProjectWSRList() {
      this.projectWSRData = this.getProjectWSRList
      this.mutateProjectWSRList(this.projectWSRData)
    }
    ,
    getInvoiceSummary() {
      this.getInvoiceData = this.getInvoiceSummary.data
      this.mutateInvoiceStatus(this.getInvoiceData)
    },
    getTopProject() {
      this.getTopProjectData = this.getTopProject.data
    },
    getNewProjectKiffOff() {
      this.newProjectKiffOffArr = this.getNewProjectKiffOff.data
    },
    getProjectAtRisk() {
      this.projectAtRisk = this.getProjectAtRisk.data
    },
    getNewCollaboration() {
      this.newCollaborationArr = this.getNewCollaboration.data
    },
    getPmWiseRagStatus() {
      this.pmWiseRagStatus = this.getPmWiseRagStatus
    },
    getBuWiseProjectRagStatus() {
      this.projectWiseRagStatusArr = this.getBuWiseProjectRagStatus
    },
    getYearlyWeeks() {
      this.yearlyWeeks = this.getYearlyWeeks
    },
    getAssignedUsers() {
      this.assignedUsers = this.getAssignedUsers
    }
  },
  mounted() {
    this.showChart = true
    this.fetchLists()
    this.getInvoiceData = this.getInvoiceSummary.data
    this.mutateInvoiceStatus(this.getInvoiceData)
    this.getTopProjectData = this.getTopProject.data
    this.newProjectKiffOffArr = this.getNewProjectKiffOff.data
    this.projectAtRisk = this.getProjectAtRisk.data
    this.newCollaborationArr = this.getNewCollaboration.data
    this.pmWiseRagStatus = this.getPmWiseRagStatus
    this.projectWiseRagStatusArr = this.getBuWiseProjectRagStatus
    this.yearlyWeeks = this.getYearlyWeeks
    this.assignedUsers = this.getAssignedUsers
    this.fetchProjectWSRData(), (this.projectWSRData = this.getProjectWSRList)
    this.mutateProjectWSRList(this.projectWSRData)

  },
  methods: {
    ...mapActions({
      fetchProjectWSRData: 'AmPmDashboard/fetchProjectWSRData',
      fetchInvoiceSummary:'dashboard/fetchInvoiceSummary',
      fetchPmWiseRagStatus:'dashboard/fetchPmWiseRagStatus',
      fetchBuWiseProjectRagStatus:'dashboard/fetchBuWiseProjectRagStatus',
      fetchProjectWiseRagStatus:'dashboard/fetchProjectWiseRagStatus',
      fetchTopProject:'dashboard/fetchTopProject',
      fetchAccountRagStatus:'dashboard/fetchAccountRagStatus',
      fetchNewProjectKiffOff:'dashboard/fetchNewProjectKiffOff',
      fetchRiskData:'dashboard/fetchRiskData',
      fetchProjectNameListing:'project/fetchProjectNameListing',
      fetchNewCollaboration:'dashboard/fetchNewCollaboration',
      fetchAssignedUsers:'AmPmDashboard/fetchAssignedUsers',
      fetchProjectAtRisk:'dashboard/fetchProjectAtRisk',
      fetchCategories:'dashboard/fetchCategories',
      fetchWeeks:'AmPmDashboard/fetchWeeks',
      fetchDepartments:'project/fetchDepartments'
    }),

    async fetchLists () {
      const requestParams = {
        'week_no': '',
        'dept_id': '',
        'user_id': '',
        'billing_id': '',
        'category_id': '',
        'project_id': ''
      }

      // eslint-disable-next-line no-useless-catch
      try {
        await Promise.all([

          this.fetchRiskData(requestParams),
          this.fetchProjectWiseRagStatus(requestParams),
          this.fetchBuWiseProjectRagStatus(requestParams),
          this.fetchPmWiseRagStatus(requestParams),
          this.fetchProjectWSRData(),

          this.fetchInvoiceSummary(),
          this.fetchTopProject(),
          this.fetchAccountRagStatus(),
          this.fetchNewProjectKiffOff(),
          this.fetchProjectNameListing(),
          this.fetchNewCollaboration(),
          this.fetchAssignedUsers(),
          this.fetchProjectAtRisk(),
          this.fetchCategories(),
          this.fetchWeeks(),
          this.fetchDepartments()

        ])
      } catch (error) {
        throw (error)
      }
    },

    formatDate(date) {
      const d = new Date(date)
      let month = '' + (d.getMonth() + 1)
      let day = '' + d.getDate()
      const year = d.getFullYear()

      if (month.length < 2) month = '0' + month
      if (day.length < 2) day = '0' + day

      return [day, month, year].join('/')
    },
    /**
     * Invoice Status Summary data mutation
     * @param data
     */
    mutateInvoiceStatus(data) {
      let countIs = 1
      let countRecord = 1

      this.isQuickTable = []
      this.invoiceStatus = []
      if (data) {
        this.loadingIS = false
        Object.entries(data).forEach(([key, values]) => {
          countIs = Number(countIs) + 1
          this.invoiceStatus.push({
            title: key,
            invoice_count: values.statusCount,
            redmineProjectId: values.ProjectID
          })
          if (values.resource && values.resource.length >= 1) {
            const isItems = []
            let disable = false

            values.resource.forEach((item) => {
              const nextInvoiceDate = this.formatDate(item.NextInvoiceDate)
              const lastInvoiceDate = this.formatDate(item.LastInvoiceDate)

              countRecord = Number(countRecord) + 1
              isItems.push({
                ProjectName: item.ProjectName,
                BillingType: item.BillingType,
                InvoiceStatus: item.InvoiceStatus,
                LastInvoiceDate: lastInvoiceDate,
                NextInvoiceDate: nextInvoiceDate,
                ProjectID: item.ProjectID,
                id: countRecord
              })
            })
            if (isItems.length <= 2) {
              disable = true
            }
            this.isQuickTable.push({
              id: countIs,
              titleColor: 'blue--text',
              status: key,
              showCollapse: false,
              showExpand: true,
              isDisabled: disable,
              items: isItems,
              code: 'is'
            })
          }
        })

        return this.isQuickTable
      }
    },
    mutateProjectWSRList(data) {
      if (data) {
        const projectData = data['projectList']

        this.newCount = 0
        this.draftCount = 0
        this.onGoingCount = 0
        this.holdCount = 0
        this.colosedCount = 0
        this.projectAtRiskCount =
          data['projectAtRiskCount'] !== undefined
            ? data['projectAtRiskCount']
            : 0
        this.allProjectActiveRiskCount =
          data['allProjectActiveRiskCount'] !== undefined
            ? data['allProjectActiveRiskCount']
            : 0

        const arrayWsrData = []
        const filterListArray = []

        if (projectData) {
          projectData.map((details) => {
            if (
              Array.isArray(details.project_w_s_r) &&
              details.project_w_s_r.length
            ) {
              arrayWsrData.push({
                uuid: details.uuid,
                projectName: details.project_name,
                redmineProjectId: details.redmine_project_id,
                projectWSR: details.project_w_s_r
              })
            }
            filterListArray.push({
              id: details.uuid,
              name: details.project_name
            })
            if (details.track.status === constant.PROJECT_STATUS.CLOSED) {
              // progress in stages graph logic
              this.colosedCount = this.colosedCount + 1
            } else if (
              details.track.status === constant.PROJECT_STATUS.ON_HOLD
            ) {
              this.holdCount = this.holdCount + 1
            } else if (details.track.is_draft === 1) {
              this.draftCount = this.draftCount + 1
            } else if (
              details.track.status === constant.PROJECT_STATUS.NEW ||
              ((details.track.is_approve === 0 ||
                details.track.is_approve === 1) &&
                details.track.status ===
                  constant.PROJECT_STATUS.INITIATION_REQUEST)
            ) {
              this.newCount = this.newCount + 1
            } else {
              this.onGoingCount = this.onGoingCount + 1
            }
          })
          this.projectWiseWSRData = arrayWsrData
          this.ProjectFilterList = filterListArray
        }
        const WsrStatusSubmitCount =
          data['allProjectwsrStatusSubmitCount'] !== undefined
            ? data['allProjectwsrStatusSubmitCount']
            : 0
        const WsrStatusPendingCount = this.onGoingCount - WsrStatusSubmitCount

        this.cards = [
          {
            title: 'Active Project',
            flex: 4,
            cardNumber: 1,
            value: this.onGoingCount,
            img: this.activeImg,
            link: null
          },
          {
            title: 'Project At Risk',
            flex: 4,
            cardNumber: 2,
            value: this.projectAtRiskCount,
            img: this.riskImg,
            link: null
          },
          {
            title: 'Active Risk',
            flex: 4,
            cardNumber: 3,
            value: this.allProjectActiveRiskCount,
            img: this.activeRiskImg,
            link: '/active-risk'
          }
        ]
        this.wsrStatusArray = [WsrStatusSubmitCount, WsrStatusPendingCount]
        this.projectEffortSerise = [
          this.newCount,
          this.draftCount,
          this.onGoingCount,
          this.holdCount,
          this.colosedCount
        ]
      }
    }
  }
}
</script>
