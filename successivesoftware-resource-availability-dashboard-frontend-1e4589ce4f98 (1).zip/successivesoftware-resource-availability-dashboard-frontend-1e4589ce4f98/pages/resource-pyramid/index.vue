<template>
  <div>
    <v-card
      class="mx-auto pl-0 pr-0"
      max-width="1385px"
    >
      <v-card-text>
        <v-row>
          <v-col cols="12" md="3">
            <v-select
              v-model="selectedDepartment"
              :items="departments"
              label="Select Department"
              item-text="name"
              item-value="id"
              item-class="idealRow"
              class="idealDepartment"
              solo
              dense
              @change="fetchDepartmentRecord"
            />
          </v-col>
        </v-row>
        <v-row>
          <v-col
            cols="12"
            md="6"
          >
            <v-row>
              <v-col cols="12" md="12" class="pr-2">
                <v-card
                  class="mx-auto rounded-xl idealDataCard"
                >
                  <v-card-text v-show="currentPyramidSetting && selectedDepartmentUserTotalCount > 0" class="pl-2 pr-2" style="padding-bottom:2%">
                    <v-row>
                      <v-col cols="9" md="9" class="divider">
                        <p style="padding-left:4%">
                          <strong class="idealLabel">
                            <span>Ideal/Expected Data</span>
                            <span class="idealCount">Total Count: {{ selectedDepartmentUserTotalCount }}</span>
                          </strong>
                        </p>
                        <v-simple-table v-if="currentPyramidSetting" :height="currentPyramidSetting && currentPyramidSetting.experience_percent.length < 8? 'auto': 300" solo dense>
                          <template v-slot:default>
                            <thead>
                              <tr>
                                <th class="text-center tableAlign">
                                  Color
                                </th>
                                <th class="text-center tableAlign">
                                  Experience Range
                                </th>
                                <th class="text-center tableAlign">
                                  Breakdown %
                                </th>
                                <th class="text-center tableAlign">
                                  Count
                                </th>
                              </tr>
                            </thead>
                            <tbody>
                              <tr v-for="(item, index) in currentPyramidSetting.experience_percent" :key="item.id">
                                <td class="text-center tableAlign">
                                  <v-icon :color="constant.PYRAMID_COLOUR_PATTERN[index]" class="mdi-18px">
                                    mdi-square
                                  </v-icon>
                                </td>
                                <td class="text-center tableAlign">
                                  {{ `${item.min_experience} - ${item.max_experience} Yrs` }}
                                </td>
                                <td class="text-center tableAlign">
                                  {{ item.percent }}
                                </td>
                                <td class="text-center tableAlign">
                                  <span>
                                    {{ Math.round(pyramidResourceCount[item.id]) }}
                                    <v-icon v-if="(Math.round((selectedDepartmentUserTotalCount/100)*item.percent) < Math.round(pyramidResourceCount[item.id]))" color="green" class="mdi-18px">
                                      mdi-arrow-up
                                    </v-icon>
                                    <v-icon v-else-if="(Math.round((selectedDepartmentUserTotalCount/100)*item.percent) > Math.round(pyramidResourceCount[item.id]))" color="red" class="mdi-18px">
                                      mdi-arrow-down
                                    </v-icon>
                                  </span>
                                </td>
                              </tr>
                            </tbody>
                          </template>
                        </v-simple-table>
                      </v-col>
                      <v-col cols="3" md="3" class="pl-0">
                        <p class="reqCount">
                          <strong class="idealLabel">
                            <span>Req Count: {{ getTotalRequiredResource() }}</span>
                          </strong>
                        </p>
                        <v-simple-table
                          v-if="currentPyramidSetting"
                          :height="currentPyramidSetting && currentPyramidSetting.experience_percent.length < 8? 'auto': 300"
                          solo
                          dense
                        >
                          <template v-slot:default>
                            <thead>
                              <tr>
                                <th class="text-center tableAlign">
                                  Required Resource
                                </th>
                              </tr>
                            </thead>
                            <tbody>
                              <tr v-for="(item) in currentPyramidSetting.experience_percent" :key="item.id">
                                <td class="text-center tableAlign">
                                  {{ `${Math.round(extraPersonCount[item.id])}` }}
                                </td>
                              </tr>
                            </tbody>
                          </template>
                        </v-simple-table>
                      </v-col>
                    </v-row>
                  </v-card-text>
                </v-card>
              </v-col>
            </v-row>
            <v-row v-if="showPyramid">
              <v-col cols="12" md="12">
                <div v-if="showPyramid" id="chart-container">
                  <highcharts :options="chartOptions" class="chart" />
                </div>
              </v-col>
            </v-row>
          </v-col>
          <v-col
            cols="12"
            md="6"
            class="pl-0 pr-3 pt-2"
          >
            <v-card
              v-if="(recordForPyramidTable.length)"
              v-show="showPyramid"
              class="mx-auto rounded-xl userDataTable"
            >
              <v-card-text class="pl-2 pr-2">
                <div v-if="selectedExperienceRangeName !== ''">
                  <h4 style="padding-left:2%">
                    <v-icon :color="(selectedTriangleColorName) ? selectedTriangleColorName : 'black'" class="mdi-18px">
                      mdi-triangle
                    </v-icon> Experience Range: {{ selectedExperienceRangeName }}
                  </h4><br>
                </div>
                <v-data-table
                  :headers="headers"
                  :items="recordForPyramidTable"
                  :hide-default-footer="recordForPyramidTable.length ? false : true"
                  :height="recordForPyramidTable.length >= 10 ? 550 : 'auto'"
                />
              </v-card-text>
            </v-card>
          </v-col>
          <v-spacer />
          <v-spacer />
          <v-col cols="12" md="12" class="pt-0 pb-8">
            <v-card
              v-show="!showPyramid"
              class="mx-auto"
              max-width="500"
              max-height="150"
            >
              <v-card-text style="text-align:center">
                <h3>
                  <v-icon class="mdi-48px">
                    mdi-alert
                  </v-icon><br> No Data Available to display for the Resource Pyramid.
                </h3>
              </v-card-text>
            </v-card>
          </v-col>
        </v-row>
      </v-card-text>
    </v-card>
  </div>
</template>
<script>
import Vue from 'vue'
import constant from '@/constants/closure-checklist.js'
import Highcharts from 'highcharts'
import { mapActions, mapGetters } from 'vuex'
import highchartsFunnel from 'highcharts/modules/funnel'
import HighchartsVue from 'highcharts-vue'

highchartsFunnel(Highcharts)

Vue.use(HighchartsVue)

export default {
  name: 'Index',
  layout: 'authenticated',
  middleware: 'authenticated',
  data () {
    return {
      headers: [
        { text: 'Employee No.', align: 'center', value: 'employeeNumber', sortable: true, width: '20%' },
        { text: 'Full Name', align: 'center', value: 'displayName', sortable: true, width: '17%' },
        { text: 'Email Address', align: 'center', value: 'email', sortable: true },
        { text: 'Job Title', align: 'center', value: 'jobTitle', sortable: true, width: '15%' },
        { text: 'Exp ', align: 'center', value: 'experience', sortable: true }
      ],
      selectedDepartment: null,
      showPyramid: false,
      storeUserRecord: [],
      selectedDepartmentUserTotalCount: 0,
      currentPyramidSetting: null,
      extraPersonCount: [],
      pyramidResourceCount: [],
      selectedTriangleColorName: null,
      recordForPyramidTable: [],
      departmentExperienceRecord: [],
      pyramidRecord: [],
      experienceRangeStringArray: [],
      selectedExperienceRangeName: '',
      constant,
      chartOptions: {
        chart: {
          type: 'pyramid'
        },
        title: {
          text: '',
          x: -50
        },
        plotOptions: {
          allowPointSelect: true,
          cursor: 'pointer',
          series: {
            dataLabels: {
              enabled: true,
              format: '<b>{point.name}</b> <br>{point.percentage:,.0f}% ({point.y:,.0f} Resources)',
              softConnector: true
            },
            center: ['40%', '50%'],
            width: '80%'
          }
        },
        legend: {
          enabled: false
        },
        series: [{
          name: 'Resources',
          data: [['undefined', 1]],
          point: {
            events: {
              click: (e) => {
                this.pyramidClick(e)
              }
            }
          }
        }],
        responsive: {
          rules: [{
            condition: {
              maxWidth: 500
            },
            chartOptions: {
              plotOptions: {
                series: {
                  dataLabels: {
                    inside: false
                  },
                  center: ['50%', '50%'],
                  width: '95%'
                }
              }
            }
          }]
        }
      }
    }
  },
  computed: {
    ...mapGetters({
      getKekaResourceDetailByDepartment: 'project/getKekaResourceDetailByDepartment',
      getPyramidSettingDetail: 'project/getPyramidSettingDetail',
      departments: 'project/getDepartments'
    })
  },
  async fetch ({ app, store }) {
    // eslint-disable-next-line no-useless-catch
    try {
      await Promise.all([
        store.dispatch('project/fetchKekaResourceDetailByDepartment', 'default'),
        store.dispatch('project/fetchAllPyramidSetting')
      ])
    } catch (error) {
      throw (error)
    }
  },
  mounted () {
    this.$nuxt.$emit('headerTitle', 'Resource Pyramid')
    if (this.getKekaResourceDetailByDepartment.department) {
      this.selectedDepartment = this.getKekaResourceDetailByDepartment.department.id
    }
    this.storeUserRecord[this.selectedDepartment] = this.getKekaResourceDetailByDepartment.users
    this.selectedDepartmentUserTotalCount = this.getKekaResourceDetailByDepartment.users.length
    const selectedDepartmentPyramidSetting = this.getPyramidSettingDetail.filter((item) => { return item.dept_id === this.selectedDepartment })

    if (this.getKekaResourceDetailByDepartment.users.length <= 0 || selectedDepartmentPyramidSetting.length <= 0) {
      this.showPyramid = false

      return
    } else {
      this.showPyramid = true
    }
    const experienceRecord = []
    const pyramidData = []
    let sortPyramidData = []

    if (selectedDepartmentPyramidSetting.length > 0) {
      const lastIndex = Number(selectedDepartmentPyramidSetting.length) - 1

      this.currentPyramidSetting = selectedDepartmentPyramidSetting[lastIndex]
      selectedDepartmentPyramidSetting[lastIndex].experience_percent.forEach((element) => {
        this.experienceRangeStringArray[element.id] = `${parseInt(element.min_experience)} to ${parseInt(element.max_experience)} Yrs`
        experienceRecord[element.id] = this.getSpecificExperienceRangeRecord(element.min_experience, element.max_experience, this.getKekaResourceDetailByDepartment.users)
      })
    }
    this.departmentExperienceRecord[this.selectedDepartment] = experienceRecord
    this.departmentExperienceRecord[this.selectedDepartment].forEach((item, key) => {
      const userArrayLength = item.length
      const experiencePeriod = this.experienceRangeStringArray[key].split(' ')
      const minimumExperience = parseInt(experiencePeriod[0])

      pyramidData.push([
        `${this.experienceRangeStringArray[key]}`, userArrayLength, minimumExperience
      ])
    })
    sortPyramidData = pyramidData.sort((a, b) => {
      return a[2] - b[2]
    })
    this.chartOptions.series[0].data = sortPyramidData
    this.recordForPyramidTable = this.getKekaResourceDetailByDepartment.users
    this.calculateExtraPersonCount()
  },
  methods: {
    ...mapActions({
      fetchKekaResourceDetailByDepartment: 'project/fetchKekaResourceDetailByDepartment',
      setCustomDialog: 'project/setCustomDialog',
      updateLoadingAction: 'project/updateLoadingAction'
    }),
    calculateExtraPersonCount () {
      let maxTotalCount = 0
      let maxTotalCountId = false

      this.pyramidResourceCount = []
      this.extraPersonCount = []
      const experienceSetting = this.currentPyramidSetting.experience_percent
      const realExperienceData = this.departmentExperienceRecord[this.selectedDepartment]

      if (realExperienceData.length > 0) {
        experienceSetting.forEach((item) => {
          const experienceRangeCount = (realExperienceData[item.id]) ? realExperienceData[item.id].length : 0
          const count = (experienceRangeCount * 100) / item.percent

          if (count > maxTotalCount) {
            maxTotalCount = count
            maxTotalCountId = item.id
          }
          this.pyramidResourceCount[item.id] = experienceRangeCount
        })
        experienceSetting.forEach((element) => {
          let requiredResource = 0
          const experienceRangeCount = (realExperienceData[element.id]) ? realExperienceData[element.id].length : 0
          const calculateActualValue = (maxTotalCount * element.percent) / 100

          if (calculateActualValue > experienceRangeCount && maxTotalCountId !== element.id) {
            requiredResource = calculateActualValue - experienceRangeCount
          }
          this.extraPersonCount[element.id] = requiredResource
        })
      }
    },
    getTotalRequiredResource () {
      let total = 0

      if (this.extraPersonCount.length) {
        this.extraPersonCount.forEach((item, index) => {
          total = total + Math.round(item) + Math.round(this.pyramidResourceCount[index])
        })
      }

      return total
    },
    getSpecificExperienceRangeRecord (minRange, maxRange, users) {
      const minExperience = parseFloat(minRange)
      const maxExperience = parseFloat(maxRange)
      const filterRecord = users.filter((item) => { return parseFloat(item.experience) >= minExperience && parseFloat(item.experience) < maxExperience })

      return filterRecord
    },
    pyramidClick (event) {
      this.selectedTriangleColorName = event.point.color
      this.selectedExperienceRangeName = event.point.name
      const selectedExperience = event.point.name.split(' ')
      const minExperience = parseFloat(selectedExperience[0])
      const maxExperience = parseFloat(selectedExperience[2])
      const selectedDepartmentPyramidSetting = this.getPyramidSettingDetail.filter((item) => { return item.dept_id === this.selectedDepartment })
      const selectedExperienceDepartment = selectedDepartmentPyramidSetting[0].experience_percent.filter((item) => { return item.min_experience === minExperience && item.max_experience === maxExperience })

      if (selectedExperienceDepartment.length > 0) {
        this.recordForPyramidTable = this.departmentExperienceRecord[this.selectedDepartment][selectedExperienceDepartment[0].id]
      }
    },
    async fetchDepartmentRecord (departmentId) {
      this.extraPersonCount = []
      this.selectedExperienceRangeName = ''
      this.recordForPyramidTable = []
      const pyramidData = []
      let sortPyramidData = []

      this.selectedDepartmentUserTotalCount = 0
      const selectedDepartmentPyramidSetting = this.getPyramidSettingDetail.filter((item) => { return item.dept_id === departmentId })

      if (selectedDepartmentPyramidSetting.length <= 0) {
        this.currentPyramidSetting = null
        this.showPyramid = false

        return
      }
      this.currentPyramidSetting = selectedDepartmentPyramidSetting[0]
      if (this.storeUserRecord[departmentId]) {
        if (this.storeUserRecord[departmentId].length <= 0) {
          this.showPyramid = false

          return
        }
      } else {
        await this.fetchKekaResourceDetailByDepartment(departmentId)
        this.storeUserRecord[departmentId] = this.getKekaResourceDetailByDepartment.users
        const experienceRecord = []

        if (selectedDepartmentPyramidSetting.length > 0) {
          selectedDepartmentPyramidSetting[0].experience_percent.forEach((element) => {
            this.experienceRangeStringArray[element.id] = `${parseInt(element.min_experience)} to ${parseInt(element.max_experience)} Yrs`
            experienceRecord[element.id] = this.getSpecificExperienceRangeRecord(element.min_experience, element.max_experience, this.getKekaResourceDetailByDepartment.users)
          })
        }
        this.departmentExperienceRecord[departmentId] = experienceRecord
      }
      this.showPyramid = this.departmentExperienceRecord[departmentId].some((element) => element.length > 0)
      if (!this.showPyramid) {
        return
      }
      this.recordForPyramidTable = this.storeUserRecord[departmentId]
      this.selectedDepartmentUserTotalCount = this.storeUserRecord[departmentId].length
      this.departmentExperienceRecord[departmentId].forEach((item, key) => {
        const userArrayLength = item.length
        const experiencePeriod = this.experienceRangeStringArray[key].split(' ')
        const minimumExperience = parseInt(experiencePeriod[0])

        pyramidData.push([
          `${this.experienceRangeStringArray[key]}`, userArrayLength, minimumExperience
        ])
      })
      sortPyramidData = pyramidData.sort((a, b) => {
        return a[2] - b[2]
      })
      this.chartOptions.series[0].data = sortPyramidData
      this.calculateExtraPersonCount()
    }
  }
}
</script>
<style scoped>
>>>.highcharts-credits {
  display: none;
}
.inner {
  display: table;
  margin: 0 auto;
}
.v-application .idealLabel {
  font-size: 12px;
}
.v-application .idealCount {
  float: right;
  margin-right: 3%;
}
.v-application .userDataTable {
  margin-top: 2%;
}
.v-application .tableAlign {
  padding-right: 4px !important;
}
.v-application .idealDataCard {
  max-width: 100% !important;
  margin: 0px !important;
}
>>>.v-data-table > .v-data-table__wrapper > table > tbody > tr > td, .v-data-table > .v-data-table__wrapper > table > thead > tr > td, .v-data-table > .v-data-table__wrapper > table > tfoot > tr > td {
  font-size: small;
  padding: 2px;
}
.v-application .container {
  padding-left: 0px;
  padding-right: 0px;
}
>>>.v-data-table > .v-data-table__wrapper > table > thead > tr > th {
padding: 0 6px;
}

>>>.v-data-table > .v-data-table__wrapper > table > tbody > tr > td {
    font-size: smaller !important
}
.v-application .idealDepartment {
  height: 20px !important;
}
>>>.v-data-table table {
    padding: 0px;
    padding-bottom: 8px;
    padding-left: 3px;
}
.divider {
border-right: 1px dashed rgb(230, 224, 224);
margin-top: 12px;;
margin-bottom: 12px;
}
.reqCount {
  text-align:right;
  padding-right: 0px;
  margin-top: 10px
}
.col-md-9{
  width: 100%;
  padding: 20px;
}
</style>
