<template>
  <div>
    <Dialog />
    <common-snackbar
      :snackbar="snackbarValue"
      :text-for-snackbar="snackbarText"
    />
    <ValidationObserver ref="projectInitObserver" v-slot="{ valid }">
      <v-card class="mx-auto" max-width="80%" rasied>
        <v-card-text>
          <v-row no-gutters>
            <v-col cols="12" md="4" class="ml-3 mt-5 pl-5 pt-5">
              <label> Department </label>
            </v-col>
          </v-row>
          <v-row>
            <v-col cols="12" md="4" class="ml-8">
              <ValidationProvider
                v-slot="{ errors }"
                :rules="'required'"
                name="selectedDepartment"
              >
                <v-autocomplete
                  v-model="selectedDepartment"
                  :items="departments"
                  :error-messages="errors"
                  :search-input.sync="searchDepartmentName"
                  item-text="name"
                  item-value="id"
                  outlined
                  dense
                  single-line
                  placeholder="Select Department"
                  @change="searchDepartmentName = ''"
                  @input="getTotalEmployees"
                />
              </ValidationProvider>
            </v-col>
          </v-row>
          <v-row no-gutters>
            <v-col cols="12" md="4" class="ml-3 pl-5 pt-2">
              <label> Total Number of Employees </label>
            </v-col>
          </v-row>
          <v-row>
            <v-col cols="12" md="2" class="ml-8">
              <v-text-field
                v-model.trim="noOfEmployees"
                outlined
                dense
                readonly
                single-line
              />
            </v-col>
          </v-row>
          <v-row no-gutters>
            <v-col cols="12" md="4" class="ml-3 pl-5 pt-2">
              <label> Experience Ranges </label>
            </v-col>
            <v-col cols="12" md="3" class="ml-2 pl-5 pt-2">
              <label> Breakdown % </label>
            </v-col>
          </v-row>
          <template v-if="updateRecord === false">
            <v-row
              v-for="(experience, index) in experienceRanges"
              :key="`${index}-experience`"
            >
              <v-col cols="12" md="2" class="ml-8">
                <ValidationProvider
                  v-slot="{ errors }"
                  :rules="'required|numeric|check_experience_range'"
                  :name="`${++index}-experience`"
                >
                  <v-text-field
                    v-model.trim="experience.min_experience"
                    :error-messages="errors"
                    placeholder="From"
                    outlined
                    dense
                    single-line
                  />
                </ValidationProvider>
              </v-col>
              <v-col cols="12" md="2">
                <ValidationProvider
                  v-slot="{ errors }"
                  :rules="'required|numeric|check_experience_range'"
                  name="experience.max_experience"
                >
                  <v-text-field
                    v-model.trim="experience.max_experience"
                    :error-messages="errors"
                    placeholder="To"
                    outlined
                    dense
                    single-line
                  />
                </ValidationProvider>
              </v-col>
              <v-col cols="12" md="2">
                <ValidationProvider
                  v-slot="{ errors }"
                  :rules="'required|numeric|between:1,100'"
                  name="experience.percent"
                >
                  <v-text-field
                    v-model.trim="experience.percent"
                    :error-messages="errors"
                    placeholder="%"
                    outlined
                    dense
                    single-line
                  />
                </ValidationProvider>
              </v-col>
              <v-col
                v-if="experienceRanges.length === index"
                cols="12"
                md="1"
                class="ml-2 pr-5"
              >
                <v-btn
                  fab
                  dark
                  color="primary"
                  x-small
                  class="mx-2"
                  @click="addMoreExperienceRanges"
                >
                  <v-icon dark>
                    mdi-plus
                  </v-icon>
                </v-btn>
              </v-col>
              <v-col v-if="index > 1" cols="12" md="1" class="ml-2 pr-5">
                <v-btn
                  class="mx-2"
                  fab
                  dark
                  color="error"
                  x-small
                  @click="removeExperienceRanges(index)"
                >
                  <v-icon dark>
                    mdi-minus
                  </v-icon>
                </v-btn>
              </v-col>
            </v-row>
          </template>
          <template v-else>
            <v-row
              v-for="(experience, index) in editExperienceRanges"
              :key="`${index}-experience`"
            >
              <v-col cols="12" md="2" class="ml-8">
                <ValidationProvider
                  v-slot="{ errors }"
                  :rules="'required|numeric|check_experience_range'"
                  :name="`${++index}-experience`"
                >
                  <v-text-field
                    v-model.trim="experience.min_experience"
                    :error-messages="errors"
                    placeholder="From"
                    outlined
                    dense
                    single-line
                  />
                </ValidationProvider>
              </v-col>
              <v-col cols="12" md="2">
                <ValidationProvider
                  v-slot="{ errors }"
                  :rules="'required|numeric|check_experience_range'"
                  name="experience.max_experience"
                >
                  <v-text-field
                    v-model.trim="experience.max_experience"
                    :error-messages="errors"
                    placeholder="To"
                    outlined
                    dense
                    single-line
                  />
                </ValidationProvider>
              </v-col>
              <v-col cols="12" md="2">
                <ValidationProvider
                  v-slot="{ errors }"
                  :rules="'required|numeric|between:1,100'"
                  name="experience.percent"
                >
                  <v-text-field
                    v-model.trim="experience.percent"
                    :error-messages="errors"
                    placeholder="%"
                    outlined
                    dense
                    single-line
                  />
                </ValidationProvider>
              </v-col>
              <v-col
                v-if="editExperienceRanges.length === index"
                cols="12"
                md="1"
                class="ml-2 pr-5"
              >
                <v-btn
                  fab
                  dark
                  color="primary"
                  x-small
                  class="mx-2"
                  @click="addMoreExperienceRanges"
                >
                  <v-icon dark>
                    mdi-plus
                  </v-icon>
                </v-btn>
              </v-col>
              <v-col v-if="index > 1" cols="12" md="1" class="ml-2 pr-5">
                <v-btn
                  class="mx-2"
                  fab
                  dark
                  color="error"
                  x-small
                  @click="removeExperienceRanges(index)"
                >
                  <v-icon dark>
                    mdi-minus
                  </v-icon>
                </v-btn>
              </v-col>
            </v-row>
          </template>
          <v-row align="end" justify="end">
            <v-col v-if="!valid" cols="12">
              <v-btn
                class="text-capitalize ma-2 white--text"
                color="blue-grey"
                @click="$router.push('/project-dashboard')"
              >
                <v-icon dark left>
                  mdi-arrow-left
                </v-icon>Back
              </v-btn>
              <v-btn
                :disabled="!valid"
                class="text-capitalize"
                color="primary"
                @click="submit"
              >
                Submit
              </v-btn>
            </v-col>
            <v-col v-else cols="12">
              <v-btn
                class="text-capitalize ma-2 white--text"
                color="blue-grey"
                @click="$router.push('/project-dashboard')"
              >
                <v-icon dark left>
                  mdi-arrow-left
                </v-icon>Back
              </v-btn>
              <v-btn
                :disabled="submitted"
                class="text-capitalize"
                color="primary"
                @click="submit"
              >
                Submit
              </v-btn>
            </v-col>
          </v-row>
        </v-card-text>
      </v-card>
    </ValidationObserver>
  </div>
</template>
<script>
import { mapActions, mapGetters } from 'vuex'
import constant from '@/constants/closure-checklist.js'
import CommonSnackbar from '@/components/CommonSnackbar'
import Dialog from '@/components/Dialog.vue'

export default {
  name: 'Index',
  components: { CommonSnackbar, Dialog },
  layout: 'authenticated',
  middleware: 'authenticated',
  data () {
    return {
      searchDepartmentName: null,
      submitted: false,
      snackbarValue: false,
      snackbarText: '',
      dialog: false,
      constant,
      inputDialog: false,
      selectedDepartment: '',
      experienceRanges: [
        { min_experience: '', max_experience: '', percent: '' }
      ],
      editExperienceRanges: [],
      noOfEmployees: 0,
      updateRecord: false,
      pyramidId: null,
      storeDepartmentUsers: []
    }
  },
  computed: {
    ...mapGetters({
      getKekaResourceDetailByDepartment: 'project/getKekaResourceDetailByDepartment',
      departments: 'project/getDepartments',
      getPyramidSettingDetail: 'project/getPyramidSettingDetail'
    })
  },
  async fetch ({ app, store }) {
    // eslint-disable-next-line no-useless-catch
    try {
      await store.dispatch('project/fetchAllPyramidSetting')
    } catch (error) {
      throw error
    }
  },
  mounted () {
    this.$nuxt.$emit('headerTitle', 'Resource Pyramid Settings')
  },
  methods: {
    ...mapActions({
      fetchKekaResourceDetailByDepartment: 'project/fetchKekaResourceDetailByDepartment',
      setPyramidSettingsByDepartment: 'project/setResourcePyramidSettingsByDepartment',
      updateLoadingAction: 'project/updateLoadingAction',
      updatePyramidSettingsByDepartment: 'project/updateResourcePyramidSettingsByDepartment'
    }),
    async getTotalEmployees (selectedDepartment) {
      if (this.storeDepartmentUsers.length <= 0 || this.storeDepartmentUsers.filter((item) => item.deptId === selectedDepartment).length <= 0) {
        await this.fetchKekaResourceDetailByDepartment(selectedDepartment)
        this.storeDepartmentUsers.push({
          deptId: selectedDepartment,
          users: this.getKekaResourceDetailByDepartment.users
        })
        this.noOfEmployees = this.getKekaResourceDetailByDepartment.users.length
      } else {
        this.storeDepartmentUsers.forEach((user) => {
          if (user.deptId === selectedDepartment) {
            this.noOfEmployees = user.users.length
          }
        })
      }
      this.updateRecord = false
      let experienceRangeArray = []

      if (this.getPyramidSettingDetail) {
        this.getPyramidSettingDetail.forEach((item) => {
          if (item.dept_id === this.selectedDepartment && this.noOfEmployees > 0) {
            experienceRangeArray = item.experience_percent
            this.pyramidId = item.uuid
            this.updateRecord = true
          }
        })
      }
      this.editExperienceRanges = experienceRangeArray
    },
    addMoreExperienceRanges () {
      if (this.updateRecord === false) {
        if (this.experienceRanges.length >= 8) {
          this.snackbarValue = true
          this.snackbarText = 'Cannot add more than 8 experience range.'

          return
        }
        this.experienceRanges.push({ min_experience: '', max_experience: '', percent: '' })
      }
      if (this.updateRecord === true) {
        if (this.editExperienceRanges.length >= 8) {
          this.snackbarValue = true
          this.snackbarText = 'Cannot add more than 8 experience range.'

          return
        }
        this.editExperienceRanges.push({ min_experience: '', max_experience: '', percent: '' })
      }
    },
    removeExperienceRanges (index) {
      if (this.updateRecord === false) {
        this.experienceRanges.splice(index - 1, 1)
      }
      if (this.updateRecord === true) {
        this.editExperienceRanges.splice(index - 1, 1)
      }
    },
    experienceValidation (experienceArray) {
      let flag = false
      let ranges = [...experienceArray]

      ranges = ranges.sort((a, b) => {
        return a.min_experience - b.min_experience
      })
      ranges.forEach((item, index) => {
        if (index !== (ranges.length - 1)) {
          if (parseInt(item.min_experience) === parseInt(ranges[index + 1].min_experience) || parseInt(item.max_experience) !== parseInt(ranges[index + 1].min_experience)) {
            flag = true
          }
        }
      })

      return flag
    },
    async submit () {
      await this.updateLoadingAction()
      const updateExperienceData = []
      let totalPercentage = 0
      let errorMsg = ''

      if (this.updateRecord === true) {
        if (errorMsg !== '' || this.noOfEmployees <= 0) {
          this.snackbarText = (errorMsg !== '') ? errorMsg : 'Cannot create pyramid settings because number of employees is 0!'
          this.snackbarValue = true
          setTimeout(() => {
            this.snackbarValue = false
          }, 3000)

          return
        }
        this.editExperienceRanges.map((value) => {
          if (parseInt(value.max_experience) <= parseInt(value.min_experience)) {
            errorMsg = 'Experience To must be greater than Experience From'
          }
          totalPercentage += Number(value.percent)
          updateExperienceData.push({
            min_experience: value.min_experience,
            max_experience: value.max_experience,
            percent: value.percent
          })
        })
        if (errorMsg === '' && this.experienceValidation(this.editExperienceRanges)) {
          errorMsg = 'Experience Range must be unique and Not allow to skip in between experience range'
        }
        if (errorMsg !== '' || totalPercentage !== 100) {
          this.snackbarText = (errorMsg !== '') ? errorMsg : 'Breakdown total must be 100!'
          this.snackbarValue = true
          setTimeout(() => {
            this.snackbarValue = false
          }, 3000)

          return
        }
        const requestData = {
          experience_data: updateExperienceData,
          dept_id: this.selectedDepartment,
          employee_count: this.noOfEmployees
        }

        await this.updatePyramidSettingsByDepartment({ id: this.pyramidId, requestData })
      } else {
        if (errorMsg !== '' || this.noOfEmployees <= 0) {
          this.snackbarText = (errorMsg !== '') ? errorMsg : 'Cannot create pyramid settings because number of employees is 0!'
          this.snackbarValue = true
          setTimeout(() => {
            this.snackbarValue = false
          }, 3000)

          return
        }
        this.experienceRanges.map((value) => {
          if (parseInt(value.max_experience) <= parseInt(value.min_experience)) {
            errorMsg = 'Experience To must be greater than Experience From'
          }
          totalPercentage += Number(value.percent)
        })
        if (errorMsg === '' && this.experienceValidation(this.experienceRanges)) {
          errorMsg = 'Experience Range must be unique and Not allow to skip in between experience range'
        }
        if (errorMsg !== '' || totalPercentage !== 100) {
          this.snackbarText = (errorMsg !== '') ? errorMsg : 'Breakdown total must be 100!'
          this.snackbarValue = true
          setTimeout(() => {
            this.snackbarValue = false
          }, 3000)

          return
        }
        const requestData = {
          experience_data: this.experienceRanges,
          dept_id: this.selectedDepartment,
          employee_count: this.noOfEmployees
        }

        await this.setPyramidSettingsByDepartment(requestData)
      }
      this.updateLoadingAction()
      this.submitted = true
    }
  }
}
</script>

<style scoped>
</style>
