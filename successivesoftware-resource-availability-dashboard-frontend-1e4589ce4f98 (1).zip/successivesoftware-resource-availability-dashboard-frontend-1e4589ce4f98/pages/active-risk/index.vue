<template>
  <div class="projectDashboardWrp">
    <div class="projectDashboradrH">
      <v-row>
        <v-col cols="6" class="pb-0">
          <div class="heading-style"><h3>Active Risk</h3></div>
        </v-col>
        <v-col cols="6" class="text-right pb-1">
          <div class="exportBtnWrp">
            <v-btn
              class="exportBtn"
              small
              @click="exportExcelSheet"
            >
              Download Report <v-icon small>
                mdi-download
              </v-icon>
            </v-btn>
          </div>
        </v-col>

      </v-row>

      <v-row class="">
        <v-col v-if="tableView === true" cols="12" class="">
          <v-data-table
            :headers="headers"
            :items="riskDetails"
            :items-per-page="itemPerPage"
            :footer-props="{ itemsPerPageOptions: rowsPerPage }"
            :hide-default-footer="riskDetails.length ? false : true"
            :search="search"
            class="projectDataWrp activeRiskTbl"
          >
            <template v-slot:top>
              <div class="projectDtopBar">
                <v-row>
                  <v-col cols="6" class="pt-0 pb-0 pr-0"> </v-col>
                  <v-col cols="3" class="pt-0 pb-0 pr-0">
                    <v-text-field
                      v-model="search"
                      append-icon="mdi-magnify"
                      label="Search"
                      outlined
                      dense
                      class="filtersFields"
                      single-line
                      hide-details
                    />
                  </v-col>
                  <v-col cols="3" class="pt-0 pb-0 pl-0">
                    <v-autocomplete
                      v-model="projectIds"
                      :items="assignedProjectList"
                      item-text="name"
                      item-value="id"
                      class="filtersFields"
                      label="Project Name"
                      outlined
                      small-chips
                      clearable
                      dense
                      multiple
                      @change="projectNameFilter(projectIds)"
                    >
                      <template v-slot:selection="{ attrs, item, parent, selected, index }" class="slectedChilpSRWrp">
                        <v-tooltip top>
                          <template v-slot:activator="{ on }">
                            <v-chip
                              v-if="item === Object(item) && index === 0"
                              v-bind="attrs"
                              :input-value="selected"
                              label
                              small
                              v-on="on"
                            >
                              <span class="slectedChilpSR">
                                {{ item.name.length >= 47? item.name.slice(0,47) + '...': item.name }}
                              </span>
                              <v-icon
                                small
                                @click="parent.selectItem(item)"
                              >
                                mdi-close
                              </v-icon>
                            </v-chip>
                            <v-menu
                              bottom
                              origin="center center"
                              transition="scale-transition"
                            >
                              <template v-slot:activator="{ on }">
                                <v-btn
                                  v-if="index === 1"
                                  class="wsrMoreChilp"
                                  outlined
                                  rounded
                                  fab
                                  small
                                  height="25"
                                  width="25"
                                  color="blue"
                                  v-on="on"
                                  @click="!false"
                                >
                                  <v-icon x-small style="height: 10px; width: 10px">
                                    mdi-plus
                                  </v-icon>
                                  {{ projectIds.length - 1 }}
                                </v-btn>
                              </template>
                              <v-card
                                v-show="!false"
                                class="mx-auto"
                                max-width="300"
                                raised
                              >
                                <v-list
                                  v-if="selectedProjectList.length > 1"
                                  disabled
                                  shaped
                                >
                                  <v-list-item-group
                                    v-model="selectedProjectList"
                                  >
                                    <v-list-item
                                      v-for="project in selectedProjectList.slice(1,selectedProjectList.length)"
                                      v-show="!false"
                                      :key="project.id"
                                    >
                                      <v-avatar
                                        color="blue lighten-1"
                                        size="30"
                                        style="padding:4px"
                                      >
                                        <strong class="white--text headline">{{ avatarNames(project.name) }}</strong>
                                      </v-avatar>
                                      <v-list-item-content class="ml-2">
                                        <v-list-item-title v-text="project.name" />
                                      </v-list-item-content>
                                    </v-list-item>
                                  </v-list-item-group>
                                </v-list>
                              </v-card>
                            </v-menu>
                          </template>
                          <span>{{ item.name }}</span>
                        </v-tooltip>
                      </template>
                    </v-autocomplete>
                  </v-col>
                </v-row>
              </div>
            </template>

            <template v-slot:item.risk_details="{item}">

              <div class="pa-2" align="left">
                <!-- <div v-if="item.expireFlag"> -->
                Risk Number: <span class="blue--text mb-3" > {{ item.risk_number }} </span><br/>
                Risk Index: <span class="green--text mb-3" >  {{ item.risk_index }} </span><br/>
                Priority: <span class="red--text mb-3"> {{ item.priority_id }} </span><br/>
                Risk Category: <span class="red--text mb-3"> {{ item.risk_category }} </span><br/>
                Due Date: <span class="red--text mb-3">{{ item.due_date }} </span><br/>

              </div>
            </template>
            <template v-slot:item.risk_description="{item}">
              <div v-html="item.risk_description"/>
            </template>

          </v-data-table>
        </v-col>
      </v-row>
    </div>
  </div>
</template>
<script>
import { mapActions, mapGetters } from 'vuex'
import { excelSheet, projectHelpers } from '@/helpers/helper.js'

export default {
  name: 'Index',
  layout: 'authenticated',
  middleware: 'authenticated',

  data() {
    return {
      itemPerPage: 10,
      loadMore: 12,
      search: '',
      rowsPerPage: [10, 100, 200],
      tableView: true,
      projectIds: '',
      exportData: [],
      assignedProjectList: [],
      selectedProjectList:[],

      riskMainData:[],
      headers: [
        { text: 'Project Name', align: 'center', value: 'project_name',  width: '15%', filter: this.PorjectNameFilters },
        { text: 'Risk Details', align: 'left', sortable: false, value: 'risk_details', width: '18%'  },
        { text: 'Risk Subject', align: 'center', value: 'risk_subject', sortable: false, width: '15%'   },
        {
          text: 'Risk Description',
          align: 'center',
          value: 'risk_description',
          sortable: false,
          width: '22%'
        },
        { text: 'Assignee', align: 'center', value: 'assigned_to', sortable: false, width: '15%' },
        { text: 'Status', align: 'center', value: 'status', sortable: false, width: '15%' }
      ],
      riskDetails: []
    }
  },
  computed: {
    ...mapGetters({
      getRiskData: 'AmPmDashboard/getRiskData',
      getAssignedProjectList: 'AmPmDashboard/getAssignedProjectList'
    })
  },
  watch: {
    riskItemList () {
      this.riskItemData = this.riskItemList
    },
    projectIds() {
      this.selectedProjectList = []
      this.projectIds.forEach((id) => {
        const domains = this.assignedProjectList.filter((item) => { return item.id === id })

        this.selectedProjectList.push(domains[0])
      })
    }
  },
  async fetch({ app, store, route }) {
    // eslint-disable-next-line no-useless-catch
    try {
      await Promise.all([
        store.dispatch('AmPmDashboard/fetchRisk'),
        store.dispatch('AmPmDashboard/fetchAssignedProjectList')
      ])
    } catch (error) {
      throw error
    }
  },
  mounted () {

    this.mutateProjectList()
    this.exportData = this.riskDetails
    this.mutateAssignedProjectList(this.getAssignedProjectList)

  },
  methods: {

    assignedToValue(value) {
      if (value.risk_asssigned_to) {
        return value.risk_asssigned_to.display_name
      } else {
        return ''
      }
    },
    avatarNames (fullName) {

      return projectHelpers.avatarNames(fullName)
    },
    probabiltyData(value) {
      if (value.probability) {
        return value.probability.value
      } else {
        return ''
      }
    },
    impactData(value) {
      if (value.impact) {
        return value.impact.value
      } else {
        return ''
      }
    },
    categoryData(value) {
      if (value.risk_category) {
        return value.risk_category.value
      } else {
        return ''
      }
    },
    mutateAssignedProjectList (data) {
      if (data) {
        const filterListArray = []

        data.map((details) => {

          filterListArray.push({
            id: details.uuid,
            name: details.project_name

          })
        })
        this.assignedProjectList = filterListArray

      }
    },
    projectNameFilter(projectIds) {

      if (projectIds.length > 0 && !projectIds.includes(0)) {
        const projectData = []

        this.riskMainData.forEach((element) => {
          if (element.project_id !== null && projectIds.includes(element.project_id)) {
            projectData.push(element)
          }
        })
        this.riskDetails = projectData

      } else {
        this.riskDetails = this.riskMainData

      }
    },

    exportExcelSheet () {
      const risk = []

      this.riskDetails.forEach((riskDetail) => {
        let riskDesc = riskDetail.risk_description.replace(/<\/?[^>]+>/gi, ' ')

        riskDesc = riskDesc.replace(/&nbsp;/g, '')
        riskDesc = riskDesc.replace(/&ndash;/g, '-')
        risk.push({
          project_name: riskDetail.project_name,
          risk_number: riskDetail.risk_number,
          risk_index: riskDetail.risk_index,
          priority: riskDetail.priority_id,
          risk_category: riskDetail.risk_category,
          due_date: riskDetail.due_date,
          risk_subject: riskDetail.risk_subject,
          risk_description: riskDesc,
          assigned_to: riskDetail.assigned_to,
          status: riskDetail.status
        })
      })

      const excelParams = {
        'sheetData': [risk],
        'headers': [['project_name','risk_number', 'risk_index', 'priority', 'risk_category',  'due_date', 'risk_subject', 'risk_description', 'assigned_to', 'status']],
        'sheetName': ['Active-Risk'],
        'fileName': 'Active Risks Report.csv'
      }

      excelSheet.createExcelSheet(excelParams)
    },

    mutateProjectList () {

      const riskData = []

      if (this.getRiskData) {
        this.getRiskData.map((details) => {
          const riskObj = details.project_risk

          riskObj.forEach((riskDetail) => {

            riskData.push({
              project_name: details.project_name,
              risk_number: riskDetail.id,
              risk_index: parseFloat(this.probabiltyData(riskDetail) * this.impactData(riskDetail)).toFixed(2),
              priority_id: riskDetail.priority_id === 1 ? 'Low' : riskDetail.priority_id === 2 ? 'Normal' : riskDetail.priority_id === 3 ? ('High') : riskDetail.priority_id === 4 ? ('Blocker') : 'Immediate',
              risk_category: this.categoryData(riskDetail),
              due_date: riskDetail.due_date,
              risk_subject: riskDetail.subject,
              risk_description: riskDetail.description,
              assigned_to: this.assignedToValue(riskDetail),
              status:riskDetail.status_id === 1 ? 'To Do' : ((riskDetail.status_id === 2) ? ('In Progress') : ('Complete')),
              project_id: details.uuid
            })
          })
        })
        this.riskDetails = riskData
        this.riskMainData = riskData
      }
    }
  }
}
</script>
<style scoped>
.projectDtopBar {
  background-color: rgb(246 247 249 / 42%);
  padding: 40px 0 30px;
  margin-bottom: 0 !important;
}
.projectDataWrp table tbody tr td:nth-child(2) {
    color: #9c9898;
    line-height: 22px;
}
</style>
