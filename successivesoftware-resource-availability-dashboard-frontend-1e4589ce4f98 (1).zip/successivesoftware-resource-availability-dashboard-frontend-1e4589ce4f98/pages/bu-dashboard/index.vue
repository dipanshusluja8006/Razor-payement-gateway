/* eslint-disable no-unreachable */
<template>
  <div id="dashboard">
    <div class="cardsBox mt-2">
      <v-row>
        <v-col cols="4">
          <div class="dashboardHeading">
            <h1>BU Head Dashboard</h1>
          </div>
        </v-col>
        <v-col cols="5"></v-col>
        <v-col cols="3" md="3">
          <v-autocomplete
            v-model="selectedDepartment"
            :items="departments"
            label="Select Department"
            item-text="name"
            item-value="id"
            item-class="idealRow"
            class="idealDepartment"
            solo
            dense
            @change="fetchDepartmentRecord(selectedDepartment)"
          />
        </v-col>
      </v-row>
      <v-row class="mt-0">
        <v-col cols="3">
          <div class="mb-4">
            <TotalResource :resource-count="selectedDepartmentUserTotalCount" />
          </div>
          <div class="mb-4">
            <ResourceExprience
              :resource-count-exp-range-wise="resourceCountExpRangeWise"
            />
          </div>
          <div>
            <BuTimeSection :department-id="departmentId" />
          </div>
        </v-col>
        <v-col cols="9">
          <v-row class="mt-0">
            <v-col cols="8" class="pt-0 pl-0">
              <ResourceUtilazotion :uti-data="utiData" />
            </v-col>
            <v-col cols="4" class="pt-0 pl-0">
              <BuRagStatus
                :department-wise-rag="departmentWiseRagArray"
                :department-id="departmentId"
              />
            </v-col>
            <v-col cols="12" class="pl-0 pt-0 budshPendingActWrp">
              <PeningActionItem
                :pending-item-list="mutatePendingActionData"
                :project-list="ProjectFilterList"
              />
            </v-col>
          </v-row>
        </v-col>
      </v-row>
    </div>
  </div>
</template>
<script>
import { mapActions, mapGetters } from 'vuex'
import constant from '@/constants/closure-checklist.js'
import { excelSheet } from '@/helpers/helper.js'
import BuRagStatus from '@/components/buHeadDashboard/BuRagStatus.vue'
import BuTimeSection from '@/components/buHeadDashboard/BuTimeSection.vue'
import TotalResource from '@/components/buHeadDashboard/TotalResource.vue'
import ResourceUtilazotion from '@/components/buHeadDashboard/ResourceUtilazotion.vue'
import PeningActionItem from '@/components/pmDashboard/PeningActionItem.vue'
import ResourceExprience from '@/components/buHeadDashboard/ResourceExprience.vue'
import { projectHelpers } from '@/helpers/helper.js'

export default {
  name: 'ProjectManager',
  components: {
    PeningActionItem,
    BuRagStatus,
    ResourceUtilazotion,
    BuTimeSection,
    TotalResource,
    ResourceExprience
  },
  layout: 'authenticated',
  middleware: 'authenticated',
  data() {
    return {
      departmentWiseRagArray: [],
      utiData: {},
      projectEffortSerise: [],
      PendingActionData: [],
      mutatePendingActionData: [],
      ProjectFilterList: [],
      projectList: [],
      departmentId: 'default',
      selectedDepartmentUserTotalCount: 0,
      resourceCountExpRangeWise: [],
      selectedDepartment: null,
      totalTime: 222
    }
  },
  computed: {
    ...mapGetters({
      getKekaResourceDetailByDepartment:
        'project/getKekaResourceDetailByDepartment',
      getDepartmentWiseRagStatus: 'project/getDepartmentWiseRagStatus',
      departments: 'project/getDepartments',
      getPendingActionList: 'AmPmDashboard/getMyActionItemList',
      getProjectNames: 'project/getProjectNameListing'
    })
  },
  watch: {
    selectedDepartment() {
      if (this.selectedDepartment !== null || this.selectedDepartment !== '') {
        this.departmentId = this.selectedDepartment
      }
    },
    getPendingActionList() {
      this.PendingActionData = this.getPendingActionList
      this.mutatePendingActionList(this.PendingActionData)
    },
    getKekaResourceDetailByDepartment() {
      this.mutateBuExpList()
    },
    getDepartmentWiseRagStatus() {
      this.mutateDepartmentWiseRagStatus()
    },
    getProjectNames () {
      this.mutateProjectNameList(this.getProjectNames)

    }
  },
  mounted() {
    this.fetchLists()
    this.mutateBuExpList()
    this.PendingActionData = this.getPendingActionList
    this.mutatePendingActionList(this.PendingActionData)
    this.mutateDepartmentWiseRagStatus()
    this.mutateProjectNameList(this.getProjectNames)
  },
  methods: {
    ...mapActions({
      fetchKekaResourceDetailByDepartment:
        'project/fetchKekaResourceDetailByDepartment',
      fetchMyActionItemList: 'AmPmDashboard/fetchMyActionItemList',
      fetchProjectNameListing: 'project/fetchProjectNameListing',
      fetchDepartmentWiseRagStatus: 'project/fetchDepartmentWiseRagStatus'
    }),
    mutateProjectNameList (data) {

      if (data) {
        const filterListArray = []

        data.map((details) => {
          filterListArray.push({
            id: details.uuid,
            name: details.project_name
          })
        })
        this.ProjectFilterList = filterListArray

      }

    },
    async fetchLists() {
      // eslint-disable-next-line no-useless-catch
      try {
        await Promise.all([
          this.fetchKekaResourceDetailByDepartment(this.departmentId),
          this.fetchDepartmentWiseRagStatus(this.departmentId),
          this.fetchMyActionItemList(),
          this.fetchProjectNameListing()
        ])
      } catch (error) {
        throw error
      }
    },

    mutateBuExpList() {
      const { users = [], department = {} } =
        this.getKekaResourceDetailByDepartment

      this.selectedDepartment = department.id
      this.departmentId = department.id
      let expZeroToTwo = 0
      let expTwoToFour = 0
      let expFourToSix = 0
      let expOther = 0

      users.forEach((item, key) => {
        if (item.experience <= 2) {
          expZeroToTwo = expZeroToTwo + 1
        } else if (item.experience <= 4 && item.experience > 2) {
          expTwoToFour = expTwoToFour + 1
        } else if (item.experience <= 6 && item.experience > 4) {
          expFourToSix = expFourToSix + 1
        } else {
          expOther = expOther + 1
        }
      })

      this.resourceCountExpRangeWise = [
        expZeroToTwo,
        expTwoToFour,
        expFourToSix,
        expOther
      ]
      this.selectedDepartmentUserTotalCount = users.length
    },
    mutatePendingActionList(data) {
      if (data) {
        const pendingData = []

        data.map((details) => {
          pendingData.push({
            uuid: details.uuid,
            project_id: details.project_id,
            project: (details.project_name) ? details.project_name.project_name : '',
            priority: this.mapItemsPriority(details.priority),
            targetCloserDate: projectHelpers.listDateFormat(
              details.target_closure_date
            ),
            description: details.description,
            statusId: details.status,
            status: this.mapItemsStatus(details.status)
          })
        })
        this.mutatePendingActionData = pendingData
      }
    },
    mapItemsPriority(value) {
      if (value === constant.PENDING_ACTION_ITEM_PRIORITY.HIGH) {
        return 'High'
      } else if (value === constant.PENDING_ACTION_ITEM_PRIORITY.MEDIUM) {
        return 'Medium'
      } else {
        return 'Low'
      }
    },
    mapItemsStatus(value) {
      if (value === constant.PENDING_ACTION_ITEM_STATUS.TODO) {
        return 'ToDo'
      } else {
        return 'Done'
      }
    },
    mutateDepartmentWiseRagStatus() {
      let redCount = 0
      let greenCount = 0
      let amberCount = 0
      let notApplicableCount = 0

      if (this.getDepartmentWiseRagStatus.Red) {
        redCount =
          this.getDepartmentWiseRagStatus.Red.statusCount.length > 0
            ? [this.getDepartmentWiseRagStatus.Red.statusCount]
            : ['0']
      }
      if (this.getDepartmentWiseRagStatus.Green) {
        greenCount =
          this.getDepartmentWiseRagStatus.Green.statusCount.length > 0
            ? [this.getDepartmentWiseRagStatus.Green.statusCount]
            : ['0']
      }
      if (this.getDepartmentWiseRagStatus.Amber) {
        amberCount =
          this.getDepartmentWiseRagStatus.Amber.statusCount.length > 0
            ? [this.getDepartmentWiseRagStatus.Amber.statusCount]
            : ['0']
      }
      if (this.getDepartmentWiseRagStatus.UnScheduled) {
        notApplicableCount = [
          this.getDepartmentWiseRagStatus.UnScheduled.statusCount
        ]
      }
      this.departmentWiseRagArray = [
        parseInt(redCount),
        parseInt(amberCount),
        parseInt(greenCount),
        parseInt(notApplicableCount)
      ]
    },
    async fetchDepartmentRecord(departmentId) {
      // eslint-disable-next-line no-useless-catch
      try {
        let dept = departmentId

        if (dept === null || dept === '') {
          dept = this.departmentId
        }

        await Promise.all([
          this.fetchKekaResourceDetailByDepartment(dept),
          this.fetchDepartmentWiseRagStatus(dept)
        ])
      } catch (error) {
        throw error
      }
    }
  }
}
</script>

<style scoped>
.pmDashboardOuterWrp .wsrTableFilter h3 {
  line-height: normal;
  padding-bottom: 10px;
}
</style>
