<template>
  <div>
    <common-snackbar :snackbar="snackbarValue" :text-for-snackbar="snackbarText" />
    <Dialog />
    <div>
      <v-card-text class="pt-0">
        <template>
          <div>
            <v-card-actions class="pt-0">
              <v-row style="text-align:center;display:inherit">
                <v-col cols="10" class="pa-0 ma-0" />
                <v-col cols="2" class="pa-0 ma-0">
                  <v-btn
                    color="blue darken-1"
                    small
                    class="text-capitalize ma-2 white--text"
                    @click="openTeamScreen"
                  >
                    RM Change Request
                  </v-btn>
                </v-col>
              </v-row>
            </v-card-actions>
            <v-col cols="12" class="pl-0 pr-1">
              <v-tabs v-model="currentTabIndex" show-arrows class="elevation-2">
                <v-tabs-slider />
                <v-tab
                  v-for="item in tabItems"
                  :key="item.id"
                  class="text-capitalize"
                >
                  {{ item.title }}
                </v-tab>
              </v-tabs>
              <v-tabs-items v-model="currentTabIndex">
                <v-tab-item
                  v-for="item in tabItems"
                  :id="`tab-${item.id}`"
                  :key="item.id"
                />
              </v-tabs-items>
              <v-divider color="lightgray" />
              <ValidationObserver v-if="tabItems[currentTabIndex].id !== 1" ref="changeDirectRm" v-slot="{ valid }">
                <v-data-table
                  v-if="tabItems[currentTabIndex].id !== 1"
                  v-model="requestSelected"
                  :single-select="singleSelect"
                  :headers="changeReportingManager"
                  :items="tabItems[currentTabIndex].content"
                  :hide-default-footer="tabItems[currentTabIndex].content.length ? false : true"
                  :items-per-page="itemsPerPage"
                  :search="search"
                  :sort-by.sync="sortBy"
                  :sort-desc.sync="sortDesc"
                  show-select
                  must-sort
                  class="elevation-2"
                  @item-selected="selectBuTeamOneByOne($event)"
                  @toggle-select-all="selectBuTeamWholeList($event)"
                >
                  <template v-slot:top>
                    <v-container fluid class="pa-0">
                      <v-row class="ma-0">
                        <v-col cols="9" />
                        <v-col cols="3" class="pr-6 pb-1">
                          <v-text-field
                            v-model="search"
                            append-icon="mdi-magnify"
                            label="Search Bar"
                            placeholder="Search"
                            outlined
                            dense
                            clearable
                          />
                        </v-col>
                      </v-row>
                      <v-divider />
                    </v-container>
                  </template>
                  <template v-if="isEnabled('body.prepend')" v-slot:body.prepend="{ headers }">
                    <tr>
                      <td :colspan="headers" />
                      <td :colspan="headers.display_name" />
                      <td :colspan="headers.employee_id" />
                      <td :colspan="headers.email" />
                      <td :colspan="headers.keka_rm" />
                      <td :colspan="headers.reporting_manager" class="pt-4">
                        <p class="black--text lighten-3--text ma-1">
                          Bulk Action
                        </p>
                        <v-autocomplete
                          v-model="selectedReportingManager"
                          :items="reportingManagerList"
                          :search-input.sync="searchRmName"
                          item-text="display_name"
                          item-value="id"
                          outlined
                          dense
                          @change="updateAllReportingManager(selectedReportingManager)"
                        />
                      </td>
                      <td :colspan="headers.status" />
                    </tr>
                  </template>
                  <template v-slot:item.requested_rm_id="{ item }">
                    <ValidationProvider v-if="allBuTeamDataRowsSelected || item.key" v-slot="{ errors }" :rules="'required'" :name="item.requested_rm_id">
                      <v-autocomplete
                        v-model="item.requested_rm_id"
                        :error-messages="errors"
                        :items="reportingManagerList"
                        item-text="display_name"
                        item-value="id"
                        dense
                        outlined
                        class="teamListReportingM"
                      />
                    </ValidationProvider>
                    <ValidationProvider v-else :name="item.requested_rm_id">
                      <v-autocomplete
                        v-model="item.requested_rm_id"
                        :items="reportingManagerList"
                        item-text="display_name"
                        item-value="id"
                        dense
                        outlined
                        disabled
                        class="teamListReportingM"
                      />
                    </ValidationProvider>
                  </template>
                  <template v-slot:item.status="{ item }">
                    <v-btn v-if="item.status === constant.CHANGE_RM_STATUS.ASSISGNED" small class="text-capitalize" color="blue lighten-3">
                      Assigned
                    </v-btn>
                    <v-btn v-else-if="item.status === constant.CHANGE_RM_STATUS.INPROGRESS" small class="text-capitalize" color="pink lighten-4">
                      Keka Mapping Pending
                    </v-btn>
                    <span v-else />
                  </template>
                </v-data-table>
                <v-col
                  cols="12"
                  md="5"
                >
                  <v-row align="end" justify="center">
                    <v-col v-if="!valid || requestSelected.length === 0" cols="12">
                      <v-btn
                        class="text-capitalize ma-2 white--text"
                        color="blue-grey"
                        @click="$router.push('/project-dashboard')"
                      >
                        <v-icon dark left>
                          mdi-arrow-left
                        </v-icon>Back
                      </v-btn>
                      <v-btn :disabled="!valid || requestSelected.length === 0" class="text-capitalize" color="primary" @click="submit">
                        Submit<v-icon dark right>
                          mdi-checkbox-marked-circle
                        </v-icon>
                      </v-btn>
                    </v-col>
                    <v-col v-else cols="12">
                      <v-btn
                        class="text-capitalize ma-2 white--text"
                        color="blue-grey"
                        @click="$router.push('/project-dashboard')"
                      >
                        <v-icon dark left>
                          mdi-arrow-left
                        </v-icon>Back
                      </v-btn>
                      <v-btn :disabled="submitted" class="text-capitalize" color="primary" @click="submit">
                        Submit<v-icon dark right>
                          mdi-checkbox-marked-circle
                        </v-icon>
                      </v-btn>
                    </v-col>
                  </v-row>
                </v-col>
              </ValidationObserver>
              <v-data-table
                v-else
                :headers="directReporting"
                :items="tabItems[currentTabIndex].content"
                :hide-default-footer="tabItems[currentTabIndex].content.length ? false : true"
                :items-per-page="itemsPerPage"
                :search="search"
                :sort-by.sync="sortBy"
                :sort-desc.sync="sortDesc"
                item-key="meta_id"
                class="elevation-4"
              >
                <template v-slot:top>
                  <v-container fluid class="pa-0">
                    <v-row class="ma-0">
                      <v-col cols="9" />
                      <v-col cols="3" class="pr-6 pb-1">
                        <v-text-field
                          v-model="search"
                          append-icon="mdi-magnify"
                          label="Search Bar"
                          placeholder="Search"
                          outlined
                          dense
                          clearable
                        />
                      </v-col>
                    </v-row>
                    <v-divider />
                  </v-container>
                </template>
                <template v-slot:no-data>
                  No Data Available
                </template>
              </v-data-table>
            </v-col>
          </div>
        </template>
      </v-card-text>
    </div>
  </div>
</template>

<script>
import { mapActions, mapGetters } from 'vuex'
import CommonSnackbar from '@/components/CommonSnackbar'
import Dialog from '@/components/Dialog.vue'
import constant from '@/constants/closure-checklist.js'

export default {
  name: 'ResourceDeAllocation',
  layout: 'authenticated',
  middleware: 'authenticated',
  components: {
    Dialog,
    CommonSnackbar
  },
  data () {
    return {
      changeReportingManager: [
        { text: 'Resource Name', sortable: true, value: 'display_name', align: 'center', width: '15%' },
        { text: 'Employee ID', sortable: true, value: 'employee_id', align: 'center', width: '15%' },
        { text: 'Email Address', value: 'email', sortable: true, align: 'center', width: '20%' },
        { text: 'Assigned Reporting Manager', value: 'keka_rm', sortable: true, align: 'center', width: '15%' },
        { text: 'New Reporting Manager', value: 'requested_rm_id', sortable: false, width: '15%', align: 'center' },
        { text: 'Status', value: 'status', sortable: true, align: 'center', width: '20%' }
      ],
      directReporting: [
        { text: 'Resource Name', sortable: true, value: 'display_name', align: 'center' },
        { text: 'Employee ID', sortable: true, value: 'employee_id', align: 'center' },
        { text: 'Email Address', value: 'email', sortable: true, align: 'center' },
        { text: 'Assigned Reporting Manager', value: 'current_rm.full_name', sortable: true, align: 'center' }
      ],
      currentTabIndex: 0,
      tabItems: [{
        id: 1,
        title: 'Direct Reporting',
        content: []
      }],
      selectedReportingManager: null,
      reportingManagerList: [],
      selectedRM: [],
      searchRmName: '',
      sortBy: 'display_name',
      sortDesc: false,
      search: '',
      singleSelect: false,
      selected: [],
      requestSelected: [],
      itemsPerPage: 10,
      snackbarValue: false,
      snackbarText: '',
      unSelectAllBuTeamRows: false,
      allBuTeamDataRowsSelected: false,
      allSelected: false,
      allrecordSelected: false,
      dialog: false,
      constant,
      submitted: false,
      enabled: null,
      tab: null
    }
  },
  computed: {
    ...mapGetters({
      users: 'project/getUserList',
      isButtonLoading: 'project/isButtonLoading',
      directReportingList: 'project/getDirectReportingListToRM',
      getDeptWiseReporting: 'project/getDeptWiseReporting',
      getChangeDirectRm: 'project/getChangeDirectRm'
    })
  },
  watch: {
    currentTabIndex (tab) {
      const tabNumber = Number(this.tabItems[this.currentTabIndex].id) - 1

      if (this.tabItems.id === 1 && tab === 0) {
        this.tabItems.content = this.directReportingList
      }
      if (tabNumber === tab) {
        this.selectedReportingManager = null
        this.allBuTeamDataRowsSelected = false
        if (this.requestSelected.length > 0) {
          this.requestSelected.forEach((item) => {
            item.key = false
            if (item.status === constant.CHANGE_RM_STATUS.ASSISGNED) {
              item.requested_rm_id = null
            }
          })
        }
        this.enabled = null
        this.requestSelected = []
      }
    },
    requestSelected () {
      if (this.allBuTeamDataRowsSelected) {
        this.requestSelected = this.tabItems[this.currentTabIndex].content
      } else if (this.unSelectAllBuTeamRows) {
        this.requestSelected = []
      }
      this.unSelectAllBuTeamRows = false
      this.allBuTeamDataRowsSelected = false
      if (this.requestSelected.length > 0) {
        this.requestSelected.forEach((item) => {
          item.key = true
        })
      }
      if (this.requestSelected.length > 1) {
        this.enabled = 'body.prepend'
        this.allrecordSelected = true
      } else {
        this.enabled = null
        this.allrecordSelected = false
      }
    }
  },
  async fetch ({ app, store }) {
    // eslint-disable-next-line no-useless-catch
    try {
      await Promise.all([
        store.dispatch('project/fetchDirectReportingListToRM'),
        store.dispatch('project/fetchDeptWiseReporting')
      ])
    } catch (error) {
      throw (error)
    }
  },
  mounted () {
    this.$nuxt.$emit('headerTitle', 'My Teams')
    const userDetails = []

    this.users.forEach((value) => {
      if (value) {
        const data = {
          id: value.id,
          display_name: value.full_name
        }

        userDetails.push(data)
      }
    })
    this.reportingManagerList = userDetails
    const deptWiseTeam = this.getDeptWiseReporting
    let tabId = 1
    let tabTitle = ''

    if (deptWiseTeam) {
      Object.entries(deptWiseTeam).forEach(([key, values]) => {
        tabId = Number(tabId) + 1
        tabTitle = 'BU Head' + ' (' + values[0].user_department[0].value + ')'
        this.tabItems.push(
          {
            id: tabId,
            title: tabTitle,
            content: values
          }
        )
      })
    }
    let directReportingData = []

    directReportingData = this.directReportingList
    if (directReportingData) {
      this.tabItems[0].content = this.directReportingList
    }
  },
  methods: {
    ...mapActions({
      setDeptWiseReporting: 'project/setDeptWiseReporting',
      setDirectReportingListToRM: 'project/setDirectReportingListToRM',
      setChangeDirectReportingManager: 'project/setChangeDirectReportingManager',
      setCustomDialog: 'project/setCustomDialog',
      updateLoadingAction: 'project/updateLoadingAction'
    }),
    openTeamScreen () {
      this.$router.push('/teams')
    },
    selectBuTeamOneByOne (event) {
      if (!event.value && event.item.requested_rm_id) {
        event.item.requested_rm_id = null
        event.item.key = false
      }
    },
    selectBuTeamWholeList (event) {
      if (event.value) {
        this.search = ''
        this.allBuTeamDataRowsSelected = true
        this.enabled = 'body.prepend'
      } else {
        this.unSelectAllBuTeamRows = true
        this.enabled = null
        this.requestSelected.forEach((item) => {
          item.requested_rm_id = null
        })
        this.selectedReportingManager = null
      }
    },
    isEnabled (slot) {
      return this.enabled === slot
    },
    updateAllReportingManager (val) {
      this.searchRmName = ''
      if (this.enabled !== null) {
        this.requestSelected.forEach((item) => {
          item.requested_rm_id = val
        })
      }
    },
    async submit () {
      this.updateLoadingAction()
      const changeRmDirectly = []
      let deptId = null
      let requestedRmId = null
      let existingRequestedRmId = null
      const rmReqData = this.requestSelected || []

      for (let i = 0; i < rmReqData.length; i++) {
        let activeRmId = null

        // eslint-disable-next-line no-loop-func
        this.users.find((item) => {
          if (item.id === rmReqData[i].id) {
            if (item.dept.length > 0) {
              deptId = item.dept[0].id
            }
          }
        })
        if (rmReqData[i].current_rm) {
          activeRmId = rmReqData[i].current_rm.id
        }
        if (rmReqData[i].requested_rm_id) {
          const type = Object.prototype.toString.call(rmReqData[i].requested_rm_id)

          if (type === '[object Object]') {
            requestedRmId = rmReqData[i].requested_rm_id.id
          } else {
            requestedRmId = rmReqData[i].requested_rm_id
          }
        }
        // eslint-disable-next-line no-loop-func
        this.tabItems[this.currentTabIndex].content.find((value) => {
          if (value.requested_rm_id && value.id === rmReqData[i].id) {
            existingRequestedRmId = value.requested_rm_id.id
          }
        })
        if (existingRequestedRmId && existingRequestedRmId === requestedRmId) {
          this.snackbarText = `${rmReqData[i].requested_rm_id.display_name} is already requested for ${rmReqData[i].display_name} `
          this.snackbarValue = true
          setTimeout(() => {
            this.snackbarValue = false
          }, 3000)

          return
        }
        if (rmReqData[i].requested_rm_id) {
          const data = {
            'resource_id': rmReqData[i].id,
            'active_rm_id': activeRmId,
            'requested_rm_id': requestedRmId,
            'dept_id': deptId
          }

          changeRmDirectly.push(data)
        }
      }
      await this.setChangeDirectReportingManager(changeRmDirectly)
      this.updateLoadingAction()
      this.submitted = true
    }
  }
}
</script>

<style scoped>
.v-text-field__slot >>> .theme--light.v-label--is-disabled {
   color: rgba(0, 0, 0, 0.6);
   font-size: 18px
}
.container {
    max-width: 1250px;
}
>>>.v-input.teamListReportingM .v-text-field__details {
    margin: 0;
}

>>>.v-input.teamListReportingM .v-input__slot {
    margin: 0;
}
>>>.v-data-table > .v-data-table__wrapper > table > thead > tr > th {
    padding: 0 8px;
}
>>>.v-data-table > .v-data-table__wrapper > table > tbody > tr > td {
    padding: 15px 8px;
    font-size: smaller !important
}
>>>.v-tabs:not(.v-tabs--vertical) .v-tab {
border-right: 1px solid lightgray;
}

</style>
