<template>
  <div>
    <common-snackbar :snackbar="snackbarValue" :text-for-snackbar="snackbarText" />
    <Dialog />
    <v-card-actions class="pt-0">
      <v-row style="text-align:center;display:inherit">
        <v-col cols="10" class="pa-0 ma-0" />
        <v-col cols="2" class="pa-0 ma-0">
          <v-btn
            color="primary"
            small
            outlined
            class="text-capitalize ma-2 white--black"
            @click="openTeamScreen"
          >
            <v-icon color="blue" small class="pr-1">
              mdi-google-circles-extended
            </v-icon> My Teams
          </v-btn>
        </v-col>
      </v-row>
    </v-card-actions>
    <v-col cols="12" class="pt-6">
      <v-data-table
        v-model="requestSelected"
        :single-select="singleSelect"
        :headers="requestedReportingManager"
        :items="requestedReportingTableData"
        :hide-default-footer="requestedReportingTableData.length ? false : true"
        :items-per-page="itemsPerPage"
        :search="search"
        :sort-by.sync="sortBy"
        :sort-desc.sync="sortDesc"
        show-select
        must-sort
        class="elevation-2"
        @toggle-select-all="selectRequestedWholeList($event)"
      >
        <template v-slot:top>
          <v-container fluid class="pa-0">
            <v-row class="ma-0">
              <v-col cols="9" />
              <v-col cols="3" class="pr-6 pb-1">
                <v-text-field
                  v-model="search"
                  append-icon="mdi-magnify"
                  label="Search Bar"
                  placeholder="Search"
                  outlined
                  dense
                  clearable
                />
              </v-col>
            </v-row>
            <v-divider />
          </v-container>
        </template>
        <template v-slot:item.requested_resource_manager="{ item }">
          <span style="color: blue">
            {{ item.requested_resource_manager.display_name }}      </span>
        </template>
      </v-data-table>
    </v-col>
    <v-col
      cols="12"
      md="5"
    >
      <v-row align="end" justify="end">
        <v-col cols="12" class="pt-0">
          <v-btn
            :disabled="submitted || requestSelected.length === 0"
            class="text-capitalize"
            color="success"
            medium
            @click="acceptRequest"
          >
            Approve
          </v-btn>
          <v-btn
            :disabled="submitted || requestSelected.length === 0"
            class="mx-2 text-capitalize"
            color="error"
            medium
            @click="rejectRequest"
          >
            Reject
          </v-btn>
        </v-col>
      </v-row>
    </v-col>
  </div>
</template>

<script>
import { mapActions, mapGetters } from 'vuex'
import CommonSnackbar from '@/components/CommonSnackbar'
import Dialog from '@/components/Dialog.vue'
import constant from '@/constants/closure-checklist.js'

export default {
  name: 'ResourceDeAllocation',
  layout: 'authenticated',
  middleware: 'authenticated',
  components: {
    Dialog,
    CommonSnackbar
  },
  data () {
    return {
      requestedReportingManager: [
        { text: 'Resource Name', sortable: true, value: 'resource.display_name', align: 'center', width: '12%' },
        { text: 'Employee ID', sortable: true, value: 'resource.employee_id', align: 'center' },
        { text: 'Department', value: 'dept', sortable: true, align: 'center' },
        { text: 'Experience', value: 'resource.experience', sortable: true, align: 'center' },
        { text: 'Assigned Reporting Manager', value: 'resource.keka_rm', sortable: true, align: 'center', width: '12%' },
        { text: 'Requested Reporting Manager', value: 'requested_resource_manager', sortable: true, width: '12%', align: 'center' },
        { text: 'Requested By', value: 'created_by', sortable: true, align: 'center' }
      ],
      sortBy: 'resource.display_name',
      sortDesc: false,
      search: '',
      singleSelect: false,
      requestSelected: [],
      requestedReportingTableData: [],
      itemsPerPage: 10,
      snackbarValue: false,
      snackbarText: '',
      unSelectAllRequestedRows: false,
      allRequestedDataRowsSelected: false,
      checkbox1: true,
      dialog: false,
      constant,
      submitted: false,
      isApproved: false
    }
  },
  computed: {
    ...mapGetters({
      getManagerRequests: 'project/getManagerRequests',
      users: 'project/getUserList'
    })
  },
  watch: {
    requestSelected () {
      if (this.allRequestedDataRowsSelected) {
        this.requestSelected = this.requestedReportingTableData
      } else if (this.unSelectAllRequestedRows) {
        this.requestSelected = []
      }
      this.unSelectAllRequestedRows = false
      this.allRequestedDataRowsSelected = false
    }
  },
  async fetch ({ app, store }) {
    // eslint-disable-next-line no-useless-catch
    try {
      await store.dispatch('project/fetchManagerRequests')
    } catch (error) {
      throw (error)
    }
  },
  mounted () {
    this.$nuxt.$emit('headerTitle', 'Resource Reporting Change Request')
    const requestedData = []

    if (this.getManagerRequests) {
      this.getManagerRequests.forEach((element) => {
        let deptName = ''

        if (element) {
          this.users.find((item) => {
            if (item.id === element.resource_id) {
              if (item.dept.length > 0) {
                deptName = item.dept[0].name
              }
            }
          })
          const data = {
            uuid: element.uuid,
            project_id: element.project_id,
            dept_id: element.dept_id,
            resource_id: element.resource_id,
            active_rm_id: element.active_rm_id,
            requested_rm_id: element.requested_rm_id,
            is_approved: element.is_approved,
            created_by: element.created_by.display_name,
            resource: element.resource,
            dept: deptName,
            active_resource_manager: element.active_resource_manager,
            requested_resource_manager: element.requested_resource_manager,
            created_at: element.created_at,
            deleted_at: element.deleted_at,
            id: element.id,
            updated_at: element.updated_at,
            updated_by: element.updated_by
          }

          requestedData.push(data)
        }
      })
      this.requestedReportingTableData = requestedData
    }
  },
  methods: {
    ...mapActions({
      setManagerApprovalOrRejection: 'project/setManagerApprovalOrRejection',
      setCustomDialog: 'project/setCustomDialog',
      updateLoadingAction: 'project/updateLoadingAction'
    }),
    openTeamScreen () {
      this.$router.push('/teams/team-list')
    },
    selectRequestedWholeList (event) {
      if (event.value) {
        this.search = ''
        this.allRequestedDataRowsSelected = true
      } else {
        this.unSelectAllRequestedRows = true
      }
    },
    async acceptRequest () {
      this.updateLoadingAction()
      const requestResponse = []
      const rmReqData = this.requestSelected || []

      this.isApproved = true
      for (let i = 0; i < rmReqData.length; i++) {
        const data = {
          'uuid': rmReqData[i].uuid,
          'resource_id': rmReqData[i].resource_id,
          'active_rm_id': rmReqData[i].active_rm_id,
          'requested_rm_id': rmReqData[i].requested_rm_id,
          'dept_id': rmReqData[i].dept_id,
          'project_id': rmReqData[i].project_id
        }

        requestResponse.push(data)
      }
      const finalData = {
        'resource_data': requestResponse,
        'is_approved': this.isApproved
      }

      await this.setManagerApprovalOrRejection(finalData)
      this.updateLoadingAction()
      this.submitted = true
    },
    async rejectRequest () {
      this.updateLoadingAction()
      const requestResponse = []
      const rmReqData = this.requestSelected || []

      for (let i = 0; i < rmReqData.length; i++) {
        const data = {
          'uuid': rmReqData[i].uuid,
          'resource_id': rmReqData[i].resource_id,
          'active_rm_id': rmReqData[i].active_rm_id,
          'requested_rm_id': rmReqData[i].requested_rm_id,
          'dept_id': rmReqData[i].dept_id,
          'project_id': rmReqData[i].project_id
        }

        requestResponse.push(data)
      }
      const finalData = {
        'resource_data': requestResponse,
        'is_approved': this.isApproved
      }

      await this.setManagerApprovalOrRejection(finalData)
      this.updateLoadingAction()
      this.submitted = true
    }
  }
}
</script>

<style scoped>
.v-text-field__slot >>> .theme--light.v-label--is-disabled {
   color: rgba(0, 0, 0, 0.6);
   font-size: 18px
}
.container {
    max-width: 1250px;
}
>>>.v-data-table > .v-data-table__wrapper > table > thead > tr > th {
    padding: 0 8px;
}
>>>.v-data-table > .v-data-table__wrapper > table > tbody > tr > td {
    padding: 0 8px;
    font-size: smaller !important
}

</style>
