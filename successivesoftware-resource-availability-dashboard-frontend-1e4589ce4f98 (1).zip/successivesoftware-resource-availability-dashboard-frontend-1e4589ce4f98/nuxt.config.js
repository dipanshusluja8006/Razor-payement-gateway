import config from './configs'

const { gaId } = config.analytics

export default {
  mode: 'spa',
  // ssr: false,
  // target: 'static',
  // Global page headers (https://go.nuxtjs.dev/config-head)
  head: {
    titleTemplate: '%s - ' + process.env.npm_package_name,
    title: process.env.npm_package_name || '',
    meta: [
      { charset: 'utf-8' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1' },
      { hid: 'description', name: 'description', content: process.env.npm_package_description || '' }
    ],
    link: [
      { rel: 'icon', type: 'image/x-icon', href: '/favicon.ico' },
      { rel: 'stylesheet', href: 'https://fonts.googleapis.com/css2?family=Quicksand:wght@500;600;700&display=swap' },
      ...config.icons.map((href) => ({ rel: 'stylesheet', href }))
    ]
  },

  // Global CSS (https://go.nuxtjs.dev/config-css)
  css: [
    '~/assets/scss/theme.scss',
    '~/assets/global-font.css',
    'aos/dist/aos.css'
  ],

  // loading: false,
  loading: {
    color: 'blue'
  },

  // Plugins to run before rendering page (https://go.nuxtjs.dev/config-plugins)
  plugins: [
    // plugins
    '~/plugins/axios',
    '~/plugins/aos',
    { src: '~/plugins/animate.js', mode: 'client' },
    { src: '~/plugins/apexcharts.js',ssr: false },
    { src: '~/plugins/clipboard.js', mode: 'client' },
    { src: '~/plugins/vue-shortkey.js', mode: 'client' },
    { src: '~/filters/capitalize.js' },
    { src: '~/filters/lowercase.js' },
    { src: '~/filters/uppercase.js' },
    { src: '~/filters/formatCurrency.js' },
    { src: '~/filters/formatDate.js' },
    { src: '~/plugins/firebase.js', mode: 'client' },
    { src: '~/plugins/veevalidate.js', mode: 'client' },
    { src: '~/plugins/vue-shortkey.js', mode: 'client' },
    { src: '~/plugins/vuex-persist', ssr: false },
    { src: '~/plugins/vuetify.js', mode: 'client' },
    { src:  '~/plugins/echarts', mode: 'client' },
    { src: '~/plugins/moment', mode: 'client' }
  ],

  // Auto import components (https://go.nuxtjs.dev/config-components)
  // components: true,

  // Modules for dev and build (recommended) (https://go.nuxtjs.dev/config-modules)
  buildModules: [
    '@nuxtjs/eslint-module',
    ['@nuxtjs/dotenv', { /* module options */ }],
    // https://go.nuxtjs.dev/vuetify
    ['@nuxtjs/vuetify', {
      customVariables: ['~/assets/scss/vuetify/variables/_index.scss'],
      optionsPath: '~/configs/vuetify.js',
      treeShake: true,
      defaultAssets: {
        font: false
      }
    }]
  ],

  // Modules (https://go.nuxtjs.dev/config-modules)
  /*
  ** Nuxt.js modules
  */
  modules: [
  // Doc: https://axios.nuxtjs.org/usage
    '@nuxtjs/axios',
    'vue-scrollto/nuxt',
    '@nuxtjs/google-gtag'
    // '@nuxtjs/proxy'
  ],
  /*
  ** Axios module configuration
  ** See https://axios.nuxtjs.org/options
  */
  // axios: {
  //   proxy: true
  // },

  // proxy
  // proxy: {
  //   '/api/': { target: 'http://test.resource-api.writso.com', pathRewrite: { '^/api/': '' }, changeOrigin: true }
  // },

  'google-gtag': {
    id: gaId,
    debug: true, // enable to track in dev mode
    disableAutoPageTrack: false // disable if you don't want to track each page route with router.afterEach(...).
  },

  // Build Configuration (https://go.nuxtjs.dev/config-build)
  /*
  ** Build configuration
  */
  build: {
  /*
  ** You can extend webpack config here
  */
    extend (config, ctx) {
      config.module.rules.push({
        enforce: 'pre',
        test: /\.(js|vue)$/,
        loader: 'eslint-loader',
        exclude: /(node_modules)/,
        options: {
          fix: true
        }
      })
    }
  }
}
