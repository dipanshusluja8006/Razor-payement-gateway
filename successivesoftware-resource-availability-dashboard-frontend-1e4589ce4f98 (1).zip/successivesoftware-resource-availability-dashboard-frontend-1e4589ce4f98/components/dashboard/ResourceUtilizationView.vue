<template>
  <div class="requisitionRequesttabWrp utilizationGraphWrp">
    <div class="cardWrp">
      <div class="cardLeftcol">
        <div class="graphWrp">
          <sources-card
            :offset="-15"
            :label="''"
            :label-array="lable"
            :series="series"
            :color-array="color"
            :fill-array="filler"
            :inner-lable="innerLable"
            :legend-position="'left'"
            :pie-width="'90%'"
            :show-labels="false"
            :show-legend="false"
            :percentage="percentage"
            class="h-full"
            color="#8c9eff"
            :type="'radialBar'"
          />
        </div>
      </div>
      <div class="cardRightcol">
        <div class="utilizationtableWrp">
          <table-card
            :headers="headers"
            :items="utilizationTableData"
            :items-per-page="5"
            :sort-by="['name']"
            :sort-desc="false"
            :show-expand="false"
            :hide-default-footer="utilizationTableData.length ? false : true"
            class="utilizationTable"
          />
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { mapActions, mapGetters } from 'vuex'
import SourcesCard from './SourcesCard'
import TableCard from './TableCard.vue'

export default {
  name: 'CustomDialog',
  components: { SourcesCard, TableCard },
  props: {
    utilizationTableData: {
      type: Array,
      default: () => ([])
    },
    series: {
      type: Array,
      default: () => ([])
    },
    lable: {
      type: Array,
      default: () => ([])
    },
    percentage: {
      type: Number,
      default: 0
    },
    innerLable: {
      type: String,
      default: ''
    },
    color: {
      type: Array,
      default: () => ([])
    },
    filler: {
      type: Object,
      default: () => ({})
    }
  },
  data () {
    return {
      sent: false,
      sentMessage: this.buttonText,
      headers: [
        { text: 'Resource', value: 'name' },
        { text: 'Project Name', value: 'projectName' },
        { text: 'Department.', value: 'department' },
        { text: 'From', value: 'startDate' },
        { text: 'To', value: 'endDate' },
        { text: 'Utilization %', value: 'utilizationPercentage' }
      ]
    }
  },
  computed: {
    ...mapGetters({
      getTimesheetSummary: 'dashboard/getTimesheetSummary',
      getInvoiceSummary: 'dashboard/getInvoiceSummary'
    })
  },
  methods: {
    ...mapActions({
      sendTimeSheetReminder: 'dashboard/sendTimeSheetReminder'
    })
  }
}
</script>

<style scoped>
.cardWrp {
    display: flex;
    justify-content: space-between;
    min-height: 310px;
}
.cardLeftcol {
    width: 30%;
    padding: 0 20px 0 0;
}
.cardRightcol {
    width: 70%;
}
#projectDashboard .resourceUtilizationWrp .gnrtGraph .apexcharts-legend.apexcharts-align-center.position-right {
    top: 0 !important;
}
</style>