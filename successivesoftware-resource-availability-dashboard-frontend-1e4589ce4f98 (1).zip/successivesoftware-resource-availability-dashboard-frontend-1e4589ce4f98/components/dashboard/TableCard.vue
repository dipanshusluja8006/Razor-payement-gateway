<template>
  <div>
    <v-card>
      <v-data-table
        :headers="headers"
        :items="items"
        :items-per-page="itemsPerPage"
        :sort-by="sortBy"
        :sort-desc="sortDesc"
        :loading="loading"
        :loading-text="loadingText"
        :hide-default-footer="hideDefaultFooter"
        :single-expand="singleExpand"
        :show-expand="showExpand"
        must-sort
        item-key="uuid"
      >
        <template v-slot:expanded-item="{headers, item}">
          <td :colspan="headers.length +1" class="px-0">
            <v-simple-table v-if="loadingSkeletonForFully">
              <template v-slot:default>
                <v-skeleton-loader
                  height="94"
                  type="list-item-two-line"
                />
              </template>
            </v-simple-table>
            <v-simple-table v-else class="resourceDashboardInnerTableWrp">
              <template v-slot:default>
                <thead>
                  <tr>
                    <th>Project name</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Sch Hrs.</th>
                  </tr>
                </thead>
                <tbody>
                  <template v-for="(data, index) in item.projectInfo">
                    <tr :key="index">
                      <td>{{ data.projectName }}</td>
                      <td>{{ new Date(data.startDate ).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }) }}</td>
                      <td>{{ new Date(data.endDate ).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }) }}</td>
                      <td>{{ data.hours }}</td>
                    </tr>
                  </template>
                </tbody>
              </template>
            </v-simple-table>
          </td>
        </template>
        <template v-slot:item.total="{ item }">
          {{ Number.isInteger(item.total) ? item.total: item.total.toFixed(2) }}
        </template>
        <template v-slot:item.utilizationPercentage="{ item }">
          {{ Number.isInteger(item.utilizationPercentage) ? item.utilizationPercentage+'%': item.total.toFixed(2)+'%' }}
        </template>
        <template v-slot:item.skill="{ item }">
          <span :title="item.skill">{{ item.skill }}</span>
        </template>
      </v-data-table>
    </v-card>
  </div>
</template>

<script>

/*
|---------------------------------------------------------------------
| Table Card Dashboard Component
|---------------------------------------------------------------------
|
| Table card component to be used to gather resource information for
| underschedule, overschedule, partially schedule and fully schedule
|
*/

export default {
  props: {
    label: {
      type: String,
      default: ''
    },
    titleColor: {
      type: String,
      default: ''
    },
    iconColor: {
      type: String,
      default: ''
    },
    hideDefaultFooter: {
      type: Boolean,
      default: false
    },
    itemsPerPage: {
      type: Number,
      default: 10
    },
    sortBy: {
      type: Array,
      default: () => ([])
    },
    sortDesc: {
      type: Boolean,
      default: false
    },
    showExpand: {
      type: Boolean,
      default: false
    },
    loading: {
      type: Boolean,
      default: false
    },
    loadingText: {
      type: String,
      default: ''
    },
    value: {
      type: String,
      default: ''
    },
    singleExpand: {
      type: Boolean,
      default: true
    },
    headers: {
      type: Array,
      default: () => ([])
    },
    items: {
      type: Array,
      default: () => ([])
    }
  },
  data () {
    return {
      loadingSkeletonForPartially: false,
      loadingSkeletonForFully: false,
      loadingSkeletonForOver: false
    }
  }
}
</script>
