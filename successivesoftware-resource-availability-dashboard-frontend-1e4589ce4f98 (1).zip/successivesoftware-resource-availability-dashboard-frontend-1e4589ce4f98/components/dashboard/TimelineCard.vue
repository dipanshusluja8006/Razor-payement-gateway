<template>
  <div v-if="showChart">
    <apexchart type="rangeBar" :options="chartOptions" :series="series"></apexchart>
  </div>
</template>

<script>
export default {
  props: {
    dataSeries: {
      type: Array,
      default: () => ([])
    },
    label: {
      type: String,
      default: ''
    },
    color: {
      type: String,
      default: '#333333'
    },
    value: {
      type: Number,
      default: 0
    },
    pieWidth: {
      type: String,
      default: '85%'
    },
    percentage: {
      type: Number,
      default: 0
    },
    percentageLabel: {
      type: String,
      default: 'vs. last week'
    },
    options: {
      type: Object,
      default: () => ({})
    },
    loading: {
      type: Boolean,
      default: false
    },
    labelArray: {
      type: Array,
      default: () => ([])
    },
    colorArray: {
      type: Array,
      default: () => ([])
    },
    fillArray: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      showChart: false,
      series: [{ data: this.dataSeries }],
      chartOptions: {
        chart: {
          height: 'auto',
          type: 'rangeBar'
        },
        plotOptions: {
          bar: {
            horizontal: true,
            distributed: true,
            dataLabels: {
              hideOverflowingLabels: false
            }
          }
        },
        dataLabels: {
          enabled: true,
          formatter: (val, opts) => {
            const label = opts.w.globals.labels[opts.dataPointIndex]
            const a = this.$moment(val[0])
            const b = this.$moment(val[1])
            const diff = b.diff(a, 'days')

            return label + ': ' + diff + (diff > 1 ? ' days' : ' day')
          },
          style: {
            colors: ['#f3f4f5', '#fff']
          }
        },
        xaxis: {
          type: 'datetime',
          position: 'top'
        },
        yaxis: {
          show: false
        },
        grid: {
          row: {
            colors: ['#f3f4f5', '#fff'],
            opacity: 1
          }
        }
      }
    }
  },
  mounted() {
    this.showChart = true
  }
}
</script>
