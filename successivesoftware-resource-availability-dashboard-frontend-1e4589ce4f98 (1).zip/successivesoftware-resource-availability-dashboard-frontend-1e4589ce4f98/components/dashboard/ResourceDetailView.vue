<template>
  <v-card>
    <div class="overScheduledHeadingWrp">
      <div class="overScheduledLeftHWrp">
        <v-card-title :class="titleColor">
          <v-icon :color="iconColor" small>
            mdi-checkbox-blank-circle
          </v-icon>
          &nbsp; {{ label }} ({{ tableItems.length }})
          &nbsp;
        </v-card-title>
        <div class="searchFieldS">
          <v-text-field
            v-model="search"
            append-icon="mdi-magnify"
            label="Search"
            outlined
            rounded
            clearable
            dense
            single-line
            hide-details
          />
        </div>
      </div>
      <div class="overScheduledRightWrp">
        <div v-for="chart in chartHeader" :key="chart.id" class="overScheduledRightQuoter">
          <div class="overScheduledRightQuoterH"><span>{{ chart.title }}</span></div>
          <div class="overScheduledRightQuoterMonthWrp">
            <ul>
              <li v-for="month in chart.months" :key="month">{{ month }}</li>
            </ul>
          </div>
        </div>
      </div>
    </div>

    <v-simple-table>
      <template v-slot:default>
        <tbody>
          <tr>
            <td :class="tableDataWrap">
              <v-data-table
                :headers="headers"
                :items="tableItems"
                :items-per-page="itemsPerPage"
                :sort-by="sortBy"
                :sort-desc="sortDesc"
                :loading="loading"
                :search="search"
                :loading-text="loadingText"
                :hide-default-footer="tableItems.length ? false : true"
                :single-expand="singleExpand"
                :show-expand="showExpand"
                must-sort
                item-key="uuid"
                class="dataWrp"
                @current-items="currentItems"
                @item-expanded="fetchProjectInfo($event)"
              >
                <template v-slot:expanded-item="{ headers, item }">
                  <td :colspan="headers.length +1" class="px-0" width="50%">
                    <div class="allProjects">
                      <ul>
                        <li v-for="(data, index) in item.projectInfo" :key="index">
                          <span class="projectName">{{ data.projectName }}</span>
                          <span class="workingHrs">{{ data.hours }}</span>
                        </li>
                      </ul>
                    </div>
                  </td>
                </template>
                <template v-slot:item.skill="{ item }">
                  <span :title="item.skill">{{ item.skill }}</span>
                </template>
                <template v-slot:item.total="{ item }">
                  {{ Number.isInteger(item.total) ? item.total: item.total.toFixed(2) }}
                </template>
              </v-data-table>
            </td>
            <td class="leftGraphWrp" >
              <div class="graphListWrp">
                <ul>
                  <li v-for="item in currentData" :key="item.uuid">
                    <div v-if="item.monthIndex === 0 && item.endMonthIndex === 0" class="progressWrp">
                      <div :class="item.commonClass">
                        <div>
                          <div class="toolTipWrp">
                            <div class="overScheduledTooltip">
                              <h6>{{ item.text }} for {{ item.differenceInHr }} Hrs</h6>
                              <div class="nameDtail">
                                <span class="graphName"><strong>{{ item.name }}</strong>, {{ item.location }}</span>
                                <span class="totalHrs"> {{ Number.isInteger(item.total) ? item.total: item.total.toFixed(2) }} Hrs</span>
                              </div>
                            </div>
                            <div class="ashishProjects">
                              <ul>
                                <li v-for="(project, index) in item.projectInfo" :key="index">
                                  <span>{{ project.projectName }}</span>
                                  <span>{{ project.hours }}</span>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                        <div></div>
                        <div></div>
                      </div>
                      <div class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                    </div>
                    <div v-else-if="item.monthIndex === 0 && item.endMonthIndex > item.monthIndex" class="progressWrp">
                      <div :class="item.startClass">
                        <div>
                          <div class="toolTipWrp">
                            <div class="overScheduledTooltip">
                              <h6>{{ item.text }} for {{ item.differenceInHr }} Hrs</h6>
                              <div class="nameDtail">
                                <span class="graphName"><strong>{{ item.name }}</strong>, {{ item.location }}</span>
                                <span class="totalHrs"> {{ Number.isInteger(item.total) ? item.total: item.total.toFixed(2) }} Hrs</span>
                              </div>
                            </div>
                            <div class="ashishProjects">
                              <ul>
                                <li v-for="(project, index) in item.projectInfo" :key="index">
                                  <span>{{ project.projectName }}</span>
                                  <span>{{ project.hours }}</span>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                        <div></div>
                        <div></div>
                      </div>
                      <div v-if="item.endMonthIndex === 1" :class="item.endClass">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div v-if="item.endMonthIndex > 1 && item.endMonthIndex <= 5" :class="item.fullBarClass">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div v-if="item.endMonthIndex < 1" class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div v-if="item.endMonthIndex === 2" :class="item.endClass">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div v-if="item.endMonthIndex > 2 && item.endMonthIndex <= 5" :class="item.fullBarClass">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div v-if="item.endMonthIndex < 2" class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div v-if="item.endMonthIndex === 3" :class="item.endClass">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div v-if="item.endMonthIndex > 3 && item.endMonthIndex <= 5" :class="item.fullBarClass">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div v-if="item.endMonthIndex < 3" class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div v-if="item.endMonthIndex === 4" :class="item.endClass">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div v-if="item.endMonthIndex > 4" :class="item.fullBarClass">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div v-if="item.endMonthIndex < 4" class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div v-if="item.endMonthIndex === 5" :class="item.endClass">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div v-if="item.endMonthIndex !== 5" class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                    </div>
                    <div v-else-if="item.monthIndex === 1 && item.endMonthIndex === 1" class="progressWrp">
                      <div class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div :class="item.commonClass">
                        <div>
                          <div class="toolTipWrp">
                            <div class="overScheduledTooltip">
                              <h6>{{ item.text }} for {{ item.differenceInHr }} Hrs</h6>
                              <div class="nameDtail">
                                <span class="graphName"><strong>{{ item.name }}</strong>, {{ item.location }}</span>
                                <span class="totalHrs">{{ Number.isInteger(item.total) ? item.total: item.total.toFixed(2) }} Hrs</span>
                              </div>
                            </div>
                            <div class="ashishProjects">
                              <ul>
                                <li v-for="(project, index) in item.projectInfo" :key="index">
                                  <span>{{ project.projectName }}</span>
                                  <span>{{ project.hours }}</span>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                        <div></div>
                        <div></div>
                      </div>

                      <div class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                    </div>
                    <div v-else-if="item.monthIndex === 1 && item.endMonthIndex > item.monthIndex" class="progressWrp">
                      <div class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div :class="item.startClass">
                        <div>
                          <div class="toolTipWrp">
                            <div class="overScheduledTooltip">
                              <h6>{{ item.text }} for {{ item.differenceInHr }} Hrs</h6>
                              <div class="nameDtail">
                                <span class="graphName"><strong>{{ item.name }}</strong>, {{ item.location }}</span>
                                <span class="totalHrs">{{ Number.isInteger(item.total) ? item.total: item.total.toFixed(2) }} Hrs</span>
                              </div>
                            </div>
                            <div class="ashishProjects">
                              <ul>
                                <li v-for="(project, index) in item.projectInfo" :key="index">
                                  <span>{{ project.projectName }}</span>
                                  <span>{{ project.hours }}</span>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                        <div></div>
                        <div></div>
                      </div>

                      <div v-if="item.endMonthIndex === 2" :class="item.endClass">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div v-if="item.endMonthIndex > 2 && item.endMonthIndex <= 5" :class="item.fullBarClass">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div v-if="item.endMonthIndex < 2" class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div v-if="item.endMonthIndex === 3" :class="item.endClass">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div v-if="item.endMonthIndex > 3 && item.endMonthIndex <= 5" :class="item.fullBarClass">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div v-if="item.endMonthIndex < 3" class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div v-if="item.endMonthIndex === 4" :class="item.endClass">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div v-if="item.endMonthIndex > 4" :class="item.fullBarClass">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div v-if="item.endMonthIndex < 4" class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div v-if="item.endMonthIndex === 5" :class="item.endClass">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div v-if="item.endMonthIndex !== 5" class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                    </div>
                    <div v-else-if="item.monthIndex === 2 && item.endMonthIndex === 2" class="progressWrp">
                      <div class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div :class="item.commonClass">
                        <div>
                          <div class="toolTipWrp">
                            <div class="overScheduledTooltip">
                              <h6>{{ item.text }} for {{ item.differenceInHr }} Hrs</h6>
                              <div class="nameDtail">
                                <span class="graphName"><strong>{{ item.name }}</strong>, {{ item.location }}</span>
                                <span class="totalHrs">{{ Number.isInteger(item.total) ? item.total: item.total.toFixed(2) }} Hrs</span>
                              </div>
                            </div>
                            <div class="ashishProjects">
                              <ul>
                                <li v-for="(project, index) in item.projectInfo" :key="index">
                                  <span>{{ project.projectName }}</span>
                                  <span>{{ project.hours }}</span>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                        <div></div>
                        <div></div>
                      </div>
                      <div class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                    </div>
                    <div v-else-if="item.monthIndex === 2 && item.endMonthIndex > item.monthIndex" class="progressWrp">
                      <div class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div :class="item.startClass">
                        <div>
                          <div class="toolTipWrp">
                            <div class="overScheduledTooltip">
                              <h6>{{ item.text }} for {{ item.differenceInHr }} Hrs</h6>
                              <div class="nameDtail">
                                <span class="graphName"><strong>{{ item.name }}</strong>, {{ item.location }}</span>
                                <span class="totalHrs">{{ Number.isInteger(item.total) ? item.total: item.total.toFixed(2) }} Hrs</span>
                              </div>
                            </div>
                            <div class="ashishProjects">
                              <ul>
                                <li v-for="(project, index) in item.projectInfo" :key="index">
                                  <span>{{ project.projectName }}</span>
                                  <span>{{ project.hours }}</span>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                        <div></div>
                        <div></div>
                      </div>
                      <div v-if="item.endMonthIndex === 3" :class="item.endClass">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div v-if="item.endMonthIndex > 3 && item.endMonthIndex <= 5" :class="item.fullBarClass">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div v-if="item.endMonthIndex < 3" class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div v-if="item.endMonthIndex === 4" :class="item.endClass">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div v-if="item.endMonthIndex > 4" :class="item.fullBarClass">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div v-if="item.endMonthIndex < 4" class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div v-if="item.endMonthIndex === 5" :class="item.endClass">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div v-if="item.endMonthIndex !== 5" class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                    </div>
                    <div v-else-if="item.monthIndex === 3 && item.endMonthIndex === 3" class="progressWrp">
                      <div class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div :class="item.commonClass">
                        <div>
                          <div class="toolTipWrp">
                            <div class="overScheduledTooltip">
                              <h6>{{ item.text }} for {{ item.differenceInHr }} Hrs</h6>
                              <div class="nameDtail">
                                <span class="graphName"><strong>{{ item.name }}</strong>, {{ item.location }}</span>
                                <span class="totalHrs">{{ Number.isInteger(item.total) ? item.total: item.total.toFixed(2) }} Hrs</span>
                              </div>
                            </div>
                            <div class="ashishProjects">
                              <ul>
                                <li v-for="(project, index) in item.projectInfo" :key="index">
                                  <span>{{ project.projectName }}</span>
                                  <span>{{ project.hours }}</span>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                        <div></div>
                        <div></div>
                      </div>

                      <div class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                    </div>
                    <div v-else-if="item.monthIndex === 3 && item.endMonthIndex > item.monthIndex" class="progressWrp">
                      <div class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div :class="item.startClass">
                        <div>
                          <div class="toolTipWrp">
                            <div class="overScheduledTooltip">
                              <h6>{{ item.text }} for {{ item.differenceInHr }} Hrs</h6>
                              <div class="nameDtail">
                                <span class="graphName"><strong>{{ item.name }}</strong>, {{ item.location }}</span>
                                <span class="totalHrs">{{ Number.isInteger(item.total) ? item.total: item.total.toFixed(2) }} Hrs</span>
                              </div>
                            </div>
                            <div class="ashishProjects">
                              <ul>
                                <li v-for="(project, index) in item.projectInfo" :key="index">
                                  <span>{{ project.projectName }}</span>
                                  <span>{{ project.hours }}</span>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                        <div></div>
                        <div></div>
                      </div>

                      <div v-if="item.endMonthIndex === 4" :class="item.endClass">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div v-if="item.endMonthIndex > 4" :class="item.fullBarClass">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div v-if="item.endMonthIndex < 4" class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div v-if="item.endMonthIndex === 5" :class="item.endClass">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div v-if="item.endMonthIndex !== 5" class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                    </div>
                    <div v-else-if="item.monthIndex === 4 && item.endMonthIndex === 4" class="progressWrp">
                      <div class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div :class="item.commonClass">
                        <div>
                          <div class="toolTipWrp">
                            <div class="overScheduledTooltip">
                              <h6>{{ item.text }} for {{ item.differenceInHr }} Hrs</h6>
                              <div class="nameDtail">
                                <span class="graphName"><strong>{{ item.name }}</strong>, {{ item.location }}</span>
                                <span class="totalHrs">{{ Number.isInteger(item.total) ? item.total: item.total.toFixed(2) }} Hrs</span>
                              </div>
                            </div>
                            <div class="ashishProjects">
                              <ul>
                                <li v-for="(project, index) in item.projectInfo" :key="index">
                                  <span>{{ project.projectName }}</span>
                                  <span>{{ project.hours }}</span>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                        <div></div>
                        <div></div>
                      </div>

                      <div class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                    </div>
                    <div v-else-if="item.monthIndex === 4 && item.endMonthIndex > item.monthIndex" class="progressWrp">
                      <div class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div :class="item.startClass">
                        <div>
                          <div class="toolTipWrp">
                            <div class="overScheduledTooltip">
                              <h6>{{ item.text }} for {{ item.differenceInHr }} Hrs</h6>
                              <div class="nameDtail">
                                <span class="graphName"><strong>{{ item.name }}</strong>, {{ item.location }}</span>
                                <span class="totalHrs">{{ Number.isInteger(item.total) ? item.total: item.total.toFixed(2) }} Hrs</span>
                              </div>
                            </div>
                            <div class="ashishProjects">
                              <ul>
                                <li v-for="(project, index) in item.projectInfo" :key="index">
                                  <span>{{ project.projectName }}</span>
                                  <span>{{ project.hours }}</span>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                        <div></div>
                        <div></div>
                      </div>

                      <div v-if="item.endMonthIndex === 5" :class="item.endClass">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>

                      <div v-if="item.endMonthIndex !== 5" class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                    </div>
                    <div v-else-if="item.monthIndex === 5 && item.endMonthIndex === 5" class="progressWrp">
                      <div class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div class="myBar">
                        <div></div>
                        <div></div>
                        <div></div>
                      </div>
                      <div :class="item.startClass">
                        <div>
                          <div class="toolTipWrp">
                            <div class="overScheduledTooltip">
                              <h6>{{ item.text }} for {{ item.differenceInHr }} Hrs</h6>
                              <div class="nameDtail">
                                <span class="graphName"><strong>{{ item.name }}</strong>, {{ item.location }}</span>
                                <span class="totalHrs">{{ Number.isInteger(item.total) ? item.total: item.total.toFixed(2) }} Hrs</span>
                              </div>
                            </div>
                            <div class="ashishProjects">
                              <ul>
                                <li v-for="(project, index) in item.projectInfo" :key="index">
                                  <span>{{ project.projectName }}</span>
                                  <span>{{ project.hours }}</span>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                        <div></div>
                        <div></div>
                      </div>
                    </div>
                    <div v-if="item.expand === true">
                      <div v-for="(project,index) in item.projectInfo" :key="index" class="expandSpace"/>
                    </div>
                  </li>
                </ul>
              </div>
            </td>
          </tr>
        </tbody>
      </template>
    </v-simple-table>
  </v-card>

</template>

<script>
import { mapActions, mapGetters } from 'vuex'
import constant from '@/constants/closure-checklist.js'

export default {
  props: {
    label: {
      type: String,
      default: ''
    },
    titleColor: {
      type: String,
      default: ''
    },
    iconColor: {
      type: String,
      default: ''
    },
    hideDefaultFooter: {
      type: Boolean,
      default: false
    },
    itemsPerPage: {
      type: Number,
      default: 10
    },
    sortBy: {
      type: Array,
      default: () => ([])
    },
    sortDesc: {
      type: Boolean,
      default: false
    },
    showExpand: {
      type: Boolean,
      default: false
    },
    loading: {
      type: Boolean,
      default: false
    },
    loadingText: {
      type: String,
      default: ''
    },
    value: {
      type: String,
      default: ''
    },
    singleExpand: {
      type: Boolean,
      default: true
    },
    headers: {
      type: Array,
      default: () => ([])
    },
    items: {
      type: Array,
      default: () => ([])
    }
  },
  data () {
    return {
      currentData: [],
      chartHeader: [],
      monthArray: [],
      search:'',
      expandRecord: false,
      projectDetails: [],
      tableItems: [],
      tableDataWrap: 'tableDataWrp'
    }
  },
  computed: {
    ...mapGetters({
      getMonthsArray: 'dashboard/getMonthsArray',
      overScheduledTableData: 'dashboard/overScheduledDownload',
      unscheduledTableData: 'dashboard/unscheduledDownload',
      fullyScheduledTableData: 'dashboard/fullyScheduledDownload',
      partiallyScheduledTableData: 'dashboard/partiallyScheduledDownload',
      changeTableView: 'theme/changeTableView'
    })
  },
  mounted() {
    if (this.label === '') {
      this.setChangeTableView(true)
    }
    this.currentItems(this.currentData)
    const startMonthArray = []
    const endMonthArray = []
    const endYearArray = []
    const startYearArray = []
    const d = new Date()
    // let currentYear = d.getFullYear()
    const currentMonth = d.getMonth()

    this.tableItems = this.items

    this.tableItems.forEach((value) => {
      const end = new Date(value.endDate)
      const start = new Date(value.startDate)
      const endMonth = '' + (end.getMonth() + 1)
      const startMonth = '' + (start.getMonth() + 1)
      const endYear = end.getFullYear()
      const startYear = start.getFullYear()

      endMonthArray.push(endMonth)
      endYearArray.push(endYear)
      startMonthArray.push(startMonth)
      startYearArray.push(startYear)
    })
    const endMonths = endMonthArray.filter((v, i, a) => a.indexOf(v) === i )
    const endYears = endYearArray.filter((v, i, a) => a.indexOf(v) === i )
    const startMonths = startMonthArray.filter((v, i, a) => a.indexOf(v) === i )
    // const startYears = startYearArray.filter((v, i, a) => a.indexOf(v) === i )

    // if (endYears[0] === startYears[0]) {
    //   currentYear = endYears[0]
    // }
    // const lastMonth = endMonths.pop()
    // const firstMonth = startMonths[0]

    // const finalRange = this.getAllMonths( startMonths[0], endMonths.pop())

    if (currentMonth < 7 && endMonths.pop() < 7 && startMonths[0] >= 1) {
      this.chartHeader.push(
        {
          id: 1,
          title: 'Q1',
          months: [`Jan,${endYears[0]}`, `Feb,${endYears[0]}`, `Mar,${endYears[0]}`],
          monthNumber: [1, 2, 3]
        },
        {
          id: 2,
          title: 'Q2',
          months: [`Apr,${endYears[0]}`, `May,${endYears[0]}`, `Jun,${endYears[0]}`],
          monthNumber: [4, 5, 6]
        }
      )
    } else {
      this.chartHeader.push(
        {
          id: 1,
          title: 'Q3',
          months: [`Jul,${endYears[0]}`, `Aug,${endYears[0]}`, `Sep,${endYears[0]}`],
          monthNumber: [7, 8, 9]
        },
        {
          id: 2,
          title: 'Q4',
          months: [`Oct,${endYears[0]}`, `Nov,${endYears[0]}`, `Dec,${endYears[0]}`],
          monthNumber: [10, 11, 12]
        }
      )
    }

    const monthData = []

    this.chartHeader.forEach((value) => {
      value.monthNumber.forEach((item) => {
        monthData.push(item)
      })
    })
    this.updateMonthsArray(monthData)
  },
  methods: {
    ...mapActions({
      updateMonthsArray: 'dashboard/updateMonthsArray',
      setChangeTableView: 'theme/setChangeTableView'

    }),
    currentItems (currentDetails) {
      let startDateRange = ''
      let startClass = ''
      let endDateRange = ''
      let endClass = ''

      this.filteredData()
      this.currentData = []
      currentDetails.forEach((value) => {
        const end = new Date(value.endDate)
        const start = new Date(value.startDate)
        const endDay = '' + (end.getDate())
        const startDay = '' + (start.getDate())
        const startMonth = start.getMonth() + 1
        const endMonth = end.getMonth() + 1
        let sMonth = ''
        let eMonth = ''
        let monthIndex = ''
        let endMonthIndex = ''
        let commonClass = ''
        let fullBarClass = 'myBar fullBar'

        if (this.getMonthsArray) {
          this.getMonthsArray.map((month,index) => {
            if (startMonth === month) {
              sMonth = month
              monthIndex = index
            }
            if (endMonth === month) {
              eMonth = month
              endMonthIndex = index
            }
          })
        }
        /**
         * fetch common class range wise
         */
        if (startMonth === endMonth) {

          if (startDay <= 10 && endDay <= 10) {
            commonClass = 'myBar radiousLft bar1-10 radiousRgt'
          } else if ((startDay > 10 && startDay <= 20) && (endDay > 10 && endDay <= 20)) {
            commonClass = 'myBar radiousLft bar11-20 radiousRgt'
          } else if (startDay > 20 && endDay > 20) {
            commonClass = 'myBar radiousLft bar21-30 radiousRgt'
          } else if (startDay <= 10 && endDay > 20) {
            commonClass = 'myBar radiousLft fullBar radiousRgt'
          } else if (startDay > 10 && endDay > 20) {
            commonClass = 'myBar radiousLft bar11-30 radiousRgt'
          } else {
            commonClass = 'myBar radiousLft bar1-20 radiousRgt'
          }
        }
        /**
         * fetch start and end class range wise
         */
        if (startDay <= 10) {
          startDateRange = '1-10'
          startClass = 'myBar fullBar radiousLft'
        } else if (startDay > 10 && startDay <= 20) {
          startDateRange = '11-20'
          startClass = 'myBar bar11-30 radiousLft'
        } else {
          startDateRange = '21-30'
          startClass = 'myBar bar21-30 radiousLft'
        }

        if (endDay <= 10) {
          endDateRange = '1-10'
          endClass = 'myBar lastBar1-10 radiousRgt'
        } else if (endDay > 10 && endDay <= 20) {
          endDateRange = '11-20'
          endClass = 'myBar lastBar1-20 radiousRgt'
        } else {
          endDateRange = '21-30'
          endClass = 'myBar fullBar radiousRgt'
        }
        let differenceInHr = 0

        if (value.total === 0) {
          differenceInHr = value.total + 8
        }
        else if (value.total > 8) { 
          differenceInHr =  value.total - 8 
        } else if (value.total < 8) {
          differenceInHr = value.total
        } else if (value.total === 8) {
          differenceInHr = value.total
          
        } 
        
        differenceInHr = Number.isInteger(differenceInHr) ? differenceInHr : differenceInHr.toFixed(2)
        // dynamic classes for other tables
        if (this.value === constant.SECTIONS.PARTIALLY) {
          startClass = startClass + ' ' + 'ps-color'
          endClass = endClass + ' ' + 'ps-color'
          commonClass = commonClass + ' ' + 'ps-color'
          fullBarClass = fullBarClass = ' ' + 'ps-color'
          this.tableDataWrap = 'tableDataWrp partiallyScheduledWrp'
        } else if (this.value === constant.SECTIONS.FULLY) {
          startClass = startClass + ' ' + 'fs-color'
          endClass = endClass + ' ' + 'fs-color'
          commonClass = commonClass + ' ' + 'fs-color'
          fullBarClass = fullBarClass = ' ' + 'fs-color'
          this.tableDataWrap = 'tableDataWrp fullyScheduledTableWrp'
        } else if (this.value === '') {
          startClass = startClass + ' ' + 'un-color'
          endClass = endClass + ' ' + 'un-color'
          commonClass = commonClass + ' ' + 'un-color'
          fullBarClass = fullBarClass = ' ' + 'un-color'
          this.tableDataWrap = 'tableDataWrp unscheduledTableWrp'
        }
        this.currentData.push(
          {
            department: value.department,
            endDate: value.endDate,
            startDate: value.startDate,
            location: value.location,
            name: value.name,
            total: value.total,
            userId: value.userId,
            uuid: value.uuid,
            startDateRange,
            startClass,
            endDateRange,
            endClass,
            commonClass,
            monthIndex,
            sMonth,
            endMonthIndex,
            eMonth,
            differenceInHr,
            fullBarClass,
            expand: value.expand,
            projectInfo: value.projectInfo,
            text: this.label,
            keyUnique: value.keyUnique
          }
        )
      })
    },
    filteredData () {
      if (this.value === constant.SECTIONS.OVER) {
        this.tableItems = this.overScheduledTableData
      } else if (this.value === constant.SECTIONS.PARTIALLY) {
        this.tableItems = this.partiallyScheduledTableData
      } else if (this.value === constant.SECTIONS.FULLY) {
        this.tableItems = this.fullyScheduledTableData
      } else {
        this.tableItems = this.unscheduledTableData
      }

      return this.tableItems
    },

    // getAllMonths(start, end) {
    //   const range = []

    //   for (let i = start; i <= end; i++) {
    //     range.push(i)
    //   }

    //   return range
    // },
    async fetchProjectInfo (selected) {
      if (selected.value === true) {
        this.expandRecord = true
      } else {
        this.expandRecord = false
      }
      let expandRow = false

      const data = []

      this.currentData.forEach((value) => {

        if (selected.item.userId === value.userId && selected.item.keyUnique === value.keyUnique) {
          expandRow = this.expandRecord
        } else {
          expandRow = false
        }
        data.push({
          department: value.department,
          endDate: value.endDate,
          startDate: value.startDate,
          location: value.location,
          name: value.name,
          total: value.total,
          userId: value.userId,
          uuid: value.uuid,
          startDateRange: value.startDateRange,
          startClass: value.startClass,
          endDateRange: value.endDateRange,
          endClass: value.endClass,
          monthIndex: value.monthIndex,
          sMonth: value.sMonth,
          differenceInHr: value.differenceInHr,
          expand: expandRow,
          fullBarClass: value.fullBarClass,
          projectInfo: value.projectInfo,
          keyUnique: value.keyUnique
        })
      })
      this.currentItems(data)
    }
  }
}

</script>

<style scoped>
  .overScheduledHeadingWrp {
    display: flex;
    justify-content: space-between;
  }

  .overScheduledLeftHWrp {
    width: 50%;
    display: flex;
    justify-content: space-between;
    box-sizing: border-box;
  }

  .overScheduledRightWrp {
    width: 50%;
    box-sizing: border-box;
    display: flex;
    justify-content: space-between;
  }

  .overScheduled {
    background: #fff;
    box-shadow: 0 0 4px #0000004f;
    border-radius: 7px;
  }

  .overScheduledLeftH h5 {
    margin: 0;
    color: red;
    font-size: 20px;
  }

  .overScheduledRightQuoter {
    flex: auto;
    box-sizing: border-box;
  }

  .overScheduledRightQuoterH {
    border-bottom: 1px solid #dddddd;
    border-left: 1px solid #dddddd;
    padding: 2px 10px;
    font-size: 14px;
    color: #00c4ff;
    text-align: center;
  }

  .overScheduledRightQuoterMonthWrp ul {display: flex;margin: 0;padding: 0;justify-content: space-between;}

  .overScheduledRightQuoterMonthWrp ul li {
    list-style: none;
    font-size: 12px;
    border-left: 1px solid #ddd;
    padding: 3px;
    border-bottom: 1px solid #ddd;
    color: gray;
    width: -webkit-fill-available;
    flex: auto;
    text-align: center;
  }

  .progressWrp {
    display: flex;
    justify-content: space-between;
  }

  .progressWrp .myBar {
    flex: auto;
    height: 24px;
    position: relative;
  }

  .radiousLft {
    border-radius: 6px 0px 0px 6px;
  }
  .radiousRgt {
    border-radius: 0 6px 6px 0;
  }
  .v-data-table > .v-data-table__wrapper > table > tbody > tr > td, .v-data-table > .v-data-table__wrapper > table > tbody > tr > th, .v-data-table > .v-data-table__wrapper > table > thead > tr > td, .v-data-table > .v-data-table__wrapper > table > thead > tr > th, .v-data-table > .v-data-table__wrapper > table > tfoot > tr > td, .v-data-table > .v-data-table__wrapper > table > tfoot > tr > th{
    padding: 0 2px !important;
  }
  .v-icon.v-icon {
    font-size: 15px !important;
  }
  .graphListWrp > ul {
    padding: 0;
    margin: 0;
  }

  .graphListWrp > ul > li {
    list-style: none;
    padding: 20px 0;
    min-height: 65px;
    box-sizing: border-box;
  }

  .graphListWrp > ul > li:nth-child(odd) {
      background: #f8f8f8;
  }

  .theme--light.v-data-table tbody tr.v-data-table__selected {
      background: transparent;
  }

  /* Devider Css */

  .myProgress {
      display: flex;
      justify-content: space-between;
  }

  .myProgress div {
      flex: auto;
  }

  .myBar {
      display: flex;
      justify-content: space-between;

  }

  .myBar div {
      flex: auto;
  }

  .fullBar.radiousLft > div:first-child {
      border-radius: 6px 0px 0px 6px;
  }

  .fullBar.radiousRgt > div:last-child {
      border-radius: 0 6px 6px 0;
  }

  .bar11-30.radiousLft > div:nth-child(2) {
      border-radius: 6px 0px 0px 6px;
  }

  .lastBar1-20.radiousRgt > div:nth-child(2) {
      border-radius: 0 6px 6px 0;
  }

  .bar21-30.radiousLft > div:last-child {
      border-radius: 6px 0px 0px 6px;
  }

  .lastBar1-10.radiousRgt > div:first-child {
      border-radius: 0 6px 6px 0;
  }

  .toolTipWrp {
    position: absolute;
    width: 210px;
    top: 100%;
    background: #fff;
    box-shadow: 0px 1px 10px rgb(172 125 255 / 34%);
    z-index: 99;
    left: auto;
    right: 0;
    transition: all 0.3s ease-in-out;
    display: none;
}
  .fullBar {
      position: relative;
  }
  .overScheduledTooltip {
    background: #F9F4FF;
    padding: 5px;
}

.overScheduledTooltip h6 {
    color: #EF5350;
    font-size: 13px;
}

.nameDtail {
    display: flex;
    padding: 9px 0 0;
}

span.totalHrs {color: #EF5350;width: 30%;text-align: right;font-weight: 600;}

span.graphName {
    font-size: 13px;
    width: 70%;
}

.ashishProjects {
    padding: 0 5px;
}

.ashishProjects ul li {list-style: none;padding: 4px 0;font-size: 12px;display: flex;justify-content: space-between;}

.ashishProjects ul li span:last-child {
    color: red;
}

.progressWrp:hover .toolTipWrp {
    display: block;
}
.ashishProjects > ul {
    padding: 0;
}

.allProjects ul {
    padding: 0;
    margin: 0 0 0 6px;
    position: relative;
}

.allProjects ul li {
    display: flex;
    justify-content: space-between;
    padding: 7px 25px 7px 40px;
    font-weight: normal;
    font-size: 12px;
    color: #565656;
    position: relative;
    height: 50px;
    box-sizing: border-box;
    align-items: center;
}

.allProjects ul li span.workingHrs {
    color: red;
}
.fullyScheduledTableWrp .allProjects ul li span.workingHrs {
    color: #f9a825;
}
.partiallyScheduledWrp .allProjects ul li span.workingHrs {
    color: #2196f3;
}
.allProjects ul:before {
    content: "";
    display: inline-block;
    height: 100%;
    width: 1px;
    background: #1976d2;
    position: absolute;
    bottom: 22px;
    left: 0;
}

.allProjects ul li:before {content: "";display: inline-block;width: 30px;height: 1px;position: absolute;left: 0px;top: 48%;transform: translateY(-50%);border-bottom: 1px solid #1976d2;}

.allProjects ul li:after {
    display: inline-block;
    width: 5px;
    height: 5px;
    position: absolute;
    background: #1976d2;
    border-radius: 100%;
    top: 48%;
    transform: translateY(-45%);
    left: 25px;
    content: "";
}

.allProjects ul li:last-child {padding-bottom: 0;}

.allProjects ul li:last-child:before {
    top: 55%;
}

.allProjects ul li:last-child:after {
    top: 55%;
}
td.leftGraphWrp {
    width: 50%;
    vertical-align: top;
}

.graphListWrp {
    padding: 37px 0 0;
    border-left: 1px solid #efefef;
}
.expandSpace:only-child {
    height: 65px;
}
.expandSpace {
    height: 50px;
}

.v-data-table > .v-data-table__wrapper > table > tbody > tr > td.tableDataWrp {
    padding: 0 !important;
}

.dataWrp.v-data-table > .v-data-table__wrapper > table > thead > tr > th {
    padding: 8px 0;
    height: auto;
}
.v-data-table > .v-data-table__wrapper > table > tbody > tr > td.leftGraphWrp {
  padding: 0 !important;
}

.bar21-30.radiousLft.radiousRgt > div:last-child {border-radius: 6px;}

.bar1-20 > div:first-child {
   border-radius: 5px 0 0 5px;
}

.bar1-20 > div:nth-child(2) {
   border-radius: 0 5px 5px 0;
}
.bar11-30.radiousRgt > div:last-child {
   border-radius: 0px 6px 6px 0px;
}

/* Over Scheduled */
.fullBar > div {
background: #8222eb;
}
.bar11-30 > div {
    background: #8222eb;
}
.lastBar1-20 > div {
    background: #8222eb;
}
.bar21-30 > div:last-child {
    background: #8222eb;
}
.lastBar1-10 > div:first-child {
    background: #8222eb;
}
.lastBar21-30 div:last-child {
  background: #8222eb;
  border-radius: 6px;
}
.bar1-10 > div:first-child {
  background: #8222eb;
  border-radius: 6px;
}
.bar11-20 > div:nth-child(2) {
  background: #8222eb;
  border-radius: 6px;
}
.bar1-20 > div {
  background: #8222eb;
  border-radius: 0 0 0;
}
.bar11-30 > div:nth-child(1) {
    background: transparent;
}
.lastBar1-20 > div:last-child {
    background: transparent;
}
.bar1-20 > div:last-child {
  background: transparent;
}

 /* Unscheduled color css */

.fullBar.un-color > div {
  background: #4CAF50;
}
.bar11-30.un-color > div {
    background: #4CAF50;
}
.lastBar1-20.un-color > div {
    background: #4CAF50;
}
.bar21-30.un-color > div:last-child {
    background: #4CAF50;
}
.lastBar1-10.un-color > div:first-child {
    background: #4CAF50;
}
.lastBar21-30.un-color div:last-child {
  background: #4CAF50;
}
.bar1-10.un-color > div:first-child {
  background: #4CAF50;
}
.bar11-20.un-color > div:nth-child(2) {
  background: #4CAF50;
}
.bar1-20.un-color > div {
  background: #4CAF50;
}
.bar11-30.un-color > div:nth-child(1) {
    background: transparent;
}
.lastBar1-20.un-color > div:last-child {
    background: transparent;
}
.bar1-20.un-color > div:last-child {
  background: transparent;
}

 /* Fully-Scheduled Color */

.fullBar.fs-color > div {
background: #f9a825;
}
.bar11-30.fs-color > div {
    background: #f9a825;
}
.lastBar1-20.fs-color > div {
    background: #f9a825;
}
.bar21-30.fs-color > div:last-child {
    background: #f9a825;
}
.lastBar1-10.fs-color > div:first-child {
    background: #f9a825;
}
.lastBar21-30.fs-color div:last-child {
  background: #f9a825;
}
.bar1-10.fs-color > div:first-child {
  background: #f9a825;
}
.bar11-20.fs-color > div:nth-child(2) {
  background: #f9a825;
}
.bar1-20.fs-color > div {
  background: #f9a825;
}
.bar11-30.fs-color > div:nth-child(1) {
    background: transparent;
}
.lastBar1-20.fs-color > div:last-child {
    background: transparent;
}
.bar1-20.fs-color > div:last-child {
  background: transparent;
}

/* Partially-Scheduled Color */

.fullBar.ps-color > div {
background: #2196F3;
}
.bar11-30.ps-color > div {
    background: #2196F3;
}
.lastBar1-20.ps-color > div {
    background: #2196F3;
}
.bar21-30.ps-color > div:last-child {
    background: #2196F3;
}
.lastBar1-10.ps-color > div:first-child {
    background: #2196F3;
}
.lastBar21-30.ps-color div:last-child {
  background: #2196F3;
}
.bar1-10.ps-color > div:first-child {
  background: #2196F3;
}
.bar11-20.ps-color > div:nth-child(2) {
  background: #2196F3;
}
.bar1-20.ps-color > div {
  background: #2196F3;
}
.bar11-30.ps-color > div:nth-child(1) {
    background: transparent;
}
.lastBar1-20.ps-color > div:last-child {
    background: transparent;
}
.bar1-20.ps-color > div:last-child {
  background: transparent;
}

</style>
