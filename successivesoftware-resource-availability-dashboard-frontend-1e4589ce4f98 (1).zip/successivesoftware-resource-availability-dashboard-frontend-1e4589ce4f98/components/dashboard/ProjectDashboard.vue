<template>
  <div class="projectDashboardWrp">
    <div class="projectDashboradrH">
      <v-row>
        <v-col cols="6" class="pb-0">
          <div class="heading-style"><h3>Project Dashboard</h3></div>
        </v-col>
        <v-col cols="6" class="text-right pb-0">
          <v-autocomplete
            v-model="reports.id"
            :items="reports"
            item-text="name"
            item-value="id"
            outlined
            small-chips
            class="DownloadReportBtn"
            label="Download Report"
            clearable
            dense
            @change="downloadExcel(reports.id)"
          >
            <template v-slot:item="{ item }">
              <span>{{ item.name }}
                <v-icon :class="item.pl">
                  mdi-download
                </v-icon>
              </span>
            </template>
          </v-autocomplete>
        </v-col>
      </v-row>
    </div>
    <Dialog />
    <common-snackbar
      :snackbar="snackbarValue"
      :text-for-snackbar="snackbarText"
      class="projectDashboardListView"
    />
    <v-dialog v-model="inputDialog" :persistent="true" width="500">
      <v-card>
        <v-card-title>
          <span class="headline">Reason for Restart Project</span>
        </v-card-title>
        <v-card-text class="pa-0">
          <v-container>
            <v-row>
              <v-col cols="12" class="pb-0 pt-1 pl-5 pr-5">
                <v-textarea
                  v-model="reasonForClose"
                  auto-grow
                  outlined
                  label="Please mention the reason for project restart if any"
                />
              </v-col>
            </v-row>
          </v-container>
        </v-card-text>
        <v-card-actions class="pr-5 pt-0">
          <v-spacer />
          <v-btn
            color="blue darken-1"
            dark
            class="text-capitalize"
            text
            @click="close"
          >
            Cancel
          </v-btn>
          <v-btn
            class="text-capitalize"
            color="blue darken-1"
            text
            @click="save"
          >
            Save
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
    <v-dialog v-model="warningDialog" :persistent="true">
      <div class="successPopup">
        <div class="successImg">
          <img src="../../assets/images/custom/ErrorDialog.png" />
        </div>
        <div class="successText d-flex align-center justify-center">
          <div class="sureTextWrp">
            <h1>Warning</h1>
            <p>{{ warningMsg }}</p>
            <v-card-actions>
              <v-btn class="cancleBtn" text @click="closeWarning">
                No
              </v-btn>
              <v-btn class="yesBtn" text @click="warningApprove">
                Yes
              </v-btn>
            </v-card-actions>
          </div>
        </div>
      </div>
      <!-- <v-card>
        <v-card-title class="dialogHeadline">
          Warning
        </v-card-title>
        <v-divider />
        <v-container>
          <v-card-text>{{ warningMsg }}</v-card-text>
        </v-container>
        <v-divider />
        <v-card-actions>
          <v-spacer />
         <v-btn color="green darken-1" text @click="closeWarning">
            No
          </v-btn>
          <v-btn color="green darken-1" text @click="warningApprove">
            Yes
          </v-btn>
        </v-card-actions>
      </v-card> -->
    </v-dialog>
    <div>

      <v-row class="mainWrp">
        <v-col v-if="tableView === true" cols="12" class="">
          <v-data-table
            :headers="headers"
            :items="projectListData"
            :items-per-page="itemPerPage"
            :footer-props="{ itemsPerPageOptions: rowsPerPage }"
            :hide-default-footer="projectListData.length ? false : true"
            class="projectDataWrp"
            :loading="projectListData.length ? false : true"
            loading-text="Loading... Please wait"
            @update:items-per-page="updatePagination"
          >
            <template v-slot:top>
              <div class="projectDtopBar">
                <v-row>
                  <v-col cols="4" class="pt-0 pb-0 pr-0">
                    <template>
                      <span class="viewOptn">
                        <v-tooltip top>
                          <template v-slot:activator="{ on, attrs }">
                            <v-img
                              :src="gridFalse"
                              v-bind="attrs"
                              @click="tableView = false, wsrGridFilter()"
                              v-on="on"
                            />
                          </template>
                          <span>Grid View</span>
                        </v-tooltip>
                      </span>
                      <span class="viewOptn">
                        <v-tooltip top>
                          <template v-slot:activator="{ on, attrs }">
                            <v-img :src="tableTrue" v-bind="attrs" v-on="on" />
                          </template>
                          <span>List View</span>
                        </v-tooltip>
                      </span>
                    </template>
                  </v-col>
                  <v-col cols="2" class="pt-0 pb-0 pr-0 pl-1">
                    <v-autocomplete
                      v-model="wsrType.id"
                      :items="wsrDetails"
                      item-text="name"
                      item-value="id"
                      class="filtersFields"
                      label="WSR Status"
                      outlined
                      small-chips
                      clearable
                      dense
                      multiple
                    />
                  </v-col>
                  <v-col cols="2" class="pt-0 pb-0 pr-0 pl-1">
                    <v-text-field
                      v-model="searchForProject"
                      append-icon="mdi-magnify"
                      label="Project Name"
                      outlined
                      dense
                      class="filtersFields"
                      single-line
                      hide-details
                      @input="storeProjectSearchString"
                    />
                  </v-col>
                  <v-col cols="2" class="pt-0 pb-0 pr-0 pl-1">
                    <v-autocomplete
                      v-model="projectType.type_id"
                      :items="typeDetails"
                      item-text="name"
                      item-value="id"
                      class="filtersFields"
                      label="Project Type"
                      outlined
                      small-chips
                      clearable
                      dense
                      multiple
                    />
                  </v-col>
                  <v-col cols="2" class="pt-0 pb-0 pl-1">
                    <v-autocomplete
                      v-model="projectStatus.status_id"
                      :items="statusDetails"
                      item-text="name"
                      item-value="id"
                      outlined
                      small-chips
                      class="filtersFields"
                      label="Project Status"
                      clearable
                      dense
                      multiple
                    />
                  </v-col>
                </v-row>
              </div>
            </template>
            <template v-slot:item.project_name="{ item }">
              {{ item.project_name }}
              <v-spacer />
              <v-list-item
                v-if="item.action_pending === true"
                class="actionPending"
              >
                <span class="red--text">
                  Action Required
                </span>
              </v-list-item>
            </template>
            <template v-slot:item.project_manager="{ item }">
              <span
                v-for="projectManager in item.project_managers.slice(0, 2)"
                :key="projectManager.user_id"
                class="ma-2"
                text-color="white"
              >
                <v-tooltip top>
                  <template v-slot:activator="{ on }">
                    <v-avatar :color="`${randomColors()}`" size="30" v-on="on">
                      <span class="white--text headline">{{
                        avatarNames( (projectManager.user !== null) ? projectManager.user.display_name : '')
                      }}</span>
                    </v-avatar>
                  </template>
                  {{ (projectManager.user !== null) ? projectManager.user.display_name : '' }}
                </v-tooltip>
              </span>
              <v-menu
                bottom
                origin="center center"
                transition="scale-transition"
              >
                <template v-slot:activator="{ on }">
                  <v-btn
                    v-if="item.project_managers.length > 3"
                    class="ma-1"
                    outlined
                    fab
                    x-small
                    color="blue"
                    v-on="on"
                    @click="!false"
                  >
                    <v-icon x-small>
                      mdi-plus
                    </v-icon>
                    {{
                      item.project_managers.slice(
                        3,
                        item.project_managers.length
                      ).length
                    }}
                  </v-btn>
                </template>
                <v-card v-show="!false" class="mx-auto" max-width="300" raised>
                  <v-list
                    v-if="item.project_managers.length > 3"
                    disabled
                    shaped
                  >
                    <v-list-item-group
                      v-model="item.project_managers"
                      color="primary"
                    >
                      <v-list-item
                        v-for="projectManager in item.project_managers.slice(
                          3,
                          item.project_managers.length
                        )"
                        v-show="!false"
                        :key="projectManager.user_id"
                      >
                        <v-avatar :color="`${randomColors()}`" size="30">
                          <strong class="white--text headline">{{
                            avatarNames(projectManager.user.display_name)
                          }}</strong>
                        </v-avatar>
                        <v-list-item-content class="ml-2">
                          <v-list-item-title
                            v-text="projectManager.user.display_name"
                          />
                        </v-list-item-content>
                      </v-list-item>
                    </v-list-item-group>
                  </v-list>
                </v-card>
              </v-menu>
            </template>
            <template v-slot:item.account_manager="{ item }">
              <span
                v-for="accountManager in item.account_managers.slice(0, 2)"
                :key="accountManager.user_id"
                class="ma-2"
                text-color="white"
              >
                <v-tooltip top>
                  <template v-slot:activator="{ on }">
                    <v-avatar :color="`${randomColors()}`" size="30" v-on="on">
                      <strong class="white--text headline">{{
                        avatarNames((accountManager.user !== null) ? accountManager.user.display_name : '')
                      }}</strong>
                    </v-avatar>
                  </template>
                  <span style="font-size: small; background: inherit;">
                    {{ (accountManager.user !== null) ? accountManager.user.display_name : '' }}
                  </span>
                </v-tooltip>
              </span>
              <v-menu
                bottom
                origin="center center"
                transition="scale-transition"
              >
                <template v-slot:activator="{ on }">
                  <v-btn
                    v-if="item.account_managers.length > 3"
                    class="ma-1"
                    outlined
                    fab
                    x-small
                    size="30"
                    color="blue"
                    v-on="on"
                    @click="!false"
                  >
                    <v-icon x-small>
                      mdi-plus
                    </v-icon>
                    {{
                      item.account_managers.slice(
                        3,
                        item.account_managers.length
                      ).length
                    }}
                  </v-btn>
                </template>
                <v-card v-show="!false" class="mx-auto" max-width="300" raised>
                  <v-list
                    v-if="item.account_managers.length > 3"
                    disabled
                    shaped
                  >
                    <v-list-item-group
                      v-model="item.account_managers"
                      color="primary"
                    >
                      <v-list-item
                        v-for="accountManager in item.account_managers.slice(
                          3,
                          item.account_managers.length
                        )"
                        v-show="!false"
                        :key="accountManager.user_id"
                      >
                        <v-avatar :color="`${randomColors()}`" size="30">
                          <span class="white--text headline">{{
                            avatarNames( (accountManager.user !== null) ? accountManager.user.display_name : '')
                          }}</span>
                        </v-avatar>
                        <v-list-item-content class="ml-2">
                          <v-list-item-title
                            v-text=" (accountManager.user !== null) ? accountManager.user.display_name : ''"
                          />
                        </v-list-item-content>
                      </v-list-item>
                    </v-list-item-group>
                  </v-list>
                </v-card>
              </v-menu>
            </template>
            <template v-slot:item.created_at="{ item }">
              {{
                new Date(item.created_at.substr(0, 10)).toLocaleDateString(
                  "en-US",
                  {
                    year: "numeric",
                    month: "short",
                    day: "numeric"
                  }
                )
              }}
            </template>
            <template v-slot:item.updated_at="{ item }">
              {{
                new Date(item.updated_at.substr(0, 10)).toLocaleDateString(
                  "en-US",
                  {
                    year: "numeric",
                    month: "short",
                    day: "numeric"
                  }
                )
              }}
            </template>
            <template v-slot:item.operation="actions">
              <v-select
                v-model="actionSelected[actions.item.id]"
                :disabled="actions.item.track.is_draft === 1"
                :items="
                  actions.item.user_performed_action.filter(
                    value => value.status === constant.ACTION_STATUS.AVAILABLE
                  )
                "
                item-text="name"
                item-value="code"
                label="Project Operations"
                solo
                dense
                return-object
                @click="fetchProjectEligibleAction(actions.item)"
                @change="performAction($event, actions.item)"
              >
                <template v-slot:no-data>
                  <v-list-item v-if="showLoader">
                    <span class="noData"><strong>Please wait...</strong></span>
                  </v-list-item>
                  <v-list-item v-else>
                    <span
                      class="noData"
                    ><strong>No Data Available</strong></span>
                  </v-list-item>
                </template>
                <template v-slot:item="{ item }">
                  <span
                    v-if="
                      constant.ALERT_ACTION.IA === item.code ||
                        constant.ALERT_ACTION.ID === item.code ||
                        constant.ALERT_ACTION.RA === item.code ||
                        constant.ALERT_ACTION.RR === item.code ||
                        constant.ALERT_ACTION.PR === item.code ||
                        constant.ALERT_ACTION.RARA === item.code ||
                        constant.ALERT_ACTION.RARD === item.code ||
                        constant.ALERT_ACTION.IR === item.code ||
                        constant.ALERT_ACTION.PHR === item.code ||
                        constant.ALERT_ACTION.PHRA === item.code
                    "
                    class="red--text"
                  >
                    {{ item.name }}
                  </span>
                  <span v-else>{{ item.name }}</span>
                </template>
              </v-select>
            </template>
            <template v-slot:item.action="{ item }">
              <v-tooltip top>
                <template v-slot:activator="{ on, attrs }">
                  <v-img
                    v-show="hasRcaAccess(item)"
                    :src="rcaIcon"
                    class="quickAct"
                    v-bind="attrs"
                    @click="rcaProject(item)"
                    v-on="on"
                  />
                </template>
                <span>RCA</span>
              </v-tooltip>

              <v-tooltip top>
                <template v-slot:activator="{ on, attrs }">
                  <v-img
                    v-show="hasViewAccess(item)"
                    :src="viewIcon"
                    class="quickAct"
                    v-bind="attrs"
                    @click="viewProject(item)"
                    v-on="on"
                  />
                </template>
                <span>View Project</span>
              </v-tooltip>

              <v-tooltip top>
                <template v-slot:activator="{ on, attrs }">
                  <v-img
                    v-show="hasViewAccess(item)"
                    :src="activityLogIcon"
                    class="quickAct"
                    v-bind="attrs"
                    @click="viewActivityLog(item)"
                    v-on="on"
                  />
                </template>
                <span>Activity Log</span>
              </v-tooltip>

              <v-tooltip top>
                <template v-slot:activator="{ on, attrs }">
                  <v-img
                    v-show="
                      (rolesAllowed &&
                        item.status !==
                        constant.PROJECT_STATUS.INITIATION_REQUEST) ||
                        (DraftEditrolesAllowed && item.is_draft === 1)
                    "
                    :src="editIcon"
                    class="quickAct"
                    v-bind="attrs"
                    @click="editProject(item)"
                    v-on="on"
                  />
                </template>
                <span>Edit Project</span>
              </v-tooltip>
              <v-tooltip top>
                <template v-slot:activator="{ on, attrs }">
                  <v-btn
                    v-if="item.wsr_status.id === 1"
                    v-show="WsrrolesAllowed"
                    v-bind="attrs"
                    class="wsrIconBtn"
                    v-on="on"
                  >
                    <v-img :src="greenWSR" class="wsrIconImg"> </v-img>
                  </v-btn>
                  <v-btn
                    v-else
                    v-show="WsrrolesAllowed"
                    v-bind="attrs"
                    class="wsrIconBtn"
                    @click="addWsr(item)"
                    v-on="on"
                  >
                    <v-img :src="redWSR" class="wsrIconImg"> </v-img>
                  </v-btn>
                </template>
                <span v-if="item.wsr_status.id === 1" class="text-capitalize">
                  WSR Submitted
                </span>
                <span v-else>Add WSR</span>
              </v-tooltip>
            </template>
            <template v-slot:item.billing_type="{ item }">
              <span
                v-if="constant.BILLABLE_ID.includes(item.billing_type.id)"
                class="text-capitalize"
              >
                Billable
              </span>
              <span
                v-else-if="
                  item.billing_type.id === constant.BILLING_TYPE.INTERNAL
                "
                class="text-capitalize"
              >
                Internal
              </span>
              <span v-else class="text-capitalize">
                POC
              </span>
            </template>

            <template v-slot:item.wsr_status="{ item }">

              <span class="text-capitalize">
                {{ item.wsr_status.name }}
              </span>
            </template>

            <template v-slot:item.track="{ item }">
              <v-btn
                v-if="item.track.is_draft === 1"
                small
                rounded
                class="white--text text-capitalize"
                color="blue"
              >
                Draft
              </v-btn>
              <v-btn
                v-else-if="
                  item.track.status === constant.PROJECT_STATUS.NEW ||
                    item.track.status ===
                    constant.PROJECT_STATUS.INITIATION_REQUEST
                "
                small
                rounded
                class="white--text text-capitalize"
                color="orange lighten-1"
              >
                New
              </v-btn>
              <v-btn
                v-else-if="
                  item.track.status === constant.PROJECT_STATUS.ON_HOLD
                "
                small
                rounded
                class="white--text text-capitalize"
                color="yellow accent-4"
              >
                On Hold
              </v-btn>
              <v-btn
                v-else-if="item.track.status === constant.PROJECT_STATUS.CLOSED"
                small
                rounded
                class="white--text text-capitalize"
                color="red"
              >
                Closed
              </v-btn>
              <v-btn
                v-else
                small
                rounded
                class="white--text text-capitalize"
                color="green lighten-1"
              >
                In progress
              </v-btn>
            </template>
          </v-data-table>
        </v-col>

        <v-col v-else cols="12">
          <div class="gridWrp">
            <template>
              <div class="projectDtopBar">
                <v-row>
                  <v-col cols="4" class="pb-0 pt-0">
                    <template>
                      <span class="viewOptn">
                        <v-tooltip top>
                          <template v-slot:activator="{ on, attrs }">
                            <v-img :src="gridTrue" v-bind="attrs" v-on="on" />
                          </template>
                          <span>Grid View</span>
                        </v-tooltip>
                      </span>
                      <span class="viewOptn">
                        <v-tooltip top>
                          <template v-slot:activator="{ on, attrs }">
                            <v-img
                              :src="tableFalse"
                              v-bind="attrs"
                              @click="tableView = true, wsrGridFilter()"
                              v-on="on"
                            />
                          </template>
                          <span>List View</span>
                        </v-tooltip>
                      </span>
                    </template>
                  </v-col>
                  <v-col cols="2" class="pt-0 pb-0 pr-0 pl-1">
                    <v-text-field
                      v-model="searchForProjectName"
                      append-icon="mdi-magnify"
                      label="Project Name"
                      outlined
                      dense
                      class="filtersFields"
                      single-line
                      hide-details
                      @input="pnGridFilter(searchForProjectName)"
                    />
                  </v-col>
                  <v-col cols="2" class="pt-0 pb-0 pr-0 pl-1">
                    <v-autocomplete
                      v-model="projectTypeGrid.type_id"
                      :items="typeDetails"
                      item-text="name"
                      item-value="id"
                      class="filtersFields"
                      label="Project Type"
                      outlined
                      small-chips
                      clearable
                      dense
                      multiple
                      @change="ptGridFilter"
                    />
                  </v-col>
                  <v-col cols="2" class="pt-0 pb-0 pr-0 pl-1">
                    <v-autocomplete
                      v-model="projectStatusGrid.status_id"
                      :items="statusDetails"
                      item-text="name"
                      item-value="id"
                      outlined
                      small-chips
                      class="filtersFields"
                      label="Project Status"
                      clearable
                      dense
                      multiple
                      @change="psGridFilter"
                    />
                  </v-col>
                  <v-col cols="2" class="pt-0 pb-0 pl-1">
                    <v-autocomplete
                      v-model="wsrTypeGrid.id"
                      :items="wsrDetails"
                      item-text="name"
                      item-value="id"
                      class="filtersFields"
                      label="Wsr Status"
                      outlined
                      small-chips
                      clearable
                      dense
                      multiple
                      @change="wsrGridFilter"
                    />
                  </v-col>
                </v-row>
              </div>
            </template>
            <v-divider></v-divider>
            <template>
              <div class="cardVIewWrp">
                <v-row v-if="projectRecords">
                  <v-col
                    v-for="project in projectRecords.filter(
                      (item, index) => index < loadMore
                    )"
                    :key="project.uuid"
                    cols="4"
                  >
                    <span>
                      <v-card class="projectCard">
                        <v-list class="projectCardH">
                          <v-list-item>
                            <v-list-item-title><h4 :title="project.project_name">
                              {{ project.project_name }}
                            </h4></v-list-item-title>
                            <v-list-item-subtitle
                              v-if="project.action_pending === true"
                              class="text-right red--text"
                            >
                              Action Required
                            </v-list-item-subtitle>
                          </v-list-item>
                        </v-list>
                        <v-divider></v-divider>
                        <v-col cols="12" class="pt-1 pb-1">
                          <v-row class="cardRowWrp">
                            <v-col cols="6" class="pa-0">
                              <v-list
                                one-line
                                class="projectCardCat projectCardCatRight"
                              >
                                <v-list-item class="projectCardCatInner">
                                  <v-list-item-content>
                                    <v-list-item-title>Project Type</v-list-item-title>
                                    <v-list-item-subtitle>
                                      <span
                                        v-if="
                                          constant.BILLABLE_ID.includes(
                                            project.billing_type.id
                                          )
                                        "
                                      >
                                        Billable
                                      </span>
                                      <span
                                        v-else-if="
                                          project.billing_type.id ===
                                            constant.BILLING_TYPE.INTERNAL
                                        "
                                      >
                                        Internal
                                      </span>
                                      <span v-else>
                                        POC
                                      </span>
                                    </v-list-item-subtitle>
                                  </v-list-item-content>
                                </v-list-item>
                                <!-- <v-list-item class="projectCardCatInner">
                                  <v-list-item-content>
                                    <v-list-item-title>Wsr Status</v-list-item-title>
                                    <v-list-item-subtitle>
                                      <span v-if="constant.BILLABLE_ID.includes(project.billing_type.id)">
                                        Billable
                                      </span>
                                      <span v-else-if="project.billing_type.id === constant.BILLING_TYPE.INTERNAL">
                                        Internal
                                      </span>
                                      <span v-else>
                                        POC
                                      </span>
                                    </v-list-item-subtitle>
                                  </v-list-item-content>
                                </v-list-item> -->
                                <v-list-item class="projectCardCatInner">
                                  <v-list-item-content>
                                    <v-list-item-title>Account Manager</v-list-item-title>
                                    <v-list-item-subtitle>
                                      <template>
                                        <span
                                          v-for="accountManager in project.account_managers.slice(
                                            0,
                                            2
                                          )"
                                          :key="accountManager.user_id"
                                          text-color="white"
                                          class="pmName"
                                        >
                                          <v-tooltip top>
                                            <template v-slot:activator="{ on }">
                                              <v-avatar
                                                :color="`${randomColors()}`"
                                                size="30"
                                                v-on="on"
                                              >
                                                <span
                                                  class="white--text headline"
                                                >{{
                                                  avatarNames(
                                                    accountManager.user
                                                      .display_name
                                                  )
                                                }}</span>
                                              </v-avatar>
                                            </template>
                                            {{
                                              accountManager.user.display_name
                                            }}
                                          </v-tooltip>
                                        </span>
                                        <v-menu
                                          bottom
                                          origin="center center"
                                          transition="scale-transition"
                                        >
                                          <template v-slot:activator="{ on }">
                                            <v-btn
                                              v-if="
                                                project.account_managers
                                                  .length > 2
                                              "
                                              style="margin-left: 4px; margin-right: 4px;"
                                              outlined
                                              fab
                                              x-small
                                              color="blue"
                                              v-on="on"
                                              @click="!false"
                                            >
                                              <v-icon x-small>
                                                mdi-plus
                                              </v-icon>
                                              {{
                                                project.account_managers.slice(
                                                  2,
                                                  project.account_managers
                                                    .length
                                                ).length
                                              }}
                                            </v-btn>
                                          </template>
                                          <v-card
                                            v-show="!false"
                                            class="mx-auto"
                                            max-width="300"
                                            raised
                                          >
                                            <v-list
                                              v-if="
                                                project.account_managers
                                                  .length > 2
                                              "
                                              disabled
                                              shaped
                                            >
                                              <v-list-item-group
                                                v-model="
                                                  project.account_managers
                                                "
                                                color="primary"
                                              >
                                                <v-list-item
                                                  v-for="accountManager in project.account_managers.slice(
                                                    2,
                                                    project.account_managers
                                                      .length
                                                  )"
                                                  v-show="!false"
                                                  :key="accountManager.user_id"
                                                >
                                                  <v-avatar
                                                    :color="`${randomColors()}`"
                                                    size="30"
                                                  >
                                                    <strong
                                                      class="white--text headline"
                                                    >{{
                                                      avatarNames(
                                                        accountManager.user
                                                          .display_name
                                                      )
                                                    }}</strong>
                                                  </v-avatar>
                                                  <v-list-item-content
                                                    class="ml-2"
                                                  >
                                                    <v-list-item-title
                                                      v-text="
                                                        accountManager.user
                                                          .display_name
                                                      "
                                                    />
                                                  </v-list-item-content>
                                                </v-list-item>
                                              </v-list-item-group>
                                            </v-list>
                                          </v-card>
                                        </v-menu>
                                      </template>
                                    </v-list-item-subtitle>
                                  </v-list-item-content>
                                </v-list-item>
                                <v-list-item class="projectCardCatInner">
                                  <v-card-actions class="projectCardCatAct">
                                    <v-select
                                      v-model="actionSelected[project.id]"
                                      :disabled="project.track.is_draft === 1"
                                      :items="
                                        project.user_performed_action.filter(
                                          value =>
                                            value.status ===
                                            constant.ACTION_STATUS.AVAILABLE
                                        )
                                      "
                                      item-text="name"
                                      item-value="code"
                                      placeholder="Project Operation"
                                      outlined
                                      small
                                      dense
                                      return-object
                                      @click="
                                        fetchProjectEligibleAction(project)
                                      "
                                      @change="performAction($event, project)"
                                    >
                                      <template v-slot:no-data>
                                        <v-list-item v-if="showLoader">
                                          <span
                                            class="noData"
                                          ><strong>Please wait...</strong></span>
                                        </v-list-item>
                                        <v-list-item v-else>
                                          <span
                                            class="noData"
                                          ><strong>No Data Available</strong></span>
                                        </v-list-item>
                                      </template>
                                      <template v-slot:item="{ item }">
                                        <span
                                          v-if="
                                            constant.ALERT_ACTION.IA ===
                                              item.code ||
                                              constant.ALERT_ACTION.ID ===
                                              item.code ||
                                              constant.ALERT_ACTION.RA ===
                                              item.code ||
                                              constant.ALERT_ACTION.RR ===
                                              item.code ||
                                              constant.ALERT_ACTION.PR ===
                                              item.code ||
                                              constant.ALERT_ACTION.RARA ===
                                              item.code ||
                                              constant.ALERT_ACTION.RARD ===
                                              item.code ||
                                              constant.ALERT_ACTION.IR ===
                                              item.code ||
                                              constant.ALERT_ACTION.PHR ===
                                              item.code ||
                                              constant.ALERT_ACTION.PHRA ===
                                              item.code
                                          "
                                          class="red--text"
                                        >
                                          {{ item.name }}
                                        </span>
                                        <span v-else>{{ item.name }}</span>
                                      </template>
                                    </v-select>
                                  </v-card-actions>
                                </v-list-item>
                              </v-list>
                            </v-col>
                            <v-col cols="6" class="pa-0">
                              <v-list
                                one-line
                                class="projectCardCat projectCardCatLeft"
                              >
                                <v-list-item class="projectCardCatInner">
                                  <v-list-item-content>
                                    <v-list-item-title>Project Status</v-list-item-title>
                                    <v-list-item-subtitle>
                                      <v-btn
                                        v-if="project.track.is_draft === 1"
                                        small
                                        rounded
                                        class="white--text text-capitalize"
                                        color="blue"
                                      >
                                        Draft
                                      </v-btn>
                                      <v-btn
                                        v-else-if="
                                          project.track.status ===
                                            constant.PROJECT_STATUS.NEW ||
                                            project.track.status ===
                                            constant.PROJECT_STATUS
                                              .INITIATION_REQUEST
                                        "
                                        small
                                        rounded
                                        class="white--text text-capitalize"
                                        color="orange lighten-1"
                                      >
                                        New
                                      </v-btn>
                                      <v-btn
                                        v-else-if="
                                          project.track.status ===
                                            constant.PROJECT_STATUS.ON_HOLD
                                        "
                                        small
                                        rounded
                                        class="white--text text-capitalize"
                                        color="yellow accent-4"
                                      >
                                        On Hold
                                      </v-btn>
                                      <v-btn
                                        v-else-if="
                                          project.track.status ===
                                            constant.PROJECT_STATUS.CLOSED
                                        "
                                        small
                                        rounded
                                        class="white--text text-capitalize"
                                        color="red"
                                      >
                                        Closed
                                      </v-btn>
                                      <v-btn
                                        v-else
                                        small
                                        rounded
                                        class="white--text text-capitalize"
                                        color="green lighten-1"
                                      >
                                        In progress
                                      </v-btn>
                                    </v-list-item-subtitle>
                                  </v-list-item-content>
                                </v-list-item>
                                <v-list-item class="projectCardCatInner">
                                  <v-list-item-content>
                                    <v-list-item-title>Project Manager</v-list-item-title>
                                    <v-list-item-subtitle>
                                      <template>
                                        <span
                                          v-for="projectManager in project.project_managers.slice(
                                            0,
                                            2
                                          )"
                                          :key="projectManager.user_id"
                                          text-color="white"
                                          class="pmName"
                                        >
                                          <v-tooltip top>
                                            <template v-slot:activator="{ on }">
                                              <v-avatar
                                                :color="`${randomColors()}`"
                                                size="30"
                                                v-on="on"
                                              >
                                                <span
                                                  class="white--text headline"
                                                >{{
                                                  avatarNames((projectManager.user !== null) ? projectManager.user.display_name : '')
                                                }}</span>
                                              </v-avatar>
                                            </template>
                                            {{
                                              (projectManager.user !== null) ? projectManager.user.display_name : ''
                                            }}
                                          </v-tooltip>
                                        </span>
                                        <v-menu
                                          bottom
                                          origin="center center"
                                          transition="scale-transition"
                                        >
                                          <template v-slot:activator="{ on }">
                                            <v-btn
                                              v-if="
                                                project.project_managers
                                                  .length > 2
                                              "
                                              outlined
                                              fab
                                              x-small
                                              color="blue"
                                              v-on="on"
                                              @click="!false"
                                            >
                                              <v-icon x-small>
                                                mdi-plus
                                              </v-icon>
                                              {{
                                                project.project_managers.slice(
                                                  2,
                                                  project.project_managers
                                                    .length
                                                ).length
                                              }}
                                            </v-btn>
                                          </template>
                                          <v-card
                                            v-show="!false"
                                            class="mx-auto"
                                            max-width="300"
                                            raised
                                          >
                                            <v-list
                                              v-if="
                                                project.project_managers
                                                  .length > 2
                                              "
                                              disabled
                                              shaped
                                            >
                                              <v-list-item-group
                                                v-model="
                                                  project.project_managers
                                                "
                                                color="primary"
                                              >
                                                <v-list-item
                                                  v-for="projectManager in project.project_managers.slice(
                                                    2,
                                                    project.project_managers
                                                      .length
                                                  )"
                                                  v-show="!false"
                                                  :key="projectManager.user_id"
                                                >
                                                  <v-avatar
                                                    :color="`${randomColors()}`"
                                                    size="30"
                                                  >
                                                    <strong
                                                      class="white--text headline"
                                                    >{{
                                                      avatarNames(
                                                        projectManager.user
                                                          .display_name
                                                      )
                                                    }}</strong>
                                                  </v-avatar>
                                                  <v-list-item-content
                                                    class="ml-2"
                                                  >
                                                    <v-list-item-title
                                                      v-text="
                                                        projectManager.user
                                                          .display_name
                                                      "
                                                    />
                                                  </v-list-item-content>
                                                </v-list-item>
                                              </v-list-item-group>
                                            </v-list>
                                          </v-card>
                                        </v-menu>
                                      </template>
                                    </v-list-item-subtitle>
                                  </v-list-item-content>
                                </v-list-item>
                                <v-list-item class="projectCardCatInner">
                                  <v-card-actions class="projectCardCatAct">
                                    <template>
                                      <span>
                                        <v-tooltip top>
                                          <template
                                            v-slot:activator="{ on, attrs }"
                                          >
                                            <v-img
                                              v-show="hasRcaAccess(project)"
                                              :src="rcaIcon"
                                              class="quickAct"
                                              v-bind="attrs"
                                              @click="rcaProject(project)"
                                              v-on="on"
                                            />
                                          </template>
                                          <span>RCA</span>
                                        </v-tooltip>
                                      </span>
                                      <span>
                                        <v-tooltip top>
                                          <template
                                            v-slot:activator="{ on, attrs }"
                                          >
                                            <v-img
                                              v-show="hasViewAccess(project)"
                                              :src="viewIcon"
                                              class="quickAct"
                                              v-bind="attrs"
                                              @click="viewProject(project)"
                                              v-on="on"
                                            />
                                          </template>
                                          <span>View Project</span>
                                        </v-tooltip>
                                      </span>
                                      <span>
                                        <v-tooltip top>
                                          <template
                                            v-slot:activator="{ on, attrs }"
                                          >
                                            <v-img
                                              v-show="hasViewAccess(project)"
                                              :src="activityLogIcon"
                                              class="quickAct"
                                              v-bind="attrs"
                                              @click="viewActivityLog(project)"
                                              v-on="on"
                                            />
                                          </template>
                                          <span>Activity Log</span>
                                        </v-tooltip>
                                      </span>
                                      <span>
                                        <v-tooltip top>
                                          <template
                                            v-slot:activator="{ on, attrs }"
                                          >
                                            <v-img
                                              v-show="
                                                (rolesAllowed &&
                                                  project.status !==
                                                  constant.PROJECT_STATUS
                                                    .INITIATION_REQUEST) ||
                                                  (DraftEditrolesAllowed &&
                                                    project.is_draft === 1)
                                              "
                                              :src="editIcon"
                                              class="quickAct"
                                              v-bind="attrs"
                                              @click="editProject(project)"
                                              v-on="on"
                                            />
                                          </template>
                                          <span>Edit Project</span>
                                        </v-tooltip>
                                      </span>
                                      <span>
                                        <v-tooltip top>
                                          <template
                                            v-slot:activator="{ on, attrs }"
                                          >
                                            <v-btn
                                              v-if="project.wsr_status.id === 1"
                                              v-show="WsrrolesAllowed"
                                              v-bind="attrs"
                                              class="greenIcon"
                                              icon
                                              project
                                              v-on="on"
                                            >
                                              <v-img
                                                :src="greenWSR"
                                                class="wsrIconImg"
                                              >
                                              </v-img>
                                            </v-btn>
                                            <v-btn
                                              v-else
                                              v-show="WsrrolesAllowed"
                                              v-bind="attrs"
                                              class="redIcon"
                                              icon
                                              @click="addWsr(project)"
                                              v-on="on"
                                            >
                                              <v-img
                                                :src="redWSR"
                                                class="wsrIconImg"
                                              >
                                              </v-img>
                                            </v-btn>
                                          </template>
                                          <span
                                            v-if="project.wsr_status.id === 1"
                                            class="text-capitalize"
                                          >
                                            WSR Submitted
                                          </span>
                                          <span v-else>Add WSR</span>
                                        </v-tooltip>
                                      </span>
                                    </template>
                                  </v-card-actions>
                                </v-list-item>
                              </v-list>
                            </v-col>
                          </v-row>
                        </v-col>
                      </v-card>
                    </span>
                  </v-col>
                  <v-col cols="12">
                    <v-btn
                      outlined
                      :disabled="projectRecords.length <= loadMore"
                      color="primary"
                      bottom
                      :style="{
                        left: '50%',
                        transform: 'translateX(-50%)',
                        bottom: '-0.1%'
                      }"
                      @click="loadMore += 12"
                    >
                      Load More (+12)
                    </v-btn>
                  </v-col>
                </v-row>
              </div>
            </template>
          </div>
        </v-col>
      </v-row>
    </div>
  </div>
</template>
<script>
import { mapActions, mapGetters } from 'vuex'
import constant from '@/constants/closure-checklist.js'
import CommonSnackbar from '@/components/CommonSnackbar'
import Dialog from '@/components/Dialog.vue'
import { excelSheet, projectHelpers } from '@/helpers/helper.js'

export default {
  name: 'Index',
  components: { CommonSnackbar, Dialog },
  layout: 'authenticated',
  middleware: 'authenticated',
  props: {
    pendingAction: {
      type: Array,
      default: () => []
    },
    projectDetails: {
      type: Array,
      default: () => []
    }
  },
  data() {
    return {
      itemPerPage: 10,
      loading: false,
      loadMore: 12,
      checkDownload: true,
      snackbarValue: false,
      snackbarText: 'Project restarted successfully.',
      tab: null,
      dialog: false,
      selectedAction: '',
      constant,
      showDashboard: false,
      rolesAllowed: false,
      DraftEditrolesAllowed: false,
      WsrrolesAllowed: false,
      inputDialog: false,
      warningDialog: false,
      warningMsg: '',
      searchForProject: '',
      searchForProjectName: '',
      selectedWarningActionCode: '',
      showLoader: false,
      reasonForClose: '',
      projectId: '',
      rowsPerPage: [50, 100, 200],
      rolesAllowedForProjectCreation: [
        constant.ROLE_ID.ADMIN,
        constant.ROLE_ID.RESOURCE_MANAGER
      ],
      actionList: constant.ACTION_LIST,
      actionSelected: [],
      projectStatus: {
        status_id: null,
        text: ''
      },
      projectStatusGrid: {
        status_id: null,
        text: ''
      },
      statusDetails: [
        { id: '1', name: 'New' },
        { id: '0', name: 'Draft' },
        { id: '3', name: 'In Progress' },
        { id: '12', name: 'On Hold' },
        { id: '13', name: 'Closed' }

      ],
      reports: [
        { id: '1', name: 'Project Details', pl: 'pl-9' },
        { id: '2', name: 'Analysis Report', pl: 'pl-8' },
        { id: '3', name: 'Resource Calendar', pl: 'pl-5' }
      ],
      projectType: {
        type_id: null,
        text: ''
      },
      projectTypeGrid: {
        type_id: null,
        text: ''
      },
      typeDetails: [
        { id: 1, name: 'Billable' },
        { id: 4, name: 'Internal' },
        { id: 5, name: 'POC' }
      ],
      wsrType: {
        id: null,
        text: ''
      },
      wsrTypeGrid: {
        id: null,
        text: ''
      },
      wsrDetails: [
        { id: 0, name: 'Pending' },
        { id: 1, name: 'Submitted' }
      ],
      exportData: [],
      tableView: true,
      headers: [
        {
          text: 'Project Name',
          align: 'center',
          value: 'project_name',
          filter: this.PorjectNameFilter
        },
        {
          text: 'Project Type',
          align: 'center',
          sortable: false,
          value: 'billing_type',
          filter: this.projectTypeFilter
        },
        {
          text: 'Project Status',
          align: 'center',
          value: 'track',
          sortable: false,
          filter: this.projectStatusFilter
        },
        {
          text: 'WSR Status',
          align: 'center',
          value: 'wsr_status',
          sortable: false,
          filter: this.wsrTypeFilter
        },
        {
          text: 'Account Manager',
          align: 'center',
          value: 'account_manager',
          sortable: false
        },
        {
          text: 'Project Manager',
          align: 'center',
          value: 'project_manager',
          sortable: false
        },
        {
          text: 'Project Operations',
          align: 'center',
          value: 'operation',
          sortable: false
        },
        {
          text: 'Quick Actions',
          align: 'center',
          value: 'action',
          sortable: false
        }
      ],
      projectRecords: [],
      projectListData: []
    }
  },
  computed: {
    ...mapGetters({
      getGlobalRole: 'roles/getGlobalRole',
      getGlobalTeamRole: 'roles/getGlobalTeamRole',
      currentUser: 'auth/user',
      getProjectSearchString: 'project/getProjectSearchString',
      getProjectWsrDefaultFilter: 'project/getProjectWsrDefaultFilter',
      getProgressStageGraphFilter:'project/getProgressStageGraphFilter',
      getProjectDashboardPagination: 'project/getProjectDashboardPagination',
      governanceCategories: 'project/getGovernanceCategories',
      projectTypes: 'project/getProjectType',
      availableRoles: 'roles/availableRoles',
      getProjectSpecificAction: 'project/getProjectSpecificAction',
      getRestartProject: 'project/getRestartProject',
      projectReport: 'project/getProjectReport',
      resourceCalendarReport: 'project/getResourceCalendarReport'
    }),
    activityLogIcon() {
      return require('@/assets/icons/activity_log_pmo.png')
    },
    editIcon() {
      return require('@/assets/icons/Edit-pmo.png')
    },
    rcaIcon() {
      return require('@/assets/icons/RCA-pmo.png')
    },
    viewIcon() {
      return require('@/assets/icons/view-PMO.png')
    },
    gridTrue() {
      return require('@/assets/icons/Grid-Selected.png')
    },
    gridFalse() {
      return require('@/assets/icons/Grid.png')
    },
    tableTrue() {
      return require('@/assets/icons/List-selected.png')
    },
    tableFalse() {
      return require('@/assets/icons/list.png')
    },
    greenWSR() {
      return require('@/assets/icons/green_WSR.png')
    },
    redWSR() {
      return require('@/assets/icons/red_WSR.png')
    }
  },
  watch: {
    projectDetails() {
      this.projectListData = this.projectDetails
      this.projectRecords = this.projectListData
    }
  },
  mounted() {
    this.projectListData = this.projectDetails
    this.projectRecords = this.projectListData
    this.searchForProject = this.getProjectSearchString
    if (this.getProgressStageGraphFilter !== null) {
      this.projectStatus = {
        status_id: [this.getProgressStageGraphFilter],
        text: ''
      },
      this.projectStatusGrid = {
        status_id: [this.getProgressStageGraphFilter],
        text: ''
      }
    }
    if (this.getProjectWsrDefaultFilter !== null) {
      this.wsrType = {
        id: [this.getProjectWsrDefaultFilter],
        text: ''
      }
      this.wsrTypeGrid = {
        id: [this.getProjectWsrDefaultFilter],
        text: ''
      }
    }
    if (this.getGlobalRole.length) {
      this.getGlobalRole.map((role) => {
        if (
          role.role_id === constant.ROLE_ID.ADMIN ||
          role.role_id === constant.ROLE_ID.GLOBAL_OPERATION ||
          role.role_id === constant.ROLE_ID.SALES
        ) {
          this.rolesAllowed = true
        }
        if (
          role.role_id === constant.ROLE_ID.ADMIN ||
          this.getGlobalTeamRole === true ||
          role.role_id === constant.ROLE_ID.GLOBAL_OPERATION ||
          role.role_id === constant.ROLE_ID.SALES ||
          role.role_id === constant.ROLE_ID.BU_HEAD ||
          role.role_id === constant.ROLE_ID.GO_TEAM
        ) {
          this.DraftEditrolesAllowed = true
        }
        if (
          role.role_id === constant.ROLE_ID.ADMIN ||
          role.role_id === constant.ROLE_ID.ACCOUNT_MANAGER ||
          role.role_id === constant.ROLE_ID.PROJECT_MANAGER
        ) {
          this.WsrrolesAllowed = true
        }
      })
    } else if (this.getGlobalTeamRole === true) {
      this.DraftEditrolesAllowed = true
    }
  },
  beforeDestroy() {
    this.storeProjectWsrDefaultFilter()
  },
  methods: {
    ...mapActions({
      projectRestart: 'project/projectRestart',
      setCustomDialog: 'project/setCustomDialog',
      updateProjectSearchString: 'project/updateProjectSearchString',
      updateProjectDashboardPagination:
        'project/updateProjectDashboardPagination',
      fetchProjectType: 'project/fetchProjectType',
      fetchGovernanceCategories: 'project/fetchGovernanceCategories',
      fetchAllRoles: 'roles/fetchAllRoles',
      fetchProjectSpecificAction: 'project/fetchProjectSpecificAction',
      fetchTechnologies: 'project/fetchTechnologies',
      fetchProjectReport: 'project/fetchProjectReport',
      fetchResourceCalendarReport: 'project/fetchResourceCalendarReport',
      updateProjectWsrDefaultFilter: 'project/updateProjectWsrDefaultFilter',
      updateProgressStageGraphFilter: 'project/updateProgressStageGraphFilter'
    }),

    storeProjectWsrDefaultFilter() {
      this.updateProjectWsrDefaultFilter(null)
      this.updateProgressStageGraphFilter(null)
    },
    editProject(project) {
      if (project.is_draft === 1) {
        this.$router.push(`/project/${project.uuid}/draft-edit`)
      } else {
        this.$router.push(`/project/${project.uuid}/edit`)
      }
    },
    viewProject(project) {
      this.$router.push(`/project/${project.uuid}/view`)
    },
    viewActivityLog(project) {
      this.$router.push(`/project/${project.uuid}/activity-log`)
    },
    rcaProject(project) {
      this.$router.push(`/rca/${project.uuid}/`)
    },
    addWsr(project) {
      this.$router.push('/wsr/add-wsr')
    },
    randomColors() {
      return projectHelpers.randomColors()
    },
    avatarNames(fullName) {
      return projectHelpers.avatarNames(fullName)
    },
    hasViewAccess(project) {
      const {
        account_managers: accountManagers,
        project_managers: projectManagers
      } = project || []
      let hasAccess = false

      if (this.getGlobalRole.length) {
        this.getGlobalRole.map((role) => {
          if (
            role.role_id === constant.ROLE_ID.ADMIN ||
            role.role_id === constant.ROLE_ID.GLOBAL_OPERATION ||
            role.role_id === constant.ROLE_ID.SALES ||
            role.role_id === constant.ROLE_ID.RESOURCE_MANAGER
          ) {
            hasAccess = true
          }
        })
      }
      if (accountManagers.length) {
        accountManagers.map((manager) => {
          if (manager.user !== null) {
            if (manager.user.email === this.currentUser.email) {
              hasAccess = true
            }
          }

        })
      }
      if (projectManagers.length) {
        projectManagers.map((manager) => {
          if (manager.user !== null) {
            if (manager.user.email === this.currentUser.email) {
              hasAccess = true
            }
          }
        })
      }

      return hasAccess
    },
    hasRcaAccess(project) {
      const { uuid: projectId } = project
      let rcaAccess = false

      this.getGlobalRole.forEach((role) => {
        if (
          role.role_id === constant.ROLE_ID.ADMIN ||
          role.role_id === constant.ROLE_ID.GLOBAL_OPERATION ||
          (role.role_id === constant.ROLE_ID.ACCOUNT_MANAGER &&
            role.project_id === projectId) ||
          (role.role_id === constant.ROLE_ID.PROJECT_MANAGER &&
            role.project_id === projectId)
        ) {
          rcaAccess = true
        }
      })

      return rcaAccess
    },
    async fetchProjectEligibleAction(item) {
      if (!item.roleUpdated) {
        this.showLoader = true
        await this.fetchProjectSpecificAction(item.uuid)
        const SpecificAction = { ...this.getProjectSpecificAction }

        if (SpecificAction.wsr_status === 1) {
          SpecificAction.wsr_status = { id: 1, name:'Submitted' }
        } else {
          SpecificAction.wsr_status = { id: 0, name:'Pending' }
        }

        const projectRecord = [...this.projectListData]

        projectRecord.forEach((element, index) => {
          if (element.uuid === item.uuid) {
            const actionPending = element.action_pending

            projectRecord[index] = SpecificAction
            projectRecord[index].action_pending = actionPending
            projectRecord[index].roleUpdated = true
            this.pendingAction[
              item.uuid
            ] = SpecificAction.pending_action
          }
        })

        this.projectListData = projectRecord
        this.projectRecords = projectRecord
      }

      this.showLoader = false

      this.pnGridFilter(this.searchForProjectName)

    },
    performAction(event, selected) {

      if (event.code === constant.USER_ACTION_CODE.RESTART) {
        this.inputDialog = true
        this.projectId = selected.uuid
      } else if (
        event.code === constant.USER_ACTION_CODE.CLOSE ||
        event.code === constant.USER_ACTION_CODE.HOLD
      ) {
        let actionName = 'project on-hold'
        let actionMsg = 'requesting for on-hold'

        if (event.code === constant.USER_ACTION_CODE.CLOSE) {
          actionName = 'project closure'
          actionMsg = 'closing'
        }
        this.selectedWarningActionCode = event.code
        this.projectId = selected.uuid
        const { isRequisition } = this.pendingAction[selected.uuid]
        const { allocationMapping } = this.pendingAction[selected.uuid]
        const { deallocationUnmapping } = this.pendingAction[selected.uuid]
        const { isDeallocation } = this.pendingAction[selected.uuid]
        const requisitinDone = this.pendingAction[selected.uuid]
          .requisitionDone

        if (requisitinDone) {
          this.warningMsg =
            'No resource is allocated on the project. Do you still want to continue with ' +
            actionName +
            '?'
        } else if (
          isRequisition &&
          allocationMapping &&
          deallocationUnmapping &&
          isDeallocation
        ) {
          this.warningMsg =
            'The resource allocation, resource mapping, resource deallocation and resource unmapping is pending. Do you still want to continue with ' +
            actionName +
            '?'
        } else if (
          isRequisition &&
          allocationMapping &&
          deallocationUnmapping
        ) {
          this.warningMsg =
            'The resource allocation, resource mapping and resource unmapping is pending. Do you still want to continue with ' +
            actionName +
            '?'
        } else if (
          allocationMapping &&
          deallocationUnmapping &&
          isDeallocation
        ) {
          this.warningMsg =
            'The resource mapping, resource deallocation and resource unmapping is pending. Do you still want to continue with ' +
            actionName +
            '?'
        } else if (isRequisition && deallocationUnmapping && isDeallocation) {
          this.warningMsg =
            'The resource allocation, resource deallocation and resource unmapping is pending. Do you still want to continue with ' +
            actionName +
            '?'
        } else if (isRequisition && allocationMapping && isDeallocation) {
          this.warningMsg =
            'The resource allocation, resource mapping and resource deallocation is pending. Do you still want to continue with ' +
            actionName +
            '?'
        } else if (isRequisition && allocationMapping) {
          this.warningMsg =
            'The resource allocation and resource mapping is pending. Do you still want to continue with ' +
            actionName +
            '?'
        } else if (allocationMapping && deallocationUnmapping) {
          this.warningMsg =
            'The resource mapping and resource unmapping is pending. Do you still want to continue with ' +
            actionName +
            '?'
        } else if (allocationMapping && isDeallocation) {
          this.warningMsg =
            'The resource mapping and resource deallocation is pending. Do you still want to continue with ' +
            actionName +
            '?'
        } else if (isRequisition && deallocationUnmapping) {
          this.warningMsg =
            'The resource allocation and resource unmapping is pending. Do you still want to continue with ' +
            actionName +
            '?'
        } else if (isDeallocation && deallocationUnmapping) {
          this.warningMsg =
            'The resource deallocation and resource unmapping is pending. Do you still want to continue with ' +
            actionName +
            '?'
        } else if (isRequisition && isDeallocation) {
          this.warningMsg =
            'The resource allocation and resource deallocation is pending. Do you still want to continue with ' +
            actionName +
            '?'
        } else if (isRequisition) {
          this.warningMsg =
            'A resource allocation request is in progress. Do you still want to continue with ' +
            actionName +
            '?'
        } else if (allocationMapping) {
          this.warningMsg =
            'The resource mapping is pending on the project. Do you still want to proceed with ' +
            actionName +
            '?'
        } else if (deallocationUnmapping) {
          this.warningMsg =
            'The resource unmapping is pending on the project. Do you still want to proceed with ' +
            actionName +
            '?'
        } else if (isDeallocation) {
          this.warningMsg =
            'Please perform resource deallocation before ' +
            actionMsg +
            ' project. Do you still want to continue with ' +
            actionName +
            '?'
        }
        if (this.warningMsg !== '') {
          this.warningDialog = true
        } else {
          this.$router.push(`/project/${selected.uuid}/${event.code}`)
        }
      } else if (event.status === constant.ACTION_STATUS.AVAILABLE) {
        this.$router.push(`/project/${selected.uuid}/${event.code}`)
      }

    },
    warningApprove() {
      this.warningDialog = false
      this.$router.push(
        `/project/${this.projectId}/${this.selectedWarningActionCode}`
      )
    },
    updatePagination(val) {
      this.updateProjectDashboardPagination(val)
    },
    closeWarning() {
      this.warningDialog = false
      this.actionSelected = []
    },
    close() {
      this.inputDialog = false
      this.reasonForClose = ''
      this.actionSelected = []
    },
    storeProjectSearchString(value) {
      this.updateProjectSearchString(value)
    },
    async save() {
      const requestData = {
        project_id: this.projectId,
        message: this.reasonForClose
      }

      this.close()
      await this.projectRestart(requestData)

      const restartProjectData = { ...this.getRestartProject }

      if (restartProjectData.wsr_status === 1) {
        restartProjectData.wsr_status = { id: 1, name:'Submitted' }
      } else {
        restartProjectData.wsr_status = { id: 0, name:'Pending' }
      }

      this.reasonForClose = ''
      const projectRecord = [...this.projectListData]

      projectRecord.forEach((element, index) => {
        const accountMangerArray = element.account_managers
        const projectMangerArray = element.project_managers
        const actionPendingArray = element.action_pending

        if (element.uuid === this.projectId) {
          projectRecord[index] = restartProjectData
          projectRecord[index].roleUpdated = false
          projectRecord[index].account_managers = accountMangerArray
          projectRecord[index].project_managers = projectMangerArray
          projectRecord[index].action_pending = actionPendingArray
        }
      })
      this.projectListData = projectRecord
    },
    /**
     * Filter for project names column.
     * @param value Value to be tested.
     * @returns {boolean}
     */
    PorjectNameFilter(value) {
      // If this filter has no value we just skip the entire filter.
      if (!this.searchForProject || !value) {
        return true
      }

      // partially contains the searched word.
      return value.toLowerCase().includes(this.searchForProject.toLowerCase())
    },
    /**
     * Filter for project status column.
     * @param value Value to be tested.
     * @returns {boolean}
     */
    projectStatusFilter(value) {
      if (!this.projectStatus.status_id || !value) {
        return true
      }
      let { status } = value

      status = status.toString()
      if (this.projectStatus.status_id.includes(constant.STATUS.DRAFT)) {
        if (
          (this.projectStatus.status_id.length &&
            this.projectStatus.status_id.includes(status)) ||
          value.is_draft === 1
        ) {
          return true
        }
        if (
          this.projectStatus.status_id.length &&
          status !== constant.STATUS.NEW &&
          status !== constant.STATUS.INITIATION &&
          status !== constant.STATUS.ON_HOLD &&
          status !== constant.STATUS.CLOSED &&
          this.projectStatus.status_id.includes(constant.STATUS.INPROGRESS)
        ) {
          return true
        }
        if (
          this.projectStatus.status_id.length &&
          this.projectStatus.status_id.includes(constant.STATUS.NEW) &&
          (value.is_approve === 0 || value.is_approve === 1) &&
          value.is_draft === 0 &&
          status === constant.STATUS.INITIATION
        ) {
          return true
        }
      } else {
        if (
          this.projectStatus.status_id.length &&
          this.projectStatus.status_id.includes(status) &&
          value.is_draft === 0
        ) {
          return true
        }
        if (
          this.projectStatus.status_id.length &&
          this.projectStatus.status_id.includes(constant.STATUS.NEW) &&
          (value.is_approve === 0 || value.is_approve === 1) &&
          value.is_draft === 0 &&
          status === constant.STATUS.INITIATION
        ) {
          return true
        }
        if (
          this.projectStatus.status_id.length &&
          value.is_draft === 0 &&
          status !== constant.STATUS.NEW &&
          status !== constant.STATUS.INITIATION &&
          status !== constant.STATUS.ON_HOLD &&
          status !== constant.STATUS.CLOSED &&
          this.projectStatus.status_id.includes(constant.STATUS.INPROGRESS)
        ) {
          return true
        }
      }
      if (this.projectStatus.status_id.length < 1) {
        return true
      }

      return false
    },
    /**
     * Filter for project type column.
     * @param value Value to be tested.
     * @returns {boolean}
     */
    projectTypeFilter(value) {
      if (!this.projectType.type_id || !value.id) {
        return true
      }
      if (
        this.projectType.type_id.length &&
        this.projectType.type_id.includes(value.id)
      ) {
        return true
      }
      if (
        this.projectType.type_id.length &&
        (value.id === constant.BILLING_TYPE.FIXED_COST ||
          value.id === constant.BILLING_TYPE.HOURLY ||
          value.id === constant.BILLING_TYPE.RETAINER) &&
        this.projectType.type_id.includes(constant.BILLING_TYPE.FIXED_COST)
      ) {
        return true
      }

      if (this.projectType.type_id.length < 1) {
        return true
      }

      return false
    },
    /**
     * Filter for project type column.
     * @param value Value to be tested.
     * @returns {boolean}
     */
    wsrTypeFilter(value) {
      if (!this.wsrType.id || !value) {
        return true
      }
      if (
        this.wsrType.id.length &&
        this.wsrType.id.includes(value.id)
      ) {
        return true
      }
      if (this.wsrType.id.length < 1) {
        return true
      }

      return false
    },
    /**
     * Filter for grid view of project details.
     * @param value Value to be tested.
     * @returns {boolean}
     */
    pnGridFilter(value) {   //grid filter for project name search
      if (value.length > 0) {
        const data = this.projectListData

        this.projectRecords = data.filter((item) =>
          item.project_name
            .toLowerCase()
            .match(RegExp(`^${value.toLowerCase()}.*$`))
        )

        return this.projectRecords
      } else {
        this.projectRecords = this.projectListData

        return this.projectRecords
      }
    },
    ptGridFilter() {
      if (this.searchForProjectName.length > 0) {
        this.searchForProjectName = ''
      }
      this.projectRecords = this.gridViewFilter()

      return this.projectRecords
    },

    wsrGridFilter() {
      if (this.searchForProjectName.length > 0) {
        this.searchForProjectName = ''
      }
      this.projectRecords = this.gridViewFilter()

      return this.projectRecords
    },

    psGridFilter() {
      if (this.searchForProjectName.length > 0) {
        this.searchForProjectName = ''
      }
      this.projectRecords = this.gridViewFilter()

      return this.projectRecords
    },
    gridViewFilter() {
      const data = []
      let billingType = null
      let wsrType = null

      this.projectListData.forEach((detail) => {
        const { is_approve: isApprove } = detail.track

        if (detail.billing_type) {  // Check project type
          const type = Object.prototype.toString.call(detail.billing_type)

          if (type === '[object Object]') {
            billingType = detail.billing_type.id
          } else {
            billingType = detail.billing_type
          }
        }
        if (detail.wsr_status) { // Check WSR Status
          const wType = Object.prototype.toString.call(detail.wsr_status)

          if (wType === '[object Object]') {
            wsrType = detail.wsr_status.id
          } else {

            wsrType = detail.wsr_status
          }
        }

        if (   // projectStatusGrid filter conitions
          this.projectStatusGrid.status_id &&
          this.projectStatusGrid.status_id.length > 0 &&
          this.projectStatusGrid.status_id.includes(constant.STATUS.DRAFT)
        ) {
          if (
            (!this.wsrTypeGrid.id ||
              this.wsrTypeGrid.id.length < 1) &&
            (!this.projectTypeGrid.type_id ||
              this.projectTypeGrid.type_id < 1) &&
            this.projectStatusGrid.status_id.length === 1 &&
            detail.is_draft === 1
          ) {
            data.push(detail)
          }

          else if (  // Only Billing Type Selected
            this.projectTypeGrid.type_id &&
            this.projectTypeGrid.type_id.length >= 1 &&
            (!this.projectStatusGrid.status_id ||
              this.projectStatusGrid.status_id.length < 1) &&
            (!this.wsrTypeGrid.id ||
              this.wsrTypeGrid.id.length < 1)
          ) {
            if (
              constant.ALL_BILLING_ID.some((v) =>
                this.projectTypeGrid.type_id.includes(v)
              )
            ) {
              if (
                (this.projectTypeGrid.type_id.includes(
                  constant.BILLING_TYPE.FIXED_COST
                ) &&
                  constant.BILLABLE_ID.includes(billingType)) ||
                (this.projectTypeGrid.type_id.includes(
                  constant.BILLING_TYPE.POC
                ) &&
                  billingType === constant.BILLING_TYPE.POC) ||
                (this.projectTypeGrid.type_id.includes(
                  constant.BILLING_TYPE.INTERNAL
                ) &&
                  billingType === constant.BILLING_TYPE.INTERNAL)
              ) {
                data.push(detail)
              }
            }
          }

          else if (  // Only project status Selected
            this.projectStatusGrid.status_id &&
            this.projectStatusGrid.status_id.length >= 1 &&
            (!this.projectTypeGrid.type_id ||
            this.projectTypeGrid.type_id < 1) &&
            (!this.wsrTypeGrid.id ||
              this.wsrTypeGrid.id.length < 1)
          ) {
            if (
              constant.ALL_STATUS.some((v) =>
                this.projectStatusGrid.status_id.includes(v)
              )
            ) {
              if (
                (this.projectStatusGrid.status_id.includes(
                  constant.STATUS.INPROGRESS
                ) &&
                  !constant.NON_INPROGRESS_STATUS.includes(detail.status)) ||
                (this.projectStatusGrid.status_id.includes(
                  constant.STATUS.CLOSED
                ) &&
                  detail.status === Number(constant.STATUS.CLOSED)) ||
                (this.projectStatusGrid.status_id.includes(
                  constant.STATUS.NEW
                ) &&
                  (detail.status === Number(constant.STATUS.NEW) ||
                    (detail.status === Number(constant.STATUS.INITIATION) &&
                      (isApprove === 0 || isApprove === 1)))) ||
                (this.projectStatusGrid.status_id.includes(
                  constant.STATUS.ON_HOLD
                ) &&
                  detail.status === Number(constant.STATUS.ON_HOLD))
              ) {
                data.push(detail)
              }
            }
          }

          else if (   //ONLY PROJECT WSR Status Selected
            this.wsrTypeGrid.id &&
            this.wsrTypeGrid.id.length >= 1 &&
            (!this.projectTypeGrid.type_id ||
              this.projectTypeGrid.type_id < 1) &&
            (!this.projectStatusGrid.status_id ||
              this.projectStatusGrid.status_id < 1)
          ) {

            if (
              constant.ALL_WSR_STATUS.some((v) =>
                this.wsrTypeGrid.id.includes(v)
              )
            ) {
              if (
                (this.wsrTypeGrid.id.includes( constant.WSR_TYPE.SUBMITTED)
                && wsrType === constant.WSR_TYPE.SUBMITTED)
                ||
                 (this.wsrTypeGrid.id.includes( constant.WSR_TYPE.PENDING)
                 && wsrType === constant.WSR_TYPE.PENDING)
              ) {
                data.push(detail)
              }
            }

          }

          else if (    //ONLY PROJECT WSR Status and Billing Type Selected

            this.projectTypeGrid.type_id &&
            this.projectTypeGrid.type_id.length >= 1 &&
            (!this.projectStatusGrid.status_id ||
              this.projectStatusGrid.status_id < 1) &&
            this.wsrTypeGrid.id &&
            this.wsrTypeGrid.id.length >= 1
          ) {
            if (
              constant.ALL_BILLING_ID.some((v) =>
                this.projectTypeGrid.type_id.includes(v)
              ) &&
               constant.ALL_WSR_STATUS.some((v) =>
                 this.wsrTypeGrid.id.includes(v)
               )
            )
            {
              if (
                ((this.projectTypeGrid.type_id.includes(
                  constant.BILLING_TYPE.FIXED_COST
                ) && constant.BILLABLE_ID.includes(billingType)) ||
                  (this.projectTypeGrid.type_id.includes(
                    constant.BILLING_TYPE.POC
                  ) && billingType === constant.BILLING_TYPE.POC) ||
                  (this.projectTypeGrid.type_id.includes(
                    constant.BILLING_TYPE.INTERNAL
                  ) && billingType === constant.BILLING_TYPE.INTERNAL)) &&
                    ((this.wsrTypeGrid.id.includes( constant.WSR_TYPE.SUBMITTED)
                      && wsrType === constant.WSR_TYPE.SUBMITTED) ||
                 (this.wsrTypeGrid.id.includes( constant.WSR_TYPE.PENDING)
                 && wsrType === constant.WSR_TYPE.PENDING) )
              ) {
                data.push(detail)
              }
            }
          }

          else if ( //ONLY PROJECT WSR Status and project status Selected
            (!this.projectTypeGrid.type_id ||
            this.projectTypeGrid.type_id < 1) &&
            this.projectStatusGrid.status_id &&
            this.projectStatusGrid.status_id.length >= 1 &&
            this.wsrTypeGrid.id &&
            this.wsrTypeGrid.id.length >= 1
          ) {
            if ( constant.ALL_STATUS.some((v) =>
              this.projectStatusGrid.status_id.includes(v))  &&
               constant.ALL_WSR_STATUS.some((v) =>
                 this.wsrTypeGrid.id.includes(v) ))
            {
              if (
                ((this.projectStatusGrid.status_id.includes(
                  constant.STATUS.INPROGRESS
                ) &&
                  !constant.NON_INPROGRESS_STATUS.includes(detail.status)) ||
                  (this.projectStatusGrid.status_id.includes(
                    constant.STATUS.CLOSED
                  ) &&
                    detail.status === Number(constant.STATUS.CLOSED)) ||
                  (this.projectStatusGrid.status_id.includes(
                    constant.STATUS.NEW
                  ) &&
                    (detail.status === Number(constant.STATUS.NEW) ||
                      (detail.status === Number(constant.STATUS.INITIATION) &&
                        (isApprove === 0 || isApprove === 1)))) ||
                  (this.projectStatusGrid.status_id.includes(
                    constant.STATUS.ON_HOLD ) &&  detail.status === Number(constant.STATUS.ON_HOLD))) &&
                    ( (this.wsrTypeGrid.id.includes( constant.WSR_TYPE.SUBMITTED)
                && wsrType === constant.WSR_TYPE.SUBMITTED)
                || (this.wsrTypeGrid.id.includes( constant.WSR_TYPE.PENDING)
                 && wsrType === constant.WSR_TYPE.PENDING) )

              ) {
                data.push(detail)
              }
            }

          }

          else if (  // both project status and Billing Type Selected
            this.projectTypeGrid.type_id &&
            this.projectTypeGrid.type_id.length >= 1 &&
            this.projectStatusGrid.status_id &&
            this.projectStatusGrid.status_id.length >= 1 &&
            (!this.wsrTypeGrid.id ||
              this.wsrTypeGrid.id.length < 1)
          ) {
            if (
              constant.ALL_BILLING_ID.some((v) =>
                this.projectTypeGrid.type_id.includes(v)
              ) &&
              constant.ALL_STATUS.some((v) =>
                this.projectStatusGrid.status_id.includes(v)
              )
            ) {
              if (
                ((this.projectTypeGrid.type_id.includes(
                  constant.BILLING_TYPE.FIXED_COST
                ) &&
                  constant.BILLABLE_ID.includes(billingType)) ||
                  (this.projectTypeGrid.type_id.includes(
                    constant.BILLING_TYPE.POC
                  ) &&
                    billingType === constant.BILLING_TYPE.POC) ||
                  (this.projectTypeGrid.type_id.includes(
                    constant.BILLING_TYPE.INTERNAL
                  ) &&
                    billingType === constant.BILLING_TYPE.INTERNAL)) &&
                ((this.projectStatusGrid.status_id.includes(
                  constant.STATUS.INPROGRESS
                ) &&
                  !constant.NON_INPROGRESS_STATUS.includes(detail.status)) ||
                  detail.is_draft === 1 ||
                  (this.projectStatusGrid.status_id.includes(
                    constant.STATUS.CLOSED
                  ) &&
                    detail.status === Number(constant.STATUS.CLOSED)) ||
                  (this.projectStatusGrid.status_id.includes(
                    constant.STATUS.NEW
                  ) &&
                    (detail.status === Number(constant.STATUS.NEW) ||
                      (detail.status === Number(constant.STATUS.INITIATION) &&
                        (isApprove === 0 || isApprove === 1)))) ||
                  (this.projectStatusGrid.status_id.includes(
                    constant.STATUS.ON_HOLD
                  ) &&
                    detail.status === Number(constant.STATUS.ON_HOLD)))
              ) {
                data.push(detail)
              }
            }
          }

          else if (   // all 3 selected
            this.projectTypeGrid.type_id &&
            this.projectTypeGrid.type_id.length >= 1 &&
            this.projectStatusGrid.status_id &&
            this.projectStatusGrid.status_id.length >= 1 &&
            this.wsrTypeGrid.id &&
            this.wsrTypeGrid.id.length >= 1
          ) {
            if (
              constant.ALL_BILLING_ID.some((v) =>
                this.projectTypeGrid.type_id.includes(v)
              ) &&
              constant.ALL_STATUS.some((v) =>
                this.projectStatusGrid.status_id.includes(v)
              )
              &&
               constant.ALL_WSR_STATUS.some((v) =>
                 this.wsrTypeGrid.id.includes(v)
               )
            )
            {
              if (
                ((this.projectTypeGrid.type_id.includes(
                  constant.BILLING_TYPE.FIXED_COST
                ) &&
                  constant.BILLABLE_ID.includes(billingType)) ||
                  (this.projectTypeGrid.type_id.includes(
                    constant.BILLING_TYPE.POC
                  ) &&
                    billingType === constant.BILLING_TYPE.POC) ||
                  (this.projectTypeGrid.type_id.includes(
                    constant.BILLING_TYPE.INTERNAL
                  ) &&
                    billingType === constant.BILLING_TYPE.INTERNAL)) &&
                ((this.projectStatusGrid.status_id.includes(
                  constant.STATUS.INPROGRESS
                ) &&
                  !constant.NON_INPROGRESS_STATUS.includes(detail.status)) ||
                  (this.projectStatusGrid.status_id.includes(
                    constant.STATUS.CLOSED
                  ) &&
                    detail.status === Number(constant.STATUS.CLOSED)) ||
                  (this.projectStatusGrid.status_id.includes(
                    constant.STATUS.NEW
                  ) &&
                    (detail.status === Number(constant.STATUS.NEW) ||
                      (detail.status === Number(constant.STATUS.INITIATION) &&
                        (isApprove === 0 || isApprove === 1)))) ||
                  (this.projectStatusGrid.status_id.includes(
                    constant.STATUS.ON_HOLD
                  ) &&
                    detail.status === Number(constant.STATUS.ON_HOLD))) &&
                    ( (this.wsrTypeGrid.id.includes( constant.WSR_TYPE.SUBMITTED)
                && wsrType === constant.WSR_TYPE.SUBMITTED) ||
                 (this.wsrTypeGrid.id.includes( constant.WSR_TYPE.PENDING)
                 && wsrType === constant.WSR_TYPE.PENDING) )
              ) {
                data.push(detail)
              }
            }
          }

        }
        else {
          if (  //no filter selected
            detail.is_draft === 0 &&
            (!this.wsrTypeGrid.id ||
             this.wsrTypeGrid.id.length < 1) &&
            (!this.projectTypeGrid.type_id ||
              this.projectTypeGrid.type_id < 1) &&
            (!this.projectStatusGrid.status_id ||
              this.projectStatusGrid.status_id < 1)
          ) {
            data.push(detail)
          }

          else if (  //only billing type selected
            detail.is_draft === 0 &&
            this.projectTypeGrid.type_id &&
            this.projectTypeGrid.type_id.length >= 1 &&
            (!this.projectStatusGrid.status_id ||
              this.projectStatusGrid.status_id < 1)  &&
            (!this.wsrTypeGrid.id ||
              this.wsrTypeGrid.id.length < 1)
          ) {
            if (
              constant.ALL_BILLING_ID.some((v) =>
                this.projectTypeGrid.type_id.includes(v)
              )
            ) {

              if (
                (this.projectTypeGrid.type_id.includes(constant.BILLING_TYPE.FIXED_COST)
                && constant.BILLABLE_ID.includes(billingType))
                || (this.projectTypeGrid.type_id.includes( constant.BILLING_TYPE.POC)
                && billingType === constant.BILLING_TYPE.POC)
                || (this.projectTypeGrid.type_id.includes( constant.BILLING_TYPE.INTERNAL)
                 && billingType === constant.BILLING_TYPE.INTERNAL)
              ) {
                data.push(detail)
              }
            }
          }

          else if (   //only project status selected
            detail.is_draft === 0 &&
            this.projectStatusGrid.status_id &&
            this.projectStatusGrid.status_id.length >= 1 &&
            this.projectStatusGrid.status_id.length >= 1 &&
            (!this.projectTypeGrid.type_id || this.projectTypeGrid.type_id < 1) &&
            (!this.wsrTypeGrid.id ||
              this.wsrTypeGrid.id.length < 1)
          ) {

            if (
              constant.ALL_STATUS.some((v) =>
                this.projectStatusGrid.status_id.includes(v)
              )
            ) {
              if (
                (this.projectStatusGrid.status_id.includes(
                  constant.STATUS.INPROGRESS
                ) &&
                  !constant.NON_INPROGRESS_STATUS.includes(detail.status)) ||
                (this.projectStatusGrid.status_id.includes(
                  constant.STATUS.CLOSED
                ) &&
                  detail.status === Number(constant.STATUS.CLOSED)) ||
                (this.projectStatusGrid.status_id.includes(
                  constant.STATUS.NEW
                ) &&
                  (detail.status === Number(constant.STATUS.NEW) ||
                    (detail.status === Number(constant.STATUS.INITIATION) &&
                      (isApprove === 0 || isApprove === 1)))) ||
                (this.projectStatusGrid.status_id.includes(
                  constant.STATUS.ON_HOLD
                ) &&
                  detail.status === Number(constant.STATUS.ON_HOLD))
              ) {
                data.push(detail)
              }
            }
          }

          else if (   //ONLY PROJECT WSR Status Selected
            detail.is_draft === 0 &&
            this.wsrTypeGrid.id &&
            this.wsrTypeGrid.id.length >= 1 &&
            (!this.projectTypeGrid.type_id ||
              this.projectTypeGrid.type_id < 1) &&
            (!this.projectStatusGrid.status_id ||
              this.projectStatusGrid.status_id < 1)
          ) {

            if (
              constant.ALL_WSR_STATUS.some((v) =>
                this.wsrTypeGrid.id.includes(v)
              )
            ) {
              if (
                (this.wsrTypeGrid.id.includes( constant.WSR_TYPE.SUBMITTED)
                && wsrType === constant.WSR_TYPE.SUBMITTED)
                ||
                 (this.wsrTypeGrid.id.includes( constant.WSR_TYPE.PENDING)
                 && wsrType === constant.WSR_TYPE.PENDING)
              ) {
                data.push(detail)
              }
            }

          }

          else if (    //ONLY PROJECT WSR Status and Billing Type Selected
            detail.is_draft === 0 &&
           this.projectTypeGrid.type_id &&
            this.projectTypeGrid.type_id.length >= 1 &&
            (!this.projectStatusGrid.status_id ||
              this.projectStatusGrid.status_id < 1) &&
            this.wsrTypeGrid.id &&
            this.wsrTypeGrid.id.length >= 1
          ) {

            if (
              constant.ALL_BILLING_ID.some((v) =>
                this.projectTypeGrid.type_id.includes(v)
              ) &&

               constant.ALL_WSR_STATUS.some((v) =>
                 this.wsrTypeGrid.id.includes(v)
               )
            )
            {
              if (
                ((this.projectTypeGrid.type_id.includes(
                  constant.BILLING_TYPE.FIXED_COST
                ) &&
                  constant.BILLABLE_ID.includes(billingType)) ||
                  (this.projectTypeGrid.type_id.includes(
                    constant.BILLING_TYPE.POC
                  ) &&
                    billingType === constant.BILLING_TYPE.POC) ||
                  (this.projectTypeGrid.type_id.includes(
                    constant.BILLING_TYPE.INTERNAL
                  ) &&
                    billingType === constant.BILLING_TYPE.INTERNAL))

                    &&

                    (
                      (this.wsrTypeGrid.id.includes( constant.WSR_TYPE.SUBMITTED)
                && wsrType === constant.WSR_TYPE.SUBMITTED)
                ||
                 (this.wsrTypeGrid.id.includes( constant.WSR_TYPE.PENDING)
                 && wsrType === constant.WSR_TYPE.PENDING)
                    )

              ) {
                data.push(detail)
              }
            }

          }

          else if ( //ONLY PROJECT WSR Status and project status Selected
            detail.is_draft === 0 &&
            (!this.projectTypeGrid.type_id ||
            this.projectTypeGrid.type_id < 1) &&
            this.projectStatusGrid.status_id &&
            this.projectStatusGrid.status_id.length >= 1 &&
            this.wsrTypeGrid.id &&
            this.wsrTypeGrid.id.length >= 1

          ) {

            if (
              constant.ALL_STATUS.some((v) =>
                this.projectStatusGrid.status_id.includes(v)
              )
              &&
               constant.ALL_WSR_STATUS.some((v) =>
                 this.wsrTypeGrid.id.includes(v)
               )
            )
            {
              if (
                ((this.projectStatusGrid.status_id.includes(
                  constant.STATUS.INPROGRESS
                ) &&
                  !constant.NON_INPROGRESS_STATUS.includes(detail.status)) ||
                  (this.projectStatusGrid.status_id.includes(
                    constant.STATUS.CLOSED
                  ) &&
                    detail.status === Number(constant.STATUS.CLOSED)) ||
                  (this.projectStatusGrid.status_id.includes(
                    constant.STATUS.NEW
                  ) &&
                    (detail.status === Number(constant.STATUS.NEW) ||
                      (detail.status === Number(constant.STATUS.INITIATION) &&
                        (isApprove === 0 || isApprove === 1)))) ||
                  (this.projectStatusGrid.status_id.includes(
                    constant.STATUS.ON_HOLD
                  ) &&
                    detail.status === Number(constant.STATUS.ON_HOLD)))

                    &&

                    (
                      (this.wsrTypeGrid.id.includes( constant.WSR_TYPE.SUBMITTED)
                && wsrType === constant.WSR_TYPE.SUBMITTED)
                ||
                 (this.wsrTypeGrid.id.includes( constant.WSR_TYPE.PENDING)
                 && wsrType === constant.WSR_TYPE.PENDING)
                    )

              ) {
                data.push(detail)
              }
            }

          }

          else if (   //both project status selected and billing type selected
            detail.is_draft === 0 &&
            this.projectTypeGrid.type_id &&
            this.projectTypeGrid.type_id.length >= 1 &&
            this.projectStatusGrid.status_id &&
            this.projectStatusGrid.status_id.length >= 1 &&
            (!this.wsrTypeGrid.id ||
              this.wsrTypeGrid.id.length < 1)
          ) {
            if (
              constant.ALL_BILLING_ID.some((v) =>
                this.projectTypeGrid.type_id.includes(v)
              ) &&
              constant.ALL_STATUS.some((v) =>
                this.projectStatusGrid.status_id.includes(v)
              )
            )
            {
              if (
                ((this.projectTypeGrid.type_id.includes(
                  constant.BILLING_TYPE.FIXED_COST
                ) &&
                  constant.BILLABLE_ID.includes(billingType)) ||
                  (this.projectTypeGrid.type_id.includes(
                    constant.BILLING_TYPE.POC
                  ) &&
                    billingType === constant.BILLING_TYPE.POC) ||
                  (this.projectTypeGrid.type_id.includes(
                    constant.BILLING_TYPE.INTERNAL
                  ) &&
                    billingType === constant.BILLING_TYPE.INTERNAL)) &&

                ((this.projectStatusGrid.status_id.includes(
                  constant.STATUS.INPROGRESS
                ) &&
                  !constant.NON_INPROGRESS_STATUS.includes(detail.status)) ||
                  (this.projectStatusGrid.status_id.includes(
                    constant.STATUS.CLOSED
                  ) &&
                    detail.status === Number(constant.STATUS.CLOSED)) ||
                  (this.projectStatusGrid.status_id.includes(
                    constant.STATUS.NEW
                  ) &&
                    (detail.status === Number(constant.STATUS.NEW) ||
                      (detail.status === Number(constant.STATUS.INITIATION) &&
                        (isApprove === 0 || isApprove === 1)))) ||
                  (this.projectStatusGrid.status_id.includes(
                    constant.STATUS.ON_HOLD
                  ) &&
                    detail.status === Number(constant.STATUS.ON_HOLD)))
              ) {
                data.push(detail)
              }
            }
          }

          else if (   // all 3 selected
            detail.is_draft === 0 &&
            this.projectTypeGrid.type_id &&
            this.projectTypeGrid.type_id.length >= 1 &&
            this.projectStatusGrid.status_id &&
            this.projectStatusGrid.status_id.length >= 1 &&
            this.wsrTypeGrid.id &&
            this.wsrTypeGrid.id.length >= 1
          ) {
            if (
              constant.ALL_BILLING_ID.some((v) =>
                this.projectTypeGrid.type_id.includes(v)
              ) &&
              constant.ALL_STATUS.some((v) =>
                this.projectStatusGrid.status_id.includes(v)
              )
              &&
               constant.ALL_WSR_STATUS.some((v) =>
                 this.wsrTypeGrid.id.includes(v)
               )
            )
            {
              if (
                ((this.projectTypeGrid.type_id.includes(
                  constant.BILLING_TYPE.FIXED_COST
                ) &&
                  constant.BILLABLE_ID.includes(billingType)) ||
                  (this.projectTypeGrid.type_id.includes(
                    constant.BILLING_TYPE.POC
                  ) &&
                    billingType === constant.BILLING_TYPE.POC) ||
                  (this.projectTypeGrid.type_id.includes(
                    constant.BILLING_TYPE.INTERNAL
                  ) &&
                    billingType === constant.BILLING_TYPE.INTERNAL))
                    &&
                ((this.projectStatusGrid.status_id.includes(
                  constant.STATUS.INPROGRESS
                ) &&
                  !constant.NON_INPROGRESS_STATUS.includes(detail.status)) ||
                  (this.projectStatusGrid.status_id.includes(
                    constant.STATUS.CLOSED
                  ) &&
                    detail.status === Number(constant.STATUS.CLOSED)) ||
                  (this.projectStatusGrid.status_id.includes(
                    constant.STATUS.NEW
                  ) &&
                    (detail.status === Number(constant.STATUS.NEW) ||
                      (detail.status === Number(constant.STATUS.INITIATION) &&
                        (isApprove === 0 || isApprove === 1)))) ||
                  (this.projectStatusGrid.status_id.includes(
                    constant.STATUS.ON_HOLD
                  ) &&  detail.status === Number(constant.STATUS.ON_HOLD))) &&
                  ( (this.wsrTypeGrid.id.includes( constant.WSR_TYPE.SUBMITTED)
                && wsrType === constant.WSR_TYPE.SUBMITTED) ||
                 (this.wsrTypeGrid.id.includes( constant.WSR_TYPE.PENDING)
                 && wsrType === constant.WSR_TYPE.PENDING) )
              ) {
                data.push(detail)
              }
            }
          }

        }
      })

      return data
    },
    downloadExcel(reportId) {
      if (reportId === '1') {
        this.exportExcelSheet()
      } else if (reportId === '2') {
        this.downloadExcelReport()
      } else if (reportId === '3') {
        this.downloadCalendarReport()
      }
    },
    exportExcelSheet() {
      const dataForExcel = []

      this.exportData = []
      let billingType = null

      this.projectListData.forEach((detail) => {
        if (detail.billing_type) {
          const type = Object.prototype.toString.call(detail.billing_type)

          if (type === '[object Object]') {
            billingType = detail.billing_type.id
          } else {
            billingType = detail.billing_type
          }
        }
        if (
          detail.is_draft === 0 &&
          (!this.projectType.type_id || this.projectType.type_id < 1) &&
          (!this.projectStatus.status_id || this.projectStatus.status_id < 1)
        ) {
          this.exportData.push(detail)
        } else if (
          detail.is_draft === 0 &&
          this.projectType.type_id &&
          this.projectType.type_id.length >= 1 &&
          (!this.projectStatus.status_id || this.projectStatus.status_id < 1)
        ) {
          if (
            constant.ALL_BILLING_ID.some((v) =>
              this.projectType.type_id.includes(v)
            )
          ) {
            if (
              (this.projectType.type_id.includes(
                constant.BILLING_TYPE.FIXED_COST
              ) &&
                constant.BILLABLE_ID.includes(billingType)) ||
              (this.projectType.type_id.includes(constant.BILLING_TYPE.POC) &&
                billingType === constant.BILLING_TYPE.POC) ||
              (this.projectType.type_id.includes(
                constant.BILLING_TYPE.INTERNAL
              ) &&
                billingType === constant.BILLING_TYPE.INTERNAL)
            ) {
              this.exportData.push(detail)
            }
          }
        } else if (
          detail.is_draft === 0 &&
          this.projectStatus.status_id.length >= 1 &&
          (!this.projectType.type_id || this.projectType.type_id < 1)
        ) {
          if (
            constant.ALL_STATUS.some((v) =>
              this.projectStatus.status_id.includes(v)
            )
          ) {
            if (
              (this.projectStatus.status_id.includes(
                constant.STATUS.INPROGRESS
              ) &&
                !constant.NON_INPROGRESS_STATUS.includes(detail.status)) ||
              (this.projectStatus.status_id.includes(constant.STATUS.CLOSED) &&
                detail.status === Number(constant.STATUS.CLOSED)) ||
              (this.projectStatus.status_id.includes(constant.STATUS.NEW) &&
                detail.status === Number(constant.STATUS.NEW)) ||
              (this.projectStatus.status_id.includes(constant.STATUS.ON_HOLD) &&
                detail.status === Number(constant.STATUS.ON_HOLD))
            ) {
              this.exportData.push(detail)
            }
          }
        } else if (
          detail.is_draft === 0 &&
          this.projectType.type_id &&
          this.projectType.type_id.length >= 1 &&
          this.projectStatus.status_id &&
          this.projectStatus.status_id.length >= 1
        ) {
          if (
            constant.ALL_BILLING_ID.some((v) =>
              this.projectType.type_id.includes(v)
            ) &&
            constant.ALL_STATUS.some((v) =>
              this.projectStatus.status_id.includes(v)
            )
          ) {
            if (
              ((this.projectType.type_id.includes(
                constant.BILLING_TYPE.FIXED_COST
              ) &&
                constant.BILLABLE_ID.includes(billingType)) ||
                (this.projectType.type_id.includes(constant.BILLING_TYPE.POC) &&
                  billingType === constant.BILLING_TYPE.POC) ||
                (this.projectType.type_id.includes(
                  constant.BILLING_TYPE.INTERNAL
                ) &&
                  billingType === constant.BILLING_TYPE.INTERNAL)) &&
              ((this.projectStatus.status_id.includes(
                constant.STATUS.INPROGRESS
              ) &&
                !constant.NON_INPROGRESS_STATUS.includes(detail.status)) ||
                (this.projectStatus.status_id.includes(
                  constant.STATUS.CLOSED
                ) &&
                  detail.status === Number(constant.STATUS.CLOSED)) ||
                (this.projectStatus.status_id.includes(constant.STATUS.NEW) &&
                  detail.status === Number(constant.STATUS.NEW)) ||
                (this.projectStatus.status_id.includes(
                  constant.STATUS.ON_HOLD
                ) &&
                  detail.status === Number(constant.STATUS.ON_HOLD)))
            ) {
              this.exportData.push(detail)
            }
          }
        }
      })

      this.exportData.map((tableData) => {
        let accountManagers = ''

        if (tableData.account_managers && tableData.account_managers !== null) {
          tableData.account_managers.map((item) => {
            accountManagers =
              accountManagers !== ''
                ? accountManagers + ', ' + item.user.display_name
                : accountManagers + item.user.display_name
          })
        }

        let projectManagers = ''

        if (tableData.project_managers && tableData.project_managers !== null) {
          tableData.project_managers.map((item) => {
            projectManagers =
              projectManagers !== ''
                ? projectManagers + ', ' + item.user.display_name
                : projectManagers + item.user.display_name
          })
        }
        let tech = ''

        if (tableData.technologies && tableData.technologies !== null) {
          tableData.technologies.map((item) => {
            tech = tech !== '' ? tech + ', ' + item.name : tech + item.name
          })
        }
        let projectDomain = ''

        if (tableData.project_domains && tableData.project_domains !== null) {
          tableData.project_domains.map((item) => {
            projectDomain =
              projectDomain !== ''
                ? projectDomain + ', ' + item.name
                : projectDomain + item.name
          })
        }
        let clientNames = ''
        let clientEmails = ''
        const clientArray = JSON.parse(tableData.client_detail)

        if (clientArray && clientArray !== null) {
          clientArray.map((item) => {
            clientNames =
              clientNames !== ''
                ? clientNames + ', ' + item.full_name
                : clientNames + item.full_name
            clientEmails =
              clientEmails !== ''
                ? clientEmails + ', ' + item.address
                : clientEmails + item.address
          })
        }
        let projectStatus = ''

        if (!constant.NON_INPROGRESS_STATUS.includes(tableData.status)) {
          projectStatus = 'In Progress'
        } else if (tableData.status === Number(constant.STATUS.CLOSED)) {
          projectStatus = 'Closed'
        } else if (tableData.status === Number(constant.STATUS.NEW)) {
          projectStatus = 'New'
        } else if (tableData.status === Number(constant.STATUS.ON_HOLD)) {
          projectStatus = 'On Hold'
        }
        let components = ''
        const componetArray = JSON.parse(tableData.project_components)

        if (componetArray && componetArray !== null) {
          componetArray.map((item) => {
            components =
              components !== '' ? components + ', ' + item : components + item
          })
        }
        let links = ''
        const linkArray = JSON.parse(tableData.project_documents_link)

        if (linkArray && linkArray !== null) {
          linkArray.map((item) => {
            links = links !== '' ? links + ', ' + item.link : links + item.link
          })
        }
        const closureObject = tableData.project_closure_details
        let estimate_close_by = null
        let estimate_close_date = null

        if (
          closureObject &&
          closureObject.project_close_by &&
          closureObject.updated_at &&
          tableData.status === 13
        ) {
          estimate_close_by = closureObject.project_close_by.display_name
          estimate_close_date = closureObject.updated_at
        }

        const rowData = {
          project_name: tableData.project_name,
          billing_type: tableData.billing_type.name,
          account_manager: accountManagers,
          project_manager: projectManagers,
          status: projectStatus,
          approved_hours: tableData.approved_hours,
          client_name: clientNames,
          client_email: clientEmails,
          state: tableData.state,
          country: tableData.country,
          company_address: tableData.company_address,
          company_name: tableData.company_name,
          estimated_timeline_from: tableData.estimated_timeline_from,
          estimated_timeline_to: tableData.estimated_timeline_to,
          initiation_date: tableData.initiation_date,
          initiated_by: tableData.initiated_by.display_name,
          close_by: estimate_close_by,
          estimated_closed_date: estimate_close_date,
          maximum_hours_billed: tableData.maximum_hours_billed,
          project_components: components,
          project_documents_link: links,
          project_domains: projectDomain,
          project_summary: tableData.project_summary,
          specific_requests: tableData.specific_requests,
          technologies: tech,
          lifecycle_model: tableData.lifecycle_model,
          project_type: tableData.project_type,
          governance_category: tableData.governance_category,
          sub_project_name: tableData.sub_project_name,
          wsr_status: tableData.wsr_status.name,
          billing_interval:
            tableData.billing_interval !== null &&
            tableData.billing_interval === 0
              ? 'Weekly'
              : 'Monthly'
        }

        if (this.projectType.type_id && this.projectType.type_id.length >= 1) {
          if (constant.BILLABLE_ID.includes(tableData.billing_type.id)) {
            delete rowData.maximum_hours_billed
          } else {
            delete rowData.approved_hours
            delete rowData.client_name
            delete rowData.client_email
            delete rowData.state
            delete rowData.country
            delete rowData.company_address
            delete rowData.company_name
          }
        }
        dataForExcel.push(rowData)
      })

      const excelParams = {
        sheetData: [dataForExcel],
        headers: [
          [
            'project_name',
            'billing_type',
            'account_manager',
            'project_manager',
            'status'
          ]
        ],
        sheetName: ['Project-Details'],
        fileName: 'project-details.xls'
      }

      excelSheet.createExcelSheet(excelParams)
    },
    async downloadCalendarReport() {
      // this.loadingCalendarBtn = true
      const projectIds = []

      this.projectListData.forEach((item) => projectIds.push(item.uuid))
      await this.fetchResourceCalendarReport(projectIds)
      const countHeader = ['Count']
      const dates = this.resourceCalendarReport.header
      const calendarSheetData = this.resourceCalendarReport.data
      const calendarSheetHeader = [
        'S_No',
        'EMP ID',
        'Resource Name',
        'Project Name',
        'Business Unit'
      ]

      if (calendarSheetData) {
        calendarSheetHeader.push(...dates)
        calendarSheetHeader.push(...countHeader)
      }
      const excelParams = {
        sheetData: [calendarSheetData],
        headers: [calendarSheetHeader],
        sheetName: ['Resource Calendar'],
        fileName: 'calendar-report.xls'
      }

      excelSheet.createExcelSheet(excelParams)
      // this.loadingCalendarBtn = false
    },
    async downloadExcelReport() {
      this.loading = true
      await this.fetchProjectReport()
      const matchedProjects = []
      const unmatchedProjects = []
      const matchedManagers = []
      const unmatchedManagers = []
      const matchedResources = []
      const unmatchedResources = []
      const {
        projectNameMismatch,
        projectManagersMismatch,
        overViewResourceMismatch
      } = this.projectReport
      let projectMatchedHeader = []
      let projectUnmatchedHeader = []
      let managerMatchedHeader = []
      let managerUnmatchedHeader = []
      let resourceMatchedHeader = []
      let resourceUnmatchedHeader = []

      if (projectNameMismatch) {
        let countMatached = 0
        let countUnmatached = 0

        projectUnmatchedHeader = [
          's_no',
          'pmo_project_name',
          'redmine_project_name'
        ]
        projectMatchedHeader = [
          's_no',
          'pmo_project_name',
          'redmine_project_name'
        ]
        projectNameMismatch.forEach((value) => {
          const checkReport = value.isMatched

          if (checkReport) {
            ++countMatached
            matchedProjects.push({
              s_no: countMatached,
              pmo_project_name: value.pmoProjectName,
              redmine_project_name: value.redmineProjectName
            })
          } else {
            ++countUnmatached
            unmatchedProjects.push({
              s_no: countUnmatached,
              pmo_project_name: value.pmoProjectName,
              redmine_project_name: value.redmineProjectName
            })
          }
        })
      }

      if (projectManagersMismatch) {
        let countMatached = 0
        let countUnmatached = 0

        managerMatchedHeader = [
          's_no',
          'project_name',
          'pmo_account_manager',
          'pmo_project_manager',
          'redmine_account_manager',
          'redmine_project_manager'
        ]
        managerUnmatchedHeader = [
          's_no',
          'project_name',
          'pmo_account_manager',
          'pmo_project_manager',
          'redmine_account_manager',
          'redmine_project_manager'
        ]

        Object.entries(projectManagersMismatch).forEach(([key, value]) => {
          if (value) {
            const checkAM = value.amMatched
            const checkPM = value.pmMatched

            if (checkAM && checkPM) {
              ++countMatached
              matchedManagers.push({
                s_no: countMatached,
                project_name: key,
                pmo_account_manager: value.pmoAM,
                pmo_project_manager: value.pmoPM,
                redmine_account_manager: value.redmineAM,
                redmine_project_manager: value.redminePM
              })
            } else {
              ++countUnmatached
              unmatchedManagers.push({
                s_no: countUnmatached,
                project_name: key,
                pmo_account_manager: value.pmoAM,
                pmo_project_manager: value.pmoPM,
                redmine_account_manager: value.redmineAM,
                redmine_project_manager: value.redminePM
              })
            }
          }
        })
      }
      if (overViewResourceMismatch) {
        let countMatached = 0
        let countUnmatached = 0

        resourceMatchedHeader = [
          's_no',
          'project_name',
          'resource_name',
          'department_name',
          'email_id',
          'employee_id',
          'pmo_role',
          'pmo_start_date',
          'pmo_end_start',
          'pmo_efforts',
          'redmine_role',
          'redmine_start_date',
          'redmine_end_start',
          'redmine_efforts'
        ]
        resourceUnmatchedHeader = [
          's_no',
          'project_name',
          'resource_name',
          'department_name',
          'email_id',
          'employee_id',
          'pmo_role',
          'pmo_start_date',
          'pmo_end_start',
          'pmo_efforts',
          'redmine_role',
          'redmine_start_date',
          'redmine_end_start',
          'redmine_efforts'
        ]
        Object.entries(overViewResourceMismatch).forEach(
          ([outterKey, values]) => {
            Object.entries(values).forEach(([innerKey, records]) => {
              records.map((item) => {
                const checkRoleMatched = item.roleMatched
                const checkEntryMatched = item.entryMatched

                if (checkRoleMatched && checkEntryMatched) {
                  ++countMatached
                  matchedResources.push({
                    s_no: countMatached,
                    project_name: outterKey,
                    resource_name: innerKey,
                    department_name: item.dept,
                    email_id: item.email,
                    employee_id: item.employeeId,
                    pmo_role: item.pmoRole,
                    pmo_start_date: item.pmoStartDate,
                    pmo_end_start: item.pmoEndDate,
                    pmo_efforts: item.pmoDailyEfforts,
                    redmine_role: item.redmineRole,
                    redmine_start_date: item.redmineStartDate,
                    redmine_end_start: item.redmineEndDate,
                    redmine_efforts: item.redmineDailyEfforts
                  })
                } else {
                  ++countUnmatached
                  unmatchedResources.push({
                    s_no: countUnmatached,
                    project_name: outterKey,
                    resource_name: innerKey,
                    department_name: item.dept,
                    email_id: item.email,
                    employee_id: item.employeeId,
                    pmo_role: item.pmoRole,
                    pmo_start_date: item.pmoStartDate,
                    pmo_end_start: item.pmoEndDate,
                    pmo_efforts: item.pmoDailyEfforts,
                    redmine_role: item.redmineRole,
                    redmine_start_date: item.redmineStartDate,
                    redmine_end_start: item.redmineEndDate,
                    redmine_efforts: item.redmineDailyEfforts
                  })
                }
              })
            })
          }
        )
      }
      const excelParams = {
        sheetData: [
          matchedProjects,
          unmatchedProjects,
          matchedManagers,
          unmatchedManagers,
          matchedResources,
          unmatchedResources
        ],
        headers: [
          projectMatchedHeader,
          projectUnmatchedHeader,
          managerMatchedHeader,
          managerUnmatchedHeader,
          resourceMatchedHeader,
          resourceUnmatchedHeader
        ],
        sheetName: [
          'Matched Project Name',
          'Unmatched Project Name',
          'Matched AMPM',
          'Unmatched AMPM',
          'Matched Resources',
          'Unmatched Resources'
        ],
        fileName: 'analysis-report.xls'
      }

      excelSheet.createExcelSheet(excelParams)
      this.loading = false
    }
  }
}
</script>

<style scoped>
.load-more-style {
  left: "50%";
  transform: "translateX(-50%)";
  bottom: "-0.1%";
}
.v-data-table td,
.v-data-table th {
  padding: 0 20px !important;
  font-size: 14px;
}
.v-application .headline {
  font-size: small !important;
}
.v-application .actionPending {
  text-align: center !important;
  display: inline !important;
  padding-left: 20px;
  padding-right: 20px;
}
.v-application .dialogHeadline {
  font-size: 20px !important;
}
.v-btn.v-size--x-small {
  font-size: smaller;
}
.v-btn.v-size--default {
  font-size: small;
}
.v-chip.v-size--default {
  font-size: smaller;
  height: auto;
}
.v-chip {
  line-height: normal !important;
}
>>> .v-data-table-header {
  box-shadow: 0px 3px 1px -2px rgba(0, 0, 0, 0.2),
    0px 2px 2px 0px rgba(0, 0, 0, 0.14), 0px 1px 5px 0px rgba(0, 0, 0, 0.12);
  color: white;
  border-radius: inherit;
}
.v-application {
  font-family: "Roboto", sans-serif;
  line-height: normal;
}
>>> .v-label {
  font-size: 14px;
}
.v-application .noData {
  font-size: 14px;
}
.title-style {
  width: auto;
  height: auto;
  background: #f2f5f8;
  color: rgba(0, 0, 0, 0.87);
  opacity: 0.72;
  padding-top: 56px;
}
>>> .v-data-table-header {
  box-shadow: none !important;
  color: white;
  border-radius: inherit;
}
.heading-style {
  color: #707070;
  font-family: "ProductSans";
  font-size: 30px;
  font-weight: 700;
  font-style: normal;
  letter-spacing: 1.7px;
  line-height: normal;
  text-align: left;
  font-style: normal;
  letter-spacing: normal;
  line-height: normal;
}
.drop-down-style {
  width: 200px;
  height: 40px;
  background-color: #f6f7f9;
  opacity: 0.4;
}
>>> .theme--light.v-sheet--outlined {
  /* border: thin solid rgba(0, 0, 0, 0.05); */
}

>>> .v-sheet.v-card {
  border-radius: 0px;
}
.theme--light.v-card {
  background-color: rgb(242 245 248) !important;
}
.theme--light.v-list {
  background: #fff !important;
}
.v-responsive {
  display: inline-flex;
}
.v-snack.projectDashboardListView {
  height: auto;
  position: static;
  padding-top: 0px !important;
}

.projectDashboradrH {
  color: #707070;
  font-family: "Product Sans";
  font-size: 34px;
  font-weight: 700;
  text-align: left;
  font-style: normal;
  letter-spacing: normal;
  line-height: normal;
}

.theme--light.v-input.DownloadReportBtn {
  width: 200px;
  border-radius: 19px;
  color: #607d8b;
  font-family: "ProductSans";
  font-size: 14px;
  font-weight: 400;
  font-style: normal;
  letter-spacing: normal;
  line-height: normal;
  border: 0;
  margin: -7px 0 0 auto;
}

.theme--light.v-input.DownloadReportBtn .v-input__slot fieldset {
  border: 0;
  box-shadow: 0 3px 8px rgba(0, 0, 0, 0.08);
  background: #f6f7f9;
}

.v-menu__content {
  background: #fff;
}

span.v-chip--select.v-chip.v-chip--clickable {
  background: #eaeaea;
  margin: 7px 0 0;
}
span.viewOptn {
  width: 60px;
  display: inline-block;
  text-align: center;
  vertical-align: middle;
  cursor: pointer;
}

span.viewOptn .v-image.v-responsive.theme--light {
  display: inline-block;
}

.v-input.filtersFields {
  width: 95%;
  color: #607d8b;
  font-size: 16px;
  font-weight: 400;
  text-align: left;
  font-style: normal;
  letter-spacing: normal;
  line-height: normal;
  border-radius: 8px;
}

.projectDtopBar {
  background-color: rgb(246 247 249 / 42%);
  padding: 50px 0 30px;
}
.v-image.v-responsive.quickAct.theme--light,
.v-image.v-responsive.wsrIconImg.theme--light {
  display: inline-block;
  cursor: pointer;
  margin: 0 6px;
  width: 24px;
}
.v-list.projectCardCat.projectCardCatLeft .projectCardCatInner {
  padding-left: 0;
}

.v-list.projectCardCat.projectCardCatLeft .projectCardCatInner .quickAct {
  margin: 0;
  width: 26px;
}
.v-data-table {
  border-radius: 16px;
}
.v-data-table.projectDataWrp.v-data-table--has-top.theme--light th {
  /* Style for "Project St" */
  color: rgb(112 112 112 / 65%);
  font-size: 18px;
  font-weight: 400;
  text-align: center;
  font-style: normal;
  letter-spacing: normal;
  line-height: normal;
}
.projectDataWrp .v-btn--icon.v-size--x-small .v-icon,
.projectDataWrp .v-btn--fab.v-size--x-small .v-icon {
  width: 10px;
}
.v-image.v-responsive.quickAct.theme--light div,
.v-image.v-responsive.wsrIconImg.theme--light div {
  background-size: auto !important;
}

.v-image.v-responsive.wsrIconImg.theme--light
  .v-image__image.v-image__image--cover {
  background-size: auto;
}

button.wsrIconBtn.v-btn.v-btn--is-elevated.v-btn--has-bg.theme--light.v-size--default {
  background: transparent;
  box-shadow: none;
  width: 24px;
  height: 24px;
  min-width: 24px;
  padding: 0;
  margin-top: -15px;
}

.row.mainWrp {
  margin-top: 0;
}
/* Card View */

.v-image.v-responsive.quickAct.theme--light {
  display: inline-block;
  padding: 6px 6px;
  cursor: pointer;
  margin: 0 2px;
}

.v-image.v-responsive.wsrIconImg.theme--light {
  display: inline-block;
  padding: 6px 6px;
  cursor: pointer;
  margin: 0 2px;
}

.v-image.v-responsive.quickAct.theme--light
  .v-image__image.v-image__image--cover {
  background-size: auto;
}

.v-data-table.projectDataWrp.v-data-table--has-top.theme--light th {
  /* Style for "Project St" */
  color: rgb(112 112 112 / 65%);
  font-family: "Open Sans";
  font-size: 18px;
  font-weight: 400;
  text-align: center;
  /* Text style for "Project St" */
  font-style: normal;
  letter-spacing: normal;
  line-height: normal;
}

.gridWrp {
  background: #fff;
  border-radius: 14px;
}

.cardVIewWrp {
  padding: 50px 30px 0;
}

.projectCard.v-card.v-sheet.theme--light {
  /* Style for "Rectangle" */
  box-shadow: 0 3px 6px rgba(108, 99, 255, 0.16);
  border-radius: 10px;
  padding-bottom: 20px;
}

.v-list.projectCardH .v-list-item__title h4 {
  color: #6f6f6f;
  font-family: "Open Sans";
  font-size: 22px;
  font-weight: 700;
  text-align: left;
  font-style: normal;
  letter-spacing: normal;
  line-height: normal;
  overflow: hidden;
  word-break: normal;
  white-space: nowrap;
  text-overflow: ellipsis;
}

.v-list.projectCardH .v-list-item__subtitle {
  /* Style for "Action Req" */
  color: #ff5858;
  font-family: "Open Sans";
  font-size: 14px;
  font-weight: 600;
  text-align: left;
  /* Text style for "Action Req" */
  font-style: normal;
  letter-spacing: normal;
  line-height: normal;
}

.projectCard hr.v-divider.theme--light {
  border-bottom: 1px solid rgb(112 112 112 / 23%);
}

.row.cardRowWrp {
  padding: 20px 0 0;
  justify-content: space-around;
  flex: auto;
  flex-wrap: nowrap;
}

.projectCardCatInner .v-list-item__title {
  /* Style for "Project Ty" */
  color: rgb(112 112 112 / 55%);
  font-size: 18px;
  font-weight: 400;
  text-align: left;
  /* Text style for "Project Ty" */
  font-style: normal;
  letter-spacing: normal;
  line-height: normal;
}

.projectCardCatInner .v-list-item__subtitle > span {
  /* Style for "Billable" */
  color: #1976d2;
  font-size: 22px;
  text-align: left;
  font-weight: 600;
  font-style: normal;
  letter-spacing: normal;
  line-height: normal;
}

.projectCardCatInner span.pmName {
  margin-right: 7px;
}

.v-card__actions.projectCardCatAct {
  display: block;
  padding: 0;
  width: 100%;
}

.v-card__actions.projectCardCatAct .v-text-field__details {
  margin: 0;
}

.projectCardCatAct .v-input__control {
  display: block !important;
}

.projectCard.v-card.v-sheet.theme--light {
  background: #fbfcfd !important;
}

.projectCard.v-card.v-sheet .projectCardH.theme--light {
  background: #fbfcfd !important;
}

.row.cardRowWrp .projectCardCat.theme--light {
  background: #fbfcfd !important;
}

button.v-btn.v-btn--icon.redIcon {
  color: #f44336;
  padding: 3px;
  height: auto;
  width: auto;
  vertical-align: super;
}

button.greenIcon.theme--light.v-btn.v-btn--icon {
  color: #66bb6a;
  padding: 3px;
  height: auto;
  width: auto;
  vertical-align: super;
}

@media (max-width: 1600px) {
  .resourceSummry {
    min-height: 268px;
  }
}
@media (max-width: 1440px) {
  .cardWrp {
    min-height: 260px;
  }
  .addProjectCWrp {
    min-height: 260px;
  }
  .resourceUtilizationWrp {
    min-height: 260px;
  }
  .resourceSummry {
    min-height: 260px;
  }
}

>>> @media(max-width: 1366px) {
  .cardWrp {
    min-height: 250px;
  }
  .addProjectCWrp {
    min-height: 250px;
  }
  .resourceUtilizationWrp {
    min-height: 250px;
  }
  .resourceSummry {
    min-height: 250px;
  }

  .dashboardHeading.col-md-12.col-12 {
    padding-top: 10px;
    padding-bottom: 10px;
  }

  .dashboardHeading h1 {
    font-size: 30px;
  }
  .cardLeftcol h3 {
    font-size: 20px;
  }
  .addProjectTitle h3 {
    font-size: 20px;
  }
  .resourceUtilizationWrp h3[data-v-958416e2] {
    font-size: 20px;
  }
  .v-card__title.resourceSummaryH h3 {
    font-size: 20px;
  }
}
</style>
