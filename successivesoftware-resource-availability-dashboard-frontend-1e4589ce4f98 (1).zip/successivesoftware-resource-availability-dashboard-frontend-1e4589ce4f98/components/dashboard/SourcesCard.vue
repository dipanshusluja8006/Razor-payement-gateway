<template>
  <div class="gnrtGraph">
    <div v-if="loading" class="d-flex flex-grow-1 align-center justify-center">
      <v-progress-circular indeterminate color="primary" />
    </div>

    <div v-else class="d-flex flex-column flex-grow-1">
      <div v-if="label" class="graphTitle">
        <h4>{{ label }}</h4>
      </div>
      <div class="chart-wrap">
        <apexchart
          :options="chartOptions"
          :series="series"
          :width="pieWidth"
          :type="type"
          :percentage="percentage"
        />
      </div>
    </div>
  </div>
</template>

<script>
/*
|---------------------------------------------------------------------
| Apex Charts Component
|---------------------------------------------------------------------
|
| Demo card component to be used to gather some ideas on how to build
| your own dashboard component
|
*/

export default {
  props: {
    series: {
      type: Array,
      default: () => ([])
    },
    type: {
      type: String,
      default: 'donut'
    },
    label: {
      type: String,
      default: ''
    },
    innerLable: {
      type: String,
      default: ''
    },
    legendPosition: {
      type: String,
      default: ''
    },
    color: {
      type: String,
      default: '#333333'
    },
    value: {
      type: Number,
      default: 0
    },
    offset: {
      type: Number,
      default: 0
    },
    pieWidth: {
      type: String,
      default: '85%'
    },
    percentage: {
      type: Number,
      default: 0
    },
    percentageLabel: {
      type: String,
      default: 'vs. last week'
    },
    options: {
      type: Object,
      default: () => ({})
    },
    loading: {
      type: Boolean,
      default: false
    },
    showLabels: {
      type: Boolean,
      default: false
    },
    showLegend: {
      type: Boolean,
      default: true
    },
    labelArray: {
      type: Array,
      default: () => ([])
    },
    colorArray: {
      type: Array,
      default: () => ([])
    },
    fillArray: {
      type: Object,
      default: () => ({})
    }
  },
  data () {
    return {
      selectedInterval: 'Last 7 days',
      intervals: [
        'Last 7 days',
        'Last 28 days',
        'Last month',
        'Last year'
      ]
    }
  },
  computed: {
    chartOptions () {
      return {
        chart: {
          type: this.type,
          animations: {
            speed: 400
          },
          background: 'transparent'
        },
        stroke: {
          show: true,
          colors: [this.$vuetify.theme.isDark ? '#333' : '#fff'],
          width: 1,
          dashArray: 0
        },
        plotOptions: {
          pie: {
            startAngle: 0,
            expandOnClick: false,
            offsetX: 0,
            offsetY: 0,
            customScale: 1,
            donut: {
              size: '80%',
              background: 'transparent',
              labels: {
                show: this.showLabels,
                name: {
                  show: false,
                  fontSize: '12px',
                  color: undefined,
                  offsetY: -20,
                  formatter (val) {
                    return val
                  }
                },
                value: {
                  show: false,
                  fontSize: '12px',
                  color: undefined,
                  offsetY: 20,
                  formatter (val) {
                    return val
                  }
                }
              }
            }
          },
          radialBar: {
            dataLabels: {
              name: {
                fontSize: '22px'
              },
              value: {
                fontSize: '16px'
              },
              total: {
                show: true,
                label: this.innerLable,
                fontSize: '12px',
                value: this.percentage,
                formatter: function (w) {
                  return `${w.globals.series[0]}%` + ' (' + this.value + ')'                }
              }
            }
          }
        },
        theme: {
          mode: this.$vuetify.theme.isDark ? 'dark' : 'light'
        },
        labels: this.labelArray,
        dataLabels: {
          enabled: false
        },
        colors: this.colorArray,
        fill: this.fillArray,
        legend: {
          show: this.showLegend,
          offsetY: this.offset,
          fontSize: '11px',
          position: this.legendPosition,
          formatter: function(seriesName, opts) {
            return [seriesName, `- ${opts.w.globals.series[opts.seriesIndex]} `]
          }
        },
        responsive: [{
          breakpoint: 480,
          options: {
            chart: {
              width: 200
            },
            legend: {
              offsetY: 0,
              position: 'bottom'
            }
          }
        }],
        ...this.options
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.chart-wrap {
  min-width: 380px;
}
#projectDashboard .resourceUtilizationWrp .gnrtGraph .apexcharts-legend.apexcharts-align-center.position-right {
    top: 0 !important;
}
</style>
