<template>
  <v-dialog
    v-model="getCustomDialog.status"
    :persistent="true"
  >
    <div class="successPopup">

      <div v-if="getCustomDialog.title === 'Error'" class="successImg">
        <v-img :src="ErrorImg" contain />
      </div>
      <div v-else class="successImg">
        <v-img :src="SuccessImg" contain />
      </div>
      <div class="successText">
        <v-card-text align="center">
          {{ getCustomDialog.message }}
        </v-card-text>
        <v-card-actions>
          <v-btn
            color="primary"
            class="succesBtn"
            @click="updateStatus"
          >
            Okay
          </v-btn>
        </v-card-actions>
      </div>
    </div>
  </v-dialog>
</template>

<script>
import { mapActions, mapGetters } from 'vuex'
import constant from '@/constants/closure-checklist.js'
export default {
  name: 'CustomDialog',
  props: {
    customTitle: {
      type: String,
      default: 'Success'
    },
    customText: {
      type: String,
      default: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'
    }
  },
  data () {
    return {
      dialog: false,
      overlay: false,
      constant
    }
  },
  computed: { 
    ...mapGetters({
      getCustomDialog: 'project/getCustomDialog'
    }),
    SuccessImg () {
      return require('@/assets/images/custom/SuccessDialog.png')
    },
    ErrorImg () {
      return require('@/assets/images/custom/ErrorDialog.png')
    }
  },

  methods: {
    ...mapActions({
      setCustomDialog: 'project/setCustomDialog'
    }),
    updateStatus () {
      const cDialog = Object.assign({}, this.getCustomDialog)

      this.setCustomDialog(
        {
          status: false,
          title: '',
          message: '',
          nextRoute: '',
          sameRoute: false
        }
      )
      if (cDialog.nextRoute) {
        this.$router.push(cDialog.nextRoute)
      }
      if (cDialog.sameRoute === true) {
        this.overlay = true
        window.location.reload(true)
        this.overlay = false
      }
    }
  }
}
</script>

<style scoped>
.iconcenter{padding-top: 30px!important}
.marginauto{margin: 0 auto}
.mdi-48px { font-size: 48px; }
</style>
