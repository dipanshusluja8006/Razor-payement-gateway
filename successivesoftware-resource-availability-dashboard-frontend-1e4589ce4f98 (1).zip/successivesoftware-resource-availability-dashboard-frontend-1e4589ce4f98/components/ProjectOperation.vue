<template>
  <div class="orojectOpFormWrp">
    <project-restart :input-dialog="inputDialog" :project-id="selectedProjectName" :project-details="projectDetails" />
    <v-row align="center">
      <v-col class="text-left" cols="12">
        <h3 class="">Project Operations</h3>
      </v-col>
    </v-row>
    <v-row>
      <v-col cols="12" md="3" class="pt-0 pb-0">
        <label>Project Name</label>
        <v-autocomplete
          v-model="selectedProjectName"
          :items="projectDetails"
          hide-details
          item-text="project_name"
          item-value="uuid"
          dense
          placeholder="Select Project Name"
          @change="fetchProjectEligibleAction(selectedProjectName)"
        />
      </v-col>
      <v-col cols="12" md="3" class="pt-0 pb-0">
        <label>Project Operation</label>
        <v-autocomplete
          v-model="projectActionSelected"
          :items="userActions"
          hide-details
          item-text="name"
          item-value="code"
          placeholder="Project Configuration"
          dense
          return-object
        />
      </v-col>
      <v-col cols="12" md="2" class="pt-0 pb-0">
        <v-btn
          class="goBtn"
          medium
          @click="performAction(projectActionSelected, selectedProjectName)"
        >
          <v-icon color="white">mdi-arrow-right</v-icon>
        </v-btn>
      </v-col>
    </v-row>
  </div>
</template>

<script>
import { mapActions, mapGetters } from 'vuex'
import constant from '../constants/closure-checklist'
import projectRestart from './projectRestart'
export default {
  name: 'ProjectOperation',
  components: { projectRestart },
  props: {
    projectDetails: {
      type: Array,
      default: () => ([])
    },
    selectedProjectName: {
      type: String,
      default: ''
    },
    projectActionSelected: {
      type: String,
      default: ''
    }
  },
  data () {
    return {
      projectNames: [],
      userActions: [],
      inputDialog: false
    }
  },
  computed: {
    ...mapGetters({
      getProjectSpecificAction: 'project/getProjectSpecificAction',
      technologies: 'project/getTechnologies',
      getDepartments: 'project/getDepartments',
      billingTypes: 'project/getBillingTypes',
      users: 'project/getUserList',
      projectTypes: 'project/getProjectType',
      availableRoles: 'roles/availableRoles'
    })
  },
  async fetch ({ store }) {
    // eslint-disable-next-line no-useless-catch
    try {
      await store.dispatch('project/fetchKedbProjectList')
    } catch (error) {
      throw (error)
    }
  },
  created () {
    this.fetchLists()
  },
  mounted () {
    // this.fetchLists()
    this.inputDialog = false
    this.getPreSelectedProjectAction()
  },
  methods: {
    ...mapActions({
      fetchProjectList: 'project/fetchProjectList',
      fetchProjectSpecificAction: 'project/fetchProjectSpecificAction',
      fetchTechnologies: 'project/fetchTechnologies',
      fetchProjectType: 'project/fetchProjectType',
      fetchGovernanceCategories: 'project/fetchGovernanceCategories',
      fetchUserList: 'project/fetchUserList',
      fetchDepartments: 'project/fetchDepartments',
      fetchProjectNames: 'project/fetchProjectNames',
      fetchAllRoles: 'roles/fetchAllRoles',
      fetchBillingTypes: 'project/fetchBillingTypes'
    }),
    fetchLists () {
      if (this.technologies.length <= 1) {
        this.fetchTechnologies()
      }
      if (this.users.length <= 1) {
        this.fetchUserList()
      }
      if (this.getDepartments.length === 0) {
        this.fetchDepartments()
      }
      if (this.billingTypes.length === 0) {
        this.fetchBillingTypes()
      }
      if (this.projectTypes.length === 0) {
        this.fetchProjectType()
      }
      if (this.availableRoles.length === 0) {
        this.fetchAllRoles()
      }
    },
    async fetchProjectEligibleAction (projectID) {
      this.projectActionSelected = ''
      await this.fetchProjectSpecificAction(projectID)
      this.userActions = this.getProjectSpecificAction.user_performed_action.filter((value) => value.status === constant.ACTION_STATUS.AVAILABLE)
    },
    async getPreSelectedProjectAction () {
      if (this.selectedProjectName) {
        await this.fetchProjectSpecificAction(this.selectedProjectName)
        this.userActions = this.getProjectSpecificAction.user_performed_action.filter((value) => value.status === constant.ACTION_STATUS.AVAILABLE)
      }
    },
    performAction (action, projectId) {
      if (action.code === constant.USER_ACTION_CODE.RESTART) {
        this.inputDialog = true

        return this.inputDialog
      }
      if (action.status === constant.ACTION_STATUS.AVAILABLE) {
        this.$router.push(`/project/${projectId}/${action.code}`)
      }
    }
  }
}
</script>

<style scoped>
.v-sheet.v-card:not(.v-sheet--outlined) {
  box-shadow: none !important;
}
.btn-color {
    background-color: #1976d2!important;
    color: #ffffff!important;
}
.v-data-table__wrapper::-webkit-scrollbar{
  height: 6px;
  background-color: #143861;
}
</style>
