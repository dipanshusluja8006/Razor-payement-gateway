<template>
  <div>
    <common-snackbar :snackbar="snackbarValue" :text-for-snackbar="snackbarText" />
    <Dialog />
    <ValidationObserver ref="deallocateObserver" v-slot="{ valid }">
      <template v-if="allDeallocationSelected">
        <div class="bulkSelection">
          <div class="bulkSelectionInner">
            <v-row>
              <v-col cols="2">
                <h3>Bulk <br>Action</h3>
              </v-col>
              <v-col cols="5">
                <div class="Fieldlable">
                  <label>Deallocate for</label>
                </div>
                <div class="slotHeight">
                  <v-select
                    v-model="deallocationBulkEfforts"
                    :items="numberList"
                    dense
                    outlined
                    placeholder="Select Hours"
                    @change="updateAllEfforts(deallocationBulkEfforts)"
                  />
                </div>
              </v-col>
              <v-col cols="5">
                <div class="Fieldlable">
                  <label>Deallocate From Date</label>
                </div>
                <div class="slotHeight">
                  <v-menu
                    v-model="commonDeallocateFromMenu"
                    :close-on-content-click="false"
                  >
                    <template v-slot:activator="{ on, attrs }">
                      <v-text-field
                        :value="(commonDeallocateFrom) ? new Date(commonDeallocateFrom).toLocaleDateString('en-US', {
                          year: 'numeric',
                          month: 'short',
                          day: 'numeric'
                        }) : ''"
                        v-bind="attrs"
                        solo
                        dense
                        readonly
                        placeholder="Choose Date"
                        v-on="on"
                      >
                        <template v-slot:prepend-inner>
                          <v-icon v-bind="attrs" v-on="on">
                            mdi-calendar
                          </v-icon>
                        </template>
                      </v-text-field>
                    </template>
                    <v-date-picker v-model="commonDeallocateFrom" @change="updateCommonDate($event, 'deallocate_from')" @input="commonDeallocateFromMenu = false" />
                  </v-menu>
                </div>
              </v-col>
            </v-row>
          </div>
        </div>
      </template>
      <div class="requisitionTableWrp extandTable">
        <v-data-table
          v-model="deallocationSelected"
          :single-select="singleSelect"
          :headers="headersForAllocationTable"
          :items="allocationTableData"
          :hide-default-footer="allocationTableData.length ? false : true"
          :items-per-page="deallocationItemsPerPage"
          :sort-by.sync="sortBy"
          :footer-props="{ itemsPerPageOptions: rowsPerPage }"
          :sort-desc.sync="sortDesc"
          item-key="meta_id"
          show-select
          must-sort
          class="elevation-1"
          @toggle-select-all="selectDeallocationWholeList($event)"
          @pagination="handlePagechange"
        >
          <template v-slot:item.resource_name="{item}">
            <div class="pa-2">
              <div v-if="item.expireFlag">
                <span class="red--text mb-3"> {{ item.expireDays }} </span><br/>
              </div>
              <div v-else>
                <span class="green--text mb-3"> {{ item.expireDays }} </span><br/>
              </div>
              <span> {{ item.resource_name }} </span>
              <br/><span></span><span> {{ item.dept }} </span>
              <br/><span class="blue--text mb-3"> {{ item.billing_type }} </span>
            </div>
          </template>
          <template v-slot:item.tech="{item}">
            <div class="pa-2">
              <span> {{ item.tech }} </span>
              <br/><span></span><span> {{ item.designation }} </span>
            </div>
          </template>

          <template v-slot:item.deallocate_hrs="{item}">

            <div v-if="item.deallocate" class="incDecCountWrp">
              <div class="incCount">
                <v-btn
                  depressed
                  small
                  @click="item.deallocate_hrs = incrementHours(item.deallocate_hrs)"
                ><v-icon dark>mdi-plus</v-icon></v-btn>
              </div>
              <div class="inputField">
                <ValidationProvider
                  v-slot="{ errors }"
                  :rules="`required|check_efforts`"
                  :name="item.deallocate_hrs"
                  class="error_msg"
                >
                  <v-text-field
                    v-model.trim="item.deallocate_hrs"
                    :error-messages="errors"
                    type="number"
                    @keyup="checkEffortsValidation($event, item)"
                  />
                </ValidationProvider>
              </div>
              <div class="decCount">
                <v-btn
                  depressed
                  small
                  @click="item.deallocate_hrs = decrementHours(item.deallocate_hrs)"
                ><v-icon dark>mdi-minus</v-icon></v-btn>
              </div>
            </div>

            <div v-else class="incDecCountWrp">
              <div class="incCount">
                <v-btn depressed small><v-icon dark>mdi-plus</v-icon></v-btn>
              </div>
              <div class="inputField">
                <ValidationProvider
                  :rules="`required|check_efforts`"
                  :name="item.deallocate_hrs"
                >
                  <v-text-field
                    v-model.trim="item.deallocate_hrs"
                    disabled
                  />
                </ValidationProvider>
              </div>
              <div class="decCount">
                <v-btn depressed small><v-icon dark>mdi-minus</v-icon></v-btn>
              </div>
            </div>

          </template>

          <template v-slot:item.date_duration="{item}">
            {{ new Date(item.start_date).toLocaleDateString('en-US', {
              year: 'numeric',
              month: 'short',
              day: 'numeric'
            })
            }} - {{ new Date(item.end_date).toLocaleDateString('en-US', {
              year: 'numeric',
              month: 'short',
              day: 'numeric'
            })
            }}
          </template>
          <template v-slot:item.deallocate_from="{item, attrs}">
            <div class="deallocationTblDatep">
              <v-menu
                ref="item.newDate"
                v-model="item.newDate"
                :close-on-content-click="false"
              >
                <template v-slot:activator="{ on }">
                  <v-text-field
                    :value="(item.deallocate_from) ? new Date(item.deallocate_from).toLocaleDateString('en-US', {
                      year: 'numeric',
                      month: 'short',
                      day: 'numeric'
                    }) : ''"
                    :disabled="!item.deallocate"
                    v-bind="attrs"
                    solo
                    dense
                    placeholder="Choose Date"
                    readonly
                    v-on="on"
                  >
                    <template v-slot:prepend-inner>
                      <v-icon :disabled="!item.deallocate" v-bind="attrs" v-on="on">
                        mdi-calendar
                      </v-icon>
                    </template>
                    <template v-slot:append-outer>
                      <v-tooltip v-if="(commonDeallocateFrom < item.start_date && item.deallocate)? true: false" top>
                        <template v-slot:activator="{ on, attrs }">
                          <span v-bind="attrs" v-on="on">
                            <v-icon color="red">mdi-alert-circle-outline</v-icon>
                          </span>
                        </template>
                        <span>The resource booking has not started till now</span>
                      </v-tooltip>
                      <v-tooltip v-else-if="item.deallocateAlert && item.deallocate" top>
                        <template v-slot:activator="{ on, attrs }">
                          <span v-bind="attrs" v-on="on">
                            <v-icon color="red">mdi-alert-circle-outline</v-icon>
                          </span>
                        </template>
                        <span>The resource cannot be deallocate</span>
                      </v-tooltip>
                    </template>
                  </v-text-field>
                </template>
                <v-col cols="12" class="pa-0">
                  <v-date-picker
                    v-model="item.deallocate_from"
                    :min="item.minDeallocateFromDate"
                    :max="item.maxDeallocateFromDate"
                    @change="changeToDateString($event, item)"
                    @input="item.newDate = false"
                  />
                </v-col>
              </v-menu>
            </div>
          </template>
        </v-data-table>
      </div>
      <div class="submitBtnWrp">
        <div v-if="!valid || deallocationSelected.length === 0 || !validationPass" class="submitDiv">
          <v-btn
            class="backBtn"
            @click="$router.push('/project-dashboard')"
          >
            <v-icon dark left>
              mdi-arrow-left
            </v-icon>Back
          </v-btn>
          <v-btn :disabled="!valid || deallocationSelected.length === 0 || !validationPass" class="submitBtn" @click="submit">
            Submit
          </v-btn>
        </div>
        <div v-else class="submitDiv" cols="12">
          <v-btn
            class="backBtn"
            @click="$router.push('/project-dashboard')"
          >
            <v-icon dark left>
              mdi-arrow-left
            </v-icon>Back
          </v-btn>
          <v-btn :disabled="submitted" class="submitBtn" @click="submit">
            Submit
          </v-btn>
        </div>
      </div>
    </ValidationObserver>
  </div>
</template>
<script>
import { mapActions, mapGetters } from 'vuex'
import CommonSnackbar from '@/components/CommonSnackbar'
import constant from '@/constants/closure-checklist.js'
import { excelSheet, projectHelpers } from '@/helpers/helper.js'

export default {
  name: 'ResourceDeAllocation',
  layout: 'authenticated',
  middleware: 'authenticated',
  components: {
    CommonSnackbar
  },
  props: {
    deallocateListData: {
      type: Array,
      default: () => ([])
    }
  },

  data () {
    return {
      // projectName: '',
      page: 1,
      pageCount: 0,
      headersForAllocationTable: [
        { text: 'Resource Details', sortable: true, value: 'resource_name', align: 'center', width: '22%' },
        { text: 'Technology/Role', value: 'tech', sortable: true, align: 'center',  width: '15%'  },
        { text: 'Efforts (In Hrs)', value: 'efforts', sortable: true, align: 'center', width: '10%' },
        { text: 'Date Duration', value: 'date_duration', sortable: false, align: 'center', width: '17%' },
        { text: 'Deallocate For (In Hours)', value: 'deallocate_hrs', sortable: false, width: '10%', align: 'center' },
        { text: 'Deallocate From (Date)', value: 'deallocate_from', sortable: false, align: 'center', width: '20%' }
      ],
      rowsPerPage: [50, 100, 200],
      sortBy: 'resource_name',
      sortDesc: false,
      numberList: [1, 2, 3, 4, 5, 6, 7, 8],
      commonExtendFrom: null,
      commonExtendTo: null,
      commonDeallocateFrom: null,
      commonDeallocateFromMenu: false,
      singleSelect: false,
      selected: [],
      deallocationSelected: [],
      allocationTableData: [],
      extensionTableData: [],
      extensionValidationPass: false,
      validationPass: false,
      itemsPerPage: 10,
      deallocationItemsPerPage: 10,
      snackbarValue: false,
      snackbarText: '',
      errorText: '',
      errorDialog: false,
      allDataRowsSelected: false,
      unSelectAllExtensionRows: false,
      unSelectAllDeallocationRows: false,
      allDeallocationDataRowsSelected: false,
      allSelected: false,
      allDeallocationSelected: false,
      currentDate: null,
      dialog: false,
      constant,
      submitted: false,
      departmentSelected: '',
      departmentList: [],
      extendBulkEfforts: '',
      deallocationBulkEfforts: '',
      selectedBulkManger: '',
      actions:['auto-deallocation', 'auto extension'],
      max: 8,
      min: 1
    }
  },
  computed: {
    ...mapGetters({
      projectDetail: 'project/getProjectDetail',
      // isButtonLoading: 'project/isButtonLoading',
      // projectList: 'project/getProjectList',
      departments: 'project/getDepartments'
      // availableRoles: 'roles/availableRoles'
      // getManageReportingDetail: 'project/getManageReportingDetail'
    })
  },
  async fetch ({ app, store, route }) {
    // eslint-disable-next-line no-useless-catch
    try {
      await store.dispatch('project/fetchProjectDetail', route.params.id)
    } catch (error) {
      throw (error)
    }
  },
  watch: {
    deallocateListData () {
      this.allocationTableData = this.deallocateListData
    },
    selected () {
      if (this.allDataRowsSelected) {
        const { selected } = this

        this.selected = selected
      } else if (this.unSelectAllExtensionRows) {
        this.selected = []
      }
      this.unSelectAllExtensionRows = false
      this.allDataRowsSelected = false
      let validationFlag = true
      const selectedRows = []

      if (this.selected.length > 1) {
        this.allSelected = true
      } else {
        this.allSelected = false
      }
      this.selected.forEach((item) => {
        if (item.deallocate_from === null || item.deallocate_to === null || item.deallocate_hrs === '') {
          validationFlag = false
        }
        selectedRows.push(item.meta_id)
      })
      this.extensionValidationPass = validationFlag
      this.extensionTableData = this.extensionTableData.map((element, index) => {
        if (selectedRows.includes(element.meta_id)) {
          element.extend = true
        } else {
          element.extend = false
        }

        return element
      })
    },
    deallocationSelected () {
      let validationFlag = true

      if (this.allDeallocationDataRowsSelected) {
        const { deallocationSelected } = this

        this.deallocationSelected = deallocationSelected
      } else if (this.unSelectAllDeallocationRows) {
        this.deallocationSelected = []
      }
      this.unSelectAllDeallocationRows = false
      this.allDeallocationDataRowsSelected = false
      const selectedRows = []

      if (this.deallocationSelected.length > 1) {
        this.allDeallocationSelected = true
      } else {
        this.allDeallocationSelected = false
      }
      this.deallocationSelected.forEach((item) => {
        if (item.deallocate_from === null || item.deallocate_hrs === '') {
          validationFlag = false
        }
        selectedRows.push(item.meta_id)
      })
      this.validationPass = validationFlag
      this.allocationTableData = this.allocationTableData.map((element, index) => {
        if (selectedRows.includes(element.meta_id)) {
          element.deallocate = true
        } else {
          element.deallocate = false
        }

        return element
      })
    }
  },
  mounted () {
    this.allocationTableData = this.deallocateListData
    let today = new Date()
    const dd = String(today.getDate()).padStart(2, '0')
    const mm = String(today.getMonth() + 1).padStart(2, '0')
    const yyyy = today.getFullYear()

    today = yyyy + '-' + mm + '-' + dd
    this.currentDate = today
    this.departments.map((item) => {
      this.departmentList.push(item.name)
    })
  },
  methods: {
    ...mapActions({
      setResourceDeAllocationData: 'project/setResourceDeAllocationData',
      setResourceExtensionData: 'project/setResourceExtensionData',
      setManageReportingData: 'project/setManageReportingData',
      setCustomDialog: 'project/setCustomDialog',
      updateLoadingAction: 'project/updateLoadingAction'
    }),
    incrementHours (value) {
      value = parseInt(value) === this.max ? this.max : parseInt(value) + 1

      return value.toString()
    },
    decrementHours (value) {
      value = parseInt(value) === this.min ? this.min : parseInt(value) - 1

      return value.toString()
    },

    changeToDateString (selectedDate, selected) {
      let validationFlag = true

      for (let i = 0; i < this.allocationTableData.length; i++) {
        if (this.allocationTableData[i].meta_id === selected.meta_id) {
          this.allocationTableData[i].deallocate_from = selectedDate
        }
      }
      this.deallocationSelected.forEach((item) => {
        if (item.deallocate_from === null || item.deallocate_hrs === '') {
          validationFlag = false
        }
      })
      this.validationPass = validationFlag
    },
    changeToExtensionDateString (selectedDate, selected, key) {
      let validationFlag = true

      for (let i = 0; i < this.extensionTableData.length; i++) {
        if (this.extensionTableData[i].meta_id === selected.meta_id) {
          if (key === 'deallocate_from') {
            this.extensionTableData[i].deallocate_from = selectedDate
          } else {
            this.extensionTableData[i].deallocate_to = selectedDate
          }
        }
      }
      this.selected.forEach((item) => {
        if (item.deallocate_from === null || item.deallocate_to === null || item.deallocate_hrs === '') {
          validationFlag = false
        }
        if (item.deallocate_to < item.deallocate_from) {
          item.deallocate_to = item.deallocate_from
        }
      })
      this.extensionValidationPass = validationFlag
    },
    /**
     * Filter for department column.
     * @param value Value to be tested.
     * @returns {boolean}
     */
    departmenetFilter (value) {
      if (!this.departmentSelected || !value) {
        return true
      }
      value = value.toString()
      if (this.departmentSelected.length && this.departmentSelected === value) {
        return true
      }
      if (this.departmentSelected.length < 1) {
        return true
      }

      return false
    },

    handlePagechange (options) {
      const { page, pageCount } = options

      if (pageCount > 1 && page !== 1) {
        // for extension table reset bulk action fields
        this.extendBulkEfforts = ''
        this.commonExtendFrom = null
        this.commonExtendTo = null
        // for deallocation table reset bulk action fields
        this.deallocationBulkEfforts = ''
        this.commonDeallocateFrom = null
        // for reporting manager change request table reset bulk action field
        this.selectedBulkManger = ''
      }
    },
    selectWholeList (event) {
      if (event.value) {
        this.search = ''
        this.allDataRowsSelected = true
      } else {
        this.unSelectAllExtensionRows = true
      }
    },

    checkEffortsValidation (selectedValue, selected) {
      let validationFlag = true

      this.deallocationSelected.forEach((item) => {
        const hours = Number(item.deallocate_hrs)

        if (hours === 0 || hours === 'NaN' || item.deallocate_from === null) {
          validationFlag = false
        }
      })
      this.validationPass = validationFlag
    },
    updateAllEfforts (val) {
      const updatedMeta = []
      let validationFlag = true

      this.deallocationSelected.forEach((item) => { updatedMeta.push(item.meta_id) })
      this.allocationTableData = this.allocationTableData.map((element) => {
        if (updatedMeta.includes(element.meta_id)) {
          let deallocationHours = val

          if (deallocationHours > element.efforts) {
            deallocationHours = element.efforts
          }
          element.deallocate_hrs = deallocationHours.toString()
        }

        return element
      })
      this.deallocationSelected.forEach((item) => {
        if (item.deallocate_from === null || item.deallocate_hrs === '') {
          validationFlag = false
        }
      })
      this.validationPass = validationFlag
    },
    selectDeallocationWholeList (event) {
      if (event.value) {
        this.search = ''
        this.allDeallocationDataRowsSelected = true
      } else {
        this.unSelectAllDeallocationRows = true
      }
    },
    updateCommonDate (value, type) {
      const updatedMeta = []
      let popUp = false
      let today = new Date()
      const dd = String(today.getDate()).padStart(2, '0')
      const mm = String(today.getMonth() + 1).padStart(2, '0')
      const yyyy = today.getFullYear()

      today = yyyy + '-' + mm + '-' + dd
      let validationFlag = true

      this.deallocationSelected.forEach((item) => { updatedMeta.push(item.meta_id) })
      this.validationPass = validationFlag
      this.allocationTableData = this.allocationTableData.map((element) => {
        let flag = true
        let alert = false

        if (updatedMeta.includes(element.meta_id)) {
          let deallocationDate = value
          const startDate = new Date(element.start_date)
          const endDate = new Date(element.end_date)
          const deallocate = new Date(deallocationDate)

          if (startDate.getTime() === endDate.getTime() && startDate.getTime() === (new Date(today)).getTime()) {
            alert = true
            flag = false
          } else if (startDate.getTime() === endDate.getTime() && startDate.getTime() > new Date(today).getTime()) {
            deallocationDate = element.end_date
          } else if (deallocate.getTime() < startDate.getTime()) {
            deallocationDate = element.start_date
          } else if (deallocate.getTime() >= endDate.getTime()) {
            let maxDeallocateDate = new Date(element.end_date)

            maxDeallocateDate.setDate(maxDeallocateDate.getDate() - 1)
            maxDeallocateDate = `${maxDeallocateDate.getFullYear()}-${String(maxDeallocateDate.getMonth() + 1).padStart(2, '0')}-${String(maxDeallocateDate.getDate()).padStart(2, '0')}`
            deallocationDate = maxDeallocateDate
          }
          if (type === 'deallocate_from' && flag) {
            element.deallocate_from = deallocationDate
          } else {
            element.deallocateAlert = alert
          }
          if (!popUp && (alert || ((new Date(value)).getTime() < startDate.getTime()))) {
            popUp = true
          }
        }

        return element
      })
      this.deallocationSelected.forEach((item) => {
        if (item.deallocate_from === null || item.deallocate_hrs === '') {
          validationFlag = false
        }
      })
      this.validationPass = validationFlag
      if (popUp) {
        this.errorText = 'Some of the resources cannot deallocate. Please click on UnSelect button for Dis-Select'
        this.errorDialog = true

        return false
      }

    },
    async submit () {
      this.updateLoadingAction()
      const deAllocationData = []
      const currentDate = new Date()
      const resourceReqData = this.allocationTableData || []

      for (let i = 0; i < resourceReqData.length; i++) {
        if (resourceReqData[i].deallocate) {
          const diffInTimeForDeallocateFrom = new Date(resourceReqData[i].start_date.substr(0, 10)).getTime() -
            new Date(resourceReqData[i].deallocate_from.substr(0, 10)).getTime()

          const deallocateFromDate = new Date(resourceReqData[i].deallocate_from)
          // To calculate the no. of days between two dates
          const diffInDaysForDeallocateFrom = diffInTimeForDeallocateFrom / (1000 * 3600 * 24)
          const fullDeallocate = ((new Date(resourceReqData[i].start_date).getTime() > currentDate.getTime()) && parseFloat(resourceReqData[i].deallocate_hrs) === parseFloat(resourceReqData[i].efforts) &&
            (diffInDaysForDeallocateFrom === 0 || deallocateFromDate.getTime() <= currentDate.getTime()))
          const data = {
            'full_deallocate': fullDeallocate,
            'resource_id': resourceReqData[i].resource_id,
            'uuid': resourceReqData[i].allocation_id,
            'hours': resourceReqData[i].deallocate_hrs,
            'start_date': resourceReqData[i].deallocate_from,
            'allocation_meta_uuid': resourceReqData[i].meta_id,
            'billing_type': resourceReqData[i].billing_type,
            'dept_name': resourceReqData[i].dept,
            'tech_name': resourceReqData[i].tech,
            'role_name': resourceReqData[i].designation,
            'allocation_start_date': resourceReqData[i].start_date,
            'allocation_end_date': resourceReqData[i].end_date
          }

          deAllocationData.push(data)
        }
      }
      if (!deAllocationData.length) {
        this.updateLoadingAction()
        alert('Please deallocate atleast one resource')

        return
      }
      const pushData = {
        'de_allocation_data': deAllocationData,
        'project_id': this.projectDetail.uuid
      }

      await this.setResourceDeAllocationData(pushData)
      this.updateLoadingAction()
      this.submitted = true
    }
  }
}

</script>

<style scoped>
>>>.v-messages__message {
  position: absolute;
  bottom: -30px;
  left: -30px;
  min-width: auto;
  word-break: normal;
  width: 148px;
}
>>>.v-text-field__details {
  overflow: visible;
}
</style>
