<template>
  <div>
    <common-snackbar :snackbar="snackbarValue" :text-for-snackbar="snackbarText" />
    <Dialog />
    <v-dialog
      v-model="overBookDialog"
      :persistent="true"
    >
      <v-card>
        <v-spacer />
        <v-card-text align="center" class="iconcenter">
          <v-spacer />
          <v-icon color="red" class="mdi-48px">
            mdi-alert-circle
          </v-icon>
        </v-card-text>
        <v-card-text align="center">
          {{ overBookText }}
        </v-card-text>
        <v-card-actions>
          <v-col cols="3" />
          <v-col cols="3">
            <v-btn
              color="primary"
              text
              class="marginauto"
              @click="overBookDialog = false"
            >
              Cancel
            </v-btn>
          </v-col>
          <v-col cols="3">
            <v-btn
              color="primary"
              text
              class="marginauto"
              @click="submitExtension(true)"
            >
              Yes
            </v-btn>
          </v-col>
          <v-col cols="3" />
        </v-card-actions>
      </v-card>
    </v-dialog>
    <ValidationObserver ref="allocateObserver" v-slot="{ valid }">
      <template v-if="allSelected">
        <div class="bulkSelection">
          <div class="bulkSelectionInner">
            <v-row>
              <v-col cols="2">
                <h3>Bulk <br>Action</h3>
              </v-col>
              <v-col cols="5">
                <div class="Fieldlable">
                  <label>Extend Hours</label>
                </div>
                <div class="slotHeight">
                  <v-select
                    v-model="extendBulkEfforts"
                    :items="numberList"
                    placeholder="Select Hours"
                    class="blkSelectHrs"
                    dense
                    @change="updateAllEfforts(extendBulkEfforts)"
                  />
                </div>
              </v-col>
              <v-col cols="5">
                <div class="Fieldlable">
                  <label>Extend Date Duration</label>
                </div>
                <div class="starttEndDatedWrp">
                  <div class="startDate">
                    <v-menu
                      v-model="commonExtendFromMenu"
                      :close-on-content-click="false"
                    >
                      <template v-slot:activator="{ on, attrs }">
                        <v-text-field
                          :value="(commonExtendFrom) ? new Date(commonExtendFrom).toLocaleDateString('en-US', {
                            year: 'numeric',
                            month: 'numeric',
                            day: 'numeric'
                          }) : ''"
                          v-bind="attrs"
                          dense
                          solo
                          readonly
                          placeholder="From"
                          v-on="on"
                        >
                          <template v-slot:prepend-inner>
                            <v-icon v-bind="attrs" v-on="on">
                              mdi-calendar
                            </v-icon>
                          </template>
                        </v-text-field>
                      </template>
                      <v-date-picker v-model="commonExtendFrom" :min="currentDate" @change="updateCommonDate($event, 'extend_from')" @input="commonExtendFromMenu = false" />
                    </v-menu>
                  </div>
                  <div class="toText"><span>to</span></div>
                  <div class="endDate">
                    <v-menu
                      v-model="commonExtendToMenu"
                      :close-on-content-click="false"
                    >
                      <template v-slot:activator="{ on, attrs }">
                        <v-text-field
                          :value="(commonExtendTo) ? new Date(commonExtendTo).toLocaleDateString('en-US', {
                            year: 'numeric',
                            month: 'numeric',
                            day: 'numeric'
                          }) : ''"
                          v-bind="attrs"
                          solo
                          dense
                          readonly
                          placeholder="To"
                          v-on="on"
                        >
                          <template v-slot:prepend-inner>
                            <v-icon v-bind="attrs" v-on="on">
                              mdi-calendar
                            </v-icon>
                          </template>
                        </v-text-field>
                      </template>
                      <v-date-picker v-model="commonExtendTo" :min="commonExtendFrom" @change="updateCommonDate($event, 'extend_to')" @input="commonExtendToMenu = false" />
                    </v-menu>
                  </div>
                </div>
              </v-col>
            </v-row>
          </div>
        </div>
      </template>
      <div class="requisitionTableWrp extandTable">
        <v-data-table
          v-model="selected"
          :single-select="singleSelect"
          :headers="headersForExtensionTable"
          :items="extensionTableData"
          item-key="meta_id"
          show-select
          class="elevation-1"
          :sort-by.sync="sortBy"
          :sort-desc.sync="sortDesc"
          :hide-default-footer="extensionTableData.length ? false : true"
          @toggle-select-all="selectWholeList($event)"
          @pagination="handlePagechange"
          @page-count="pageCount = $event"
        >
          <!-- resource_name -->
          <template v-slot:item.resource_name="{item}">
            <div class="pa-2">
              <div v-if="item.expireFlag">
                <span class="red--text mb-3"> {{ item.expireDays }} </span><br/>
              </div>
              <div v-else>
                <span class="green--text mb-3"> {{ item.expireDays }} </span><br/>
              </div>
              <span> {{ item.resource_name }} </span>
              <br/><span></span><span> {{ item.dept }} </span>
              <br/><span class="blue--text mb-3"> {{ item.billing_type }} </span>
            </div>
          </template>
          <template v-slot:item.deallocate_hrs="{item}">
            <div v-if="item.extend" class="incDecCountWrp">
              <div class="incCount">
                <v-btn
                  depressed
                  small
                  @click="item.deallocate_hrs = incrementHours(item.deallocate_hrs)"
                ><v-icon dark>mdi-plus</v-icon></v-btn>
              </div>
              <div class="inputField">
                <ValidationProvider
                  v-slot="{ errors }"
                  :rules="`required|check_efforts`"
                  :name="item.deallocate_hrs"
                >
                  <v-text-field
                    v-model.trim="item.deallocate_hrs"
                    :error-messages="errors"
                    type="number"
                    @keyup="checkEffortsValidation($event, item)"
                  />
                </ValidationProvider>
              </div>
              <div class="decCount">
                <v-btn
                  depressed
                  small
                  @click="item.deallocate_hrs = decrementHours(item.deallocate_hrs)"
                ><v-icon dark>mdi-minus</v-icon></v-btn>
              </div>
            </div>
            <div v-else class="incDecCountWrp">
              <div class="incCount">
                <v-btn depressed small><v-icon dark>mdi-plus</v-icon></v-btn>
              </div>
              <div class="inputField">
                <ValidationProvider :rules="`required|check_efforts`" :name="item.deallocate_hrs">
                  <v-text-field v-model.trim="item.deallocate_hrs" disabled />
                </ValidationProvider>
              </div>
              <div class="decCount">
                <v-btn depressed small><v-icon dark>mdi-minus</v-icon></v-btn>
              </div>
            </div>
          </template>
          <template v-slot:item.tech="{item}">
            <div class="pa-2">
              <span> {{ item.tech }} </span>
              <br/><span></span><span> {{ item.designation }} </span>
            </div>
          </template>
          <template v-slot:item.date_duration="{item}">
            {{ new Date(item.start_date).toLocaleDateString('en-US', {
              year: 'numeric',
              month: 'short',
              day: 'numeric'
            })
            }} - {{ new Date(item.end_date).toLocaleDateString('en-US', {
              year: 'numeric',
              month: 'short',
              day: 'numeric'
            })
            }}
          </template>
          <template v-slot:item.extend_date_duration="{item, attrs}">
            <div class="starttEndDatedWrp">
              <div class="startDate">
                <v-menu
                  ref="item.extensionFromDate"
                  v-model="item.extensionFromDate"
                  :close-on-content-click="false"
                >
                  <template v-slot:activator="{ on }">
                    <v-text-field
                      :value="(item.deallocate_from) ? new Date(item.deallocate_from).toLocaleDateString('en-US', {
                        year: 'numeric',
                        month: 'numeric',
                        day: 'numeric'
                      }) : ''"
                      :disabled="!item.extend"
                      v-bind="attrs"
                      readonly
                      placeholder="From"
                      solo
                      dense
                      v-on="on"
                    >
                      <template v-slot:prepend-inner>
                        <v-icon :disabled="!item.extend" v-bind="attrs" v-on="on">
                          mdi-calendar
                        </v-icon>
                      </template>
                    </v-text-field>
                  </template>
                  <v-col cols="12" class="pa-0">
                    <v-date-picker v-model="item.deallocate_from" :min="currentDate" @change="changeToExtensionDateString($event, item, 'deallocate_from')" @input="item.extensionFromDate = false" />
                  </v-col>
                </v-menu>
              </div>
              <div class="toText"><span>to</span></div>
              <div class="endDate">
                <v-menu
                  ref="item.extensionToDate"
                  v-model="item.extensionToDate"
                  :close-on-content-click="false"
                >
                  <template v-slot:activator="{ on }">
                    <v-text-field
                      :value="(item.deallocate_to) ? new Date(item.deallocate_to).toLocaleDateString('en-US', {
                        year: 'numeric',
                        month: 'numeric',
                        day: 'numeric'
                      }) : ''"
                      :disabled="!item.extend"
                      v-bind="attrs"
                      readonly
                      solo
                      placeholder="To"
                      dense
                      v-on="on"
                    >
                      <template v-slot:prepend-inner>
                        <v-icon :disabled="!item.extend" v-bind="attrs" v-on="on">
                          mdi-calendar
                        </v-icon>
                      </template>
                    </v-text-field>
                  </template>
                  <v-col cols="12" class="pa-0">
                    <v-date-picker v-model="item.deallocate_to" :min="item.deallocate_from" @change="changeToExtensionDateString($event, item, 'deallocate_to')" @input="item.extensionToDate = false" />
                  </v-col>
                </v-menu>
              </div>
            </div>
          </template>
          <!-- actions -->
          <template v-slot:item.action="{item}">
            <div class="ExtActionTblWrp">
              <v-autocomplete
                v-model="item.action"
                :disabled="!item.extend"
                :items="actionTypesArray"
                item-text="name"
                item-value="value"
                solo
                dense
              />
            </div>
          </template>
          <!-- extend -->
          <template v-slot:item.deallocate="{ item }">
            <v-checkbox v-model="item.extend" />
          </template>
        </v-data-table>
      </div>
      <div class="submitBtnWrp">
        <div v-if="!valid || selected.length === 0 || !extensionValidationPass" class="submitDiv" cols="12">
          <v-btn
            class="backBtn"
            @click="$router.push('/project-dashboard')"
          >
            <v-icon dark left>
              mdi-arrow-left
            </v-icon>Back
          </v-btn>
          <v-btn :disabled="!valid || selected.length === 0 || !extensionValidationPass" class="submitBtn" @click="submitExtension(false)">
            Submit
          </v-btn>
        </div>
        <div v-else class="submitDiv" cols="12">
          <v-btn
            class="backBtn"
            @click="$router.push('/project-dashboard')"
          >
            <v-icon dark left>
              mdi-arrow-left
            </v-icon>Back
          </v-btn>
          <v-btn :disabled="submitted" class="submitBtn" @click="submitExtension(false)">
            Submit
          </v-btn>
        </div>
      </div>
    </ValidationObserver>
  </div>
</template>
<script>
import { mapActions, mapGetters } from 'vuex'
import CommonSnackbar from '@/components/CommonSnackbar'
import Dialog from '@/components/Dialog.vue'
import constant from '@/constants/closure-checklist.js'
import { excelSheet, projectHelpers } from '@/helpers/helper.js'

export default {
  name: 'ResourceDeAllocation',
  layout: 'authenticated',
  middleware: 'authenticated',
  components: {
    Dialog,
    CommonSnackbar
  },
  props: {
    extensionListData: {
      type: Array,
      default: () => ([])
    }
  },
  data () {
    return {
      page: 1,
      pageCount: 0,
      headersForExtensionTable: [
        { text: 'Resource Details', sortable: true, value: 'resource_name', align: 'center', width: '19%' },
        { text: 'Technology/Role', value: 'tech', sortable: true, align: 'center',  width: '9%'  },
        { text: 'Efforts (In Hrs)', value: 'efforts', sortable: true, align: 'center', width: '4%' },
        { text: 'Date Duration', value: 'date_duration', sortable: false, align: 'center', width: '9%' },
        { text: 'Extend Hrs', value: 'deallocate_hrs', sortable: false, align: 'center', width: '10%' },
        { text: 'Extend Date Duration', value: 'extend_date_duration', sortable: false, align: 'center', width: '25%' },
        { text: 'Actions', value: 'action', sortable: false, align: 'center', width: '15%' }
      ],
      rowsPerPage: [50, 100, 200],
      sortBy: 'resource_name',
      sortDesc: false,
      numberList: [1, 2, 3, 4, 5, 6, 7, 8],
      commonExtendFrom: null,
      commonExtendTo: null,
      commonDeallocateFrom: null,
      commonExtendFromMenu: false,
      commonExtendToMenu: false,
      singleSelect: false,
      selected: [],
      deallocationSelected: [],
      manageReportingSelected: [],
      allocationTableData: [],
      extensionTableData: [],
      extensionValidationPass: false,
      validationPass: false,
      itemsPerPage: 10,
      snackbarValue: false,
      snackbarText: '',
      resourceAllocationMeta: [],
      overBookResourceArray: [],
      overBookText: '',
      overBookDialog: false,
      errorText: '',
      errorDialog: false,
      allDataRowsSelected: false,
      unSelectAllExtensionRows: false,
      allSelected: false,
      extensionActive: true,
      currentDate: null,
      dialog: false,
      actionSelected: [],
      constant,
      submitted: false,
      departmentSelected: '',
      departmentList: [],
      extendBulkEfforts: '',
      deallocationBulkEfforts: '',
      selectedBulkManger: '',
      actions:['auto-deallocation', 'auto extension'],
      max: 8,
      min: 1,
      actionTypesArray: [{ name: 'Auto Deallocate', value: 0 }]
    }
  },
  computed: {
    ...mapGetters({
      // projectDetail: 'project/getProjectDetail',
      // isButtonLoading: 'project/isButtonLoading',
      // projectList: 'project/getProjectList',
      departments: 'project/getDepartments'
      // availableRoles: 'roles/availableRoles',
      // getManageReportingDetail: 'project/getManageReportingDetail'
    })
  },
  watch: {
    extensionListData () {
      this.extensionTableData = this.extensionListData
    },
    selected () {
      if (this.allDataRowsSelected) {
        const { selected } = this

        this.selected = selected
      } else if (this.unSelectAllExtensionRows) {
        this.selected = []
      }
      this.unSelectAllExtensionRows = false
      this.allDataRowsSelected = false
      let validationFlag = true
      const selectedRows = []

      if (this.selected.length > 1) {
        this.allSelected = true
      } else {
        this.allSelected = false
      }
      this.selected.forEach((item) => {
        if (item.deallocate_from === null || item.deallocate_to === null || item.deallocate_hrs === '') {
          validationFlag = false
        }
        selectedRows.push(item.meta_id)
      })
      this.extensionValidationPass = validationFlag
      this.extensionTableData = this.extensionTableData.map((element, index) => {
        if (selectedRows.includes(element.meta_id)) {
          element.extend = true
        } else {
          element.extend = false
        }

        return element
      })
    }
  },
  mounted () {
    this.extensionTableData = this.extensionListData
    let today = new Date()
    const dd = String(today.getDate()).padStart(2, '0')
    const mm = String(today.getMonth() + 1).padStart(2, '0')
    const yyyy = today.getFullYear()

    today = yyyy + '-' + mm + '-' + dd
    this.currentDate = today
    this.departments.map((item) => {
      this.departmentList.push(item.name)
    })
  },
  methods: {
    ...mapActions({
      setResourceDeAllocationData: 'project/setResourceDeAllocationData',
      setResourceExtensionData: 'project/setResourceExtensionData',
      setManageReportingData: 'project/setManageReportingData',
      setCustomDialog: 'project/setCustomDialog',
      updateLoadingAction: 'project/updateLoadingAction'
    }),

    incrementHours (value) {
      value = parseInt(value) === this.max ? this.max : parseInt(value) + 1

      return value.toString()
    },

    decrementHours (value) {
      value = parseInt(value) === this.min ? this.min : parseInt(value) - 1

      return value.toString()
    },

    changeToExtensionDateString (selectedDate, selected, key) {
      let validationFlag = true

      for (let i = 0; i < this.extensionTableData.length; i++) {
        if (this.extensionTableData[i].meta_id === selected.meta_id) {
          if (key === 'deallocate_from') {
            this.extensionTableData[i].deallocate_from = selectedDate
          } else {
            this.extensionTableData[i].deallocate_to = selectedDate
          }
        }
      }
      this.selected.forEach((item) => {
        if (item.deallocate_from === null || item.deallocate_to === null || item.deallocate_hrs === '') {
          validationFlag = false
        }
        if (item.deallocate_to < item.deallocate_from) {
          item.deallocate_to = item.deallocate_from
        }
      })
      this.extensionValidationPass = validationFlag
    },

    /**
     * Filter for department column.
     * @param value Value to be tested.
     * @returns {boolean}
     */
    departmenetFilter (value) {
      if (!this.departmentSelected || !value) {
        return true
      }
      value = value.toString()
      if (this.departmentSelected.length && this.departmentSelected === value) {
        return true
      }
      if (this.departmentSelected.length < 1) {
        return true
      }

      return false
    },
    handlePagechange (options) {
      const { page, pageCount } = options

      if (pageCount > 1 && page !== 1) {
        // for extension table reset bulk action fields
        this.extendBulkEfforts = ''
        this.commonExtendFrom = null
        this.commonExtendTo = null

        // for deallocation table reset bulk action fields
        this.deallocationBulkEfforts = ''
        this.commonDeallocateFrom = null

        // for reporting manager change request table reset bulk action field
        this.selectedBulkManger = ''
      }
    },
    selectWholeList (event) {
      if (event.value) {
        this.search = ''
        this.allDataRowsSelected = true
        // this.itemsPerPage = this.extensionTableData.length
      } else {
        this.unSelectAllExtensionRows = true
      }
    },

    checkEffortsValidation (selectedValue, selected) {
      if (this.extensionActive) {
        let validationFlag = true

        this.selected.forEach((item) => {
          const hours = Number(item.deallocate_hrs)

          if (hours === 0 || hours === 'NaN' || item.deallocate_from === null || item.deallocate_to === null) {
            validationFlag = false
          }
        })
        this.extensionValidationPass = validationFlag
      } else {
        let validationFlag = true

        this.deallocationSelected.forEach((item) => {
          const hours = Number(item.deallocate_hrs)

          if (hours === 0 || hours === 'NaN' || item.deallocate_from === null) {
            validationFlag = false
          }
        })

        this.validationPass = validationFlag
      }
    },
    updateAllEfforts (val) {
      const updatedMeta = []

      if (this.extensionActive) {
        let validationFlag = true

        this.selected.forEach((item) => { updatedMeta.push(item.meta_id) })
        this.extensionTableData = this.extensionTableData.map((element) => {
          if (updatedMeta.includes(element.meta_id)) {
            element.deallocate_hrs = val.toString()
          }

          return element
        })
        this.selected.forEach((item) => {
          if (item.deallocate_from === null || item.deallocate_to === null || item.deallocate_hrs === '') {
            validationFlag = false
          }
        })
        this.extensionValidationPass = validationFlag
      } else {
        let validationFlag = true

        this.deallocationSelected.forEach((item) => { updatedMeta.push(item.meta_id) })
        this.allocationTableData = this.allocationTableData.map((element) => {
          if (updatedMeta.includes(element.meta_id)) {
            let deallocationHours = val

            if (deallocationHours > element.efforts) {
              deallocationHours = element.efforts
            }
            element.deallocate_hrs = deallocationHours.toString()
          }

          return element
        })
        this.deallocationSelected.forEach((item) => {
          if (item.deallocate_from === null || item.deallocate_hrs === '') {
            validationFlag = false
          }
        })
        this.validationPass = validationFlag
      }
    },
    updateCommonDate (value, type) {
      const updatedMeta = []

      if (this.extensionActive) {
        let validationFlag = true

        this.selected.forEach((item) => { updatedMeta.push(item.meta_id) })
        this.extensionTableData = this.extensionTableData.map((element) => {
          if (updatedMeta.includes(element.meta_id)) {
            if (type === 'extend_from') {
              element.deallocate_from = value
            } else {
              element.deallocate_to = value
            }
          }

          return element
        })
        this.selected.forEach((item) => {
          if (item.deallocate_from === null || item.deallocate_to === null || item.deallocate_hrs === '') {
            validationFlag = false
          }
        })
        this.extensionValidationPass = validationFlag
      } else {
        let popUp = false
        let today = new Date()
        const dd = String(today.getDate()).padStart(2, '0')
        const mm = String(today.getMonth() + 1).padStart(2, '0')
        const yyyy = today.getFullYear()

        today = yyyy + '-' + mm + '-' + dd
        let validationFlag = true

        this.deallocationSelected.forEach((item) => { updatedMeta.push(item.meta_id) })
        this.validationPass = validationFlag
        this.allocationTableData = this.allocationTableData.map((element) => {
          let flag = true
          let alert = false

          if (updatedMeta.includes(element.meta_id)) {
            let deallocationDate = value
            const startDate = new Date(element.start_date)
            const endDate = new Date(element.end_date)
            const deallocate = new Date(deallocationDate)

            if (startDate.getTime() === endDate.getTime() && startDate.getTime() === (new Date(today)).getTime()) {
              alert = true
              flag = false
            } else if (startDate.getTime() === endDate.getTime() && startDate.getTime() > new Date(today).getTime()) {
              deallocationDate = element.end_date
            } else if (deallocate.getTime() < startDate.getTime()) {
              deallocationDate = element.start_date
            } else if (deallocate.getTime() >= endDate.getTime()) {
              let maxDeallocateDate = new Date(element.end_date)

              maxDeallocateDate.setDate(maxDeallocateDate.getDate() - 1)
              maxDeallocateDate = `${maxDeallocateDate.getFullYear()}-${String(maxDeallocateDate.getMonth() + 1).padStart(2, '0')}-${String(maxDeallocateDate.getDate()).padStart(2, '0')}`
              deallocationDate = maxDeallocateDate
            }
            if (type === 'deallocate_from' && flag) {
              element.deallocate_from = deallocationDate
            } else {
              element.deallocateAlert = alert
            }
            if (!popUp && (alert || ((new Date(value)).getTime() < startDate.getTime()))) {
              popUp = true
            }
          }

          return element
        })
        this.deallocationSelected.forEach((item) => {
          if (item.deallocate_from === null || item.deallocate_hrs === '') {
            validationFlag = false
          }
        })
        this.validationPass = validationFlag
        if (popUp) {
          this.errorText = 'Some of the resources cannot deallocate. Please click on UnSelect button for Dis-Select'
          this.errorDialog = true

          return false
        }
      }
    },

    checkResourceOverbooking (data, resourceId, startDate, endDate, hours) {
      let response = false
      let allocatedHours = parseFloat(hours)

      if (data[resourceId]) {
        data[resourceId].forEach((item) => {
          if (item.resource_id === resourceId) {
            if ((new Date(startDate)).getTime() >= (new Date(item.start_date)).getTime() && (new Date(startDate)).getTime() <= (new Date(item.end_date)).getTime()) {
              allocatedHours = allocatedHours + parseFloat(item.hours)
            } else if ((new Date(endDate)).getTime() >= (new Date(item.start_date)).getTime() && (new Date(endDate)).getTime() <= (new Date(item.end_date)).getTime()) {
              allocatedHours = allocatedHours + parseFloat(item.hours)
            }
          }
        })
        if (allocatedHours > 8) {
          response = true
        }
      }

      return response
    },
    async submitExtension (type = false) {
      const extensionResources = []

      this.updateLoadingAction()
      const resourceOverbookResource = []

      this.selected.forEach((row) => {
        const overbook = this.checkResourceOverbooking(this.resourceAllocationMeta, row.resource_id, row.deallocate_from, row.deallocate_to, row.deallocate_hrs)

        if (overbook) {
          resourceOverbookResource.push(row.resource_id)
        }
      })
      this.overBookResourceArray = resourceOverbookResource
      if (resourceOverbookResource.length > 0 && !type) {
        this.overBookText = 'The selected resource is already allocated on the project for the same duration and efforts which may lead to creating duplicate bookings. Do you still want to continue?'
        this.overBookDialog = true

        return false
      } else {
        this.overBookDialog = false
      }

      this.selected.forEach((record) => {
        extensionResources.push({
          'dept_id': record.dept_id,
          'tech_id': record.tech_id,
          'extension_resource_id': record.resource_id,
          'efforts': record.deallocate_hrs,
          'experience': record.experience,
          'start_date': record.deallocate_from,
          'end_date': record.deallocate_to,
          'role_id': record.role_id,
          'billing_type': record.billing_value,
          'suggested_resource': null,
          'allocation_start_date': record.start_date,
          'allocation_end_date': record.end_date,
          'allocation_efforts': record.efforts,
          'auto_extn_deallocation': record.action
        })
      })
      const payload = {
        'extension_data': extensionResources,
        'project_id': this.$route.params.id
      }

      await this.setResourceExtensionData(payload)
      this.updateLoadingAction()
      this.submitted = true
    }
  }
}

</script>

<style scoped>
>>>.v-messages__message {
  position: absolute;
  bottom: -30px;
  left: -30px;
  min-width: auto;
  word-break: normal;
  width: 148px;
}
>>>.v-text-field__details {
  overflow: visible;
}
</style>
