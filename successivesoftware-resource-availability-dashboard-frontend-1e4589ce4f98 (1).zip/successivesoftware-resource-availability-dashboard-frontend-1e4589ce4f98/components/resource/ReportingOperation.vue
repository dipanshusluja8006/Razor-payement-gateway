<template>
  <div>
    <common-snackbar :snackbar="snackbarValue" :text-for-snackbar="snackbarText" />
    <Dialog />

    <template v-if="allManageReportingSelected">
      <div class="bulkSelection">
        <div class="bulkSelectionInner">
          <v-row class="justify-center">
            <v-col cols="2">
              <h3>Bulk <br>Action</h3>
            </v-col>
            <v-col cols="5">
              <div class="Fieldlable">
                <label>Requested Reporting Manager</label>
              </div>
              <div class="slotHeight">
                <v-autocomplete
                  v-model="selectedBulkManger"
                  :items="getManageReportingDetail"
                  dense
                  item-text="display_name"
                  item-value="id"
                  placeholder="Choose Name"
                  solo
                  @change="updateAllManager(selectedBulkManger)"
                />
              </div>
            </v-col>
          </v-row>
        </div>
      </div>
    </template>
    <ValidationObserver ref="manageReportingObserver" v-slot="{ valid }">
      <div class="requisitionTableWrp extandTable">
        <v-data-table
          v-model="manageReportingSelected"
          :single-select="singleSelect"
          :headers="headersForManageReportingTable"
          :items="reportingMangaerTableData"
          :hide-default-footer="reportingMangaerTableData.length ? false : true"
          :items-per-page="manageReportingItemsPerPage"
          :sort-by.sync="sortBy"
          :footer-props="{ itemsPerPageOptions: rowsPerPage }"
          :sort-desc.sync="sortDesc"
          item-key="meta_id"
          show-select
          must-sort
          class="elevation-1"
          @toggle-select-all="selectReportingManagerWholeList($event)"
          @pagination="handlePagechange"
        >
          <template v-slot:item.resource_name="{item}">
            <div class="pa-2">
              <div v-if="item.expireFlag">
                <span class="red--text mb-3"> {{ item.expireDays }} </span><br/>
              </div>
              <div v-else>
                <span class="green--text mb-3"> {{ item.expireDays }} </span><br/>
              </div>
              <span> {{ item.resource_name }} </span>
              <br/><span></span><span> {{ item.dept }} </span>
              <br/><span class="blue--text mb-3"> {{ item.billing_type }} </span>
            </div>
          </template>
          <template v-slot:item.tech="{item}">
            <div class="pa-2">
              <span> {{ item.tech }} </span>
              <br/><span></span><span> {{ item.designation }} </span>
            </div>
          </template>

          <template v-slot:item.date_duration="{item}">
            {{ new Date(item.start_date).toLocaleDateString('en-US', {
              year: 'numeric',
              month: 'short',
              day: 'numeric'
            })
            }} - {{ new Date(item.end_date).toLocaleDateString('en-US', {
              year: 'numeric',
              month: 'short',
              day: 'numeric'
            })
            }}
          </template>
          <template v-slot:item.status="{item}">
            <v-chip
              v-if="(reportingManagerRecord[item.resource_id])"
              :color="(item.requestedManagerStatusId === 0) ? 'orangeBtn' : (item.requestedManagerStatusId === 1) ? 'purpleBtn' : (item.requestedManagerStatusId === 2) ? 'redBtn' : 'greenBtn'"
              :text-color="(item.requestedManagerStatusId === 0 || item.requestedManagerStatusId === 1) ? 'black' : 'white'"
              small
              label
            >
              {{ (reportingManagerRecord[item.resource_id]) ? reportingManagerRecord[item.resource_id].status : '' }}
            </v-chip>
          </template>
          <template v-slot:item.requested_reporting_manager="{item}">
            <div class="requestedManager">
              <v-autocomplete
                v-model="item.requestedManager"
                :disabled="!item.manageReporting"
                :items="getManageReportingDetail"
                dense
                item-text="display_name"
                item-value="id"
                placeholder="Choose"
                solo
                @change="updateReportingManager($event, item)"
              >
                <template v-slot:append-outer>
                  <v-tooltip v-if="(isSameNames && item.resource_id === item.requestedManager)? true: false" top>
                    <template v-slot:activator="{ on, attrs }">
                      <span v-bind="attrs" v-on="on">
                        <v-icon :disabled="!item.manageReporting" color="red">mdi-alert-circle-outline</v-icon>
                      </span>
                    </template>
                    <span>Resource and RM Name can not be the same!</span>
                  </v-tooltip>
                </template>
              </v-autocomplete>
            </div>
          </template>
        </v-data-table>
      </div>
      <div class="submitBtnWrp">
        <div v-if="!valid || manageReportingSelected.length === 0 || !manageReportingValidationPass" class="submitDiv">
          <v-btn
            class="backBtn"
            @click="$router.push('/project-dashboard')"
          >
            <v-icon dark left>
              mdi-arrow-left
            </v-icon>Back
          </v-btn>
          <v-btn :disabled="!valid || manageReportingSelected.length === 0 || !manageReportingValidationPass" class="submitBtn" @click="manageReportingSubmit">
            Submit
          </v-btn>
        </div>
        <div v-else class="submitDiv">
          <v-btn
            class="backBtn"
            @click="$router.push('/project-dashboard')"
          >
            <v-icon dark left>
              mdi-arrow-left
            </v-icon>Back
          </v-btn>
          <v-btn :disabled="submitted" class="submitBtn" @click="manageReportingSubmit" >
            Submit
          </v-btn>
        </div>
      </div>
    </ValidationObserver>

  </div>
</template>
<script>
import { mapActions, mapGetters } from 'vuex'
import CommonSnackbar from '@/components/CommonSnackbar'
import Dialog from '@/components/Dialog.vue'
import constant from '@/constants/closure-checklist.js'
import { excelSheet, projectHelpers } from '@/helpers/helper.js'

export default {
  name: 'ResourceDeAllocation',
  layout: 'authenticated',
  middleware: 'authenticated',
  components: {
    Dialog,
    CommonSnackbar
  },
  props: {
    reportingListData: {
      type: Array,
      default: () => ([])
    },
    reportingRecords: {
      type: Array,
      default: () => ([])
    }
  },
  data () {
    return {
      page: 1,
      pageCount: 0,
      headersForManageReportingTable: [
        { text: 'Resource Details', sortable: true, value: 'resource_name', align: 'center', width: '15%' },
        { text: 'Technology/Role', value: 'tech', sortable: true, align: 'center' },
        { text: 'Efforts (In Hrs)', value: 'efforts', sortable: true, align: 'center' },
        { text: 'Date Duration', value: 'date_duration', sortable: false, align: 'center', width: '17%' },
        { text: 'Assigned Reporting Manager', value: 'assignedReportingManagerNameKeka', sortable: true, align: 'center' },
        { text: 'Requested Reporting Manager', value: 'requested_reporting_manager', sortable: false, align: 'center' },
        { text: 'Status', value: 'status', sortable: false, align: 'center' }
      ],
      rowsPerPage: [50, 100, 200],
      sortBy: 'resource_name',
      sortDesc: false,
      commonExtendFrom: null,
      commonExtendTo: null,
      commonDeallocateFrom: null,
      reportingManagerRecord: [],
      singleSelect: false,
      selected: [],
      manageReportingSelected: [],
      reportingMangaerTableData: [],
      manageReportingValidationPass: false,
      validationPass: false,
      itemsPerPage: 10,
      manageReportingItemsPerPage: 10,
      snackbarValue: false,
      snackbarText: '',
      unSelectAllManageReportingnRows: false,
      allManageReportingDataRowsSelected: false,
      allManageReportingSelected: false,
      currentDate: null,
      dialog: false,
      constant,
      submitted: false,
      departmentList: [],
      extendBulkEfforts: '',
      deallocationBulkEfforts: '',
      selectedBulkManger: '',
      isSameNames: false,
      actions:['auto-deallocation', 'auto extension']
    }
  },
  computed: {
    ...mapGetters({
      // projectDetail: 'project/getProjectDetail',
      // isButtonLoading: 'project/isButtonLoading',
      // projectList: 'project/getProjectList',
      departments: 'project/getDepartments',
      // availableRoles: 'roles/availableRoles',
      getManageReportingDetail: 'project/getManageReportingDetail'
    })
  },
  watch: {
    reportingListData () {
      this.reportingMangaerTableData = this.reportingListData
    },
    reportingRecords () {
      this.reportingManagerRecord = this.reportingRecords
    },
    manageReportingSelected () {
      let validationFlag = true

      if (this.allManageReportingDataRowsSelected) {
        const { manageReportingSelected } = this

        this.manageReportingSelected = manageReportingSelected
      } else if (this.unSelectAllManageReportingnRows) {
        this.manageReportingSelected = []
      }
      this.unSelectAllManageReportingnRows = false
      this.allManageReportingDataRowsSelected = false
      const selectedRows = []

      if (this.manageReportingSelected.length > 1) {
        this.allManageReportingSelected = true
      } else {
        this.allManageReportingSelected = false
      }
      this.manageReportingValidationPass = validationFlag
      this.manageReportingSelected.forEach((item) => {
        if (!item.requestedManager && item.requestedManager !== '') {
          validationFlag = false
        }
        if (item.resource_id === item.requestedManager) {
          this.isSameNames = true
          validationFlag = false
        }
        selectedRows.push(item.meta_id)
      })
      this.manageReportingValidationPass = validationFlag
      this.reportingMangaerTableData = this.reportingMangaerTableData.map((element, index) => {
        if (selectedRows.includes(element.meta_id)) {
          element.manageReporting = true
        } else {
          element.manageReporting = false
        }

        return element
      })
    }
  },
  mounted () {
    this.reportingMangaerTableData = this.reportingListData
    this.reportingManagerRecord = this.reportingRecords
    let today = new Date()
    const dd = String(today.getDate()).padStart(2, '0')
    const mm = String(today.getMonth() + 1).padStart(2, '0')
    const yyyy = today.getFullYear()

    today = yyyy + '-' + mm + '-' + dd
    this.currentDate = today
    this.departments.map((item) => {
      this.departmentList.push(item.name)
    })
  },
  methods: {
    ...mapActions({
      setResourceDeAllocationData: 'project/setResourceDeAllocationData',
      setResourceExtensionData: 'project/setResourceExtensionData',
      setManageReportingData: 'project/setManageReportingData',
      setCustomDialog: 'project/setCustomDialog',
      updateLoadingAction: 'project/updateLoadingAction'
    }),

    updateAllManager (value) {
      let validationFlag = true
      const unselectSameNames = []
      const updatedMeta = []

      this.manageReportingSelected.forEach((item) => { updatedMeta.push(item.meta_id) })
      this.reportingMangaerTableData = this.reportingMangaerTableData.map((element) => {
        if (updatedMeta.includes(element.meta_id)) {
          if (element.resource_id === value) {
            this.isSameNames = true
            validationFlag = false
            unselectSameNames.push(element.resource_id)
          }
          element.requestedManager = value
        }

        return element
      })
      this.manageReportingValidationPass = validationFlag
      this.manageReportingSelected = this.manageReportingSelected.filter((item) => { return !unselectSameNames.includes(item.resource_id) })
      this.updateReportingManager()
    },
    handlePagechange (options) {
      const { page, pageCount } = options

      if (pageCount > 1 && page !== 1) {
        // for extension table reset bulk action fields
        this.extendBulkEfforts = ''
        this.commonExtendFrom = null
        this.commonExtendTo = null

        // for deallocation table reset bulk action fields
        this.deallocationBulkEfforts = ''
        this.commonDeallocateFrom = null

        // for reporting manager change request table reset bulk action field
        this.selectedBulkManger = ''
      }
    },
    updateReportingManager (event) {
      let validationFlag = true

      this.manageReportingSelected.forEach((item) => {
        if (!item.requestedManager && item.requestedManager !== '') {
          validationFlag = false
        }
        if (event && item.resource_id === event) {
          this.isSameNames = true
          validationFlag = false
        }
      })
      this.manageReportingValidationPass = validationFlag
    },
    selectReportingManagerWholeList (event) {
      if (event.value) {
        this.search = ''
        this.allManageReportingDataRowsSelected = true
        // this.manageReportingItemsPerPage = this.reportingMangaerTableData.length
      } else {
        this.unSelectAllManageReportingnRows = true
      }
    },
    async manageReportingSubmit () {
      this.updateLoadingAction()
      const response = []

      this.manageReportingSelected.forEach((item) => {
        const record = {
          resource_id: item.resource_id,
          dept_id: item.dept_id,
          requested_rm_id: item.requestedManager,
          active_rm_id: (this.reportingManagerRecord[item.resource_id]) ? this.reportingManagerRecord[item.resource_id].currentRm.id : null,
          keka_rm_name: item.assignedReportingManagerNameKeka,
          keka_rm_email: item.assignedReportingManagerEmailKeka
        }

        response.push(record)
      })
      const payload = {
        project_id: this.$route.params.id,
        resource_data: response
      }

      await this.setManageReportingData(payload)
      this.updateLoadingAction()
      this.submitted = true
    }
  }
}

</script>

<style scoped>

</style>
