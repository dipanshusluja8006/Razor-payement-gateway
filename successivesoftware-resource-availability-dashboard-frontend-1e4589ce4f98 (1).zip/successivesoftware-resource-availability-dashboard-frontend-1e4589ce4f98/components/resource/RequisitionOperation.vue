<template>
  <div>
    <confirm-dialog ref="confirm"/>
    <common-snackbar :snackbar="snackbarValue" :text-for-snackbar="snackbarText" />
    <Dialog />
    <div class="requisitionWrp">
      <v-tabs v-model="currentTabIndex" show-arrows class="tablistWrp">
        <v-tabs-slider />
        <v-tab
          v-for="item in tabItems"
          :key="item.id"
          class="text-capitalize"
        >
          {{ item.title }}
        </v-tab>
      </v-tabs>
      <v-tabs-items v-model="currentTabIndex">
        <v-tab-item
          v-for="item in tabItems"
          :id="`tab-${item.id}`"
          :key="item.id"
        />
      </v-tabs-items>
      <div v-if="tabItems[currentTabIndex].id === 1">
        <div id="editDataForm" class="requisitionRequesttabWrp">
          <div class="requisitionRequesttabeH">
            <h4>Request Resource <v-btn
              @click="hideForm(reqBtnLabel)"
            >
              {{ reqBtnLabel }}
              <v-icon>{{ collapseIcon }}</v-icon>
            </v-btn> </h4>
          </div>
          <div v-if="collapseReqForm">
            <ValidationObserver ref="resourceReqObserver" v-slot="{ valid }">
              <div class="cardWrp">
                <div class="cardLeftcol">
                  <v-img :src="cardImg" class="img"/>
                </div>
                <div class="cardRightcol">
                  <v-row>
                    <v-col cols="12" sm="4">
                      <div class="field">
                        <span>Department *</span>
                      </div>
                      <ValidationProvider v-slot="{ errors }" :rules="'required'" name="editedItem.department">
                        <v-autocomplete
                          v-model="editedItem.department"
                          :items="departments"
                          :error-messages="errors"
                          item-text="name"
                          item-value="id"
                          :disabled="editedItem.edit"
                          placeholder="Choose Department"
                          @change="updateResourceList"
                        />
                      </ValidationProvider>
                    </v-col>
                    <v-col cols="12" sm="4">
                      <div class="field">
                        <span>Technology *</span>
                      </div>
                      <ValidationProvider v-slot="{ errors }" :rules="'required'" name="editedItem.technology">
                        <v-autocomplete
                          v-model="editedItem.technology"
                          :items="technologies"
                          :error-messages="errors"
                          item-text="name"
                          item-value="id"
                          placeholder="Choose Technology"
                        />
                      </ValidationProvider>
                    </v-col>
                    <v-col cols="12" sm="4">
                      <div class="field">
                        <span>Role *</span>
                      </div>
                      <ValidationProvider v-slot="{ errors }" :rules="'required'" name="editedItem.role">
                        <v-autocomplete
                          v-model="editedItem.role"
                          :items="availableRoles"
                          :error-messages="errors"
                          item-text="name"
                          item-value="id"
                          placeholder="Choose Role"
                        />
                      </ValidationProvider>
                    </v-col>
                  </v-row>
                  <v-row>
                    <v-col v-show="editedItem.type === 0" cols="12" sm="4" class="pt-0 pb-0">
                      <div class="field">
                        <span>No of Resources *</span>
                      </div>
                      <ValidationProvider v-slot="{ errors }" :rules="'required|numeric|between:1,100'" name="editedItem.resource">
                        <v-text-field v-model.trim="editedItem.resource" :error-messages="errors" placeholder="Enter No. of Resource" @change="exactCountSuggested" />
                      </ValidationProvider>
                    </v-col>
                    <v-col cols="12" sm="4" class="pt-0 pb-0">
                      <div class="field">
                        <span>Daily Efforts *</span>
                      </div>
                      <ValidationProvider v-slot="{ errors }" :rules="'required|check_efforts'" name="editedItem.efforts">
                        <v-text-field v-model.trim="editedItem.efforts" :error-messages="errors" placeholder="Efforts (in hrs)" />
                      </ValidationProvider>
                    </v-col>
                    <v-col cols="12" sm="4" class="pt-0 pb-0">
                      <div class="field">
                        <span>Experience *</span>
                      </div>
                      <ValidationProvider v-slot="{ errors }" :rules="'required|check_experience'" name="editedItem.experience">
                        <v-text-field v-model.trim="editedItem.experience" :error-messages="errors" placeholder="Enter Experience(in yrs)" />
                      </ValidationProvider>
                    </v-col>
                  </v-row>
                  <v-row>
                    <v-col cols="12" sm="4">
                      <div class="field">
                        <span>Billing Type *</span>
                      </div>
                      <ValidationProvider v-slot="{ errors }" :rules="'required'" name="editedItem.billing_type">
                        <v-select
                          v-model="editedItem.billing_type"
                          :items="billingList"
                          :error-messages="errors"
                          item-text="name"
                          item-value="value"
                          placeholder="Choose Billing Type"
                        />
                      </ValidationProvider>
                    </v-col>
                    <v-col v-show="editedItem.type === 0" cols="12" sm="4">
                      <div class="field">
                        <span>Suggested Resource</span>
                      </div>
                      <v-autocomplete
                        v-model="editedItem.suggested_resource"
                        placeholder="Enter Resource Name"
                        :items="usersData.filter((user) => { return user.dept.length !== 0 && user.dept.some(value => value.id === selectedDepartment) })"
                        item-text="full_name"
                        item-value="id"
                        multiple
                        class="suggestedResourceFiled"
                        @change="exactCountSuggested"
                      >
                        <template v-slot:selection="{ attrs, item, parent, selected, index }" class="slectedChilpSRWrp">
                          <v-tooltip top>
                            <template v-slot:activator="{ on }">
                              <v-chip
                                v-if="item === Object(item) && index === 0"
                                v-bind="attrs"
                                :input-value="selected"
                                label
                                small
                                v-on="on"
                              >
                                <span class="slectedChilpSR">
                                  {{ item.full_name.length >= 47? item.full_name.slice(0,47) + '...': item.full_name }}
                                </span>
                                <v-icon
                                  small
                                  @click="parent.selectItem(item)"
                                >
                                  mdi-close
                                </v-icon>
                              </v-chip>
                              <v-menu
                                bottom
                                origin="center center"
                                transition="scale-transition"
                              >
                                <template v-slot:activator="{ on }">
                                  <v-btn
                                    v-if="index === 1"
                                    class="ml-1 mr-1 text-capitalize"
                                    outlined
                                    rounded
                                    fab
                                    small
                                    height="30"
                                    width="30"
                                    color="blue"
                                    v-on="on"
                                    @click="!false"
                                  >
                                    <v-icon x-small style="height: 10px; width: 10px">
                                      mdi-plus
                                    </v-icon>
                                    {{ seletedResources.length - 1 }}
                                  </v-btn>
                                </template>
                                <v-card
                                  v-show="!false"
                                  class="mx-auto"
                                  max-width="300"
                                  raised
                                >
                                  <v-list
                                    v-if="seletedResources.length > 1"
                                    disabled
                                    shaped
                                  >
                                    <v-list-item-group
                                      v-model="seletedResources"
                                    >
                                      <v-list-item
                                        v-for="resource in seletedResources.slice(1,seletedResources.length)"
                                        v-show="!false"
                                        :key="resource.id"
                                      >
                                        <v-avatar
                                          color="blue lighten-1"
                                          size="30"
                                          style="padding:4px"
                                        >
                                          <strong class="white--text headline">{{ avatarNames(resource.full_name) }}</strong>
                                        </v-avatar>
                                        <v-list-item-content class="ml-2">
                                          <v-list-item-title v-text="resource.full_name" />
                                        </v-list-item-content>
                                      </v-list-item>
                                    </v-list-item-group>
                                  </v-list>
                                </v-card>
                              </v-menu>
                            </template>
                            <span>{{ item.full_name }}</span>
                          </v-tooltip>
                        </template>
                      </v-autocomplete>
                    </v-col>
                    <v-col cols="12" sm="4">
                      <div class="field">
                        <span>Estimated Allocated Duration *</span>
                      </div>
                      <div class="starttEndDatedWrp">
                        <div class="startDate allocationSD">
                          <v-menu
                            ref="start_date"
                            v-model="start_date"
                            :close-on-content-click="false"
                            offset-y
                            max-width="290px"
                            transition="scale-transition"
                          >
                            <template v-slot:activator="{ on }">
                              <ValidationProvider v-slot="{ errors }" :rules="'required'" name="editedItem.start_date">
                                <v-text-field
                                  :value="editedItem.start_date"
                                  :error-messages="errors"
                                  readonly
                                  dense
                                  v-on="on"
                                >
                                  <template v-slot:prepend-inner>
                                    <v-icon v-on="on">
                                      mdi-calendar
                                    </v-icon>
                                  </template>
                                </v-text-field>
                              </ValidationProvider>
                            </template>
                            <v-col cols="12" class="pa-0">
                              <v-date-picker
                                v-model="editedItem.start_date"
                                :min="date_min"
                                @change="changeStartDate(editedItem)"
                                @input="start_date = false"
                              />
                            </v-col>
                          </v-menu>
                        </div>
                        <div class="toText"><span>to</span></div>
                        <div class="endDate allocationED">
                          <v-menu
                            ref="end_date"
                            v-model="end_date"
                            :close-on-content-click="false"
                            offset-y
                            max-width="290px"
                            transition="scale-transition"
                          >
                            <template v-slot:activator="{ on }">
                              <ValidationProvider v-slot="{ errors }" :rules="'required'" name="editedItem.end_date">
                                <v-text-field
                                  :value="editedItem.end_date"
                                  :error-messages="errors"
                                  readonly
                                  dense
                                  v-on="on"
                                >
                                  <template v-slot:prepend-inner>
                                    <v-icon v-on="on">
                                      mdi-calendar
                                    </v-icon>
                                  </template>
                                </v-text-field>
                              </ValidationProvider>
                            </template>
                            <v-col cols="12" class="pa-0">
                              <v-date-picker
                                v-model="editedItem.end_date"
                                :min="editedItem.start_date"
                                @input="end_date = false"
                              />
                            </v-col>
                          </v-menu>
                        </div>
                      </div>
                    </v-col>
                  </v-row>
                  <v-row>
                    <v-col cols="12">
                      <div class="requisitionSBtnWrp">
                        <v-btn text class="backBtn" @click="back">
                          <v-icon small class="mr-1">mdi-arrow-left</v-icon> Back
                        </v-btn>
                        <v-btn
                          :disabled="!valid || submitted"
                          class="submitBtn"
                          text
                          @click="save"
                        >
                          Submit
                        </v-btn>
                      </div>
                    </v-col>
                  </v-row>
                </div>
              </div>
            </ValidationObserver>
          </div>
        </div>
        <div class="requisitionTableWrp">
          <v-data-table
            :headers="headers"
            :items="requisitionItems"
            :hide-default-footer="requisitionItems.length ? false : true"
            sort-by="department"
            class="elevation-1"
            width="100%"
          >
            <template v-slot:item.technology="{ item }">
              <div>
                {{ item.technology.name }}/<br/>{{ item.role.name }}
              </div>
            </template>
            <template v-slot:item.department="{ item }">
              <div class="pa-2">
                <span class="grey--text text--darken-4 requisitionRDetailFs"> {{ item.department.name }} </span> <br/><span class="grey--text">Experience:</span> <span>{{ item.experience }} yrs</span>
                <br/><span class="grey--text"> No. Of Resources:</span><span> {{ item.resource }} </span>
                <br/><span class="blue--text mb-3"> {{ item.billing_type === 1? 'Biilable': 'Non Billable' }} </span>
              </div>
            </template>
            <template v-slot:item.start_date="{ item }">
              {{ new Date(item.start_date).toLocaleDateString('en-US', {
                year: 'numeric', month: 'short', day: 'numeric'
              }) }} - <br/> {{ new Date(item.end_date).toLocaleDateString('en-US', {
                year: 'numeric', month: 'short', day: 'numeric'
              }) }}
            </template>
            <template v-slot:item.created_at="{ item }">
              {{ new Date(item.created_at).toLocaleDateString('en-US', {
                year: 'numeric', month: 'short', day: 'numeric'
              }) }}
            </template>
            <template v-slot:item.requested_user="{ item }">
              {{ item.requested_user }}
            </template>
            <template v-slot:item.suggested_resource="{ item }">
              <span
                v-for="resource in item.suggested_resource.slice(0,2)"
                :key="resource.id"
                class="ma-2"
                text-color="white"
              >
                <v-tooltip top>
                  <template v-slot:activator="{ on }">
                    <v-avatar
                      color="blue lighten-1"
                      size="30"
                      v-on="on"
                    >
                      <span class="white--text headline">{{ avatarNames(resource.full_name) }}</span>
                    </v-avatar>
                  </template>
                  {{ resource.full_name }}
                </v-tooltip>
              </span>
              <v-menu
                bottom
                origin="center center"
                transition="scale-transition"
              >
                <template v-slot:activator="{ on }">
                  <v-btn
                    v-if="item.suggested_resource.length > 2"
                    outlined
                    fab
                    x-small
                    color="blue"
                    v-on="on"
                    @click="!false"
                  >
                    <v-icon x-small>
                      mdi-plus
                    </v-icon>
                    {{ item.suggested_resource.slice(2,item.suggested_resource.length).length }}
                  </v-btn>
                </template>
                <v-card
                  v-show="!false"
                  class="mx-auto"
                  max-width="300"
                  raised
                >
                  <v-list
                    v-if="item.suggested_resource.length > 2"
                    disabled
                    shaped
                  >
                    <v-list-item-group
                      v-model="item.suggested_resource"
                      color="primary"
                    >
                      <v-list-item
                        v-for="resource in item.suggested_resource.slice(2,item.suggested_resource.length)"
                        v-show="!false"
                        :key="resource.id"
                      >
                        <v-avatar
                          color="blue"
                          size="30"
                        >
                          <strong class="white--text headline">{{ avatarNames(resource.full_name) }}</strong>
                        </v-avatar>
                        <v-list-item-content class="ml-2">
                          <v-list-item-title v-text="resource.full_name" />
                        </v-list-item-content>
                      </v-list-item>
                    </v-list-item-group>
                  </v-list>
                </v-card>
              </v-menu>
            </template>
            <template v-slot:item.action="{ item }">
              <v-row>
                <v-col cols="12">
                  <a href="#editDataForm"><v-img :src="editIcon" @click="editItem(item)"/></a>
                  <v-img :src="deleteIcon" @click="deleteItem(item)"/>
                </v-col>
              </v-row>
            </template>
          </v-data-table>

        </div>
        <div>
        </div>
      </div>
      <div v-else>
        <div class="requisitionRequesttabWrp">
          <div class="requisitionRequesttabeH">
            <h4>Allocate Resource <v-btn
              @click="hideForm(dirBtnLabel)"
            >
              {{ dirBtnLabel }}
              <v-icon>{{ collapseDIcon }}</v-icon>
            </v-btn> </h4>
          </div>
          <div v-if="collapseDirForm">
            <ValidationObserver ref="resourceReqObserver" v-slot="{ valid }">
              <div class="cardWrp">
                <div class="cardLeftcol">
                  <v-img :src="cardImg" class="img"/>
                </div>
                <div class="cardRightcol">
                  <v-row>
                    <v-col cols="12" sm="4">
                      <div class="field">
                        <span>Department *</span>
                      </div>
                      <ValidationProvider v-slot="{ errors }" :rules="'required'" name="defaultItem.department">
                        <v-autocomplete
                          v-model="defaultItem.department"
                          :items="allocationDepartment"
                          :error-messages="errors"
                          item-text="name"
                          item-value="id"
                          placeholder="Choose Department"
                          @change="updateResourceList"
                        />
                      </ValidationProvider>
                    </v-col>
                    <v-col cols="12" sm="4">
                      <div class="field">
                        <span>Technology *</span>
                      </div>
                      <ValidationProvider v-slot="{ errors }" :rules="'required'" name="defaultItem.technology">
                        <v-autocomplete
                          v-model="defaultItem.technology"
                          :items="technologies"
                          :error-messages="errors"
                          item-text="name"
                          item-value="id"
                          placeholder="Choose Technology"
                        />
                      </ValidationProvider>
                    </v-col>
                    <v-col cols="12" sm="4">
                      <div class="field">
                        <span>Role *</span>
                      </div>
                      <ValidationProvider v-slot="{ errors }" :rules="'required'" name="defaultItem.role">
                        <v-autocomplete
                          v-model="defaultItem.role"
                          :items="availableRoles"
                          :error-messages="errors"
                          item-text="name"
                          item-value="id"
                          placeholder="Choose Role"
                        />
                      </ValidationProvider>
                    </v-col>
                  </v-row>
                  <v-row>
                    <v-col cols="12" sm="4" class="pt-0 pb-0">
                      <div class="field">
                        <span>Daily Efforts *</span>
                      </div>
                      <ValidationProvider v-slot="{ errors }" :rules="'required|check_efforts'" name="defaultItem.efforts">
                        <v-text-field v-model.trim="defaultItem.efforts" :error-messages="errors" placeholder="Efforts (in hrs)" />
                      </ValidationProvider>
                    </v-col>
                    <v-col cols="12" sm="4" class="pt-0 pb-0">
                      <div class="field">
                        <span>Experience *</span>
                      </div>
                      <ValidationProvider v-slot="{ errors }" :rules="'required|check_experience'" name="defaultItem.experience">
                        <v-text-field v-model.trim="defaultItem.experience" :error-messages="errors" placeholder="Enter Experience(in yrs)" />
                      </ValidationProvider>
                    </v-col>
                    <v-col cols="12" sm="4" class="pt-0 pb-0">
                      <div class="field">
                        <span>Billing Type *</span>
                      </div>
                      <ValidationProvider v-slot="{ errors }" :rules="'required'" name="defaultItem.billing_type">
                        <v-select
                          v-model="defaultItem.billing_type"
                          :items="billingList"
                          :error-messages="errors"
                          item-text="name"
                          item-value="value"
                          placeholder="Choose Billing Type"
                        />
                      </ValidationProvider>
                    </v-col>
                  </v-row>
                  <v-row>
                    <v-col cols="12" sm="4">
                      <div class="field">
                        <span>Select Resource *</span>
                      </div>
                      <ValidationProvider v-slot="{ errors }" :rules="'required'" name="defaultItem.resource_id">
                        <v-autocomplete
                          v-model="defaultItem.resource_id"
                          :error-messages="errors"
                          :items="usersData.filter((user) => { return user.dept.length !== 0 && user.dept.some(value => value.id === allocatedDepartment) })"
                          item-text="full_name"
                          item-value="id"
                          placeholder="Select Resource"
                        />
                      </ValidationProvider>
                    </v-col>
                    <v-col cols="12" sm="4">
                      <div class="field">
                        <span>Estimated Allocated Duration *</span>
                      </div>
                      <div class="starttEndDatedWrp">
                        <div class="startDate allocationSD">
                          <v-menu
                            ref="start_date"
                            v-model="start_date"
                            :close-on-content-click="false"
                            offset-y
                            transition="scale-transition"
                          >
                            <template v-slot:activator="{ on }">
                              <ValidationProvider v-slot="{ errors }" :rules="'required'" name="defaultItem.start_date">
                                <v-text-field
                                  :value="defaultItem.start_date"
                                  :error-messages="errors"
                                  readonly
                                  dense
                                  v-on="on"
                                >
                                  <template v-slot:prepend-inner>
                                    <v-icon v-on="on">
                                      mdi-calendar
                                    </v-icon>
                                  </template>
                                </v-text-field>
                              </ValidationProvider>
                            </template>
                            <v-col cols="12" class="pa-0">
                              <v-date-picker
                                v-model="defaultItem.start_date"
                                :min="date_min"
                                @change="changeStartDate(defaultItem)"
                                @input="start_date = false"
                              />
                            </v-col>
                          </v-menu>
                        </div>
                        <div class="toText"><span>to</span></div>
                        <div class="endDate allocationED">
                          <v-menu
                            ref="end_date"
                            v-model="end_date"
                            :close-on-content-click="false"
                            offset-y
                            transition="scale-transition"
                          >
                            <template v-slot:activator="{ on }">
                              <ValidationProvider v-slot="{ errors }" :rules="'required'" name="defaultItem.end_date">
                                <v-text-field
                                  :value="defaultItem.end_date"
                                  :error-messages="errors"
                                  readonly
                                  dense
                                  v-on="on"
                                >
                                  <template v-slot:prepend-inner>
                                    <v-icon v-on="on">
                                      mdi-calendar
                                    </v-icon>
                                  </template>
                                </v-text-field>
                              </ValidationProvider>
                            </template>
                            <v-col cols="12" class="pa-0">
                              <v-date-picker
                                v-model="defaultItem.end_date"
                                :min="defaultItem.start_date"
                                @input="end_date = false"
                              />
                            </v-col>
                          </v-menu>
                        </div>
                      </div>
                    </v-col>
                  </v-row>
                  <v-row>
                    <v-col cols="12">
                      <div class="requisitionSBtnWrp">
                        <v-btn text class="backBtn" @click="back">
                          <v-icon small class="mr-1">mdi-arrow-left</v-icon> Back
                        </v-btn>
                        <v-btn
                          :disabled="!valid || submitted"
                          class="submitBtn"
                          text
                          @click="allocate"
                        >
                          Submit
                        </v-btn>
                      </div>
                    </v-col>
                  </v-row>
                </div>
              </div>
            </ValidationObserver>
          </div>
        </div>
        <div class="requisitionTableWrp">
          <v-data-table
            :headers="allocationHeader"
            :items="directAllocationData"
            :hide-default-footer="directAllocationData.length ? false : true"
            sort-by="calories"
            class="elevation-1"
            width="100%"
          >
            <template v-slot:item.technology="{ item }">
              <div>
                {{ item.technology }}/{{ item.role }}
              </div>
            </template>
            <template v-slot:item.efforts="{ item }">
              <div>
                {{ item.efforts }}
              </div>
            </template>
            <template v-slot:item.department="{ item }">
              <div class="pa-2">
                <span class="grey--text text--darken-4 requisitionRDetailFs"> {{ item.name }} </span> <br/>
                <span class="grey--text"> Department:</span><span> {{ item.department }} </span>
                <br/><span class="grey--text">Experience:</span> <span>{{ item.experience }} yrs</span>
                <br/><span class="blue--text mb-3"> {{ item.billing_type === 1? 'Biilable': 'Non Billable' }} </span>
              </div>
            </template>
            <template v-slot:item.start_date="{ item }">
              {{ new Date(item.start_date).toLocaleDateString('en-US', {
                year: 'numeric', month: 'short', day: 'numeric'
              }) }} - <br/> {{ new Date(item.end_date).toLocaleDateString('en-US', {
                year: 'numeric', month: 'short', day: 'numeric'
              }) }}
            </template>
            <template v-slot:item.created_at="{ item }">
              {{ new Date(item.created_at).toLocaleDateString('en-US', {
                year: 'numeric', month: 'short', day: 'numeric'
              }) }}
            </template>
          </v-data-table>
        </div>
        <div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapActions, mapGetters } from 'vuex'
import CommonSnackbar from '@/components/CommonSnackbar'
import Dialog from '@/components/Dialog.vue'
import { projectHelpers } from '@/helpers/helper.js'
import ConfirmDialog from '@/components/ConfirmDialog'
import constant from '../../constants/closure-checklist'
export default {
  name: 'ResourceRequistion',
  layout: 'authenticated',
  middleware: 'authenticated',
  components: {
    ConfirmDialog,
    Dialog,
    CommonSnackbar
  },
  async fetch ({ app, store, route }) {
    // eslint-disable-next-line no-useless-catch
    try {
      await store.dispatch('project/fetchProjectDetail', route.params.id)
    } catch (error) {
      throw (error)
    }
  },
  data () {
    return {
      currentTabIndex: 0,
      department: '',
      collapseIcon: 'mdi mdi-chevron-down',
      collapseDIcon: 'mdi mdi-chevron-down',
      reqBtnLabel: 'Add Requisition',
      dirBtnLabel: 'Add Direct Allocation',
      collapseReqForm: false,
      collapseDirForm: false,
      tabItems: [{
        id: 1,
        title: 'Requisition Management',
        content: []
      },
      {
        id: 2,
        title: 'Direct Allocation Management',
        content: []
      }],
      headers: [
        { text: 'Resource Details', value: 'department', sortable: false },
        { text: 'technology/Role', value: 'technology', sortable: false },
        { text: 'Daily Efforts (Hours)', value: 'efforts', sortable: true },
        { text: 'Estimated Duration', value: 'start_date', sortable: true },
        { text: 'Requested on', value: 'created_at', sortable: true },
        { text: 'Requested By', value: 'requested_user', sortable: true },
        { text: 'Suggested Resource', value: 'suggested_resource', sortable: false },
        { text: 'Actions', value: 'action', sortable: false, width: '10%' }
      ],
      allocationHeader:  [
        { text: 'Resource Details', value: 'department', sortable: true },
        { text: 'technology/Role', value: 'technology', sortable: true },
        { text: 'Efforts (Hours)', value: 'efforts', sortable: true },
        { text: 'Estimated Duration', value: 'start_date', sortable: true },
        { text: 'Requested on', value: 'created_at', sortable: true }
      ],
      requisitionItems: [],
      directAllocationData: [],
      editedIndex: -1,
      directAllocation: false,
      directAllocationDepartmentArray: [],
      allocationDepartment: [],
      selectedDepartment: -1,
      allocatedDepartment: -1,
      usersData: [],
      billingList: [{ name: 'Billable', value: 1 }, { name: 'Non-Billable', value: 0 }],
      submitted: false,
      editedItem: {
        department: '',
        technology: '',
        resource: '',
        efforts: '',
        experience: '',
        start_date: '',
        end_date: '',
        role: '',
        resource_id: '',
        billing_type: null,
        suggested_resource: '',
        edit: false,
        type: 0,
        isDeleted: false
      },
      defaultItem: {
        department: '',
        technology: '',
        resource: '',
        efforts: '',
        experience: '',
        start_date: '',
        end_date: '',
        role: '',
        resource_id: '',
        billing_type: null,
        suggested_resource: ''
      },
      resourceAllocationMeta: [],
      overBookResourceArray: [],
      overBookText: '',
      overBookDialog: false,
      snackbarValue: false,
      snackbarText: '',
      projectName: '',
      start_date: false,
      end_date: false,
      date_min: '',
      date_max: '',
      projectActionSelected: 'resource-requisition',
      seletedResources: []
    }
  },
  computed: {
    ...mapGetters({
      technologies: 'project/getTechnologies',
      departments: 'project/getDepartments',
      // projects: 'project/getProjectList',
      users: 'project/getUserList',
      projectDetail: 'project/getProjectDetail',
      isButtonLoading: 'project/isButtonLoading',
      availableRoles: 'roles/availableRoles',
      getGlobalRole: 'roles/getGlobalRole',
      getDirectCreatedAllocation: 'project/getDirectCreatedAllocation'
    }),
    cardImg () {
      return require('@/assets/images/custom/requisition.png')
    },
    editIcon () {
      return require('@/assets/images/feather-edit-2.png')
    },
    deleteIcon () {
      return require('@/assets/images/noun_Delete.png')
    }
  },
  created () {
    this.initialize()
  },
  mounted () {
    this.projectName = this.projectDetail.project_name
    this.date_min = this.projectDetail.estimated_timeline_from
    this.date_max = this.projectDetail.estimated_timeline_to
    const today = new Date()

    this.editedItem.start_date = this.formatDate(today)
    this.editedItem.end_date = this.formatDate(today)
    this.defaultItem.start_date = this.formatDate(today)
    this.defaultItem.end_date = this.formatDate(today)
    if (this.projectDetail.direct_allocation_department.length > 0) {
      this.directAllocation = true
      this.directAllocationDepartmentArray = this.projectDetail.direct_allocation_department
      this.allocationDepartment = this.departments.filter((item) => this.directAllocationDepartmentArray.includes(item.id))
    }
    this.usersData = this.users
    const metaRecord = []

    this.projectDetail.resource_requisition.forEach((item) => {
      item.resource_allocation.forEach((element) => {
        if (element.mapped_resource !== null) {
          element.resource_allocation_meta.forEach((meta) => {
            if (metaRecord[meta.resource_id]) {
              metaRecord[meta.resource_id].push(meta)
            } else {
              metaRecord[meta.resource_id] = [meta]
            }
          })
        }
      })
    })
    const requisitionRecord = Object.assign([], this.projectDetail.resource_requisition)

    this.mutateNewRequisition(requisitionRecord)
    this.resourceAllocationMeta = metaRecord
    this.tabAccess()
  },
  methods: {
    ...mapActions({
      setCreatedProjectData: 'project/setCreatedProjectData',
      setResourceRequisitionData: 'project/setResourceRequisitionData',
      setCustomDialog: 'project/setCustomDialog',
      updateLoadingAction: 'project/updateLoadingAction',
      setDirectResourceAllocationData: 'project/setDirectResourceAllocationData',
      setDirectAllocation: 'project/setDirectAllocation',
      editRequisitionAction: 'project/editRequisitionAction'
    }),
    back () {
      this.$router.push('/project-dashboard')
    },
    tabAccess() {
      let arAccess = false
      let daAccess = false
      const buHeadRole = this.getGlobalRole.some((role) => role.role_id === constant.ROLE_ID.BU_HEAD)

      this.getGlobalRole.forEach((role) => {
        if (role.role_id === constant.ROLE_ID.ADMIN ||
        (buHeadRole && (role.role_id === constant.ROLE_ID.ACCOUNT_MANAGER || role.role_id === constant.ROLE_ID.PROJECT_MANAGER))) {
          daAccess = true
          arAccess = true
        }
        if (role.role_id === constant.ROLE_ID.GLOBAL_OPERATION || role.role_id === constant.ROLE_ID.GO_TEAM  || role.role_id === constant.ROLE_ID.SALES ||
            role.role_id === constant.ROLE_ID.ACCOUNT_MANAGER || role.role_id === constant.ROLE_ID.PROJECT_MANAGER) {
          arAccess = true
        }
      })

      // check access of the direct allocation and add requisition
      if (arAccess && daAccess) {
        return this.tabItems
      } else if (arAccess && !daAccess) {
        this.tabItems.pop()

        return this.tabItems
      } else {
        this.tabItems.shift()

        return this.tabItems
      }
    },
    hideForm () {
      if (Number(this.tabItems[this.currentTabIndex].id) === 1) {
        if (this.reqBtnLabel === 'Add Requisition') {
          this.collapseReqForm = true
          this.reqBtnLabel = 'Collapse'
          this.collapseIcon = 'mdi mdi-chevron-up'
        } else {
          this.collapseReqForm = false
          this.reqBtnLabel = 'Add Requisition'
          this.collapseIcon = 'mdi mdi-chevron-down'
        }
      } else {
        if (this.dirBtnLabel === 'Add Direct Allocation') {
          this.collapseDirForm = true
          this.dirBtnLabel = 'Collapse'
          this.collapseDIcon = 'mdi mdi-chevron-up'
        } else {
          this.collapseDirForm = false
          this.dirBtnLabel = 'Add Direct Allocation'
          this.collapseDIcon = 'mdi mdi-chevron-down'
        }
      }
    },
    initialize () {
      this.requisitionItems = []
    },
    editItem (item) {
      const eidtedRecord = {
        uuid: item.uuid,
        department: item.department.id,
        technology: item.technology.id,
        resource: item.resource,
        efforts: item.efforts,
        experience: item.experience,
        start_date: this.formatDate(item.start_date),
        end_date: this.formatDate(item.end_date),
        role: item.role.id,
        resource_id: item.resource_id,
        billing_type: item.billing_type,
        suggested_resource: item.suggested_resource,
        edit: true,
        type: item.type,
        isDeleted: false
      }

      this.editedItem = eidtedRecord
      this.selectedDepartment = this.editedItem.department
      this.seletedResources = this.editedItem.suggested_resource
      this.collapseReqForm = true
      this.reqBtnLabel = 'Collapse'
      this.collapseIcon = 'mdi mdi-chevron-up'
    },
    deleteItem (item) {
      this.$refs.confirm.open('Delete Requisition', 'Are you sure you want to delete?', { color: 'red' }).then((confirm) => {
        if (confirm) {
          const eidtedRecord = {
            uuid: item.uuid,
            department: item.department.id,
            technology: item.technology.id,
            resource: item.resource,
            efforts: item.efforts,
            experience: item.experience,
            start_date: item.start_date,
            end_date: item.end_date,
            role: item.role.id,
            resource_id: item.resource_id,
            billing_type: item.billing_type,
            suggested_resource: item.suggested_resource,
            edit: item.edit,
            type: item.type,
            isDeleted: true
          }

          this.editedItem = eidtedRecord
          const actionType = 'delete'

          this.submit(false, actionType)
        }
      })
    },
    exactCountSuggested () {
      this.seletedResources = []
      const suggestedNumber = this.editedItem.suggested_resource

      if (this.editedItem.resource !== '' && suggestedNumber.length > this.editedItem.resource) {
        this.editedItem.suggested_resource = suggestedNumber.slice(suggestedNumber.length - this.editedItem.resource)
      }
      const users = []

      this.users.forEach((user) => {
        users.push({
          full_name : user.full_name,
          id: user.id
        })
      })
      if (this.editedItem.suggested_resource && this.editedItem.suggested_resource.length > 0) {
        this.editedItem.suggested_resource.forEach((id) => {
          const resource = users.filter((item) => { return item.id === id })

          this.seletedResources.push(resource[0])
        })
      }
    },
    mutateNewRequisition (data) {
      let suggestedResources = []

      this.requisitionItems = []
      if (data) {
        data.forEach((value) => {
          let suggested = []
          const type = Object.prototype.toString.call(value.suggested_resource)

          if (value.suggested_resource && value.suggested_resource !== null && value.suggested_resource !== '' && type !== '[object Number]') {
            if (value.suggested_resource.startsWith('[') && value.suggested_resource.endsWith(']')) {
              suggested = JSON.parse(value.suggested_resource)
            }
          }

          const type2 = Object.prototype.toString.call(suggested)

          suggestedResources = []
          if (suggested && suggested !== null && (type2 !== '[object Number]' && type2 !== '[object String]')) {
            suggested.map((id) => {
              this.users.forEach((item) => {
                if (id === item.id && value.type === 0) {
                  suggestedResources.push({
                    full_name: item.full_name,
                    id: item.id
                  })
                }
              })
            })
          }
          this.users.forEach((item) => {
            if (value.extension_resource_id !== null && value.extension_resource_id === item.id && value.type === 1) {
              suggestedResources.push({
                full_name: item.full_name,
                id: item.id
              })
            }
          })
          if (value.status === '0' && !value.resource_allocation.length && (value.type === 0 || value.type === 1)) {
            this.requisitionItems.push({
              uuid: value.uuid,
              technology: value.technology,
              role: value.designation,
              created_at: value.created_at,
              start_date: value.start_date,
              end_date: value.end_date,
              extension_resource_id: value.extension_resource_id,
              experience: value.experience,
              department: value.department,
              billing_type: value.billing_type,
              efforts: value.efforts,
              resource: value.no_of_resource,
              requested_user: value.requested_user.display_name,
              type: value.type,
              edit: false,
              isDeleted: value.isDeleted,
              suggested_resource: suggestedResources
            })
          }
          if (value.status === '1' && value.resource_allocation.length && value.direct_requisition !== null & (value.type === 1 || value.type === 0)) {
            this.mutateDirectAllocation(value)
          }
        })
      }
    },
    mutateDirectAllocation (data) {
      const directArray = [data]

      if (directArray) {
        directArray.forEach((value) => {
          if ( value.resource_allocation[0].resource_allocation_meta[0] && (value.resource_allocation[0].mapped_resource === null || value.resource_allocation[0].mapped_resource.status === 0)) {
            const name = value.resource_allocation[0].resource_allocation_meta[0].resource.display_name

            this.directAllocationData.push({
              technology: value.technology.name,
              role: value.designation.name,
              created_at: value.created_at,
              start_date: value.start_date,
              end_date: value.end_date,
              name,
              experience: value.experience,
              department: value.department.name,
              billing_type: value.billing_type,
              efforts: value.efforts
            })
          }
        })
      }
    },
    avatarNames (fullName) {
      fullName =  fullName.replace(/[^a-zA-Z]/g, ' ')

      return projectHelpers.avatarNames(fullName.trim())
    },
    formatDate (date) {
      const d = new Date(date)
      let month = '' + (d.getMonth() + 1)
      let day = '' + d.getDate()
      const year = d.getFullYear()

      if (month.length < 2) { month = '0' + month }
      if (day.length < 2) { day = '0' + day }

      return [year, month, day].join('-')
    },
    changeStartDate (item) {
      if (item.start_date > item.end_date) {
        item.end_date = item.start_date
      }
    },
    updateResourceList () {
      this.selectedDepartment = this.editedItem.department
      this.allocatedDepartment = this.defaultItem.department
    },
    save () {
      const actionType = this.editedItem.edit ? 'edit' : 'add'

      this.submit(false, actionType)
    },
    async allocate () {
      const actionType = 'allocate'

      this.submit(false, actionType)
    },
    checkResourceOverbooking (data, resourceId, startDate, endDate, hours) {
      let response = false
      let allocatedHours = parseFloat(hours)

      if (data[resourceId]) {
        data[resourceId].forEach((item) => {
          if (item.resource_id === resourceId) {
            if ((new Date(startDate)).getTime() >= (new Date(item.start_date)).getTime() && (new Date(startDate)).getTime() <= (new Date(item.end_date)).getTime()) {
              allocatedHours = allocatedHours + parseFloat(item.hours)
            } else if ((new Date(endDate)).getTime() >= (new Date(item.start_date)).getTime() && (new Date(endDate)).getTime() <= (new Date(item.end_date)).getTime()) {
              allocatedHours = allocatedHours + parseFloat(item.hours)
            }
          }
        })
        if (allocatedHours > 8) {
          response = true
        }
      }

      return response
    },
    async submit (type = false, actionType) {
      this.updateLoadingAction()
      const requisitionData = []
      const allocationData = []
      const commonMsg = ''

      if (this.directAllocationData.length > 0) {
        const resourceIdArray = []
        // let isSameResource = false
        const resourceOverbookResource = []

        this.directAllocationData.forEach((row) => {
          if (!resourceIdArray.includes(row.resource_id)) {
            resourceIdArray.push(row.resource_id)
          } else {
            // isSameResource = true
          }
          const overbook = this.checkResourceOverbooking(this.resourceAllocationMeta, row.resource_id, row.start_date, row.end_date, row.daily_effort)

          if (overbook) {
            resourceOverbookResource.push(row.resource_id)
          }
        })
        // if (isSameResource) {
        //   this.snackbarText = 'Same Resource exist in multiple direct allocation'
        //   this.snackbarValue = true
        //   setTimeout(() => {
        //     this.snackbarValue = false
        //   }, 3000)

        //   return
        // }
        this.overBookResourceArray = resourceOverbookResource
        if (resourceOverbookResource.length > 0 && !type) {
          this.overBookText = 'The selected resource is already allocated on the project for the same duration and efforts which may lead to creating duplicate bookings. Do you still want to continue?'
          this.overBookDialog = true

          return false
        } else {
          this.overBookDialog = false
        }
      }
      if (actionType === 'add') {
        requisitionData.push({
          'dept_id': this.editedItem.department,
          'tech_id': this.editedItem.technology,
          'no_of_resource': this.editedItem.resource,
          'efforts': this.editedItem.efforts,
          'experience': this.editedItem.experience,
          'start_date': this.editedItem.start_date,
          'end_date': this.editedItem.end_date,
          'role_id': this.editedItem.role,
          'billing_type': this.editedItem.billing_type,
          'suggested_resource': this.editedItem.suggested_resource
        })
        let requisitionMsg = ''

        if (requisitionMsg === '') {
          requisitionMsg = 'The resource requisition request has been successfully submitted.'
        }
        const requestData = {
          project_id: this.$route.params.id,
          resource_data: requisitionData,
          project_status: 3,
          message: requisitionMsg
        }

        await this.setResourceRequisitionData(requestData)
      }
      if (actionType === 'edit' || actionType === 'delete') {
        const suggestedResources = []

        this.editedItem.suggested_resource.forEach((resource) => {resource.id ? suggestedResources.push(resource.id) : suggestedResources.push(resource)})
        requisitionData.push({
          'dept_id': this.editedItem.department,
          'tech_id': this.editedItem.technology,
          'no_of_resource': this.editedItem.resource,
          'efforts': this.editedItem.efforts,
          'experience': this.editedItem.experience,
          'start_date': this.editedItem.start_date,
          'end_date': this.editedItem.end_date,
          'role_id': this.editedItem.role,
          'billing_type': this.editedItem.billing_type,
          'suggested_resource': suggestedResources,
          'resource_requisition_uuid': this.editedItem.uuid,
          'isDelete': this.editedItem.isDeleted
        })
        const requestData = {
          project_id: this.$route.params.id,
          resource_data: requisitionData,
          project_status: 3
        }

        await this.editRequisitionAction(requestData)

      }
      if (actionType === 'allocate') {
        allocationData.push({
          'dept_id': this.defaultItem.department,
          'tech_id': this.defaultItem.technology,
          'resource_id': this.defaultItem.resource_id,
          'efforts': this.defaultItem.efforts,
          'experience': this.defaultItem.experience,
          'start_date': this.defaultItem.start_date,
          'end_date': this.defaultItem.end_date,
          'role_id': this.defaultItem.role,
          'billing_type': this.defaultItem.billing_type
        })

        const allocateMsg = 'The Direct Allocation request has been successfully submitted.'
        const requestData = {
          project_id: this.$route.params.id,
          allocation_data: allocationData,
          message: allocateMsg
        }

        await this.setDirectResourceAllocationData(requestData)
      }
      this.updateLoadingAction()
      this.submitted = true
    }
  }
}

</script>

<style scoped>
.v-text-field__slot >>> .theme--light.v-label--is-disabled {
   color: rgba(0, 0, 0, 0.6);
   font-size: 18px
}
.breadcrumbWrp ul li:last-child button.v-btn {
    font-size: 12px;
    padding: 10%;
}
.cardWrp {
    display: flex;
    align-items: center;
    justify-content: space-between;
    min-height: 310px;
}
.cardLeftcol {
    width: 30%;
    padding: 0 20px 0 0;
}
.cardRightcol {
    width: 70%;
    padding: 20px;
}
.img {
  background-position: inherit;
  height: 150;
  width: 150;
}
.icon {
  background-position: inherit;
  height: 50;
  width: 50;
}
.v-chip.v-size--default {
    font-size: smaller;
    height: auto;
}
.v-application .headline {
    font-size: 1rem !important;
    font-weight: 400;
    line-height: 2rem;
    letter-spacing: normal !important;
    font-family: "Open Sans", sans-serif !important;
}
</style>
