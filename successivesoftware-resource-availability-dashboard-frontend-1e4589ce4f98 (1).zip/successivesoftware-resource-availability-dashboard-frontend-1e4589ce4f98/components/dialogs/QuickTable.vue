<template>
  <v-card v-click-outside="onClickOutside" class="timeSheetTableWrp">
    <v-list v-for="{items, id, titleColor, code, status, showCollapse, showExpand, isDisabled} in quickTablesData" :key="id">
      <v-list-item class="timeSheetTableitem">
        <v-data-table
          :headers="headers" 
          :items="items" 
          hide-default-footer
          disable-pagination
          :single-expand="singleExpand"
          :show-expand="expandRow"
          item-key="id"
          class="elevation-0 text-capitalize timeSheetTable"
        >
          <template v-slot:top>
            <v-row>
              <v-col cols="8" class="pt-1 pb-0">
                <h5 class="sheetStatusH"> {{ mainTitle }}:  <span :class="titleColor"><b>{{ status }}</b></span></h5>
              </v-col>
              <v-col v-show="showExpand" cols="4" class="pt-0 pb-0 text-center">
                <v-btn
                  :disabled="isDisabled"
                  text
                  :class="isDisabled === true? 'text-capitalize grey--text pa-2 expdClps': 'text-capitalize blue--text pa-2 expdClps'"
                  small
                  @click="expandTable(showExpand, status)"
                >
                  Expand
                </v-btn>
              </v-col>
              <v-col v-show="showCollapse" cols="4" class="pt-0 pb-0 text-center">
                <v-btn text class="text-capitalize blue--text pa-2 expdClps" small @click="collapseTable(showCollapse, status)">
                  Collapse
                </v-btn>
              </v-col>
            </v-row>
          </template>
          <template v-slot:item.status="{item}">
            <span :class="titleColor"> {{ item.status }} </span>
          </template>
          <template v-slot:expanded-item="{headers, item}">
            <td :colspan="headers.length +1" class="px-0">
              <v-simple-table>
                <template v-slot:default>
                  <thead>
                    <tr>
                      <th />
                      <th />
                      <th>Project name</th>
                      <th>Hours</th>
                      <th>Spent Date</th>
                      <th />
                      <th />
                    </tr>
                  </thead>
                  <tbody>
                    <template v-for="(data, index) in item.projectInfo">
                      <tr :key="index">
                        <td />
                        <td />
                        <td>{{ data.ProjectName }}</td>
                        <td>{{ Number.isInteger(data.Hours) ? data.Hours: data.Hours.toFixed(2) }}</td>
                        <td>{{ data.SpentDate }}</td>
                        <td />
                        <td />
                      </tr>
                    </template>
                  </tbody>
                </template>
              </v-simple-table>
            </td>
          </template>
          <template v-slot:item.Hours="{item}">
            {{ Number.isInteger(item.Hours) ? item.Hours: item.Hours.toFixed(2) }}
          </template>
          <template v-slot:item.LastInvoiceDate="{item}">
            {{ item.LastInvoiceDate === 'NaN/NaN/NaN' ? '': item.LastInvoiceDate }}
          </template>
        </v-data-table>
        <div v-show="code === 'is' && (quickTablesData.length === 1 && items.length === 1)">
          <v-list-item
            v-for="status in invoiceStatus"
            :key="status"
          >
            <v-list-item-content>
              <v-list-item-title class="blue--text"><span class="grey--text">Invoice Status:</span> {{ status }}</v-list-item-title>
            </v-list-item-content>
          </v-list-item>
        </div>
      </v-list-item>
    </v-list>
  </v-card>
</template>

<script>
export default {
  name: 'QuickTable',
  props: {
    quickTables: {
      type: Array,
      default: () => ([])
    },
    headers: {
      type: Array,
      default: () => ([])
    },
    mainTitle: {
      type: String,
      default: ''
    },
    singleExpand: {
      type: Boolean,
      default: true
    },
    expandRow: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      quickTablesData: this.defaultData().data,
      invoiceStatus: ['Pending','Draft','Estimate','Sent','Paid','Cancelled']
    }
  },
  methods: {
    expandTable (showExpnd, status) {
      const expandedTable = []

      this.quickTables.forEach((element) => {
        let allItems = []
        let syncStatus = ''

        if (element.showExpand === showExpnd && status === element.status) {
          element.showExpand = false
          element.showCollapse = true
        }
        if (element.status !== status) {
          element.showCollapse = false
          element.showExpand = true
        }
        if (element.status === status && element.items.length > 2) {
          allItems = element.items
          syncStatus = element.status
        } else {
          allItems = element.items.slice(0, 2)
          syncStatus = element.status
        }
        const { id, titleColor, showCollapse, showExpand, isDisabled, code } = element

        expandedTable.push({
          id,
          titleColor,
          status: syncStatus,
          showCollapse,
          showExpand,
          items: allItems,
          isDisabled,
          code
        })
      })
      this.quickTablesData = expandedTable
    },
    collapseTable (showClpse, status) {
      const expandedTable = []

      this.quickTablesData.forEach((element) => {
        let allItems = []
        let syncStatus = ''

        if (element.showCollapse === showClpse && status === element.status) {
          element.showExpand = true
          element.showCollapse = false
        }
        if (element.status === status && element.items.length > 2) {
          allItems = element.items.slice(0, 2)
          syncStatus = element.status
        } else {
          allItems = element.items
          syncStatus = element.status
        }
        const { id, titleColor, showCollapse, showExpand, isDisabled, code } = element

        expandedTable.push({
          id,
          titleColor,
          status: syncStatus,
          showCollapse,
          showExpand,
          items: allItems,
          isDisabled,
          code
        })
      })
      this.quickTablesData = expandedTable
    },
    defaultData() {
      const data = []

      if (this.quickTables) {
        this.quickTables.forEach((element) => {
          if (element.items.length <= 2) {
            data.push({
              id: element.id,
              titleColor: element.titleColor,
              status: element.status,
              showCollapse: element.showCollapse,
              showExpand: element.showExpand,
              items: element.items,
              isDisabled: element.isDisabled,
              code: element.code
            })
          }  else {
            const items = element.items.slice(0, 2)

            data.push({
              id: element.id,
              titleColor: element.titleColor,
              status: element.status,
              showCollapse: element.showCollapse,
              showExpand: element.showExpand,
              items: items,
              isDisabled: element.isDisabled,
              code: element.code
            })
          }
        })
      }

      return { data }
    },
    onClickOutside () {
      const data = []

      if (this.quickTables) {
        this.quickTables.forEach((element) => {
          if (element.showCollapse === true) {
            element.showExpand = true
            element.showCollapse = false
          }
          if (element.items.length <= 2) {
            data.push({
              id: element.id,
              titleColor: element.titleColor,
              status: element.status,
              showCollapse: element.showCollapse,
              showExpand: element.showExpand,
              items: element.items,
              isDisabled: element.isDisabled,
              code: element.code
            })
          }  else {
            const items = element.items.slice(0, 2)

            data.push({
              id: element.id,
              titleColor: element.titleColor,
              status: element.status,
              showCollapse: element.showCollapse,
              showExpand: element.showExpand,
              items: items,
              isDisabled: element.isDisabled,
              code: element.code
            })
          }
        })
      }

      return this.quickTablesData = data
    }
  }
}
</script>

<style scoped>
>>>.v-data-table-header {
    box-shadow: none !important;
    color: white;
    border-radius: inherit;
}
.timeSheetTableWrp.v-list-item.theme--light {
    display: block;
}

.timeSheetTableWrp {
    padding: 30px 0 0;
    box-shadow: none !important;
}

.timeSheetTableitem.v-list-item.theme--light {
    display: block;
    padding: 0;
}

h5.sheetStatusH {
    font-size: 18px;
    text-align: left;
    color: #707070;
    font-weight: 400;
    font-style: normal;
    letter-spacing: normal;
    line-height: normal;
    margin-bottom: 20px;
}

.timeSheetTableWrp .v-list.v-sheet.theme--light {
    padding: 20px 0 20px;
}

.timeSheetTable {
    border-bottom: 1px solid #dcdbe0;
    border-radius: 0;
}

.v-application .yellow--text {
    color: #d6c52c !important;
    caret-color: #d6c52c !important;
}

.v-application .red--text {
    color: #dd1515 !important;
    caret-color: #dd1515 !important;
}

button.text-capitalize.blue--text.pa-2.expdClps {
    color: #1976d2 !important;
    font-size: 13px;
    font-weight: 400;
    font-style: normal;
    letter-spacing: normal;
    line-height: normal;
    height: auto;
    padding: 10px 16px !important;
}
</style>