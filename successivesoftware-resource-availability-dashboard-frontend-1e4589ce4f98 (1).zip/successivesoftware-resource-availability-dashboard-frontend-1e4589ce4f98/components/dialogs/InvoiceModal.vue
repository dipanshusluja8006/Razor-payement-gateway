<template>
  <div class="timeSheetWrp">
    <Dialog />
    <div class="timeSheetH">
      <h4>{{ title }}</h4>
      <p>{{ subTitle }}</p>
    </div>
    <div class="timeSheetAct">
      <v-card-actions>
        <v-btn
          v-show="showBtn"
          color="primary"
          :disabled="sent === true || btnAccess === false"
          @click="sendReminder"
        >
          <span v-if="sentMessage === 'Send Reminder'">
            {{ sentMessage }}
          </span>
          <span v-else>
            {{ sentMessage }}
            <v-icon right dark>
              mdi-check
            </v-icon>
          </span>
        </v-btn>
      </v-card-actions>
    </div>
  </div>
</template>

<script>
import { mapActions } from 'vuex'
import Dialog from '../Dialog.vue'
import { EventBus } from '.././event-bus.js'
export default {
  name: 'InvoiceModal',
  components: { Dialog },
  props: {
    title: {
      type: String,
      default: ''
    },
    buttonText: {
      type: String,
      default: ''
    },
    subTitle: {
      type: String,
      default: ''
    },
    showBtn: {
      type: Boolean,
      default: false
    },
    tsData: {
      type: Array,
      default: () => []
    },
    isData: {
      type: Array,
      default: () => []
    },
    userRoleObject: {
      type: Object,
      default: () => ({})
    }
  
  },
  data() {
    return {
      sent: false,
      sentMessage: this.buttonText,
      userRoleUpdate: {},
      isDataArray: [],
      tsDataArray: [],
      tsDisplay: false,
      isDisplay: false,
      btnAccess:false
    }
  },
  watch: {
    userRoleObject() {
      this.userRoleUpdate = this.userRoleObject
    },
    isData() {
      this.isDataArray = this.isData
      this.invoiceCheck()
    },
    tsData() {
      this.tsDataArray = this.tsData
      this.timesheetCheck()
    }
  },
  mounted() {
    this.isDataArray = this.isData
    this.tsDataArray = this.tsData
    this.userRoleUpdate = this.userRoleObject
    this.invoiceCheck()
    this.timesheetCheck()
      
    EventBus.$on('invoiceStatusActive', (data) => { 
      data !== 'Pending' ?  this.btnAccess = false :  this.btnAccess = true
    })
  },

  methods: {
    ...mapActions({
      sendTimeSheetReminder: 'dashboard/sendTimeSheetReminder',
      sendInvoiceReminder: 'dashboard/sendInvoiceReminder',
      updateUserRole: 'roles/updateUserRole'
    }),
    invoiceCheck() {
      const dataInvoice = this.isDataArray

      if (dataInvoice && this.title === 'Invoice Status Details') {
        const statusArray = []
        let statusLength = false
      
        dataInvoice.forEach((values) => {
          statusArray.push(values.status)
          if (values.items.length > 0 && values.status === 'Pending') {
            this.btnAccess = true
            statusLength = true
          }
        })
        if (statusArray.includes('Pending') && statusLength === true) {
          this.sent = false
        } else {
          this.sent = true
        }
        this.sentMessage = 'Send Reminder'
      }
    },
    timesheetCheck() {
      const timesheetData = this.tsDataArray

      if (this.title === 'Timesheet Details') {
        const statusArray = []
        let statusLength = false

        timesheetData.forEach((values) => {
          statusArray.push(values.status)
          if (values.items.length > 0 && values.status === 'Pending') {
            statusLength = true
          }
        })
        if (statusArray.includes('Pending') && statusLength === true) {
          this.sent = false
        } else {
          this.sent = true
        }
        this.sentMessage = 'Send Reminder'
      }
    },
    async sendReminder() {
      // Timesheet reminder
      if (this.title === 'Timesheet Details') {
        const timesheetData = this.tsDataArray

        if (timesheetData) {
          const userIds = []

          timesheetData.forEach((values) => {
            if (values.status === 'Pending') {
              if (values.items) {
                values.items.forEach((item) => {
                  userIds.push(item.UsersId)
                })
              }
            }
          })
          await this.sendTimeSheetReminder(userIds)
          this.sentMessage = 'Reminder Sent'
          this.sent = true
        }
      } else if (this.title === 'Invoice Status Details') {
        // invoice reminder
        const dataInvoice = this.isDataArray

        if (dataInvoice) {
          const projectIds = []

          dataInvoice.forEach((values) => {
            if (values.status === 'Pending') {
              if (values.items) {
                values.items.forEach((item) => {
                  projectIds.push(item.ProjectID)
                })
              }
            }
          })
          await this.sendInvoiceReminder(projectIds)
          this.sentMessage = 'Reminder Sent'
          this.sent = true
        }
      } else {
        // Change User Role
        const requestData = this.userRoleObject

        await this.updateUserRole(requestData)
        this.sentMessage = 'Role Updated Successfully!'
        this.sent = true
        window.location.reload()
      }
    }
  }
}
</script>

<style scoped>
.dialog-text {
  font-size: small;
  font-weight: 100 !important;
  color: grey;
}
.timeSheetWrp {
  display: flex;
  justify-content: space-between;
  padding: 20px 30px 0;
  border-bottom: 1px solid #bab9c2;
}

.timeSheetH h4 {
  color: #707070;
  font-size: 28px;
  font-weight: 700;
  text-align: left;
  font-style: normal;
  letter-spacing: normal;
  line-height: normal;
  border-bottom: 1px solid #707070;
  padding: 0 0 10px;
  margin-bottom: 10px;
  display: inline-block;
  min-width: 70%;
}

.timeSheetH p {
  color: #707070;
  font-size: 13px;
  font-weight: 400;
  text-align: left;
  font-style: normal;
  letter-spacing: normal;
  line-height: normal;
}

.timeSheetAct
  button.v-btn.v-btn--is-elevated.v-btn--has-bg.theme--light.v-size--default.primary {
  border-radius: 8px;
  background-color: #1976d2 !important;
  color: #ffffff;
  font-size: 16px;
  font-weight: normal;
  text-align: center;
  font-style: normal;
  letter-spacing: normal;
  line-height: normal;
  padding: 7px 30px;
  height: auto;
}
</style>
