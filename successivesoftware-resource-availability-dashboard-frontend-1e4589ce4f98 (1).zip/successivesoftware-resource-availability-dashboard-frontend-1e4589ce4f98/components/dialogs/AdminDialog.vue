<template class="aab">

  <div class="userEditModalWrp">
    <v-card>
      <ValidationObserver ref="resourceReqObserver" v-slot="{ valid }">
        <common-snackbar :text-for-snackbar="snackbarText" :snackbar="snackbarValue" />
        <div class="timeSheetWrp">
          <Dialog />
          <div class="timeSheetH">
            <h4>{{ title }}</h4>
          </div>
          <div class="timeSheetAct">
            <v-card-actions>
              <v-btn
                v-show="showBtn"
                color="primary"
                :disabled="!valid || sent === true"
                @click="save"
              >
                {{ message }}
              </v-btn>
            </v-card-actions>
          </div>
        </div>
        <v-card-text>
          <div class="userEdtFieldOuterWrp">
            <div class="userEdtFieldWrp">
              <div class="field">
                <strong>Department</strong>
              </div>
              <v-text-field
                v-model.trim="userData.department"
                dense
                readonly
                placeholder="Department"
              />
            </div>
            <div class="userEdtFieldWrp">
              <div class="field">
                <strong>Name</strong>
              </div>
              <v-text-field
                v-model.trim="userData.name"
                dense
                readonly
                placeholder="Name"
              />
            </div>
            <div class="userEdtFieldWrp">
              <div class="field">
                <strong>Email</strong>
              </div>
              <v-text-field
                v-model.trim="userData.email"
                dense
                readonly
                placeholder="Email"
              />
            </div>
            <div class="userEdtFieldWrp">
              <div class="field">
                <strong>Default Role(s)</strong>
              </div>
              <v-chip-group
                active-class="primary--text"
                column
              >
                <v-chip
                  v-for="(defaultRole,index) in userData.defaultRole"
                  :key="index"
                  disabled
                >
                  {{ defaultRole }}
                </v-chip>
              </v-chip-group>
            </div>
            <div class="userEdtFieldWrp">
              <div v-if="action === 'view' && globalRoleArray.length > 0">
                <div class="field">
                  <strong>Global Role(s)</strong>
                </div>
                <v-chip-group
                  active-class="primary--text"
                  column
                >
                  <v-chip
                    v-for="(globalRole,index) in globalRoleArray"
                    :key="index"
                    disabled
                  >
                    {{ globalRole }}
                  </v-chip>
                </v-chip-group>
              </div>
              <div v-else-if="action === 'edit'">
                <div class="field editField">
                  <strong>Global Role(s)</strong>
                </div>
                <div class="globalRoleWrp">
                  <div
                    v-for="role in roles"
                    :key="role.id"
                    class="globalRole"
                  >
                    <div v-if="role.dept.length <= 0 || !selectedRoles.includes(buHead)" class="globalRole">
                      <v-checkbox
                        v-model="selectedRoles"
                        :label="role.role"
                        :value="role.id"
                        @change="globalRoleCheck($event,role.id, 'no')"
                      ></v-checkbox>
                    </div>
                    <div v-else-if="selectedRoles.includes(buHead)">
                      <v-checkbox
                        v-model="selectedRoles"
                        :label="'Bu Head'"
                        :value="7"
                        class="globalRole"
                        @change="removeAllDepts"
                      ></v-checkbox>
                      <div
                        v-for="(dept, index) in role.dept"
                        :key="index"
                        class="globalRole"
                      >
                        <v-checkbox
                          v-model="selectedBuHead"
                          :label="`BU Head: ${dept.name}`"
                          :value="dept.id"
                          @change="globalRoleCheck($event,dept.id, 'yes')"
                        ></v-checkbox>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div v-if="action === 'edit' && selectedRoles.includes(buHead)" class="userEdtFieldWrp">
              <div class="field">
                <strong>Department *</strong>
              </div>
              <ValidationProvider
                v-slot="{ errors }"
                :rules="'required'"
                name="selectedDepartment"
              >
                <v-autocomplete
                  v-model="selectedDepartment"
                  :items="departments"
                  :error-messages="errors"
                  multiple
                  placeholder="Please select department for BU Head"
                  item-text="name"
                  item-value="id"
                  dense
                  @change="addBuHeadDept(selectedDepartment, errors)"
                />
              </ValidationProvider>
            </div>
          </div>
        </v-card-text>
      </ValidationObserver></v-card>
  </div>
</template>
<script>
import { mapActions, mapGetters } from 'vuex'
import constant from '@/constants/closure-checklist.js'
import CommonSnackbar from '../CommonSnackbar'

export default {
  name: 'CustomDialog',
  components:{ CommonSnackbar },
  props: {
    userData: {
      type: Object,
      default: () => ({})
    },
    roles: {
      type: Array,
      default: () => ([])
    },
    action: {
      type: String,
      default: ''
    },
    title: {
      type: String,
      default: ''
    },
    buttonText: {
      type: String,
      default: ''
    },
    showBtn: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      selectedRoles: [],
      buHead: constant.ROLE_ID.BU_HEAD,
      userDetails: {},
      selectedDepartment: [],
      selectedBuHead: [],
      removeDeptIds: [],
      removeRoleIds: [],
      userRoleObeject: {},
      userId: null,
      validateDept: true,
      message: this.buttonText,
      sent: false,
      globalRoleArray: [],
      snackbarText: '',
      snackbarValue: false
    }
  },
  watch: {
    userData () {
      this.userDetails = this.userData
      this.globalRoleView()
      this.selectedRoles = this.userData.editableRoleIds
      this.selectedBuHead = this.userData.deptIds
      this.selectedDepartment = this.userData.deptIds
      this.userId = this.userData.id
    }
  },
  computed: {
    ...mapGetters({
      departments: 'project/getDepartments',
      getGlobalRole: 'roles/getGlobalRole'
    })
  },
  mounted() {
    this.userDetails = this.userData
    this.selectedRoles = this.userData.editableRoleIds
    this.selectedBuHead = this.userData.deptIds
    this.selectedDepartment = this.userData.deptIds
    this.userId = this.userData.id
    this.updateUserRoleObject()
    this.globalRoleView()
  },
  methods: {
    ...mapActions({
      updateUserRole: 'roles/updateUserRole'
    }),
    updateUserRoleObject () {
      this.userRoleObeject = {
        'userId': this.userId,
        'addRoleIds': this.selectedRoles,
        'removeRoleIds': this.removeRoleIds,
        'addDeptIds': this.selectedDepartment,
        'removeDeptIds': this.removeDeptIds
      }
    },
    removeAllDepts () {
      if (this.selectedBuHead.length > 0) {
        this.removeDeptIds = this.selectedBuHead
        if (!this.removeRoleIds.includes(this.buHead) && this.removeDeptIds.length > 0) {
          this.removeRoleIds.push(this.buHead)
        }
        this.selectedBuHead = []
        this.selectedDepartment = []
        this.updateUserRoleObject()
      }
    },
    globalRoleView () {
      this.globalRoleArray = []
      this.userDetails.globalRole.forEach((value) => {
        if (value === 'BU Head') {
          this.userDetails.depts.forEach((element) => {
            const buHeadDept = `${value} (${element.name})`

            this.globalRoleArray.push(buHeadDept)
          })
        } else {
          this.globalRoleArray.push(value)
        }
      })
    },
    globalRoleCheck (event, id, checkId)  {
      if (event.includes(id) && checkId === 'no') {
        this.selectedRoles = event
        this.removeRoleIds = this.removeRoleIds.filter((item) => !event.includes(item))
      } else if (event.includes(id) && checkId === 'yes') {
        this.selectedDepartment = event
        this.removeDeptIds = this.removeDeptIds.filter((item) => !event.includes(item))
      } else {
        if (checkId === 'yes') {
          this.removeDeptIds.push(id)
          this.selectedDepartment = event
        } else if (this.userData.editableRoleIds.includes(id)) {
          this.removeRoleIds.push(id)
        }
      }

      if (!this.selectedRoles.includes(this.buHead)) {
        this.selectedDepartment = []
      }
      if (!this.removeRoleIds.includes(this.buHead) && this.removeDeptIds.length > 0) {
        this.removeRoleIds.push(this.buHead)
      }
      if (this.selectedRoles.includes(this.buHead) && this.selectedDepartment.length <= 0 && checkId === 'yes') {
        this.selectedRoles = this.selectedRoles.filter((item) => item !== this.buHead)
      }
      this.updateUserRoleObject()
    },
    addBuHeadDept (selected) {
      this.selectedDepartment = selected
      this.selectedBuHead.forEach((item) => {
        if (!selected.includes(item)) {
          this.selectedBuHead = selected
          this.removeDeptIds.push(item)
          if (!this.removeRoleIds.includes(this.buHead) && this.removeDeptIds.length > 0) {
            this.removeRoleIds.push(this.buHead)
          }
        }
      })
      this.updateUserRoleObject()
    },
    async save () {
      // Change User Role
      if (this.getGlobalRole[0].user_id === this.userDetails.id && this.removeRoleIds.includes(constant.ROLE_ID.ADMIN)) {
        this.snackbarText = 'You can not remove your own admin role.'
        this.snackbarValue = true
        setTimeout(() => {
          this.snackbarValue = false
        }, 3000)

        return
      }
      const requestData = this.userRoleObeject

      await this.updateUserRole(requestData)
      this.message = 'Role Updated Successfully!'
      this.sent = true
      window.location.reload()
    }
  }
}
</script>

<style scoped>
.dialog-text {
  font-size: small;
  font-weight: 100 !important;
  color: grey
}
.timeSheetWrp {
    display: flex;
    justify-content: space-between;
    padding: 20px 30px 0;
    border-bottom: 1px solid #bab9c2;
}

.timeSheetH h4 {
    color: #707070;
    font-size: 28px;
    font-weight: 700;
    text-align: left;
    font-style: normal;
    letter-spacing: normal;
    line-height: normal;
    border-bottom: 1px solid #707070;
    padding: 0 0 10px;
    margin-bottom: 10px;
}

.timeSheetH p {
    color: #707070;
    font-size: 13px;
    font-weight: 400;
    text-align: left;
    font-style: normal;
    letter-spacing: normal;
    line-height: normal;
}

.timeSheetAct button.v-btn.v-btn--is-elevated.v-btn--has-bg.theme--light.v-size--default.primary {
    border-radius: 8px;
    background-color: #1976d2 !important;
    color: #ffffff;
    font-size: 15px;
    font-weight: 600;
    text-align: center;
    font-style: normal;
    letter-spacing: normal;
    line-height: normal;
    padding: 7px 40px;
    height: auto;
}
</style>
