<template>
  <v-card class="timeSheetTableWrp">
    <div class="orgDshbDialogsBtn">
      <button :class="{ active : activeEl == 'Pending' }" @click="handleClickStatus('Pending')">
        Pending
      </button>
      <button :class="{ active : activeEl == 'Draft' }" @click="handleClickStatus('Draft')">Draft</button>
      <button :class="{ active : activeEl == 'Estimate' }" @click="handleClickStatus('Estimate')">Estimate</button>
      <button :class="{ active : activeEl == 'Sent' }" @click="handleClickStatus('Sent')">Sent</button>
      <button :class="{ active : activeEl == 'Paid' }" @click="handleClickStatus('Paid')" >Paid</button>
      <button :class="{ active : activeEl == 'Cancelled' }" @click="handleClickStatus('Cancelled')">Cancelled</button>
    </div>
    <div class="orgDshbDialogsFilterOpt">
      <v-autocomplete
        v-model="selectedProject"
        :items="projectNameArray"
        item-text="name"
        item-value="id"
        class="filtersFields"
        label="Project Name"
        outlined
        small-chips
        dense
        style="width: 250px; margin: 0px 0 0px auto"
        clearable
        @change="projectNameFilter"
      >
      </v-autocomplete>
    </div>
    <v-list
      v-for="{ items, id, titleColor, code, status} in quickTablesData"
      :key="id"
    >
      <v-list-item class="timeSheetTableitem">
        <v-data-table
          :headers="headers"
          :items="items"
          hide-default-footer
          enable-pagination
          :single-expand="singleExpand"
       
          item-key="id"
          disable-pagination
          class="elevation-0 text-capitalize timeSheetTable"
        >
          <template v-slot:top>
            <v-row>
              <v-col cols="8" class="pt-1 pb-0">
                <h5 class="sheetStatusH">
                  {{ mainTitle }}:
                  <span
                    :class="titleColor"
                  ><b>{{ status }}</b></span>
                </h5>
              </v-col>
            
            </v-row>
          </template>

          <template v-slot:expanded-item="{ headers, item }">
            <td :colspan="headers.length + 1" class="px-0">
              <v-simple-table>
                <template v-slot:default>
                  <thead>
                    <tr>
                      <th />
                      <th />
                      <th>Project name</th>
                      <th>Hours</th>
                      <th>Spent Date</th>
                      <th />
                      <th />
                    </tr>
                  </thead>
                  <tbody>
                    <template v-for="(data, index) in item.projectInfo">
                      <tr :key="index">
                        <td />
                        <td />
                        <td>{{ data.ProjectName }}</td>
                        <td>
                          {{
                            Number.isInteger(data.Hours)
                              ? data.Hours
                              : data.Hours.toFixed(2)
                          }}
                        </td>
                        <td>{{ data.SpentDate }}</td>
                        <td />
                        <td />
                      </tr>
                    </template>
                  </tbody>
                </template>
              </v-simple-table>
            </td>
          </template>
          <template v-slot:item.Hours="{ item }">
            {{
              Number.isInteger(item.Hours) ? item.Hours : item.Hours.toFixed(2)
            }}
          </template>
          <template v-slot:item.LastInvoiceDate="{ item }">
            {{
              item.LastInvoiceDate === "NaN/NaN/NaN" ? "" : item.LastInvoiceDate
            }}
          </template>
        </v-data-table>
        <div
          v-show="
            code === 'is' && quickTablesData.length === 1 && items.length === 1
          "
        >
          <v-list-item v-for="status in invoiceStatus" :key="status">
          </v-list-item>
        </div>
      </v-list-item>
    </v-list>
  </v-card>
</template>

<script>
import { excelSheet, projectHelpers } from '@/helpers/helper.js'
import { mapActions, mapGetters } from 'vuex'
import { EventBus } from '.././event-bus.js'
export default {
  name: 'InvoiceTable',
  props: {
    quickTables: {
      type: Array,
      default: () => []
    },
    getProjectName: {
      type: Array,
      default: () => []
    },
    headers: {
      type: Array,
      default: () => []
    },
    mainTitle: {
      type: String,
      default: ''
    },
    singleExpand: {
      type: Boolean,
      default: true
    }  
  },
  data() {
    return {
      activeEl:'Pending',
      projectList: [],
      originoalDataArray: [],
      quickTablesData: [],
      selectedProjectItem: [],
      myItemProjectIds: [],
      selectedProject: '',
      fetchProjectNames: [],
      projectNameArray: [],
      projectName: [],
      projectData: '',
      data: [],
      serchProjectRecordsArray: [],
      searchProjectName: '',
      status: 'Pending',
      invoiceStatus: [
        'Pending',
        'Draft',
        'Estimate',
        'Sent',
        'Paid',
        'Cancelled'
      ]
    }
  },

  watch: {
    quickTables () {
      this.originoalDataArray = this.quickTables
    }
  },
  mounted() {
    this.originoalDataArray = this.quickTables
    this.defaultData()
  },
  methods: {
    limiter(e) {},
    handleClickStatus(status) {
    
      this.activeEl = status
      this.status = status
      EventBus.$emit('invoiceStatusActive', status)
    
      this.quickTablesData = this.originoalDataArray.filter(
        (element) => element.status === this.status
      )
      
      this.mutateProjectNameList( this.quickTablesData)
      this.selectedProject = ''
    },
    mutateProjectNameList(data) {
      const filterListArray = []
     
      data.map((details) => {
        details.items.map((projectData) => {
          filterListArray.push({
            id: projectData.ProjectID,
            name: projectData.ProjectName
          })
        })
      })
     
      this.projectNameArray = filterListArray
    },

    defaultData() {
      this.quickTablesData = this.originoalDataArray.filter(
        (element) => element.status === 'Pending'
      )
      this.mutateProjectNameList(this.quickTablesData)

      return { data: this.quickTablesData }
    },
   
    /**
     * Global Filter Method
     * @param projectIds
     */
    projectNameFilter() {
      const serchProjectRecordsArray = this.originoalDataArray.filter(
        (element) => element.status === this.status
      )
      let projectList

      if (this.selectedProject !== null) {
        projectList = serchProjectRecordsArray[0].items.filter(
          (x) => x.ProjectID === this.selectedProject
        )
      } else if (this.selectedProject === null) {
        projectList = serchProjectRecordsArray[0].items
      }
      this.quickTablesData = {
        data: { ...serchProjectRecordsArray, items: projectList,status:this.status }
      
      }
    }
  }
}
</script>

<style scoped>
>>> .v-data-table-header {
  box-shadow: none !important;
  color: white;
  border-radius: inherit;
}
.timeSheetTableWrp.v-list-item.theme--light {
  display: block;
}

.timeSheetTableWrp {
  padding: 30px 0 0;
  box-shadow: none !important;
}

.timeSheetTableitem.v-list-item.theme--light {
  display: block;
  padding: 0;
}

h5.sheetStatusH {
  font-size: 18px;
  text-align: left;
  color: #707070;
  font-weight: 400;
  font-style: normal;
  letter-spacing: normal;
  line-height: normal;
  margin-bottom: 20px;
}

.timeSheetTableWrp .v-list.v-sheet.theme--light {
  padding: 20px 0 20px;
}

.timeSheetTable {
  border-bottom: 1px solid #dcdbe0;
  border-radius: 0;
}

.v-application .yellow--text {
  color: #d6c52c !important;
  caret-color: #d6c52c !important;
}

.v-application .red--text {
  color: #dd1515 !important;
  caret-color: #dd1515 !important;
}

button.text-capitalize.blue--text.pa-2.expdClps {
  color: #1976d2 !important;
  font-size: 13px;
  font-weight: 400;
  font-style: normal;
  letter-spacing: normal;
  line-height: normal;
  height: auto;
  padding: 10px 16px !important;
}
</style>
