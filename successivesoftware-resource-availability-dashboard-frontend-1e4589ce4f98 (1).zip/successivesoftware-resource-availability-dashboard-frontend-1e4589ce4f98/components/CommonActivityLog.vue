<template>
  <v-card class="rounded-xl">
    <v-card-text>
      <v-row v-if="header !== ''">
        <v-col cols="12">
          <h3>{{ header }}</h3>
        </v-col>
      </v-row>
      <v-row v-if="arrayTypeCastData.length > 0">
        <v-col v-for="(item, index) in arrayTypeCastData" :key="index" :cols="column">
          <v-textarea
            :value="item[1]"
            :label="item[0].replace(/_/g, ' ')"
            auto-grow
            rows="1"
            dense
            readonly
          />
        </v-col>
      </v-row>
    </v-card-text>
  </v-card>
</template>

<script>
export default {
  name: 'CommonActivityLog',
  props: {
    customData: {
      type: Object,
      default: () => ({})
    },
    header: {
      type: String,
      default: ''
    },
    column: {
      type: String,
      default: '4'
    }
  },
  data () {
    return {
      arrayTypeCastData: []
    }
  },
  mounted () {
    this.arrayTypeCastData = Object.entries(this.customData)
    this.arrayTypeCastData = this.arrayTypeCastData.filter((item) => { return item[1] && item[1] !== '' })
  }
}
</script>

<style scoped>

</style>
