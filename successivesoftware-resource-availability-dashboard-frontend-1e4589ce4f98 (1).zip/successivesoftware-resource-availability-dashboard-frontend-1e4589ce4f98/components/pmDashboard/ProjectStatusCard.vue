<template>
  <div>
    <v-card
      exact
      class="pmDsbpstatusCard"
      @click="onTileClick(data.link)"
    >
      <div>
        <div class="pmDsbpstatusCardWrp">
          <div class="mDsbpstatusCardImg">
            <v-img :src="data.img" height="70" width="70" class="img"/>
          </div>
          <div class="mDsbpstatusCardDesc">
            <div class="mDsbpstatusCardDescInner">
              <h3 v-text="data.value"></h3>
              <p v-text="data.title"></p>
            </div>
          </div>
        </div>
      </div>
    </v-card>
  </div>
</template>
<script>

export default {
  name: 'ProjectStatusCard',

  props: {
    data: {
      type: Object,
      default: () => {}
    }
  },
  methods: {
    /**
     * Perform action on tile click
     * @param cardNumber
     */
    onTileClick (link) {
      if (link) {
        this.$router.push(link)
      }
    }
  }
}
</script>

<style scoped>

.img {
  background-position: inherit;
  height: 150;
  width: 150;
}

button.plushBtn {/* Style for "Ellipse 80" */
    width: 36px;
    height: 36px;
    box-shadow: 0 3px 6px rgba(25, 118, 210, 0.2);
    border: 3px solid #1976d2;
    background-color: #1976d2 !important;
    border-radius: 100%;
    text-align: center;
    color: #fff;
}

.addProjectCWrp {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.addProjectTitleWrp {
    padding: 20px 20px;
    width: 60%;
    text-align: center;
}

.addProjectDescription {width: 40%;padding: 15px;text-align: center;}

.v-card__title.addProjectTitle {
    padding: 30px 0 10px;
    text-align: center;
    line-height: normal;
}

</style>
