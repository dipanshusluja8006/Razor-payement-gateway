<template>
  <div class="pmProgressStageWrp">
    <v-card>
      <div class="pmProgressStage">
        <v-row class="ma-0">
          <v-col cols="8" class="pa-0">
            <h3>Resources - Effort (Planned vs Actual)</h3>
          </v-col>
          <v-col cols="4" class="pa-0 pr-2">
            <div class="PMslectProjectDsh">
              <v-autocomplete
                v-model="selectedProject"
                :items="projectList"
                :search-input.sync="searchProjectName"
                item-text="name"
                item-value="id"
                class="filtersFields"
                label="Project Name"
                outlined
                dense
                multiple
                @input="limiter"
                @change="projectNameFilter"
              >
                <template v-slot:selection="{ attrs, item, parent, selected, index }" class="slectedChilpSRWrp">
                  <v-tooltip top>
                    <template v-slot:activator="{ on }">
                      <v-chip
                        v-if="item === Object(item) && index === 0"
                        v-bind="attrs"
                        :input-value="selected"
                        label
                        small
                        v-on="on"
                      >
                        <span class="slectedChilpSR">
                          {{ item.name.length >= 47? item.name.slice(0,47) + '...': item.name }}
                        </span>
                        <v-icon
                          small
                          @click="parent.selectItem(item)"
                        >
                          mdi-close
                        </v-icon>
                      </v-chip>
                      <v-menu
                        bottom
                        origin="center center"
                        transition="scale-transition"
                      >
                        <template v-slot:activator="{ on }">
                          <v-btn
                            v-if="index === 1"
                            class="ml-1 mr-1 text-capitalize"
                            outlined
                            rounded
                            fab
                            small
                            height="25"
                            width="25"
                            color="blue"
                            v-on="on"
                            @click="!false"
                          >
                            <v-icon x-small style="height: 10px; width: 10px">
                              mdi-plus
                            </v-icon>
                            {{ selectedProject.length - 1 }}
                          </v-btn>
                        </template>
                        <v-card
                          v-show="!false"
                          class="mx-auto"
                          max-width="300"
                          raised
                        >
                          <v-list
                            v-if="selectedProjectData.length > 1"
                            disabled
                            shaped
                          >
                            <v-list-item-group
                              v-model="selectedProjectData"
                            >
                              <v-list-item
                                v-for="project in selectedProjectData.slice(1,selectedProjectData.length)"
                                v-show="!false"
                                :key="project.id"
                              >
                                <v-avatar
                                  color="blue lighten-1"
                                  size="30"
                                  style="padding:4px"
                                >
                                  <strong class="white--text headline">{{ avatarNames(project.name) }}</strong>
                                </v-avatar>
                                <v-list-item-content class="ml-2">
                                  <v-list-item-title v-text="project.name" />
                                </v-list-item-content>
                              </v-list-item>
                            </v-list-item-group>
                          </v-list>
                        </v-card>
                      </v-menu>
                    </template>
                    <span>{{ item.name }}</span>
                  </v-tooltip>
                </template>
              </v-autocomplete>
            </div>
          </v-col>
        </v-row>
      </div>

      <div class="pt-2 pb-0">
        <e-charts
          ref="bar"
          style="width: 100%"
          autoresize
          :options="bar"
          auto-resize
        />
      </div>
    </v-card>

  </div>
</template>
<script>
import { projectHelpers } from '@/helpers/helper.js'
import constant from '../../constants/closure-checklist'
export default {
  name: 'ResourceEffortGraph',
  props: {
    projectEffortList: {
      type: Array,
      default: () => ([])
    },
    projectList: {
      type: Array,
      default: () => []
    }
  },
  data() {
    return {
      selectedProject: '',
      searchProjectName: '',
      selectedProjectArray: [],
      filterSerise: [],
      filterMonthsSerise: [],
      monthData: [],
      wsrData: [],
      showChart: true,
      items: [],
      searchForProject: '',
      selectedProjectData:[],
      chartOptions: { },
      projectEffortsSerise: [],
      bar: {
        legend: {},
        tooltip: {},
        dataset: {
          source: []
        },
        xAxis : [
          {
            type: 'category',
            boundaryGap:true,
            axisLabel: {
              formatter: (function(value) {
                return value.length >= 8 ? value.slice(0,8) + '...' : value
              })
            }
          }
        ],
        yAxis: {},
        series: [{ type: 'bar' }, { type: 'bar' }]
      }
    }
  },
  watch: {
    projectEffortList () {
      this.projectEffortData = this.projectEffortList
      this.mutategetProjectEffortsList(this.projectEffortData)
      this.bar.dataset.source = this.projectEffortsSerise

    },
    projectEffortsSerise () {
      this.bar.dataset.source = this.projectEffortsSerise
    },
    selectedProject () {
      this.selectedProjectData = []
      this.selectedProject.forEach((id) => {
        const domains = this.projectList.filter((item) => { return item.id === id })

        this.selectedProjectData.push(domains[0])
      })
    }
  },
  mounted() {
    this.projectEffortData = this.projectEffortList
    this.mutategetProjectEffortsList(this.projectEffortData)
    this.bar.dataset.source = this.projectEffortsSerise
  },
  methods: {

    mutategetProjectEffortsList (data) {
      let count = 1

      this.projectEffortsSerise = [['Product', 'Planned Effort', 'Actual Effort']]
      if (data) {
        data.map((details) => {
          if (details.estimated_hours !== undefined  && details.actual_hours !== undefined && count <= 5) {
            this.projectEffortsSerise.push(
              [details.project_name, details.estimated_hours, details.actual_hours]
            )
            count ++
          }
        })
      }
    },
    limiter(e) {
      if (e.length > 5) {
        e.pop()
      }
    },
    /**
* Filter for project names column.
* @param value Value to be tested.
* @returns {boolean}
*/
    projectNameFilter(selected) {
      this.selectedProjectArray = []
      if (selected.length > 0 && !selected.includes(0)) {
        const projectData = []

        this.projectEffortList.forEach((element) => {
          if (element.uuid !== null && selected.includes(element.uuid)) {
            projectData.push(element)
            this.selectedProjectArray.push({
              name: element.project_name,
              id: element.uuid
            })
          }
        })
        this.projectEffortData = projectData
      } else {
        this.projectEffortData = this.projectWsrData
      }
      this.mutategetProjectEffortsList(this.projectEffortData)
    },
    avatarNames (fullName) {
      return projectHelpers.avatarNames(fullName)
    }
  }
}
</script>
