<template>
  <div class="pmDashboardOuterWrp">
    <v-row class="wsrTableListWrp">
      <v-col cols="12">
        <v-data-table
          :headers="headers"
          :items="wsrListData"
          :hide-default-footer="wsrListData.length ? false : true"
          class="wsrTableList"
        >
          <template v-slot:top>
            <div class="wsrTableFilter">
              <v-row>
                <v-col cols="5" class="pt-0 pb-0 pr-0 d-flex">
                  <div class="heading-style mr-4"><h3>WSRs</h3></div>
                  <div class="submitDiv">
                    <v-btn class="submitBtn" @click="$router.push('/wsr/wsr-list')">
                      View All
                    </v-btn>
                    <v-btn class="submitBtn" @click="$router.push('/wsr/add-wsr')">
                      Add WSR
                    </v-btn>
                  </div>
                </v-col>
                <v-col cols="7" class="pt-0 pb-0 pr-1 d-flex">
                  <v-autocomplete
                    v-model="selectedStatus"
                    :items="status"
                    item-text="text"
                    item-value="id"
                    class="filtersFields"
                    label="Overall Health Status"
                    outlined
                    dense
                    multiple
                    @change="commonFilter"
                  >
                    <template v-slot:selection="{ attrs, item, parent, selected, index }" class="slectedChilpSRWrp">
                      <v-tooltip top>
                        <template v-slot:activator="{ on }">
                          <v-chip
                            v-if="item === Object(item) && index === 0"
                            v-bind="attrs"
                            :input-value="selected"
                            label
                            small
                            v-on="on"
                          >
                            <span class="slectedChilpSR">
                              {{ item.text.length >= 47? item.text.slice(0,47) + '...': item.text }}
                            </span>
                            <v-icon
                              small
                              @click="parent.selectItem(item)"
                            >
                              mdi-close
                            </v-icon>
                          </v-chip>
                          <v-menu
                            bottom
                            origin="center center"
                            transition="scale-transition"
                          >
                            <template v-slot:activator="{ on }">
                              <v-btn
                                v-if="index === 1"
                                class="ml-1 mr-1 text-capitalize"
                                outlined
                                rounded
                                fab
                                small
                                height="25"
                                width="25"
                                color="blue"
                                v-on="on"
                                @click="!false"
                              >
                                <v-icon x-small style="height: 10px; width: 10px">
                                  mdi-plus
                                </v-icon>
                                {{ selectedStatus.length - 1 }}
                              </v-btn>
                            </template>
                            <v-card
                              v-show="!false"
                              class="mx-auto"
                              max-width="300"
                              raised
                            >
                              <v-list
                                v-if="selectedStatusData.length > 1"
                                disabled
                                shaped
                              >
                                <v-list-item-group
                                  v-model="selectedStatusData"
                                >
                                  <v-list-item
                                    v-for="project in selectedStatusData.slice(1,selectedStatusData.length)"
                                    v-show="!false"
                                    :key="project.id"
                                  >
                                    <v-avatar
                                      color="blue lighten-1"
                                      size="30"
                                      style="padding:4px"
                                    >
                                      <strong class="white--text headline">{{ avatarNames(project.text) }}</strong>
                                    </v-avatar>
                                    <v-list-item-content class="ml-2">
                                      <v-list-item-title v-text="project.text" />
                                    </v-list-item-content>
                                  </v-list-item>
                                </v-list-item-group>
                              </v-list>
                            </v-card>
                          </v-menu>
                        </template>
                        <span>{{ item.text }}</span>
                      </v-tooltip>
                    </template>
                  </v-autocomplete>
                  <v-autocomplete
                    v-model="selectedProject"
                    :items="projectNameArray"
                    :search-input.sync="searchProjectName"
                    item-text="name"
                    item-value="id"
                    class="filtersFields"
                    label="Project Name"
                    outlined
                    dense
                    multiple
                    @change="commonFilter"
                  >
                    <template v-slot:selection="{ attrs, item, parent, selected, index }" class="slectedChilpSRWrp">
                      <v-tooltip top>
                        <template v-slot:activator="{ on }">
                          <v-chip
                            v-if="item === Object(item) && index === 0"
                            v-bind="attrs"
                            :input-value="selected"
                            label
                            small
                            v-on="on"
                          >
                            <span class="slectedChilpSR">
                              {{ item.name.length >= 47? item.name.slice(0,47) + '...': item.name }}
                            </span>
                            <v-icon
                              small
                              @click="parent.selectItem(item)"
                            >
                              mdi-close
                            </v-icon>
                          </v-chip>
                          <v-menu
                            bottom
                            origin="center center"
                            transition="scale-transition"
                          >
                            <template v-slot:activator="{ on }">
                              <v-btn
                                v-if="index === 1"
                                class="ml-1 mr-1 text-capitalize"
                                outlined
                                rounded
                                fab
                                small
                                height="25"
                                width="25"
                                color="blue"
                                v-on="on"
                                @click="!false"
                              >
                                <v-icon x-small style="height: 10px; width: 10px">
                                  mdi-plus
                                </v-icon>
                                {{ selectedProject.length - 1 }}
                              </v-btn>
                            </template>
                            <v-card
                              v-show="!false"
                              class="mx-auto"
                              max-width="300"
                              raised
                            >
                              <v-list
                                v-if="selectedProjectData.length > 1"
                                disabled
                                shaped
                              >
                                <v-list-item-group
                                  v-model="selectedProjectData"
                                >
                                  <v-list-item
                                    v-for="project in selectedProjectData.slice(1,selectedProjectData.length)"
                                    v-show="!false"
                                    :key="project.id"
                                  >
                                    <v-avatar
                                      color="blue lighten-1"
                                      size="30"
                                      style="padding:4px"
                                    >
                                      <strong class="white--text headline">{{ avatarNames(project.name) }}</strong>
                                    </v-avatar>
                                    <v-list-item-content class="ml-2">
                                      <v-list-item-title v-text="project.name" />
                                    </v-list-item-content>
                                  </v-list-item>
                                </v-list-item-group>
                              </v-list>
                            </v-card>
                          </v-menu>
                        </template>
                        <span>{{ item.name }}</span>
                      </v-tooltip>
                    </template>

                  </v-autocomplete>
                  <v-autocomplete
                    v-model="selectedWeek"
                    :items="getYearlyWeeksArr"
                    item-text="name"
                    item-value="id"
                    class="filtersFields"
                    label="Select Week No."
                    outlined
                    dense
                    multiple

                    :search-input.sync="selectedWeekData"
                    @click:clear="clearItem(selectedWeek)"
                    @change="selectedWeekData = ''"
                    @input="commonFilter"
                  >
                    <template v-slot:selection="{ attrs, item, parent, selected, index }" class="slectedChilpSRWrp">
                      <v-tooltip top>
                        <template v-slot:activator="{ on }">
                          <v-chip
                            v-if="item === Object(item) && index === 0"
                            v-bind="attrs"
                            :input-value="selected"
                            label
                            small
                            v-on="on"
                          >
                            <span class="slectedChilpSR">
                              {{ item.name.length >= 47? item.name.slice(0,47) + '...': item.name }}
                            </span>
                            <v-icon
                              small
                              @click="parent.selectItem(item)"
                            >
                              mdi-close
                            </v-icon>
                          </v-chip>
                          <v-menu
                            bottom
                            origin="center center"
                            transition="scale-transition"
                          >
                            <template v-slot:activator="{ on }">
                              <v-btn
                                v-if="index === 1"
                                class="ml-1 mr-1 text-capitalize"
                                outlined
                                rounded
                                fab
                                small
                                height="25"
                                width="25"
                                color="blue"
                                v-on="on"
                                @click="!false"
                              >
                                <v-icon x-small style="height: 10px; width: 10px">
                                  mdi-plus
                                </v-icon>
                                {{ selectedWeek.length - 1 }}
                              </v-btn>
                            </template>
                            <v-card
                              v-show="!false"
                              class="mx-auto"
                              max-width="300"
                              raised
                            >
                              <v-list
                                v-if="selectedWeekArray.length > 1"
                                disabled
                                shaped
                              >
                                <v-list-item-group
                                  v-model="selectedWeekArray"
                                >
                                  <v-list-item
                                    v-for="project in selectedWeekArray.slice(1,selectedWeekArray.length)"
                                    v-show="!false"
                                    :key="project.id"
                                  >
                                    <v-avatar
                                      color="blue lighten-1"
                                      size="30"
                                      style="padding:4px"
                                    >
                                      <strong class="white--text headline">{{ avatarNames(project.name) }}</strong>
                                    </v-avatar>
                                    <v-list-item-content class="ml-2">
                                      <v-list-item-title v-text="project.name" />
                                    </v-list-item-content>
                                  </v-list-item>
                                </v-list-item-group>
                              </v-list>
                            </v-card>
                          </v-menu>
                        </template>
                        <span>{{ item.name }}</span>
                      </v-tooltip>
                    </template>
                  </v-autocomplete>
                </v-col>
              </v-row>
            </div>
          </template>

          <template v-slot:item.overall_health="{ item }">
            <div v-if="item.overall_health === health.RED">
              <v-chip color="red" dark rounded>Red</v-chip>
            </div>
            <div v-else-if="item.overall_health === health.GREEN">
              <v-chip color="green" dark rounded>Green</v-chip>
            </div>
            <div v-else-if="item.overall_health === health.AMBER">
              <v-chip color="amber" dark rounded>Amber</v-chip>
            </div>
            <div v-else>
              NA
            </div>
          </template>
          <template v-slot:item.sch_status="{ item }">
            <div v-if="item.sch_status === health.RED">
              <div v-if="item.sch_remark.length>0">

                <v-tooltip top>
                  <template v-slot:activator="{ on, attrs }">
                    <v-chip
                      color="red"
                      dark
                      v-bind="attrs"
                      rounded
                      v-on="on"
                    >
                      Red
                    </v-chip>
                  </template>
                  <span>{{ item.sch_remark }}</span>
                </v-tooltip>
              </div>
              <div v-else>
                <v-chip
                  color="red"
                  dark
                  rounded
                >
                  Red
                </v-chip>
              </div>
            </div>
            <div v-else-if="item.sch_status === health.GREEN">
              <div v-if="item.sch_remark.length>0">
                <v-tooltip top>
                  <template v-slot:activator="{ on, attrs }">
                    <v-chip
                      color="green"
                      dark
                      v-bind="attrs"
                      rounded
                      v-on="on"
                    >
                      Green
                    </v-chip>
                  </template>
                  <span>{{ item.sch_remark }}</span>
                </v-tooltip>
              </div>
              <div v-else>
                <v-chip
                  color="green"
                  dark
                  rounded
                >
                  Green
                </v-chip>
              </div>
            </div>
            <div v-else-if="item.sch_status === health.AMBER">
              <div v-if="item.sch_remark.length>0">
                <v-tooltip top>
                  <template v-slot:activator="{ on, attrs }">
                    <v-chip
                      color="amber"
                      dark
                      v-bind="attrs"
                      rounded
                      v-on="on"
                    >
                      Amber
                    </v-chip>
                  </template>
                  <span>{{ item.sch_remark }}</span>
                </v-tooltip>
              </div>
              <div v-else>
                <v-chip
                  color="amber"
                  dark
                  rounded
                >
                  Amber
                </v-chip>
              </div>
            </div>
            <div v-else>
              NA
            </div>
          </template>
          <template v-slot:item.qlt_status="{ item }">
            <div v-if="item.qlt_status === health.RED">
              <div v-if="item.qlt_remark.length>0">
                <v-tooltip top>
                  <template v-slot:activator="{ on, attrs }">
                    <v-chip
                      color="red"
                      dark
                      v-bind="attrs"
                      rounded
                      v-on="on"
                    >
                      Red
                    </v-chip>
                  </template>
                  <span>{{ item.qlt_remark }}</span>
                </v-tooltip>
              </div>
              <div v-else>
                <v-chip
                  color="red"
                  dark
                  rounded
                >
                  Red
                </v-chip>
              </div>
            </div>
            <div v-else-if="item.qlt_status === health.GREEN">
              <div v-if="item.qlt_remark.length>0">
                <v-tooltip top>
                  <template v-slot:activator="{ on, attrs }">
                    <v-chip
                      color="green"
                      dark
                      v-bind="attrs"
                      rounded
                      v-on="on"
                    >
                      Green
                    </v-chip>
                  </template>
                  <span>{{ item.qlt_remark }}</span>
                </v-tooltip>
              </div>
              <div v-else>
                <v-chip
                  color="green"
                  dark
                  rounded
                >
                  Green
                </v-chip>
              </div>
            </div>
            <div v-else-if="item.qlt_status === health.AMBER">
              <div v-if="item.qlt_remark.length>0">
                <v-tooltip top>
                  <template v-slot:activator="{ on, attrs }">
                    <v-chip
                      color="amber"
                      dark
                      v-bind="attrs"
                      rounded
                      v-on="on"
                    >
                      Amber
                    </v-chip>
                  </template>
                  <span>{{ item.qlt_remark }}</span>
                </v-tooltip>
              </div>
              <div v-else>
                <v-chip
                  color="amber"
                  dark
                  rounded
                >
                  Amber
                </v-chip>
              </div>
            </div>
            <div v-else>
              NA
            </div>
          </template>
          <template v-slot:item.stf_status="{ item }">
            <div v-if="item.stf_status === health.RED">
              <div v-if="item.stf_remark.length>0">
                <v-tooltip top>
                  <template v-slot:activator="{ on, attrs }">
                    <v-chip
                      color="red"
                      dark
                      v-bind="attrs"
                      rounded
                      v-on="on"
                    >
                      Red
                    </v-chip>
                  </template>
                  <span>{{ item.stf_remark }}</span>
                </v-tooltip>
              </div>
              <div v-else>
                <v-chip
                  color="red"
                  dark
                  rounded
                >
                  Red
                </v-chip>
              </div>
            </div>
            <div v-else-if="item.stf_status === health.GREEN">
              <div v-if="item.stf_remark.length>0">
                <v-tooltip top>
                  <template v-slot:activator="{ on, attrs }">
                    <v-chip
                      color="green"
                      dark
                      v-bind="attrs"
                      rounded
                      v-on="on"
                    >
                      Green
                    </v-chip>
                  </template>
                  <span>{{ item.stf_remark }}</span>
                </v-tooltip>
              </div>
              <div v-else>
                <v-chip
                  color="green"
                  dark
                  rounded
                >
                  Green
                </v-chip>
              </div>
            </div>
            <div v-else-if="item.stf_status === health.AMBER">
              <div v-if="item.stf_remark.length>0">
                <v-tooltip top>
                  <template v-slot:activator="{ on, attrs }">
                    <v-chip
                      color="amber"
                      dark
                      v-bind="attrs"
                      rounded
                      v-on="on"
                    >
                      Amber
                    </v-chip>
                  </template>
                  <span>{{ item.stf_remark }}</span>
                </v-tooltip>
              </div>
              <div v-else>
                <v-chip
                  color="amber"
                  dark
                  rounded
                >
                  Amber
                </v-chip>
              </div>
            </div>
            <div v-else>
              NA
            </div>
          </template>
          <template v-slot:item.inv_status="{ item }">
            <div v-if="item.inv_status === health.RED">
              <div v-if="item.inv_remark.length>0">
                <v-tooltip top>
                  <template v-slot:activator="{ on, attrs }">
                    <v-chip
                      color="red"
                      dark
                      v-bind="attrs"
                      rounded
                      v-on="on"
                    >
                      Red
                    </v-chip>
                  </template>
                  <span>{{ item.inv_remark }}</span>
                </v-tooltip>
              </div>
              <div v-else>
                <v-chip
                  color="red"
                  dark
                  rounded
                >
                  Red
                </v-chip>
              </div>
            </div>
            <div v-else-if="item.inv_status === health.GREEN">
              <div v-if="item.inv_remark.length>0">
                <v-tooltip top>
                  <template v-slot:activator="{ on, attrs }">
                    <v-chip
                      color="green"
                      dark
                      v-bind="attrs"
                      rounded
                      v-on="on"
                    >
                      Green
                    </v-chip>
                  </template>
                  <span>{{ item.inv_remark }}</span>
                </v-tooltip>
              </div>
              <div v-else>
                <v-chip
                  color="green"
                  dark
                  rounded
                >
                  Green
                </v-chip>
              </div>
            </div>
            <div v-else-if="item.inv_status === health.AMBER">
              <div v-if="item.inv_remark.length>0">
                <v-tooltip top>
                  <template v-slot:activator="{ on, attrs }">
                    <v-chip
                      color="amber"
                      dark
                      v-bind="attrs"
                      rounded
                      v-on="on"
                    >
                      Amber
                    </v-chip>
                  </template>
                  <span>{{ item.inv_remark }}</span>
                </v-tooltip>
              </div>
              <div v-else>
                <v-chip
                  color="amber"
                  dark
                  rounded
                >
                  Amber
                </v-chip>
              </div>
            </div>
            <div v-else>
              NA
            </div>
          </template>
          <template v-slot:item.rsk_status="{ item }">
            <div v-if="item.rsk_status === health.RED">
              <div v-if="item.rsk_remark.length>0">
                <v-tooltip top>
                  <template v-slot:activator="{ on, attrs }">
                    <v-chip
                      color="red"
                      dark
                      v-bind="attrs"
                      rounded
                      v-on="on"
                    >
                      Red
                    </v-chip>
                  </template>
                  <span>{{ item.rsk_remark }}</span>
                </v-tooltip>
              </div>
              <div v-else>
                <v-chip
                  color="red"
                  dark
                  rounded
                >
                  Red
                </v-chip>
              </div>
            </div>
            <div v-else-if="item.rsk_status === health.GREEN">
              <div v-if="item.rsk_remark.length>0">
                <v-tooltip top>
                  <template v-slot:activator="{ on, attrs }">
                    <v-chip
                      color="green"
                      dark
                      v-bind="attrs"
                      rounded
                      v-on="on"
                    >
                      Green
                    </v-chip>
                  </template>
                  <span>{{ item.rsk_remark }}</span>
                </v-tooltip>
              </div>
              <div v-else>
                <v-chip
                  color="green"
                  dark
                  rounded
                >
                  Green
                </v-chip>
              </div>
            </div>
            <div v-else-if="item.rsk_status === health.AMBER">
              <div v-if="item.rsk_remark.length>0">
                <v-tooltip top>
                  <template v-slot:activator="{ on, attrs }">
                    <v-chip
                      color="amber"
                      dark
                      v-bind="attrs"
                      rounded
                      v-on="on"
                    >
                      Amber
                    </v-chip>
                  </template>
                  <span>{{ item.rsk_remark }}</span>
                </v-tooltip>
              </div>
              <div v-else>
                <v-chip
                  color="amber"
                  dark
                  rounded
                >
                  Amber
                </v-chip>
              </div>
            </div>
            <div v-else>
              NA
            </div>
          </template>
          <template v-slot:item.eft_status="{ item }">
            <div v-if="item.eft_status === health.RED">
              <div v-if="item.eft_remark.length>0">
                <v-tooltip top>
                  <template v-slot:activator="{ on, attrs }">
                    <v-chip
                      color="red"
                      dark
                      v-bind="attrs"
                      rounded
                      v-on="on"
                    >
                      Red
                    </v-chip>
                  </template>
                  <span>{{ item.eft_remark }}</span>
                </v-tooltip>
              </div>
              <div v-else>
                <v-chip
                  color="red"
                  dark
                  rounded
                >
                  Red
                </v-chip>
              </div>
            </div>
            <div v-else-if="item.eft_status === health.GREEN">
              <div v-if="item.eft_remark">
                <v-tooltip top>
                  <template v-slot:activator="{ on, attrs }">
                    <v-chip
                      color="green"
                      dark
                      v-bind="attrs"
                      rounded
                      v-on="on"
                    >
                      Green
                    </v-chip>
                  </template>
                  <span>{{ item.eft_remark }}</span>
                </v-tooltip>
              </div>
              <div v-else>
                <v-chip
                  color="green"
                  dark
                  rounded
                >
                  Green
                </v-chip>
              </div>
            </div>
            <div v-else-if="item.eft_status === health.AMBER">
              <div v-if="item.eft_remark.length>0">
                <v-tooltip top>
                  <template v-slot:activator="{ on, attrs }">
                    <v-chip
                      color="amber"
                      dark
                      v-bind="attrs"
                      rounded
                      v-on="on"
                    >
                      Amber
                    </v-chip>
                  </template>
                  <span>{{ item.eft_remark }}</span>
                </v-tooltip>
              </div>
              <div v-else>
                <v-chip
                  color="amber"
                  dark
                  rounded
                >
                  Amber
                </v-chip>
              </div>
            </div>
            <div v-else>
              NA
            </div>
          </template>
          <template v-slot:item.action="{item}">
            <span>
              <v-tooltip top>
                <template v-slot:activator="{ on, attrs }">
                  <v-img
                    :src="viewIcon"
                    class="quickAct"
                    v-bind="attrs"
                    @click="viewProject(item.uuid)"
                    v-on="on"
                  />
                </template>
                <span>View Project</span>
              </v-tooltip>
            </span>
            <span>
              <v-tooltip top>
                <template v-slot:activator="{ on, attrs }">
                  <v-img

                    :src="editIcon"
                    class="quickAct"
                    v-bind="attrs"
                    @click="editProject(item.uuid)"
                    v-on="on"
                  />
                </template>
                <span>Edit Project</span>
              </v-tooltip>
            </span>

          </template>
        </v-data-table>
      </v-col>
    </v-row>
  </div>
</template>

<script>
import { mapActions, mapGetters } from 'vuex'
import constant from '../../constants/closure-checklist'
import { projectHelpers } from '@/helpers/helper.js'
export default {
  name: 'DashboardWsr',
  layout: 'default',
  middleware: 'authenticated',
  props: {
    projectList: {
      type: Array,
      default: () => []
    }
  },
  data () {
    return {
      menu: false,
      selectedStatus: null,
      selectedWeek: [],
      highRemark: '',
      peopleRemark: '',
      customerRemark: '',
      lowRemark: '',
      selectedProject: '',
      selectedProjectData:[],
      submitted: false,
      projectNameArray: [],
      headers: [
        { text: 'Project Name', align: 'center', value: 'project_name' },
        { text: 'Ending Date', align: 'center', value: 'week_end_date', sortable: false },
        { text: 'Overall Health', align: 'center', sortable: false, value: 'overall_health' },
        { text: 'Schedule', align: 'center', value: 'sch_status', sortable: false },
        { text: 'Quality', align: 'center', value: 'qlt_status', sortable: false },
        { text: 'Staffing', align: 'center', value: 'stf_status', sortable: false },
        { text: 'Invoices', align: 'center', value: 'inv_status', sortable: false },
        { text: 'Risk', align: 'center', value: 'rsk_status', sortable: false },
        {
          text: 'Effort',
          align: 'center',
          value: 'eft_status',
          sortable: false
        },
        { text: 'Quick Actions', align: 'center', value: 'action', sortable: false }
      ],
      status: constant.WSR_STATUS,
      categories: constant.WSR_CATEGORY,
      health: constant.HEALTH_STATUS,
      remark: '',
      searchProjectName: '',
      modifiedItems: [],
      allStatusSelected: true,
      scheduleId: null,
      qualityId: null,
      staffingId: null,
      invoiceId: null,
      riskId: null,
      effortId: null,
      scheduleRemark: '',
      qualityRemark: '',
      staffingRemark: '',
      invoiceRemark: '',
      riskRemark: '',
      effortRemark: '',
      wsrListData: [],
      getWsrListData: [],
      selectedProjectArray: [],
      getYearlyWeeksArr:[],
      selectedWeekData:'',
      selectedWeekArray:[],
      selectedWeekArr:[]
    }
  },
  computed: {
    ...mapGetters({
      getWsrList: 'AmPmDashboard/getWsrList',
      getYearlyWeeks: 'AmPmDashboard/getYearlyWeeks'
    }),
    viewIcon() {
      return require('@/assets/icons/view-PMO.png')
    },
    editIcon () {
      return require('@/assets/icons/Edit-pmo.png')
    }
  },
  watch: {
    projectList () {
      this.projectNameArray = this.projectList
      this.mutateWsrListData(this.getWsrListData)
    },
    selectedProject () {
      this.selectedProjectData = []
      this.selectedProject.forEach((id) => {
        const domains = this.projectNameArray.filter((item) => { return item.id === id })

        this.selectedProjectData.push(domains[0])
      })
    },
    selectedStatus() {
      this.selectedStatusData = []
      this.selectedStatus.forEach((id) => {
        const health = this.status.filter((item) => { return item.id === id })

        this.selectedStatusData.push(health[0])
      })
    },
    selectedWeek() {
      this.selectedWeekArray = []
      if (this.selectedWeek.length > 0) {
        this.selectedWeek.forEach((id) => {
          const weekData = this.getYearlyWeeksArr.filter((item) => { return item.id === id })

          this.selectedWeekArray.push(weekData[0])
        })
      }
    },
    getYearlyWeeks() {
      this.getYearlyWeeksArr = this.getYearlyWeeks
      this.mutateYearAndWeekList(this.getYearlyWeeks)

    },
    getWsrList () {
      this.getWsrListData = this.getWsrList.data
      this.mutateWsrListData(this.getWsrListData)
    }
  },

  mounted() {
    this.fetchLists()
    this.projectNameArray = this.projectList
    this.getWsrListData = this.getWsrList
    this.mutateWsrListData(this.getWsrListData)
    this.getYearlyWeeksArr = this.getYearlyWeeks
    this.mutateYearAndWeekList(this.getYearlyWeeks)
  },
  methods: {
    ...mapActions({
      fetchWSR: 'AmPmDashboard/fetchWSR',
      fetchWeeks: 'AmPmDashboard/fetchWeeks'
    }),
    async commonFilter() {

      if (this.clientEscalationId === null) {
        this.clientEscalationId = ''
      }
      let weekValue = this.selectedWeek

      if (this.selectedWeek === undefined || this.selectedWeek === null || this.selectedWeek === '') {
        weekValue = []
      }

      const requestData = {
        'week_no': (weekValue) ? weekValue : [],
        'pmuser_id':  [],
        'overall_health_status':  (this.selectedStatus) ? this.selectedStatus : [],
        'client_exclation':  '',
        'project_name':  (this.selectedProject) ? this.selectedProject : [],
        'billing_type': []
      }

      await this.fetchWSR(requestData)
    },
    async fetchLists () {
      const requestData = {
        'week_no': [],
        'pmuser_id':  [],
        'overall_health_status': [],
        'client_exclation':  '',
        'project_name': [],
        'billing_type': []
      }

      // eslint-disable-next-line no-useless-catch
      try {
        await Promise.all([
          this.fetchWSR(requestData),
          this.fetchWeeks()
        ])
      } catch (error) {
        throw (error)
      }
    },

    async mutateYearAndWeekList (data) {

      if (data !== undefined && data.length > 0)
      {
        const currentMinusOneWeekData = this.getYearlyWeeksArr.filter((details) => details.status === 'currentWeek')

        if (currentMinusOneWeekData.length > 0)
        {
          this.selectedWeek = [currentMinusOneWeekData[0].value]
        }
        const weekListArray = []

        this.getYearlyWeeksArr.map((details) => {

          weekListArray.push({
            id: details.value,
            name:  details.value + ' (' + details.key + ')'
          })
        })

        this.getYearlyWeeksArr = weekListArray
      }
    },

    clearItem(id) {
      const result = id.filter((value) => { return  value === ''})

      if (result[0] === '') {
        this.selectedWeek = ''
      }
    },
    mutateWsrListData (data) {
      const newListData = []

      if (data !== undefined && data.length > 0) {

        this.getWsrListData.forEach((item) => {
          if (this.projectNameArray.filter((e) => { return e.id === item.project_id }).length > 0) {

            let weekEndDate = 'NA'

            if (item.week_end_date !== null) {
              weekEndDate = new Date(item.week_end_date).toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'short',
                day: 'numeric'
              })
            }
            newListData.push({
              id: item.id,
              uuid: item.uuid,
              project_id: item.project_id,
              sch_status: item.sch_cat_status,
              sch_remark: item.sch_cat_remark,
              qlt_status: item.qlt_cat_status,
              qlt_remark: item.qlt_cat_remark,
              stf_status: item.stf_cat_status,
              stf_remark: item.stf_cat_remark,
              inv_status: item.inv_cat_status,
              inv_remark: item.inv_cat_remark,
              rsk_status: item.rsk_cat_status,
              rsk_remark: item.rsk_cat_remark,
              eft_status: item.eft_cat_status,
              eft_remark: item.eft_cat_remark,
              highlights_remark: item.highlights_remark,
              lowlights_remark: item.lowlights_remark,
              customer_happiness_remark: item.customer_happiness_remark,
              people_happiness_remark: item.people_happiness_remark,
              created_by: item.created_by,
              created_at: item.created_at,
              updated_at: item.updated_at,
              deleted_at: item.deleted_at,
              created_by_user: item.created_by_user,
              project_name: item.project_name.project_name,
              overall_health: item.overall_health_status,
              week_end_date: weekEndDate,
              wk_end_date: item.week_end_date,
              wk_start_date: item.week_start_date,
              week_no: item.week_no
            })
          }
        })

      }
      this.wsrListData = newListData
    },
    avatarNames (fullName) {
      return projectHelpers.avatarNames(fullName)
    },
    viewProject (id) {
      this.$router.push(`/wsr/${id}/view-wsr`)
    },
    editProject (id) {
      this.$router.push(`/wsr/${id}/edit-wsr`)
    }

  }
}
</script>

<style scoped>
  .submitDiv button.submitBtn.v-btn.v-btn--is-elevated.v-btn--has-bg.theme--light.v-size--default{
    border: 2px solid #1e5fff;
    background-color: #1e5fff;
    font-weight: 400;
    padding: 7px 15px;
    font-weight: normal;
    letter-spacing: 1px;
  }
</style>
