<template>

  <div class="pmDashboardOuterWrp pmPendingTableWrp">
    <Dialog />
    <confirm-dialog ref="confirm"/>
    <v-row class="wsrTableListWrp">
      <v-col cols="12">
        <v-data-table
          :headers="headers"
          :items="pendingItemData"
          :items-per-page="itemPerPage"
          :footer-props="{ itemsPerPageOptions: rowsPerPage }"
          :hide-default-footer="projectList.length ? false : true"
          :search="search"
          class="wsrTableList"
        >
          <template v-slot:top>
            <div class="wsrTableFilter">
              <v-row>
                <v-col cols="5" class="pt-0 pb-0 pr-0 ">
                  <div class="align-center d-flex">
                    <div class="heading-style"><h3>Pending Action Items</h3></div>
                    <div class="submitDiv pl-2">
                      <v-btn class="submitBtn" @click="$router.push(`/action/${myItemTab}`)">
                        View All
                      </v-btn>
                    </div>
                  </div>
                </v-col>
                <v-col cols="7" class="pa-0 pl-5 pr-1">
                  <div class="d-flex justify-space-between">
                    <v-text-field
                      v-model="search"
                      append-icon="mdi-magnify"
                      label="Search"
                      outlined
                      dense
                      class="filtersFields"
                      single-line
                      hide-details
                      style="width: 35%"
                    />
                    <v-autocomplete
                      v-model="selectedProject"
                      :items="projectList"
                      item-text="name"
                      item-value="id"
                      class="filtersFields"
                      label="Project Name"
                      style="width: 35%"
                      outlined
                      small-chips
                      dense
                      multiple
                      @change="projectNameFilter"
                    >
                      <template v-slot:selection="{ attrs, item, parent, selected, index }" class="slectedChilpSRWrp">
                        <v-tooltip top>
                          <template v-slot:activator="{ on }">
                            <v-chip
                              v-if="item === Object(item) && index === 0"
                              v-bind="attrs"
                              :input-value="selected"
                              label
                              small
                              v-on="on"
                            >
                              <span class="slectedChilpSR">
                                {{ item.name.length >= 47? item.name.slice(0,47) + '...': item.name }}
                              </span>
                              <v-icon
                                small
                                @click="parent.selectItem(item)"
                              >
                                mdi-close
                              </v-icon>
                            </v-chip>
                            <v-menu
                              bottom
                              origin="center center"
                              transition="scale-transition"
                            >
                              <template v-slot:activator="{ on }">
                                <v-btn
                                  v-if="index === 1"
                                  class="wsrMoreChilp"
                                  outlined
                                  rounded
                                  fab
                                  small
                                  height="25"
                                  width="25"
                                  color="blue"
                                  v-on="on"
                                  @click="!false"
                                >
                                  <v-icon x-small style="height: 10px; width: 10px">
                                    mdi-plus
                                  </v-icon>
                                  {{ selectedProject.length - 1 }}
                                </v-btn>
                              </template>
                              <v-card
                                v-show="!false"
                                class="mx-auto"
                                max-width="300"
                                raised
                              >
                                <v-list
                                  v-if="selectedProjectData.length > 1"
                                  disabled
                                  shaped
                                >
                                  <v-list-item-group
                                    v-model="selectedProjectData"
                                  >
                                    <v-list-item
                                      v-for="project in selectedProjectData.slice(1,selectedProjectData.length)"
                                      v-show="!false"
                                      :key="project.id"
                                    >
                                      <v-avatar
                                        color="blue lighten-1"
                                        size="30"
                                        style="padding:4px"
                                      >
                                        <strong class="white--text headline">{{ avatarNames(project.name) }}</strong>
                                      </v-avatar>
                                      <v-list-item-content class="ml-2">
                                        <v-list-item-title v-text="project.name" />
                                      </v-list-item-content>
                                    </v-list-item>
                                  </v-list-item-group>
                                </v-list>
                              </v-card>
                            </v-menu>
                          </template>
                          <span>{{ item.name }}</span>
                        </v-tooltip>
                      </template>
                    </v-autocomplete>
                    <div class="addpendingItmBtnWrp" style="width: 30%">
                      <v-btn class="submitBtn" @click="$router.push(`/action/${addItemTab}`)">
                        ADD Action Item
                      </v-btn>
                    </div>
                  </div>
                </v-col>
              </v-row>
            </div>
          </template>

          <template v-slot:item.action="{ item }">
            <div v-if="item.statusId == 1">
              <v-btn icon @click="markDone(item.uuid, 0)">
                <v-icon color="primary">mdi-check-circle</v-icon>
              </v-btn>
            </div>
            <div v-else>
              <v-btn icon @click="markDone(item.uuid, 1)">
                <v-icon color="primary">mdi-check-circle-outline</v-icon>
              </v-btn>
            </div>

          </template>
        </v-data-table>
      </v-col>
    </v-row>
  </div>

</template>
<script>

import { mapActions, mapGetters } from 'vuex'
import Dialog from '@/components/Dialog.vue'
import { projectHelpers } from '@/helpers/helper.js'
import ConfirmDialog from '@/components/ConfirmDialog'
export default {
  name: 'PendingActionItem',
  components: {
    Dialog,
    ConfirmDialog
  },
  props: {
    pendingItemList: {
      type: Array,
      default: () => []
    },

    projectList: {
      type: Array,
      default: () => []
    }
  },
  data () {
    return {
      addItemTab: 3,
      myItemTab:1,
      showChart: true,
      projectNameArray: [],
      selectedProject: '',
      searchForProject: '',
      itemPerPage: 3,
      rowsPerPage: [3],
      projectIds: [],
      selectedProjectData:[],
      pendingItemData: [],
      search: '',
      headers: [
        { text: 'Project', align: 'center', value: 'project' },
        { text: 'Priority', align: 'center', value: 'priority' },
        { text: 'Target Closure Date', align: 'center', value: 'targetCloserDate' },
        { text: 'Description', align: 'center', value: 'description' },
        { text: 'Status', align: 'center', value: 'status' },
        { text: 'Action', align: 'center', value: 'action', sortable: false }
      ]
    }
  },
  computed: {
    ...mapGetters({
      getCustomDialog: 'AmPmDashboard/getCustomDialog'
    })
  },
  watch: {
    pendingItemList () {
      this.pendingItemData = this.pendingItemList
    },
    selectedProject () {
      this.selectedProjectData = []
      this.selectedProject.forEach((id) => {
        const domains = this.projectList.filter((item) => { return item.id === id })

        this.selectedProjectData.push(domains[0])
      })
    }
  },
  mounted () {
    this.pendingItemData = this.pendingItemList
  },
  methods: {
    ...mapActions({
      setPendingItemMarkDone: 'AmPmDashboard/setPendingItemMarkDone',
      setCustomDialog: 'project/setCustomDialog'
    }),
    avatarNames (fullName) {
      return projectHelpers.avatarNames(fullName)
    },

    markDone (uuid, status) {
      let title = 'Mark As Pending'
      let sub = 'Are you sure you want to mark it as pending ?'

      if (status === 1) {
        title = 'Mark As Done'
        sub = 'Are you sure you want to mark it as done ?'
      }
      this.$refs.confirm.open(title, sub, { color: 'red' }).then((confirm) => {
        if (confirm) {
          this.submit(uuid, status)
        }
      })
    },

    async submit (uuid, status) {
      const route = this.$route.path
      const requestData = {
        uuid:uuid,
        status: status,
        route: route
      }

      await this.setPendingItemMarkDone(requestData)
      const dialogData = this.getCustomDialog

      await this.setCustomDialog(dialogData)
    },
    /**
     * Global Filter Method
     * @param projectIds
     */
    projectNameFilter(projectIds) {

      if (projectIds.length > 0 && !projectIds.includes(0)) {
        const projectData = []

        this.pendingItemList.forEach((element) => {
          if (element.project_id !== null && projectIds.includes(element.project_id)) {
            projectData.push(element)
          }
        })
        this.pendingItemData = projectData
      } else {
        this.pendingItemData = this.pendingItemList
      }

    }
  }
}

</script>

<style scoped>
  .submitDiv button.submitBtn.v-btn.v-btn--is-elevated.v-btn--has-bg.theme--light.v-size--default{
    border: 2px solid #1e5fff;
    background-color: #1e5fff;
    font-weight: 400;
    padding: 7px 15px;
    font-weight: normal;
    letter-spacing: 1px;
  }

  @media(max-width: 1440px){
    button.submitBtn.v-btn.v-btn--is-elevated.v-btn--has-bg.theme--light, button.submitBtn.v-btn.v-btn--contained.theme--light.v-size--default, a.doneBtn.v-btn.v-btn--has-bg.v-btn--router.theme--light.v-size--default {
        font-weight: 400;
        padding: 9px 20px;
        font-size: 14px;
    }
  }

</style>
