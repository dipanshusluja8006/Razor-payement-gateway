<template>
  <div class="PMprojectsReportOuterWrp">
    <v-card>
      <div class="PMprojectsReportHWrp">
        <v-row class="ma-0">
          <v-col cols="5" class="pa-0">
            <h3>Projects Report</h3>
            <ul class="pmDhbdnotation">
              <li><span></span> 1 red</li>
              <li class="pramber"><span></span> 2 Amber</li>
              <li class="prgreen"><span></span> 3 Green</li>
            </ul>
          </v-col>
          <v-col cols="7" class="pa-0">
            <div class="PMslectProjectDsh">
              <ul>
                <li><button type="button" @click="getLastMonths(3)">3m</button></li>
                <li><button type="button" @click="getLastMonths(6)">6m</button></li>
                <li><button type="button" @click="getLastMonths(9)">9m</button></li>
                <li><button type="button" @click="getLastMonths(12)">12m</button></li>
                <!-- <li><button type="button">All</button></li> -->
              </ul>

              <v-autocomplete
                v-model="selectedProject"
                :items="projectList"
                :search-input.sync="searchProjectName"
                item-text="name"
                item-value="id"
                class="filtersFields"
                label="Project Name"
                outlined
                dense
                multiple
                @input="limiter"
                @change="projectNameFilter"
              >
                <template v-slot:selection="{ attrs, item, parent, selected, index }" class="slectedChilpSRWrp">
                  <v-tooltip top>
                    <template v-slot:activator="{ on }">
                      <v-chip
                        v-if="item === Object(item) && index === 0"
                        v-bind="attrs"
                        :input-value="selected"
                        label
                        small
                        v-on="on"
                      >
                        <span class="slectedChilpSR">
                          {{ item.name.length >= 47? item.name.slice(0,47) + '...': item.name }}
                        </span>
                        <v-icon
                          small
                          @click="parent.selectItem(item)"
                        >
                          mdi-close
                        </v-icon>
                      </v-chip>
                      <v-menu
                        bottom
                        origin="center center"
                        transition="scale-transition"
                      >
                        <template v-slot:activator="{ on }">
                          <v-btn
                            v-if="index === 1"
                            class="wsrMoreChilp"
                            outlined
                            rounded
                            fab
                            small
                            height="25"
                            width="25"
                            color="blue"
                            v-on="on"
                            @click="!false"
                          >
                            <v-icon x-small style="height: 10px; width: 10px">
                              mdi-plus
                            </v-icon>
                            {{ selectedProject.length - 1 }}
                          </v-btn>
                        </template>
                        <v-card
                          v-show="!false"
                          class="mx-auto"
                          max-width="300"
                          raised
                        >
                          <v-list
                            v-if="selectedProjectData.length > 1"
                            disabled
                            shaped
                          >
                            <v-list-item-group
                              v-model="selectedProjectData"
                            >
                              <v-list-item
                                v-for="project in selectedProjectData.slice(1,selectedProjectData.length)"
                                v-show="!false"
                                :key="project.id"
                              >
                                <v-avatar
                                  color="blue lighten-1"
                                  size="30"
                                  style="padding:4px"
                                >
                                  <strong class="white--text headline">{{ avatarNames(project.name) }}</strong>
                                </v-avatar>
                                <v-list-item-content class="ml-2">
                                  <v-list-item-title v-text="project.name" />
                                </v-list-item-content>
                              </v-list-item>
                            </v-list-item-group>
                          </v-list>
                        </v-card>
                      </v-menu>
                    </template>
                    <span>{{ item.name }}</span>
                  </v-tooltip>
                </template>

              </v-autocomplete>

            </div>
          </v-col>
        </v-row>
      </div>
      <div v-if="showChart">
        <apexchart
          type="area"
          :options="chartOptions"
          :series="filterSerise"
        >
        </apexchart>
      </div>

    </v-card>

  </div>
</template>
<script>
import { projectHelpers } from '@/helpers/helper.js'
import constant from '../../constants/closure-checklist'
export default {
  name: 'PrjectReport',

  props: {
    projectWsrData: {
      type: Array,
      default: () => []
    },
    projectList: {
      type: Array,
      default: () => []
    }
  },
  data () {
    return {
      monthValue: 12,
      selectedProject: '',
      searchProjectName: '',
      selectedProjectArray: [],
      filterSerise: [],
      filterMonthsSerise: [],
      monthData: [],
      selectedProjectData:[],
      wsrData: [],
      showChart: true,
      items: [],
      searchForProject: '',
      chartOptions: { }
    }
  },
  watch: {
    projectWsrData () {
      this.wsrData =  this.projectWsrData.slice(0, 3)
      this.mutateDataAccordingToMonth()
    },
    selectedProject () {
      this.selectedProjectData = []
      this.selectedProject.forEach((id) => {
        const domains = this.projectList.filter((item) => { return item.id === id })

        this.selectedProjectData.push(domains[0])
      })
    },
    filterMonthsSerise () {
      this.mutateDataAccordingToMonth()

      this.chartOptions = {
        chart: {
          height: 245,
          type: 'line'
        },
        dataLabels: {
          enabled: false
        },
        stroke: {
          curve: 'straight'
        },
        xaxis: {
          type: 'category',
          categories: this.filterMonthsSerise
        },
        yaxis: {
          min:0,
          max:3,
          tickAmount: 3
        }
      }
    }
  },
  mounted() {
    this.wsrData =  this.projectWsrData.slice(0, 3)

    this.getLastMonths(this.monthValue)
    this.mutateDataAccordingToMonth()

    this.chartOptions = {
      chart: {
        height: 300,
        type: 'line'
      },
      dataLabels: {
        enabled: false
      },
      stroke: {
        curve: 'straight'
      },
      xaxis: {
        type: 'category',
        categories: this.filterMonthsSerise
      },
      yaxis: {
        min:0,
        max:3,
        tickAmount: 3
      }
    }
  },
  methods: {
    limiter(e) {
      if (e.length > 3) {
        e.pop()
      }
    },
    /**
* Filter for project names column.
* @param value Value to be tested.
* @returns {boolean}
*/
    projectNameFilter(selected) {
      const projectData = []

      this.selectedProjectArray = []
      if (selected.length) {

        this.projectWsrData.forEach((element) => {
          if (element.uuid !== null && selected.includes(element.uuid)) {

            projectData.push(element)

            this.selectedProjectArray.push({
              name: element.project_name,
              id: element.uuid
            })
          }
        })
        this.wsrData = projectData
      } else {
        this.wsrData = this.projectWsrData.slice(0, 3)
      }
      this.mutateDataAccordingToMonth()
    },
    avatarNames (fullName) {
      return projectHelpers.avatarNames(fullName)
    },
    mutateDataAccordingToMonth () {
      const data = this.wsrData
      const AllProjectSeries = []

      data.forEach((wsr) => {  //get project all wsr

        const allData = []
        const allMonthsArray = []

        this.monthData.forEach((month) => {  //get month for which wsr data should shaperated
          const monthWSR = []

          wsr.projectWSR.forEach((item) => {  // each wsr data match with month according to date
            const startDate = new Date(item.week_start_date)
            const endDate = new Date(item.week_end_date)
            const startMonth = startDate.getMonth()
            const endMonth = endDate.getMonth()
            const startYear = startDate.getFullYear()
            const endYear = endDate.getFullYear()

            if (startMonth === month.currentMonth && endMonth === month.currentMonth &&
             startYear === month.year) {
              monthWSR.push(item.overall_health_status )
            } else if (startMonth === month.currentMonth && endMonth === month.nextMonth &&
             startYear === month.year) {
              monthWSR.push(item.overall_health_status )
            }
          })
          let avgValue = 0

          if (Array.isArray(monthWSR) && monthWSR.length) {
            const count = monthWSR.length
            const totalValue = 1

            monthWSR.forEach((item) => {
              totalValue + item
            })
            avgValue = Math.ceil(totalValue / count)
          }
          //manage data month wise here
          allData.push(avgValue)
        })
        const projectSeries = { name: wsr.projectName, data: allData }

        AllProjectSeries.push(projectSeries)
      })

      this.filterSerise = AllProjectSeries
    },
    getLastMonths(n) {
      this.monthValue = n
      const m = ['Jan','Feb','Mar','Aprl','May','Jun','July','Aug','Sep','Oct','Nov','Dec']
      const lastMonths = []
      const monthName = []
      const d = new Date()

      for (let i = 0;i < n;i++) {
        const month = d.getMonth()
        const nextMonth = d.getMonth() + 1

        lastMonths.push(
          { 'month': m[d.getMonth()], 'currentMonth': month,'nextMonth': nextMonth, 'year': d.getFullYear() }
        )
        monthName.push(m[d.getMonth()])
        d.setMonth(d.getMonth() - 1)
      }
      this.filterMonthsSerise = monthName.reverse()

      this.monthData = lastMonths
    }
  }
}

</script>
