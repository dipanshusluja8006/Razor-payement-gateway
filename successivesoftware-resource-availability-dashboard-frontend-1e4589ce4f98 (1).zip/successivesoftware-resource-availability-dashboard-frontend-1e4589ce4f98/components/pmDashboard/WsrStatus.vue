<template>
  <div class="pMcurrentWeekgrp">
    <v-card>
      <div>
        <div ><h3>WSR Status - Current Week</h3></div>
      </div>
      <div v-if="showChart">
        <apexchart
          type="donut"
          width="280"
          style="margin: 0 auto;"
          :options="chartOptions"
          :series="data"
          @click="onTileClick"
        ></apexchart>
      </div>
    </v-card>
  </div>
</template>
<script>

import { mapActions, mapGetters } from 'vuex'
export default {
  name: 'WsrStatus',

  props: {
    data: {
      type: Array,
      default: () => ([])
    }
  },
  data () {
    return {
      WSRStatusName:'',
      showChart: true,
      chartOptions: {
        chart: {
          height: 350,
          type: 'line'
        },
        labels: ['Submitted','Pending'],
        dataLabels: {
          enabled: false
        },
        colors: ['#3ba5c3', '#fbb143'],
        fill: {
          colors: ['#3ba5c3', '#fbb143']
        }
      }

    }
  },

  methods: {
    ...mapActions({
      updateProjectWsrDefaultFilter: 'project/updateProjectWsrDefaultFilter'
    }),
    onTileClick(event) {
      const [first,last] = event.target.classList
      const invoiceStatusIndex = last.split('-')
      const  [one,two,three,four] = invoiceStatusIndex

      if (four === '1') {
        this.storeProjectWsrDefaultFilter(0)
        this.$router.push('/project-dashboard')
      }  else {
        this.storeProjectWsrDefaultFilter(1)
        this.$router.push('/project-dashboard')
      }

    },
    storeProjectWsrDefaultFilter(value) {
      this.updateProjectWsrDefaultFilter(value)
    }
  }
}

</script>
