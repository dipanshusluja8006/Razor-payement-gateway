/* eslint-disable no-unreachable */
<template>
  <div id="dashboard">
    <div class="dashboardHeading">
      <h1>PM Dashboard</h1>
    </div>
    <div class="projectStatusCardOuterWrp">
      <v-row class="mt-0">
        <v-col
          v-for="card in cards"
          :key="card.cardNumber"
          cols="4"
          data-aos="flip-left"
        >
          <ProjectStatusCard :data="card" />
        </v-col>
      </v-row>
    </div>
    <v-row>
      <v-col cols="8">
        <ProjectReport :project-wsr-data="projectWiseWSRData" :project-list="ProjectFilterList"/>
      </v-col>
      <v-col cols="4">
        <WsrStatus :data="wsrStatusArray"/>
      </v-col>
    </v-row>
    <DashboardWsr :project-list="WsrProjectNameArray"/>
    <v-row>
      <v-col cols="4">
        <ProgressStageGraph :project-effort-serise="projectEffortSerise"/>
      </v-col>
      <v-col cols="8">
        <ResourceEffortGraph :project-effort-list="getProjectEffortsData" :project-list="ProjectFilterList"/>
      </v-col>
    </v-row>
    <PeningActionItem :pending-item-list="mutatePendingActionData" :project-list="ProjectFilterList"/>

  </div>

</template>
<script>
import { mapActions, mapGetters } from 'vuex'
import constant from '@/constants/closure-checklist.js'
import { excelSheet } from '@/helpers/helper.js'
import ProjectStatusCard from '@/components/pmDashboard/ProjectStatusCard.vue'
import DashboardWsr from '@/components/pmDashboard/DashboardWsr.vue'
import ProjectReport from '@/components/pmDashboard/ProjectReport.vue'
import ResourceEffortGraph from '@/components/pmDashboard/ResourceEffortGraph.vue'
import ProgressStageGraph from '@/components/pmDashboard/ProgressStageGraph.vue'
import PeningActionItem from '@/components/pmDashboard/PeningActionItem.vue'
import WsrStatus from '@/components/pmDashboard/WsrStatus.vue'
import { projectHelpers } from '@/helpers/helper.js'

export default {
  name: 'ProjectManager',
  components: {
    ProjectStatusCard,
    DashboardWsr,
    ProjectReport,
    WsrStatus,
    PeningActionItem,
    ResourceEffortGraph,
    ProgressStageGraph
  },
  layout: 'authenticated',
  middleware: 'authenticated',
  data () {
    return {
      wsrStatusArray: [],
      search: '',
      PendingActionData: [],
      projectWSRData: [],
      mutatePendingActionData: [],
      activeProjectCount: '',
      projectAtRiskCount: '',
      allProjectActiveRiskCount: '',
      projectWiseWSRData: [],
      ProjectFilterList: [],
      WSRPending: 33,
      getProjectEffortsData: [],
      actionSelected: [],
      projectList: [],
      cards: [],
      newCount: 0,
      draftCount: 0,
      onGoingCount: 0,
      holdCount: 0,
      colosedCount: 0,
      projectEffortSerise: [],
      WsrProjectNameArray: []
    }
  },

  computed: {
    ...mapGetters({
      getPendingActionList: 'AmPmDashboard/getMyActionItemList',
      getProjectWSRList: 'AmPmDashboard/getProjectWSRList',
      getProjectEffortsList: 'AmPmDashboard/getProjectEffortsList',
      getProjectList: 'project/getProjectList'
    }),
    riskImg () {
      return require('@/assets/images/risk.svg')
    },
    activeRiskImg () {
      return require('@/assets/images/warning.svg')
    },
    activeImg () {
      return require('@/assets/images/active.svg')
    }
  },
  watch: {
    getProjectList () {
      this.mutateProjectList()
    },
    getPendingActionList () {
      this.PendingActionData = this.getPendingActionList
      this.mutatePendingActionList(this.PendingActionData)
    },
    getProjectWSRList () {
      this.projectWSRData = this.getProjectWSRList
      this.mutateProjectWSRList(this.projectWSRData)
    },
    getProjectEffortsList () {
      this.getProjectEffortsData = this.getProjectEffortsList
    }
  },
  mounted () {
    this.showChart = true
    this.fetchLists()
    this.PendingActionData = this.getPendingActionList
    this.mutatePendingActionList(this.PendingActionData)
    this.projectWSRData = this.getProjectWSRList
    this.mutateProjectWSRList(this.projectWSRData)
    this.getProjectEffortsData = this.getProjectEffortsList
  },
  methods: {
    ...mapActions({
      fetchMyActionItemList: 'AmPmDashboard/fetchMyActionItemList',
      fetchProjectWSRData: 'AmPmDashboard/fetchProjectWSRData',
      fetchProjectEffortsList: 'AmPmDashboard/fetchProjectEffortsList',
      fetchProjectList: 'project/fetchProjectList'
    }),
    async fetchLists () {
    // eslint-disable-next-line no-useless-catch
      try {
        await Promise.all([
          this.fetchMyActionItemList(),
          this.fetchProjectWSRData(),
          this.fetchProjectEffortsList(),
          this.fetchProjectList()
        ])
      } catch (error) {
        throw (error)
      }
    },
    mutateProjectList () {
      if (this.getProjectList.length > 0)
      {
        const list = []

        this.getProjectList.forEach((project) => {
          if (!constant.NON_INPROGRESS_STATUS.includes(project.status) && project.is_draft === 0) {
            list.push({
              name: project.project_name,
              id: project.uuid
            })
          }

        })
        this.WsrProjectNameArray = list
      }

    },
    mutatePendingActionList (data) {
      if (data) {
        const pendingData = []

        data.map((details) => {
          pendingData.push({
            uuid: details.uuid,
            project_id: details.project_id,
            project: (details.project_name) ? details.project_name.project_name : '',
            priority: this.mapItemsPriority(details.priority),
            targetCloserDate: projectHelpers.listDateFormat(details.target_closure_date),
            description: details.description,
            statusId: details.status,
            status: this.mapItemsStatus(details.status)
          }
          )
        })
        this.mutatePendingActionData = pendingData
      }
    },
    mapItemsPriority (value) {
      if (value === constant.PENDING_ACTION_ITEM_PRIORITY.HIGH) {
        return 'High'
      }
      else if (value === constant.PENDING_ACTION_ITEM_PRIORITY.MEDIUM) {
        return 'Medium'
      }
      else {
        return 'Low'
      }
    },
    mapItemsStatus (value) {
      if (value === constant.PENDING_ACTION_ITEM_STATUS.TODO) {
        return 'ToDo'
      }
      else {
        return 'Done'
      }
    },
    mutateProjectWSRList (data) {
      if (data) {
        const projectData = data['projectList']

        this.newCount = 0
        this.draftCount = 0
        this.onGoingCount = 0
        this.holdCount = 0
        this.colosedCount = 0
        this.projectAtRiskCount = (data['projectAtRiskCount'] !== undefined) ? data['projectAtRiskCount'] : 0
        this.allProjectActiveRiskCount = (data['allProjectActiveRiskCount'] !== undefined) ? data['allProjectActiveRiskCount'] : 0

        const arrayWsrData = []
        const filterListArray = []

        if (projectData) {
          projectData.map((details) => {
            if (Array.isArray(details.project_w_s_r) && details.project_w_s_r.length) {
              arrayWsrData.push({
                uuid: details.uuid,
                projectName: details.project_name,
                redmineProjectId: details.redmine_project_id,
                projectWSR: details.project_w_s_r
              })
            }
            filterListArray.push({
              id: details.uuid,
              name: details.project_name
            }
            )
            if (details.track.status === constant.PROJECT_STATUS.CLOSED) {      // progress in stages graph logic
              this.colosedCount = this.colosedCount + 1
            } else if (details.track.status === constant.PROJECT_STATUS.ON_HOLD) {
              this.holdCount = this.holdCount + 1
            } else if (details.track.is_draft === 1) {
              this.draftCount = this.draftCount + 1
            }
            else if (details.track.status === constant.PROJECT_STATUS.NEW  || ((details.track.is_approve === 0 || details.track.is_approve === 1) && details.track.status === constant.PROJECT_STATUS.INITIATION_REQUEST)) {
              this.newCount = this.newCount + 1
            } else {
              this.onGoingCount = this.onGoingCount + 1
            }
          })
          this.projectWiseWSRData = arrayWsrData
          this.ProjectFilterList = filterListArray
        }
        const WsrStatusSubmitCount = (data['allProjectwsrStatusSubmitCount'] !== undefined) ? data['allProjectwsrStatusSubmitCount'] : 0
        const WsrStatusPendingCount = this.onGoingCount - WsrStatusSubmitCount

        this.cards = [{ title: 'Active Project', flex: 4, cardNumber: 1, value: this.onGoingCount, img: this.activeImg, link: null },
          { title: 'Project At Risk', flex: 4, cardNumber: 2, value: this.projectAtRiskCount, img: this.riskImg, link: null },
          { title: 'Active Risk', flex: 4, cardNumber: 3, value: this.allProjectActiveRiskCount, img: this.activeRiskImg, link: '/active-risk' }]
        this.wsrStatusArray = [WsrStatusSubmitCount, WsrStatusPendingCount]
        this.projectEffortSerise = [this.newCount, this.draftCount, this.onGoingCount, this.holdCount, this.colosedCount]
      }
    }
  }
}
</script>
