<template>
  <div class="pmProgressStageWrp">
    <v-card>
      <div class="orgdshbHeadings">
        <v-row class="ma-0">
          <v-col cols="6" class="pa-0"><h4>Risks</h4></v-col>
          <v-col cols="3" class="pa-0">
            <v-autocomplete
              v-model="selectedCategories" 
              :items="getCategoriesType"
              item-text="name"
              item-value="name"
              class="filtersFields"
              label="Category"
              outlined
              dense
              multiple
              :search-input.sync="searchCategoryType"
              @click:clear="clearItem(selectedCategories)"
              @change="searchCategoryType = ''"
              @input="riskFilter"
            >
              <template v-slot:selection="{ attrs, item, parent, selected, index }" class="slectedChilpSRWrp">
                <v-tooltip top>
                  <template v-slot:activator="{ on }">
                    <v-chip
                      v-if="item === Object(item) && index === 0"
                      v-bind="attrs"
                      :input-value="selected"
                      label
                      small
                      v-on="on"
                    >
                      <span class="slectedChilpSR">
                        {{ item.name.length >= 47? item.name.slice(0,47) + '...': item.name }}
                      </span>
                      <v-icon
                        small
                        @click="parent.selectItem(item)"
                      >
                        mdi-close
                      </v-icon>
                    </v-chip>
                    <v-menu
                      bottom
                      origin="center center"
                      transition="scale-transition"
                    >
                      <template v-slot:activator="{ on }">
                        <v-btn
                          v-if="index === 1"
                          class="wsrMoreChilp"
                          outlined
                          rounded
                          fab
                          small
                          color="blue"
                          v-on="on"
                          @click="!false"
                        >
                          <v-icon x-small style="height: 10px; width: 10px">
                            mdi-plus
                          </v-icon>
                          {{ selectedCategories.length - 1 }}
                        </v-btn>
                      </template>
                      <v-card
                        v-show="!false"
                        class="mx-auto"
                        max-width="300"
                        raised
                      >
                        <v-list
                          v-if="selectedCategoriesData.length > 1"
                          disabled
                          shaped
                        >
                          <v-list-item-group
                            v-model="selectedCategoriesData"
                          >
                            <v-list-item
                              v-for="project in selectedCategoriesData.slice(1,selectedCategoriesData.length)"
                              v-show="!false"
                              :key="project.name"
                            >
                              <v-avatar
                                color="blue lighten-1"
                                size="30"
                                style="padding:4px"
                              >
                                <strong class="white--text headline">{{ avatarNames(project.name) }}</strong>
                              </v-avatar>
                              <v-list-item-content class="ml-2">
                                <v-list-item-title v-text="project.name" />
                              </v-list-item-content>
                            </v-list-item>
                          </v-list-item-group>
                        </v-list>
                      </v-card>
                    </v-menu>
                  </template>
                  <span>{{ item.name }}</span>
                </v-tooltip>
              </template>
            </v-autocomplete>
          </v-col>
          <v-col cols="3" class="pa-0">
            <v-autocomplete
              v-model="selectedProject"
              :items="projectNameArray"
              item-text="name"
              item-value="id"
              class="filtersFields"
              label="Project Name"
              outlined
              dense
              multiple
              @change="riskFilter"
            >
              <template v-slot:selection="{ attrs, item, parent, selected, index }" class="slectedChilpSRWrp">
                <v-tooltip top>
                  <template v-slot:activator="{ on }">
                    <v-chip
                      v-if="item === Object(item) && index === 0"
                      v-bind="attrs"
                      :input-value="selected"
                      label
                      small
                      v-on="on"
                    >
                      <span class="slectedChilpSR">
                        {{ item.name.length >= 47? item.name.slice(0,47) + '...': item.name }}
                      </span>
                      <v-icon
                        small
                        @click="parent.selectItem(item)"
                      >
                        mdi-close
                      </v-icon>
                    </v-chip>
                    <v-menu
                      bottom
                      origin="center center"
                      transition="scale-transition"
                    >
                      <template v-slot:activator="{ on }">
                        <v-btn
                          v-if="index === 1"
                          class="wsrMoreChilp"
                          outlined
                          rounded
                          fab
                          small
                          color="blue"
                          v-on="on"
                          @click="!false"
                        >
                          <v-icon x-small style="height: 10px; width: 10px">
                            mdi-plus
                          </v-icon>
                          {{ selectedProject.length - 1 }}
                        </v-btn>
                      </template>
                      <v-card
                        v-show="!false"
                        class="mx-auto"
                        max-width="300"
                        raised
                      >
                        <v-list
                          v-if="selectedProjectData.length > 1"
                          disabled
                          shaped
                        >
                          <v-list-item-group
                            v-model="selectedProjectData"
                          >
                            <v-list-item
                              v-for="project in selectedProjectData.slice(1,selectedProjectData.length)"
                              v-show="!false"
                              :key="project.name"
                            >
                              <v-avatar
                                color="blue lighten-1"
                                size="30"
                                style="padding:4px"
                              >
                                <strong class="white--text headline">{{ avatarNames(project.name) }}</strong>
                              </v-avatar>
                              <v-list-item-content class="ml-2">
                                <v-list-item-title v-text="project.name" />
                              </v-list-item-content>
                            </v-list-item>
                          </v-list-item-group>
                        </v-list>
                      </v-card>
                    </v-menu>
                  </template>
                  <span>{{ item.name }}</span>
                </v-tooltip>
              </template>
            </v-autocomplete>
          </v-col>
        </v-row>
      </div>
      <div v-if="showChart" class="orgdshRiskGrpg">
        <apexchart
          type="area"
          height="100%"
          :options="chartOptions"
          :series="riskDataArray"
        ></apexchart>
      </div>
    </v-card>
  </div>
</template>
<script>
import { mapActions, mapGetters } from 'vuex'
import {  projectHelpers } from '@/helpers/helper.js'
export default {

  data: function() {
    return {
      showChart: true,
      getRiskDataArray: [],
      riskDataArray: [],
      selectedProject: '',
      projectNameArray: [],
      selectedCategories: [],
      selectedProjectData:[],
      selectedCategoriesData:[],
      projectItem: '',
      getCategoriesType: [],
      searchCategoryType: '',
      chartOptions: {
        chart: {
          height: 250,
          type: 'line',
          toolbar: {
            show: true
          },
          zoom: {
            enabled: true
          }
        },
        dataLabels: {
          enabled: true
        },
        stroke: {
          curve: 'smooth',
          width: 2
        },
        xaxis: {
          type: 'string',
          categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
        },
        yaxis: {
          axisBorder: {
            show: true,
            color: '#ffdddd'
          }
        },
        colors: ['#31ff3c', '#fcc401', '#fa1001', '#045000', '#dddddd']
      }
    }
  },
  computed: {
    ...mapGetters({
      getProjectNames: 'project/getProjectNameListing',
      getCategories: 'dashboard/getCategories',
      getRiskData: 'dashboard/getRiskData'
    })
  },
  watch : {
    getRiskData() {
      this.riskDataValue()
    },
    getProjectNames () {
      this.mutateProjectNameList(this.getProjectNames)
    },
    getCategories () {
      this.getCategoriesType = this.getCategories
    },
    selectedCategories() {
      this.selectedCategoriesData = []
      this.selectedCategories.forEach((filterValue) => {
        const res = this.getCategoriesType.filter((item) => { return item.name === filterValue })

        this.selectedCategoriesData.push(res[0])
      })
    },
    selectedProject() {
      this.selectedProjectData = []
      this.selectedProject.forEach((id) => {
        const projectName = this.projectNameArray.filter((item) => { return item.id === id })
        
        this.selectedProjectData.push(projectName[0])
        
      })
    }
  },
  mounted() {
    this.getCategoriesType = this.getCategories
    this.showChart = true
    this.riskDataValue( )
    this.mutateProjectNameList(this.getProjectNames)
  },
  methods:{
    ...mapActions({
      fetchRiskData: 'dashboard/fetchRiskData'
    }),
    
    avatarNames (fullName) {

      return projectHelpers.avatarNames(fullName)
    },
    riskDataValue() {
      if (this.getRiskData.data) {
        this.riskDataArray = this.getRiskData.data
        this.getRiskDataArray = this.getRiskData.data[0].categories
      }
    },
    async riskFilter (id) {
    
      const result = id.filter((value) => { return  value === 'All' })

      if (result[0] === 'All' && id[0] !== 'All') {
        this.selectedCategories = [this.getCategoriesType[0].name]

      } else if (result[0] === 'All' && id[0] === 'All' && id.length > 1 ) {
        const allFirstIndex = id.shift()
      
      }
      const requestData = {
        'category_id': this.selectedCategories.length === 0 ? ['All'] : this.selectedCategories  ,
        'project_id': (this.selectedProject) ? this.selectedProject : ''

      }

      await this.fetchRiskData(requestData)
    },
    clearItem(id) {
      const resultb = id.filter((value) => { return  value === '' })

      if (resultb[0] === '') {
        this.selectedCategories = ''
        
      }
    },
    mutateProjectNameList (data) {

      if (data) {
        const filterListArray = []

        data.map((details) => {

          filterListArray.push({
            id: details.uuid,
            name: details.project_name
          })
        })

        this.projectNameArray = filterListArray
        this.projectItem =  filterListArray
      }
    }
  }
}
</script>
<style scoped>
.orgdshbHeadings {
  z-index: 11;
}
.orgdshbHeadings h4 {
    text-align: left;
    padding-left: 30px;
}
.orgdshRiskGrpg {
  padding-bottom: 20px;
}

@media(max-width: 1366px){
  .orgdshbHeadings span.slectedChilpSR {
      width: 115px;
  }
}

</style>