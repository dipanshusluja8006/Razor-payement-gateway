<template>
  <div class="pmProgressStageWrp">
    <v-card elevation="1">
      <div class="orgdshbHeadings">
        <h4>Invoice Status</h4>
      </div>

      <div>
        <v-dialog v-model="invoiceDialog">
          <v-card>
            <invoice-modal
              :title="isCardHeading.title"
              :is-data="isQuickTableData"
              :sub-title="isCardHeading.subTitle"
              :show-btn="isCardHeading.showBtn"
              :button-text="isCardHeading.btnText"
            />
            <v-divider class="pb-1" />
            <v-card-text>
              <invoice-table
                :quick-tables="isQuickTableData"
                :headers="isHeaders"
                :main-title="'Invoice Status'"
              />
            </v-card-text>
          </v-card>
        </v-dialog>
      </div>
      <div v-if="showChart" class="pmProgressStageGraph">
        <apexchart
          type="donut"
          width="100%"
          height="auto"
          style="margin: 0 auto;"
          :options="chartOptions"
          :series="invoiceStatusSerise"
          @click="onTileClick"
        ></apexchart></div></v-card>
  </div>
</template>

<script>
import InvoiceModal from '@/components/dialogs/InvoiceModal.vue'
import CardHeading from '@/components/dialogs/CardHeading.vue'
import QuickTable from '../../components/dialogs/QuickTable.vue'
import InvoiceTable from '../../components/dialogs/InvoiceTable.vue'
export default {
  components: {
    InvoiceModal,
    InvoiceTable
  },
  props: {
    getInvoiceData: {
      type: Object,
      default: () => {}
    },
    isQuickTableData:{
      type: Array,
      default: () => []
    }
  },
  data() {
    return {
      isCardHeading: {
        showBtn: true,
        title: 'Invoice Status Details',
        subTitle:
          'Please click the button to remind the AMs/PMs to generate invoices for their projects.',
        btnText: 'Send Reminder'
      },
      isQuickTable: [],
      isHeaders: [
        { text: 'project Name', value: 'ProjectName' },
        { text: 'Billing Type', value: 'BillingType' },
        { text: 'Invoice Status', value: 'InvoiceStatus' },
        { text: 'Last Invoice Date', value: 'LastInvoiceDate' },
        { text: 'Next Invoice Date', value: 'NextInvoiceDate' }
      ],
      invoiceDialog: false,
      invoiceDetailArray: [],
      invoiceStatusSerise: [],
      invoiceStatusObj: '',
      invoiceData: '',
      type: '',
      showChart: true,
      invoiceStatusData: '',
      invoiceItemData:[],
      chartOptions: {
        chart: {
          type: 'donut'
        },
        labels: ['Pending', 'Estimate', 'Paid', 'Draft', 'Sent', 'Cancelled'],
        dataLabels: {
          enabled: false
        },
        legend: {
          show: true,
          position: 'bottom'
        },
        colors: [
          '#9ecffa',
          '#6eafe8',
          '#6a98be',
          '#1c5985',
          '#2b4f65',
          '#123140'
        ],
        fill: {
          colors: [
            '#9ecffa',
            '#6eafe8',
            '#6a98be',
            '#1c5985',
            '#2b4f65',
            '#123140'
          ],
          opacity: 1
        }
      }
    }
  },
  watch: {
    getInvoiceData () {
      this.invoiceItemData = this.getInvoiceData
      this.invoiceStatusCount(this.invoiceItemData)
    },
    isQuickTable () {
      this.isQuickTable = this.isQuickTableData
    }
  },
  mounted() {
    this.showChart = true
    this.invoiceItemData = this.getInvoiceData
        
  },
  methods: {
    
    onTileClick() {
      this.invoiceDialog = true
     
    },
    invoiceStatusCount(data) {
      if ( data !== undefined) {
       
        this.invoiceStatusSerise = [
          data.Pending.statusCount,
          data.Estimate.statusCount,
          data.Paid.statusCount,
          data.Draft.statusCount,
          data.Sent.statusCount,
          data.Cancelled.statusCount
        ]
      }
    }
 
  }
}
</script>

<style scoped>
.apexcharts-legend.position-bottom .apexcharts-legend-series,
.apexcharts-legend.position-top .apexcharts-legend-series {
  display: flex;
  align-items: center;
  padding-left: 12px;
}
</style>
