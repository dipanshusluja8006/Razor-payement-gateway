<template>
  <div class="pmProgressStageWrp">
    <v-card elevation="1">
      <div class="orgdshbHeadings">
        <v-row class="ma-0">
          <v-col cols="4" class="pa-0"><h4><v-icon>mdi mdi-clipboard-text</v-icon> PM RAG Status</h4></v-col>
          <v-col cols="2" class="pa-0 text-right pr-1"><v-btn class="submitBtn" @click="$router.push('/am-pm-rag')">
            View All
          </v-btn></v-col>
          <v-col cols="3" class="pa-0">
            <v-autocomplete
              v-model="assignToIds"
              :items="assignedUsers"
              item-text="name"
              item-value="id"
              class="filtersFields"
              label="Project Manager"
              outlined
              dense
              multiple
              :search-input.sync="assignToIdsType"
              @click:clear="clearItem(assignToIds)"
              @change="assignToIdsType = ''"
              @input="pmRagFilter"
            >
              <template v-slot:selection="{ attrs, item, parent, selected, index }" class="slectedChilpSRWrp">
                <v-tooltip top>
                  <template v-slot:activator="{ on }">
                    <v-chip
                      v-if="item === Object(item) && index === 0"
                      v-bind="attrs"
                      :input-value="selected"
                      label
                      small
                      v-on="on"
                    >
                      <span class="slectedChilpSR">
                        {{ item.name.length >= 47? item.name.slice(0,47) + '...': item.name }}
                      </span>
                      <v-icon
                        small
                        @click="parent.selectItem(item)"
                      >
                        mdi-close
                      </v-icon>
                    </v-chip>
                    <v-menu
                      bottom
                      origin="center center"
                      transition="scale-transition"
                    >
                      <template v-slot:activator="{ on }">
                        <v-btn
                          v-if="index === 1"
                          class="wsrMoreChilp"
                          outlined
                          rounded
                          fab
                          small
                          color="blue"
                          v-on="on"
                          @click="!false"
                        >
                          <v-icon x-small style="height: 10px; width: 10px">
                            mdi-plus
                          </v-icon>
                          {{ assignToIds.length - 1 }}
                        </v-btn>
                      </template>
                      <v-card
                        v-show="!false"
                        class="mx-auto"
                        max-width="300"
                        raised
                      >
                        <v-list
                          v-if="selectedManagerData.length > 1"
                          disabled
                          shaped
                        >
                          <v-list-item-group
                            v-model="selectedManagerData"
                          >
                            <v-list-item
                              v-for="project in selectedManagerData.slice(1,selectedManagerData.length)"
                              v-show="!false"
                              :key="project.name"
                            >
                              <v-avatar
                                color="blue lighten-1"
                                size="25"
                              >
                                <strong class="white--text headline">{{ avatarNames(project.name) }}</strong>
                              </v-avatar>
                              <v-list-item-content class="ml-2">
                                <v-list-item-title v-text="project.name" />
                              </v-list-item-content>
                            </v-list-item>
                          </v-list-item-group>
                        </v-list>
                      </v-card>
                    </v-menu>
                  </template>
                  <span>{{ item.name }}</span>
                </v-tooltip>
              </template>
            </v-autocomplete>
          </v-col>
          <v-col cols="3" class="pa-0">
            <v-autocomplete
              v-model="selectedWeek"
              :items="getYearlyWeeksArr"
              item-text="id"
              item-value="name"
              class="filtersFields"
              label="Week No"
              outlined
              dense
              @change="pmRagFilter"
            />
          </v-col>

        </v-row>
      </div>
      <div class="orgBuRAGStats">
        <apexchart
          height="700px"
          width="100%"
          type="bar"
          :options="chartOptions"
          :series="dataArray"
        ></apexchart>
      </div>
    </v-card>
  </div>
</template>

<script>
import { mapActions, mapGetters } from 'vuex'
import {  projectHelpers } from '@/helpers/helper.js'
export default {
  name: 'BarExample',
 
  data: function() {
    return {
      red: [],
      green: [],
      amber: [],
      projectManagerName: [],
      selectedManagerData:[],
      getPmWiseRagStatusArray: [],
      dataArray: [],
      chartOptions: {},
      assignedUsers:[],
      selectedWeek: '',
      selectedAssignId:[],
      getYearlyWeeksArr:[],
      assignToIds:[],  
      assignToIdsType:''
    }
  },

  computed: {
    ...mapGetters({
      getAssignedUsers: 'AmPmDashboard/getAssignedUsers',
      getYearlyWeeks: 'AmPmDashboard/getYearlyWeeks',
      getPmWiseRagStatus: 'dashboard/getPmWiseRagStatus'
    })
  },

  watch: {
    assignToIds () {
      this.selectedManagerData = []
      if (this.assignToIds.length > 0) {
        this.assignToIds.forEach((id) => {
          const dept = this.assignedUsers.filter((item) => { return item.id === id })

          this.selectedManagerData.push(dept[0])
      
        })
      }
    },
    getPmWiseRagStatus() {
      this.pmWiseRagCount(this.getPmWiseRagStatus)
    },
    getAssignedUsers () {
      this.mutateAssignedUsers(this.getAssignedUsers)
    },
    getYearlyWeeks () {
      this.mutateYearAndWeekList(this.getYearlyWeeks)
    },

    getPmWiseRagStatusArray () {
      this.chartOptions = {
        chart: {
          type: 'bar',
          height: '700px',
          width: '100%',
          stacked: true,
          toolbar: {
            show: false
          },
          zoom: {
            enabled: false
          }
        },
        plotOptions: {
          bar: {
            horizontal: true
            // barHeight: '40px'
          }
        },
        noData: {
          text: 'No Data Available',
          align: 'center',
          verticalAlign: 'top',
          offsetX: 0,
          offsetY: 100,
          style: {
            fontSize: '14px'
          }
        },
        yaxis: {
          labels: {
            show: true,
            align: 'left',
            minWidth: 0,
            maxWidth: 80,
            style: {
              cssClass: 'abc'
            }
            
          }
        },
        dataLabels: {
          enabled: true,
          style: {
            fontSize: '18px',
            fontWeight: 'bold'
          }
        },
        xaxis: {
          type: 'string',
          categories: this.getPmWiseRagStatusArray,
          tickAmount: 1
        },
        colors: ['#fa1001', '#fcc401', '#31ff3c','#aea9a9'],
        fill: {
          colors: ['#fa1001', '#fcc401', '#31ff3c','#aea9a9'],
          opacity: 1
        },
        legend: {
          show: false
        }
      }
    }

  },

  mounted() {
    this.showChart = true
    this.pmWiseRagCount(this.getPmWiseRagStatus)
    this.mutateYearAndWeekList(this.getYearlyWeeks)
    this.chartOptions = {
      chart: {
        type: 'bar',
        stacked: true,
        toolbar: {
          show: false
        },
        zoom: {
          enabled: false
        }
      },
      plotOptions: {
        bar: {
          horizontal: true
        }
      },
      xaxis: {
        type: 'string',
        categories: this.getPmWiseRagStatusArray
      },
      colors: ['#fa1001', '#fcc401', '#31ff3c','#aea9a9'],
      fill: {
        colors: ['#fa1001', '#fcc401', '#31ff3c','#aea9a9'],
        opacity: 1
      },
      legend: {
        show: false
      }
    }
    this.mutateAssignedUsers(this.getAssignedUsers)
  },
  methods: {
    ...mapActions({
      fetchPmWiseRagStatus: 'dashboard/fetchPmWiseRagStatus'
    }),
    avatarNames (fullName) {

      return projectHelpers.avatarNames(fullName)
    },
    pmWiseRagCount(data) {
      if (typeof data !== 'undefined') {
        if (data.data)
        {
          this.dataArray = data.data
          const [first] = data.data

          this.getPmWiseRagStatusArray = first.categories
        }
      }
    },
    async mutateYearAndWeekList (data) {
      if (data.length > 0 )
      {
        const currentMinusOneWeekData =  data.filter((details) => details.status === 'previousWeek')

        this.selectedWeek = currentMinusOneWeekData[0].value
        const weekListArray = []
      
        data.map((details) => {

          weekListArray.push({
            id: details.value + ' (' + details.key + ')',
            name: details.value
          })
        })
        this.getYearlyWeeksArr = weekListArray
      
      }

    },
    async pmRagFilter (id) {
      const selectedWeekArr = []

      if (id.length >= 1)
      {
        const resultc = id.filter((value) => { return  value === '' })
    
        if (resultc[0] === '') {
          this.assignToIds = this.assignedUsers[0].id
        }
      }
      this.selectedWeekArr = [this.selectedWeek]
      const requestData = {
        'user_id': (this.assignToIds) ? this.assignToIds : '',
        'week_no': (this.selectedWeekArr) ? this.selectedWeekArr : ''
      }

      await this.fetchPmWiseRagStatus(requestData)
    },
    clearItem(Id) {
      const resultb = id.filter((value) => { return  value === '' })

      if (resultb[0] === '') {
        this.assignToIds = ''
        
      }
    },
    mutateAssignedUsers (data) {
      if (typeof data !== 'undefined' && data !== null) {
        const listArray = []

        data.map((details) => {
          if (details.user_role_local.length) {
            const userRoles = details.user_role_local
            const am = Object.values(userRoles).filter((item) => (item.role_id === 5 || item.role_id === 6))

            if (am.length) {
              listArray.push({
                id: details.user_id,
                name: details.full_name
              })
            }
          }
        })
        this.assignedUsers = listArray
        const result = this.assignedUsers.filter((value) => { return  value.user_id === null })

        if (result.length === 0) {
          this.assignedUsers.unshift({
            name: 'All',
            id: ''
          })
        }
      }
    }
  }
}
</script>

<style scoped>
  button.submitBtn.v-btn.v-btn--is-elevated.v-btn--has-bg.theme--light, button.submitBtn.v-btn.v-btn--contained.theme--light.v-size--default, a.doneBtn.v-btn.v-btn--has-bg.v-btn--router.theme--light.v-size--default {
    font-weight: 400;
    padding: 7px 15px;
}
.orgBuRAGStats {
  border-bottom: 30px solid #fff;
}
.orgdshbHeadings h4 {
    text-align: left;
    padding-left: 30px;
}
.orgdshbHeadings .v-input.filtersFields input {
    width: 150px;
    max-width: 150px;
    overflow: hidden;
    text-overflow: ellipsis;
}
</style>
