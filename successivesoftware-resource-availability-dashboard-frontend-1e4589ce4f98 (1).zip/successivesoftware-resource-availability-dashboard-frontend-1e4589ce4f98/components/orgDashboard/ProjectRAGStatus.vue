<template>
  <div class="pmProgressStageWrp">
    <v-card elevation="1">
      <div class="orgdshbHeadings">
        <v-row class="ma-0">
          <v-col cols="4" class="pa-0 pl-1"><h4>BU Wise Project RAG Status</h4></v-col>
          <v-col cols="2" class="pa-0 pr-1 text-right"><v-btn class="submitBtn" @click="$router.push('/bu-project-rag/default')">
            View All
          </v-btn></v-col>
          <v-col cols="3" class="pa-0 text-right pr-1">
            <v-autocomplete
              v-model="filterDepartment"
              :items="departmentsArray"
              :search-input.sync="searchDepartmentName"
              item-text="name"
              item-value="id"
              label="Department"
              multiple
              class="filtersFields"
              outlined
              dense
              @click:clear="clearItem(filterDepartment)"
              @change="searchDepartmentName = ''"
              @input="department(filterDepartment)"
            >
              <template v-slot:selection="{ attrs, item, parent, selected, index }" class="slectedChilpSRWrp">
                <v-tooltip top>
                  <template v-slot:activator="{ on }">
                    <v-chip
                      v-if="item === Object(item) && index === 0"
                      v-bind="attrs"
                      :input-value="selected"
                      label
                      small
                      v-on="on"
                    >
                      <span class="slectedChilpSR">
                        {{ item.name.length >= 47? item.name.slice(0,47) + '...': item.name }}
                      </span>
                      <v-icon
                        small
                        @click="parent.selectItem(item)"
                      >
                        mdi-close
                      </v-icon>
                    </v-chip>
                    <v-menu
                      bottom
                      origin="center center"
                      transition="scale-transition"
                    >
                      <template v-slot:activator="{ on }">
                        <v-btn
                          v-if="index === 1"
                          class="wsrMoreChilp"
                          outlined
                          rounded
                          fab
                          small
                          color="blue"
                          v-on="on"
                          @click="!false"
                        >
                          <v-icon x-small style="height: 10px; width: 10px">
                            mdi-plus
                          </v-icon>
                          {{ filterDepartment.length - 1 }}
                        </v-btn>
                      </template>
                      <v-card
                        v-show="!false"
                        class="mx-auto"
                        max-width="300"
                        raised
                      >
                        <v-list
                          v-if="selectedDeptData.length > 1"
                          disabled
                          shaped
                        >
                          <v-list-item-group
                            v-model="selectedDeptData"
                          >
                            <v-list-item
                              v-for="project in selectedDeptData.slice(1,selectedDeptData.length)"
                              v-show="!false"
                              :key="project.name"
                            >
                              <v-avatar
                                color="blue lighten-1"
                                size="30"
                                style="padding:4px"
                              >
                                <strong class="white--text headline">{{ avatarNames(project.name) }}</strong>
                              </v-avatar>
                              <v-list-item-content class="ml-2">
                                <v-list-item-title v-text="project.name" />
                              </v-list-item-content>
                            </v-list-item>
                          </v-list-item-group>
                        </v-list>
                      </v-card>
                    </v-menu>
                  </template>
                  <span>{{ item.name }}</span>
                </v-tooltip>
              </template>
            </v-autocomplete>
          </v-col>
          <v-col cols="3" class="pa-0">
            <v-autocomplete
              v-model="selectedWeek"
              :items="getYearlyWeeksArr"
              item-text="id"
              item-value="name"
              class="filtersFields"
              search-input.sync="search"
              label="Week No"
              outlined
              dense
              @change="department"
            />
            
          </v-col>
        </v-row>
      </div>
      <div class="orgBuRAGStats">
        <apexchart
          height="500px"
          width="100%"
          type="bar"
          :options="chartOptions"
          :series="dataArray"
        ></apexchart>
      </div>
    </v-card>
  </div>
</template>

<script>
import { mapActions, mapGetters } from 'vuex'
import {  projectHelpers } from '@/helpers/helper.js'
export default {
  name: 'BarExample',
 
  data: function() {
    return {
      red: [],
      green: [],
      amber: [],
      departmentname: [],
      getBuWiseProjectRagStatusArray: [],
      dataArray: [],
      chartOptions: {},
      filterDepartment: [],
      selectedDeptData:[],
      selectedWeek: '',
      departmentsArray:[],
      getYearlyWeeksArr:[],
      searchDepartmentName:'',
      catArry: []
    }
  },
  computed: {
    ...mapGetters({
      getYearlyWeeks: 'AmPmDashboard/getYearlyWeeks',
      departments: 'project/getDepartments',
      getBuWiseProjectRagStatus: 'dashboard/getBuWiseProjectRagStatus'
    })
  },
  watch: {
    filterDepartment () {
      this.selectedDeptData = []
      if (this.filterDepartment.length > 0)
      {
        this.filterDepartment.forEach((id) => {
          const dept = this.departmentsArray.filter((item) => { return item.id === id })

          this.selectedDeptData.push(dept[0])

        })
      }
    },
    getBuWiseProjectRagStatus() {
     
      this.buWiseProjecCount(this.getBuWiseProjectRagStatus)
    },
    getYearlyWeeks() {
      this.mutateYearAndWeekList(this.getYearlyWeeks)
    },
    departments() {
      this.deptFilterName(this.departments)
    },
    getBuWiseProjectRagStatusArray() {
      this.chartOptions = {
        chart: {
          type: 'bar',
          height: '350px',
          width: '100%',
          stacked: true,
          toolbar: {
            show: false
          },
          zoom: {
            enabled: false
          }
        },
        plotOptions: {
          bar: {
            horizontal: true
          }
        },
        dataLabels: {
          enabled: true,
          style: {
            fontSize: '18px',
            fontWeight: 'bold'
          }
        },
        noData: {
          text: 'No Data Available',
          align: 'center',
          verticalAlign: 'top',
          offsetX: 0,
          offsetY: 100,
          style: {
            fontSize: '14px'
          }
        },
        xaxis: {
          type: 'string',
          categories: this.catArry,
          tickAmount: 1
        },
        yaxis: {
          labels: {
            show: true,
            align: 'left',
            minWidth: 0,
            maxWidth: 80
          }
        },
        colors: ['#fa1001', '#fcc401', '#31ff3c','#aea9a9'],
        fill: {
          colors: ['#fa1001', '#fcc401', '#31ff3c','#aea9a9'],
          opacity: 1
        },
        legend: {
          show: false
        }
      }
    }
  },
  mounted() {
    this.showChart = true
    this.buWiseProjecCount(this.getBuWiseProjectRagStatus)
    this.mutateYearAndWeekList(this.getYearlyWeeks)
    this.deptFilterName(this.departments)
    this.chartOptions = {
      chart: {
        type: 'bar',
        height: '350px',
        width: '100%',
        stacked: true,
        toolbar: {
          show: false
        },
        zoom: {
          enabled: false
        }
      },
      plotOptions: {
        bar: {
          horizontal: true
        }
      },
      stroke: {
        width: 1,
        colors: ['#fff']
      },
      xaxis: {
        type: 'string',
        categories: this.catArry
      },
      colors: ['#fa1001', '#fcc401', '#31ff3c'],
      fill: {
        colors: ['#fa1001', '#fcc401', '#31ff3c'],
        opacity: 1
      },
      legend: {
        show: false
      }
    }
  },
  methods: {
    ...mapActions({
      fetchBuWiseProjectRagStatus: 'dashboard/fetchBuWiseProjectRagStatus'
    }),
    avatarNames (fullName) {

      return projectHelpers.avatarNames(fullName)
    },
    buWiseProjecCount(data) {
   
      if (typeof data !== 'undefined' ) {
        if (data.data)
        {
          this.dataArray = data.data
          const [first] = data.data

          this.getBuWiseProjectRagStatusArray = first.categories
          this.catArry = first.categories
        }
      }
    },
    async department (id) {
      const selectedWeekArr = []

      if (id.length >= 1)
      {
        const result = id.filter((value) => { return  value === '' })

        if (result[0] === '') {
          this.filterDepartment = this.departmentsArray[0].id
        }
      }
    
      this.selectedWeekArr = [this.selectedWeek]
      const requestData = {
        'dept_id': (this.filterDepartment) ? this.filterDepartment : '',
        'week_no': (this.selectedWeekArr) ? this.selectedWeekArr : ''
      }

      await this.fetchBuWiseProjectRagStatus(requestData)
    },
    clearItem(id) {
      const result = id.filter((value) => { return  value === ''})

      if (result[0] === '') {
        this.filterDepartment = ''
      }
    },
    async mutateYearAndWeekList (data) {
      if (data.length > 0 )
      {
        const currentMinusOneWeekData =  data.filter((details) => details.status === 'previousWeek')

        this.selectedWeek = currentMinusOneWeekData[0].value
      
        const weekListArray = []

        data.map((details) => {

          weekListArray.push({
            id: details.value + ' (' + details.key + ')',
            name: details.value
          })
        })
        this.getYearlyWeeksArr = weekListArray
      
      }

    },
    deptFilterName() {
      const  deptListArray = []
    
      deptListArray.push({
        code: null,
        created_at: null,
        deleted_at: null,
        id: '',
        name: 'All',
        updated_at: null
      })
      const result = this.departments.filter((value) => { return  value.id === null })
      const deptName = this.departments

      if (result.length === 0) {
        this.departmentsArray = [...deptListArray,...deptName]
      }
     
    }

  }
}
</script>
<style scoped>
  .orgBuRAGStats {
      height: 344px;
  }
  button.submitBtn.v-btn.v-btn--is-elevated.v-btn--has-bg.theme--light, button.submitBtn.v-btn.v-btn--contained.theme--light.v-size--default, a.doneBtn.v-btn.v-btn--has-bg.v-btn--router.theme--light.v-size--default {
    font-weight: 400;
    padding: 7px 15px;
}
.orgBuRAGStats {
  border-bottom: 30px solid #fff;
}
span.slectedChilpSR {
    width: 120px;
}
.orgdshbHeadings .v-input.filtersFields input {
    width: 150px;
    max-width: 150px;
    overflow: hidden;
    text-overflow: ellipsis;
}

@media(max-width: 1366px){
  span.slectedChilpSR {
      width: 70px;
  }
}
</style>