<template>
  <div class="pmProgressStageWrp">
    <v-card elevation="1">
      <div class="orgdshbHeadings">
        <h4>Project Phases</h4>
      </div>
      <div v-if="showChart" class="pmProgressStageGraph">
        <apexchart
          type="donut"
          width="100%"
          style="margin: 0 auto;"
          :options="chartOptions"
          :series="projectEffortSerise"
          @click="onTileClick"
        ></apexchart>
      </div>
    </v-card>
  </div>
</template>
<script>
import { mapActions, mapGetters } from 'vuex'
export default {
  name: 'ProgressStageGraph',
  props: {
    projectEffortSerise: {
      type: Array,
      default: () => []
    }
  },
  data() {
    return {
      showChart: true,
      chartOptions: {
        chart: {
          height: 350,
          type: 'donut'
        },
        labels: ['New', 'Draft', 'In Progress', 'On Hold', 'Closed'],
        dataLabels: {
          enabled: false
        },
        legend: {
          show: true,
          position: 'bottom'
        },
        colors: ['#c2b3ff', '#fbca78', '#62d6ff', '#f764b9', '#97e489'],
        fill: {
          colors: ['#c2b3ff', '#fbca78', '#62d6ff', '#f764b9', '#97e489']
        }
      }
    }
  },

  mounted() {
    this.showChart = true
  },
  methods: {
    ...mapActions({
      updateProgressStageGraphFilter: 'project/updateProgressStageGraphFilter'
    }),
    onTileClick(event) {
      const [first,last] = event.target.classList
      const progressStatusIndex = last.split('-')
      const  [one,two,three,four] = progressStatusIndex

      if (four === '0') {
        this.storeProgressStageGraphFilter('1')
        this.$router.push('/project-dashboard')
      }
      else if (four === '1') {
        this.storeProgressStageGraphFilter('0')
        this.$router.push('/project-dashboard')
      } 
      else if (four === '2') {
        this.storeProgressStageGraphFilter('3')
        this.$router.push('/project-dashboard')
      } 
      else if (four === '3') {
        this.storeProgressStageGraphFilter('12')
        this.$router.push('/project-dashboard')
      }  else {
        this.storeProgressStageGraphFilter('13')
        this.$router.push('/project-dashboard')
      }

    },
    storeProgressStageGraphFilter(value) {
      this.updateProgressStageGraphFilter(value)
    }
  }
}
</script>
