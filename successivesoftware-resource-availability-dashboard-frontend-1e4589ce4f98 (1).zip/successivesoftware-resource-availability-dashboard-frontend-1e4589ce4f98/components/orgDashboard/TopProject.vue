<template>
  <div class="orgdDhbSlidercolmWrp">
    <v-card elevation="1">
      <div class="orgtopProjWrp">
        <div class="orgtopProjIcon"> <v-icon>mdi-terrain</v-icon></div>
        <div class="orgtopProjDesc">
          <span>{{ topProjectCount }}</span>
          <p>Top Projects</p>
        </div>
      </div>
      <div class="orgdDhbSliderWrp">
        <h4>Projects</h4>
        <div>
          <v-carousel
            height="auto"
            hide-delimiter-background
            show-arrows-on-hover
            :cycle="true"
          >
            <v-carousel-item
              v-for="project in projectDetailsArr"
              :key="project.project_id"
            >
              <v-sheet height="100%">
                <div class="orgDshprojectNameWrp">
                  <div class="orgDshprojectName">
                    <h5>Project Name</h5>
                    <span>{{ project.project_name.project_name }}</span>
                  </div>
                  <div class="orgDshprojectLogo">
                    <v-tooltip top>
                      <template v-slot:activator="{ on }">
                        <v-avatar
                          :color="`${randomColors()}`"
                          size="30"
                          v-on="on"
                        >
                          <span class="white--text headline">{{
                            project.project_name.project_name
                              .split(" ")
                              .map(x => x[0])
                              .join("")
                          }}</span>
                        </v-avatar>
                      </template>
                      {{ project.project_name.project_name }}
                    </v-tooltip>
                  </div>
                </div>
                <div class="orgDshHelthstsWrp">
                  <p>Overall Health Since Last 4 weeks</p>
                  <button class="btn-green">Green</button>
                </div>
              </v-sheet>
            </v-carousel-item>
          </v-carousel>
        </div>
      </div>
    </v-card>
  </div>
</template>

<script>
import { excelSheet, projectHelpers } from '@/helpers/helper.js'
export default {
  props: {
    getTopProjectData: {
      type: Object,
      default: () => {}
    }
  },
  data() {
    return {
      topProjectCount: '',
      projectDetailsArr: [],
      getTopProjectArray:[],
      colors: [
        'indigo',
        'warning',
        'pink darken-2',
        'red lighten-1',
        'deep-purple accent-4'
      ],
      cycle: false,
      slides: ['First', 'Second', 'Third', 'Fourth', 'Fifth']
    }
  },
  watch: {
    getTopProjectData() {
      this.getTopProjectArray = this.getTopProjectData
      this.getProjectDetails(this.getTopProjectArray)
    }
  },
  mounted() {
    this.getTopProjectArray = this.getTopProjectData
    this.getProjectDetails(this.getTopProjectArray)
 
  },
  methods: {
    getProjectDetails(data) {
      if (data) {
        (this.projectDetailsArr = data.topProject),
        (this.topProjectCount = data.count)
      }
    },
    randomColors() {
      return projectHelpers.randomColors()
    },
    avatarNames(fullName) {
      return projectHelpers.avatarNames(fullName)
    }
  }
}
</script>

<style scoped>
.orgdDhbSlidercolmWrp {
  background: #fff;
  border-radius: 6px;
}

.orgtopProjWrp {
  padding: 10px 10px;
  border-bottom: 1px solid #d8d8d8;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.orgtopProjDesc {
  width: 60%;
  text-align: center;
  background: #e5eaef;
  border-radius: 6px;
  padding: 15px 5px 15px;
}

.orgtopProjDesc span {
  font-size: 25px;
  font-weight: 700;
}

.orgtopProjDesc p {
  margin: 0;
  font-size: 12px;
  font-weight: 600;
}

.orgdDhbSliderWrp {
  padding: 10px 10px 10px;
}

.orgdDhbSliderWrp h4 {
  text-align: center;
  font-weight: normal;
  margin: 0 0 10px;
}

.orgdDhbSliderWrp .v-sheet.theme--dark {
  background: transparent;
  box-shadow: none;
  color: gray;
}

.orgDshprojectNameWrp {
  display: flex;
  justify-content: space-between;
  padding: 10px 0;
}

.orgDshprojectName h5 {
  font-weight: normal;
  font-size: 12px;
  color: gray;
}

.orgDshprojectName span {
  font-weight: 600;
  display: block;
  margin: 6px 0 0;
}

.orgDshHelthstsWrp p {
  font-size: 12px;
  margin: 5px 0;
}

.orgdDhbSliderWrp .orgDshHelthstsWrp {
  padding-bottom: 48px;
}

.orgDshHelthstsWrp button.btn-green {
  border-radius: 6px;
  background-color: rgba(127, 251, 152, 0.15) !important;
  color: #18f627;
  font-size: 14px;
  font-weight: 400;
  font-style: normal;
  letter-spacing: normal;
  line-height: normal;
  text-align: left;
  padding: 6px 15px;
}

.orgdDhbSliderWrp
  .v-carousel__controls
  button.v-carousel__controls__item.v-btn.v-btn--icon.v-btn--round.theme--dark.v-size--small {
  background-color: #e8e8e8;
  height: 10px;
  width: 10px;
  margin: 0 4px;
}

.orgdDhbSliderWrp .v-carousel__controls button span.v-btn__content i.v-icon {
  height: auto;
  width: auto;
  font-size: 10px !important;
}

.orgdDhbSliderWrp
  button.v-carousel__controls__item.v-btn.v-item--active.v-btn--active.v-btn--icon.v-btn--round.theme--dark.v-size--small {
  background-color: #828282;
}
.orgtopProjIcon .theme--light.v-icon {
    font-size: 65px;
    color: gray;
}

.orgtopProjIcon {
    text-align: center;
    width: 40%;
}
.orgDshprojectLogo span.white--text.headline {
    font-size: 12px !important;
}

.orgDshprojectLogo .v-avatar {
    margin: 7px 20px 0 0;
}

</style>
