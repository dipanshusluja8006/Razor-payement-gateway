<template>
  <div class="pmProgressStageWrp">
    <v-card elevation="1">
      <div class="orgdshbHeadings">
        <v-row class="ma-0">
          <v-col cols="6" class="pa-0"><h4>Projects at Risk</h4></v-col>
          <v-col cols="6" class="pa-0">
            <v-btn class="submitBtn" @click="$router.push('/org-action/2')">
              View All
            </v-btn>
          </v-col>
        </v-row>
      </div>
      <div>
        <div class="resourceSummry orgdshProjriskWrp">
          <div class="">
            <div class="resourceSummryTableWrp">
              <div class="resourceSummryTableH">
                <div class="pjctNme">
                  <h4>Project Name</h4>
                </div>
                <div class="noResorc">
                  <h4>Account Manager</h4>
                </div>
              </div>
              <div class="resourceSummryTableData">
                <ul>
                  <li v-for="project in projects" :key="project.id">
                    <div>
                      <v-list-item-title @click="clickEvent(project.id)">{{
                        project.project_name
                      }}</v-list-item-title>
                    </div>
                    <div>
                      <span
                        v-for="accountManager in project.account_managers"
                        :key="accountManager.user_id"
                      >
                        <v-tooltip top>
                          <template v-slot:activator="{ on }">
                            <v-avatar
                              :color="`${randomColors()}`"
                              size="30"
                              v-on="on"
                            >
                              <span class="white--text headline">{{
                                avatarNames(accountManager.user.display_name)
                              }}</span>
                            </v-avatar>
                          </template>
                          {{ accountManager.user.display_name }}&nbsp;&nbsp;
                        </v-tooltip>
                      </span>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div></v-card>
  </div>
</template>
<script>
import { excelSheet, projectHelpers } from '@/helpers/helper.js'
export default {
  props: {
    getProjectAtRisk: {
      type: Array,
      default: () => []
    }
  },
  data() {
    return {
      accountManagers: '',
      projects: [],
      accountName: [],
      getProjectAtRiskArr:[]
    }
  },
  watch:{
    getProjectAtRisk() {
      this.getProjectAtRiskArr = this.getProjectAtRisk
      this.getProjectRiskData(this.getProjectAtRiskArr)
    }
  },
  mounted() {
    this.getProjectRiskData(this.getProjectAtRiskArr)
  },
  methods: {
    getProjectRiskData(data) {
      if (data !== null) {
        this.projects = data
      }
    },
    randomColors() {
      return projectHelpers.randomColors()
    },
    avatarNames(fullName) {
      return projectHelpers.avatarNames(fullName)
    },
    clickEvent(e, chartContext, config) {
      const base_url = location.origin

      location.href = base_url + '/org-action' + '/' + e
    }
  }
}
</script>