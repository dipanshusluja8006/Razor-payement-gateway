<template>
  <div class="orgdDhbSlidercolmWrp">
    <v-card elevation="1">
      <div class="orgtopProjWrp">
        <div class="orgtopProjIcon"> <v-icon>mdi-elevation-rise</v-icon></div>
        <div class="orgtopProjDesc">
          <span>{{ newCollaborationCount }}</span>
          <p>New Collaboration</p>
        </div>
      </div>
      <div class="orgdDhbSliderWrp">
        <h4>Collaboration Partners</h4>
        <div>
          <v-carousel
            height="190"
            hide-delimiter-background
            show-arrows-on-hover
            :cycle="true"
          >
            <v-carousel-item
              v-for="partners in collaborationDetailsArr"
              :key="partners.code"
            >
              <v-sheet height="100%">
                <div class="orgDshprojectNameWrp">
                  <div class="orgDshprojectName">
                    <h5>Partner Name</h5>
                    <span>{{ partners.name }}</span>
                  </div>
                  <div class="orgDshprojectLogo">
                    <v-tooltip top>
                      <template v-slot:activator="{ on }">
                        <v-avatar
                          :color="`${randomColors()}`"
                          size="30"
                          v-on="on"
                        >
                          <span class="white--text headline">{{
                            partners.name
                              .split(" ")
                              .map(x => x[0])
                              .join("")
                          }}</span>
                        </v-avatar>
                      </template>
                      {{ partners.name }}
                    </v-tooltip>
                  </div>
                </div>
              </v-sheet>
            </v-carousel-item>
          </v-carousel>
        </div>
      </div>
    </v-card>
  </div>
</template>

<script>
import { excelSheet, projectHelpers } from '@/helpers/helper.js'
export default {
  props: {
    getNewCollaboration: {
      type: Object,
      default: () => {}
    }
  },
  data() {
    return {
      newCollaborationCount: '',
      collaborationDetailsArr: [],
      getNewCollaborationArr:[],
      colors: [
        'indigo',
        'warning',
        'pink darken-2',
        'red lighten-1',
        'deep-purple accent-4'
      ],
      slides: ['First', 'Second', 'Third', 'Fourth', 'Fifth']
    }
  },
  watch: {
    getNewCollaboration() {
      this.getNewCollaborationArr = this.getNewCollaboration
      this.getCollaborationDetails(this.getNewCollaborationArr)
    }
  },
  mounted() {
    this.getCollaborationDetails(this.getNewCollaborationArr)
  },
  methods: {

    getCollaborationDetails(data) {
      if (data) {
        this.collaborationDetailsArr = data.newCollaboration
        this.newCollaborationCount = data.count
      }
    },
    randomColors() {
      return projectHelpers.randomColors()
    },
    avatarNames(fullName) {
      return projectHelpers.avatarNames(fullName)
    }
  }
}
</script>

<style scoped>
.orgdDhbSlidercolmWrp {
  background: #fff;
  border-radius: 6px;
  min-height: 345px;
}

.orgtopProjWrp {
  padding: 10px 10px;
  border-bottom: 1px solid #d8d8d8;
  display: flex;
  justify-content: space-between;
}

.orgtopProjIcon .theme--light.v-icon {
    font-size: 65px;
    color: gray;
}

.orgtopProjIcon {
    text-align: center;
    width: 40%;
}

.orgtopProjDesc {
  width: 60%;
  text-align: center;
  background: #e5eaef;
  border-radius: 6px;
  padding: 10px 5px 15px;
}

.orgtopProjDesc span {
  font-size: 25px;
  font-weight: 700;
}

.orgtopProjDesc p {
  margin: 0;
  font-size: 12px;
  font-weight: 600;
}

.orgdDhbSliderWrp {
  padding: 10px 10px 10px;
}

.orgdDhbSliderWrp h4 {
  text-align: center;
  font-weight: normal;
  margin: 0 0 10px;
}

.orgdDhbSliderWrp .v-sheet.theme--dark {
  background: transparent;
  box-shadow: none;
  color: gray;
}

.orgDshprojectNameWrp {
  display: flex;
  justify-content: space-between;
  padding: 14px 0;
}

.orgDshprojectName h5 {
  font-weight: normal;
  font-size: 12px;
  color: gray;
}

.orgDshprojectName span {
  font-weight: 600;
  display: block;
  margin: 6px 0 0;
}

.orgDshHelthstsWrp p {
  font-size: 12px;
  margin: 5px 0;
}

.orgdDhbSliderWrp .orgDshHelthstsWrp {
  padding-bottom: 60px;
}

.orgDshHelthstsWrp button.btn-green {
  border-radius: 6px;
  background-color: rgba(127, 251, 152, 0.15) !important;
  color: #18f627;
  font-size: 14px;
  font-weight: 400;
  font-style: normal;
  letter-spacing: normal;
  line-height: normal;
  text-align: left;
  padding: 6px 15px;
}

.orgdDhbSliderWrp
  .v-carousel__controls
  button.v-carousel__controls__item.v-btn.v-btn--icon.v-btn--round.theme--dark.v-size--small {
  background-color: #e8e8e8;
  height: 10px;
  width: 10px;
  margin: 0 4px;
}

.orgdDhbSliderWrp .v-carousel__controls button span.v-btn__content i.v-icon {
  height: auto;
  width: auto;
  font-size: 10px !important;
}

.orgdDhbSliderWrp
  button.v-carousel__controls__item.v-btn.v-item--active.v-btn--active.v-btn--icon.v-btn--round.theme--dark.v-size--small {
  background-color: #828282;
}

@media(max-width: 1366px){
  .orgdDhbSliderWrp{
    min-height: 220px;
  }
}

</style>
