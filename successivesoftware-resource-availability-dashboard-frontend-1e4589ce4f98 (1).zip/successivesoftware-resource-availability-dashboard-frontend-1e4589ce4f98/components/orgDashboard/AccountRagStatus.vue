<template>
  <div class="pmProgressStageWrp">
    <v-card elevation="1">
      <div class="orgdshbHeadings">
        <h4>Account Rag Status</h4>
      </div>
      <div
        style="width: 100%; min-height: 288px; background: #fff; border-radius: 6px;"
      >
        <span
          style="    display: block;
    text-align: center;
    font-size: 30px;
    color: #c3c3c3;
    padding: 90px 0;"
        >Coming Soon</span>
      </div>
    </v-card>
  </div>
</template>
