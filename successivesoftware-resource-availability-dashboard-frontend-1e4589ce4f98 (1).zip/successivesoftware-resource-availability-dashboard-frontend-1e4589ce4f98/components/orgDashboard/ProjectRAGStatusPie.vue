<template>
  <div class="pmProgressStageWrp">
    <v-card elevation="1">
      <div class="orgdshbHeadings pb-0">
        <h4>Project Rag Status</h4>
        <br />
        <v-row class="ma-0">
          <v-col cols="6" class="pa-0 pl-1">
            <v-autocomplete
              v-model="billingType"
              :items="newBillingType"
              item-text="name"
              item-value="id"
              class="filtersFields"
              label="Billing Type"
              outlined
              multiple
              dense
              :search-input.sync="searchBillingType"
              @click:clear="clearItem(billingType)"
              @change="searchBillingType = ''"
              @input="projectBillingFilter"
            >
              <template v-slot:selection="{ attrs, item, parent, selected, index }" class="slectedChilpSRWrp">
                <v-tooltip top>
                  <template v-slot:activator="{ on }">
                    <v-chip
                      v-if="item === Object(item) && index === 0"
                      v-bind="attrs"
                      :input-value="selected"
                      label
                      small
                      v-on="on"
                    >
                      <span class="slectedChilpSR">
                        {{ item.name.length >= 47? item.name.slice(0,47) + '...': item.name }}
                      </span>
                      <v-icon
                        small
                        @click="parent.selectItem(item)"
                      >
                        mdi-close
                      </v-icon>
                    </v-chip>
                    <v-menu
                      bottom
                      origin="center center"
                      transition="scale-transition"
                    >
                      <template v-slot:activator="{ on }">
                        <v-btn
                          v-if="index === 1"
                          class="wsrMoreChilp"
                          outlined
                          rounded
                          fab
                          small
                          color="blue"
                          v-on="on"
                          @click="!false"
                        >
                          <v-icon x-small style="height: 10px; width: 10px">
                            mdi-plus
                          </v-icon>
                          {{ billingType.length - 1 }}
                        </v-btn>
                      </template>
                      <v-card
                        v-show="!false"
                        class="mx-auto"
                        max-width="300"
                        raised
                      >
                        <v-list
                          v-if="selectedBillingData.length > 1"
                          disabled
                          shaped
                        >
                          <v-list-item-group
                            v-model="selectedBillingData"
                          >
                            <v-list-item
                              v-for="project in selectedBillingData.slice(1,selectedBillingData.length)"
                              v-show="!false"
                              :key="project.id"
                            >
                              <v-avatar
                                color="blue lighten-1"
                                size="30"
                                style="padding:4px"
                              >
                                <strong class="white--text headline">{{ avatarNames(project.name) }}</strong>
                              </v-avatar>
                              <v-list-item-content class="ml-2">
                                <v-list-item-title v-text="project.name" />
                              </v-list-item-content>
                            </v-list-item>
                          </v-list-item-group>
                        </v-list>
                      </v-card>
                    </v-menu>
                  </template>
                  <span>{{ item.name }}</span>
                </v-tooltip>
              </template>
            </v-autocomplete>
          </v-col>
          <v-col cols="6" class="pa-0 pl-1">
            <v-autocomplete
              v-model="selectedWeek"
              :items="getYearlyWeeksArr"
              item-text="id"
              item-value="name"
              class="filtersFields"
              label="Select Week"
              outlined
              dense
              @change="projectBillingFilter"
            />
          </v-col>
        </v-row>
      </div>
      <div v-if="showChart" class="pmProgressStageGraph pmProgressStageGraphPie">
        <apexchart
          type="donut"
          width="100%"
          style="margin: 0 auto;"
          :options="chartOptions"
          :series="getProjectWiseRagStatusArray"
          @click="clickEvent"
        ></apexchart>
      </div>
    </v-card>
  </div>
</template>

<script>
import { mapActions, mapGetters } from 'vuex'
import {  projectHelpers } from '@/helpers/helper.js'
export default {
  data() {
    return {
      red: [],
      green: [],
      amber: [],
      dataArray: [],
      assignedUsers:[],
      billingType:[],
      selectedBillingData:[],
      selectedWeek: '',
      getProjectWiseRagStatusArray: [],
      showChart: true,
      getYearlyWeeksArr:[],
      newBillingType: [],
      searchBillingType:'',

      chartOptions: {
        chart: {
          type: 'donut'
        },
        labels: ['Red', 'Amber', 'Green', 'Not Available'],
        dataLabels: {
          enabled: false
        },
        legend: {
          show: true,
          position: 'bottom'
        },
        colors: ['#fa1001', '#fcc401', '#31ff3c', '#aea9a9'],
        fill: {
          colors: ['#fa1001', '#fcc401', '#31ff3c', '#aea9a9']
        }
      }
    }
  },
  computed: {
    ...mapGetters({
      getYearlyWeeks: 'AmPmDashboard/getYearlyWeeks',
      billingTypes: 'project/getBillingTypes',
      getProjectWiseRagStatus: 'dashboard/getProjectWiseRagStatus'
    })
  },
  watch: {
    billingType () {
      this.selectedBillingData = []
      if (this.billingType.length !== 0)
      {
        this.billingType.forEach((id) => {
          const dept = this.newBillingType.filter((item) => { return item.id === id })

          this.selectedBillingData.push(dept[0])
        
        })
      }
      
    },
    getProjectWiseRagStatus() {
      this.getProjectWiseRagStatusCount(this.getProjectWiseRagStatus)
    },
    getYearlyWeeks() {
      this.mutateYearAndWeekList(this.getYearlyWeeks)
    },
    billingTypes() {
      this.billingTypesMultiple(this.billingTypes)
    }
  },
  mounted() {
    this.newBillingType = this.billingTypes
    this.showChart = true
    this.getProjectWiseRagStatusCount(this.getProjectWiseRagStatus)
    this.mutateYearAndWeekList(this.getYearlyWeeks)
    this.billingTypesMultiple(this.billingTypes)
  },
  methods: {
    ...mapActions({
      fetchProjectWiseRagStatus: 'dashboard/fetchProjectWiseRagStatus',
      updateProjectRagStatus: 'dashboard/updateProjectRagStatus',
      updateProjectRagBillingStatus:'dashboard/updateProjectRagBillingStatus',
      updateProjectRagWeek:'dashboard/updateProjectRagWeek'
    }),
    avatarNames (fullName) {

      return projectHelpers.avatarNames(fullName)
    },
    getProjectWiseRagStatusCount(data) {
      if (data.data) {
        this.getProjectWiseRagStatusArray = [
          data.data.Red.statusCount,
          data.data.Amber.statusCount,
          data.data.Green.statusCount,
          data.data.UnScheduled.statusCount
        ]
      }
    },
    async mutateYearAndWeekList (data) {
      if (data.length > 0 )
      {
        if (this.selectedWeek === '') {
          const currentMinusOneWeekData =  data.filter((details) => details.status === 'previousWeek')

          this.selectedWeek =  currentMinusOneWeekData[0].value
        }
        const weekListArray = []
      
        data.map((details) => {

          weekListArray.push({
            id: details.value + ' (' + details.key + ')',
            name: details.value
          })
        })
        this.getYearlyWeeksArr = weekListArray
      
      }

    },
    billingTypesMultiple(id) {
      const  billingListArray = []
    
      billingListArray.push({
        code: null,
        created_at: null,
        id: '',
        name: 'All',
        updated_at: null
      })
      const result = this.billingTypes.filter((value) => { return  value.id === null })
      const billingName = this.billingTypes

      if (result.length === 0) {
        this.newBillingType = [...billingListArray,...billingName]
      }
    },
    async projectBillingFilter (id) {
      const selectedWeekArr = []
     
      if (id.length >= 1) {
        const result = id.filter((value) => { return  value === '' })
    
        if (result[0] === '') {
          this.billingType = this.newBillingType[0].id
        }
      }
      this.selectedWeekArr = [this.selectedWeek]
      const requestData = {
        'billing_id': (this.billingType) ? this.billingType : '',
        'week_no': (this.selectedWeekArr) ? this.selectedWeekArr : ''
      }

      await this.fetchProjectWiseRagStatus(requestData)
    },
    clearItem(id) {
      const resultb = id.filter((value) => { return  value === '' })

      if (resultb[0] === '') {
        this.billingType = ''
        
      }
    },
    clickEvent(event) {
      const [first,last] = event.target.classList
      const projectRagStatusIndex = last.split('-')
      const  [one,two,three,four] = projectRagStatusIndex
  
      if (four === '0') {
        this.storeProjectRagStatus(1)
        this.storeProjectRagBillingStatus(this.billingType)
        this.storeProjectRagWeek(this.selectedWeek)
        this.$router.push('/am-pm-rag')
      }
      else if (four === '1') {
        this.storeProjectRagStatus(2)
        this.storeProjectRagBillingStatus(this.billingType)
        this.storeProjectRagWeek(this.selectedWeek)
        this.$router.push('/am-pm-rag')
      } 
      else if (four === '2') {
        this.storeProjectRagStatus(3)
        this.storeProjectRagBillingStatus(this.billingType)
        this.storeProjectRagWeek(this.selectedWeek)
        this.$router.push('/am-pm-rag')
      } 
      else {
        this.storeProjectRagStatus(4)
        this.storeProjectRagBillingStatus(this.billingType)
        this.storeProjectRagWeek(this.selectedWeek)
        this.$router.push('/am-pm-rag')
      }

    },
    storeProjectRagStatus(value) {
      this.updateProjectRagStatus(value)
    },
    storeProjectRagBillingStatus(value) {
      this.updateProjectRagBillingStatus(value)
    },
    storeProjectRagWeek(value) {
      this.updateProjectRagWeek(value)
    }

  }
}
</script>
<style scoped>
.apexcharts-legend.position-bottom .apexcharts-legend-series,
.apexcharts-legend.position-top .apexcharts-legend-series {
  display: flex;
  align-items: center;
  padding-left: 12px;
}
div#orgdashboard .pmProgressStageGraph{
  padding: 10px 0 30px;
    min-height: 354px;
}
@media(max-width: 1366px){
  div#orgdashboard .pmProgressStageGraph{
    padding: 10px 0 21px;
  }
  .orgdshbHeadings span.slectedChilpSR {
      width: 65px;
  }
}
</style>
