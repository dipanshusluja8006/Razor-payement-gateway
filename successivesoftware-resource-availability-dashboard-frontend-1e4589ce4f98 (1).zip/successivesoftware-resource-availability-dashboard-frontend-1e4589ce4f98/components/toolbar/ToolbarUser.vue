<template>
  <v-menu offset-y left transition="slide-y-transition">
    <template v-slot:activator="{ on }">
      <v-btn icon class="elevation-2" v-on="on">
        <v-badge
          color="success"
          dot
          bordered
          offset-x="10"
          offset-y="10"
        >
          <v-avatar :color="`${randomColors()}`" size="40">
            <strong class="white--text headline font-weight-bold">{{ shortName }}</strong>
            <!-- <v-img src="/images/avatars/avatar1.svg"></v-img> -->
          </v-avatar>
        </v-badge>
      </v-btn>
    </template>
    <!-- user menu list -->
    <v-list dense nav>
      <v-list-item
        v-for="(item, index) in menu"
        :key="index"
        :to="item.link"
        :exact="item.exact"
        :disabled="item.disabled"
        link
      >
        <v-list-item-icon>
          <v-icon small :class="{ 'grey--text': item.disabled }">{{ item.icon }}</v-icon>
        </v-list-item-icon>
        <v-list-item-content>
          <v-list-item-title>{{ item.text }}</v-list-item-title>
        </v-list-item-content>
      </v-list-item>

      <!-- <v-divider class="my-1"></v-divider> -->

      <v-list-item @click="signOutUser">
        <v-list-item-icon>
          <v-icon small>mdi-logout-variant</v-icon>
        </v-list-item-icon>
        <v-list-item-content>
          <v-list-item-title> Log Out</v-list-item-title>
        </v-list-item-content>
      </v-list-item>
    </v-list>
  </v-menu>
</template>

<script>
import config from '@/configs'
import { mapGetters, mapActions } from 'vuex'
import firebase from 'firebase/app'
import { projectHelpers } from '@/helpers/helper.js'

/*
|---------------------------------------------------------------------
| Toolbar User Component
|---------------------------------------------------------------------
|
| Quickmenu for user menu shortcuts on the toolbar
|
*/
export default {
  data () {
    return {
      menu: config.toolbar.user,
      shortName: ''
    }
  },
  computed: {
    ...mapGetters({
      user: 'auth/user'
    })
  },
  mounted () {
    this.shortName = this.avatarNames(this.user.username)
  },
  methods: {
    ...mapActions({
      updateAuthentication: 'auth/updateAuthentication',
      setUserDetails: 'auth/setUserDetails',
      resetState: 'dashboard/resetCartState',
      resetProjectState: 'project/resetProjectState',
      resetCartState: 'roles/resetCartState',
      resetAuthState: 'auth/resetAuthState'
    }),
    randomColors () {
      const letters = '0123456789ABCDEF'.split('')
      let color = '#'

      for (let i = 0; i < 6; i++) {
        color += letters[Math.round(Math.random() * 15)]
      }

      return color
    },
    avatarNames (fullName) {
      return projectHelpers.avatarNames(fullName)
    },
    signOutUser () {
      firebase.auth().signOut()
        .then(() => {
          this.updateAuthentication(false)
          this.setUserDetails(null)
          this.resetState()
          this.resetAuthState()
          this.resetCartState()
          this.resetProjectState()
          this.$router.push('/login')
        })
    }
  }
}
</script>
