<template>
  <v-overlay :value="show">
    <v-progress-circular indeterminate color="white" size="64" />
    <!-- <v-progress-circular
      :rotate="360"
      :size="100"
      :width="15"
      :value="value"
      color="primary"
    >
      {{ value }}
    </v-progress-circular>   -->
    <!-- <v-progress-circular
      :size="50"
      color="primary"
      indeterminate
    ></v-progress-circular> -->
    <!-- <img src="https://mir-s3-cdn-cf.behance.net/project_modules/disp/585d0331234507.564a1d239ac5e.gif"/> -->
  </v-overlay>
</template>

<script>
export default {
  name: 'Overlay',
  props: {
    show: Boolean
  },
  data () {
    return {
      interval: {},
      value: 0
    }
  },
  beforeDestroy () {
    clearInterval(this.interval)
  },
  mounted () {
    this.interval = setInterval(() => {
      if (this.value === 100) {
        return (this.value = 0)
      }
      this.value += 20
    }, 1000)
  }
}
</script>
