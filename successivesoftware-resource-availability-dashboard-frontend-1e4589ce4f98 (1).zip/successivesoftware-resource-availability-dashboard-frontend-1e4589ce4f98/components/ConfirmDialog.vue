<template>
  <v-dialog v-model="dialog" :style="{ zIndex: options.zIndex }" @keydown.esc="cancel">
    <div class="successPopup">
      <div class="successImg">
        <img src="../assets/images/custom/ErrorDialog.png" />
      </div>
      <div class="successText d-flex align-center justify-center">
        <div class="sureTextWrp">
          <h1>{{ title }}</h1>
          <p v-show="!!message">{{ message }}</p>
          <v-card-actions>
            <v-btn class="yesBtn" text @click.native="agree">
              Yes
            </v-btn>
            <v-btn class="cancleBtn" text @click.native="cancel">
              Cancel
            </v-btn>
          </v-card-actions> 
        </div>
      </div>
    </div>
  </v-dialog>
</template>

<script>
export default {
  data: () => ({
    dialog: false,
    resolve: null,
    reject: null,
    message: null,
    title: null,
    options: {
      color: 'primary',
      width: 290,
      zIndex: 200
    }
  }),
  methods: {
    open (title, message, options) {
      this.dialog = true
      this.title = title
      this.message = message
      this.options = Object.assign(this.options, options)

      return new Promise((resolve, reject) => {
        this.resolve = resolve
        this.reject = reject
      })
    },
    agree () {
      this.resolve(true)
      this.dialog = false
    },
    cancel () {
      this.resolve(false)
      this.dialog = false
    }
  }
}
</script>
