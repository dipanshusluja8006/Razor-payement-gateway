<template>
  <div class="pmProgressStageWrp">
    <v-card>
      <div class="orgdshbHeadings pb-0">
        <h4>BU RAG Status</h4>
      </div>
      <div v-if="showChart" class="pmProgressStageGraph buRagStatusGrp">
        <apexchart
          type="donut"
          width="300"
          style="margin: 0 auto;"
          :options="chartOptions"
          :series="departmentWiseRag"
          @click="clickEvent"
        ></apexchart>
      </div>
    </v-card>
  </div>
</template>
<script>
import { mapActions, mapGetters } from 'vuex'
export default {
  name: 'ProgressStageGraph',
  props: {
    departmentWiseRag: {
      type: Array,
      default: () => []
    },
    departmentId: {
      type: [String, Number],
      default: ''
    }
  },

  data () {
    return {
      // deptId:3,
      showChart: true,
      chartOptions: {
        chart: {
          type: 'donut'
        },
        labels: ['Red','Amber', 'Green', 'Not Available'],
        dataLabels: {
          enabled: false
        },
        legend: {
          show: true,
          position: 'bottom'
        },
        colors: ['#fa1001', '#fcc401', '#31ff3c', '#aea9a9'],
        fill: {
          colors: ['#fa1001', '#fcc401', '#31ff3c', '#aea9a9']
        }
      }
    }
  },
  methods:{
    ...mapActions({
      updateProjectRagStatus: 'dashboard/updateProjectRagStatus'
     
    }),
    clickEvent(event) {
      const [first,last] = event.target.classList
      const projectRagStatusIndex = last.split('-')
      const  [one,two,three,four] = projectRagStatusIndex

      if (four === '0') {
        this.storeProjectRagStatus(1)
        this.$router.push(`/bu-project-rag/${this.departmentId}`)
      }
      else if (four === '1') {
        this.storeProjectRagStatus(2)
        this.$router.push(`/bu-project-rag/${this.departmentId}`)
      } 
      else if (four === '2') {
        this.storeProjectRagStatus(3)
        this.$router.push(`/bu-project-rag/${this.departmentId}`)
      } 
      else {
        this.storeProjectRagStatus(4)
        this.$router.push(`/bu-project-rag/${this.departmentId}`)
      }

    },
    storeProjectRagStatus(value) {
      this.updateProjectRagStatus(value)
    }
  }
}

</script>

<style scoped>

</style>
