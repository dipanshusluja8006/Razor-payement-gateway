<template>
  <div class="pmProgressStageWrp">
    <v-card
      exact
      class="pmDsbpstatusCard"
    >
      <div>
        <div class="orgdshbHeadings">
          <h4 >Time In BU</h4>
          <v-row>
            <v-col cols="12">
              <v-autocomplete
                v-model="selectedUser"
                :items="userData"
                label="Select Employee"
                item-text="full_name"
                item-value="id"
                item-class="idealRow"
                class="filtersFields buDshTimefield"
                solo
                dense
                @change="fetchDepartmentRecord(selectedUser)"
              />
            </v-col>
          </v-row>
          <h5 class="orgsdhbutotlhrs">Total Hours <span>{{ totalCount }}</span></h5>
        </div>
      </div>
    </v-card>
  </div>
</template>
<script>

import { mapActions, mapGetters } from 'vuex'
export default {
  name: 'BuTimeSection',
  props: {
    departmentId: {
      type: [String, Number],
      default: ''
    }
  },
  data () {
    return {
      totalCount: 0,
      selectedUser: '',
      userData: [],
      userList: []
    }
  },
  computed: {
    ...mapGetters({
      users: 'project/getUserList',
      getResourceTime: 'AmPmDashboard/getResourceTime'
    }),
    dummyImg2 () {
      return require('@/assets/images/dummy2.png')
    }
  },
  watch: {
    departmentId () {
      this.userData = this.deptWiseUser(this.users)
      this.defaultUser()
      this.fetchDepartmentRecord()
    }
  },
  mounted () {
    this.userData = this.deptWiseUser(this.users)
    this.defaultUser()
    this.fetchDepartmentRecord()
  },
  methods: {
    ...mapActions({
      fetchResourceTime: 'AmPmDashboard/fetchResourceTime'
    }),
    defaultUser() {
      if (this.userData.length > 0) {
        this.selectedUser = this.userData[0].id
      }
    },
    deptWiseUser(data) {
      return data.filter((user) => { return user.dept.length !== 0 && user.dept.some((value) => value.id === this.departmentId) })
    },
    async fetchDepartmentRecord () {
      if (this.selectedUser !== undefined && this.selectedUser !== null && this.selectedUser !== '' &&
    this.departmentId !== undefined && this.departmentId !== null && this.departmentId !== '') {
        const requestParams = {
          'selectedUser': this.selectedUser,
          'departmentId': this.departmentId
        }

        await this.fetchResourceTime(requestParams)
        this.totalCount = this.getResourceTime
      }
    }
  }
}
</script>
