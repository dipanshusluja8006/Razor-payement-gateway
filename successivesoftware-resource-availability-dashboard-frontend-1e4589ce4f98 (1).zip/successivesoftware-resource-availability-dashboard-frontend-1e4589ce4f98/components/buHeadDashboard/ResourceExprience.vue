<template>
  <div class="pmProgressStageWrp">
    <v-card>
      <div class="orgdshbHeadings pb-0">
        <h4>Resources</h4>
      </div>
      <div v-if="showChart" class="pmProgressStageGraphResource">
        <apexchart
          type="donut"
          width="100%"
          height="auto"
          style="margin: 0 auto;"
          :options="chartOptions"
          :series="resourceCountExpRangeWise"
        ></apexchart>
      </div>
    </v-card>
  </div>
</template>
<script>
export default {
  name: 'ProgressStageGraph',
  props: {
    resourceCountExpRangeWise: {
      type: Array,
      default: () => []
    }
  },
  data () {
    return {
      showChart: true,
      chartOptions: {
        chart: {
          type: 'donut'
        },
        labels: ['0-2','2-4', '4-6', '6+'],
        dataLabels: {
          enabled: false
        },
        legend: {
          show: true,
          position: 'bottom'
        },
        colors: ['#ffa726', '#2196F3', '#4CAF50', '#ffeb3b', '#F44336'],
        fill: {
          colors: ['#ffa726', '#2196F3', '#4CAF50', '#ffeb3b', '#F44336']
        }
      }
    }
  }
}
</script>
<style scoped>
 .pmProgressStageGraphResource  {
    padding: 20px 0;
  }
  .pmProgressStageGraphResource .apexcharts-canvas {
    margin: 20px auto;
  }
</style>