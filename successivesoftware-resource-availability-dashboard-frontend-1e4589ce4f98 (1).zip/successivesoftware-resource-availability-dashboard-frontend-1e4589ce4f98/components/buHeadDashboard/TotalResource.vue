<template>
  <div class="pmProgressStageWrp">
    <v-card
      exact
      class="pmDsbpstatusCard"
    >
      <div>
        <div class="pmDsbpstatusCardWrp">
          <div class="mDsbpstatusCardImg">
            <v-img
              :src="networkIcon"
              width="70"
              height="70"
              class="img"
            />
          </div>
          <div class="mDsbpstatusCardDesc">
            <div class="mDsbpstatusCardDescInner">
              <h1 >{{ resourceCount }} </h1>
              <p >Total Resources</p>
            </div> 
          </div>
        </div>
      </div>
    </v-card>
  </div>
</template>
<script>

export default {
  name: 'TotalResource',
  props: {
    resourceCount: {
      type: [String, Number],
      default: 0
    }
  },
  computed: {
    networkIcon() {
      return require('@/assets/icons/network.png')
    }
  }
}
</script>
