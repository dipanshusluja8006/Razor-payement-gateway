<template>
  <div class="menuOuter">
    <v-list-item
      v-if="!menuItem.items"
      v-show="menuItem.show === true"
      :input-value="menuItem.value"
      :to="menuItem.link"
      :exact="menuItem.exact"
      :disabled="menuItem.disabled"
      active-class="activeMenu"
      link
      class="menuitemWrp"
    >
      <v-list-item-icon class="menuitemIcon">
        <v-icon :small="small" :class="{ 'grey--text': menuItem.disabled }">
          {{ menuItem.icon || 'mdi-circle-medium' }}
        </v-icon>
      </v-list-item-icon>
      <v-list-item-content class="menuitemName">
        <v-list-item-title>
          {{ menuItem.key ? menuItem.key : menuItem.text }}
        </v-list-item-title>
      </v-list-item-content>
    </v-list-item>

    <v-list-group
      v-else
      v-show="menuItem.show === true"
      :value="menuItem.regex ? menuItem.regex.test($route.path) : false"
      :disabled="menuItem.disabled"
      :sub-group="subgroup"
      :to="menuItem.link"
      link
      class="menuitemWrp groupMenu"
    >

      <template v-slot:activator>
        <v-list-item-icon v-if="!subgroup" class="menuitemIcon">
          <v-icon :small="small">{{ menuItem.icon || 'mdi-circle-medium' }}</v-icon>
        </v-list-item-icon>
        <v-list-item-content class="menuitemName">
          <v-list-item-title>
            {{ menuItem.text }}
          </v-list-item-title>
        </v-list-item-content>
      </template>

      <slot></slot>

    </v-list-group>
  </div>
</template>

<script>
/*
|---------------------------------------------------------------------
| Navigation Menu Item Component
|---------------------------------------------------------------------
|
| Navigation items for the NavMenu component
|
*/
import { mapMutations } from 'vuex'

export default {
  props: {
    menuItem: {
      type: Object,
      default: () => {}
    },
    subgroup: {
      type: Boolean,
      default: false
    },
    small: {
      type: Boolean,
      default: false
    }
  }
}
</script>
<style scoped>
/* .v-application .primary--text {
    color: white !important;
    caret-color: white !important;
    background: #1569C7 !important;
} */
</style>
