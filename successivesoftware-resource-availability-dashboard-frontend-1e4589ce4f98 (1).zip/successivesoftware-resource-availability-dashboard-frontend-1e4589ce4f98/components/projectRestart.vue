<template>
  <v-content class="ma-1 pa-0">
    <v-dialog
      v-model="inputDialog"
      :persistent="true"
      width="500"
    >
      <v-card>
        <v-card-title>
          <span class="headline">Reason for Restart Project</span>
        </v-card-title>
        <v-card-text class="pa-0">
          <v-container>
            <v-row>
              <v-col cols="12" class="pb-0 pt-1 pl-5 pr-5">
                <v-textarea
                  v-model="reasonForClose"
                  auto-grow
                  outlined
                  label="Please mention the reason for project restart if any"
                />
              </v-col>
            </v-row>
          </v-container>
        </v-card-text>
        <v-card-actions class="pr-5 pt-0">
          <v-spacer />
          <v-btn
            color="blue darken-1"
            dark
            class="text-capitalize"
            text
            @click="close"
          >
            Cancel
          </v-btn>
          <v-btn class="text-capitalize" color="blue darken-1" text @click="save">
            Save
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-content>
</template>
<script>
import { mapActions, mapGetters } from 'vuex'
export default {
  name: 'ProjectOperation',
  props: {
    projectDetails: {
      type: Array,
      default: () => ([])
    },
    projectId: {
      type: String,
      default: ''
    },
    inputDialog: {
      type: Boolean,
      default: false
    }

  },
  data () {
    return {
      reasonForClose: ''
    }
  },
  computed: {
    ...mapGetters({
      getRestartProject: 'project/getRestartProject'
    })
  },
  methods: {
    ...mapActions({
      projectRestart: 'project/projectRestart'
    }),
    close () {
      this.inputDialog = false
      this.reasonForClose = ''
    },
    async save () {
      const requestData = {
        'project_id': this.projectId,
        'message': this.reasonForClose
      }

      this.close()
      await this.projectRestart(requestData)
      this.reasonForClose = ''
      const projectRecord = [...this.projectDetails]

      projectRecord.forEach((element, index) => {
        const accountMangerArray = element.account_managers
        const projectMangerArray = element.project_managers
        const actionPendingArray = element.action_pending

        if (element.uuid === this.projectId) {
          projectRecord[index] = this.getRestartProject
          projectRecord[index].roleUpdated = false
          projectRecord[index].account_managers = accountMangerArray
          projectRecord[index].project_managers = projectMangerArray
          projectRecord[index].action_pending = actionPendingArray
        }
      })
      this.projectDetails = projectRecord
    }

  }
}
</script>
