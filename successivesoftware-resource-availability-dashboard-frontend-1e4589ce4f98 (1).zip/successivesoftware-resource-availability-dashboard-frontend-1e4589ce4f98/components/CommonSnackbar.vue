<template>
  <v-snackbar
    :value="snackbar"
    top
  >
    <div class="d-flex justify-space-between align-center">
      <div>
        {{ textForSnackbar }}
      </div>
      <div class="closeSnackAct">
        <v-btn
          color="pink"
          text
          @click="snackbar = false"
        >
          <v-icon>
            mdi-close
          </v-icon>
        </v-btn>
      </div>    
    </div>
  </v-snackbar>
</template>

<script>
export default {
  name: 'CommonSnackbar',
  props: {
    snackbar: Boolean,
    textForSnackbar: {
      type: String,
      default: ''
    }
  }
}
</script>

<style scoped>
  .closeSnackAct button.v-btn.v-btn--text.theme--dark.v-size--default.pink--text {
    min-width: auto;
    padding: 0 8px;
}

</style>
