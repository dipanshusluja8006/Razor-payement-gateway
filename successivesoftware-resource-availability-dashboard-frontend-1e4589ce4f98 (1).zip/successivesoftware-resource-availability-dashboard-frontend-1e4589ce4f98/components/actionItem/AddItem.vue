<template>
  <div>
    <Dialog />
    <ValidationObserver ref="projectInitObserver" v-slot="{ valid }" class="">
      <div class="addActionItemOuter">
        <div class="addActionItemWrp">
          <div class="addActionItemFldLbl">
            <div class="addActionItemlable">
              <label>Assign To *</label>
            </div>
            <div class="addActionItemField">
              <ValidationProvider
                v-slot="{ errors }"
                :rules="'required'"
                name="assignTo"
              >
                <v-autocomplete
                  v-model="assignTo"
                  :items="assignToList"
                  :error-messages="errors"
                  clearable
                  placeholder="Select AM/PM/BU Head"
                  item-text="name"
                  item-value="id"
                  dense
                />
              </ValidationProvider>
            </div>
          </div>
          <div class="addActionItemFldLbl">
            <div class="addActionItemlable">
              <label>Project</label>
            </div>
            <div class="addActionItemField">
              <ValidationProvider
                v-slot="{ errors }"

                name="selectedProject"
              >
                <v-autocomplete
                  v-model="selectedProject"
                  :items="projectList"
                  :error-messages="errors"
                  clearable
                  placeholder="Select Project"
                  item-text="name"
                  item-value="id"
                  dense
                />
              </ValidationProvider>
            </div>
          </div>
        </div>
        <div class="addActionItemWrp">
          <div class="addActionItemFldLbl">
            <div class="addActionItemlable">
              <label>Target Closure Date</label>
            </div>
            <div class="addActionItemField dateFiled">
              <v-menu
                ref="TimelineMenu"
                v-model="menu"
                :close-on-content-click="false"
                offset-y
                transition="scale-transition"
              >
                <template v-slot:activator="{ on }">
                  <v-text-field
                    slot="activator"
                    v-model="date"
                    multiple
                    readonly
                    dense
                    solo-inverted
                    filled
                    placeholder="Select Date"
                    style="color: #607d8b !important"
                    v-on="on"
                  >
                    <template v-slot:append>
                      <v-icon v-on="on">
                        mdi-calendar
                      </v-icon>
                    </template>
                  </v-text-field>
                </template>
                <v-date-picker
                  v-model="datePicker"
                  :min="minDate"
                  no-title
                  scrollable
                  @change="changeTimelineFromDateString"
                />
              </v-menu>
            </div>
          </div>
          <div class="addActionItemFldLbl">
            <div class="addActionItemlable">
              <label>Priority *</label>
            </div>
            <div class="addActionItemField">
              <ValidationProvider v-slot="{ errors }" :rules="'required'" name="priority">
                <v-autocomplete
                  v-model="priority"
                  :items="priorityValues"
                  :error-messages="errors"
                  item-text="name"
                  item-value="value"
                  placeholder="Select Task Priorty"
                  dense
                  clearable
                />
              </ValidationProvider>
            </div>
          </div>
        </div>
        <div class="addActionItemWrp addActionItemDesWrp">
          <div class="addActionItemlable">
            <label>Description *</label>
          </div>
          <div class="addActionItemField">
            <ValidationProvider v-slot="{ errors }" :rules="'required|alpha_num_whitespace_special_line_break'" name="description">
              <v-textarea
                v-model.trim="description"
                :error-messages="errors"
                :auto-grow="true"
                dense
                placeholder="Add Description"
                rows="4"
              />
            </ValidationProvider>
          </div>
        </div>
        <div class="btnWrp text-right">
          <v-btn
            v-if="!valid"
            class="continueBtn"
            :disabled="!valid"
            @click="submit"
          >
            Submit
            <v-icon
              small
            >
              mdi-chevron-right
            </v-icon>
          </v-btn>
          <v-btn v-else :disabled="submitted" class="continueBtn" @click="submit">
            Submit <v-icon
              middle
            >
              mdi-chevron-right
            </v-icon>
          </v-btn>
        </div>
      </div>
    </ValidationObserver>
  </div>
</template>

<script>

import { mapActions, mapGetters } from 'vuex'
import Dialog from '@/components/Dialog.vue'
import { projectHelpers } from '@/helpers/helper.js'
export default {
  name: 'AddItem',
  components: {
    Dialog
  },
  props: {
    assignedUserData: {
      type: Array,
      default: () => []
    },
    assignedProjectData: {
      type: Array,
      default: () => []
    }
  },
  data () {
    return {
      minDate: new Date(),
      FormatedDate: '',
      date: '',
      datePicker: new Date().toISOString().substr(0, 10),
      menu: '',
      assignTo:'',
      submitted: false,
      assignToList: [],
      projectList:[],
      selectedProject:'',
      priorityValues: [{ name: 'High', value: 3 }, { name: 'Medium', value: 2 }, { name: 'Low', value: 1 }],
      statusValues: [{ name: 'To do', value: 0 }, { name: 'Inprogress', value: 1 }, { name: 'Done', value: 2 }],
      priority:'',
      status: 0,
      description:''
    }
  },
  computed: {
    ...mapGetters({
      getCustomDialog: 'AmPmDashboard/getCustomDialog'
    })
  },
  watch: {
    assignedUserData () {
      this.assignToList = this.assignedUserData
    },
    assignedProjectData () {
      this.projectList = this.assignedProjectData
    }
  },

  mounted () {
    const today = new Date()
    const dd = String(today.getDate()).padStart(2, '0')
    const mm = String(today.getMonth() + 1).padStart(2, '0')
    const yyyy = today.getFullYear()

    this.minDate = yyyy + '-' + mm + '-' + dd
    this.assignToList = this.assignedUserData
    this.projectList = this.assignedProjectData
  },
  methods: {
    ...mapActions({
      addPendingActionItems: 'AmPmDashboard/addPendingActionItems',
      updateLoadingAction: 'project/updateLoadingAction',
      setCustomDialog: 'project/setCustomDialog'
    }),
    async submit () {
      await this.updateLoadingAction()

      const requestData = {
        'assiged_user_id': this.assignTo,
        'project_id': this.selectedProject,
        'target_closure_date': this.datePicker,
        'priority': this.priority,
        'status': this.status,
        'description': this.description
      }

      await this.addPendingActionItems(requestData)
      this.updateLoadingAction()
      this.submitted = true
      const dialogData = this.getCustomDialog

      await this.setCustomDialog(dialogData)

    },
    changeTimelineFromDateString (selected) {
      this.date  = new Date(selected).toLocaleDateString({
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      })

      this.datePicker = projectHelpers.formatDate(selected)

      return this.date
    }

  }
}
</script>
