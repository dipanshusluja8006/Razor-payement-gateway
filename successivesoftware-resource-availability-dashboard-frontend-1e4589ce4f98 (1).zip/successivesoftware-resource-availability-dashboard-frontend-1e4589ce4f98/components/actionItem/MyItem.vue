<template>
  <div class="pmDashboardOuterWrp pmPendingTableWrp">
    <Dialog />
    <confirm-dialog ref="confirm"/>
    <div class="wsrTableListWrp">
      <v-row>
        <v-col cols="12">
          <v-data-table
            :headers="headers"
            :items="myItemData"
            :items-per-page="itemPerPage"
            :footer-props="{ itemsPerPageOptions: rowsPerPage }"
            :hide-default-footer="myItemData.length ? false : true"
            :search="search"
            class="wsrTableList"
          >
            <template v-slot:item.action="{ item }">
              <div v-if="item.statusId == 1">
                <v-btn icon @click="markDone(item.uuid, 0)">
                  <v-icon color="primary">mdi-check-circle</v-icon>
                </v-btn>
              </div>
              <div v-else>
                <v-btn icon @click="markDone(item.uuid, 1)">
                  <v-icon color="primary">mdi-check-circle-outline</v-icon>
                </v-btn>
              </div>

            </template>
          </v-data-table>

        </v-col>
      </v-row>
    </div>
  </div>
</template>

<script>
import { mapActions, mapGetters } from 'vuex'
import { projectHelpers } from '@/helpers/helper.js'
import Dialog from '@/components/Dialog.vue'
import ConfirmDialog from '@/components/ConfirmDialog'
export default {
  name: 'MyItem',
  components: {
    Dialog,
    ConfirmDialog
  },
  props: {
    // eslint-disable-next-line vue/require-default-prop
    searchData: {
      type: [String, Number]
    },
    myItemList: {
      type: Array,
      default: () => []
    }
  },
  data () {
    return {
      itemPerPage: 10,
      loadMore: 12,
      search: '',
      rowsPerPage: [10, 100, 200],
      myItemData: [],
      assignToList: [],
      projectList:[],
      showChart: true,
      projectNameArray: [],
      headers: [
        { text: 'Project', align: 'center', value: 'project' },
        { text: 'Priority', align: 'center', value: 'priority' },
        { text: 'Target Closure Date', align: 'center', value: 'target_closure_date' },
        { text: 'Description', align: 'center', value: 'description' },
        { text: 'Status', align: 'center', value: 'status' },
        { text: 'Action', align: 'center', value: 'action', sortable: false }
      ]
    }
  },
  computed: {
    ...mapGetters({
      getCustomDialog: 'AmPmDashboard/getCustomDialog'
    })
  },
  watch: {
    myItemList () {
      this.myItemData = this.myItemList
    },
    searchData () {
      this.search = this.searchData
    }
  },
  mounted () {
    this.myItemData = this.myItemList
  },
  methods: {
    ...mapActions({
      setPendingItemMarkDone: 'AmPmDashboard/setPendingItemMarkDone',
      setCustomDialog: 'project/setCustomDialog'
    }),

    markDone (uuid, status) {
      let title = 'Mark As Pending'
      let sub = 'Are you sure you want to mark it as pending ?'

      if (status === 1) {
        title = 'Mark As Done'
        sub = 'Are you sure you want to mark it as done ?'
      }
      this.$refs.confirm.open(title, sub, { color: 'red' }).then((confirm) => {
        if (confirm) {
          this.submit(uuid, status)
        }
      })
    },

    async submit (uuid, status) {
      const route = this.$route.path
      const requestData = {
        uuid:uuid,
        status: status,
        route: route
      }

      await this.setPendingItemMarkDone(requestData)
      const dialogData = this.getCustomDialog

      await this.setCustomDialog(dialogData)
    }
  }
}
</script>
<style scoped>
  .wsrTableListWrp .v-data-table{
        border-radius: 0;
  }
  .pmDashboardOuterWrp .wsrTableListWrp .v-data-table.wsrTableList table > thead > tr > th i {
      font-size: 0 !important;
  }
  .pmDashboardOuterWrp .wsrTableListWrp .v-data-table.wsrTableList table > tbody > tr > td{
      padding: 15px 30px;
      word-break: unset;
  }
</style>
