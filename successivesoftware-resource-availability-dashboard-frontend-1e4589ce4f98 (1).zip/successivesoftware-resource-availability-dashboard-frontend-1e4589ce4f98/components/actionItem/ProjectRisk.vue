<template>
  <div class="pmDashboardOuterWrp pmPendingTableWrp">
    <Dialog />
    <div class="wsrTableListWrp">
      <v-row>
        <v-col cols="12">
          <v-data-table
            :headers="headers"
            :items="riskList"
            :items-per-page="itemPerPage"
            :footer-props="{ itemsPerPageOptions: rowsPerPage }"
            :hide-default-footer="riskList.length ? false : true"
            :search="search"
            class="wsrTableList"
          >

            <template v-slot:item.account_managers="{ item }">
              <span
                v-for="accountManager in item.account_managers.slice(0, 2)"
                :key="accountManager.user_id"
                class="ma-2"
                text-color="white"
              >
                <v-tooltip top>
                  <template v-slot:activator="{ on }">
                    <v-avatar :color="`${randomColors()}`" size="30" v-on="on">
                      <strong class="white--text headline">{{
                        avatarNames(accountManager.user.display_name)
                      }}</strong>
                    </v-avatar>
                  </template>
                  <span style="font-size: small; background: inherit;">
                    {{ accountManager.user.display_name }}
                  </span>
                </v-tooltip>
              </span>
              <v-menu
                bottom
                origin="center center"
                transition="scale-transition"
              >
                <template v-slot:activator="{ on }">
                  <v-btn
                    v-if="item.account_managers.length > 3"
                    class="ma-1"
                    outlined
                    fab
                    x-small
                    size="30"
                    color="blue"
                    v-on="on"
                    @click="!false"
                  >
                    <v-icon x-small>
                      mdi-plus
                    </v-icon>
                    {{
                      item.account_managers.slice(
                        3,
                        item.account_managers.length
                      ).length
                    }}
                  </v-btn>
                </template>
                <v-card v-show="!false" class="mx-auto" max-width="300" raised>
                  <v-list
                    v-if="item.account_managers.length > 3"
                    disabled
                    shaped
                  >
                    <v-list-item-group
                      v-model="item.account_managers"
                      color="primary"
                    >
                      <v-list-item
                        v-for="accountManager in item.account_managers.slice(
                          3,
                          item.account_managers.length
                        )"
                        v-show="!false"
                        :key="accountManager.user_id"
                      >
                        <v-avatar :color="`${randomColors()}`" size="30">
                          <span class="white--text headline">{{
                            avatarNames(accountManager.user.display_name)
                          }}</span>
                        </v-avatar>
                        <v-list-item-content class="ml-2">
                          <v-list-item-title
                            v-text="accountManager.user.display_name"
                          />
                        </v-list-item-content>
                      </v-list-item>
                    </v-list-item-group>
                  </v-list>
                </v-card>
              </v-menu>
            </template>
            <template v-slot:item.project_managers="{ item }">
              <span
                v-for="accountManager in item.project_managers.slice(0, 2)"
                :key="accountManager.user_id"
                class="ma-2"
                text-color="white"
              >
                <v-tooltip top>
                  <template v-slot:activator="{ on }">
                    <v-avatar :color="`${randomColors()}`" size="30" v-on="on">
                      <strong class="white--text headline">{{
                        avatarNames(accountManager.user.display_name)
                      }}</strong>
                    </v-avatar>
                  </template>
                  <span style="font-size: small; background: inherit;">
                    {{ accountManager.user.display_name }}
                  </span>
                </v-tooltip>
              </span>
              <v-menu
                bottom
                origin="center center"
                transition="scale-transition"
              >
                <template v-slot:activator="{ on }">
                  <v-btn
                    v-if="item.project_managers.length > 3"
                    class="ma-1"
                    outlined
                    fab
                    x-small
                    size="30"
                    color="blue"
                    v-on="on"
                    @click="!false"
                  >
                    <v-icon x-small>
                      mdi-plus
                    </v-icon>
                    {{
                      item.project_managers.slice(
                        3,
                        item.project_managers.length
                      ).length
                    }}
                  </v-btn>
                </template>
                <v-card v-show="!false" class="mx-auto" max-width="300" raised>
                  <v-list
                    v-if="item.project_managers.length > 3"
                    disabled
                    shaped
                  >
                    <v-list-item-group
                      v-model="item.project_managers"
                      color="primary"
                    >
                      <v-list-item
                        v-for="accountManager in item.project_managers.slice(
                          3,
                          item.project_managers.length
                        )"
                        v-show="!false"
                        :key="accountManager.user_id"
                      >
                        <v-avatar :color="`${randomColors()}`" size="30">
                          <span class="white--text headline">{{
                            avatarNames(accountManager.user.display_name)
                          }}</span>
                        </v-avatar>
                        <v-list-item-content class="ml-2">
                          <v-list-item-title
                            v-text="accountManager.user.display_name"
                          />
                        </v-list-item-content>
                      </v-list-item>
                    </v-list-item-group>
                  </v-list>
                </v-card>
              </v-menu>
            </template>
            <template v-slot:item.assignee_names_array="{ item }">
              <span
                v-for="assignee in item.assignee_names_array.slice(0, 2)"
                :key="assignee.id"
                class="ma-2"
                text-color="white"
              >
                <v-tooltip top>
                  <template v-slot:activator="{ on }">
                    <v-avatar :color="`${randomColors()}`" size="30" v-on="on">
                      <strong class="white--text headline">{{
                        avatarNames(assignee.name)
                      }}</strong>
                    </v-avatar>
                  </template>
                  <span style="font-size: small; background: inherit;">
                    {{ assignee.name }}
                  </span>
                </v-tooltip>
              </span>
              <v-menu
                bottom
                origin="center center"
                transition="scale-transition"
              >
                <template v-slot:activator="{ on }">
                  <v-btn
                    v-if="item.assignee_names_array.length > 3"
                    class="ma-1"
                    outlined
                    fab
                    x-small
                    size="30"
                    color="blue"
                    v-on="on"
                    @click="!false"
                  >
                    <v-icon x-small>
                      mdi-plus
                    </v-icon>
                    {{
                      item.assignee_names_array.slice(
                        3,
                        item.assignee_names_array.length
                      ).length
                    }}
                  </v-btn>
                </template>
                <v-card v-show="!false" class="mx-auto" max-width="300" raised>
                  <v-list
                    v-if="item.assignee_names_array.length > 3"
                    disabled
                    shaped
                  >
                    <v-list-item-group
                      v-model="item.assignee_names_array"
                      color="primary"
                    >
                      <v-list-item
                        v-for="assignee in item.assignee_names_array.slice(
                          3,
                          item.assignee_names_array.length
                        )"
                        v-show="!false"
                        :key="assignee.id"
                      >
                        <v-avatar :color="`${randomColors()}`" size="30">
                          <span class="white--text headline">{{
                            avatarNames(assignee.name)
                          }}</span>
                        </v-avatar>
                        <v-list-item-content class="ml-2">
                          <v-list-item-title
                            v-text="assignee.name"
                          />
                        </v-list-item-content>
                      </v-list-item>
                    </v-list-item-group>
                  </v-list>
                </v-card>
              </v-menu>
            </template>
          </v-data-table>

        </v-col>
      </v-row>
    </div>
  </div>
</template>

<script>
import { mapActions, mapGetters } from 'vuex'
import { projectHelpers } from '@/helpers/helper.js'
import Dialog from '@/components/Dialog.vue'
export default {
  name: 'ActiveRisk',
  components: {
    Dialog
  },
  props: {
    // eslint-disable-next-line vue/require-default-prop
    searchData: {
      type: [String, Number]
    },
    projectRiskDetails: {
      type: Array,
      default: () => []
    }
  },
  data () {
    return {
      itemPerPage: 10,
      loadMore: 12,
      search: '',
      rowsPerPage: [10, 100, 200],
      myItemData: [],
      assignToList: [],
      projectList:[],
      showChart: true,
      projectNameArray: [],
      riskList: [],
      headers: [
        { text: 'Project Name', align: 'center', value: 'project_name' },
        { text: 'Total Risk', align: 'center', value: 'total_risk' },
        { text: 'Total Risk Index', align: 'center', value: 'totalRisk_index' },
        { text: 'Risk Category', align: 'center', value: 'risk_category' },
        { text: 'Account Manager', align: 'center', value: 'account_managers'  },
        { text: 'Project Manager', align: 'center', value: 'project_managers'  },
        { text: 'Assignee', align: 'center', value: 'assignee_names_array', width:'15%' }

      ]
    }
  },
  computed: {
    ...mapGetters({
      getCustomDialog: 'AmPmDashboard/getCustomDialog'
    }),
    viewIcon() {
      return require('@/assets/icons/view-PMO.png')
    },
    editIcon () {
      return require('@/assets/icons/Edit-pmo.png')
    }
  },
  watch: {
    projectRiskDetails () {
      this.riskList = this.projectRiskDetails

    },
    searchData () {
      this.search = this.searchData
    }
  },
  mounted () {
    this.riskList = this.projectRiskDetails

  },
  methods: {
    randomColors () {
      return projectHelpers.randomColors()
    },
    avatarNames (fullName) {
      return projectHelpers.avatarNames(fullName)
    }

  }
}
</script>
<style scoped>
  .wsrTableListWrp .v-data-table{
        border-radius: 0;
  }
  .pmDashboardOuterWrp .wsrTableListWrp .v-data-table.wsrTableList table > thead > tr > th i {
      font-size: 0 !important;
  }
  .pmDashboardOuterWrp .wsrTableListWrp .v-data-table.wsrTableList table > tbody > tr > td{
      padding: 15px 30px;
      word-break: unset;
  }
</style>
