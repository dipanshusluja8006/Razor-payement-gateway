<template>
  <div class="pmDashboardOuterWrp pmPendingTableWrp">
    <div class="wsrTableListWrp">
      <v-row>
        <v-col cols="12">
          <v-data-table
            :headers="headers"
            :items="pendingItemData"
            :items-per-page="itemPerPage"
            :footer-props="{ itemsPerPageOptions: rowsPerPage }"
            :hide-default-footer="pendingItemData.length ? false : true"
            :search="search"
            class="wsrTableList"
          >
          </v-data-table>
        </v-col>
      </v-row>
    </div>
  </div>
</template>

<script>
import { mapActions, mapGetters } from 'vuex'
import { projectHelpers } from '@/helpers/helper.js'
export default {
  name: 'AddItem',
  props: {
    // eslint-disable-next-line vue/require-default-prop
    searchData: {
      type: [String, Number]
    },
    pendingItemList: {
      type: Array,
      default: () => []
    }
  },
  data () {
    return {
      itemPerPage: 10,
      loadMore: 12,
      search: '',
      rowsPerPage: [10, 100, 200],
      pendingItemData: [],
      assignToList: [],
      projectList:[],
      showChart: true,
      projectNameArray: [],
      headers: [
        { text: 'Project', align: 'center', value: 'project' },
        { text: 'Priority', align: 'center', value: 'priority' },
        { text: 'Assigned On', align: 'center', value: 'assign_on' },
        { text: 'Assigned To', align: 'center', value: 'assign_to' },
        { text: 'Target Closure Date', align: 'center', value: 'target_closure_date' },
        { text: 'Description', align: 'center', value: 'description' },
        { text: 'Status', align: 'center', value: 'status' }
      ]
    }
  },
  watch: {
    pendingItemList () {
      this.pendingItemData = this.pendingItemList
    },
    searchData () {
      this.search = this.searchData
    }
  },
  mounted () {
    this.pendingItemData = this.pendingItemList
  }
}
</script>

<style scoped>
  .wsrTableListWrp .v-data-table{
        border-radius: 0;
  }
  .pmDashboardOuterWrp .wsrTableListWrp .v-data-table.wsrTableList table > thead > tr > th i {
      font-size: 0 !important;
  }
  .pmDashboardOuterWrp .wsrTableListWrp .v-data-table.wsrTableList table > tbody > tr > td{
      padding: 15px 30px;
      word-break: unset;
  }
</style>
