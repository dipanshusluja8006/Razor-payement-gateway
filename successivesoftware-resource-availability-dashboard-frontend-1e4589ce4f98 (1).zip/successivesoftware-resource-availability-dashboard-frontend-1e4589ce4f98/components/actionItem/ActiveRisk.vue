<template>
  <div class="pmDashboardOuterWrp pmPendingTableWrp">
    <Dialog />
    <div class="wsrTableListWrp">
      <v-row>
        <v-col cols="12">
          <v-data-table
            :headers="headers"
            :items="riskList"
            :items-per-page="itemPerPage"
            :footer-props="{ itemsPerPageOptions: rowsPerPage }"
            :hide-default-footer="riskList.length ? false : true"
            :search="search"
            class="wsrTableList"
          >
            <template v-slot:item.assigned_to="{ item }">
              <span
                v-for="assigneName in item.assigned_to.slice(0,1)"
                :key="assigneName"
                class="ma-2"
                text-color="white"
              >
                <v-tooltip top>
                  <template v-slot:activator="{ on }">
                    <v-avatar
                      :color="`${randomColors()}`"
                      size="30"
                      v-on="on"
                    >
                      <strong class="white--text headline">{{ avatarNames(item.assigned_to) }}</strong>
                    </v-avatar>
                  </template>
                  <span style="font-size: small; background: inherit;">
                    {{ item.assigned_to }}
                  </span>
                </v-tooltip>
              </span>
              
            </template>
            
          </v-data-table>

        </v-col>
      </v-row>
    </div>
  </div>
</template>

<script>
import { mapActions, mapGetters } from 'vuex'
import { projectHelpers } from '@/helpers/helper.js'
import Dialog from '@/components/Dialog.vue'
import { color } from 'highcharts'
export default {
  name: 'ActiveRisk',
  components: {
    Dialog
  },
  props: {
    // eslint-disable-next-line vue/require-default-prop
    searchData: {
      type: [String, Number]
    },
    riskDetails: {
      type: Array,
      default: () => []
    }
  },
  data () {
    return {
      itemPerPage: 10,
      loadMore: 12,
      search: '',
      rowsPerPage: [10, 100, 200],      
      assignToList: [],
      projectList:[],
      showChart: true,
      projectNameArray: [],
      riskList: [],
      headers: [
        { text: 'Project', align: 'center', value: 'project_name' },
        { text: 'Risk Number', align: 'center', value: 'risk_number', class:'blue--text mb-1' },
        { text: 'Risk Index', align: 'center', color: 'red',value: 'risk_index' },
        { text: 'Priority', align: 'center', value: 'priority_id' },
        { text: 'Risk Category', align: 'center', value: 'risk_category' },
        { text: 'Assignee', align: 'center', value: 'assigned_to' },
        { text: 'Risk Description', align: 'center', value: 'risk_description' },
        { text: 'Status', align: 'center', value: 'status', sortable: false }
      ]
    }
  },
  computed: {
    ...mapGetters({
      getCustomDialog: 'AmPmDashboard/getCustomDialog'
    })
  },
  watch: {
    riskDetails () {
      this.riskList = this.riskDetails
      
    },
    searchData () {
      this.search = this.searchData
    }
  },
  mounted () {
    this.riskList = this.riskDetails
    
  },
  methods: {
    randomColors () {
      return projectHelpers.randomColors()
    },
    avatarNames (fullName) {
      return projectHelpers.avatarNames(fullName)
    }
    
  }
}
</script>
<style scoped>
  .wsrTableListWrp .v-data-table{
        border-radius: 0;
  }
  .pmDashboardOuterWrp .wsrTableListWrp .v-data-table.wsrTableList table > thead > tr > th i {
      font-size: 0 !important;
  }
  .pmDashboardOuterWrp .wsrTableListWrp .v-data-table.wsrTableList table > tbody > tr > td{
      padding: 15px 30px;
      word-break: unset;
  }
</style>
