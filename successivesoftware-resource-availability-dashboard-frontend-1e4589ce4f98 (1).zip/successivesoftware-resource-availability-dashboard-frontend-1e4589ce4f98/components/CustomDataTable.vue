<template>
  <v-card class="rounded-lg" style="margin-bottom:2%;margin-top:1%">
    <v-card-text class="cardPadding">
      <v-row v-if="header !== ''">
        <v-col cols="12">
          <span style="font-size:17px"><strong>{{ header }}</strong></span><span v-if="subHeader !== ''" style="margin-left:1%;color:darkgray"><strong>{{ subHeader }}</strong></span>
        </v-col>
      </v-row>
      <v-row>
        <v-col cols="12">
          <v-data-table
            :headers="tableHeader"
            :items="tableData"
            :hide-default-footer="tableData.length ? false : true"
            class="elevation-1"
          >
            <template v-slot:item.suggested="{ item }">
              <span
                v-for="(resource,index) in item.suggested.slice(0,2)"
                :key="index"
                class="ma-2"
                text-color="white"
              >
                <v-tooltip top>
                  <template v-slot:activator="{ on }">
                    <v-avatar
                      color="blue lighten-1"
                      size="30"
                      v-on="on"
                    >
                      <span class="white--text headline">{{ avatarNames(resource) }}</span>
                    </v-avatar>
                  </template>
                  {{ resource }}
                </v-tooltip>
              </span>
              <v-menu
                bottom
                origin="center center"
                transition="scale-transition"
              >
                <template v-slot:activator="{ on }">
                  <v-btn
                    v-if="item.suggested.length > 2"
                    outlined
                    fab
                    x-small
                    color="blue"
                    v-on="on"
                    @click="!false"
                  >
                    <v-icon x-small>
                      mdi-plus
                    </v-icon>
                    {{ item.suggested.slice(2,item.suggested.length).length }}
                  </v-btn>
                </template>
                <v-card
                  v-show="!false"
                  class="mx-auto"
                  max-width="300"
                  raised
                >
                  <v-list
                    v-if="item.suggested.length > 2"
                    disabled
                    shaped
                  >
                    <v-list-item-group
                      v-model="item.suggested"
                      color="primary"
                    >
                      <v-list-item
                        v-for="(resource,index) in item.suggested.slice(2,item.suggested.length)"
                        v-show="!false"
                        :key="index"
                      >
                        <v-avatar
                          color="blue"
                          size="30"
                        >
                          <strong class="white--text headline">{{ avatarNames(resource) }}</strong>
                        </v-avatar>
                        <v-list-item-content class="ml-2">
                          <v-list-item-title v-text="resource" />
                        </v-list-item-content>
                      </v-list-item>
                    </v-list-item-group>
                  </v-list>
                </v-card>
              </v-menu>
            </template>
          </v-data-table>
        </v-col>
      </v-row>
    </v-card-text>
  </v-card>
</template>

<script>
import { projectHelpers } from '@/helpers/helper.js'

export default {
  name: 'CustomDataTable',
  props: {
    tableData: {
      type: Array,
      default: () => ([])
    },
    tableHeader: {
      type: Array,
      default: () => ([])
    },
    header: {
      type: String,
      default: ''
    },
    subHeader: {
      type: String,
      default: ''
    }
  },
  methods: {
    avatarNames (fullName) {
      fullName =  fullName.replace(/[^a-zA-Z]/g, ' ')

      return projectHelpers.avatarNames(fullName.trim())
    }
  }
}
</script>

<style scoped>
.v-application .cardPadding {
  padding-top: 0px;
  padding-bottom: 0px;
}
.v-chip.v-size--default {
font-size: smaller;
height: auto;
}
.v-application .headline {
font-size: 1rem !important;
font-weight: 400;
line-height: 2rem;
letter-spacing: normal !important;
font-family: "Open Sans", sans-serif !important;
}
.v-text-field__slot >>> .theme--light.v-label--is-disabled {
color: rgba(0, 0, 0, 0.6);
font-size: 18px
}
.icon {
background-position: inherit;
height: 50;
width: 50;
}
</style>
