import menuUI from './menus/ui.menu'
// import menuApps from './menus/apps.menu'
// import menuPages from './menus/pages.menu'

export default {
  // main navigation - side menu
  menu: [{
    text: '',
    key: '',
    items: [
      { icon: 'mdi-view-dashboard-outline', key: 'Resource Dashboard', text: 'Resource Dashboard', link: '/', show: true }
    ]
  },
  {
    text: '',
    key: '',
    items: [
      { icon: 'mdi-file-outline', key: 'Project Initiation', text: 'Project Initiation', link: '/project-initiation', show: false }
    ]
  },
  {
    text: '',
    key: '',
    items: [
      { icon: 'mdi-google-analytics', key: 'Org Dashboard', text: 'Org Dashboard', link: '/org-dashboard', show: false }
    ]
  },
  {
    text: '',
    key: '',
    items: [
      { icon: 'mdi-briefcase', key: 'AM/PM Dashboard', text: 'AM/PM Dashboard', link: '/dashboard', show: false }
    ]
  },
  {
    text: '',
    key: '',
    items: [
      { icon: 'mdi-account-multiple', key: 'BU Dashboard', text: 'BU Dashboard', link: '/bu-dashboard', show: false }
    ]
  },
  {
    text: '',
    key: '',
    items: [
      { icon: 'mdi-format-list-bulleted-square', key: 'Project Dashboard', text: 'Project Dashboard', link: '/project-dashboard', show: false }
    ]
  },
  {
    text: '',
    key: '',
    items: [
      { icon: 'mdi-file-document', key: 'KEDB', text: 'KEDB', link: '/kedb', show: true }
    ]
  },
  {
    text: '',
    items: menuUI
  }
  ]
}
