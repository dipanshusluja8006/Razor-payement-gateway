export default {
  // Google analytics ID
  gaId: process.env.VUE_APP_GA_ID || ''
}
