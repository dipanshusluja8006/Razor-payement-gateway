export default {
  // Google maps API key
  key: process.env.VUE_APP_GMAPS_KEY || ''
}
