export default [{ icon: 'mdi-cube-outline',
  text: 'Resource Pyramid',
  regex: /^\/resource-praymid/,
  show: false,
  items: [
    { text: 'Pyramid Visualization', link: '/resource-pyramid', show: true },
    { text: 'Pyramid Settings', link: '/resource-pyramid/setting', show: true }
  ] },
{ icon: 'mdi-table-heart',
  text: 'Teams',
  regex: /^\/teams/,
  show: false,
  items: [
    { text: 'My Teams', link: '/teams/team-list', show: true },
    { text: 'RM Change Requests', link: '/teams', show: true }
  ] },
{ icon: 'mdi-account-star',
  text: 'Admin',
  regex: /^\/admin/,
  show: false,
  items: [
    { text: 'User Management', link: '/admin/user-management', show: true }
  ] }
]
