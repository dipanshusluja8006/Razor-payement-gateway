<template>
  <v-app>
    <div
      v-shortkey="['ctrl', '/']"
      class="d-flex flex-grow-1"
      @shortkey="onKeyup"
    >
      <!-- Navigation -->
      <v-navigation-drawer
        v-model="drawer"
        app
        floating
        expand-on-hover
        class="elevation-1"
        :right="$vuetify.rtl"
        :light="menuTheme === 'light'"
        :dark="menuTheme === 'dark'"
      >
        <!-- Navigation menu info -->
        <template v-slot:prepend>
          <div class="pa-2">
            <div class="title font-weight-bold text-uppercase primary--text">{{ product.name }}</div>
          </div>
        </template>

        <!-- Navigation menu -->
        <main-menu :menu="navigation" />

        <!-- Navigation menu footer -->
        <template v-slot:append>
          <!-- Footer navigation links -->
          <div class="pa-1 text-center">
            <v-btn
              v-for="(item, index) in navigation.footer"
              :key="index"
              :href="item.href"
              :target="item.target"
              small
              text
            >
              {{ item.key !== '' ? item.key : item.text }}
            </v-btn>
          </div>
        </template>
      </v-navigation-drawer>

      <!-- Toolbar -->
      <v-app-bar
        app
        :color="isToolbarDetached ? 'surface' : undefined"
        :flat="isToolbarDetached"
        :light="toolbarTheme === 'light'"
        :dark="toolbarTheme === 'dark'"
      >
        <v-card class="flex-grow-1 d-flex" :class="[isToolbarDetached ? 'pa-1 mt-3 mx-1' : 'pa-0 ma-0']" :flat="!isToolbarDetached">
          <div class="d-flex flex-grow-1 align-center">
            <div class="d-flex flex-grow-1 align-center">
              <v-app-bar-nav-icon @click.stop="drawer = !drawer"></v-app-bar-nav-icon>
              <v-spacer class="d-none d-lg-block"></v-spacer>

              <toolbar-user />
            </div>
          </div>
        </v-card>
      </v-app-bar>
      <v-custom-overlay :show="showOverlayLoading" />
      <v-main>
        <v-container :fluid="!isContentBoxed">
          <nuxt />
        </v-container>

        <v-footer app inset>
          <span>
            <div id="helpdesk_widget" style="margin-bottom:5px" /><script type="text/javascript" src="https://redmine.successive.tech/helpdesk_widget/widget.js" />
          </span>
          <v-spacer></v-spacer>
          <div class="overline">
            <v-img :src="logo" width="50px" height="20px" contain />
          </div>
        </v-footer>
      </v-main>
    </div>
  </v-app>
</template>

<script>
import { mapState, mapGetters } from 'vuex'
import constant from '@/constants/closure-checklist.js'
import config from '../configs'
import VCustomOverlay from '@/components/Overlay'
import MainMenu from '../components/navigation/MainMenu'
import ToolbarUser from '../components/toolbar/ToolbarUser'

export default {
  components: {
    MainMenu,
    ToolbarUser,
    VCustomOverlay
  },
  data() {
    return {
      drawer: null,
      showSearch: false,
      navigation: [],
      roles: [constant.ROLES.ADMIN, constant.ROLES.GLOBAL_OPERATION, constant.ROLES.SALES],
      projectDashboardVisible: false,
      projectInitiationVisible: false,
      pyramidAccess: false,
      settingsVisible: false,
      buHeadTeamVisible: false,
      goHeadMyTeamVisible: false,
      orgDashboardVisible: false,
      buDashboardVisible: false
    }
  },
  computed: {
    ...mapState('app', ['product', 'isContentBoxed', 'menuTheme', 'toolbarTheme', 'isToolbarDetached']),
    ...mapGetters({
      expiryDate: 'auth/getExpiry',
      getGlobalRole: 'roles/getGlobalRole',
      showOverlayLoading: 'project/getOverlayLoading',
      getDashboardAccess: 'roles/getDashboardAccess',
      getInitiationAccess: 'roles/getInitiationAccess',
      getGlobalTeamRole: 'roles/getGlobalTeamRole'
    }),
    logo () {
      return require('@/assets/icons/successive-logo.svg')
    }
  },
  mounted () {
    let adminAccess = false

    if (this.getDashboardAccess) {
      this.projectDashboardVisible = true
    }
    if (this.getInitiationAccess) {
      this.projectInitiationVisible = true
    }
    adminAccess = this.getGlobalRole.some((item) => item.role_id === constant.ROLE_ID.ADMIN)

    this.pmDashboardVisible = this.getGlobalRole.some((item) => item.role_id === constant.ROLE_ID.ADMIN || item.role_id === constant.ROLE_ID.ACCOUNT_MANAGER || item.role_id === constant.ROLE_ID.PROJECT_MANAGER )

    this.orgDashboardVisible = this.getGlobalRole.some((item) => item.role_id === constant.ROLE_ID.ADMIN || item.role_id === constant.ROLE_ID.GLOBAL_OPERATION)
    this.buDashboardVisible = this.getGlobalRole.some((item) => item.role_id === constant.ROLE_ID.ADMIN || item.role_id === constant.ROLE_ID.BU_HEAD )

    this.pyramidAccess = this.getGlobalRole.some((item) => item.role_id === constant.ROLE_ID.ADMIN || item.role_id === constant.ROLE_ID.RESOURCE_MANAGER || item.role_id === constant.ROLE_ID.GLOBAL_OPERATION || item.role_id === constant.ROLE_ID.ACCOUNT_MANAGER || item.role_id === constant.ROLE_ID.PROJECT_MANAGER || item.role_id === constant.ROLE_ID.BU_HEAD)
    this.goHeadMyTeamVisible = this.getGlobalRole.some((item) => item.role_id === constant.ROLE_ID.ADMIN || item.role_id === constant.ROLE_ID.BU_HEAD || item.role_id === constant.ROLE_ID.GLOBAL_OPERATION)
    if (!this.pyramidAccess) {
      this.pyramidAccess = this.getGlobalTeamRole
    }
    if (this.getGlobalRole.length) {
      this.getGlobalRole.map((role) => {
        if (role.role_id === constant.ROLE_ID.ADMIN || role.role_id === constant.ROLE_ID.GLOBAL_OPERATION) {
          this.settingsVisible = true

          return this.settingsVisible
        }
      })
      this.getGlobalRole.map((role) => {
        if (role.role_id === constant.ROLE_ID.ADMIN || role.role_id === constant.ROLE_ID.BU_HEAD) {
          this.buHeadTeamVisible = true

          return this.buHeadTeamVisible
        }
      })
    }

    const menuArray = config.navigation.menu

    /*
    * Role based display of the Nav Menu Items
    */

    for (let i = 0; i < menuArray.length; i++) {
      for ( let j = 0; j < menuArray[i].items.length; j++) {
        if (!menuArray[i].items[j].items) {
          if (menuArray[i].items[j].link === '/project-initiation') {
            menuArray[i].items[j].show = this.projectInitiationVisible
          } else if (menuArray[i].items[j].link === '/project-dashboard') {
            menuArray[i].items[j].show = this.projectDashboardVisible
          } else if (menuArray[i].items[j].link === '/dashboard') {
            menuArray[i].items[j].show = this.pmDashboardVisible
          }
          else if (menuArray[i].items[j].link === '/org-dashboard') {
            menuArray[i].items[j].show = this.orgDashboardVisible
          }
          else if (menuArray[i].items[j].link === '/bu-dashboard') {
            menuArray[i].items[j].show = this.buDashboardVisible
          }
          else {
            menuArray[i].items[j].show = true
          }
        } else {
          for (let k = 0; k < menuArray[i].items[j].items.length; k++) {
            if (menuArray[i].items[j].text === 'Teams') {
              if (this.buHeadTeamVisible === true || this.goHeadMyTeamVisible === true) {
                menuArray[i].items[j].show = true
              }
            } else if (menuArray[i].items[j].text === 'Resource Pyramid') {
              menuArray[i].items[j].show = this.pyramidAccess
            } else if (menuArray[i].items[j].text === 'Admin') {
              menuArray[i].items[j].show = adminAccess
            }
            /*
            * Role based display of the Nav Menu Sub Items
            */
            if (menuArray[i].items[j].items[k].link === '/resource-pyramid') {
              menuArray[i].items[j].items[k].show = this.pyramidAccess
            } else if (menuArray[i].items[j].items[k].link === '/resource-pyramid/setting') {
              menuArray[i].items[j].items[k].show = this.settingsVisible
            } else if (menuArray[i].items[j].items[k].link === '/teams/team-list') {
              if (this.buHeadTeamVisible === true || this.goHeadMyTeamVisible === true) {
                menuArray[i].items[j].items[k].show = true
              }
            } else if (menuArray[i].items[j].items[k].link === '/teams') {
              menuArray[i].items[j].items[k].show = this.buHeadTeamVisible
            }
          }
        }
      }
    }
    this.navigation = menuArray
  },
  methods: {
    onKeyup(e) {
      this.$refs.search.focus()
    }
  }
}
</script>

<style scoped>
.buy-button {
  box-shadow: 1px 1px 18px #ee44aa;
}
.v-overlay{
  z-index: 8 !important;
}
</style>
