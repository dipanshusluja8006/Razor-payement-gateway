<?php

namespace App;


use Illuminate\Auth\Authenticatable;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Database\Eloquent\Model;
use Laravel\Lumen\Auth\Authorizable;
use App\ResourceBooking;
use App\CustomValue;
use App\CustomField;


class User extends Model implements AuthenticatableContract, AuthorizableContract
{
    use Authenticatable, Authorizable;


    protected $connection = "redmine_db_mysql";

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'id',
        'login',
        'hashed_password',
        'firstname',
        'lastname',
        'admin',
        'status',
        'last_login_on',
        'language',
        'auth_source_id',
        'created_on',
        'updated_on',
        'type',
        'identity_url',
        'mail_notification',
        'salt',
        'must_change_passwd',
        'passwd_changed_on',
        'accept_agreement_at',
        'parent_id',
        'lft',
        'rgt',
    ];
    public $timestamps = false;
    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
        'password',
    ];

    public function ResourceBooking()
    {
        return $this->hasMany('App\ResourceBooking', 'assigned_to_id', 'id')->with('Project')->select('id', 'project_id', 'start_date', 'end_date', 'hours_per_day', 'assigned_to_id', \DB::raw("CONCAT(start_date,'-',end_date) as date_range"));
    }
    public function CustomValue()
    {
        return $this->hasMany('App\CustomValue', 'customized_id', 'id');
    }
    public function userDepartment()
    {
        return $this->hasMany('App\CustomValue', 'customized_id', 'id')->where('custom_field_id', 21);
    }

    public function emailAddresse()
    {
        return $this->belongsTo('App\EmailAddresse', 'id', 'user_id')->select('id', 'user_id', 'address', 'is_default', 'notify');
    }

    public function ReportingManager()
    {
        return $this->hasOne('App\Models\ReportingManager', 'resource_id', 'id')->where('is_approved', 1)->with('ActiveResourceManager', 'RequestedResourceManager')->orderBy('created_at', 'DESC');
    }

    public function defaultRole()
    {
        return $this->hasMany('App\Models\UserRole', 'user_id', 'id')
                    ->select('id', 'user_id', 'role_id', 'dept_id')
                    ->whereIn('role_id', ['5', '6'])
                    ->with('role');
    }

    public function editableRole()
    {
        return $this->hasMany('App\Models\UserRole', 'user_id', 'id')
            ->select('id', 'user_id', 'role_id', 'dept_id')
            ->whereNotIn('role_id', ['5', '6', '8'])
            ->with('role');
    }
}
