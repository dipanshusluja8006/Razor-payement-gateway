<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmailAddresse extends Model {

    /**
     * The table associated with the model.
     *
     * @var string
     */
    public $timestamps = false;
    protected $connection="redmine_db_mysql";
    protected $fillable = [

        'id',
        'user_id',
        'address',
        'is_default',
        'notify',
        'created_on',
        'updated_on'
    ];


}
