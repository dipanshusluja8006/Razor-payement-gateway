<?php

namespace App;
use Illuminate\Database\Eloquent\Model;
use Helpers;
use Carbon\Carbon;
use Awobaz\Compoships\Compoships;
use Illuminate\Support\Facades\DB;

class TimeEntrie extends Model {

    /**
     * The table associated with the model.
     *
     * @var string
     */
    use Compoships;
    protected $connection="redmine_db_mysql";
    protected $fillable = [
        'id',
        'project_id',
        'user_id',
        'issue_id',
        'hours',
        'comments',                                                                                                                                                                                                                                                                                                                                                                                       
        'activity_id',          
        'spent_on',
        'tyear',  
        'tmonth',  
        'tweek',  
        'created_on',  
        'updated_on',
    ];

}
