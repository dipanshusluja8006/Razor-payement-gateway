<?php

use App\Mail\ResourceDeAllocationMail;
use App\Mail\AutoExtensionMail;
use App\Models\MailContent;
use App\EmailAddresse;
use App\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use App\Models\UserRole;
use App\Models\ProjectAction;
use App\Jobs\QueueJob;
use App\Mail\BenchResourceMail;
use App\Models\Role;
use App\Models\Department;
use App\Models\Designation;
use App\Models\Project;
use App\Models\ResourceRequisition;
use App\Models\Technology;
use App\Models\ResourceMapping;
use App\Libraries\MailService;
use App\Models\ProjectDomain;
use App\Models\BillingType;
use App\Models\ProjectType;
use App\Models\GovernanceCategory;
use Illuminate\Http\Request;
use App\Models\BillingMedium;
use Carbon\Carbon;
use App\Models\LogActivity as LogActivityModel;
use App\Models\ProjectActivity as ProjectActivityModel;
use App\CustomValue;
use App\Project as RedmineProjectModel;
use App\ResourceBooking;
use App\Member;
use App\Role as RedmineRolesModel;
use Successive\Keka\Http\Services\EmployeeService;
use App\MemberRole;
use App\Models\LifeCycle;
use App\CustomFieldEnumeration;
use App\Models\CustomValueApi;
use Successive\Keka\Http\Services\CurlHelper;



class Helpers
{

    /**
     * using sendResponse() function for creating response format
     * @param $location
     * @param $message
     * @return \Illuminate\Http\Response|\Laravel\Lumen\Http\ResponseFactory
     */
    static function sendResponse($location, $message)
    {
        if ($location != null) {
            $res['status'] = 200;
            $res['message'] = 'success, ' . $message;
            $res['data'] = $location;
            return response($res);
        } else {
            $res['status'] = 500;
            $res['message'] = 'error!, ' . $message;
            return response($res);
        }
    }

    public static function callKekaHoliday($dates = false){
        $ALL_LEAVES_ENDPOINT = '/v1/leaves/';
        $GET_METHOD = 'GET';
        try {
            $curlHelper = new CurlHelper();
            return $curlHelper->CallAPI($GET_METHOD, $ALL_LEAVES_ENDPOINT, $dates);
        }catch (\Exception $exception){
            return $exception;
        }
    }

    public static function timeEntryExceptionUsersIdList()
    {
        $data = DB::connection('redmine_db_mysql')->table('users as u')
            ->join('groups_users  as gu', 'u.id', '=', 'gu.group_id')
            ->select('gu.user_id')
            ->where('u.type', '=', config('constant.TIME_ENTRY_EXCEPTION.group'))
            ->where('u.lastname', '=', config('constant.TIME_ENTRY_EXCEPTION.name'))
            ->pluck('gu.user_id')->toArray();
        return $data;
    }

    public static function dateDiffExcludingWeekend($startDate, $endDate)
    {
        $start = new DateTime($startDate);
        $end = new DateTime($endDate);
        $holidays = array();
        $period = new DatePeriod($start, new DateInterval('P1D'), $end);
        $days = array();
        foreach ($period as $day) {
            $dayOfWeek = $day->format('N');
            if ($dayOfWeek < 6) {
                $format = $day->format('Y-m-d');
                if (false === in_array($format, $holidays)) {
                    $days[] = $day;
                }
            }
        }
        return count($days);
    }

    /**
     * fetching possible_values from custom_fields table and create its array
     * @param $value
     * @return array|mixed|string
     */
    public static function PossibleValuesArray($value)
    {
        $value = (new App\CustomField)->possibleValues($value);
        if (!is_null($value)) {
            $value = $value->possible_values;
            $value = str_replace("\"", '', $value);
            $value = str_replace('---', '', $value);
            $value = trim(preg_replace('/\n/', '', $value));
            $value = explode('- ', strtolower($value));
            $value = array_filter($value);
            $value = array_diff($value, config('constant.EXCLUDE_DEPARTMENTS'));
            $value = array_values($value);
            $value = array_map('ucfirst', $value);
        }
        return $value;
    }

    /**
     * send reminder mail about resource booking ending
     * @param $mailData
     * @param $mail_to
     * @return array|mixed|string
     */

    public static function sendMail($mailData, $mailTo)
    {
        $blacklistEmails = config('constant.BLACKLIST_EMAILS');
        $customEmail=config('constant.CUSTOM_RESOURCEMAIL');
        $mailTo = array_merge($mailTo,$customEmail);
        $mailTo = array_diff($mailTo, $blacklistEmails);
        Mail::to($mailTo)->send(new ResourceDeAllocationMail($mailData));
        return true;
    }

    public static function sendAutoExtensionMail($mailData, $mailTo)
    {
        $blacklistEmails = config('constant.BLACKLIST_EMAILS');
        $CUSTOM_GAURAVEMAIL = config('constant.CUSTOM_GAURAVEMAIL');
        $CUSTOM_ASHISHEMAIL = config('constant.CUSTOM_ASHISHEMAIL');
        $mailTo = array_diff($mailTo, $blacklistEmails);
        $mailTo = array_merge($mailTo, $CUSTOM_GAURAVEMAIL);
        $mailTo = array_merge($mailTo, $CUSTOM_ASHISHEMAIL);
        Mail::to($mailTo)->send(new AutoExtensionMail($mailData));
        return true;
    }

    public static function sendBenchResourceMail($mailData, $mailId)
    {
        Mail::to($mailId)->cc(['prateek.gera@successive.tech'])->send(new BenchResourceMail($mailData));
        return true;
    }

    public static function getAccountManagerEmail($projectId)
    {
        $projectManager = config('constant.USER_ROLE_REDMINE.account_manager');
        return \Helpers::getManagersEmails($projectId, $projectManager);
    }

    public static function getProjectManagerEmail($projectId)
    {
        $accountManager = config('constant.USER_ROLE_REDMINE.project_manager');
        return \Helpers::getManagersEmails($projectId, $accountManager);
    }

    public static  function getManagersEmails($projectId, $manager)
    {
        $managerEmail = [];
        if ($projectId) {
            $data = DB::connection('redmine_db_mysql')->table('projects as p')
                ->join('members  as m', 'p.id', '=', 'm.project_id')
                ->join('member_roles  as mr', 'mr.member_id', '=', 'm.id')
                ->join('roles  as r', 'r.id', '=', 'mr.role_id')
                ->join('users  as u', 'u.id', '=', 'm.user_id')
                ->join('email_addresses  as ea', 'u.id', '=', 'ea.user_id')
                ->select('ea.address')
                ->where('u.status', '=', 1)
                ->where(function ($query) use ($projectId, $manager) {
                    $query->where('p.id', '=', $projectId);
                    $query->where('r.name', '=', $manager);
                })
                ->pluck('ea.address')->toArray();
            $managerEmail = $data;
        }
        return $managerEmail;
    }

    /**
     * gets instance of MailContent Acc to code
     *
     * @param string $code
     * @return mixed
     */
    public static function getTemplateByCode($code = '')
    {

        $data = MailContent::where('code', $code)->first();
        return $data;
    }

    /**
     * checks if a employee is authorized or not
     *
     * @param $empId
     * @param $projectId
     * @param $authorizedRole
     * @return bool
     */


    public static function getRole($user_id, $project_id = null)
    {
        $roles = array();
        $roles['global'] = [];
        $roles['department'] = [];
        $roles['project'] = [];
        $BUHead = \Helpers::getRoleIdByCode(config('constant.ROLES.bu_head'));
        if ($user_id) {
            $global_roles = UserRole::where(['project_id' => null, 'user_id' => $user_id])->select('id', 'role_id', 'dept_id')->get();
            foreach ($global_roles as $value) {
                array_push($roles['global'], $value['role_id']);
                if ($value['role_id'] == $BUHead && isset($value['dept_id'])) {
                    array_push($roles['department'], $value['dept_id']);
                }
            }
           $redmineDept = Self::getUserDepartments($user_id);
            if(isset($redmineDept) && in_array(trim(config('constant.GO_TEAM_DEPARTMENT')), $redmineDept)){
                array_push($roles['global'], 8);
            }
        }
        if ($project_id) {
            $project_roles = UserRole::where(['project_id' => $project_id, 'user_id' => $user_id])->select('id', 'role_id')->get();
            foreach ($project_roles as $value) {
                array_push($roles['project'], $value['role_id']);
            }
        }
        return $roles;
    }


    /**
     * @param $code what action is performed
     * @return array of roles to whom send email on performed action
     * @throws Exception
     *
     * sales will work fine according new changes
     * GO will work fine according new changes
     * resource_manager will work fine according new changes
     */
    public static function getEmailTo($code)
    {
        switch (trim($code)) {
            case 'initiation':
                $mailTo = [
                    // config('constant.ROLES.resource_manager')
                    config('constant.ROLES.account_manager'),
                    config('constant.ROLES.project_manager')
                ];
                break;
            case 'project_detail_updation':
                $mailTo = [
                    config('constant.ROLES.resource_manager')
                ];
                break;
            case 'creation':
                $mailTo = [
                    config('constant.ROLES.global_operation'),
                    config('constant.ROLES.sales')
                ];
                break;
            case 'requisition':
                $mailTo = [
                    config('constant.ROLES.bu_head'),
                ];
                break;
            case 'edit_requisition':
                $mailTo = [
                    config('constant.ROLES.bu_head')
                ];
                break;
            case 'delete_requisition':
                $mailTo = [
                    config('constant.ROLES.bu_head')
                ];
                break;
            case 'edit_extension_requisition':
                    $mailTo = [
                    config('constant.ROLES.bu_head')
                ];
                break;
            case 'delete_extension_requisition':
                    $mailTo = [
                        config('constant.ROLES.bu_head')
                    ];
                break;
            case 'partial_allocation':
                $mailTo = [
                    config('constant.ROLES.account_manager'),
                    config('constant.ROLES.project_manager')
                ];
                break;
            case 'allocation':
                $mailTo = [
                    // config('constant.ROLES.resource_manager') old
                    // new
                    config('constant.ROLES.account_manager'),
                    config('constant.ROLES.project_manager')
                ];
                break;
            case 'edit_allocation':
                $mailTo = [
                    config('constant.ROLES.account_manager'),
                    config('constant.ROLES.project_manager')
                ];
                break;
            case 'edit_allocation_rm':
                $mailTo = [
                    config('constant.ROLES.account_manager'),
                    config('constant.ROLES.project_manager')
                ];
                break;
            case 'edit_direct_allocation':
                $mailTo = [
                    config('constant.ROLES.resource_manager')
                ];
                break;
            case 'delete_allocation':
                $mailTo = [
                    config('constant.ROLES.account_manager'),
                    config('constant.ROLES.project_manager')
                ];
                break;
            case 'delete_allocation_rm':
                $mailTo = [
                    config('constant.ROLES.account_manager'),
                    config('constant.ROLES.project_manager')
                ];
                break;
            case 'delete_direct_allocation':
                $mailTo = [
                    config('constant.ROLES.resource_manager')
                ];
                break;
            case 'mapping':
                $mailTo = [
                    config('constant.ROLES.account_manager'),
                    config('constant.ROLES.project_manager')
                ];
                break;
            case 'de_allocation':
                $mailTo = [
                    config('constant.ROLES.bu_head'),
                    config('constant.ROLES.global_operation'),
                    config('constant.ROLES.sales')
                ];
                break;
            case 'partial_resource_deallocation':
                $mailTo = [
                    config('constant.ROLES.bu_head'),
                    config('constant.ROLES.global_operation'),
                    config('constant.ROLES.sales')
                ];
                break;
            case 'de_allocation_mapping':
                $mailTo = [
                    config('constant.ROLES.account_manager'),
                    config('constant.ROLES.project_manager')
                ];
                break;
            case 'resource_allocation_rejection':
                $mailTo = [
                    config('constant.ROLES.bu_head')
                ];
                break;
            case 'resource_allocation_approval':
                $mailTo = [
                    // config('constant.ROLES.resource_manager') old
                    // new
                    config('constant.ROLES.bu_head')
                ];
                break;
            case 'resource_reallocation':
                $mailTo = [
                    config('constant.ROLES.resource_manager')
                ];
                break;
            case 'resource_reallocation_partial':
                $mailTo = [
                    config('constant.ROLES.account_manager'),
                    config('constant.ROLES.project_manager')
                ];
                break;
            case 'on_hold_request':
                $mailTo = [
                    config('constant.ROLES.global_operation'),
                    config('constant.ROLES.sales')
                ];
                break;
            case 'on_hold_approved':
                $mailTo = [
                    config('constant.ROLES.account_manager'),
                    config('constant.ROLES.project_manager')
                ];
                break;
            case 'on_hold_rejection':
                $mailTo = [
                    config('constant.ROLES.account_manager'),
                    config('constant.ROLES.project_manager')
                ];
                break;
            case 'restart':
                $mailTo = [
                    config('constant.ROLES.resource_manager')
                ];
                break;
            case 'project_close':
                $mailTo = [
                    config('constant.ROLES.resource_manager')
                ];
                break;
            case 'rca_creation':
                $mailTo = [
                    config('constant.ROLES.account_manager'),
                    config('constant.ROLES.project_manager')
                ];
                break;
            case 'extension':
                $mailTo = [
                    config('constant.ROLES.bu_head'),
                ];
                break;
            case 'direct_extension':
                $mailTo = [
                    // config('constant.ROLES.resource_manager')
                    config('constant.ROLES.account_manager'),
                    config('constant.ROLES.project_manager')
                ];
                break;
            case 'delete_reallocation':
                $mailTo = [
                    config('constant.ROLES.resource_manager')
                ];
                break;

          //initiation_request
            case 'initiation_request':
                $mailTo = [
                    config('constant.ROLES.global_operation')
                ];
                break;
            case 'initiation_approval':
                $mailTo = [
                    // config('constant.ROLES.go_team')
                    config('constant.ROLES.account_manager'),
                    config('constant.ROLES.project_manager')
                ];
                break;
            case 'initiation_decline':
                $mailTo = [
                    config('constant.ROLES.go_team')
                ];
                break;
            case 'initiation_request_update':
                $mailTo = [
                    config('constant.ROLES.global_operation'),
                ];
                break;
             //reporting manager change process
            case 'reporting_manager_change_request':
                $mailTo = [
                    config('constant.ROLES.bu_head'),
                ];
                break;
            case 'reporting_manager_approval':
                $mailTo = [
                    config('constant.ROLES.hr'),
                ];
                break;
            case 'reporting_manager_decline':
                $mailTo = [
                    config('constant.ROLES.account_manager'),
                    config('constant.ROLES.project_manager')
                ];
                break;
            case 'reporting_manager_changes':
                $mailTo = [
                    config('constant.ROLES.hr'),
                ];
                break;
            case 'reporting_manager_system_changes':
                $mailTo = [
                    config('constant.ROLES.hr'),
                ];
                break;
            case 'reject_requisition_email':
                $mailTo = [
                    config('constant.ROLES.project_manager'),
                    config('constant.ROLES.account_manager')
                ];
                break;
            case 'employee_allocation_email':
                $mailTo = [
                    config('constant.ROLES.project_manager')
                ];
                break;
            case 'employee_de_allocation_email':
                    $mailTo = [
                        config('constant.ROLES.project_manager')
                    ];
                    break;
            case 'bu_assignment_as_rm':
                $mailTo = [
                    config('constant.ROLES.hr'),
                ];
                break;
            default:
                throw new \Exception('Unexpected value');
        }
        return $mailTo;
    }

    public static function getEmailCC($code)
    {
        switch (trim($code)) {
            case 'initiation':
                $mailcc = [
                    config('constant.ROLES.resource_manager'),
                    config('constant.ROLES.sales'),
                    config('constant.ROLES.global_operation')
                ];
                break;
            case 'project_detail_updation':
                $mailcc = [
                    config('constant.ROLES.account_manager'),
                    config('constant.ROLES.project_manager')
                ];
                break;
            case 'creation':
                $mailcc = [
                    config('constant.ROLES.account_manager'),
                    config('constant.ROLES.project_manager')
                ];
                break;
            case 'requisition':
                $mailcc = [
                    config('constant.ROLES.account_manager'),
                    config('constant.ROLES.project_manager')
                ];
                break;
            case 'edit_requisition':
                $mailcc = [
                    config('constant.ROLES.account_manager'),
                    config('constant.ROLES.project_manager')
                ];
                break;
            case 'delete_requisition':
                $mailcc = [
                    config('constant.ROLES.account_manager'),
                    config('constant.ROLES.project_manager')
                ];
                break;
            case 'edit_extension_requisition':
                $mailcc = [
                    config('constant.ROLES.account_manager'),
                    config('constant.ROLES.project_manager')
                ];
                break;
            case 'delete_extension_requisition':
                $mailcc = [
                    config('constant.ROLES.account_manager'),
                    config('constant.ROLES.project_manager')
                ];
                break;
            case 'allocation':
                $mailcc = [
                    // old
                    // config('constant.ROLES.account_manager'),
                    // config('constant.ROLES.project_manager'),
                    // config('constant.ROLES.global_operation'),
                    // config('constant.ROLES.sales')
                    // new
                    config('constant.ROLES.resource_manager'),
                    config('constant.ROLES.sales'),
                    config('constant.ROLES.global_operation')
                ];
                break;
            case 'resource_allocation_approval':
                $mailcc = [
                    // old
                    // config('constant.ROLES.account_manager'),
                    // config('constant.ROLES.project_manager'),
                    // config('constant.ROLES.bu_head'),
                    // config('constant.ROLES.global_operation'),
                    // config('constant.ROLES.sales')
                    // new
                    config('constant.ROLES.resource_manager'),
                    config('constant.ROLES.sales'),
                    config('constant.ROLES.global_operation')
                ];
                break;
            case 'resource_allocation_rejection':
                $mailcc = [
                    /* old
                    config('constant.ROLES.account_manager'),
                    config('constant.ROLES.project_manager'),
                    config('constant.ROLES.global_operation'),
                    config('constant.ROLES.sales') */
                    // new 
                    config('constant.ROLES.global_operation'),
                    config('constant.ROLES.sales'),
                    config('constant.ROLES.resource_manager')
                ];
                break;
            case 'edit_allocation_rm':
                $mailcc = [
                    config('constant.ROLES.resource_manager')
                ];
                break;
            case 'edit_direct_allocation':
                $mailcc = [
                    config('constant.ROLES.account_manager'),
                    config('constant.ROLES.project_manager')
                ];
                break;
            case 'delete_allocation_rm':
                $mailcc = [
                    config('constant.ROLES.resource_manager')
                ];
                break;
            case 'delete_direct_allocation':
                $mailcc = [
                    config('constant.ROLES.account_manager'),
                    config('constant.ROLES.project_manager')
                ];
                break;
            case 'mapping':
                $mailcc = [
                    config('constant.ROLES.bu_head')
                ];
                break;
            case 'de_allocation':
                $mailcc = [
                    config('constant.ROLES.account_manager'),
                    config('constant.ROLES.project_manager'),
                    config('constant.ROLES.resource_manager')
                ];
                break;
            case 'partial_resource_deallocation':
                $mailcc = [
                    config('constant.ROLES.account_manager'),
                    config('constant.ROLES.project_manager'),
                    config('constant.ROLES.resource_manager')
                ];
                break;
            case 'de_allocation_mapping':
                $mailcc = [
                    config('constant.ROLES.bu_head')
                ];
                break;
            case 'resource_reallocation':
                $mailcc = [
                    config('constant.ROLES.account_manager'),
                    config('constant.ROLES.project_manager'),
                    config('constant.ROLES.global_operation'),
                    config('constant.ROLES.sales')
                ];
                break;
            case 'on_hold_request':
                $mailcc = [
                    config('constant.ROLES.account_manager'),
                    config('constant.ROLES.project_manager')
                ];
                break;
            case 'on_hold_rejection':
                $mailcc = [
                    config('constant.ROLES.resource_manager')
                ];
                break;
            case 'restart':
                $mailcc = [
                    config('constant.ROLES.account_manager'),
                    config('constant.ROLES.project_manager'),
                    config('constant.ROLES.global_operation'),
                    config('constant.ROLES.sales')
                ];
                break;
            case 'project_close':
                $mailcc = [
                    config('constant.ROLES.account_manager'),
                    config('constant.ROLES.project_manager'),
                    config('constant.ROLES.global_operation'),
                    config('constant.ROLES.sales')
                ];
                break;
            case 'extension':
                $mailcc = [
                    config('constant.ROLES.account_manager'),
                    config('constant.ROLES.project_manager')
                ];
                break;
            case 'direct_extension':
                $mailcc = [
                    config('constant.ROLES.resource_manager'),
                    config('constant.ROLES.sales'),
                    config('constant.ROLES.global_operation')
                ];
                break;
            case 'delete_reallocation':
                $mailcc = [
                    config('constant.ROLES.account_manager'),
                    config('constant.ROLES.project_manager')
                ];
                break;
            case 'initiation_approval':
                $mailcc = [
                    // config('constant.ROLES.global_operation')
                        // only send to who created request
                    config('constant.ROLES.resource_manager'),
                    config('constant.ROLES.sales'),
                    config('constant.ROLES.global_operation')
                ];
                break;
            case 'initiation_decline':
                $mailcc = [
                    config('constant.ROLES.global_operation')
                    // only send to who created request
                ];
                break;
            case 'initiation_request_update':
                $mailcc = [
                       config('constant.ROLES.go_team'),
                ];
                break;
            //reporting manager change process
            case 'reporting_manager_change_request':
                $mailcc = [
                    config('constant.ROLES.account_manager'),
                    config('constant.ROLES.project_manager')
                ];
                break;
            case 'reporting_manager_approval':
                $mailcc = [
                    config('constant.ROLES.bu_head'),
                    config('constant.ROLES.account_manager'),
                    config('constant.ROLES.project_manager')
                ];
                break;
            case 'reporting_manager_decline':
                $mailcc = [
                    config('constant.ROLES.bu_head'),
                ];
                break;
            case 'reporting_manager_changes':
                $mailcc = [
                    config('constant.ROLES.bu_head'),
                ];
                break;
            case 'reporting_manager_system_changes':
                $mailcc = [
                    config('constant.ROLES.bu_head'),
                ];
                break;
            default:
               $mailcc=[];
        }
        return $mailcc;
    }

    public static function sendProjectMappingMailWithAllocationId($projectId,$allocatedIDArray)
    {
        $mailTemplate = [config('constant.TEMPLATES.allocation')];
        $mappingData = [];
        $mappedRecords = ResourceMapping::where(['project_id' => $projectId, 'status' => '0'])
        ->whereIn('allocated_resource_id', $allocatedIDArray)->with('resourceAllocation', 'resource')->get();
        foreach ($mappedRecords as $value) {
            if ($value['resourceAllocation']['resourceRequisition']['status'] == 1) {
                $data = [
                    'flag' => true,
                    'allocation_status' => config('constant.PROJECT_ACTION')['resource_allocation_response_accept'],
                    'efforts' => $value['hours'],
                    'start_date' => $value['start_date'],
                    'end_date' => $value['end_date'],
                    'experience' => $value['resourceAllocation']['experience'],
                    'employee_code' => \Helpers::getEmployeeCode($value['resource_id']),
                    'resource_name' => $value['resource']['display_name'],
                    'employee_email' => \Helpers::getUserEmail($value['resource_id']),
                    'department' => $value['resourceAllocation']['resourceRequisition']['department']['name'],
                    'designation' => $value['resourceAllocation']['resourceRequisition']['designation']['name'],
                    'billing_type' =>\Helpers::getBillableType($value['resourceAllocation']['resourceRequisition']['billing_type']),
                    'type' =>$value['resourceAllocation']['resourceRequisition']['type']
                ];
                array_push($mappingData, $data);
            }
        }
        if (!empty($mappingData)) {
            foreach ($mailTemplate as $template) {
                $mailService = new MailService($template, $projectId, $mappingData);
                $mailService->sendMail();
            }
        }
    }

    public static function sendProjectMappingMail($projectId,$mailData)
    {
        $mailTemplate = [config('constant.TEMPLATES.allocation')];
            foreach ($mailTemplate as $template) {
                $mailService = new MailService($template, $projectId, $mailData);
                $mailService->sendMail();
        }
    }
    /**
     * Getting global role user ids
     * @param $dept_id
     * @param $role (role code)
     * @return array
     */
    public static function getGlobalUserId($dept_id, $roleCode)
    {
        $roleId = \Helpers::getRoleIdByCode($roleCode);
        $query = UserRole::where('role_id', $roleId);
        if (isset($dept_id[0])) {
            $query = $query->whereIn('dept_id', $dept_id);
        }
        $users = $query->get();
        $emails = [];
        if (isset($users[0])) {
            foreach ($users as $user) {
                $email = \Helpers::getUserEmailISActive($user->user_id);
                if (isset($email)) {
                    $emails[] = $email;
                }
            }
        }
        return $emails;
    }

    /**
     * Getting project and account manager ids for perticlular project
     * @param $dept_id
     * @param $role_id
     * @return array
     */
    public static function getProjectUserId($projectId, $roleCode)
    {
        $roleArray = \Helpers::getRoleByModel('Role');
        $roleId = $roleArray[$roleCode];
        $users = UserRole::where('project_id', $projectId)
            ->where('role_id', $roleId)->get();
        $emails = [];
        if (isset($users[0])) {
            foreach ($users as $user) {
                $email = \Helpers::getUserEmailISActive($user->user_id);
                if (isset($email)) {
                    $emails[] = $email;
                }
            }
        }
        return $emails;
    }

    /**
     * @param $userId
     * @return mixed
     */
    public static function getUserEmail($userId)
    {
        $email = null;
        $userDetail = User::where('id',$userId)->first();
        if ($userDetail) {
            $userEmail = EmailAddresse::where('user_id', $userId)->select('address as email')->first();
            if ($userEmail) {
                $email = $userEmail->email;
            }
        }
        return $email;
    }

    public static function getUserId($userEmail)
    {
        $userId = null;
        if ($userEmail) {
            $userId = EmailAddresse::where('user_id', $userEmail)->pluck('user_id')->first();
            if ($userId) {
               return $userId;
            }
        }
        return $userId;
    }


    public static function getUserEmailISActive($userId)
    {
        $email = null;
        $userDetail = User::where(['id'=>$userId,'status'=>config('constant.REDMINE_USERSTATUS.activeUser')])->first();
        if ($userDetail) {
            $userEmail = EmailAddresse::where('user_id', $userId)->select('address as email')->first();
            if ($userEmail) {
                $email = $userEmail->email;
            }
        }
        return $email;
    }

    public static function getUserName($userId)
    {
        $userDetail = User::where('id',$userId)->first();
        return $userDetail['firstname'] . ' ' . $userDetail['lastname'];
    }

    /**
     * merges the different arguments in one array
     *
     * @return array
     */
    public static function merge()
    {
        $emails = [];
        foreach (func_get_args() as $argument) {
            if (is_array($argument)) {
                foreach ($argument as $email) {
                    array_push($emails, $email);
                }
            } else {
                array_push($emails, $argument);
            }
        }
        return $emails;
    }

    public static function getUserIdByGlobalRole($roleId)
    {
        $user = UserRole::where('role_id', $roleId)->select('user_id')->first();
        if ($user) {
            return $user->user_id;
        }
    }

    public static function updateRestartMailTemplate($template, $projectDetail)
    {
        $previousProjectDetails = ProjectAction::where(['link_id' => $projectDetail->uuid])
            ->where(function ($query) {
                $query->where('status_id', '=', config('constant.PROJECT_ACTION')['project_on_hold_request'])
                    ->orWhere('status_id', '=', config('constant.PROJECT_ACTION')['project_closure_checklist']);
            })
            ->orderBy('id', 'desc')->first();
        $reason = isset($previousProjectDetails['comment']) ? $previousProjectDetails['comment'] : config('constant.PROJECT_CLOSE_DEFAULT_MESSAGE');
        $mailTemplate = '';
        if ($template) {
            $mailTemplate = str_replace('<project Name>', $projectDetail->project_name, $template);
            $mailTemplate = str_replace('<Reason>', $reason, $mailTemplate);
        }
        return $mailTemplate;
    }

    public static function updateTemplateVariablesWithValues($template, $projectDatail)
    {
        $mailTemplate = '';
        if ($template) {
            $mailTemplate = str_replace('<project Name>', $projectDatail->project_name, $template);
        }
        return $mailTemplate;
    }

    public static function getRouteAction($route)
    {
        $routeArray = $route[1]['uses'];
        $array = explode('Controllers\Resource', $routeArray);
        $routeValue = stripslashes($array[1]);
        return $routeValue;
    }
    /**
     * get the project id
     *
     * @return string
     */
    public static function getProjectId($request)
    {
        $projectId = '';
        if ($request['project_id'] != '') {
            $projectId = $request['project_id'];
        } elseif ($request['projectId'] != '') {
            $projectId = $request['projectId'];
        } elseif (!empty($request->route()[2]['uuid'])) {
            $projectId = $request->route()[2]['uuid'];
        } elseif (!empty($request->route()[2]['projectUUID'])) {
            $projectId = $request->route()[2]['projectUUID'];
        } elseif (!empty($request->route()[2]['projectId'])) {
            $projectId = $request->route()[2]['projectId'];
        } else {
            $projectId = '';
        }
        return $projectId;
    }
    /**
     * get the current route role
     *
     * @return array
     */
    public static function getUserRole($admin, $global_operation = null, $sales = null, $resource_manager = null, $account_manager = null, $project_manager = null, $bu_head = null, $go_team = null)
    {
        $result = array();
        $roleArray = \Helpers::getRoleByModel('Role');
        if ($admin) {
            foreach ($roleArray as $key => $value) {
                switch ($key) {
                    case $admin:
                        $result[] = $value;
                        break;
                    case $global_operation:
                        $result[] = $value;
                        break;
                    case $sales:
                        $result[] = $value;
                        break;
                    case $resource_manager:
                        $result[] = $value;
                        break;
                    case $account_manager:
                        $result[] = $value;
                        break;
                    case $project_manager:
                        $result[] = $value;
                        break;
                    case $bu_head:
                        $result[] = $value;
                        break;
                    case $go_team:
                        $result[] = $value;
                        break;
                }
            }
            return $result;
        }
    }

    public static function getUniqueId($model, $table, $withThrash)
    {
        if ($withThrash) {
            $max = $model->withTrashed()->find(DB::table($table)->max('id'));
            return (($max) ? $max->id : 0) + 1;
        }
        $max = $model->find(DB::table($table)->max('id'));
        return (($max) ? $max->id : 0) + 1;
    }


    public static function getRoleIdByCode($code)
    {
        return $user = Role::where('code', $code)->pluck('id')->first();
    }

    public static function getDepartmentIdByCode($code)
    {
        return $deparment = Department::where('code', $code)->pluck('id')->first();
    }

    public static function getDepartmentNameByID($id)
    {
        return $deparment = Department::where('id', $id)->pluck('name')->first();
    }

    public static function getDesignationNameByID($id)
    {
        return $designation = Designation::where('id', $id)->pluck('name')->first();
    }

    public static function getTechnolgyNameByID($id)
    {
        return $technology = Technology::where('id', $id)->pluck('name')->first();
    }

    public static function getDomainNameByID($id)
    {
        return $domain = ProjectDomain::where('id', $id)->pluck('name')->first();
    }

    public static function getBillTypeName($id)
    {
        return $billType = BillingType::where('id', $id)->pluck('name')->first();
    }

    public static function getProjectTypeName($id)
    {
        return $projectType = ProjectType::where('id', $id)->pluck('name')->first();
    }

    public static function getGovCategoryName($id)
    {
        return $govCategory = GovernanceCategory::where('id', $id)->pluck('name')->first();
    }

    public static function getBillingMediumName($id)
    {
        return $billingMedium = BillingMedium::where('id', $id)->pluck('name')->first();
    }

    public static function getProjectName($id)
    {
        $projectName = Project::where('uuid', $id)->pluck('project_name')->first();
        if(isset($projectName)){
        return $projectName;
        }else{
        return false;
        }
    }

    public static function getRoleByModel($modelName)
    {
        $roleArray = [];
        $modelName = '\\App\Models\\' . $modelName;
        $model = new $modelName;
        $data = $model->select('id', 'code')->get();
        foreach ($data as $value) {
            $roleArray[$value->code] = $value->id;
        }
        return $roleArray;
    }

    public static function addToLog($projectId,$request,$response,$action)
    {
        $log = [];
        if($request!=''){
        $requestData=$request->toArray();
        $log['link_id'] = isset($projectId) ? $projectId : '';
    	$log['url'] = $request->fullUrl();
    	$log['action_id'] = $action;
    	$log['ip'] = $request->ip();
        $log['agent'] = $request->header('user-agent');
        $log['user_id'] = $request->user->id;
        $log['request'] = json_encode($requestData);
        $log['response'] = json_encode($response);
        }else{
            $log['link_id'] = isset($projectId) ? $projectId : '';
            $log['url'] = '';
            $log['action_id'] = $action;
            $log['ip'] = '';
            $log['agent'] = '';
            $log['user_id'] = Null;
            $log['request'] = $request;
            $log['response'] = json_encode($response);
        }
        return $log;
    }

    public static function addlogActivityDB($projectId,$request,$response,$action)
    {
        $logArray = [];
        if($request!=''){
        $requestData=$request->toArray();
        $logArray['link_id'] = $projectId;
    	$logArray['url'] = $request->fullUrl();
    	$logArray['action_id'] = $action;
    	$logArray['ip'] = $request->ip();
        $logArray['agent'] = $request->header('user-agent');
        $logArray['user_id'] = $request->user->id;
        $logArray['request'] = json_encode($requestData,JSON_UNESCAPED_SLASHES);
        $logArray['response'] = json_encode($response,JSON_UNESCAPED_SLASHES);
        ProjectActivityModel::create($logArray);
        }else{
        $logArray['link_id'] = $projectId;
    	$logArray['url'] = '';
    	$logArray['action_id'] = $action;
    	$logArray['ip'] = '';
        $logArray['agent'] = '';
        $logArray['user_id'] = Null;
        $logArray['request'] = $request;
        $logArray['response'] = json_encode($response,JSON_UNESCAPED_SLASHES);
        ProjectActivityModel::create($logArray);
        }
        return $logArray;
    }

    public static function logActivityLists($projectId)
    {
        $projectDetails = LogActivityModel::where('link_id', $projectId)->get();
        return $projectDetails;
    }

    public static function clean($string) {
        $string = str_replace(' ', '-', $string); // Replaces all spaces with hyphens.
        $string = preg_replace('/[^A-Za-z0-9\-]/', '', $string); // Removes special chars.
        $string = preg_replace('/-+/', '_', $string);// Replaces multiple hyphens with single one.
        return strtolower( $string); // Replace in lowercase.
    }

    public static function getEmployeeCode($userId)
    {
        $userDetail = CustomValue::where(['customized_id' => $userId, 'custom_field_id' => config('constant.REDMINE_CUSTOMFIELDID')])->first();
        return $userDetail['value'];
    }

    public static function updateProjectEstimatedToDate($projectId, $updateTimelineTo)
    {
        $projectDetails = Project::where('uuid', $projectId)->update(['estimated_timeline_to' => $updateTimelineTo]);
        return $projectDetails;
    }

    public static function getUserDepartments($currentUserId)
    {
          $dept = [];
          $user = User::select('id')
            ->with(['userDepartment'])
            ->where('id', $currentUserId)
            ->first();
          if(isset($user['userDepartment'][0])){
              foreach ($user['userDepartment'] as $userDepartment)
                  if (!empty($userDepartment['value'])) {
                          $dept[] = trim($userDepartment['value']);
                  }
          }
          return $dept;

    }

    public static function getBillableType($id)
    {
        $type='';
        if(isset($id)){
           if($id==config('constant.REQ_BILLABLE_TYPE.billable')){
           $type='Billable';
           }else{
            $type='Non Billable';
         }
       }
        return $type;
    }

    public static function projectUpdateEmail($updateArrayDiff,$newProjectArray,$oldProjectArray,$oldProjectManagers,$newProjectManagers,
        $oldAccountManagers, $newAccountManagers,$oldtechnologies,$newtechnologies){
            $updateArray = [];
            if(isset($updateArrayDiff['ProjectName'])) {
                $updateArray['Old_Project_Name'] = $oldProjectArray['ProjectName'];
                $updateArray['New_Project_Name'] = $newProjectArray['ProjectName'];
                }
                if(isset($updateArrayDiff['ProjectSummary'])) {
                $updateArray['Old_Project_Summary'] = $oldProjectArray['ProjectSummary'];
                $updateArray['New_Project_Summary'] = $newProjectArray['ProjectSummary'];
                }
                if(isset($updateArrayDiff['BillingType'])) {
                $updateArray['Old_Billing_Type'] = \Helpers::getBillTypeName($oldProjectArray['BillingType']);
                $updateArray['New_Billing_Type'] = \Helpers::getBillTypeName($newProjectArray['BillingType']);
                }
                if(isset($updateArrayDiff['parent_id'])) {
                    if($oldProjectArray['parent_id']!=''){
                    $updateArray['Old_SubProject_Name'] = \Helpers::getProjectNameRedmine($oldProjectArray['parent_id']);
                    }else{
                    $updateArray['Old_SubProject_Name'] = 'N/A';
                    }
                    if($newProjectArray['parent_id']!=''){
                    $updateArray['New_SubProject_Name'] = \Helpers::getProjectNameRedmine($newProjectArray['parent_id']);
                    }else{
                    $updateArray['New_SubProject_Name'] = 'N/A';
                    }
                }
                if(isset($updateArrayDiff['CompanyName'])) {
                    if($oldProjectArray['CompanyName']!=''){
                    $updateArray['Old_Company_Name'] = $oldProjectArray['CompanyName'];
                    }else{
                    $updateArray['Old_Company_Name'] = 'N/A';
                    }
                    if($newProjectArray['CompanyName']!=''){
                    $updateArray['New_Company_Name'] = $newProjectArray['CompanyName'];
                    }else{
                    $updateArray['New_Company_Name'] = 'N/A';
                    }
                }
                if(isset($updateArrayDiff['CompanyAddress'])) {
                    if($oldProjectArray['CompanyAddress']!=''){
                    $updateArray['Old_Company_Address'] = $oldProjectArray['CompanyAddress'];
                    }else{
                    $updateArray['Old_Company_Address'] = 'N/A';
                    }
                    if($newProjectArray['CompanyAddress']!=''){
                    $updateArray['New_Company_Address'] = $newProjectArray['CompanyAddress'];
                    }else{
                        $updateArray['New_Company_Address']= 'N/A';
                    }
                }
                if(isset($updateArrayDiff['state'])) {
                    if($oldProjectArray['state']!=''){
                    $updateArray['Old_State_Name'] = $oldProjectArray['state'];
                    }else{
                    $updateArray['Old_State_Name'] = 'N/A';
                    }
                    if($newProjectArray['state']!=''){
                    $updateArray['New_State_Name'] = $newProjectArray['state'];
                    }else{
                    $updateArray['New_State_Name'] = 'N/A';
                    }
                }
                if(isset($updateArrayDiff['country'])) {
                    if($oldProjectArray['country']!=''){
                    $updateArray['Old_Country_Name'] = $oldProjectArray['country'];
                    }else{
                    $updateArray['Old_Country_Name'] = 'N/A';
                    }
                    if($newProjectArray['country']!=''){
                    $updateArray['New_Country_Name'] = $newProjectArray['country'];
                    }else{
                    $updateArray['New_Country_Name'] = 'N/A';
                    }
                }
                if(isset($updateArrayDiff['lifecycle_model_id'])) {
                    if($oldProjectArray['lifecycle_model_id']!=''){
                    $updateArray['Old_LifeCycle_Name'] = \Helpers::getLifeCycleName($oldProjectArray['lifecycle_model_id']);
                    }else{
                    $updateArray['Old_LifeCycle_Name'] = 'N/A';
                    }
                    if($newProjectArray['lifecycle_model_id']!=''){
                    $updateArray['New_LifeCycle_Name'] = \Helpers::getLifeCycleName($newProjectArray['lifecycle_model_id']);
                    }else{
                    $updateArray['New_LifeCycle_Name'] = 'N/A';
                    }
                }

                if(isset($updateArrayDiff['billing_interval'])) {
                    if($oldProjectArray['billing_interval']==0){
                    $updateArray['Old_BillingInterval_Name'] = 'Weekly';
                    }elseif($oldProjectArray['billing_interval']==1){
                    $updateArray['Old_BillingInterval_Name'] = 'Monthly';
                    }else{
                        $updateArray['Old_BillingInterval_Name'] = 'N/A';
                    }
                    if($newProjectArray['billing_interval']=='0'){
                    $updateArray['New_BillingInterval_Name'] = 'Weekly';
                    }elseif($newProjectArray['billing_interval']=='1'){
                        $updateArray['New_BillingInterval_Name'] = 'Monthly';//\Helpers::getBillIntervalName($newProjectArray['billing_interval']);
                    }
                    else{
                    $updateArray['New_BillingInterval_Name'] = 'N/A';
                    }
                }
                if(isset($updateArrayDiff['ApprovedHours'])) {
                    if($oldProjectArray['ApprovedHours']!=''){
                    $updateArray['Old_Approved_Hours'] = $oldProjectArray['ApprovedHours'];
                    }else{
                    $updateArray['Old_Approved_Hours'] = 'N/A';
                    }
                    if($newProjectArray['ApprovedHours']!=''){
                     $updateArray['New_Approved_Hours'] = $newProjectArray['ApprovedHours'];
                    }else{
                     $updateArray['New_Approved_Hours'] = 'N/A';
                    }
                }
                if(isset($updateArrayDiff['MaximumHoursBilled'])) {
                    if($oldProjectArray['MaximumHoursBilled']!=''){
                        $updateArray['Old_MaximumHours_Billed'] = $oldProjectArray['MaximumHoursBilled'];
                    }else{
                        $updateArray['Old_MaximumHours_Billed'] = 'N/A';
                    }
                    if($newProjectArray['MaximumHoursBilled']!=''){
                        $updateArray['New_MaximumHours_Billed'] = $newProjectArray['MaximumHoursBilled'];
                    }else{
                        $updateArray['New_MaximumHours_Billed'] = 'N/A';
                    }
                }
                if(isset($updateArrayDiff['project_type_id'])) {
                    if($oldProjectArray['project_type_id']!=''){
                    $updateArray['Old_Project_Type'] = \Helpers::getProjectTypeName($oldProjectArray['project_type_id']);
                    }else{
                        $updateArray['Old_Project_Type'] = 'N/A';
                    }
                    if($newProjectArray['project_type_id']!=''){
                    $updateArray['New_Project_Type'] = \Helpers::getProjectTypeName($newProjectArray['project_type_id']);
                    }else{
                        $updateArray['New_Project_Type'] =  'N/A';
                    }
                }
                if(isset($updateArrayDiff['gov_category_id'])) {
                    if($oldProjectArray['gov_category_id']!=''){
                    $updateArray['Old_Governance_Category'] = \Helpers::getGovCategoryName($oldProjectArray['gov_category_id']);
                    }else{
                        $updateArray['Old_Governance_Category'] = 'N/A';
                    }
                    if($newProjectArray['gov_category_id']!=''){
                    $updateArray['New_Governance_Category'] = \Helpers::getGovCategoryName($newProjectArray['gov_category_id']);
                    }else{
                        $updateArray['New_Governance_Category'] = 'N/A';
                    }
                }
                if(isset($updateArrayDiff['billing_medium'])) {
                    if($oldProjectArray['billing_medium']!=''){
                    $updateArray['Old_Billing_Medium'] = \Helpers::getBillingMediumName($oldProjectArray['billing_medium']);
                    }else{
                        $updateArray['Old_Billing_Medium'] = 'N/A';
                    }
                    if($newProjectArray['billing_medium']!=''){
                    $updateArray['New_Billing_Medium'] = \Helpers::getBillingMediumName($newProjectArray['billing_medium']);
                    }else{
                        $updateArray['New_Billing_Medium'] = 'N/A';
                    }
                }
                if(isset($updateArrayDiff['ProjectComponents'])) {
                    $newArrayData = json_decode($newProjectArray['ProjectComponents'], TRUE);
                    $oldArrayData = json_decode($oldProjectArray['ProjectComponents'], TRUE);
                    $currentArray=['web','design','mobile'];
                    $oldArrayVal=[];
                    foreach($oldArrayData as $oldvalue){
                        if(in_array($oldvalue,$currentArray) ){
                              array_push($oldArrayVal,$oldvalue);
                        }elseif($oldvalue!='other'){
                            $strOld='other:'.$oldvalue;
                            array_push($oldArrayVal,$strOld);
                        }
                    }
                    $updateArray['Old_Project_Components'] = implode(' , ', $oldArrayVal);
                    $newArrayVal=[];
                    foreach($newArrayData as $newvalue){
                        if(in_array($newvalue,$currentArray) ){
                            if(!in_array($newvalue,$oldArrayVal)){
                            array_push($newArrayVal,$newvalue);
                            }else{
                            array_push($newArrayVal,$newvalue);
                            }
                        }elseif($newvalue!='other'){
                            $strNew='other:'.$newvalue;
                            if(!in_array($strNew,$oldArrayVal)){
                            array_push($newArrayVal,$strNew);
                            }else{
                            array_push($newArrayVal,$strNew);
                            }
                        }
                    }
                    $updateArray['New_Project_Components'] = implode(' , ', $newArrayVal);
                }
                $pmDiffArray = array_merge(array_diff($oldProjectManagers['projectManagers'], $newProjectManagers['projectManagers']), array_diff($newProjectManagers['projectManagers'], $oldProjectManagers['projectManagers']));
                if(!empty($pmDiffArray)) {
                    $updateArray['Old_Project_Managers'] = implode(' , ', $oldProjectManagers['projectManagers']);
                    $updateArray['New_Project_Managers'] = implode(' , ', $newProjectManagers['projectManagers']);
                }
                $amDiffArray = array_merge(array_diff($oldAccountManagers['accountManagers'], $newAccountManagers['accountManagers']), array_diff($newAccountManagers['accountManagers'], $oldAccountManagers['accountManagers']));
                if(!empty($amDiffArray)) {
                    $updateArray['Old_Account_Managers'] = implode(' , ', $oldAccountManagers['accountManagers']);
                    $updateArray['New_Account_Managers'] = implode(' , ', $newAccountManagers['accountManagers']);
                }
                $techDiffArray = array_merge(array_diff($oldtechnologies['technologies'], $newtechnologies['technologies']), array_diff($newtechnologies['technologies'], $oldtechnologies['technologies']));
                if(!empty($techDiffArray)) {
                    $updateArray['Old_Technologies'] = implode(' , ', $oldtechnologies['technologies']);
                    $updateArray['New_Technologies'] = implode(' , ', $newtechnologies['technologies']);
                }
                if (isset($updateArrayDiff['ClientDetail'])) {
                    $oldClientName=[];
                    $oldClientEmail=[];
                    $newClientName=[];
                    $newClientEmail=[];
                    $newClientData = json_decode($newProjectArray['ClientDetail'], TRUE);
                    $oldClientData = json_decode($oldProjectArray['ClientDetail'], TRUE);
                      foreach ($oldClientData as $key=>$oldclientdetails) {
                        $keyNo=$key+1;
                        if($oldclientdetails['full_name']!=''){
                        $fullName='<strong>'.$keyNo.'</strong>'.'. '.$oldclientdetails['full_name'];
                        }else{
                        $fullName='N/A';
                        }
                        if($oldclientdetails['address']!=''){
                        $address='<strong>'.$keyNo.'</strong>'.'. '.$oldclientdetails['address'];
                        }else{
                        $address='N/A';
                        }
                        array_push($oldClientName,$fullName);
                        array_push($oldClientEmail,$address);
                      }
                      foreach ($newClientData as $key=>$newclientdetails) {
                        $keyNo=$key+1;
                        if($newclientdetails['full_name']!=''){
                        $fullName='<strong>'.$keyNo.'</strong>'.'. '.$newclientdetails['full_name'];
                        }else{
                        $fullName='N/A';
                        }
                        if($newclientdetails['address']!=''){
                        $address='<strong>'.$keyNo.'</strong>'.'. '.$newclientdetails['address'];
                        }else{
                        $address='N/A';
                        }
                        array_push($newClientName,$fullName);
                        array_push($newClientEmail,$address);
                    }
                    if(!empty($oldClientName)){
                    $updateArray['Old_Client_Name'] = implode('<br>', $oldClientName);
                    }
                    if(!empty($oldClientEmail)){
                    $updateArray['Old_Client_Email'] = implode('<br>', $oldClientEmail);
                    }
                    if(!empty($newClientName)){
                    $updateArray['New_Client_Name'] = implode('<br>', $newClientName);
                    }
                    if(!empty($newClientEmail)){
                    $updateArray['New_Client_Email'] = implode('<br>', $newClientEmail);
                    }
                }
                if(isset($updateArrayDiff['Comment'])) {
                    if($oldProjectArray['Comment']!=''){
                        $updateArray['Old_Comment'] = $oldProjectArray['Comment'];
                    }else{
                        $updateArray['Old_Comment'] = 'N/A';
                    }
                    if($newProjectArray['Comment']!=''){
                        $updateArray['New_Comment'] = $newProjectArray['Comment'];
                    }else{
                        $updateArray['New_Comment'] = 'N/A';
                    }
                    }
                return $updateArray;
        }

    public static function getProjectsID($projectsId)
      {
        $projectUsers = ResourceBooking::where('project_id', $projectsId)->pluck('assigned_to_id')->toArray();
        return $arrayString = implode(",",$projectUsers);
     }
    public static function getBillingProjectsID($billingID)
    {
       $projectBilling = CustomValue::where(['custom_field_id'=>config('constant.CUSTOM_VALUES.billing_unit')])
      ->whereIn('value',$billingID)->pluck('customized_id')->toArray();
      $newProjectsIds = RedmineProjectModel::whereIn('id', $projectBilling)->where('status', config('constant.REDMINE_PROJECTSTATUS.activeProject'))->pluck('id')->toArray();
      return $arrayString = implode(",",$newProjectsIds);
    }

    /**
     *
     * @param array $rows
     * @param string $startDate
     * @param string $endDate
     * @return array
     */

    public static function breakIntoIntervals($rows,$startDate,$endDate){
        $intervals = [];
        $startRow = $rows[0];
        //check any unassigned interval before first scheduled date for user
        if($startRow->date!=null && strtotime($startRow->date) > strtotime($startDate))
        {
            $interval = clone $startRow;
            $interval->total = 0;
            $interval->startDate = $startDate;
            $interval->endDate = date('Y-m-d',strtotime($startRow->date." -1 day"));
            unset($interval->date);
            $intervals[] = $interval;
        }

        foreach($rows as $index=> $row){
            if($index==0){
                continue;
            }
            $currentDate = new \DateTime($row->date);
            $lastRowDate = new \DateTime($rows[$index-1]->date);
            $diff = $lastRowDate->diff($currentDate);

            if($startRow->total != $row->total || $diff->days>1){
                $interval = clone $startRow;
                $interval->startDate = $startRow->date;
                $interval->endDate = $rows[$index-1]->date;
                unset($interval->date);
                $intervals[] = $interval;

                $startRow = $row;
                // find any missing interval between two dates
                if($diff->days>1){
                    $interval = clone $startRow;
                    $interval->total =0;
                    $lastRowDate->add(new \DateInterval('P1D'));
                    $interval->startDate = $lastRowDate->format('Y-m-d');
                    $lastRowDate->add(new \DateInterval('P'.($diff->days-2).'D'));
                    $interval->endDate = $lastRowDate->format('Y-m-d');
                    unset($interval->date);
                    $intervals[] = $interval;
                }
            }


        }

        $endRow = clone end($rows);
        $startRow->startDate = $startRow->date ? $startRow->date : $startDate;
        $startRow->endDate = $endRow->date ? $endRow->date : $endDate;
        unset($startRow->date);
        $intervals[] = $startRow;
        //check any unassigned interval after last scheduled date for user
        if(strtotime($endRow->date) < strtotime($endDate) && $endRow->total!=0)
        {
            $endRow->total = 0;
            $endRow->startDate = date('Y-m-d',strtotime($endRow->date."+1 day"));
            $endRow->endDate =  $endDate;
            unset($endRow->date);
            $intervals[] = $endRow;
        }
        return $intervals;
    }
    public static function projectIDRedmine($name)
    {
        $allProjects = RedmineProjectModel::where('status',1)->get(['id','name','status']);
        if(!empty($allProjects)){
        foreach($allProjects as $val){
            if(Helpers::cleanNew($name) == Helpers::cleanNew($val['name'])){
                return $val['id'];
            }
        }
      }
    }

    public static function checkMembers($redmineProjectID,$resource_id,$loopMapData,$membershipData=''){
        $redmineTechID = Self::roleIDRedmine($loopMapData['designation']);
        $bookingStartDate = Carbon::parse($loopMapData['start_date'])->format('Y-m-d');
        $flag = false;
        $rolesIDs =[];
        $result ='';
        if(isset($membershipData['memberships']) && count($membershipData['memberships'])>0){
        foreach($membershipData['memberships'] as $key=>$val){
            if(isset($val['user']) && isset($val['user']['id'])){
                $userID = $val['user']['id'];
                if((int)$userID==(int)$resource_id){
                foreach($val['roles'] as $key1=>$val1){
                    array_push($rolesIDs,$val1['id']);
                }
                if(in_array($redmineTechID,$rolesIDs)){
                    return true;
                }else{
                array_push($rolesIDs,$redmineTechID);
                }
                $flag=true;
                break;
           }
        }
      }
       if($flag){
            $dataPut = json_encode([
                'membership' =>
                [
                  'role_ids' =>
                  $rolesIDs,
                ],
            ]);
             $result = Self::callAPI('PUT','/memberships/'.$val['id'].'.json',$dataPut);
             Log::info(['Project_Membership_PUT_API', json_encode($result),$dataPut]);
             return true;
            }else{
            $data = json_encode([
            'membership' =>
            [
              'user_id' => $resource_id,
              'role_ids' =>
              [
                0 => $redmineTechID,
              ],
            ],
           ]);
           if(Carbon::parse($bookingStartDate)->lessThanOrEqualTo(Carbon::now())){
           $result = Self::callAPI('POST','/projects/'.$redmineProjectID.'/memberships.json',$data);
           Log::info(['Project_Membership_POST_API', json_encode($result),$data]);
           }
           if($result==200){
            return true;
            }else{
           return false;
            }
          }
        }else{
            $data = json_encode([
                'membership' =>
                [
                  'user_id' => $resource_id,
                  'role_ids' =>
                  [
                    0 => $redmineTechID,
                  ],
                ],
               ]);
               if(Carbon::parse($bookingStartDate)->lessThanOrEqualTo(Carbon::now())){
                $result = Self::callAPI('POST','/projects/'.$redmineProjectID.'/memberships.json',$data);
                Log::info(['Project_Membership_POST_API_NEW', json_encode($result),$data]);
              }
               if($result==200){
                 return true;
               }else{
                return false;
               }
        }
     }

    public static function roleIDRedmine($pmoTechName)
    {
        $allRoles = RedmineRolesModel::get(['id','name']);
        if(!empty($allRoles)){
        foreach($allRoles as $val){
            if(Helpers::cleanNew($pmoTechName) == Helpers::cleanNew($val['name'])){
                return $val['id'];
            }
        }
      }
    }

    public static function cleanAll($string) {
        return trim(strtolower(str_replace(array('/', '\'', '"', ',', ';', '<', '>', ' ', '-', '_', '.', '%', '@'), '', $string))); // Replace in lowercase.
    }
    public static function callAPIGET($url){
        $Host = env('X_Redmine_URL');
        $fullUrl = $Host.$url;
        $curl = curl_init();
        $key = env('X_Redmine_API_Key');
        // OPTIONS:
        curl_setopt($curl, CURLOPT_URL, $fullUrl);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array(
           "X-Redmine-API-Key:" . $key,
           "Content-Type: application/json",
        ));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);

        // EXECUTE:
        $result = curl_exec($curl);
        if(!$result){die("Connection Failure");}
        curl_close($curl);
        return $result;
     }

     public static function callAPI($method, $url, $data){
        $Host = env('X_Redmine_URL');
        $fullUrl=$Host.$url;
        $curl = curl_init();
        switch ($method){
           case "POST":
              curl_setopt($curl, CURLOPT_POST, 1);
              if ($data)
                 curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
              break;
           case "PUT":
              curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
              if ($data)
                 curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
              break;
            case "DELETE":
                curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "DELETE");
                if ($data)
                   curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
              break;
        }
        $key = env('X_Redmine_API_Key');
        // OPTIONS:
        curl_setopt($curl, CURLOPT_URL, $fullUrl);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array(
           "X-Redmine-API-Key:" . $key,
           "Content-Type: application/json",
        ));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);

        // EXECUTE:
        $result = curl_exec($curl);
        $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        curl_close($curl);
        if(!$result){
         return $httpCode;
        } else{
         return $result;
        }
     }

    public static function getKekaData() {
        $response = CustomValueApi::where('custom_field_api_id', 1)->first();
        $responseValue = $response['values'];
        return json_decode($responseValue, true);
    }

    public static function getAllUserEmailsISActive($userId)
    {
        $emailIds[] = [];
        $userDetails = User::whereIn('id', $userId)
                      ->where('status', config('constant.REDMINE_USERSTATUS.activeUser'))
                      ->get();
        foreach ($userDetails as $userDetail){
            if ($userDetail) {
                $userEmail = EmailAddresse::where('user_id', $userId)->select('address as email')->first();
                if (isset($userEmail->email)) {
                    $emailIds[] = $userEmail->email;
                }
            }
        }
        return $emailIds;
    }

    public static function getAllBUHeads()
    {
         $buHeads = UserRole::whereNotNull('dept_id')
            ->where('role_id', Helpers::getRoleIdByCode(config('constant.ROLES.bu_head')))
            ->with('User')
            ->get();
        return $buHeads;
    }

    public static function getProjectAllCurrentBookings($projectId)
    {
        $project = Project::with('currentBookings', 'ProjectUsers')
            ->where('uuid', $projectId)
            ->first();
        return $project;
    }

    public static function cleanNew($string) {
        return trim(strtolower(str_replace(array(' '), '', $string))); // Replace in lowercase.
    }

    public static function getLifeCycleName($id)
    {
        return $lifeCycleName = LifeCycle::where('id', $id)->pluck('name')->first();
    }
    public static function billingIDRedmine($billingTypeName)
    {
        $allBillingTypes = CustomFieldEnumeration::get(['id','custom_field_id','name','active']);
        if(!empty($allBillingTypes)){
        foreach($allBillingTypes as $val){
            if(Helpers::cleanNew($billingTypeName) == Helpers::cleanNew($val['name'])){
                return $val['id'];
            }elseif($billingTypeName == 'Internal' || $billingTypeName =='POC'){
                return 7;
            }
        }
      }
    }

    public static function getProjectNameRedmine($id)
    {
        $projectNameRedmine = RedmineProjectModel::where('id', $id)->pluck('name')->first();
        if(isset($projectNameRedmine)){
        return $projectNameRedmine;
        }else{
        return false;
        }
    }

public static function checkMatchedRecordPMO($currentBookings, $redmineRecord){
        foreach ($currentBookings as $resourceMapped){
            if(isset($resourceMapped['resourceAllocation']['resourceAllocationMeta'][0])) {
                foreach ($resourceMapped['resourceAllocation']['resourceAllocationMeta'] as $resourceAllocationMeta) {
                    if (Carbon::parse($resourceAllocationMeta->start_date)->format('Y-m-d') == Carbon::parse($redmineRecord->start_date)->format('Y-m-d') &&
                        Carbon::parse($resourceAllocationMeta->end_date)->format('Y-m-d') == Carbon::parse($redmineRecord->end_date)->format('Y-m-d') &&
                        $redmineRecord->hours_per_day == $resourceAllocationMeta->hours &&
                        $redmineRecord->assigned_to_id == $resourceAllocationMeta->resource_id
                    ){
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public static function checkMatchedRecordRedmine($resourceAllocationMeta, $redmineResources){
        foreach ($redmineResources as $redmineResource){
            if (Carbon::parse($resourceAllocationMeta->start_date)->format('Y-m-d') == Carbon::parse($redmineResource->start_date)->format('Y-m-d') &&
                Carbon::parse($resourceAllocationMeta->end_date)->format('Y-m-d') == Carbon::parse($redmineResource->end_date)->format('Y-m-d') &&
                $redmineResource->hours_per_day == $resourceAllocationMeta->hours &&
                $redmineResource->assigned_to_id == $resourceAllocationMeta->resource_id
            ) {
                return true;
            }
        }
        return false;
    }


    public static function checkBackDateRecordRedmine($matchRecordsRedmineId, $tillYesterdayBooking, $resourceId){

        if(count($tillYesterdayBooking) > 0){
            foreach ($tillYesterdayBooking as $booking){
                    if(!in_array($booking->assigned_to_id, $matchRecordsRedmineId) &&
                        Carbon::parse($booking->end_date)->format('Y-m-d') == Carbon::yesterday()->format('Y-m-d') &&
                        $booking->assigned_to_id == $resourceId){
                        return $booking;
                    }
                }
        }
        return false;
    }
    public static function getIdentifier($projectName){
        if(isset($projectName)){
         $identifierString = (str_replace(' ', '_', strtolower($projectName)));
         $identifierString = preg_replace('/[^A-Za-z0-9\-]/', '', $identifierString);
         return Self::getProjectIdentifier($identifierString);
        }
    }

    public static function getProjectIdentifier($identifier)
    {
        $projectIdentifier = Project::whereNotNull('identifier')->pluck('identifier')->toArray();
        if(in_array($identifier, $projectIdentifier)){
            return $identifier.rand(1, 100);
        }else{
            return $identifier;
        }
    }
    public static function getCustomBillingType($id)
    {
        $billingName = CustomFieldEnumeration::where('id', $id)->pluck('name')->first();
        if(isset($billingName)){
            return $billingName;
            }else{
            return false;
        }
    }

    public static function checkProjectNameRedmine($name)
    {
        $selectedValueArray = [];
        $allProjects = RedmineProjectModel::where('status',1)->get(['id','name','identifier','status']);
        if(!empty($allProjects)){
        foreach($allProjects as $val){
            if(Helpers::cleanNew($name) == Helpers::cleanNew($val['name'])){
                return $selectedValueArray = [
                    'id'=>$val['id'],
                    'name'=>$val['name'],
                    'identifier'=>$val['identifier']
                 ];
                }
        }
        return $selectedValueArray;
      }
    }

    /**
     * Function For add department in User array
     */
    public static function mapDepartmentWithUser($users)
    {
        $departmentArray = Helpers::getDepartmentArray();
        if (isset($users)) {
            foreach ($users as $key => $value) {
                $dept = [];
                if(isset($value['userDepartment'][0])){
                    foreach ($value['userDepartment'] as $userDepartment)
                        if (!empty($userDepartment['value'])) {
                            if (array_key_exists(strtolower($userDepartment['value']), $departmentArray)) {
                                $dept[] = $departmentArray[strtolower($userDepartment['value'])];
                            }
                        }
                }
                $users[$key]->dept = $dept;
            }
        }

        return $users;
    }

    /**
     * Function For add department in User array
     */
    public static function mapDepartmentWithUserForManagement($users)
    {
        $departmentArray = Helpers::getDepartmentArrayWithoutClient();
        if (isset($users)) {
            foreach ($users as $key => $value) {
                $dept = [];
                if(isset($value['userDepartment'][0])){
                    foreach ($value['userDepartment'] as $userDepartment)
                        if (!empty($userDepartment['value'])) {
                            if (array_key_exists(strtolower($userDepartment['value']), $departmentArray)) {
                                $dept[] = $departmentArray[strtolower($userDepartment['value'])];
                            }
                        }
                }
                unset($value['userDepartment']);
                $users[$key]->dept = $dept;
            }
        }

        return $users;
    }

    public static function getDepartmentArrayWithoutClient()
    {
        $response = [];
        $departments = Department::get();
        foreach ($departments as $key => $value) {
            $response[strtolower($value['name'])] = $value;
        }
        return $response;
    }

    public static function getDepartmentArray()
    {
        $response = [];
        $departments = Department::get();
        foreach ($departments as $key => $value) {
            $response[strtolower($value['name'])] = $value;
        }
        return $response;
    }

    public static function createTraineeUserArray()
    {
        $user = User::select('id', DB::raw("(select address from email_addresses where users.id  =   user_id) as email"),
            DB::raw("(select value from custom_values where customized_id = users.id and custom_field_id = 15) as employee_id"))
            ->where('status', config('constant.REDMINE_USERSTATUS.activeUser'))
            ->where('type', config('constant.REDMINE_USERSTATUS.userType'))->get();
        $traineeIds = Helpers::checkJobProfileWithUser($user);
        return $traineeIds;
    }

    public static function checkJobProfileWithUser($users){
        $data = [];
        $result = Helpers::getKekaData();
        $tranieeArray = ["Trainee Engineer", "Trainee-Engineer", "TraineeEngineer", "Trainee"];
        foreach ($users as $user) {
            foreach ($result as $key => $value) {
                if (trim($value['employeeNumber']) == trim($user['employee_id']) || trim($value['email']) == trim($user['email'])) {
                    if (in_array(trim($value['jobTitle']['title']), $tranieeArray))
                       {
                        $data[] = $user->id;
                    }
                }
            }
        }
        return $data;
    }

    public static function computeDomian($clientEmail)
    {
        if(is_array($clientEmail)){
            $emailAddress = $clientEmail[0]->address;
            $domain = substr($emailAddress, strpos($emailAddress, '@') + 1);
            return substr($domain, 0, strpos($domain , "."));
        }   
       
    }

}
