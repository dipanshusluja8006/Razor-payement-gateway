<?php

namespace App\Libraries;

use App\Mail\ResourceMailable;
use App\Models\Project;
use Illuminate\Support\Facades\Mail;
use Illuminate\Contracts\Bus\Dispatcher;
use App\Jobs\QueueJob;

/**
 * Class MailService
 * @package App\Libraries
 */
class MailService
{

    private $templateCode, $project, $submitArray, $department, $emails, $currentUser;

    /**
     * MailService constructor.
     * @param $templateCode
     * @param $projectUUID
     * @param null $department
     * @param array $emails
     */
    public function __construct($templateCode, $projectUUID, $submitArray = [], $department = [], $emails = [], $currentUser = null)
    {
        $this->templateCode = $templateCode;
        $this->submitArray = $submitArray;
        $this->department = $department;
        $this->emails = $emails;
        $this->currentUser = $currentUser;

        if (!empty($projectUUID))
            $this->project = Project::where('uuid', $projectUUID)->first();
    }

    /**
     * @return bool
     * @throws \Exception
     */
    public function sendMail()
    {
        $currentUserName = '';
        if (isset($this->currentUser)) {
            $currentUserName = \Helpers::getUserName($this->currentUser);
        }
        $mailData = \Helpers::getTemplateByCode($this->templateCode);
        $roles = \Helpers::getEmailTo($this->templateCode);
        $blacklistEmails = config('constant.BLACKLIST_EMAILS');
        $mailTo = [];
        foreach ($roles as $eachRole) {
            switch (trim($eachRole)) {
                case config('constant.ROLES.account_manager'):
                    $mail = \Helpers::getProjectUserId($this->project->uuid, config('constant.ROLES.account_manager'));
                    if (isset($mail)) {
                        $mailTo[] = $mail;
                    }
                    break;
                case config('constant.ROLES.project_manager'):
                    $mail = \Helpers::getProjectUserId($this->project->uuid, config('constant.ROLES.project_manager'));
                    if (isset($mail)) {
                        $mailTo[] = $mail;
                    }
                    break;
                case config('constant.ROLES.bu_head'):
                    if (isset($this->department[0])) {
                        $mail = \Helpers::getGlobalUserId($this->department, config('constant.ROLES.bu_head'));
                        if (isset($mail[0])) {
                            $mailTo[] = $mail;
                        }
                    }
                    break;
                case config('constant.ROLES.global_operation'):
                    $mail = \Helpers::getGlobalUserId('', config('constant.ROLES.global_operation'));
                    if (isset($mail[0])) {
                        $mailTo[] = $mail;
                    }
                    break;
                case config('constant.ROLES.sales'):
                    $mail = \Helpers::getGlobalUserId('', config('constant.ROLES.sales'));
                    if (isset($mail[0])) {
                        $mailTo[] = $mail;
                    }
                    break;
                case config('constant.ROLES.resource_manager'):
                    $mail = \Helpers::getGlobalUserId('', config('constant.ROLES.resource_manager'));
                    if (isset($mail[0])) {
                        $mailTo[] = $mail;
                    }
                    break;
                case config('constant.ROLES.go_team'):
                    //mail send only to created_by in project it may be bu_head or go_team
                    $mail = \Helpers::getUserEmailISActive($this->project->created_by);
                    if (isset($mail)) {
                        $mailTo[] = $mail;
                    }
                    break;
                case config('constant.ROLES.hr'):
                    //mail send only to hr group mail id
                    $mail = config('constant.HR_GROUP_MAIL_ID');
                    if (isset($mail)) {
                        $mailTo[] = $mail;
                    }
                    break;
                default:
                    throw new \Exception('Unexpected value to');
            }
        }
        array_walk_recursive($mailTo, function ($item) use (&$mergedArray) {
            $mergedArray[] = $item;
        });
        $rolesCC = \Helpers::getEmailCC($this->templateCode);
        $mailcc = [];
        if (!empty($rolesCC)) {
            foreach ($rolesCC as $eachRoleCC) {
                switch (trim($eachRoleCC)) {
                    case config('constant.ROLES.account_manager'):
                        $mail = \Helpers::getProjectUserId($this->project->uuid, config('constant.ROLES.account_manager'));
                        if (isset($mail)) {
                            $mailcc[] = $mail;
                        }
                        break;
                    case config('constant.ROLES.project_manager'):
                        $mail = \Helpers::getProjectUserId($this->project->uuid, config('constant.ROLES.project_manager'));
                        if (isset($mail)) {
                            $mailcc[] = $mail;
                        }
                        break;
                    case config('constant.ROLES.bu_head'):
                        if (isset($this->department[0])) {
                            $mail = \Helpers::getGlobalUserId($this->department, config('constant.ROLES.bu_head'));
                            if (isset($mail[0])) {
                                $mailcc[] = $mail;
                            }
                        }
                        break;
                    case config('constant.ROLES.global_operation'):
                        $mail = \Helpers::getGlobalUserId('', config('constant.ROLES.global_operation'));
                        if (isset($mail[0])) {
                            $mailcc[] = $mail;
                        }
                        break;
                    case config('constant.ROLES.sales'):
                        $mail = \Helpers::getGlobalUserId('', config('constant.ROLES.sales'));
                        if (isset($mail[0])) {
                            $mailcc[] = $mail;
                        }
                        break;
                    case config('constant.ROLES.resource_manager'):
                        $mail = \Helpers::getGlobalUserId('', config('constant.ROLES.resource_manager'));
                        if (isset($mail[0])) {
                            $mailcc[] = $mail;
                        }
                        break;
                    case config('constant.ROLES.go_team'):
                        //mail send only to created_by in project it may be bu_head or go_team
                        $mail = \Helpers::getUserEmailISActive($this->project->created_by);
                        if (isset($mail)) {
                            $mailcc[] = $mail;
                        }
                        break;
                    case config('constant.ROLES.hr'):
                        //mail send only to hr group mail id
                        $mail = config('constant.HR_GROUP_MAIL_ID');
                        if (isset($mail)) {
                            $mailcc[] = $mail;
                        }
                        break;
                    default:
                        throw new \Exception('Unexpected value cc');
                }
            }
            if ($this->emails) $mailcc[] = $this->emails;
            array_walk_recursive($mailcc, function ($item) use (&$mergedArrayCC) {
                $mergedArrayCC[] = $item;
            });
        }
        $finalMailData['subject'] = $mailData->subject;
        if (isset($this->project->project_name)) {
            $finalMailData['subject'] = $mailData->subject . ' | ' . $this->project->project_name;
        }
        if ($this->templateCode == config('constant.TEMPLATES.employee_allocation_email')) {
            $finalMailData['subject'] = $mailData->subject . $this->project->project_name;
            unset($mergedArray[0]);
            $mergedArray = array_values([$this->submitArray['email']]);
        }

        if ($this->templateCode == config('constant.TEMPLATES.employee_de_allocation_email')) {
            $finalMailData['subject'] = $mailData->subject;
            unset($mergedArray[0]);
            $mergedArray = array_values([$this->submitArray['email']]);
        }

        $finalMailData['code'] = $mailData->code;
        $finalMailData['template'] = $mailData->template;
        $finalMailData['projectArray'] = $this->project;
        $finalMailData['currentUserName'] = $currentUserName;
        $finalMailData['submitArray'] = $this->submitArray;
        $finalMailData['department'] = $this->department;
        $finalMailData['mailTo'] = $mailTo;
        $finalMailData['mailcc'] = $mailcc;
        $finalMailData = (object) $finalMailData;
        if (!empty($mergedArray) && !empty($mergedArrayCC)) {
            $key = config('constant.QUEUEJOB.ResourceMailable');
            $mergedArray = array_diff($mergedArray, $blacklistEmails);
            $mergedArrayCC = array_diff($mergedArrayCC, $blacklistEmails);
            dispatch(new QueueJob($mergedArray, $finalMailData, $key, $mergedArrayCC))->onQueue('default');
        } else {
            $key = config('constant.QUEUEJOB.ResourceMailable');
            if (!empty($mergedArray)) {
                $mergedArray = array_diff($mergedArray, $blacklistEmails);
                dispatch(new QueueJob($mergedArray, $finalMailData, $key, $mergedArrayCC = []))->onQueue('default');
            }
        }
        return true;
    }
}
