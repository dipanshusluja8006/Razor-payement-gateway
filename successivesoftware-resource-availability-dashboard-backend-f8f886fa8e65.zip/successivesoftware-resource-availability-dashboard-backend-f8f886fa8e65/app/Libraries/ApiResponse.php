<?php

class ApiResponse
{

  /**
   * using genericResponse() function for creating response format
   * @param $location
   * @param $message
   * @return \Illuminate\Http\Response|\Laravel\Lumen\Http\ResponseFactory
   */

  public static function genericResponse($status, $data = '', $message = '')
  {
    if ($message != '') {
      $msgText = $message;
    } else {
      switch ($status) {
        case config('constant.STATUS_CODE.statusOk'):
          $msgText = 'Ok';
          break;
        case config('constant.STATUS_CODE.statusCreated'):
          $msgText = 'Created';
          break;
        case config('constant.STATUS_CODE.statusUnauthorized'):
          $msgText = 'Unauthorized';
          break;
        case config('constant.STATUS_CODE.statusForbidden'):
          $msgText = 'Forbidden';
          break;
        case config('constant.STATUS_CODE.statusNotFound'):
          $msgText = 'Not Found';
          break;
        case config('constant.STATUS_CODE.statusUnprocessable'):
          $msgText = 'Unprocessable Entity';
          break;
        case config('constant.STATUS_CODE.alreadyExist'):
          $msgText = 'Already Exist';
          break;
      }
    }
    return response()->json(['data' => $data, 'message' => $msgText, 'status' => $status], $status);
  }
}
