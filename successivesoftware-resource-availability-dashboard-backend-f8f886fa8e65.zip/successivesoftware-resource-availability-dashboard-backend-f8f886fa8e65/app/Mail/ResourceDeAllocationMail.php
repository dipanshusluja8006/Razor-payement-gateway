<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class ResourceDeAllocationMail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public $maildata;

    public function __construct($data)
    {
        $this->maildata = $data;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {

        switch ($this->maildata['mailTo']){
            case 'resource':
                return $this
                    ->view('mail.deallocation-reminder')
                    ->subject(isset($this->maildata['template']['subject']) ? $this->maildata['template']['subject'] : 'Resource DeAllocation Reminder');
                break;
            case 'projectManager':
                return $this
                    ->view('mail.deallocation-reminder-for-pm')
                    ->subject('Resource DeAllocation Reminder');
                break;
            case 'resourceManager':
                return $this
                    ->view('mail.deallocation-reminder-for-rm')
                    ->subject('Resource Booking Ended');
                break;
            case 'globalOperation':
                return $this
                    ->view('mail.deallocation-reminder-for-go')
                    ->subject('Resource DeAllocation Reminder');
                break;
        }

    }
}
