<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class deleteLapsedResourceExtensionRequest extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public $maildata;

    public function __construct($data)
    {
        $this->maildata = $data['stage'];
        $this->emailIds = $data['emails'];
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this
            ->cc($this->emailIds)
            ->view('mail.delete-lapsed-extension-request')
            ->subject('Lapsed Resource Extension Request');
    }

}
