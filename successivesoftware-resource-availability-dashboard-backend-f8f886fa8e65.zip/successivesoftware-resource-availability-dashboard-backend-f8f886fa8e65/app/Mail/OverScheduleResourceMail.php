<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class OverScheduleResourceMail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public $maildata;

    public function __construct($data)
    {
        $this->maildata = $data;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this
            ->view('mail.over-schedule-resource-reminder')
            ->with([
                'data' => $this->maildata['data'],
                'duration' => $this->maildata['duration']
            ])
            ->subject(isset($this->maildata['subject']) ? $this->maildata['subject'] : 'Over Scheduled Resources Weekly Report');
    }
}
