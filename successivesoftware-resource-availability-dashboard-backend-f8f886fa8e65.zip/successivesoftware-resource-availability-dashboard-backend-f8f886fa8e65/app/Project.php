<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;
class Project extends Model {

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $connection="redmine_db_mysql";
    public $timestamps = false;
    protected $fillable = [
        'id',
        'name',
        'description',
        'homepage',
        'is_public',
        'parent_id',
        'created_on',
        'updated_on',
        'identifier',
        'status',
        'lft',
        'rgt',
        'inherit_members',
        'project_meeting_rooms',
        'default_version_id',
        'default_assigned_to_id',
        'activity_report_settings',
        'product_backlog_id',
        'dmsf_description',
        'dmsf_notification',
        'dmsf_act_as_attachable',
    ];

    public function Member()
    {
        return $this->belongsTo('App\Member', 'id', 'project_id')->with('MemberRole', 'user');
    }

    public function ProjectMembers()
    {
        return $this->hasMany('App\Member', 'project_id', 'id')->with('MemberRole', 'user');
    }

    public function userProjects()
    {
        return $this->hasOne('App\CustomValue', 'customized_id', 'id')->where('custom_field_id', config('constant.CUSTOM_VALUES.billing_unit'));
    }

    public function projectBookings()
    {
        return $this->hasMany('App\ResourceBooking', 'project_id', 'id')
            ->whereDate('end_date', '>=', Carbon::today())
            ->where('hours_per_day', '!=' , 0)
            ->with('userDepartment', 'userDetail')
            ->orderByDesc('assigned_to_id');
    }

    public function currentBooking()
    {
        return $this->hasMany('App\ResourceBooking', 'project_id', 'id')
            ->whereDate('end_date', '>=', Carbon::today())
            ->where('hours_per_day', '!=' , 0)
            ->with('userMembers', 'userProjects', 'userDepartment');
    }

    public function tillYesterdayBooking()
    {
        return $this->hasMany('App\ResourceBooking', 'project_id', 'id')->whereDate('end_date', '>=', Carbon::yesterday())->where('hours_per_day', '!=' , 0)->with('userMembers', 'userProjects', 'userDepartment');
    }

    public function billingProjects()
    {
        return $this->hasOne('App\CustomValue', 'customized_id', 'id')
        ->where('custom_field_id', config('constant.CUSTOM_VALUES.billing_unit'))
        ->whereIn('value', [4,5,6]);
    }
    public function projectInvoices()
    {
        return $this->hasOne('App\Invoice', 'project_id', 'id')->select('id','number','invoice_date','project_id','created_at','status_id')->orderBy('invoice_date','DESC');
    }

}
