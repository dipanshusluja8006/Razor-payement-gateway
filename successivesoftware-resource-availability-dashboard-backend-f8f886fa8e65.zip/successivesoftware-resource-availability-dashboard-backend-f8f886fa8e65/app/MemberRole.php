<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Helpers;
use Awobaz\Compoships\Compoships;

class MemberRole extends Model {


    /**
     * The table associated with the model.
     *
     * @var string
     */
    use Compoships;
    protected $connection="redmine_db_mysql";
    protected $fillable = [
        'id',
        'member_id',
        'role_id',
        'inherited_from'
    ];

    public function Role()
    {
        return $this->hasOne('App\Role', 'id', 'role_id')->select('id', 'name');
    }
}
