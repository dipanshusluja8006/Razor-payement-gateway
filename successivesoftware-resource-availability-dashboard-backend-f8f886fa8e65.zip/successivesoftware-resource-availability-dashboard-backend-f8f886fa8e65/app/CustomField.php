<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CustomField extends Model {

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $connection="redmine_db_mysql";
    protected $fillable = [
            'id',
            'type',
            'name',
            'field_format',
            'possible_values',
            'regexp',
            'min_length',
            'max_length',
            'is_required',
            'is_for_all',
            'is_filter',
            'position',
            'searchable',
            'default_value',
            'editable',
            'visible',
            'multiple',
            'format_store',
            'description',
            'ajaxable',
            'acl_trim_multiple',
            'user_editable',
            'dmsf_not_inheritable',
    ];
    /**
     * @param $value
     * @return mixed
     */
    static function possibleValues($value)
    {
        return $value = CustomField::where('id', $value)->select('possible_values')->first();
    }



}
