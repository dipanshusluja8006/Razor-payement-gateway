<?php

namespace App\Http\Controllers\Admin;

use App\EmailAddresse;
use App\Http\Controllers\Controller;
use App\Models\Department;
use App\Models\Project;
use App\Models\ProjectRole;
use App\Models\Role;
use App\User;
use App\Models\UserRole;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Helpers;
use ApiResponse;
use Successive\Keka\Http\Services\EmployeeService;
use App\Models\CronLog;

class UserManagementController extends Controller
{

    public function __construct()
    {
        $this->rolesArray = Helpers::getRoleByModel('Role');
    }

    public static $userManagementValidationRules = [
        'user_id' => 'required',
        'add_role_ids' => 'array',
        'add_role_ids.*' => 'exists:resource_mysql.roles,id',
        'add_dept_ids' => 'array',
        'add_dept_ids.*' => 'exists:resource_mysql.departments,id',
        'remove_role_ids' => 'array',
        'remove_role_ids.*' => 'exists:resource_mysql.roles,id',
        'remove_dept_ids' => 'array',
        'remove_dept_ids.*' => 'exists:resource_mysql.departments,id',
    ];

    public function index()
    {
        try {
            $user = User::select(
                'id',
                DB::raw("CONCAT(firstname,' ',lastname) as full_name"),
                DB::raw("(select address from email_addresses where users.id  =   user_id) as email"),
                DB::raw("(select value from custom_values where customized_id = users.id and custom_field_id = 15) as employee_id")
            )
                ->with('userDepartment', 'defaultRole', 'editableRole')
                ->where('status', config('constant.REDMINE_USERSTATUS.activeUser'))
                ->where('type', config('constant.REDMINE_USERSTATUS.userType'))->get();
            $userData = Helpers::mapDepartmentWithUserForManagement($user);

            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $userData);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function allRoles()
    {
        try {
            $roles = Role::select('id', 'code', 'role')
                ->whereNotIn('code', ['account_manager', 'project_manager', 'go_team'])
                ->get();
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $roles);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function update(Request $request)
    {
        $this->validate($request, self::$userManagementValidationRules);
        $requestData = $request;

        $buHead = $this->rolesArray[config('constant.ROLES.bu_head')];
        $accountManager = $this->rolesArray[config('constant.ROLES.account_manager')];
        $projectManager = $this->rolesArray[config('constant.ROLES.project_manager')];


        try {
            // code for delete global roles
            if (isset($requestData->remove_role_ids) && count($requestData->remove_role_ids) > 0) {
                $this->removeBuHeadAndGlobalRoles($requestData, $buHead, $accountManager, $projectManager);
            }

            // code for add global roles
            if (isset($requestData->add_role_ids) && count($requestData->add_role_ids) > 0) {
                $this->addBuHeadAndGlobalRoles($requestData, $buHead, $accountManager, $projectManager);
            }

            $createdRecord = UserRole::where('user_id', $requestData->user_id)->get();

            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusCreated'), $createdRecord);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }


    public function removeBuHeadAndGlobalRoles($requestData, $buHead, $accountManager, $projectManager)
    {
        // check array id for BUHead Role
        if (
            in_array($buHead, $requestData->remove_role_ids) &&
            (isset($requestData->remove_dept_ids) && count($requestData->remove_dept_ids) > 0)
        ) {
            //delete buHead roles
            UserRole::where(['user_id' => $requestData->user_id, 'role_id' => $buHead])->whereIn('dept_id', $requestData->remove_dept_ids)->delete();
        }

        // remove BUHead role id from delete array
        $delRoleIds = array_diff($requestData->remove_role_ids, [$buHead, $accountManager, $projectManager]);
        if (isset($delRoleIds) && count($delRoleIds) > 0) {
            //delete roles global roles
            UserRole::where(['user_id' => $requestData->user_id, 'project_id' => null])->whereIn('role_id', $delRoleIds)->delete();
        }
    }

    public function addBuHeadAndGlobalRoles($requestData, $buHead, $accountManager, $projectManager)
    {
        $allRecordArray = [];
        // check array id for BUHead Role
        if (
            in_array($buHead, $requestData->add_role_ids) &&
            (isset($requestData->add_dept_ids) && count($requestData->add_dept_ids) > 0)
        ) {

            // new BUHead roles records for create
            foreach ($requestData->add_dept_ids as $dept) {
                $roleMeta = [
                    'user_id' => $requestData->user_id,
                    'role_id' => $buHead,
                    'dept_id' => $dept
                ];
                $allRecordArray[] = $roleMeta;
            }
        }

        // remove BUHead role id from delete array
        $RoleIds = array_diff($requestData->add_role_ids, [$buHead, $accountManager, $projectManager]);
        if (isset($RoleIds) && count($RoleIds) > 0) {
            // new global roles records for create
            foreach ($RoleIds as $roleId) {
                $roleMeta = [
                    'user_id' => $requestData->user_id,
                    'role_id' => $roleId
                ];
                $allRecordArray[] = $roleMeta;
            }
        }

        //check existing record already exist or not and create new records
        if (count($allRecordArray) > 0) {
            foreach ($allRecordArray as $value) {
                $existGlobalRole = UserRole::where($value)->first();
                if (!isset($existGlobalRole)) {
                    $globalRole = new UserRole($value);
                    $globalRole->save();
                }
            }
        }
    }

    public function getCronLog()
    {
        try {
            $data = CronLog::all();
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $data);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }
}
