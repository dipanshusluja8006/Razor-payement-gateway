<?php

namespace App\Http\Controllers;

use Laravel\Lumen\Routing\Controller as BaseController;

class Controller extends BaseController
{
    /**
     * @OA\Info(
     *   title="Resource Dashboard API",
     *   version="1.0",
     *   @OA\Contact(
     *     email="support@example.com",
     *     name="Support Team"
     *   )
     * )
     *
     * @OA\Schema(
     *     schema="ProjectInitiation",
     *     type="object",
     *     title="ProjectInitiation",
     *     required={"project_name", "company_name", "company_address", "project_domain","client_name",
     *     "client_email", "client_email", "billing_type","approved_hours", "maximum_hours", "project_components",
     *     "initiation_date", "status", "project_documents_link","specific_requests", "project_summary",
     *     "technologies","account_manager_id","project_manager_id", "estimated_timeline_to","estimated_timeline_from"},
     *     properties={
     *         @OA\Property(property="project_name", type="string"),
     *         @OA\Property(property="company_name", type="string"),
     *         @OA\Property(property="company_address", type="string"),
     *         @OA\Property(property="project_domain", type="array",
     *         @OA\Items(type="integer",format="int32")),
     *         @OA\Property(property="client_name", type="string"),
     *         @OA\Property(property="client_email", type="string",format="email"),
     *         @OA\Property(property="billing_type", type="integer"),
     *         @OA\Property(property="approved_hours", type="integer"),
     *         @OA\Property(property="maximum_hours", type="integer"),
     *         @OA\Property(property="project_components", type="string"),
     *         @OA\Property(property="initiation_date", type="string",format="date"),
     *         @OA\Property(property="status", type="integer",format="int32"),
     *         @OA\Property(property="project_documents_link", type="string"),
     *         @OA\Property(property="specific_requests", type="string"),
     *         @OA\Property(property="project_summary", type="string"),
     *         @OA\Property(property="technologies", type="array",
     *         @OA\Items(type="integer",format="int32")),
     *         @OA\Property(property="account_manager_id", type="integer"),
     *         @OA\Property(property="project_manager_id", type="integer"),
     *         @OA\Property(property="estimated_timeline_to", type="string",format="date"),
     *         @OA\Property(property="estimated_timeline_from", type="string",format="date")
     *     }
     * )
     *
     * @OA\Schema(
     *     schema="ProjectUpdate",
     *     type="object",
     *     title="ProjectUpdate",
     *     required={"project_name", "company_name", "company_address", "project_domain","client_name",
     *     "client_email", "client_email", "billing_type","approved_hours", "maximum_hours", "project_components",
     *     "initiation_date", "status", "project_documents_link","specific_requests", "project_summary",
     *     "technologies","account_manager_id","project_manager_id", "estimated_timeline_to","estimated_timeline_from"},
     *     properties={
     *         @OA\Property(property="project_name", type="string"),
     *         @OA\Property(property="company_name", type="string"),
     *         @OA\Property(property="company_address", type="string"),
     *         @OA\Property(property="project_domain", type="array",
     *         @OA\Items(type="integer",format="int32")),
     *         @OA\Property(property="client_name", type="string"),
     *         @OA\Property(property="client_email", type="string",format="email"),
     *         @OA\Property(property="billing_type", type="integer"),
     *         @OA\Property(property="approved_hours", type="integer"),
     *         @OA\Property(property="maximum_hours", type="integer"),
     *         @OA\Property(property="project_components", type="string"),
     *         @OA\Property(property="initiation_date", type="string",format="date"),
     *         @OA\Property(property="status", type="integer",format="int32"),
     *         @OA\Property(property="project_documents_link", type="string"),
     *         @OA\Property(property="specific_requests", type="string"),
     *         @OA\Property(property="project_summary", type="string"),
     *         @OA\Property(property="technologies", type="array",
     *         @OA\Items(type="integer",format="int32")),
     *         @OA\Property(property="account_manager_id", type="integer"),
     *         @OA\Property(property="project_manager_id", type="integer"),
     *         @OA\Property(property="estimated_timeline_to", type="string",format="date"),
     *         @OA\Property(property="estimated_timeline_from", type="string",format="date")
     *     }
     * )
     *
     * @OA\Schema(
     *     schema="ProjectCreation",
     *     type="object",
     *     title="projectCreation",
     *     required={"status", "project_id", "project_status"},
     *     properties={
     *         @OA\Property(property="status", type="integer"),
     *         @OA\Property(property="project_id", type="string"),
     *         @OA\Property(property="project_status", type="integer")
     *     }
     * )
     *
     * @OA\Schema(
     *     schema="DesignationCreation",
     *     type="object",
     *     title="DesignationCreation",
     *     required={"name","code"},
     *     properties={
     *         @OA\Property(property="code", type="string"),
     *         @OA\Property(property="name", type="string")
     *     }
     * )
     *
     * @OA\Schema(
     *     schema="ProjectClose",
     *     type="object",
     *     title="ProjectClose",
     *     required={"checkboxIds", "status_id"},
     *     properties={
     *         @OA\Property(property="checkboxIds", type="array", items="type:object"),
     *         @OA\Property(property="status_id", type="integer")
     *     }
     * )
     *
     *  * * @OA\Schema(
     *     schema="ProjectClosure",
     *     type="object",
     *     title="ProjectClosure",
     *     required={"checkboxIds"},
     *     properties={
     *         @OA\Property(property="checkboxIds", type="array", items="type:object")
     *     }
     * )
     *
     * * @OA\Schema(
     *     schema="UpdateProjectClosure",
     *     type="object",
     *     title="UpdateProjectClosure",
     *     required={"checkboxIds"},
     *     properties={
     *         @OA\Property(property="checkboxIds", type="array", items="type:object")
     *     }
     * )
     *
     * @OA\Schema(
     *     schema="ProjectDomain",
     *     type="object",
     *     title="ProjectDomain",
     *     required={"name"},
     *     properties={
     *         @OA\Property(property="name", type="string")
     *     }
     * )
     *
     * @OA\Schema(
     *     schema="ProjectDomainUpdate",
     *     type="object",
     *     title="ProjectDomain",
     *     required={"name"},
     *     properties={
     *         @OA\Property(property="name", type="string")
     *     }
     * )
     *
     * @OA\Schema(
     *     schema="ResourceAllocate",
     *     type="object",
     *     title="ResourceAllocate",
     *     required={"project_id","allocation_data","project_status"},
     *     properties={
     *         @OA\Property(property="allocation_data", type="array",
     *             @OA\Items(type="object",
     *                  @OA\Property(property="resource_req_id", type="string"),
     *                  @OA\Property(property="resource_id", type="integer"),
     *                  @OA\Property(property="tech", type="integer"),
     *                  @OA\Property(property="dept", type="integer"),
     *                  @OA\Property(property="efforts", type="integer"),
     *                  @OA\Property(property="experience", type="integer"),
     *                  @OA\Property(property="start_date", type="string",format="date"),
     *                  @OA\Property(property="end_date", type="string",format="date"),
     *                  @OA\Property(property="no_of_hours", type="integer")
     *              ),
     *         ),
     *         @OA\Property(property="project_id", type="string"),
     *         @OA\Property(property="project_status", type="integer")
     *     }
     * )
     * @OA\Schema(
     *     schema="ResourceDirectAllocate",
     *     type="object",
     *     title="ResourceAllocate",
     *     required={"project_id","allocation_data"},
     *     properties={
     *         @OA\Property(property="allocation_data", type="array",
     *             @OA\Items(type="object",
     *                  @OA\Property(property="resource_id", type="integer"),
     *                  @OA\Property(property="tech_id", type="integer"),
     *                  @OA\Property(property="dept_id", type="integer"),
     *                  @OA\Property(property="efforts", type="integer"),
     *                  @OA\Property(property="experience", type="integer"),
     *                  @OA\Property(property="start_date", type="string",format="date"),
     *                  @OA\Property(property="end_date", type="string",format="date"),
     *                  @OA\Property(property="role_id", type="integer")
     *              ),
     *         ),
     *         @OA\Property(property="project_id", type="string")
     *     }
     * )
     * @OA\Schema(
     *     schema="ResourceReAllocate",
     *     type="object",
     *     title="ResourceAllocate",
     *     required={"project_id","resource_req_id","resource_id","tech","dept","efforts","experience","start_date","end_date","no_of_hours","project_status","allocation_status"},
     *     properties={
     *         @OA\Property(property="project_id", type="string"),
     *         @OA\Property(property="resource_req_id", type="string"),
     *         @OA\Property(property="resource_id", type="integer"),
     *         @OA\Property(property="tech", type="integer"),
     *         @OA\Property(property="dept", type="integer"),
     *         @OA\Property(property="efforts", type="integer"),
     *         @OA\Property(property="experience", type="integer"),
     *         @OA\Property(property="start_date", type="string" ,format="date"),
     *         @OA\Property(property="end_date", type="string" ,format="date"),
     *         @OA\Property(property="no_of_hours", type="integer"),
     *         @OA\Property(property="project_status", type="integer"),
     *         @OA\Property(property="allocation_status", type="integer")
     *    }
     * )
     * @OA\Schema(
     *     schema="EditAllocation",
     *     type="object",
     *     title="Edit-Allocation",
     *     required={"project_id","allocation_data"},
     *     properties={
     *         @OA\Property(property="allocation_data", type="array",
     *             @OA\Items(type="object",
     *                  @OA\Property(property="efforts", type="integer"),
     *                  @OA\Property(property="resource_req_id", type="string"),
     *                  @OA\Property(property="experience", type="integer"),
     *                  @OA\Property(property="resource_id", type="integer"),
     *                  @OA\Property(property="start_date", type="string",format="date"),
     *                  @OA\Property(property="end_date", type="string",format="date"),
     *                  @OA\Property(property="isDelete", type="boolean")
     *              ),
     *         ),
     *         @OA\Property(property="project_id", type="string")
     *     }
     * )
     * @OA\Schema(
     *     schema="ResourceApprove",
     *     type="object",
     *     title="ResourceApprove",
     *     required={"approve_status"},
     *     properties={
     *         @OA\Property(property="approve_status", type="integer")
     *    }
     * )
     * @OA\Schema(
     *     schema="ResourceDeallocate",
     *     type="object",
     *     title="ResourceDeallocate",
     *     required={"de_allocation_data","project_status","project_id"},
     *     properties={
     *         @OA\Property(property="project_id", type="string"),
     *         @OA\Property(property="de_allocation_data", type="array",
     *             @OA\Items(type="object",
     *                  @OA\Property(property="full_deallocate", type="boolean"),
     *                  @OA\Property(property="uuid", type="string"),
     *                  @OA\Property(property="allocation_meta_uuid", type="string"),
     *                  @OA\Property(property="hours", type="integer"),
     *                  @OA\Property(property="start_date", type="string"),
     *              ),
     *         ),
     *         @OA\Property(property="project_status", type="integer")
     *     }
     * )
     * @OA\Schema(
     *     schema="EditRequisition",
     *     type="object",
     *     title="Edit/Delete Requisition",
     *     required={"resource_data","project_id"},
     *     properties={
     *         @OA\Property(property="project_id", type="string"),
     *         @OA\Property(property="resource_data", type="array",
     *             @OA\Items(type="object",
     *                  @OA\Property(property="resource_requisition_uuid", type="string"),
     *                  @OA\Property(property="isDelete", type="boolean"),
     *                  @OA\Property(property="dept_id", type="integer"),
     *                  @OA\Property(property="tech_id", type="integer"),
     *                  @OA\Property(property="role_id", type="integer"),
     *                  @OA\Property(property="no_of_resource", type="integer"),
     *                  @OA\Property(property="efforts", type="number"),
     *                  @OA\Property(property="experience", type="integer"),
     *                  @OA\Property(property="end_date", type="string"),
     *                  @OA\Property(property="start_date", type="string"),
     *              ),
     *         )
     *     }
     * )
     * @OA\Schema(
     *     schema="ResourceMapResource",
     *     type="object",
     *     title="ResourceMapResource",
     *     required={"project_id","project_status","map_data"},
     *     properties={
     *         @OA\Property(property="project_id", type="string"),
     *         @OA\Property(property="project_status", type="integer"),
     *         @OA\Property(property="map_data", type="array",
     *             @OA\Items(type="object",
     *                  @OA\Property(property="resource_mapping_id", type="integer"),
     *                  @OA\Property(property="status", type="integer")
     *              ),
     *         )
     *     }
     * )
     *
     * * @OA\Schema(
     *     schema="ResourceDeMapResource",
     *     type="object",
     *     title="ResourceDeMapResource",
     *     required={"project_id","de_allocation_map_data"},
     *     properties={
     *         @OA\Property(property="project_id", type="string"),
     *         @OA\Property(property="de_allocation_map_data", type="array",
     *             @OA\Items(type="object",
     *                  @OA\Property(property="de_allocation_map_id", type="integer"),
     *                  @OA\Property(property="status", type="integer")
     *              ),
     *         )
     *     }
     * )
     *
     * * @OA\Schema(
     *     schema="ResourceRequisition",
     *     type="object",
     *     title="ResourceRequisition",
     *     required={"project_id","resource_data"},
     *     properties={
     *         @OA\Property(property="project_id", type="string"),
     *         @OA\Property(property="project_status", type="integer"),
     *         @OA\Property(property="resource_data", type="array",
     *             @OA\Items(type="object",
     *                  @OA\Property(property="dept_id", type="integer"),
     *                  @OA\Property(property="tech_id", type="integer"),
     *                  @OA\Property(property="no_of_resource", type="integer"),
     *                  @OA\Property(property="efforts", type="integer"),
     *                  @OA\Property(property="experience", type="integer"),
     *                  @OA\Property(property="start_date", type="string",format="date"),
     *                  @OA\Property(property="end_date", type="string" ,format="date")
     *              ),
     *         )
     *     }
     * )
     *
     * @OA\Schema(
     *     schema="ProjectOnHold",
     *     type="object",
     *     title="ProjectOnHold",
     *     required={"reason","from","to"},
     *     properties={
     *         @OA\Property(property="reason", type="string"),
     *         @OA\Property(property="from", type="string"),
     *         @OA\Property(property="to", type="string")
     *    }
     * )
     * @OA\Schema(
     *     schema="ProjectOnHoldAction",
     *     type="object",
     *     title="ProjectOnHold",
     *     required={"status_id","reason","from","to"},
     *     properties={
     *         @OA\Property(property="status_id", type="integer"),
     *         @OA\Property(property="reason", type="string"),
     *         @OA\Property(property="from", type="string"),
     *         @OA\Property(property="to", type="string"),
     *         @OA\Property(property="requested_by", type="integer")
     *    }
     * )
     *
     * @OA\Schema(
     *     schema="RcaCreate",
     *     type="object",
     *     title="RcaCreate",
     *     required={"issue_detail", "date_of_issue_reported_first",
     *     "date_of_action_reported_first","issue_reported_by","resolve_issue_type",
     *     "time_taken_to_fix","issue_priority","prevent_for_future"},
     *     properties={
     *         @OA\Property(property="issue_detail", type="string"),
     *         @OA\Property(property="date_of_issue_reported_first", type="date-time"),
     *         @OA\Property(property="date_of_action_reported_first", type="date-time"),
     *         @OA\Property(property="issue_reported_by", type="integer"),
     *         @OA\Property(property="resolve_issue_type", type="string"),
     *         @OA\Property(property="time_taken_to_fix", type="integer"),
     *         @OA\Property(property="issue_priority", type="integer"),
     *         @OA\Property(property="prevent_for_future", type="string"),
     *         @OA\Property(property="fixed_by", type="array",
     *         @OA\Items(type="integer",format="int32")),
     *         @OA\Property(property="attachments", type="array",
     *         @OA\Items(type="integer",format="int32")),
     *     }
     * )
     *
     *     @OA\Schema(
     *     schema="Tag",
     *     type="object",
     *     title="kedb Tag",
     *     required={"name"},
     *     properties={
     *         @OA\Property(property="name", type="string")
     *     }
     * )
     *     @OA\Schema(
     *     schema="TagUpdate",
     *     type="object",
     *     title="kedb Tag",
     *     required={"name"},
     *     properties={
     *         @OA\Property(property="name", type="string")
     *     }
     * )
     *
     *     @OA\Schema(
     *     schema="Kedb",
     *     type="object",
     *     title="Kedb",
     *     required={"description_of_known_error", "description_of_workaround"},
     *     properties={
     *         @OA\Property(property="project_id", type="string"),
     *         @OA\Property(property="project_rca_id", type="string"),
     *         @OA\Property(property="description_of_known_error", type="string"),
     *         @OA\Property(property="description_of_workaround", type="string"),
     *         @OA\Property(property="tags", type="array",
     *         @OA\Items(type="integer",format="int32")),
     *         @OA\Property(property="attachments", type="array",
     *         @OA\Items(type="integer",format="int32")),
     *
     *     }
     * )
     *
     *     @OA\Schema(
     *     schema="PyramidPost",
     *     type="object",
     *     title="PyramidPost",
     *     required={"dept_id","experience_data","employee_count"},
     *     properties={
     *         @OA\Property(property="experience_data", type="array",
     *             @OA\Items(type="object",
     *                  @OA\Property(property="percent", type="integer"),
     *                  @OA\Property(property="min_experience", type="float"),
     *                  @OA\Property(property="max_experience", type="float"),
     *
     *              ),
     *         ),
     *         @OA\Property(property="dept_id", type="integer"),
     *         @OA\Property(property="employee_count", type="integer")
     *     }
     * )
     *
     *
     *     @OA\Schema(
     *     schema="PyramidUpdate",
     *     type="object",
     *     title="PyramidUpdate",
     *     required={"dept_id","experience_data","employee_count"},
     *     properties={
     *         @OA\Property(property="experience_data", type="array",
     *             @OA\Items(type="object",
     *                  @OA\Property(property="percent", type="integer"),
     *                  @OA\Property(property="min_experience", type="float"),
     *                  @OA\Property(property="max_experience", type="float"),
     *
     *              ),
     *         ),
     *         @OA\Property(property="dept_id", type="integer"),
     *         @OA\Property(property="employee_count", type="integer")
     *     }
     * )
     */
}
