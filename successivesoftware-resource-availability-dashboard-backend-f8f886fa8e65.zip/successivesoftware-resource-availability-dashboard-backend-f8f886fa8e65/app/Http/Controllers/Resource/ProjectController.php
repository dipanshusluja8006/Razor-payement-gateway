<?php

namespace App\Http\Controllers\Resource;

use App\EmailAddresse;
use App\Http\Controllers\Controller;
use App\Libraries\MailService;
use App\Mail\ProjectInitiation;
use App\Models\Department;
use App\Models\PerformedActionLog;
use App\Models\Project;
use App\Models\UserRole;
use App\Models\UserAction;
use App\Models\UserActionRole;
use App\Models\StaticActionList;
use App\Models\ResourceRequisition;
use Illuminate\Http\Request;
use Helpers;
use Illuminate\Support\Facades\Mail;
use ApiResponse;
use App\Models\ResourceMapping;
use App\Traits\ResourceControllerTraits;
use Carbon\Carbon;
use Log;
use App\Models\ProjectActivity;
use App\ResourceBooking;
use App\TimeEntrie;
use App\CustomValue;
use App\Project as RedmineProjectModel;
use App\Models\LocalUser;
use App\Models\WeeklyStatusReport;
use App\Models\PartnerCollaboration;
use DB;

class ProjectController extends Controller
{
    use ResourceControllerTraits;
    protected $helpers;
    /**
     * ProjectController constructor.
     */
    public function __construct(Helpers $helpers)
    {
        $this->helpers = $helpers;
        $this->rolesArray = Helpers::getRoleByModel('Role');
        $this->departmentArray = Helpers::getRoleByModel('Department');
    }


    public static $initiationValidationRules = [
        'project_manager_id' => 'required|array',
        'project_manager_id.*' => 'exists:redmine_db_mysql.users,id',
        'account_manager_id' => 'required|array',
        'account_manager_id.*' => 'exists:redmine_db_mysql.users,id',
        'technologies' => 'required|array',
        'project_domain' => 'required|array',
        'project_domain.*' => 'exists:resource_mysql.project_domains,id',
        'status' => 'required',
        'technologies.*' => 'exists:resource_mysql.technologies,id',
        //        'save_as_draft' => 'required',
        'project_id' => 'nullable|exists:resource_mysql.projects,uuid',
    ];

    public static $initiationDraftValidationRules = [
        'project_name' => 'required',
        'project_manager_id' => 'array',
        'account_manager_id' => 'array',
        'technologies' => 'array',
        'project_domain' => 'array',
        'status' => 'required',
        //        'save_as_draft' => 'required',
        'project_id' => 'nullable|exists:resource_mysql.projects,uuid',
    ];

    public static $validationRules = [
        'project_manager_id' => 'required|array',
        'project_manager_id.*' => 'exists:redmine_db_mysql.users,id',
        'account_manager_id' => 'required|array',
        'account_manager_id.*' => 'exists:redmine_db_mysql.users,id',
        'technologies' => 'required|array',
        'project_domain' => 'required|array',
        'project_domain.*' => 'exists:resource_mysql.project_domains,id',
        'status' => 'required',
        'technologies.*' => 'exists:resource_mysql.technologies,id'
    ];

    public static $updateProjectStatus = [
        'status_id' => 'required'
    ];

    public static $projectCreationvalidationRules = [
        'project_id' => 'required|exists:resource_mysql.projects,uuid',
    ];

    public static $projectSummaryValidation = [
        'redmine_project_ids' => 'array'
    ];

    /**
     *
     * @OA\Get(
     *     path="/v1/project",
     *     operationId="/v1/project/index",
     *     summary="Fetch all project details",
     *     tags={"Project"},
     *     @OA\Response(
     *         response="200",
     *         description="Returns all Project",
     *         @OA\JsonContent()
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function index(Request $request)
    {
        $currentUserId = $request->user->id;
        $checkMapped = false;
        $pendingInitiaion = true;
        try {
            $userRole = Helpers::getRole($currentUserId);
            if (in_array($this->rolesArray[config('constant.ROLES.admin')], $userRole['global'])) {
                $userRole['department'] = Department::pluck('id')->toArray();
            }
            $projects = Project::with([
                'projectClosureDetails', 'technologies', 'lifecycleModel', 'projectType', 'governanceCategory', 'subProjectName', 'projectDomains', 'billingType', 'initiatedBy', 'deAllocationMappingPending', 'resourceMappingPending', 'accountManagers', 'ResourceRequisitionAll', 'projectManagers',
                'resourceRequisitionAllProject' => function ($query) use ($userRole) {
                    $query->whereIn('dept_id', $userRole['department']);
                }, 'ProjectRole' => function ($query) use ($currentUserId) {
                    $query->where('user_id', $currentUserId);
                }
            ])->orderBy('created_at', 'desc')->get();
            $projects = $this->removeUnAuthorizedProjects($projects, $currentUserId, $userRole, $checkMapped, $pendingInitiaion);
            $projects = $this->checkWsrWeekStatus($projects);
            $projectDetails = $this->isProjectActionPending($projects, $currentUserId);
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $projectDetails);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }
    public function checkWsrWeekStatus($projects)
    {
        if (!empty($projects)) {
            $today = Carbon::today();
            $weekNumber = $today->weekOfYear;
            foreach ($projects as $key => $value) {
                $value->wsr_status = 0;
                $wsrresult = WeeklyStatusReport::where('project_id', '=', $value->uuid)
                ->where('week_no', '=', $weekNumber)
                ->where('overall_health_status', '!=', 4)
                ->pluck('uuid')->toArray();
                if (count($wsrresult) > 0) {
                    $value->wsr_status = 1;
                }
            }
            return $projects;
        }
    }

    public function removeUnAuthorizedProjects($projects, $currentUserId, $userRole, $checkMapped, $pendingInitiaion = false)
    {
        $filterProjects = [];
        if (!empty($projects)) {
            foreach ($projects as $key => $value) {
                $flag = false;
                if ($value->is_draft == 0) {
                    if (
                        in_array($this->rolesArray[config('constant.ROLES.admin')], $userRole['global']) ||
                        in_array($this->rolesArray[config('constant.ROLES.global_operation')], $userRole['global'])
                    ) {
                        $flag = true;
                    } else {
                        if ((in_array($this->rolesArray[config('constant.ROLES.sales')], $userRole['global']) ||
                                in_array($this->rolesArray[config('constant.ROLES.resource_manager')], $userRole['global']))
                            && $value->status != config('constant.PROJECT_ACTION.initiation_request')
                        ) {
                            $flag = true;
                        } else if (count($value['ProjectRole']) > 0 && $value->status != config('constant.PROJECT_ACTION.initiation_request')) {
                            $flag = true;
                        } else if ($value->created_by == $currentUserId && $value->status == config('constant.PROJECT_ACTION.initiation_request')) {
                            $flag = true;
                        } else if (count($value['resourceRequisitionAllProject']) > 0) {
                            foreach ($value['resourceRequisitionAllProject'] as $requisition) {
                                if ($requisition->status == 0) {
                                    $flag = true;
                                    break;
                                } else {
                                    if (count($requisition['Allocation']) > 0) {
                                        foreach ($requisition['Allocation'] as $allocation) {
                                            if ($allocation->allocation_status == 14) {
                                                $flag = true;
                                                break;
                                            }
                                        }
                                        if ($flag) {
                                            break;
                                        }
                                    }
                                }
                            }
                        } else {
                            if ($checkMapped) {
                                if (isset($value['resourceMapped'])) {
                                    foreach ($value['resourceMapped'] as $mappedResource) {
                                        if (isset($mappedResource['resourceAllocation']['resourceAllocationMeta']) && $mappedResource['resourceAllocation']->allocation_status == 14) {
                                            $flag = true;
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if ($value->created_by == $currentUserId) {
                        $flag = true;
                    }
                }

                if ($flag) {
                    array_push($filterProjects, $value);
                }
            }
        }
        return $filterProjects;
    }

    public function mergeUserAndPerformedAction($project)
    {
        if (isset($project)) {
            $mergeArray = array_merge($project->user_actions, $project->performed_action);
            $project->user_performed_action = $mergeArray;
        }
        return $project;
    }

    public function addPerformedActionInProjectAccordingRole($project, $userId)
    {
        if (isset($project)) {
            $userActionRole = $this->getUserActionRoles();
            $userProjectRole = Helpers::getRole($userId, $project['uuid']);
            $performedActionLog = PerformedActionLog::where('project_id', $project['uuid'])->with('userAction')->get();
            $performedUserLog = [];

            if (in_array($this->rolesArray[config('constant.ROLES.admin')], $userProjectRole['global'])) {
                if (isset($performedActionLog[0])) {
                    foreach ($performedActionLog as $log) {
                        $log->name = $log['userAction']->name;
                        $log->disabled = true;
                        array_push($performedUserLog, $log);
                    }
                }
                $project->performed_action = $performedUserLog;
            }

            if (isset($performedActionLog[0])) {
                foreach ($performedActionLog as $value) {
                    $flag = false;
                    $currentActionRequiredRole = $userActionRole[$value['user_action_id']];
                    if (in_array($this->rolesArray[config('constant.ROLES.bu_head')], $currentActionRequiredRole)) {
                        if ((!empty(array_intersect($userProjectRole['global'], $currentActionRequiredRole))) &&
                            in_array($value['dept_id'], $userProjectRole['department'])
                        ) {
                            $value->name = $value['userAction']->name;
                            $value->disabled = true;
                            array_push($performedUserLog, $value);
                            $flag = true;
                        }
                    }
                    if (
                        !$flag && (in_array($this->rolesArray[config('constant.ROLES.account_manager')], $currentActionRequiredRole) ||
                            in_array($this->rolesArray[config('constant.ROLES.project_manager')], $currentActionRequiredRole))
                    ) {
                        if (!empty(array_intersect($userProjectRole['project'], $currentActionRequiredRole))) {
                            $value->name = $value['userAction']->name;
                            $value->disabled = true;
                            array_push($performedUserLog, $value);
                            $flag = true;
                        }
                    }

                    if (
                        !$flag
                        && $value['user_action_id'] == config('constant.USER_ACTIONLIST.creation-request')
                    ) {
                        if ($value['status'] == config('constant.PERFORM_ACTIONLOG.inProgress')) {
                            if (
                                in_array($this->rolesArray[config('constant.ROLES.global_operation')], $userProjectRole['global']) ||
                                in_array($this->rolesArray[config('constant.ROLES.sales')], $userProjectRole['global'])
                            ) {
                                $value->name = $value['userAction']->name;
                                $value->disabled = true;
                                array_push($performedUserLog, $value);
                                $flag = true;
                            }
                        } else {
                            if (!empty(array_intersect($userProjectRole['global'], $currentActionRequiredRole))) {
                                $value->name = $value['userAction']->name;
                                $value->disabled = true;
                                array_push($performedUserLog, $value);
                                $flag = true;
                            }
                        }
                    }

                    if (
                        !$flag && (in_array($this->rolesArray[config('constant.ROLES.global_operation')], $currentActionRequiredRole) ||
                            in_array($this->rolesArray[config('constant.ROLES.sales')], $currentActionRequiredRole))
                    ) {
                        if (
                            !empty(array_intersect($userProjectRole['global'], $currentActionRequiredRole)) || (in_array($this->rolesArray[config('constant.ROLES.bu_head')], $userProjectRole['global']) && (in_array($this->departmentArray[config('constant.DEPARTMENT.global_operation')], $userProjectRole['department']) ||
                                in_array($this->departmentArray[config('constant.DEPARTMENT.sales')], $userProjectRole['department'])))
                        ) {
                            $value->name = $value['userAction']->name;
                            $value->disabled = true;
                            array_push($performedUserLog, $value);
                            $flag = true;
                        }
                    }

                    if (
                        !$flag &&
                        !in_array($this->rolesArray[config('constant.ROLES.bu_head')], $currentActionRequiredRole)
                        && $value['user_action_id'] != config('constant.USER_ACTIONLIST.creation-request')
                    ) {
                        if (!empty(array_intersect($userProjectRole['global'], $currentActionRequiredRole))) {
                            $value->name = $value['userAction']->name;
                            $value->disabled = true;
                            array_push($performedUserLog, $value);
                            $flag = true;
                        }
                    }
                }
                $project->performed_action = $performedUserLog;
            } else {
                $project->performed_action = [];
            }
        }
        return $project;
    }

    public function isProjectActionPending($projects, $userId)
    {
        if (!empty($projects)) {
            $userActionRole = $this->getUserActionRoles();
            $getUserActionIds = UserAction::whereIn('code', config('constant.RESPONSE_REQUIRED_ACTION_LIST'))->pluck('id')->toArray();
            $actionPendingProject = [];
            $completeProject = [];
            $userRole = Helpers::getRole($userId);
            foreach ($projects as $project) {
                $userRole['project'] = [];
                $project->action_pending = false;
                $project->track = ['status' => $project->status, 'is_approve' => $project->is_approve, 'is_draft' => $project->is_draft];
                if (count($project['ProjectRole']))
                    foreach ($project['ProjectRole'] as $projectRole) {
                        $userRole['project'][] = $projectRole->role_id;
                    }
                foreach ($getUserActionIds as $action) {
                    $permitedRole = $userActionRole[$action];
                    if (
                        array_intersect($permitedRole, $userRole['global']) || array_intersect($permitedRole, $userRole['project']) ||
                        in_array($this->rolesArray[config('constant.ROLES.admin')], $userRole['global'])
                    ) {

                        if (config('constant.RESPONSE_REQUIRED_ACTION_LIST_WITH_ID.initiation-approval') == $action) {
                            //initiation-approval
                            if ($project->status == config('constant.PROJECT_ACTION.initiation_request') && $project->is_approve == config('constant.PROJECT_APPROVAL.approval_request')) {
                                $project->action_pending = true;
                                break;
                            }
                        }
                        if ($project->created_by == $userId || in_array($this->rolesArray[config('constant.ROLES.admin')], $userRole['global'])) {
                            if (
                                !(in_array($this->rolesArray[config('constant.ROLES.sales')], $userRole['global'])
                                    || in_array($this->rolesArray[config('constant.ROLES.global_operation')], $userRole['global']))
                                || in_array($this->rolesArray[config('constant.ROLES.admin')], $userRole['global'])
                            ) {
                                if (config('constant.RESPONSE_REQUIRED_ACTION_LIST_WITH_ID.initiation-request') == $action) {
                                    //initiation-request-edit(initiation-request)
                                    if ($project->status == config('constant.PROJECT_ACTION.initiation_request') && $project->is_approve == config('constant.PROJECT_APPROVAL.edit_initiation_request')) {
                                        $project->action_pending = true;
                                        break;
                                    }
                                }
                            }
                        }
                        if (config('constant.RESPONSE_REQUIRED_ACTION_LIST_WITH_ID.creation-request') == $action) {
                            //check pending action
                            if ($project->status == config('constant.PROJECT_ACTION.initiation')) {
                                $project->action_pending = true;
                                break;
                            }
                        }
                        if (config('constant.RESPONSE_REQUIRED_ACTION_LIST_WITH_ID.resource-mapping') == $action) {
                            //resource-deallocation-resource-manager  mapping pending
                            if (count($project['resourceMappingPending']) > 0) {
                                $project->action_pending = true;
                                break;
                            }
                        }
                        if (config('constant.RESPONSE_REQUIRED_ACTION_LIST_WITH_ID.resource-deallocation-resource-manager') == $action) {
                            //resource-deallocation-resource-manager  un_mapping pending
                            if (count($project['deAllocationMappingPending']) > 0) {
                                $project->action_pending = true;
                                break;
                            }
                        }
                        if (config('constant.RESPONSE_REQUIRED_ACTION_LIST_WITH_ID.hold-request-approval') == $action) {
                            //hold-request-approval
                            if ($project->status == config('constant.PROJECT_ACTION.project_on_hold_request')) {
                                $project->action_pending = true;
                                break;
                            }
                        }
                        if (config('constant.RESPONSE_REQUIRED_ACTION_LIST_WITH_ID.resource-allocation') == $action) {
                            //allocation pending
                            foreach ($project['resourceRequisitionAllProject'] as $resourceRequisition) {
                                if (count($resourceRequisition['Allocation']) == 0) {
                                    $project->action_pending = true;
                                    break;
                                }
                            }
                        }
                        if (config('constant.RESPONSE_REQUIRED_ACTION_LIST_WITH_ID.resource-allocation-manager') == $action) {
                            //resource-allocation-manager
                            foreach ($project['ResourceRequisitionAll'] as $resourceRequisition) {
                                if (isset($resourceRequisition['Allocation'])) {
                                    foreach ($resourceRequisition['Allocation'] as $resourceAllocation) {
                                        if ($resourceAllocation->allocation_status == config('constant.PROJECT_ACTION.resource_allocation_request')) {
                                            $project->action_pending = true;
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                        if (config('constant.RESPONSE_REQUIRED_ACTION_LIST_WITH_ID.resource-reallocation') == $action) {
                            //resource-reallocation
                            foreach ($project['resourceRequisitionAllProject'] as $resourceRequisition) {
                                if (isset($resourceRequisition['Allocation'])) {
                                    foreach ($resourceRequisition['Allocation'] as $resourceAllocation) {
                                        if ($resourceAllocation->allocation_status == config('constant.PROJECT_ACTION.resource_allocation_response_decline')) {
                                            $project->action_pending = true;
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                if ($project->action_pending) {
                    array_push($actionPendingProject, $project);
                } else {
                    array_push($completeProject, $project);
                }
            }
            $projects = array_merge($actionPendingProject, $completeProject);
        }
        return $projects;
    }

    public function addUserActionInProjectAccordingRole($project, $userId)
    {
        $adminAccess = false;
        if (isset($project)) {

            $allUserAction = $this->getUserActionRecord();
            $userActionRole = $this->getUserActionRoles();
            $statusActionList = $this->getStatusActionList();
            $userProjectRole = Helpers::getRole($userId, $project['uuid']);
            $getCurrentProjectEligibleAction = isset($statusActionList[$project->status]) ? $statusActionList[$project->status] : [];
            $approvedUserAction = [];

            if (in_array($this->rolesArray[config('constant.ROLES.admin')], $userProjectRole['global'])) {
                $adminAccess = true;
            }
            if (!empty($getCurrentProjectEligibleAction)) {
                $removableAction = $this->fetchAllNotRequiredActionOfProject($project['uuid'], $userProjectRole, $userId);
                $getCurrentProjectEligibleAction = array_diff($getCurrentProjectEligibleAction, $removableAction);

                if (in_array(config('constant.USER_ACTIONLIST.edit-allocation'), $getCurrentProjectEligibleAction)) {
                    $editAllocationExists = $this->isAnyEditAllocationExists($userId, $project['uuid']);
                    if (!$editAllocationExists) {
                        if (($index = array_search(config('constant.USER_ACTIONLIST.edit-allocation'), $getCurrentProjectEligibleAction)) !== false) {
                            unset($getCurrentProjectEligibleAction[$index]);
                        }
                    }
                }
                foreach ($getCurrentProjectEligibleAction as $action) {
                    $flag = false;
                    $currentActionRequiredRole = $userActionRole[$action];

                    if (
                        $action == config('constant.USER_ACTIONLIST.initiation-approval') ||
                        $action == config('constant.USER_ACTIONLIST.initiation-request')
                    ) {
                        array_push($approvedUserAction, $action);
                        $flag = true;
                    }
                    if ($adminAccess || in_array($this->rolesArray[config('constant.ROLES.bu_head')], $currentActionRequiredRole)) {
                        $getProjectRequisitionDepartment = $this->getProjectRequisitionDepartmentArray($project->uuid);
                        if ($action == config('constant.USER_ACTIONLIST.edit-allocation')) {
                            $unmappedDepartmentArray = $this->getUnmappedRequisitionDepartmentArray($project->uuid);
                            $getProjectRequisitionDepartment = array_merge($getProjectRequisitionDepartment, $unmappedDepartmentArray);
                        }
                        if (
                            $adminAccess || ((!empty(array_intersect($userProjectRole['global'], $currentActionRequiredRole))) &&
                                !empty(array_intersect($userProjectRole['department'], $getProjectRequisitionDepartment)))
                        ) {
                            array_push($approvedUserAction, $action);
                            $flag = true;
                        }
                    }
                    if (
                        !$flag && (in_array($this->rolesArray[config('constant.ROLES.account_manager')], $currentActionRequiredRole) ||
                            in_array($this->rolesArray[config('constant.ROLES.project_manager')], $currentActionRequiredRole))
                    ) {
                        if ($adminAccess || !empty(array_intersect($userProjectRole['project'], $currentActionRequiredRole))) {
                            array_push($approvedUserAction, $action);
                            $flag = true;
                        }
                    }
                    if (
                        !$flag && (in_array($this->rolesArray[config('constant.ROLES.global_operation')], $currentActionRequiredRole) ||
                            in_array($this->rolesArray[config('constant.ROLES.sales')], $currentActionRequiredRole))
                    ) {
                        if (
                            $adminAccess ||
                            !empty(array_intersect($userProjectRole['global'], $currentActionRequiredRole)) || (in_array($this->rolesArray[config('constant.ROLES.bu_head')], $userProjectRole['global']) && (in_array($this->departmentArray[config('constant.DEPARTMENT.global_operation')], $userProjectRole['department']) ||
                                in_array($this->departmentArray[config('constant.DEPARTMENT.sales')], $userProjectRole['department'])))
                        ) {
                            array_push($approvedUserAction, $action);
                            $flag = true;
                        }
                    }
                    if (
                        !$flag &&
                        !in_array($this->rolesArray[config('constant.ROLES.bu_head')], $currentActionRequiredRole)
                    ) {
                        if ($adminAccess || !empty(array_intersect($userProjectRole['global'], $currentActionRequiredRole))) {
                            array_push($approvedUserAction, $action);
                            $flag = true;
                        }
                    }
                }
                $project = $this->addUserActionInProject($project, $approvedUserAction, $allUserAction);
            } else {
                $project->user_actions = [];
            }
        }
        return $project;
    }

    public function getUnmappedRequisitionDepartmentArray($projectUuid)
    {
        $unmappedDepartmentArray = [];
        $unMappedData = ResourceMapping::with('resourceAllocation')
            ->where(['project_id' => $projectUuid, 'status' => config('constant.GENERAL_STATUS.decline')])
            ->get();
        if (isset($unMappedData)) {
            foreach ($unMappedData as $record) {
                if ($record['resourceAllocation'] && $record['resourceAllocation']['resourceRequisition']) {
                    array_push($unmappedDepartmentArray, $record['resourceAllocation']['resourceRequisition']['dept_id']);
                }
            }
        }
        return $unmappedDepartmentArray;
    }

    public function getProjectRequisitionDepartmentArray($projectUuid)
    {
        $departments = [];
        $requisition = ResourceRequisition::with(['ResourceAllocation'])
            ->where(
                [
                    'project_id' => $projectUuid,
                    'status' => '0'
                ]
            )->get();
        if (isset($requisition[0])) {
            foreach ($requisition as $key => $value) {
                array_push($departments, $value['dept_id']);
            }
        }
        return $departments;
    }

    public function addUserActionInProject($project, $userAction, $allUserAction)
    {
        $userActions = [];
        if (!empty($userAction)) {
            foreach ($userAction as $key => $value) {
                $allUserAction[$value]->status = '2';
                if ($value != 9 && $value != 13) {
                    array_push($userActions, $allUserAction[$value]);
                }
            }
        }
        $project->user_actions = $userActions;
        return $project;
    }

    public function getStatusActionList()
    {
        $statusActionListArray = [];
        $record = StaticActionList::get();
        if (isset($record)) {
            foreach ($record as $value) {
                if (array_key_exists($value->status_id, $statusActionListArray)) {
                    array_push($statusActionListArray[$value->status_id], $value->user_action_id);
                } else {
                    if ($value->user_action_id) {
                        $statusActionListArray[$value->status_id] = [$value->user_action_id];
                    } else {
                        $statusActionListArray[$value->status_id] = [];
                    }
                }
            }
        }
        return $statusActionListArray;
    }

    public function getUserActionRoles()
    {
        $userActionRoleArray = [];
        $record = UserActionRole::get();
        if (isset($record)) {
            foreach ($record as $value) {
                if (array_key_exists($value->user_action_id, $userActionRoleArray)) {
                    array_push($userActionRoleArray[$value->user_action_id], $value->role_id);
                } else {
                    $userActionRoleArray[$value->user_action_id] = [$value->role_id];
                }
            }
        }
        return $userActionRoleArray;
    }

    public function getUserActionRecord()
    {
        $userActionArray = [];
        $record = UserAction::get();
        if (isset($record)) {
            foreach ($record as $value) {
                $userActionArray[$value->id] = $value;
            }
        }
        return $userActionArray;
    }
    /**
     *
     * @OA\Get(
     *     path="/v1/project/{project_id}",
     *     operationId="/v1/project/{project_id}",
     *     summary="Fetch specific project detail using project uuid",
     *     tags={"Project"},
     *     @OA\Parameter(
     *         name="project_id",
     *         in="path",
     *         description="Project UUID",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\Response(
     *         response="200",
     *         description="Returns Specific Project Detail",
     *         @OA\JsonContent()
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     *
     * @param $uuid
     * @return \Illuminate\Http\JsonResponse
     */


    public function show(Request $request, $uuid)
    {
        try {
            $directAllocationDepartment = [];
            $role = Helpers::getRole($request->user->id, $uuid);
            $project = Project::where('uuid', $uuid)
                ->with(['billingType', 'billingMediumData', 'technologies', 'accountManagers', 'projectManagers', 'initiatedBy', 'ResourceRequisition', 'projectDomains', 'projectType', 'governanceCategory', 'lifecycleModel'])
                ->firstOrFail();
            $project_name = $project['project_name'];
            $redmineProjectID = $project['redmine_project_id'];
            if ($redmineProjectID == null || $redmineProjectID == '') {
                $redmineProjectID = Helpers::projectIDRedmine($project_name);
            }
            $project_exist_redmine = false;
            if (isset($redmineProjectID)) {
                $project_exist_redmine = true;
            }
            $project->project_exist_redmine = $project_exist_redmine;
            if ((!empty($role['department']) && !empty($role['project'])) || (!empty($role['department']) && in_array($this->rolesArray[config('constant.ROLES.global_operation')], $role['global']))
            ) {
                $directAllocationDepartment = $role['department'];
            }
            if (in_array($this->rolesArray[config('constant.ROLES.admin')], $role['global'])) {
                $directAllocationDepartment = Department::pluck('id');
            }
            $project->direct_allocation_department = $directAllocationDepartment;
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $project);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }
    /**
     * Fetch user all projects with roles
     */
    public function userProjectRole(Request $request)
    {
        try {
            $projectRole = UserRole::where(['user_id' => $request->user->id])
                ->with(['userRole', 'project'])
                ->get();
            $userProjectRole = $this->formatUserProjectRole($projectRole);
            if (!empty($userProjectRole)) {
                $globalResponse = ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $userProjectRole, 'User Projects Role');
            } else {
                $globalResponse = ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), '', 'User Projects Role Not Found');
            }
            return $globalResponse;
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    /**
     * Format the user project role data
     */
    public function formatUserProjectRole($data)
    {
        $responseArray = [];
        $finalUserRoleData = [];
        $tempUserRole = [];
        if (isset($data[0])) {
            foreach ($data as $key => $value) {
                if (!array_key_exists($value->project_id, $finalUserRoleData)) {
                    $finalUserRoleData[$value->project_id] = $value;
                    $tempUserRole[$value->project_id] = [$value->userRole];
                    unset($finalUserRoleData[$value->project_id]->role_id);
                    unset($finalUserRoleData[$value->project_id]->userRole);
                } else {
                    array_push($tempUserRole[$value->project_id], $value->userRole);
                }
            }
            if (!empty($tempUserRole)) {
                foreach ($tempUserRole as $index => $record) {
                    $finalUserRoleData[$index]['user_role'] = $record;
                    array_push($responseArray, $finalUserRoleData[$index]);
                }
            }
        }
        return $responseArray;
    }

    public function projectInitiationRequestEdit(Request $request, $uuid)
    {
        $this->validate($request, self::$validationRules);
        $currentUserId = $request->user->id;
        $isApproved = config('constant.PROJECT_APPROVAL.approval_request');
        $request->status = config('constant.PROJECT_ACTION.initiation_request');
        $oldProjectManagers['projectManagers'] = [];
        $oldtechnologies['technologies'] = [];
        $oldAccountManagers['accountManagers'] = [];
        $oldprojectDomain['projectDomains'] = [];
        //bu_head or go_team
        try {
            $project = Project::with(['technologies', 'accountManagers', 'projectManagers', 'projectDomains', 'projectDomains', 'projectType', 'governanceCategory', 'lifecycleModel', 'billingMediumData'])
                ->where('uuid', $uuid)->first();
            foreach ($project['projectManagers'] as $projectManagers) {
                $oldProjectManagers['projectManagers'][] = $projectManagers->user->display_name;
            }
            foreach ($project['technologies'] as $tech) {
                $oldtechnologies['technologies'][] = $tech->name;
            }
            foreach ($project['accountManagers'] as $accountManager) {
                $oldAccountManagers['accountManagers'][] = $accountManager->user->display_name;
            }
            foreach ($project['projectDomains'] as $projectDomain) {
                $oldprojectDomain['projectDomains'][] = $projectDomain->name;
            }
            $identifier = Helpers::getIdentifier($project->project_name);
            $oldProjectArray = [
                'ProjectName' => $project->project_name,
                'BillingType' => $project->billing_type,
                'project_type_id' => $project->project_type_id,
                'gov_category_id' => $project->gov_category_id,
                'ProjectSummary' => $project->project_summary,
                'CompanyName' => $project->company_name,
                'CompanyAddress' => $project->company_address,
                'ApprovedHours' => $project->approved_hours,
                'MaximumHoursBilled' => $project->maximum_hours_billed,
                'EstimatedTimelineTo' => Carbon::parse($project->estimated_timeline_to)->format('Y-m-d'),
                'EstimatedTimelineFrom' => Carbon::parse($project->estimated_timeline_from)->format('Y-m-d'),
                'ClientDetail' => $project->client_detail,
                'ProjectComponents' => $project->project_components,
                'InitiationDate' => Carbon::parse($project->initiation_date)->format('Y-m-d'),
                'ProjectDocumentsLink' => $project->project_documents_link,
                'SpecificRequests' => $project->specific_requests,
                'UpdatedBy' => $project->updated_by,
                'Comment' => $project->comment,
                'parent_id' => $project->parent_id,
                'identifier' => $identifier,
                'lifecycle_model_id' => $project->lifecycle_model_id,
                'state' => $project->state,
                'country' => $project->country,
                'billing_interval' => $project->billing_interval,
                'billing_medium' => $project->billing_medium,
            ];
            $del_acc_manager = UserRole::where('project_id', $uuid)->where('role_id', $this->rolesArray[config('constant.ROLES.account_manager')])->delete();
            $del_proj_manager = UserRole::where('project_id', $uuid)->where('role_id', $this->rolesArray[config('constant.ROLES.project_manager')])->delete();
            $data = $this->UpdateRequestData($request, $isApproved);
            $project->update($data);
            $technologies = $request->get('technologies');
            $project->technologies()->sync($technologies);
            $project->projectDomains()->sync($request->get('project_domain'));
            $project->load('technologies', 'billingType', 'projectDomains', 'projectType', 'governanceCategory', 'billingMediumData');
            UserRole::saveProjectRole($project->uuid, $request->account_manager_id, $this->rolesArray[config('constant.ROLES.account_manager')]);
            UserRole::saveProjectRole($project->uuid, $request->project_manager_id, $this->rolesArray[config('constant.ROLES.project_manager')]);
            $newProject = Project::with(['technologies', 'accountManagers', 'projectManagers', 'projectDomains', 'projectDomains', 'projectType', 'governanceCategory', 'lifecycleModel', 'billingMediumData'])
                ->where('uuid', $uuid)->latest()->first();
            foreach ($newProject['projectManagers'] as $newProjectManager) {
                $newProjectManagers['projectManagers'][] = $newProjectManager->user->display_name;
            }
            foreach ($newProject['technologies'] as $tech) {
                $newtechnologies['technologies'][] = $tech->name;
            }
            foreach ($newProject['accountManagers'] as $accountManager) {
                $newAccountManagers['accountManagers'][] = $accountManager->user->display_name;
            }
            foreach ($newProject['projectDomains'] as $projectDomain) {
                $newprojectDomain['projectDomains'][] = $projectDomain->name;
            }
            $identifier = Helpers::getIdentifier($newProject->project_name);
            $newProjectArray = [
                'ProjectName' => $newProject->project_name,
                'BillingType' => $newProject->billing_type,
                'project_type_id' => $newProject->project_type_id,
                'gov_category_id' => $newProject->gov_category_id,
                'ProjectSummary' => $newProject->project_summary,
                'CompanyName' => $newProject->company_name,
                'CompanyAddress' => $newProject->company_address,
                'ApprovedHours' => $newProject->approved_hours,
                'MaximumHoursBilled' => $newProject->maximum_hours_billed,
                'EstimatedTimelineTo' => Carbon::parse($newProject->estimated_timeline_to)->format('Y-m-d'),
                'EstimatedTimelineFrom' => Carbon::parse($newProject->estimated_timeline_from)->format('Y-m-d'),
                'ClientDetail' => $newProject->client_detail,
                'ProjectComponents' => $newProject->project_components,
                'InitiationDate' => Carbon::parse($newProject->initiation_date)->format('Y-m-d'),
                'ProjectDocumentsLink' => $newProject->project_documents_link,
                'SpecificRequests' => $newProject->specific_requests,
                'UpdatedBy' => $newProject->updated_by,
                'Comment' => $newProject->comment,
                'parent_id' => $newProject->parent_id,
                'identifier' => $identifier,
                'lifecycle_model_id' => $newProject->lifecycle_model_id,
                'state' => $newProject->state,
                'country' => $newProject->country,
                'billing_interval' => $newProject->billing_interval,
                'billing_medium' => $newProject->billing_medium,
            ];
            $updateArrayDiff = array_merge(array_diff($newProjectArray, $oldProjectArray), array_diff($oldProjectArray, $newProjectArray));
            $selectedArray = [
                'Old_Project_Name' => 'Old Project Name',
                'New_Project_Name' => 'New Project Name',
                'Old_Billing_Type' => 'Old Billing Type',
                'New_Billing_Type' => 'New Billing Type',
                'Old_Project_Summary' => 'Old Project Summary',
                'New_Project_Summary' => 'New Project Summary',
                'Old_Company_Name' => 'Old Company Name',
                'New_Company_Name' => 'New Company Name',
                'Old_Company_Address' => 'Old Company Address',
                'New_Company_Address' => 'New Company Address',
                'Old_Approved_Hours' => 'Old Approved Hours',
                'New_Approved_Hours' => 'New Approved Hours',
                'Old_MaximumHours_Billed' => 'Old MaximumHours Billed',
                'New_MaximumHours_Billed' => 'New MaximumHours Billed',
                'Old_Client_Name' => 'Old Client Name',
                'New_Client_Name' => 'New Client Name',
                'Old_Client_Email' => 'Old Client Email',
                'New_Client_Email' => 'New Client Email',
                'Old_Project_Components' => 'Old Project Components',
                'New_Project_Components' => 'New Project Components',
                'Old_Project_Managers' => 'Old Project Managers',
                'New_Project_Managers' => 'New Project Managers',
                'Old_Account_Managers' => 'Old Account Managers',
                'New_Account_Managers' => 'New Account Managers',
                'Old_Technologies' => 'Old Technologies',
                'New_Technologies' => 'New Technologies',
                'Old_Project_Type' => 'Old Project Type',
                'New_Project_Type' => 'New Project Type',
                'Old_Governance_Category' => 'Old Governance Category',
                'New_Governance_Category' => 'New Governance Category',
                'Old_Comment' => 'Old Comment',
                'New_Comment' => 'New Comment',
                'Old_SubProject_Name' => 'Old SubProject Name',
                'New_SubProject_Name' => 'New SubProject Name',
                'Old_LifeCycle_Name' => 'Old LifeCycle Name',
                'New_LifeCycle_Name' => 'New LifeCycle Name',
                'Old_State_Name' => 'Old State Name',
                'New_State_Name' => 'New State Name',
                'Old_Country_Name' => 'Old Country Name',
                'New_Country_Name' => 'New Country Name',
                'Old_BillingInterval_Name' => 'Old BillingInterval Name',
                'New_BillingInterval_Name' => 'New BillingInterval Name',
            ];
            $updatedArray = Helpers::projectUpdateEmail(
                $updateArrayDiff,
                $newProjectArray,
                $oldProjectArray,
                $oldProjectManagers,
                $newProjectManagers,
                $oldAccountManagers,
                $newAccountManagers,
                $oldtechnologies,
                $newtechnologies
            );
            $mailArray = [config('constant.TEMPLATES.initiation_request_update')];
            $rmUpdatedArray = [];
            foreach ($updatedArray as $key => $value) {
                if (array_key_exists($key, $selectedArray)) {
                    $updatedKey = str_replace('_', ' ', $key);
                    $rmUpdatedArray[$updatedKey] = $value;
                }
            }
            foreach ($mailArray as $val) {
                $mailService = new MailService($val, $project->uuid, $rmUpdatedArray, [], [], $currentUserId);
                $mailService->sendMail();
            }
            Log::info($this->helpers->addToLog($uuid, $request, $project, config('constant.LOG_ACTIONS.initiation_request_edit')));
            $this->helpers->addlogActivityDB($uuid, $request, $project, config('constant.LOG_ACTIONS.initiation_request_edit'));
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $project);
        } catch (\Exception $e) {
            Log::error($this->helpers->addToLog($uuid, $request, $e->getMessage(), config('constant.LOG_ACTIONS.initiation_request_edit')));
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusUnauthorized'), '', $e->getMessage());
        }
    }

    public function projectInitiationApproval(Request $request, $uuid)
    {
        $this->validate($request, self::$validationRules);
        $currentUserId = $request->user->id;
        $oldProjectManagers['projectManagers'] = [];
        $oldtechnologies['technologies'] = [];
        $oldAccountManagers['accountManagers'] = [];
        $oldprojectDomain['projectDomains'] = [];
        if ($request->is_accept == true) {
            $isApproved = config('constant.PROJECT_APPROVAL.approved');
            $request->status =  config('constant.PROJECT_ACTION.initiation');
            $actionLog = config('constant.LOG_ACTIONS.initiation_approval');
            //mail will send to RM
        } else {
            $isApproved = config('constant.PROJECT_APPROVAL.edit_initiation_request');
            $request->status = config('constant.PROJECT_ACTION.initiation_request');
            $actionLog = config('constant.LOG_ACTIONS.initiation_decline');
            //mail will not send to RM
        }
        try {
            $project = Project::with(['technologies', 'accountManagers', 'projectManagers', 'projectDomains', 'projectDomains', 'projectType', 'governanceCategory', 'lifecycleModel'])
                ->where('uuid', $uuid)->first();
            foreach ($project['projectManagers'] as $projectManagers) {
                $oldProjectManagers['projectManagers'][] = $projectManagers->user->display_name;
            }
            foreach ($project['technologies'] as $tech) {
                $oldtechnologies['technologies'][] = $tech->name;
            }
            foreach ($project['accountManagers'] as $accountManager) {
                $oldAccountManagers['accountManagers'][] = $accountManager->user->display_name;
            }
            foreach ($project['projectDomains'] as $projectDomain) {
                $oldprojectDomain['projectDomains'][] = $projectDomain->name;
            }
            $oldProjectArray = [
                'ProjectName' => $project->project_name,
                'BillingType' => $project->billing_type,
                'project_type_id' => $project->project_type_id,
                'gov_category_id' => $project->gov_category_id,
                'ProjectSummary' => $project->project_summary,
                'CompanyName' => $project->company_name,
                'CompanyAddress' => $project->company_address,
                'ApprovedHours' => $project->approved_hours,
                'MaximumHoursBilled' => $project->maximum_hours_billed,
                'EstimatedTimelineTo' => Carbon::parse($project->estimated_timeline_to)->format('Y-m-d'),
                'EstimatedTimelineFrom' => Carbon::parse($project->estimated_timeline_from)->format('Y-m-d'),
                'ClientDetail' => $project->client_detail,
                'ProjectComponents' => $project->project_components,
                'InitiationDate' => Carbon::parse($project->initiation_date)->format('Y-m-d'),
                'ProjectDocumentsLink' => $project->project_documents_link,
                'SpecificRequests' => $project->specific_requests,
                'UpdatedBy' => $project->updated_by,
                'Comment' => $project->comment,
                'parent_id' => $project->parent_id,
                'identifier' => Helpers::getIdentifier($project->project_name),
                'lifecycle_model_id' => $project->lifecycle_model_id,
                'state' => $project->state,
                'country' => $project->country,
                'billing_interval' => $project->billing_interval,
            ];
            $del_acc_manager = UserRole::where('project_id', $uuid)->where('role_id', $this->rolesArray[config('constant.ROLES.account_manager')])->delete();
            $del_proj_manager = UserRole::where('project_id', $uuid)->where('role_id', $this->rolesArray[config('constant.ROLES.project_manager')])->delete();
            $data = $this->UpdateRequestData($request, $isApproved);
            $project->update($data);
            $technologies = $request->get('technologies');
            $project->technologies()->sync($technologies);
            $project->projectDomains()->sync($request->get('project_domain'));
            $project->load('technologies', 'billingType', 'projectDomains', 'projectType', 'governanceCategory', 'lifecycleModel');
            UserRole::saveProjectRole($project->uuid, $request->account_manager_id, $this->rolesArray[config('constant.ROLES.account_manager')]);
            UserRole::saveProjectRole($project->uuid, $request->project_manager_id, $this->rolesArray[config('constant.ROLES.project_manager')]);
            $newProject = Project::with(['technologies', 'accountManagers', 'projectManagers', 'projectDomains', 'projectDomains', 'projectType', 'governanceCategory', 'lifecycleModel'])
                ->where('uuid', $uuid)->latest()->first();
            foreach ($newProject['projectManagers'] as $newProjectManager) {
                $newProjectManagers['projectManagers'][] = $newProjectManager->user->display_name;
            }
            foreach ($newProject['technologies'] as $tech) {
                $newtechnologies['technologies'][] = $tech->name;
            }
            foreach ($newProject['accountManagers'] as $accountManager) {
                $newAccountManagers['accountManagers'][] = $accountManager->user->display_name;
            }
            foreach ($newProject['projectDomains'] as $projectDomain) {
                $newprojectDomain['projectDomains'][] = $projectDomain->name;
            }
            $newProjectArray = [
                'ProjectName' => $newProject->project_name,
                'BillingType' => $newProject->billing_type,
                'project_type_id' => $newProject->project_type_id,
                'gov_category_id' => $newProject->gov_category_id,
                'ProjectSummary' => $newProject->project_summary,
                'CompanyName' => $newProject->company_name,
                'CompanyAddress' => $newProject->company_address,
                'ApprovedHours' => $newProject->approved_hours,
                'MaximumHoursBilled' => $newProject->maximum_hours_billed,
                'EstimatedTimelineTo' => Carbon::parse($newProject->estimated_timeline_to)->format('Y-m-d'),
                'EstimatedTimelineFrom' => Carbon::parse($newProject->estimated_timeline_from)->format('Y-m-d'),
                'ClientDetail' => $newProject->client_detail,
                'ProjectComponents' => $newProject->project_components,
                'InitiationDate' => Carbon::parse($newProject->initiation_date)->format('Y-m-d'),
                'ProjectDocumentsLink' => $newProject->project_documents_link,
                'SpecificRequests' => $newProject->specific_requests,
                'UpdatedBy' => $newProject->updated_by,
                'Comment' => $newProject->comment,
                'parent_id' => $newProject->parent_id,
                'identifier' => Helpers::getIdentifier($newProject->project_name),
                'lifecycle_model_id' => $newProject->lifecycle_model_id,
                'state' => $newProject->state,
                'country' => $newProject->country,
                'billing_interval' => $newProject->billing_interval,
            ];
            $updateArrayDiff = array_merge(array_diff($newProjectArray, $oldProjectArray), array_diff($oldProjectArray, $newProjectArray));
            $selectedArray = [
                'Old_Project_Name' => 'Old Project Name',
                'New_Project_Name' => 'New Project Name',
                'Old_Billing_Type' => 'Old Billing Type',
                'New_Billing_Type' => 'New Billing Type',
                'Old_Project_Summary' => 'Old Project Summary',
                'New_Project_Summary' => 'New Project Summary',
                'Old_Company_Name' => 'Old Company Name',
                'New_Company_Name' => 'New Company Name',
                'Old_Company_Address' => 'Old Company Address',
                'New_Company_Address' => 'New Company Address',
                'Old_Approved_Hours' => 'Old Approved Hours',
                'New_Approved_Hours' => 'New Approved Hours',
                'Old_MaximumHours_Billed' => 'Old MaximumHours Billed',
                'New_MaximumHours_Billed' => 'New MaximumHours Billed',
                'Old_Client_Name' => 'Old Client Name',
                'New_Client_Name' => 'New Client Name',
                'Old_Client_Email' => 'Old Client Email',
                'New_Client_Email' => 'New Client Email',
                'Old_Project_Components' => 'Old Project Components',
                'New_Project_Components' => 'New Project Components',
                'Old_Project_Managers' => 'Old Project Managers',
                'New_Project_Managers' => 'New Project Managers',
                'Old_Account_Managers' => 'Old Account Managers',
                'New_Account_Managers' => 'New Account Managers',
                'Old_Technologies' => 'Old Technologies',
                'New_Technologies' => 'New Technologies',
                'Old_Project_Type' => 'Old Project Type',
                'New_Project_Type' => 'New Project Type',
                'Old_Governance_Category' => 'Old Governance Category',
                'New_Governance_Category' => 'New Governance Category',
                'Old_Comment' => 'Old Comment',
                'New_Comment' => 'New Comment',
                'Old_SubProject_Name' => 'Old SubProject Name',
                'New_SubProject_Name' => 'New SubProject Name',
                'Old_LifeCycle_Name' => 'Old LifeCycle Name',
                'New_LifeCycle_Name' => 'New LifeCycle Name',
                'Old_State_Name' => 'Old State Name',
                'New_State_Name' => 'New State Name',
                'Old_Country_Name' => 'Old Country Name',
                'New_Country_Name' => 'New Country Name',
                'Old_BillingInterval_Name' => 'Old BillingInterval Name',
                'New_BillingInterval_Name' => 'New BillingInterval Name',
            ];
            $updatedArray = Helpers::projectUpdateEmail(
                $updateArrayDiff,
                $newProjectArray,
                $oldProjectArray,
                $oldProjectManagers,
                $newProjectManagers,
                $oldAccountManagers,
                $newAccountManagers,
                $oldtechnologies,
                $newtechnologies
            );
            $mailArray = [];
            if ($isApproved == config('constant.PROJECT_APPROVAL.approved')) {
                // $mailArray = [config('constant.TEMPLATES.initiation'), config('constant.TEMPLATES.initiation_approval')];
                $mailArray = [config('constant.TEMPLATES.initiation_approval')];
                //show project initiation request is approve by go_head and mail with updated data in initiation_approval template
            }
            if ($isApproved == config('constant.PROJECT_APPROVAL.edit_initiation_request')) {
                //show project initiation request is decline by go_head  and mail with updated data in initiation_approval template
                array_push($mailArray, config('constant.TEMPLATES.initiation_decline'));
            }
            $rmUpdatedArray = [];
            foreach ($updatedArray as $key => $value) {
                if (array_key_exists($key, $selectedArray)) {
                    $updatedKey = str_replace('_', ' ', $key);
                    $rmUpdatedArray[$updatedKey] = $value;
                }
            }
            foreach ($mailArray as $val) {
                if ($val == 'initiation_approval' || $val == 'initiation_decline') {
                    $mailService = new MailService($val, $project->uuid, $rmUpdatedArray, [], [], $project->created_by);
                } else {
                    $mailService = new MailService($val, $project->uuid);
                }
                $mailService->sendMail();
                //send mail of comments only to person who has created / or all GO and BU heads
            }

            if ($request->is_accept == true) {
                $actionLogInitiation = config('constant.LOG_ACTIONS.initiation_project');
                Log::info($this->helpers->addToLog($uuid, $request, $project, $actionLogInitiation));
                $this->helpers->addlogActivityDB($uuid, $request, $project, $actionLogInitiation);
            }

            Log::info($this->helpers->addToLog($uuid, $request, $project, $actionLog));
            $this->helpers->addlogActivityDB($uuid, $request, $project, $actionLog);
            
            if ($request->is_accept == true) {
            $request['project_id'] = $project->uuid;
                $status = 1;
                $this->projectCreation($request, $status);
            }

            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $project);
        } catch (\Exception $e) {
            Log::error($this->helpers->addToLog($uuid, $request, $e->getMessage(), $actionLog));
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusUnauthorized'), '', $e->getMessage());
        }
    }

    /**
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     * @throws \Illuminate\Validation\ValidationException
     */

    /**
     * @OA\Post(
     *     path="/v1/project",
     *     summary="Project Initiation",
     *     operationId="/v1/project",
     *     tags={"Project"},
     *     @OA\RequestBody(
     *         required=true,
     *         description="Post object",
     *         @OA\JsonContent(ref="#/components/schemas/ProjectInitiation")
     *     ),
     *     @OA\Response(
     *         response=201,
     *         description="A post",
     *         @OA\JsonContent(),
     *     ),
     *     @OA\Response(
     *         response="default",
     *         description="unexpected error",
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     *
     * @param Request $request
     * @return array
     */
    public function store(Request $request)
    {
        $this->validate($request, self::$initiationValidationRules);
        $currentUserId = $request->user->id;
        $projectId = $request->project_id;
        $userRole = Helpers::getRole($currentUserId);
        if (
            in_array($this->rolesArray[config('constant.ROLES.admin')], $userRole['global']) ||
            in_array($this->rolesArray[config('constant.ROLES.global_operation')], $userRole['global']) ||
            in_array($this->rolesArray[config('constant.ROLES.sales')], $userRole['global'])
        ) {
            $isApprove = null;
            $request->status = config('constant.PROJECT_ACTION.initiation');
            $actionLog = config('constant.LOG_ACTIONS.initiation_project');
        } else {
            $isApprove = config('constant.PROJECT_APPROVAL.approval_request');
            $request->status = config('constant.PROJECT_ACTION.initiation_request');
            $actionLog = config('constant.LOG_ACTIONS.initiation_request');
        }
        try {
            $project = $this->createProject($request, $isApprove, $projectId, 0);
            if ($project->status == config('constant.PROJECT_ACTION.initiation')) {
                PerformedActionLog::storePerformedActionLog($project->uuid, 1, config('constant.PERFORM_ACTIONLOG.inProgress'));
                //for email
                $mailArray = [config('constant.TEMPLATES.initiation')];
            } else {
                $mailArray = [config('constant.TEMPLATES.initiation_request')];
            }
            foreach ($mailArray as $val) {
                $mailService = new MailService($val, $project->uuid, [], [], [], $currentUserId);
                $mailService->sendMail();
            }
            $this->helpers->addlogActivityDB($project->uuid, $request, $project, $actionLog);
            Log::info($this->helpers->addToLog($project->uuid, $request, $project, $actionLog));
            if (
                in_array($this->rolesArray[config('constant.ROLES.admin')], $userRole['global']) ||
                in_array($this->rolesArray[config('constant.ROLES.global_operation')], $userRole['global']) ||
                in_array($this->rolesArray[config('constant.ROLES.sales')], $userRole['global'])
            ) {
                $request['project_id'] = $project->uuid;
                $status = 1;
                $this->projectCreation($request, $status);
            }
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusCreated'), $project);
        } catch (\Exception $e) {
            Log::error($this->helpers->addToLog($project->uuid, $request, $e->getMessage(), $actionLog));
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function storeDraft(Request $request)
    {
        $this->validate($request, self::$initiationDraftValidationRules);
        $currentUserId = $request->user->id;
        $projectId = $request->project_id;
        $userRole = Helpers::getRole($currentUserId);

        if (
            in_array($this->rolesArray[config('constant.ROLES.admin')], $userRole['global']) ||
            in_array($this->rolesArray[config('constant.ROLES.global_operation')], $userRole['global']) ||
            in_array($this->rolesArray[config('constant.ROLES.sales')], $userRole['global'])
        ) {
            $isApprove = null;
            $request->status = config('constant.PROJECT_ACTION.initiation');
            $actionLog = config('constant.LOG_ACTIONS.initiation_project');
        } else {
            $isApprove = config('constant.PROJECT_APPROVAL.approval_request');
            $request->status = config('constant.PROJECT_ACTION.initiation_request');
            $actionLog = config('constant.LOG_ACTIONS.initiation_request');
        }
        try {
            $project = $this->createProject($request, $isApprove, $projectId, 1);
            $actionLog = config('constant.PROJECT_ACTION.initiation_project_draft');
            Log::info($this->helpers->addToLog($project->uuid, $request, $project, $actionLog));
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusCreated'), $project);
        } catch (\Exception $e) {
            Log::error($this->helpers->addToLog($project->uuid, $request, $e->getMessage(), $actionLog));
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function createProject($request, $isApprove = null, $projectId, $draft)
    {
        if ($request->estimated_timeline_to == '') {
            $request->estimated_timeline_to = null;
        }
        if ($request->estimated_timeline_from == '') {
            $request->estimated_timeline_from = null;
        }
        $identifier = Helpers::getIdentifier($request->project_name);
        $data = [
            'project_name' => $request->project_name,
            'company_name' => $request->company_name,
            'company_address' => $request->company_address,
            'parent_id' => $request->parent_id,
            'identifier' => $identifier,
            'lifecycle_model_id' => $request->lifecycle_model_id,
            'state' => $request->state,
            'country' => $request->country,
            'billing_interval' => $request->billing_interval,
            'client_detail' => $request->client_detail,
            'billing_type' => $request->billing_type,
            'approved_hours' => $request->approved_hours,
            'maximum_hours_billed' => $request->maximum_hours_billed,
            'project_components' => $request->project_components,
            'initiation_date' => date("Y-m-d"),
            'status' => $request->status,
            'project_documents_link' => $request->project_documents_link,
            'specific_requests' => $request->specific_requests,
            'project_summary' => $request->project_summary,
            'created_by' => $request->user->id,
            'estimated_timeline_to' => $request->estimated_timeline_to,
            'estimated_timeline_from' => $request->estimated_timeline_from,
            'project_type_id' => $request->project_type_id,
            'gov_category_id' => $request->gov_category_id,
            'is_approve' => $isApprove,
            'comment' => isset($request->comment) ? $request->comment : null,
            'is_draft' => $draft,
            'billing_medium' => $request->billing_medium,
        ];
        if ($projectId == null) {
            $project = new Project($data);
            $project->save();
        } else {
            $project = Project::where('uuid', $projectId)->first();
            $del_acc_manager = UserRole::where('project_id', $projectId)->where('role_id', $this->rolesArray[config('constant.ROLES.account_manager')])->delete();
            $del_proj_manager = UserRole::where('project_id', $projectId)->where('role_id', $this->rolesArray[config('constant.ROLES.project_manager')])->delete();
            $project->update($data);
        }
        if (isset($request->technologies)) {
            $technologies = $request->get('technologies');
            $project->technologies()->sync($technologies);
        }
        if (isset($request->project_domain)) {
            $project->projectDomains()->sync($request->get('project_domain'));
        }
        UserRole::saveProjectRole($project->uuid, $request->account_manager_id, $this->rolesArray[config('constant.ROLES.account_manager')]);
        UserRole::saveProjectRole($project->uuid, $request->project_manager_id, $this->rolesArray[config('constant.ROLES.project_manager')]);
        $project->load('technologies', 'billingType', 'projectDomains', 'projectType', 'governanceCategory', 'accountManagers', 'projectManagers', 'lifecycleModel');
        return $project;
    }

    public function UpdateRequestData($request, $isApprove = null)
    {
        if ($request->estimated_timeline_to == '') {
            $request->estimated_timeline_to = null;
        }
        if ($request->estimated_timeline_from == '') {
            $request->estimated_timeline_from = null;
        }
        if ($request->project_type_id == '') {
            $request->project_type_id = null;
        }
        if ($request->gov_category_id == '') {
            $request->gov_category_id = null;
        }
        $data = [
            'project_name' => $request->project_name,
            'billing_type' => $request->billing_type,
            'project_type_id' => $request->project_type_id,
            'state' => $request->state,
            'country' => $request->country,
            'billing_interval' => $request->billing_interval,
            'gov_category_id' => $request->gov_category_id,
            'project_summary' => $request->project_summary,
            'company_name' => $request->company_name,
            'company_address' => $request->company_address,
            'approved_hours' => $request->approved_hours,
            'maximum_hours_billed' => $request->maximum_hours_billed,
            'estimated_timeline_to' => $request->estimated_timeline_to,
            'estimated_timeline_from' => $request->estimated_timeline_from,
            'client_detail' => $request->client_detail,
            'project_components' => $request->project_components,
            'initiation_date' => $request->initiation_date,
            'project_documents_link' => $request->project_documents_link,
            'specific_requests' => $request->specific_requests,
            'status' => $request->status,
            'updated_by' => $request->user->id,
            'is_approve' => $isApprove,
            'comment' => $request->comment,
            'parent_id' => $request->parent_id,
            'identifier' => Helpers::getIdentifier($request->project_name),
            'lifecycle_model_id' => $request->lifecycle_model_id,
            'billing_medium' => $request->billing_medium,
        ];
        return $data;
    }

    /**
     * @OA\Put(
     *     path="/v1/project/{uuid}",
     *     summary="Project Update",
     *     operationId="/v1/project/{uuid}",
     *     tags={"Project"},
     *     @OA\Parameter(
     *         name="uuid",
     *         in="path",
     *         description="Project UUID",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\RequestBody(
     *         required=true,
     *         description="Post object",
     *         @OA\JsonContent(ref="#/components/schemas/ProjectUpdate")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="A post",
     *         @OA\JsonContent(),
     *     ),
     *     @OA\Response(
     *         response="default",
     *         description="unexpected error",
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     *
     * @param Request $request
     * @param $uuid
     * @return \Illuminate\Http\JsonResponse
     * @throws \Illuminate\Validation\ValidationException
     */
    public function update(Request $request, $uuid)
    {
        $this->validate($request, self::$validationRules);
        if ($request->estimated_timeline_to == '') {
            $request->estimated_timeline_to = null;
        }
        if ($request->estimated_timeline_from == '') {
            $request->estimated_timeline_from = null;
        }
        $oldProjectManagers['projectManagers'] = [];
        $oldtechnologies['technologies'] = [];
        $oldAccountManagers['accountManagers'] = [];
        $oldprojectDomain['projectDomains'] = [];
        $oldProjectManagersID = [];
        $oldAccountManagersID = [];
        $project = Project::with(['technologies', 'accountManagers', 'projectManagers', 'projectDomains', 'projectDomains', 'projectType', 'governanceCategory', 'lifecycleModel', 'billingMediumData'])
            ->where('uuid', $uuid)->first();
        foreach ($project['projectManagers'] as $projectManagers) {
            $oldProjectManagers['projectManagers'][] = $projectManagers->user->display_name;
            array_push($oldProjectManagersID, $projectManagers->user->id);
        }
        foreach ($project['technologies'] as $tech) {
            $oldtechnologies['technologies'][] = $tech->name;
        }
        foreach ($project['accountManagers'] as $accountManager) {
            $oldAccountManagers['accountManagers'][] = $accountManager->user->display_name;
            array_push($oldAccountManagersID, $accountManager->user->id);
        }
        foreach ($project['projectDomains'] as $projectDomain) {
            $oldprojectDomain['projectDomains'][] = $projectDomain->name;
        }
        $oldProjectArray = [
            'ProjectName' => $project->project_name,
            'parent_id' => $project->parent_id,
            'lifecycle_model_id' => $project->lifecycle_model_id,
            'BillingType' => $project->billing_type,
            'project_type_id' => $project->project_type_id,
            'gov_category_id' => $project->gov_category_id,
            'ProjectSummary' => $project->project_summary,
            'CompanyName' => $project->company_name,
            'CompanyAddress' => $project->company_address,
            'state' => $project->state,
            'country' => $project->country,
            'billing_interval' => $project->billing_interval,
            'ApprovedHours' => $project->approved_hours,
            'MaximumHoursBilled' => $project->maximum_hours_billed,
            'EstimatedTimelineTo' => Carbon::parse($project->estimated_timeline_to)->format('Y-m-d'),
            'EstimatedTimelineFrom' => Carbon::parse($project->estimated_timeline_from)->format('Y-m-d'),
            'ClientDetail' => $project->client_detail,
            'ProjectComponents' => $project->project_components,
            'InitiationDate' => Carbon::parse($project->initiation_date)->format('Y-m-d'),
            'ProjectDocumentsLink' => $project->project_documents_link,
            'SpecificRequests' => $project->specific_requests,
            'UpdatedBy' => $project->updated_by,
            'billing_medium' => $project->billing_medium,
        ];
        $del_acc_manager = UserRole::where('project_id', $uuid)->where('role_id', $this->rolesArray[config('constant.ROLES.account_manager')])->delete();
        $del_proj_manager = UserRole::where('project_id', $uuid)->where('role_id', $this->rolesArray[config('constant.ROLES.project_manager')])->delete();
        $data = $this->UpdateRequestData($request);
        try {
            $project->update($data);
            $technologies = $request->get('technologies');
            $project->technologies()->sync($technologies);
            $project->projectDomains()->sync($request->get('project_domain'));
            $project->load('technologies', 'billingType', 'projectDomains', 'projectType', 'governanceCategory', 'lifecycleModel', 'billingMediumData');
            UserRole::saveProjectRole($project->uuid, $request->account_manager_id, $this->rolesArray[config('constant.ROLES.account_manager')]);
            UserRole::saveProjectRole($project->uuid, $request->project_manager_id, $this->rolesArray[config('constant.ROLES.project_manager')]);
            $newProject = Project::with(['technologies', 'accountManagers', 'projectManagers', 'projectDomains', 'projectType', 'governanceCategory', 'lifecycleModel', 'billingMediumData'])
                ->where('uuid', $uuid)->latest()->first();
            if ($newProject['redmine_project_id'] != null) {
                $billingTypeName = Helpers::getBillTypeName($newProject['billing_type']);
                $billingIDRedmine = Helpers::billingIDRedmine($billingTypeName);
                $pmoProjectName = Helpers::getProjectName($newProject['parent_id']);
                $redmineProjectID = Helpers::projectIDRedmine($pmoProjectName);
                $clientBillable = 1;
                if ($billingIDRedmine == 7) {
                    $clientBillable = 0;
                }
                $techArray = [];
                foreach ($newProject['technologies'] as $techVal) {
                    array_push($techArray, $techVal['name']);
                }
                $technologyString = implode(",", $techArray);
                $dataPut = json_encode([
                    'project' =>
                    [
                        'name' => $newProject['project_name'],
                        'identifier' => $newProject['identifier'],
                        'description' => $newProject['project_summary'],
                        'homepage' => '',
                        'status' => config('constant.REDMINE_PROJECTSTATUS.activeProject'),
                        'is_public' => false,
                        'parent_id' => $redmineProjectID,
                        'inherit_members' => false,
                        'custom_fields' =>
                        [
                            0 =>
                            [
                                'id' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.Technology_Stack_ID'),
                                'name' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.Technology_Stack'),
                                'value' => isset($technologyString) ? $technologyString : '',
                            ],
                            1 =>
                            [
                                'id' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.Client_Billable_ID'),
                                'name' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.Client_Billable'),
                                'value' => $clientBillable,
                            ],
                            2 =>
                            [
                                'id' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.Infrastructure_Details_ID'),
                                'name' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.Infrastructure_Details'),
                                'value' => '',
                            ],
                            3 =>
                            [
                                'id' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.Contract_Type_ID'),
                                'name' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.Contract_Type'),
                                'value' => isset($billingIDRedmine) ? $billingIDRedmine : '',
                            ],
                            4 =>
                            [
                                'id' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.ProjectEndDate_ID'),
                                'name' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.ProjectEndDate'),
                                'value' => isset($newProject['estimated_timeline_to']) ? $newProject['estimated_timeline_to'] : '',
                            ],
                            5 =>
                            [
                                'id' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.ProjectStartDate_ID'),
                                'name' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.ProjectStartDate'),
                                'value' => isset($newProject['estimated_timeline_from']) ? $newProject['estimated_timeline_from'] : '',
                            ],
                            6 =>
                            [
                                'id' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.RevisedEndDate_ID'),
                                'name' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.RevisedEndDate'),
                                'value' => '',
                            ],
                            7 =>
                            [
                                'id' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.Estimated_Hrs_ID'),
                                'name' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.Estimated_Hrs'),
                                'value' => isset($newProject['approved_hours']) ? $newProject['approved_hours'] : $newProject['maximum_hours_billed'],
                            ],
                            8 =>
                            [
                                'id' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.Lifecycle_Model_ID'),
                                'name' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.Lifecycle_Model'),
                                'value' => isset($newProject['lifecycleModel']['name']) ? $newProject['lifecycleModel']['name'] : '',
                            ],
                            9 =>
                            [
                                'id' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.Project_Type_ID'),
                                'name' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.Project_Type'),
                                'value' => isset($newProject['projectType']['name']) ? $newProject['projectType']['name'] : '',
                            ],
                            10 =>
                            [
                                'id' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.Governance_Category_ID'),
                                'name' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.Governance_Category'),
                                'value' => isset($newProject['governanceCategory']['name']) ? $newProject['governanceCategory']['name'] : '',
                            ],
                            11 =>
                            [
                                'id' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.Billing_Medium_ID'),
                                'name' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.Billing_Medium'),
                                'value' => isset($newProject['billing_medium']) ? $newProject['billing_medium'] : '',
                            ],
                        ],
                    ],
                ]);
                $result = Helpers::callAPI('PUT', '/projects/' . $newProject['redmine_project_id'] . '.json', $dataPut);
                $apiRedmineResponse = json_decode($result, true);
                $statusCode = http_response_code();
                if (isset($statusCode) == 200) {
                    $pmIDs = [];
                    $amIDs = [];
                    if (isset($newProject['accountManagers'])) {
                        foreach ($newProject['accountManagers'] as $acckey => $accval) {
                            array_push($amIDs, $accval['user_id']);
                        }
                    }
                    if (isset($newProject['projectManagers'])) {
                        foreach ($newProject['projectManagers'] as $prokey => $proval) {
                            array_push($pmIDs, $proval['user_id']);
                        }
                    }
                    $resultProjectMembers = Helpers::callAPIGET('/projects/' . $newProject['redmine_project_id'] . '/memberships.json');
                    $membershipDataInner = json_decode($resultProjectMembers, true);
                    $array = [];
                    foreach ($membershipDataInner['memberships'] as $key => $val) {
                        if (isset($val['user']['id'])) {
                            if (in_array($val['user']['id'], $oldAccountManagersID)) {
                                $result = Helpers::callAPI('DELETE', '/memberships/' . $val['id'] . '.json', $data = []);
                                Log::info(['Project_Membership_AM_Delete_API_CRON', json_encode($result), json_encode($val['id'])]);
                            }
                            if (in_array($val['user']['id'], $oldProjectManagersID)) {
                                $result = Helpers::callAPI('DELETE', '/memberships/' . $val['id'] . '.json', $data = []);
                                Log::info(['Project_Membership_PM_Delete_API_CRON', json_encode($result), json_encode($val['id'])]);
                            }
                        }
                    }
                    $commanID = array_intersect($amIDs, $pmIDs);
                    $newAMArray = array_diff($amIDs, $commanID);
                    $newPMArray = array_diff($pmIDs, $commanID);
                    if (count($newAMArray) > 0) {
                        foreach ($newAMArray as $key => $amVal) {
                            $dataMemberACC = json_encode([
                                'membership' =>
                                [
                                    'user_id' => $amVal,
                                    'role_ids' =>
                                    [
                                        0 => 3,
                                    ],
                                ],
                            ]);
                            $resultAm = Helpers::callAPI('POST', '/projects/' . $newProject['redmine_project_id'] . '/memberships.json', $dataMemberACC);
                            Log::info(['Project_POST_Membership_AM_API', $resultAm, $dataMemberACC]);
                        }
                    }

                    if (count($newPMArray) > 0) {
                        foreach ($newPMArray as $key => $pmVal) {
                            $dataMemberPRO = json_encode([
                                'membership' =>
                                [
                                    'user_id' => $pmVal,
                                    'role_ids' =>
                                    [
                                        0 => 15,
                                    ],
                                ],
                            ]);
                            $resultpm = Helpers::callAPI('POST', '/projects/' . $newProject['redmine_project_id'] . '/memberships.json', $dataMemberPRO);
                            Log::info(['Project_POST_Membership_PM_API', $resultpm, $dataMemberPRO]);
                        }
                    }

                    if (count($commanID) > 0) {
                        $rolesCommon = [3, 15];
                        foreach ($commanID as $key => $ampmVal) {
                            $dataMemberAM_PM = json_encode([
                                'membership' =>
                                [
                                    'user_id' => $ampmVal,
                                    'role_ids' =>
                                    $rolesCommon,
                                ],
                            ]);
                            $resultcm = Helpers::callAPI('POST', '/projects/' . $newProject['redmine_project_id'] . '/memberships.json', $dataMemberAM_PM);
                            Log::info(['Project_POST_Membership_AM_PM_API', $resultcm, $dataMemberAM_PM]);
                        }
                    }
                }
            }

            foreach ($newProject['projectManagers'] as $newProjectManager) {
                $newProjectManagers['projectManagers'][] = $newProjectManager->user->display_name;
            }
            foreach ($newProject['technologies'] as $tech) {
                $newtechnologies['technologies'][] = $tech->name;
            }
            foreach ($newProject['accountManagers'] as $accountManager) {
                $newAccountManagers['accountManagers'][] = $accountManager->user->display_name;
            }
            foreach ($newProject['projectDomains'] as $projectDomain) {
                $newprojectDomain['projectDomains'][] = $projectDomain->name;
            }
            $newProjectArray = [
                'ProjectName' => $newProject->project_name,
                'parent_id' => $newProject->parent_id,
                'lifecycle_model_id' => $newProject->lifecycle_model_id,
                'ProjectName' => $newProject->project_name,
                'BillingType' => $newProject->billing_type,
                'project_type_id' => $newProject->project_type_id,
                'gov_category_id' => $newProject->gov_category_id,
                'ProjectSummary' => $newProject->project_summary,
                'CompanyName' => $newProject->company_name,
                'CompanyAddress' => $newProject->company_address,
                'state' => $newProject->state,
                'country' => $newProject->country,
                'billing_interval' => $newProject->billing_interval,
                'ApprovedHours' => $newProject->approved_hours,
                'MaximumHoursBilled' => $newProject->maximum_hours_billed,
                'EstimatedTimelineTo' => Carbon::parse($newProject->estimated_timeline_to)->format('Y-m-d'),
                'EstimatedTimelineFrom' => Carbon::parse($newProject->estimated_timeline_from)->format('Y-m-d'),
                'ClientDetail' => $newProject->client_detail,
                'ProjectComponents' => $newProject->project_components,
                'InitiationDate' => Carbon::parse($newProject->initiation_date)->format('Y-m-d'),
                'ProjectDocumentsLink' => $newProject->project_documents_link,
                'SpecificRequests' => $newProject->specific_requests,
                'UpdatedBy' => $newProject->updated_by,
                'billing_medium' => $newProject->billing_medium,
            ];
            $updateArrayDiff = array_merge(array_diff($newProjectArray, $oldProjectArray), array_diff($oldProjectArray, $newProjectArray));
            $selectedArray = [
                'Old_Project_Name' => 'Old Project Name',
                'New_Project_Name' => 'New Project Name',
                'Old_SubProject_Name' => 'Old SubProject Name',
                'New_SubProject_Name' => 'New SubProject Name',
                'Old_LifeCycle_Name' => 'Old LifeCycle Name',
                'New_LifeCycle_Name' => 'New LifeCycle Name',
                'Old_Billing_Type' => 'Old Billing Type',
                'New_Billing_Type' => 'New Billing Type',
                'Old_Project_Summary' => 'Old Project Summary',
                'New_Project_Summary' => 'New Project Summary',
                'Old_Company_Name' => 'Old Company Name',
                'New_Company_Name' => 'New Company Name',
                'Old_Company_Address' => 'Old Company Address',
                'New_Company_Address' => 'New Company Address',
                'Old_State_Name' => 'Old State Name',
                'New_State_Name' => 'New State Name',
                'Old_Country_Name' => 'Old Country Name',
                'New_Country_Name' => 'New Country Name',
                'Old_BillingInterval_Name' => 'Old BillingInterval Name',
                'New_BillingInterval_Name' => 'New BillingInterval Name',
                'Old_Approved_Hours' => 'Old Approved Hours',
                'New_Approved_Hours' => 'New Approved Hours',
                'Old_MaximumHours_Billed' => 'Old MaximumHours Billed',
                'New_MaximumHours_Billed' => 'New MaximumHours Billed',
                'Old_Client_Name' => 'Old Client Name',
                'New_Client_Name' => 'New Client Name',
                'Old_Client_Email' => 'Old Client Email',
                'New_Client_Email' => 'New Client Email',
                'Old_Project_Components' => 'Old Project Components',
                'New_Project_Components' => 'New Project Components',
                'Old_Project_Managers' => 'Old Project Managers',
                'New_Project_Managers' => 'New Project Managers',
                'Old_Account_Managers' => 'Old Account Managers',
                'New_Account_Managers' => 'New Account Managers',
                'Old_Technologies' => 'Old Technologies',
                'New_Technologies' => 'New Technologies',
                'Old_Project_Type' => 'Old Project Type',
                'New_Project_Type' => 'New Project Type',
                'Old_Governance_Category' => 'Old Governance Category',
                'New_Governance_Category' => 'New Governance Category',
                'Old_Billing_Medium' => 'Old Billing Medium',
                'New_Billing_Medium' => 'New Billing Medium',
            ];
            $updatedArray = Helpers::projectUpdateEmail(
                $updateArrayDiff,
                $newProjectArray,
                $oldProjectArray,
                $oldProjectManagers,
                $newProjectManagers,
                $oldAccountManagers,
                $newAccountManagers,
                $oldtechnologies,
                $newtechnologies
            );
            //for email
            $mailArray = [config('constant.TEMPLATES.project_detail_updation')];
            $rmUpdatedArray = [];
            foreach ($updatedArray as $key => $value) {
                if (array_key_exists($key, $selectedArray)) {
                    $updatedKey = str_replace('_', ' ', $key);
                    $rmUpdatedArray[$updatedKey] = $value;
                }
            }
            if (!empty($rmUpdatedArray['New Billing Type'])) {
                if ($rmUpdatedArray['New Billing Type'] == 'Fixed Cost') {
                    unset($rmUpdatedArray['Old MaximumHours Billed']);
                    unset($rmUpdatedArray['New MaximumHours Billed']);
                } else {
                    unset($rmUpdatedArray['Old Approved Hours']);
                    unset($rmUpdatedArray['New Approved Hours']);
                }
            }
            $selectedLogArray = [
                'New Project Name' => 'New Project Name',
                'New Billing Type' => 'New Billing Type',
                'New Project Summary' => 'New Project Summary',
                'New Company Name' => 'New Company Name',
                'New Company Address' => 'New Company Address',
                'New Approved Hours' => 'New Approved Hours',
                'New MaximumHours Billed' => 'New MaximumHours Billed',
                'New Client Name' => 'New Client Name',
                'New Client Email' => 'New Client Email',
                'New Project Components' => 'New Project Components',
                'New Project Managers' => 'New Project Managers',
                'New Account Managers' => 'New Account Managers',
                'New Technologies' => 'New Technologies',
                'New Project Type' => 'New Project Type',
                'New Governance Category' => 'New Governance Category',
                'New Billing Medium' => 'New Billing Medium',
            ];
            $activityLogArray = [];
            foreach ($rmUpdatedArray as $key => $value) {
                if (array_key_exists($key, $selectedLogArray)) {
                    $updatedNewKey = str_replace('New ', '', $key);
                    $activityLogArray[$updatedNewKey] = $value;
                }
            }
            //for email
            foreach ($mailArray as $val) {
                $mailService = new MailService($val, $project->uuid, $rmUpdatedArray);
                $mailService->sendMail();
            }
            Log::info($this->helpers->addToLog($uuid, $request, $rmUpdatedArray, config('constant.LOG_ACTIONS.update_project')));
            $this->helpers->addlogActivityDB($uuid, $request, $activityLogArray, config('constant.LOG_ACTIONS.update_project'));
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $project);
        } catch (\Exception $e) {
            Log::error($this->helpers->addToLog($uuid, $request, $e->getMessage(), config('constant.LOG_ACTIONS.update_project')));
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    /**
     * @OA\Put(
     *     path="/v1/project-creation",
     *     summary="Project Creation",
     *     operationId="/v1/project-creation",
     *     tags={"Project"},
     *     @OA\RequestBody(
     *         required=true,
     *         description="Post object",
     *         @OA\JsonContent(ref="#/components/schemas/ProjectCreation")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="A post",
     *         @OA\JsonContent(),
     *     ),
     *     @OA\Response(
     *         response="default",
     *         description="unexpected error",
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     *
     * @param Request $request
     * @param $uuid
     * @return \Illuminate\Http\JsonResponse
     * @throws \Illuminate\Validation\ValidationException
     */

    public function projectCreation(Request $request, $status = 0)
    {
        $this->validate($request, self::$projectCreationvalidationRules);
        $data = $request->toArray();
        try {
            $projectLogs = Project::with(['technologies', 'billingType', 'projectDomains', 'projectType', 'governanceCategory', 'accountManagers', 'projectManagers', 'lifecycleModel', 'billingMediumData'])->where('uuid', $data['project_id'])->first();
            $projectLogs = $projectLogs->toArray();
            $projectSelectedValues = Helpers::checkProjectNameRedmine($projectLogs['project_name']);
            if (empty($projectSelectedValues)) {
                $billingIDRedmine = Helpers::billingIDRedmine($projectLogs['billing_type']['name']);
                $redmineProjectID = '';
                if (isset($projectLogs['parent_id'])) {
                    $pmoProjectName = Helpers::getProjectName($projectLogs['parent_id']);
                    $redmineProjectID = Helpers::projectIDRedmine($pmoProjectName);
                }
                $clientBillable = 1;
                if ($billingIDRedmine == 7) {
                    $clientBillable = 0;
                }
                $techArray = [];
                foreach ($projectLogs['technologies'] as $techVal) {
                    array_push($techArray, $techVal['name']);
                }
                $technologyString = implode(",", $techArray);
                $dataPost = json_encode([
                    'project' =>
                    [
                        'name' => $projectLogs['project_name'],
                        'identifier' => $projectLogs['identifier'],
                        'description' => $projectLogs['project_summary'],
                        'homepage' => '',
                        'status' => config('constant.REDMINE_PROJECTSTATUS.activeProject'),
                        'is_public' => false,
                        'parent_id' => $redmineProjectID,
                        'inherit_members' => false,
                        'custom_fields' =>
                        [
                            0 =>
                            [
                                'id' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.Technology_Stack_ID'),
                                'name' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.Technology_Stack'),
                                'value' => isset($technologyString) ? $technologyString : '',
                            ],
                            1 =>
                            [
                                'id' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.Client_Billable_ID'),
                                'name' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.Client_Billable'),
                                'value' => $clientBillable,
                            ],
                            2 =>
                            [
                                'id' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.Infrastructure_Details_ID'),
                                'name' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.Infrastructure_Details'),
                                'value' => '',
                            ],
                            3 =>
                            [
                                'id' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.Contract_Type_ID'),
                                'name' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.Contract_Type'),
                                'value' => isset($billingIDRedmine) ? $billingIDRedmine : '',
                            ],
                            4 =>
                            [
                                'id' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.ProjectEndDate_ID'),
                                'name' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.ProjectEndDate'),
                                'value' => isset($projectLogs['estimated_timeline_to']) ? $projectLogs['estimated_timeline_to'] : '',
                            ],
                            5 =>
                            [
                                'id' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.ProjectStartDate_ID'),
                                'name' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.ProjectStartDate'),
                                'value' => isset($projectLogs['estimated_timeline_from']) ? $projectLogs['estimated_timeline_from'] : '',
                            ],
                            6 =>
                            [
                                'id' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.RevisedEndDate_ID'),
                                'name' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.RevisedEndDate'),
                                'value' => '',
                            ],
                            7 =>
                            [
                                'id' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.Estimated_Hrs_ID'),
                                'name' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.Estimated_Hrs'),
                                'value' => isset($projectLogs['approved_hours']) ? $projectLogs['approved_hours'] : $projectLogs['maximum_hours_billed'],
                            ],
                            8 =>
                            [
                                'id' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.Lifecycle_Model_ID'),
                                'name' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.Lifecycle_Model'),
                                'value' => isset($projectLogs['lifecycle_model']['name']) ? $projectLogs['lifecycle_model']['name'] : '',
                            ],
                            9 =>
                            [
                                'id' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.Project_Type_ID'),
                                'name' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.Project_Type'),
                                'value' => isset($projectLogs['project_type']['name']) ? $projectLogs['project_type']['name'] : '',
                            ],
                            10 =>
                            [
                                'id' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.Governance_Category_ID'),
                                'name' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.Governance_Category'),
                                'value' => isset($projectLogs['governance_category']['name']) ? $projectLogs['governance_category']['name'] : '',
                            ],
                            11 =>
                            [
                                'id' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.Billing_Medium_ID'),
                                'name' => config('constant.PROJECT_CUSTOMFIELDS_ARRAY.Billing_Medium'),
                                'value' => isset($projectLogs['billing_medium']) ? $projectLogs['billing_medium'] : '',
                            ],
                        ],
                    ],
                ]);
                $result = Helpers::callAPI('POST', '/projects.json', $dataPost);
                $apiRedmineResponse = json_decode($result, true);
                if (!isset($apiRedmineResponse['errors'])) {
                    Log::info(['Project_POST_API', $result, $dataPost]);
                    $redmineLastID = $apiRedmineResponse['project']['id'];
                    $updateRedmineStatus = Project::where('uuid', $data['project_id'])->update(['redmine_project_id' => $redmineLastID]);
                    $pmIDs = [];
                    $amIDs = [];
                    if (isset($projectLogs['account_managers'])) {
                        foreach ($projectLogs['account_managers'] as $acckey => $accval) {
                            array_push($amIDs, $accval['user_id']);
                        }
                    }
                    if (isset($projectLogs['project_managers'])) {
                        foreach ($projectLogs['project_managers'] as $prokey => $proval) {
                            array_push($pmIDs, $proval['user_id']);
                        }
                    }
                    $commanID = array_intersect($amIDs, $pmIDs);
                    $newAMArray = array_diff($amIDs, $commanID);
                    $newPMArray = array_diff($pmIDs, $commanID);
                    if (count($newAMArray) > 0) {
                        foreach ($newAMArray as $key => $amVal) {
                            $dataMemberACC = json_encode([
                                'membership' =>
                                [
                                    'user_id' => $amVal,
                                    'role_ids' =>
                                    [
                                        0 => 3,
                                    ],
                                ],
                            ]);
                            $resultAm = Helpers::callAPI('POST', '/projects/' . $redmineLastID . '/memberships.json', $dataMemberACC);
                            Log::info(['Project_POST_Membership_AM_API', $resultAm, $dataMemberACC]);
                        }
                    }

                    if (count($newPMArray) > 0) {
                        foreach ($newPMArray as $key => $pmVal) {
                            $dataMemberPRO = json_encode([
                                'membership' =>
                                [
                                    'user_id' => $pmVal,
                                    'role_ids' =>
                                    [
                                        0 => 15,
                                    ],
                                ],
                            ]);
                            $resultpm = Helpers::callAPI('POST', '/projects/' . $redmineLastID . '/memberships.json', $dataMemberPRO);
                            Log::info(['Project_POST_Membership_PM_API', $resultpm, $dataMemberPRO]);
                        }
                    }

                    if (count($commanID) > 0) {
                        $rolesCommon = [3, 15];
                        foreach ($commanID as $key => $ampmVal) {
                            $dataMemberAM_PM = json_encode([
                                'membership' =>
                                [
                                    'user_id' => $ampmVal,
                                    'role_ids' =>
                                    $rolesCommon,
                                ],
                            ]);
                            $resultcm = Helpers::callAPI('POST', '/projects/' . $redmineLastID . '/memberships.json', $dataMemberAM_PM);
                            Log::info(['Project_POST_Membership_AM_PM_API', $resultcm, $dataMemberAM_PM]);
                        }
                    }
                    $changeStatus = Project::where('uuid', $data['project_id'])->update(array('status' => config('constant.PROJECT_ACTION')['creation']));
                    PerformedActionLog::where(['project_id' => $data['project_id'], 'user_action_id' => 1])->update(['status' => config('constant.PERFORM_ACTIONLOG.completed')]);
                    //for mail
                    $project = Project::where('uuid', $data['project_id'])->first();
                    if($status){
                        Log::info($this->helpers->addToLog($data['project_id'], $request, $project, config('constant.LOG_ACTIONS.creation_project')));
                        $this->helpers->addlogActivityDB($data['project_id'], $request, $projectLogs, config('constant.LOG_ACTIONS.creation_project'));
                        return 1;
                    }
                    if (!is_null($project)) {
                        $appFrontendUrl = ['APP_FRONTEND_URL' => config('constant.FRONTEND_URL')];
                        $mailArray = [config('constant.TEMPLATES.creation')];
                        foreach ($mailArray as $val) {
                            $mailService = new MailService($val, $data['project_id'], $appFrontendUrl);
                            $mailService->sendMail();
                        }
                    }
                    Log::info($this->helpers->addToLog($data['project_id'], $request, $project, config('constant.LOG_ACTIONS.creation_project')));
                    $this->helpers->addlogActivityDB($data['project_id'], $request, $projectLogs, config('constant.LOG_ACTIONS.creation_project'));
                    return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $project);
                } else {
                    Log::info(['Project_POST_API', $result, $dataPost]);
                    return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusUnprocessable'), '', $result);
                }
            } else {
                $changeStatus = Project::where('uuid', $data['project_id'])->update(array('status' => config('constant.PROJECT_ACTION')['creation']));
                PerformedActionLog::where(['project_id' => $data['project_id'], 'user_action_id' => 1])->update(['status' => config('constant.PERFORM_ACTIONLOG.completed')]);
                Project::where('uuid', $data['project_id'])->update([
                    'redmine_project_id' => $projectSelectedValues['id'],
                    'identifier' => $projectSelectedValues['identifier']
                ]);
                //for mail
                $project = Project::where('uuid', $data['project_id'])->first();
                if($status){
                    Log::info($this->helpers->addToLog($data['project_id'], $request, $project, config('constant.LOG_ACTIONS.creation_project')));
                    $this->helpers->addlogActivityDB($data['project_id'], $request, $projectLogs, config('constant.LOG_ACTIONS.creation_project'));
                    return 1;
                }
                if (!is_null($project)) {
                    $appFrontendUrl = ['APP_FRONTEND_URL' => config('constant.FRONTEND_URL')];
                    $mailArray = [config('constant.TEMPLATES.creation')];
                    foreach ($mailArray as $val) {
                        $mailService = new MailService($val, $data['project_id'], $appFrontendUrl);
                        $mailService->sendMail();
                    }
                }

                Log::info($this->helpers->addToLog($data['project_id'], $request, $project, config('constant.LOG_ACTIONS.creation_project')));
                $this->helpers->addlogActivityDB($data['project_id'], $request, $projectLogs, config('constant.LOG_ACTIONS.creation_project'));
                return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $project);
            }
        } catch (\Exception $e) {
            Log::error($this->helpers->addToLog($data['project_id'], $request, $e->getMessage(), config('constant.LOG_ACTIONS.creation_project')));
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function projectStatusUpdate(Request $request, $uuid)
    {
        $this->validate($request, self::$updateProjectStatus);
        try {
            $project = Project::where('uuid', $uuid)->update(['status' => $request->status_id]);
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $project, 'status updated');
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function destroy(Request $request, $uuid)
    {
        try {
            $project = Project::where('uuid', $uuid)->first();
            if ($project) {
                $project->delete();
                $message = 'record deleted';
            } else {
                $message = 'record not found';
            }
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $project, $message);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function testMail(Request $request)
    {
        $emails = ['yash.gupta1@successive.tech', 'aakash.kumar@successive.tech'];
        Mail::to($emails)->send(new ProjectInitiation());
        return 'success';
    }

    public function pendingActionsInProject($project)
    {
        if (isset($project)) {
            $pendingAction = [];
            $doneRequisition = $this->checkIsRequisitionExist($project['uuid']);
            $pendingAction['requisitionDone'] = $doneRequisition;
            $requisation = $this->checkIsRequisitionPending($project['uuid']);
            if (count($requisation) > 0) {
                $pendingAction['isRequisition'] = true;
            } else {
                $pendingAction['isRequisition'] = false;
            }
            $pendingMapping = $this->getMappingPendingRequisitionList($project['uuid']);
            if (count($pendingMapping) > 0) {
                $pendingAction['allocationMapping'] = true;
            } else {
                $pendingAction['allocationMapping'] = false;
            }
            $existDeallocation = $this->getExistingAllocatedResource($project['uuid']);
            $pendingAction['isDeallocation'] = $existDeallocation;
            $pendingUnmapping = $this->MapAllDeAllocationMapping($project['uuid']);
            if (count($pendingUnmapping) > 0) {
                $pendingAction['deallocationUnmapping'] = true;
            } else {
                $pendingAction['deallocationUnmapping'] = false;
            }
            $project->pending_action = $pendingAction;
        }
        return $project;
    }

    public static $changeManagersvalidationRules = [
        'project_manager_id' => 'array',
        'account_manager_id' => 'array',
        'is_delete' => 'required',
    ];
    public function changeManagers(Request $request, $projectId)
    {
        $this->validate($request, self::$changeManagersvalidationRules);
        try {
            $accountManagers = EmailAddresse::whereIn('address', $request->account_manager_id)->pluck('user_id');
            $projectManagers = EmailAddresse::whereIn('address', $request->project_manager_id)->pluck('user_id');
            if ($request->is_delete) {
                UserRole::where('project_id', $projectId)->where('role_id', $this->rolesArray[config('constant.ROLES.account_manager')])->whereIn('user_id', $accountManagers)->delete();
                UserRole::where('project_id', $projectId)->where('role_id', $this->rolesArray[config('constant.ROLES.project_manager')])->whereIn('user_id', $projectManagers)->delete();
            } else {
                UserRole::saveProjectRole($projectId, $accountManagers, $this->rolesArray[config('constant.ROLES.account_manager')]);
                UserRole::saveProjectRole($projectId, $projectManagers, $this->rolesArray[config('constant.ROLES.project_manager')]);
            }
            $project = Project::with(['technologies', 'accountManagers', 'projectManagers', 'projectDomains'])
                ->where('uuid', $projectId)->first();
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $project);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function getAllAssignedProject(Request $request)
    {
        $currentUserId = $request->user->id;
        $checkMapped = true;
        $projectDetails = [];
        $projectStatus = [config('constant.PROJECT_ACTION')['project_closure_checklist'], config('constant.PROJECT_ACTION')['project_on_hold_request_accept']];
        try {
            $userRole = Helpers::getRole($currentUserId);
            $projects = Project::with([
                'accountManagers', 'projectManagers',
                'ProjectRole' => function ($query) use ($currentUserId) {
                    $query->where('user_id', $currentUserId);
                }, 'resourceRequisitionAllProject' => function ($query) use ($userRole) {
                    $query->whereIn('dept_id', $userRole['department']);
                }, 'resourceMapped' => function ($query) use ($currentUserId) {
                    $query->where('resource_id', $currentUserId);
                },
            ])
                ->whereNotIn('status', $projectStatus)
                ->orderBy('created_at', 'desc')
                ->select('uuid', 'project_name')
                ->get();
            $projects = $this->removeUnAuthorizedProjects($projects, $currentUserId, $userRole, $checkMapped);
            foreach ($projects as $project) {
                $projectDetails[] = ['uuid' => $project->uuid, 'project_name' => $project->project_name];
            }
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $projectDetails);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function projectAction(Request $request, $projectId)
    {
        $currentUserId = $request->user->id;
        try {
            $userRole = Helpers::getRole($currentUserId);
            $project = Project::with([
                'billingType', 'technologies', 'accountManagers', 'projectManagers',
                'ProjectRole' => function ($query) use ($currentUserId) {
                    $query->where('user_id', $currentUserId);
                }, 'initiatedBy', 'projectDomains', 'ResourceRequisition' => function ($query) use ($userRole) {
                    $query->whereIn('dept_id', $userRole['department']);
                }
            ])
                ->where('is_draft', 0)
                ->where('uuid', $projectId)
                ->first();
            $project->track = ['status' => $project->status, 'is_approve' => $project->is_approve, 'is_draft' => $project->is_draft];
            $projectDetails = $this->addUserActionInProjectAccordingRole($project, $currentUserId);
            $projectDetails = $this->addPerformedActionInProjectAccordingRole($projectDetails, $currentUserId);
            $projectDetails = $this->mergeUserAndPerformedAction($projectDetails);
            $projectDetails = $this->pendingActionsInProject($projectDetails);
            $projectDetails = $this->checkWsrWeekStatusAction($projectDetails);
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $projectDetails);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function checkWsrWeekStatusAction($projects)
    {
        if (!empty($projects)) {
            $today = Carbon::today();
            $weekNumber = $today->weekOfYear;
                $projects->wsr_status = 0;
                $wsrresult = WeeklyStatusReport::where('project_id', '=', $projects->uuid)
                ->where('week_no', '=', $weekNumber)
                ->where('overall_health_status', '!=', 4)
                ->pluck('uuid')->toArray();
                if (count($wsrresult) > 0) {
                    $projects->wsr_status = 1;
                }
            return $projects;
        }
    }
    public function projectListing(Request $request)
    {
        try {
            $projectListing = Project::get(['uuid', 'project_name', 'status']);
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $projectListing);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }
    public function projectListingRedmine(Request $request)
    {
        try {
            $projectListing = RedmineProjectModel::where('status', 1)
                ->where('name', 'not like', "%BU")
                ->where('name', 'not like', "%training%")->get(['id as uuid', 'name as project_name', 'status', 'parent_id']);
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $projectListing);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function projectActivity($projectId)
    {
        try {
            $userActivity = ProjectActivity::with(['projectActionType', 'createdBy'])
                ->where('link_id', $projectId)
                ->orderBy('id', 'desc')
                ->get(['id', 'link_id', 'action_id', 'user_id', 'response', 'created_at', 'updated_at']);
            $user_actvity = [];
            foreach ($userActivity as $activity) {
                if (isset(json_decode($activity['response'], true)[0]['suggested_resource']) && json_decode($activity['response'], true)[0]['suggested_resource'] != "") {
                    $suggestedIds = json_decode($activity['response'], true)[0]['suggested_resource'];
                    if (is_array($suggestedIds)) {
                        $suggested_resources_name = LocalUser::select(DB::raw('CONCAT("[", GROUP_CONCAT(full_name), "]") as names'))->whereIn('user_id', $suggestedIds)->get()->toArray();
                        $data = json_decode($activity['response'], true)[0];
                        $data['suggested_resource'] = $suggested_resources_name[0]['names'];
                        $activity['response'] = json_encode([$data], true);
                    }
                    $user_actvity[] = $activity;
                } else if (isset(json_decode($activity['response'], true)[0]['resource_requisition']) && json_decode($activity['response'], true)[0]['resource_requisition'] != "") {
                    $requisitions = json_decode($activity['response'], true);
                    $resource = [];
                    foreach ($requisitions as $requisition) {
                        $id = str_replace(array('[', ']'), '', $requisition['resource_requisition']['suggested_resource']);
                        $suggested_resources_name = LocalUser::select(DB::raw('CONCAT("[", GROUP_CONCAT(full_name), "]") as names'))->whereIn('user_id', explode(",", $id))->get()->toArray();
                        $requisition['resource_requisition']['suggested_resource'] = $suggested_resources_name[0]['names'];
                        $resource[] = $requisition;
                    }
                    $activity['response'] = json_encode($resource, true);
                    $user_actvity[] = $activity;
                } else if (isset(json_decode($activity['response'], true)['resource_requisition']) && json_decode($activity['response'], true)['resource_requisition'] != "") {
                    $requisition = json_decode($activity['response'], true);
                    $id = str_replace(array('[', ']'), '', $requisition['resource_requisition']['suggested_resource']);
                    $suggested_resources_name = LocalUser::select(DB::raw('CONCAT("[", GROUP_CONCAT(full_name), "]") as names'))->whereIn('user_id', explode(",", $id))->get()->toArray();
                    $requisition['resource_requisition']['suggested_resource'] = $suggested_resources_name[0]['names'];
                    $activity['response'] = json_encode($requisition, true);
                    $user_actvity[] = $activity;
                } else {
                    $user_actvity[] = $activity;
                }
            }
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $userActivity);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function exportMismatchSheet()
    {
        $data['projectNameMismatch'] = [];
        $data['projectManagersMismatch'] = [];
        $data['overViewResourceMismatch'] = [];

        $redmineProjects = RedmineProjectModel::with('ProjectMembers', 'currentBooking', 'tillYesterdayBooking')
            ->where('status', 1)->get();
        $redmineResources = ResourceBooking::whereHas('project', function ($q) {
            $q->where('status', 1);
        })->with('userMembers', 'userProjects', 'userDepartment')
            ->whereDate('end_date', '>=', Carbon::today())
            ->where('hours_per_day', '!=', 0)
            ->get();

        $pmoResources = Project::with('currentBookings', 'ProjectRole') // need to add role(designation) relation in allocation table
            ->where('status', '!=', 17)
            ->get();

        $matchData = $this->overViewResourceMismatch($pmoResources, $redmineResources, $redmineProjects);
        $data['projectManagersMismatch'] = $matchData['managers'];
        $data['overViewResourceMismatch'] = $matchData['resources'];
        $data['projectNameMismatch'] = $this->projectNameMismatch($pmoResources, $redmineProjects);
        return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $data);
    }

    public function projectManagersMismatch($pmoproject, $redmineProjects)
    {
        foreach ($redmineProjects as $redmineProject) {
            if (
                trim(strtolower(str_replace(array(' '), '', $redmineProject->name))) ==
                trim(strtolower(str_replace(array(' '), '', $pmoproject->project_name)))
            ) {
                $amMatched = false;
                $pmMatched = false;
                $pmoProjectAMIds = [];
                $pmoProjectPMIds = [];
                $pmoProjectAMNames = [];
                $pmoProjectPMNames = [];
                $redmineProjectAMIds = [];
                $redmineProjectPMIds = [];
                $redmineProjectAMNames = [];
                $redmineProjectPMNames = [];
                foreach ($pmoproject['projectRole'] as $role) {
                    if ($role->role_id == 5) {
                        $pmoProjectAMIds[] = $role->user_id;
                        $pmoProjectAMNames[] = isset($role['User']->display_name) ? $role['User']->display_name : '';
                    }
                    if ($role->role_id == 6) {
                        $pmoProjectPMIds[] = $role->user_id;
                        $pmoProjectPMNames[] = isset($role['User']->display_name) ? $role['User']->display_name : '';
                    }
                }
                foreach ($redmineProject['ProjectMembers'] as $userProjects) {
                    foreach ($userProjects['MemberRole'] as $memberRole) {
                        if ($memberRole->role_id == 3) {
                            $redmineProjectAMIds[] = $userProjects->user_id;
                            $redmineProjectAMNames[] = isset($userProjects['User']->display_name) ? $userProjects['User']->display_name : '';
                        }
                        if ($memberRole->role_id == 15) {
                            $redmineProjectPMIds[] = $userProjects->user_id;
                            $redmineProjectPMNames[] = isset($userProjects['User']->display_name) ? $userProjects['User']->display_name : '';
                        }
                    }
                }
                if (array_diff($pmoProjectAMIds, $redmineProjectAMIds) == array_diff($redmineProjectAMIds, $pmoProjectAMIds)) {
                    $amMatched = true;
                }
                if (array_diff($pmoProjectPMIds, $redmineProjectPMIds) == array_diff($redmineProjectPMIds, $pmoProjectPMIds)) {
                    $pmMatched = true;
                }

                return [
                    'pmoAM' => count($pmoProjectAMNames) > 0 ? implode(", ", $pmoProjectAMNames) : 'N/A',
                    'pmoPM' => count($pmoProjectPMNames) > 0 ? implode(", ", $pmoProjectPMNames) : 'N/A',
                    'redmineAM' => count($redmineProjectAMNames) > 0 ? implode(", ", $redmineProjectAMNames) : 'N/A',
                    'redminePM' => count($redmineProjectPMNames) > 0 ? implode(", ", $redmineProjectPMNames) : 'N/A',
                    'amMatched' => $amMatched,
                    'pmMatched' => $pmMatched,
                ];
            }
        }
    }

    public function checkMatchedRecords($currentBookings, $redmineRecord)
    {
        foreach ($currentBookings as $resourceMapped) {
            if (isset($resourceMapped['resourceAllocation']['resourceAllocationMeta'][0])) {
                foreach ($resourceMapped['resourceAllocation']['resourceAllocationMeta'] as $resourceAllocationMeta) {
                    if (
                        Carbon::parse($resourceAllocationMeta->start_date)->format('Y-m-d') == Carbon::parse($redmineRecord->start_date)->format('Y-m-d') &&
                        Carbon::parse($resourceAllocationMeta->end_date)->format('Y-m-d') == Carbon::parse($redmineRecord->end_date)->format('Y-m-d') &&
                        $redmineRecord->hours_per_day == $resourceAllocationMeta->hours
                    ) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public function overViewResourceMismatch($pmoResources, $redmineProjects)
    {
        $data = [];
        $managers = [];
        $excludeRoleArray = config('constant.EXCLUDE_RESOURCE_BOOKED');
        foreach ($pmoResources as $key => $pmoproject) {
            $projectName = $pmoproject->project_name;
            //Project and Account Managers Match
            $managers[$projectName] = $this->projectManagersMismatch($pmoproject, $redmineProjects);
            $matchRecordsRedmineId = [];
            $pmoResourceIdArray = [];
            $redmineResources = [];
            $tillYesterdayBooking = [];
            foreach ($redmineProjects as $redmineProject) {
                if (
                    trim(strtolower(str_replace(array(' '), '', $redmineProject->name))) ==
                    trim(strtolower(str_replace(array(' '), '', $projectName)))
                ) {
                    $redmineResources = $redmineProject['currentBooking'];
                    $tillYesterdayBooking = $redmineProject['tillYesterdayBooking'];
                }
            }
            //            Resource Booking Match
            foreach ($pmoproject['currentBookings'] as $resourceMapped) {
                if (isset($resourceMapped['resourceAllocation']['resourceAllocationMeta'][0])) {
                    foreach ($resourceMapped['resourceAllocation']['resourceAllocationMeta'] as $resourceAllocationMeta) {
                        if (
                            isset($resourceAllocationMeta['resource']->status) &&
                            $resourceAllocationMeta['resource']->status == config('constant.REDMINE_USERSTATUS.activeUser')
                        ) {
                            $pmoRole = $resourceMapped['resourceAllocation']['ResourceRequisition']['designation']->name;
                            $userDept = isset($resourceMapped['resourceAllocation']['ResourceRequisition']['department']->name) ? $resourceMapped['resourceAllocation']['ResourceRequisition']['department']->name : '';
                            $flag = false;
                            $entryMatched = false;
                            $endDate = Carbon::parse($resourceAllocationMeta->end_date);
                            $resourceId = $resourceAllocationMeta->resource_id;
                            $resourceEmail = isset($resourceAllocationMeta['resource']->email) ? $resourceAllocationMeta['resource']->email : "";
                            $resourceEmployeeCode = isset($resourceAllocationMeta['resource']->employee_id) ? $resourceAllocationMeta['resource']->employee_id : "";
                            $pmoResourceIdArray[] = $resourceAllocationMeta->resource_id;
                            $resourceName = isset($resourceAllocationMeta['resource']->display_name) ? $resourceAllocationMeta['resource']->display_name : "";
                            $projectName = $pmoproject->project_name;
                            $count = 0;
                            $redmineResourceBookingCount = 0;
                            $pmoResourceBookingCount = 0;
                            //booking count check for single resource
                            foreach ($pmoproject['currentBookings'] as $countPmoBookig) {
                                if ($countPmoBookig->resource_id == $resourceId) {
                                    $pmoResourceBookingCount = $pmoResourceBookingCount + 1;
                                }
                            }
                            foreach ($redmineResources as $redmineResource) {
                                if (
                                    $redmineResource->assigned_to_id == $resourceId
                                ) {
                                    $redmineResourceBookingCount = $redmineResourceBookingCount + 1;
                                }
                            }
                            //if both pmo and redmine has entry
                            foreach ($redmineResources as $redmineResource) {
                                if (
                                    !in_array($redmineResource->id, $matchRecordsRedmineId) &&
                                    $redmineResource->assigned_to_id == $resourceId &&
                                    $endDate->greaterThanOrEqualTo(Carbon::today())
                                ) {
                                    $redmineRole = null;
                                    $roleMatched = false;
                                    if (isset($redmineResource['userMembers']['memberRole']) && count($redmineResource['userMembers']['memberRole']) >= 1) {
                                        foreach ($redmineResource['userMembers']['memberRole'] as $member) {
                                            if (
                                                trim(strtolower(str_replace(array(' '), '', $pmoRole))) ==
                                                trim(strtolower(str_replace(array(' '), '', $member['Role']->name)))
                                            ) {
                                                $roleMatched = true;
                                                $redmineRole = $member['Role']->name;
                                                break;
                                            }
                                        }
                                        if (!$roleMatched) {
                                            foreach ($redmineResource['userMembers']['memberRole'] as $member) {
                                                if (!in_array($member['Role']->name, $excludeRoleArray)) {
                                                    $redmineRole = $member['Role']->name;
                                                }
                                            }
                                        }
                                    }

                                    // if start end date and hours matched
                                    if (
                                        Carbon::parse($resourceAllocationMeta->start_date)->format('Y-m-d') == Carbon::parse($redmineResource->start_date)->format('Y-m-d') &&
                                        Carbon::parse($resourceAllocationMeta->end_date)->format('Y-m-d') == Carbon::parse($redmineResource->end_date)->format('Y-m-d') &&
                                        $redmineResource->hours_per_day == $resourceAllocationMeta->hours
                                    ) {
                                        $matchRecordsRedmineId[] = $redmineResource->id;
                                        $entryMatched = true;
                                        $array = $this->createBookingData($redmineResource, $resourceMapped, $projectName, $resourceId, true, true, $resourceName, $resourceEmail, $resourceEmployeeCode, $resourceAllocationMeta, $roleMatched, $pmoRole, $redmineRole, $userDept, $entryMatched);
                                        $data[$projectName][$resourceName][] = $array;
                                        $count = $count + 1;
                                        $flag = true;
                                        break;
                                        // if start end date and hours not matched
                                    } else {
                                        if (
                                            Helpers::checkMatchedRecordPMO($pmoproject['currentBookings'], $redmineResource) ||
                                            Helpers::checkMatchedRecordRedmine($resourceAllocationMeta, $redmineResources)
                                        ) {
                                            continue;
                                        } else {
                                            $matchRecordsRedmineId[] = $redmineResource->id;
                                            $array = $this->createBookingData($redmineResource, $resourceMapped, $projectName, $resourceId, true, true, $resourceName, $resourceEmail, $resourceEmployeeCode, $resourceAllocationMeta, $roleMatched, $pmoRole, $redmineRole, $userDept, $entryMatched);
                                            $data[$projectName][$resourceName][] = $array;
                                            $count = $count + 1;
                                            $flag = true;
                                            break;
                                        }
                                    }
                                }
                            }
                            //if only pmo has entry that is not in Redmine and reCheck if pmo booking has mismatch entry which have end date as yesterday
                            if (
                                $redmineResourceBookingCount < $pmoResourceBookingCount && $flag == false &&
                                $endDate->greaterThanOrEqualTo(Carbon::today())
                            ) {
                                $roleMatched = false;
                                $redmineRole = null;
                                // reCheck if pmo booking has mismatch entry which have end date as yesterday
                                $yesterdayBooking = Helpers::checkBackDateRecordRedmine($matchRecordsRedmineId, $tillYesterdayBooking, $resourceId);
                                if ($yesterdayBooking) {
                                    if (isset($yesterdayBooking['userMembers']['memberRole']) && count($yesterdayBooking['userMembers']['memberRole']) >= 1) {
                                        foreach ($yesterdayBooking['userMembers']['memberRole'] as $member) {
                                            if (
                                                trim(strtolower(str_replace(array(' '), '', $pmoRole))) ==
                                                trim(strtolower(str_replace(array(' '), '', $member['Role']->name)))
                                            ) {
                                                $roleMatched = true;
                                                $redmineRole = $member['Role']->name;
                                                break;
                                            }
                                        }
                                        if (!$roleMatched) {
                                            foreach ($yesterdayBooking['userMembers']['memberRole'] as $member) {
                                                if (!in_array($member['Role']->name, $excludeRoleArray)) {
                                                    $redmineRole = $member['Role']->name;
                                                }
                                            }
                                        }
                                    }
                                    $matchRecordsRedmineId[] = $yesterdayBooking->id;
                                    $array = $this->createBookingData($yesterdayBooking, $resourceMapped, $projectName, $resourceId, true, true, $resourceName, $resourceEmail, $resourceEmployeeCode, $resourceAllocationMeta, $roleMatched, $pmoRole, $redmineRole, $userDept, $entryMatched);
                                    $data[$projectName][$resourceName][] = $array;
                                    $count = $count + 1;
                                    $flag = true;
                                    break;
                                } else {
                                    //if only pmo has entry that is not in Redmine
                                    $array = $this->createBookingData([], $resourceMapped, $projectName, $resourceId, false, true, $resourceName, $resourceEmail, $resourceEmployeeCode, $resourceAllocationMeta, $roleMatched, $pmoRole, null, $userDept, $entryMatched);
                                    $data[$projectName][$resourceName][] = $array;
                                }
                            }
                            //if only redmine has entry that is not in pmo
                            if ($redmineResourceBookingCount > $pmoResourceBookingCount && $count == $pmoResourceBookingCount) {
                                foreach ($redmineResources as $redmineResource) {
                                    $roleMatched = false;
                                    $redmineRole = null;
                                    if (
                                        !in_array($redmineResource->id, $matchRecordsRedmineId) &&
                                        $redmineResource->assigned_to_id == $resourceId &&
                                        $endDate->greaterThanOrEqualTo(Carbon::today())
                                    ) {
                                        if (isset($redmineResource['userMembers']['memberRole']) && count($redmineResource['userMembers']['memberRole']) >= 1) {
                                            foreach ($redmineResource['userMembers']['memberRole'] as $member) {
                                                if (!in_array($member['Role']->name, $excludeRoleArray)) {
                                                    $redmineRole = $member['Role']->name;
                                                }
                                            }
                                        }
                                        $matchRecordsRedmineId[] = $redmineResource->id;
                                        $array = $this->createBookingData($redmineResource, [], $projectName, $resourceId, true, false, $resourceName, $resourceEmail, $resourceEmployeeCode, [], $roleMatched, null, $redmineRole, $userDept, $entryMatched);
                                        $data[$projectName][$resourceName][] = $array;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            //if only redmine has entry for diffrent resource that is not in pmo
            foreach ($redmineResources as $redmineResource) {
                if (
                    isset($redmineResource['userDetail']->status) &&
                    $redmineResource['userDetail']->status == config('constant.REDMINE_USERSTATUS.activeUser')
                ) {
                    $roleMatched = false;
                    $redmineRole = null;
                    $userDept = null;
                    $entryMatched = false;
                    $endDate = Carbon::parse($redmineResource->end_date);
                    if (!in_array($redmineResource->assigned_to_id, $pmoResourceIdArray)) {
                        if (
                            !in_array($redmineResource->id, $matchRecordsRedmineId) &&
                            $endDate->greaterThanOrEqualTo(Carbon::today())
                        ) {
                            if (isset($redmineResource['userMembers']['memberRole']) && count($redmineResource['userMembers']['memberRole']) >= 1) {
                                foreach ($redmineResource['userMembers']['memberRole'] as $member) {
                                    if (!in_array($member['Role']->name, $excludeRoleArray)) {
                                        $redmineRole = $member['Role']->name;
                                    }
                                }
                            }
                            if (isset($redmineResource['userDepartment']->value)) {
                                $userDept = $redmineResource['userDepartment']->value;
                            }
                            $matchRecordsRedmineId[] = $redmineResource->id;
                            if (isset($redmineResource['userDetail']->display_name) || isset($redmineResource['userDetail']->email)) {
                                $resourceName = isset($redmineResource['userDetail']->display_name) ? $redmineResource['userDetail']->display_name : '';
                                $resourceEmail = isset($redmineResource['userDetail']->email) ? $redmineResource['userDetail']->email : "";
                                $resourceEmployeeCode = isset($redmineResource['userDetail']->employee_id) ? $redmineResource['userDetail']->employee_id : "";
                                $isMatched = false;
                                $array = $this->createBookingData($redmineResource, [], $projectName, $redmineResource->assigned_to_id, true, false, $resourceName, $resourceEmail, $resourceEmployeeCode, [], $roleMatched, null, $redmineRole, $userDept, $entryMatched);
                                $data[$projectName][$resourceName][] = $array;
                            }
                        }
                    }
                }
            }
        }
        return ['managers' => $managers, 'resources' => $data];
    }

    public function createBookingData($redmineResource, $resourceMapped, $projectName, $resourceId, $redmine, $pmo, $resourceName, $resourceEmail, $resourceEmployeeCode, $resourceAllocationMeta, $roleMatched, $pmoRole, $redmineRole, $userDept, $entryMatched)
    {
        $array = [];
        if ($redmine == true && $pmo == true) {
            $array = [
                'projectName' => $projectName,
                'resourceName' => $resourceName,
                'employeeId' => $resourceEmployeeCode,
                'email' => $resourceEmail,
                'redmineStartDate' => Carbon::parse($redmineResource->start_date)->format('d/m/Y'),
                'redmineEndDate' => Carbon::parse($redmineResource->end_date)->format('d/m/Y'),
                'redmineDailyEfforts' => $redmineResource->hours_per_day,
                'redmineRole' => ($redmineRole != null) ? $redmineRole : "N/A",
                'pmoRole' => ($pmoRole != null) ? $pmoRole : "N/A",
                'pmoStartDate' => Carbon::parse($resourceAllocationMeta->start_date)->format('d/m/Y'),
                'pmoEndDate' => Carbon::parse($resourceAllocationMeta->end_date)->format('d/m/Y'),
                'pmoDailyEfforts' => $resourceAllocationMeta->hours,
                'roleMatched' => $roleMatched,
                'entryMatched' => $entryMatched,
                'dept' => ($userDept != null) ? $userDept : "N/A",
            ];
        }
        if ($redmine != true && $pmo == true) {
            $array = [
                'projectName' => $projectName,
                'resourceName' => $resourceName,
                'employeeId' => $resourceEmployeeCode,
                'email' => $resourceEmail,
                'redmineStartDate' => "N/A",
                'redmineEndDate' => "N/A",
                'redmineDailyEfforts' => "N/A",
                'redmineRole' => ($redmineRole != null) ? $redmineRole : "N/A",
                'pmoRole' => ($pmoRole != null) ? $pmoRole : "N/A",
                'pmoStartDate' => Carbon::parse($resourceAllocationMeta->start_date)->format('d/m/Y'),
                'pmoEndDate' => Carbon::parse($resourceAllocationMeta->end_date)->format('d/m/Y'),
                'pmoDailyEfforts' => $resourceAllocationMeta->hours,
                'roleMatched' => $roleMatched,
                'entryMatched' => $entryMatched,
                'dept' => ($userDept != null) ? $userDept : "N/A",
            ];
        }
        if ($redmine == true && $pmo != true) {
            $array = [
                'projectName' => $projectName,
                'resourceName' => $resourceName,
                'employeeId' => $resourceEmployeeCode,
                'email' => $resourceEmail,
                'redmineStartDate' => Carbon::parse($redmineResource->start_date)->format('d/m/Y'),
                'redmineEndDate' => Carbon::parse($redmineResource->end_date)->format('d/m/Y'),
                'redmineDailyEfforts' => $redmineResource->hours_per_day,
                'redmineRole' => ($redmineRole != null) ? $redmineRole : "N/A",
                'pmoRole' => ($pmoRole != null) ? $pmoRole : "N/A",
                'pmoEndDate' => "N/A",
                'pmoStartDate' => "N/A",
                'pmoDailyEfforts' => "N/A",
                'roleMatched' => $roleMatched,
                'entryMatched' => $entryMatched,
                'dept' => ($userDept != null) ? $userDept : "N/A",
            ];
        }
        return $array;
    }

    public function projectNameMismatch($pmoResources, $redmineProjects)
    {

        $data = [];
        foreach ($pmoResources as $pmoResource) {
            $matched = false;
            foreach ($redmineProjects as $redmineProject) {

                if (
                    trim(strtolower(str_replace(array(' '), '', $pmoResource->project_name))) ==
                    trim(strtolower(str_replace(array(' '), '', $redmineProject->name)))
                ) {
                    $matched = true;
                    $row = $this->createProjectData($pmoResource->project_name, $redmineProject->name, true);
                    if ($row != null) {
                        $data[] = $row;
                    }
                    $ids[] = $redmineProject->id;
                    break;
                }
            }
            if (!$matched) {
                $row = $this->createProjectData($pmoResource->project_name, null, false);
                if ($row != null) {
                    $data[] = $row;
                }
            }
        }
        return $data;
    }

    public function createProjectData($pmoProjectName, $redmineProjectName, $isMatched)
    {
        $data = [
            'pmoProjectName' => ($pmoProjectName != null) ? $pmoProjectName : "N/A",
            'redmineProjectName' => ($redmineProjectName != null) ? $redmineProjectName : "N/A",
            'isMatched' => $isMatched,
        ];
        return $data;
    }
    public function projectActivityUsers()
    {
        try {
            $userActivity = ProjectActivity::with(['projectActionType', 'createdBy'])
                ->orderBy('id', 'desc')
                ->get(['id', 'link_id', 'url', 'action_id', 'user_id', 'created_at', 'updated_at']);
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $userActivity);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function resourceSummary(Request $request)
    {
        try {
            $currentUserId = $request->user->id;
            $checkMapped = false;
            $pendingInitiaion = true;
            $userRole = Helpers::getRole($currentUserId);
            if (in_array($this->rolesArray[config('constant.ROLES.admin')], $userRole['global'])) {
                $userRole['department'] = Department::pluck('id')->toArray();
            }
            $projects = Project::with([
                'resourceRequisitionAllProject' => function ($query) use ($userRole) {
                    $query->whereIn('dept_id', $userRole['department']);
                }, 'ProjectRole' => function ($query) use ($currentUserId) {
                    $query->where('user_id', $currentUserId);
                }
            ])
                ->orderBy('created_at', 'desc')
                ->get();
            $projects = $this->removeUnAuthorizedProjects($projects, $currentUserId, $userRole, $checkMapped, $pendingInitiaion);
            $redmineId = [];
            foreach ($projects as $key => $projectValue) {
                $redmineId[] = $projectValue->redmine_project_id;
            }
            $projectIds = array_filter($redmineId, function ($value) {
                return !is_null($value) && $value !== '';
            });
            $data = [];
            if (isset($projectIds) && count($projectIds) > 0) {
                $redmineProjects = RedmineProjectModel::whereIn('id', $projectIds)
                    ->with('projectBookings')
                    ->select('id', 'name', 'status')
                    ->where('status', 1)
                    ->get();

                foreach ($redmineProjects as $redmineProject) {
                    $projectName = $redmineProject->name;
                    $projectRedmineId = $redmineProject->id;
                    $data[$projectName]['resourceCount'] = 0;
                    $data[$projectName]['ProjectRedmineId'] = $projectRedmineId;
                    $resourceIds = [];
                    if (isset($redmineProject['currentBooking']) && count($redmineProject['currentBooking']) > 0) {
                        foreach ($redmineProject['currentBooking'] as $redmineResource) {
                            if (isset($redmineResource['userDetail'])) {
                                $resourceIds[] = $redmineResource->id;
                                $userDept = isset($redmineResource['userDepartment']->value) ? $redmineResource['userDepartment']->value : '';
                                $userName = isset($redmineResource['userDetail']->display_name) ? $redmineResource['userDetail']->display_name : '';
                                $array = [
                                    'ResourceName' => $userName,
                                    'userId' => $redmineResource->assigned_to_id,
                                    'department' => $userDept,
                                    'startDate' => $redmineResource->start_date,
                                    'endDate' => $redmineResource->end_date,
                                    'Hour' => $redmineResource->hours_per_day
                                ];
                                $data[$projectName]['resource'][] = $array;
                                $data[$projectName]['resourceCount'] = count($resourceIds);
                            }
                        }
                    }
                }
            }

            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $data);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function updateRedmineIdInPMO(Request $request, $uuid)
    {
        $requestData = $request->toArray();
        if (isset($requestData)) {
            if (isset($requestData['redmine_project_id'])) {
                $updatedProject['redmine_project_id'] = $requestData['redmine_project_id'];
            }
            if (isset($requestData['identifier'])) {
                $updatedProject['identifier'] = $requestData['identifier'];
            }
            $updateRedmineStatus = Project::where('uuid', $uuid)->update($updatedProject);
        }
        return $updateRedmineStatus;
    }

    public function updateInitiationDatePMO(Request $request, $uuid)
    {
        $requestData = $request->toArray();
        if (isset($requestData)) {
            if (isset($requestData['initiation_date'])) {
                $updatedProject['initiation_date'] = $requestData['initiation_date'];
            }
            $updateRedmineStatus = Project::where('uuid', $uuid)->update($updatedProject);
        }
        return $updateRedmineStatus;
    }

    public function projectWSRData(Request $request)
    {
        $currentUserId = $request->user->id;
        $checkMapped = false;
        $pendingInitiaion = true;
        try {
            $userRole = Helpers::getRole($currentUserId);
            if (in_array($this->rolesArray[config('constant.ROLES.admin')], $userRole['global'])) {
                $userRole['department'] = Department::pluck('id')->toArray();
            }
            $projects = Project::with([
                'ProjectRisk', 'projectWSR',
                'resourceRequisitionAllProject' => function ($query) use ($userRole) {
                    $query->whereIn('dept_id', $userRole['department']);
                },
                'ProjectRole' => function ($query) use ($currentUserId) {
                    $query->where('user_id', $currentUserId);
                }
            ])->whereIn('billing_type', config('constant.billing_type'))
                ->orderBy('created_at', 'desc')
                ->get();
            $resultArray = [];
            $projects = $this->removeUnAuthorizedProjects($projects, $currentUserId, $userRole, $checkMapped, $pendingInitiaion);
            $projects = $this->addTrackerKeyInProjects($projects);
            $activeRiskCount = $this->checkProjectInRisk($projects);
            $allProjectActiveRisk = $this->allProjectActiveRisk($projects);
            $allProjectwsrStatusSubmit = $this->wsrStatusSubmit($projects);
            $resultArray['projectList'] = $projects;
            $resultArray['activeProjectCount'] = count($projects);
            $resultArray['projectAtRiskCount'] = count($activeRiskCount);
            $resultArray['allProjectActiveRiskCount'] = count($allProjectActiveRisk);
            $resultArray['allProjectwsrStatusSubmitCount'] = count($allProjectwsrStatusSubmit);
            $resultArray['allProjectwsrPendingSubmitCount'] = count($projects) - count($allProjectwsrStatusSubmit);
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $resultArray);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function topProjectGarph(Request $request)
    {
        $currentWeekNumber = date('W');
        $weekRange = range($currentWeekNumber - 3, $currentWeekNumber);
        try {
            $topProject = WeeklyStatusReport::with('projectName')
                ->whereIn('week_no', $weekRange)
                ->select('project_id', 'uuid', 'week_no', 'overall_health_status')
                ->orderBy('overall_health_status', 'desc')
                ->get();
            $data = collect($topProject)->groupBy('project_id')->toArray();
            $excludeStatus = [1, 2];
            $finalArray = [];
            foreach ($data as $key => $val) {
                $overallHealth = [];
                foreach ($val as $innerkey) {
                    $overallHealth[] = $innerkey['overall_health_status'];
                }
                if (!in_array(1, $overallHealth) && !in_array(2, $overallHealth)) {
                    $finalArray[] = $val[0];
                }
            }
            $count = count($finalArray);
            $resultArray = ['topProject' => $finalArray, 'count' => $count];
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $resultArray);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function projectKickOff(Request $request)
    { {
            $currentUserId = $request->user->id;
            $checkMapped = false;
            $pendingInitiaion = true;
            try {
                $userRole = Helpers::getRole($currentUserId);
                if (in_array($this->rolesArray[config('constant.ROLES.admin')], $userRole['global'])) {
                    $userRole['department'] = Department::pluck('id')->toArray();
                }
                $activeProjectStatus = ['12', '13', '1'];
                $projects = Project::whereNotIn('status', $activeProjectStatus)
                    ->whereIn('billing_type', config('constant.billing_type'))
                    ->whereDate('created_at', '>', Carbon::now()->subDays(30))
                    ->orderBy('created_at', 'desc')
                    ->select('uuid', 'project_name', 'status', 'client_detail', 'created_at')
                    ->get();
                $allProject = [];
                foreach ($projects as $value) {
                    if ($value['is_draft'] == 1) {
                        $allProject[] = $value;
                    } else if ((($value['is_approve'] == 0 || $value['is_approve'] == 1) && $value['status'] == 17)) {
                        $allProject[] = $value;
                    } else {
                        $allProject[] = $value;
                    }
                }
                foreach ($allProject as $key => $value) {
                    $clientAddress = json_decode($value->client_detail);
                    $clientDomain = Helpers::computeDomian($clientAddress);
                    $value->user_domain = $clientDomain;
                }
                $count = count($allProject);

                $projects = $this->removeUnAuthorizedProjects($allProject, $currentUserId, $userRole, $checkMapped, $pendingInitiaion);

                return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), ['projectKickOff' => $projects, 'count' => $count]);
            } catch (\Exception $e) {
                return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
            }
        }
    }

    public function projectEffortsData(Request $request)
    {
        $currentUserId = $request->user->id;
        $checkMapped = false;
        $pendingInitiaion = true;
        try {
            $userRole = Helpers::getRole($currentUserId);
            if (in_array($this->rolesArray[config('constant.ROLES.admin')], $userRole['global'])) {
                $userRole['department'] = Department::pluck('id')->toArray();
            }
            $projects = Project::with([
                'resourceRequisitionAllProject' => function ($query) use ($userRole) {
                    $query->whereIn('dept_id', $userRole['department']);
                },
                'ProjectRole' => function ($query) use ($currentUserId) {
                    $query->where('user_id', $currentUserId);
                },
            ])->whereIn('billing_type', config('constant.billing_type'))
                ->orderBy('created_at', 'desc')
                ->get();
            $projects = $this->removeUnAuthorizedProjects($projects, $currentUserId, $userRole, $checkMapped, $pendingInitiaion);
            $projectDetails = $this->getEstimateActualHours($projects);
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $projectDetails);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function projectActiveRisk(Request $request)
    {
        $currentUserId = $request->user->id;
        $checkMapped = false;
        $pendingInitiaion = true;
        try {
            $userRole = Helpers::getRole($currentUserId);
            if (in_array($this->rolesArray[config('constant.ROLES.admin')], $userRole['global'])) {
                $userRole['department'] = Department::pluck('id')->toArray();
            }
            $projects = Project::with([
                'ProjectRisk',
                'resourceRequisitionAllProject' => function ($query) use ($userRole) {
                    $query->whereIn('dept_id', $userRole['department']);
                },
                'ProjectRole' => function ($query) use ($currentUserId) {
                    $query->where('user_id', $currentUserId);
                }
            ])->whereIn('billing_type', config('constant.billing_type'))
                ->orderBy('created_at', 'desc')
                ->get();
            $projectsDetails = $this->removeUnAuthorizedProjects($projects, $currentUserId, $userRole, $checkMapped, $pendingInitiaion);
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $projectsDetails);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function addTrackerKeyInProjects($projects)
    {
        if (!empty($projects)) {
            foreach ($projects as $key => $value) {
                $value->track = ['status' => $value->status, 'is_approve' => $value->is_approve, 'is_draft' => $value->is_draft];
            }
        }
        return $projects;
    }

    public function getEstimateActualHours($projects)
    {
        if (!empty($projects)) {
            $timeResult = [];
            $estimateTime = [];
            foreach ($projects as $key => $value) {
                $value->actual_hours = 0;
                $value->estimated_hours = 0;
                if (isset($value->redmine_project_id)) {
                    $timeResult = TimeEntrie::where('project_id', '=', $value->redmine_project_id)->pluck('hours')->toArray();
                    $estimateTime = CustomValue::where('customized_id', '=', $value->redmine_project_id)->where('custom_field_id', '=', 32)->pluck('value')->toArray();
                }
                $value->actual_hours = array_sum($timeResult);
                $value->estimated_hours = array_sum($estimateTime);
            }
        }
        return $projects;
    }

    public function checkProjectInRisk($projects)
    {
        $projectInRiskArray = [];
        if (!empty($projects)) {
            foreach ($projects as $key => $value) {
                if (count($value->ProjectRisk) > 0) {
                    array_push($projectInRiskArray, $value->redmine_project_id);
                }
            }
        }
        return $projectInRiskArray;
    }

    public function allProjectActiveRisk($projects)
    {
        $allProjectRiskArray = [];
        if (!empty($projects)) {
            foreach ($projects as $key => $value) {
                if (count($value->ProjectRisk) > 0) {
                    foreach ($value->ProjectRisk as $result) {
                        $allProjectRiskArray[] = $value;
                    }
                }
            }
        }
        return $allProjectRiskArray;
    }

    public function wsrStatusSubmit($projects)
    {
        $allProjectSubmitWSR = [];
        if (!empty($projects)) {
            $today = Carbon::today();
            $weekNumber = $today->weekOfYear;
            foreach ($projects as $key => $value) {
                if (count($value->projectWSR) > 0) {
                    foreach ($value->projectWSR as $result) {
                        if ((int)$result->week_no == (int)$weekNumber && $result->overall_health_status!=4) {
                            array_push($allProjectSubmitWSR, $result);
                        }
                    }
                }
            }
        }
        return $allProjectSubmitWSR;
    }

    public function pmoProjectListing(Request $request)
    {
        $currentUserId = $request->user->id;
        $checkMapped = false;
        $pendingInitiaion = true;
        try {
            $userRole = Helpers::getRole($currentUserId);
            if (in_array($this->rolesArray[config('constant.ROLES.admin')], $userRole['global'])) {
                $userRole['department'] = Department::pluck('id')->toArray();
            }
            $projects = Project::with([
                'ProjectRole' => function ($query) use ($currentUserId) {
                    $query->where('user_id', $currentUserId);
                }
            ])
                ->orderBy('created_at', 'desc')
                ->get();
            $projectsListing = $this->removeUnAuthorizedProjects($projects, $currentUserId, $userRole, $checkMapped, $pendingInitiaion);
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $projectsListing);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function projectAtRisk(Request $request)
    {
        $currentUserId = $request->user->id;
        $checkMapped = false;
        $pendingInitiaion = true;
        try {
            $userRole = Helpers::getRole($currentUserId);
            if (in_array($this->rolesArray[config('constant.ROLES.admin')], $userRole['global'])) {
                $userRole['department'] = Department::pluck('id')->toArray();
            }
            $projects = Project::with([
                'projectManagers', 'accountManagers', 'ProjectRisk', 'ProjectRole' => function ($query) use ($currentUserId) {
                    $query->where('user_id', $currentUserId);
                }
            ])->select("id", "uuid", "redmine_project_id", "project_name")->whereIn('billing_type', config('constant.billing_type'))
                ->orderBy('created_at', 'desc')
                ->get();

            $projectsDetails = $this->removeUnAuthorizedProjects($projects, $currentUserId, $userRole, $checkMapped, $pendingInitiaion);
            $allProjectActiveRisk = $this->allProjectAtRisk($projectsDetails);
            $riskProjectDataCount = $this->riskProjectDataCount($allProjectActiveRisk);
            foreach ($riskProjectDataCount as $key => $val) {
                if ($val->simplifiedArray['count'] == 0) {
                    $val->simplifiedArray = [];
                }
            }

            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $riskProjectDataCount);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function allProjectAtRisk($projects)
    {
        $allProjectRiskArray = [];
        if (!empty($projects)) {
            foreach ($projects as $key => $value) {
                $count = count($value->ProjectRisk);
                if ($count > 0) {
                    $allProjectRiskArray[] = $value;
                }
            }
        }
        return $allProjectRiskArray;
    }

    public function riskProjectDataCount($allProjectActiveRisk)
    {
        if (!empty($allProjectActiveRisk)) {
            $simplifiedArray = [];
            foreach ($allProjectActiveRisk as $key => $value) {
                $simplifiedArray['risk_sum'] = 0;
                $simplifiedArray['count'] = 0;
                $assignedIds = [];
                $categoryIds = [];
                if (count($value->ProjectRisk) > 0) {
                    foreach ($value->ProjectRisk as $result) {
                        if (!in_array($result->assigned_to_id, $assignedIds) && !empty($result->assigned_to_id)) {
                            $assignedIds[] = ['id' => $result->assigned_to_id, 'name' => \Helpers::getUserName($result->assigned_to_id)];
                        }
                        if (!in_array($result->riskCategory, $assignedIds) && !empty($result->riskCategory)) {
                            $categoryName = strtolower($result->riskCategory->value);
                            $categoryIds[] =  ['id' => $result->riskCategory->customized_id, 'name' => ucfirst($categoryName)];
                        }
                        if (isset($simplifiedArray['risk_sum']) && !empty($simplifiedArray['risk_sum'])) {
                            if (isset($result->probability) && isset($result->impact)) {
                                $simplifiedArray['risk_sum'] += ($result->impact->value * $result->probability->value);
                            }
                            $simplifiedArray['count']++;
                        } else {
                            if (isset($result->probability) && isset($result->impact)) {
                                $simplifiedArray['risk_sum'] += ($result->impact->value * $result->probability->value);
                            }
                            $simplifiedArray['count'] = 1;
                        }
                        $simplifiedArray['risk_sum'] = round($simplifiedArray['risk_sum'], 2);
                    }
                }
                $simplifiedArray['assigned_id'] = (!empty($assignedIds)) ? $assignedIds : '';
                $simplifiedArray['category_to_id'] = (!empty($categoryIds)) ? $categoryIds : '';
                $value->simplifiedArray = (!empty($simplifiedArray)) ? $simplifiedArray : [];
                $allProjectRiskArray[] = $value;
            }
        }
        return $allProjectRiskArray;
    }

    public function partnerCollaboration(Request $request)
    { {
            try {
                $partnerList = PartnerCollaboration::get();
                $count = $partnerList->count();
                $resultArray = ['newCollaboration' => $partnerList, 'count' => $count];
                return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $resultArray);
            } catch (\Exception $e) {
                return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
            }
        }
    }
}
