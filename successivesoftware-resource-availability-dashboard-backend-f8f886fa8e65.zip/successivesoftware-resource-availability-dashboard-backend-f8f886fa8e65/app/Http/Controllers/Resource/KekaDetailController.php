<?php

namespace App\Http\Controllers\Resource;

use App\Http\Controllers\Controller;
use App\Models\Department;
use App\Models\ExperiencePercent;
use App\Models\Pyramid;
use App\Models\UserRole;
use App\User;
use Illuminate\Http\Request;
use Successive\Keka\Http\Services\EmployeeService;
use ApiResponse;
use Carbon\Carbon;
use Helpers;
use Log;
use App\Models\CustomValueApi;


class KekaDetailController extends Controller
{
    protected $helpers;
    /**
     * KekaDetailController constructor.
     */
    public function __construct(Helpers $helpers)
    {
        $this->helpers = $helpers;
        $this->rolesArray = Helpers::getRoleByModel('Role');
        $this->departmentArray = Helpers::getRoleByModel('Department');
    }
    public static $validationRules = [
        'experience_data' => 'array',
        'experience_data.*.percent' => 'required|numeric|between:0,100',
        'experience_data.*.min_experience' => 'required|numeric|between:0,35',
        'experience_data.*.max_experience' => 'required|numeric|between:0,35',
        'dept_id' => 'required|exists:resource_mysql.departments,id',
        'employee_count' => 'required|numeric',

    ];

    public static $validationUpdateRules = [
        'experience_data' => 'array',
        'experience_data.*.percent' => 'required|numeric|between:0,100',
        'experience_data.*.min_experience' => 'required|numeric|between:0,35',
        'experience_data.*.max_experience' => 'required|numeric|between:0,35',
        'dept_id' => 'required|exists:resource_mysql.departments,id',
        'employee_count' => 'required|numeric',
        'pyramid_id' =>  'required|exists:resource_mysql.pyramids,uuid',
    ];

    public static $validationCountRules = [
        'min' => 'required|numeric',
        'max' => 'required|numeric',
        'dept_id' => 'required|exists:resource_mysql.departments,id',
    ];

    public static $validationGetRules = [
        'pyramid_id' => 'required|exists:resource_mysql.pyramids,uuid',
    ];

    /**
     * @OA\Get(
     *     path="/v1/pyramid-employee/{deptId}",
     *     operationId="/v1/pyramid/getAllEmployeeDetails",
     *     summary="Fetch all pyramid details",
     *     tags={"pyramid"},
     *     @OA\Parameter(
     *         name="deptId",
     *         in="path",
     *         description="Department id or instant of department id can use default",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\Response(
     *         response="200",
     *         description="Returns all employee details from keka",
     *         @OA\JsonContent()
     *     ),
     *     @OA\Response(
     *         response="default",
     *         description="unexpected error",
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     */

    public function getAllEmployeeDetails(Request $request, $deptId)
    {
        try{
            $dataDepartmentWise = [];
            $dataDepartmentWise['users'] = [];
            $dataDepartmentWise['department'] = '';
            $departmentName = '';
            $currentUserId = $request->user->id;
            $globalDepartment = null;
            $userRole = Helpers::getRole($currentUserId);
            $projectRole = UserRole::has('project')->where('user_id', $currentUserId)->first();
            if( $projectRole || isset($userRole['global'][0])) {
                if ($deptId == 'default') {
                    if (in_array(Helpers::getRoleIdByCode(config('constant.ROLES.bu_head')), $userRole['global'])) {
                        $globalDepartment = Department::where('id', $userRole['department'][0])->first();
                    } else {
                        $userDepartments = Helpers::getUserDepartments($currentUserId);
                        if (isset($userDepartments[0])) {
                            $globalDepartment = Department::where('name', $userDepartments[0])->first();
                        }
                    }
                }
                else {
                    $globalDepartment = Department::where('id', $deptId)->first();
                }
                if ($globalDepartment) {
                    $departmentName = $globalDepartment->name;
                }
                $result = Helpers::getKekaData();
                foreach ($result as $key => $value) {
                    foreach ($value['groups'] as $groups) {
                        if ($groups['groupType'] == 1) {
                            $department = $groups['title'];
                            break;
                        }
                    }
                    if (trim(strtolower(str_replace( array( '\'', '"', ',' , ';', '<', '>', ' ', '-', '_', '.', '%', '@'), '', $department))) ==
                        trim(strtolower(str_replace( array( '\'', '"', ',' , ';', '<', '>', ' ', '-', '_', '.', '%', '@'), '', $departmentName)))) {
                        $PriviousExp = 0;
                        foreach ($value['experienceDetails'] as $experienceDetails) {
                            if (isset($experienceDetails['dateOfJoining']) && isset($experienceDetails['dateOfRelieving'])) {
                                $dateOfJoining = Carbon::createFromDate($experienceDetails['dateOfJoining']);
                                $dateOfRelieving = Carbon::createFromDate($experienceDetails['dateOfRelieving']);
                                $PriviousExp = $PriviousExp + $dateOfJoining->diffInDays($dateOfRelieving);
                            }
                        }
                        $dateOfJoining = Carbon::createFromDate($value['joiningDate']);
                        $now = Carbon::now();
                        $currentExp = $dateOfJoining->diffInDays($now);
                        $totaldays = $PriviousExp + $currentExp;
                        $years = ($totaldays / 365); // days / 365 days
                        $years1 = round($years, 1);
                        $years = floor($years); // Remove all decimals
                        $month = ($totaldays % 365) / 30.5; // I choose 30.5 for Month (30,31) ;)
                        $month = floor($month); // Remove all decimals
                        $data = [
                            'experienceInYearMonth' => $years . " years " . $month . " months",
                            'experience' => $years1,
                            'employeeNumber' => $value['employeeNumber'],
                            'displayName' => $value['displayName'],
                            'email' => $value['email'],
                            'jobTitle' => $value['jobTitle']['title']
                        ];
                        $dataDepartmentWise['users'][] = $data;
                    }
                }
                $dataDepartmentWise['department'] = $globalDepartment;
            }
            $response = $dataDepartmentWise;
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'),$response);
        }catch(\Exception $e ) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'),'',$e->getMessage());
        }
    }

    /**
     * @OA\Post(
     *     path="/v1/pyramid",
     *     summary="Pyramid Post",
     *     operationId="/v1/pyramid",
     *     tags={"pyramid"},
     *     @OA\RequestBody(
     *         required=true,
     *         description="Post object",
     *         @OA\JsonContent(ref="#/components/schemas/PyramidPost")
     *     ),
     *     @OA\Response(
     *         response=201,
     *         description="A post",
     *         @OA\JsonContent(),
     *     ),
     *     @OA\Response(
     *         response="default",
     *         description="unexpected error",
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     * @throws \Illuminate\Validation\ValidationException
     *
     */

    public function store(Request $request)
    {
        $this->validate($request, self::$validationRules);
        try {
            $pyramid = Pyramid::where('dept_id', $request->dept_id)->first();
            if($pyramid){
                $pyramid = $this->updatePyramid($request, $pyramid->uuid);
            }else{
                $data = [
                    'dept_id' => $request->dept_id,
                    'created_by' => $request->user->id,
                    'employee_count' => $request->employee_count,
                ];
                $pyramid = new Pyramid($data);
                $pyramid->save();
                ExperiencePercent::saveExperiencePercent($pyramid->uuid, $request);
                $pyramid->load('ExperiencePercent');
            }
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusCreated'), $pyramid);
        } catch (\Exception $e) {
            Log::error($this->helpers->addToLog($request, $e->getMessage(), config('constant.LOG_ACTIONS.pyramid_create')));
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    /**
     *
     * @OA\Get(
     *     path="/v1/pyramid",
     *     operationId="/v1/pyramid/index",
     *     summary="Fetch all pyramid details",
     *     tags={"pyramid"},
     *     @OA\Response(
     *         response="200",
     *         description="Returns all Pyramid",
     *         @OA\JsonContent()
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function index()
    {
       try {
           $pyramids = Pyramid::with('ExperiencePercent')
                ->orderBy('created_at', 'desc')
                ->get();

            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $pyramids);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    /**
     * @OA\Get(
     *     path="/v1/pyramid/{pyramidId}",
     *     summary="Fetch one pyramid details",
     *     operationId="/v1/pyramid/show",
     *     tags={"pyramid"},
     *     @OA\Parameter(
     *         name="pyramidId",
     *         in="path",
     *         description="Pyramid UUID",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\Response(
     *         response="200",
     *         description="Returns one Pyramid",
     *         @OA\JsonContent()
     *     ),
     *     @OA\Response(
     *         response="default",
     *         description="unexpected error",
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     */
    public function show(Request $request, $pyramidId)
    {
        $request->merge(['pyramid_id' => $pyramidId]);
        $this->validate($request, self::$validationGetRules);
        try {
            $pyramid = Pyramid::with('ExperiencePercent')
                        ->where('uuid', $pyramidId)
                        ->orderBy('created_at', 'desc')
                        ->first();

            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $pyramid);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }


    /**
     * @OA\Put(
     *     path="/v1/pyramid/{pyramidId}",
     *     summary="Pyramid Update",
     *     operationId="/v1/pyramid/{pyramidId}",
     *     tags={"pyramid"},
     *     @OA\Parameter(
     *         name="pyramidId",
     *         in="path",
     *         description="Pyramid UUID",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\RequestBody(
     *         required=true,
     *         description="Post object",
     *         @OA\JsonContent(ref="#/components/schemas/PyramidUpdate")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="A put",
     *         @OA\JsonContent(),
     *     ),
     *     @OA\Response(
     *         response="default",
     *         description="unexpected error",
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     *
     * @param Request $request
     * @param $uuid
     * @return \Illuminate\Http\JsonResponse
     * @throws \Illuminate\Validation\ValidationException
     */
    public function update(Request $request, $pyramidId)
    {
        $request->merge(['pyramid_id' => $pyramidId]);
        $this->validate($request, self::$validationUpdateRules);
        try {
            $pyramid = $this->updatePyramid($request, $pyramidId);
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $pyramid);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function updatePyramid($request, $pyramidId){
        $pyramid = Pyramid::where('uuid', $pyramidId)->first();
//            Delete All Experience Percent for Pyramid Id
        ExperiencePercent::where('pyramid_id', $pyramidId)->delete();
        $data = [
            'dept_id' => $request->dept_id,
            'employee_count' => $request->employee_count,
            'updated_by' => $request->user->id,
        ];
        $pyramid->update($data);
        ExperiencePercent::saveExperiencePercent($pyramidId, $request);
        $pyramid->load('ExperiencePercent');
        return $pyramid;
    }

    public function getExperienceCount(Request $request)
    {
        try{
            $this->validate($request, self::$validationCountRules);
            $min = $request->get('min');
            $max = $request->get('max');
            $deptId = $request->get('dept_id');
            $reqResourceCount = 0;
            $departmentWiseUsers = $this->getDepartmentData($deptId);
            $DepartmentExpSlots = $this->getDepartmentExpSlot($deptId);
            $userCountExpSlotWise = $this->getUserCountExpSlotWise($departmentWiseUsers, $DepartmentExpSlots);
            $totalRequireCount = $this->totalRequireResourceCount($userCountExpSlotWise);
            $ExpSlotsWithAllData = $this->CalculateCount($totalRequireCount, $userCountExpSlotWise);
            foreach ($ExpSlotsWithAllData as $value){
                if(($max > $value->min_experience && $min < $value->max_experience)){
                    $reqResourceCount = $reqResourceCount + $value->reuire_count;
                }
            }
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $reqResourceCount);
        }catch(\Exception $e ) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'),'',$e->getMessage());
        }
    }

    public function totalRequireResourceCount($DepartmentExpSlots){
        $maxValue = 0;
        foreach ($DepartmentExpSlots as $expSlot){
           $count = ($expSlot->count == 0) ? 1 : $expSlot->count;
           $value = ($count * 100)/$expSlot->percent;
           if($value > $maxValue){
               $maxValue = $value;
           }
        }
        return $maxValue;
    }

    public function CalculateCount($totalCount, $expSlots){
        $data = [];
        foreach ($expSlots as $expSlot){
            $totalRequireExpWiseCount = round($totalCount * $expSlot->percent / 100);
            if($totalRequireExpWiseCount > $expSlot->count){
                $value = $totalRequireExpWiseCount - $expSlot->count;
            }else{
                $value = 0;
            }
            $expSlot->reuire_count = $value;
            $data[] = $expSlot;
        }
        return $data;
    }

    public function getUserCountExpSlotWise($departmentWiseUsers, $DepartmentExpSlots){
        $data = [];
        foreach ($DepartmentExpSlots as $expSlot){
            $expSlot->count = 0;
            foreach ($departmentWiseUsers as $user){
                if($user['experience'] >= $expSlot->min_experience && $user['experience'] < $expSlot->max_experience){
                        $expSlot->count = $expSlot->count + 1;
                }
            }
            $data[] = $expSlot;
        }
        return $data;
    }

    public function getDepartmentExpSlot($deptId){
        $pyramid = Pyramid::with('ExperiencePercent')
            ->where('dept_id', $deptId)->first();
        if(isset($pyramid['ExperiencePercent'])){
            return $pyramid['ExperiencePercent'];
        }else{
            return [];
        }

    }

    public function getDepartmentData($deptId){
        $dataDepartmentWiseUsers = [];
        $departmentName = '';
        $globalDepartment = null;
        $globalDepartment = Department::where('id', $deptId)->first();
        if ($globalDepartment) {
            $departmentName = $globalDepartment->name;
        }
        $result = Helpers::getKekaData();
        foreach ($result as $key => $value) {
            foreach ($value['groups'] as $groups) {
                if ($groups['groupType'] == 1) {
                    $department = $groups['title'];
                    break;
                }
            }
            if (trim(strtolower(str_replace( array( '\'', '"', ',' , ';', '<', '>', ' ', '-', '_', '.', '%', '@'), '', $department))) ==
                trim(strtolower(str_replace( array( '\'', '"', ',' , ';', '<', '>', ' ', '-', '_', '.', '%', '@'), '', $departmentName)))) {
                $PriviousExp = 0;
                foreach ($value['experienceDetails'] as $experienceDetails) {
                    if (isset($experienceDetails['dateOfJoining']) && isset($experienceDetails['dateOfRelieving'])) {
                        $dateOfJoining = Carbon::createFromDate($experienceDetails['dateOfJoining']);
                        $dateOfRelieving = Carbon::createFromDate($experienceDetails['dateOfRelieving']);
                        $PriviousExp = $PriviousExp + $dateOfJoining->diffInDays($dateOfRelieving);
                    }
                }
                $dateOfJoining = Carbon::createFromDate($value['joiningDate']);
                $now = Carbon::now();
                $currentExp = $dateOfJoining->diffInDays($now);
                $totaldays = $PriviousExp + $currentExp;
                $years = ($totaldays / 365); // days / 365 days
                $years1 = round($years, 1);
                $years = floor($years); // Remove all decimals
                $month = ($totaldays % 365) / 30.5; // I choose 30.5 for Month (30,31) ;)
                $month = floor($month); // Remove all decimals
                $data = [
                    'experienceInYearMonth' => $years . " years " . $month . " months",
                    'experience' => $years1,
                    'employeeNumber' => $value['employeeNumber'],
                ];

                $dataDepartmentWiseUsers[] = $data;
            }
        }
        return $dataDepartmentWiseUsers;
    }

    public function Department()
    {
        try{
            $departments = Department::whereNotIn('code', ['client'])->get();
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'),$departments);
        }catch(\Exception $e ) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'),'',$e->getMessage());
        }
    }

}
