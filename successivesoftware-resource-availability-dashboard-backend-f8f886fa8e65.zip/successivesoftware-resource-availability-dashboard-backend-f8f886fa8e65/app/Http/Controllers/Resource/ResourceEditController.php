<?php

namespace App\Http\Controllers\Resource;

use App\Libraries\MailService;
use App\Models\Department;
use App\Models\ResourceRequisition;
use App\Models\PerformedActionLog;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Project;
use App\Models\ResourceAllocation;
use App\Models\ResourceAllocationMeta;
use App\Models\ProjectAction;
use Helpers;
use Carbon\Carbon;
use Log;
use ApiResponse;
use App\Models\ResourceMapping;
use App\Traits\ResourceControllerTraits;
use App\Models\LocalUser;
use App\Http\Controllers\Resource\ResourceMappingController;

class ResourceEditController extends Controller
{
    use ResourceControllerTraits;
    protected $helpers;
    public $rolesArray;

    public function __construct(Helpers $helpers)
    {
        $this->helpers = $helpers;
        $this->rolesArray = Helpers::getRoleByModel('Role');
    }

    public static $validationRules = [
        'allocation_data' => 'array',
        'allocation_data.*.efforts' => 'required',
        'allocation_data.*.resource_req_id' => 'required',
        'allocation_data.*.experience' => 'required',
        'allocation_data.*.start_date' => 'required',
        'allocation_data.*.end_date' => 'required',
        'allocation_data.*.resource_id' => 'required',
        'allocation_data.*.isDelete' => 'required',
        'project_id' => 'required'

    ];

    public static $allocationValidationRules = [
        'allocation_data' => 'array',
        'allocation_data.*.efforts' => 'required',
        'allocation_data.*.experience' => 'required',
        'allocation_data.*.dept_id' => 'required',
        'allocation_data.*.department' => 'string',
        'allocation_data.*.tech_id' => 'required',
        'allocation_data.*.role_id' => 'required',
        'allocation_data.*.start_date' => 'required',
        'allocation_data.*.end_date' => 'required',
        'allocation_data.*.resource_id' => 'required|exists:redmine_db_mysql.users,id',
        'project_id' => 'required|exists:resource_mysql.projects,uuid'

    ];

    /**
     *
     * @OA\Get(
     *     path="/v1/edit-allocation-list/{projectUuid}",
     *     operationId="/edit-allocation-list/{projectUuid}",
     *     summary="Fetch Edit Allocated resources List using projectUuid",
     *     tags={"Resource-allocation"},
     *     @OA\Parameter(
     *         name="projectUuid",
     *         in="path",
     *         description="Project UUID",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\Response(
     *         response="200",
     *         description="Returns Edit Allocated Resources List",
     *         @OA\JsonContent()
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     *
     * Fetch Edit resource allocation List
     */
    public function show(Request $request, $projectUuid)
    {
        try {
            $response = $this->editAllocationList($request->user->id, $projectUuid, true);
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $response);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    /**
     * @OA\Put(
     *     path="/v1/edit-allocation",
     *     summary="Edit Resource Allocation",
     *     operationId="/v1/edit-allocation",
     *     tags={"Resource-allocation"},
     *     @OA\RequestBody(
     *         required=true,
     *         description="Post object",
     *         @OA\JsonContent(ref="#/components/schemas/EditAllocation")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="A post",
     *         @OA\JsonContent(),
     *     ),
     *     @OA\Response(
     *         response="default",
     *         description="unexpected error",
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     *
     * Api for Edit Resource Allocation
     */
    public function update(Request $request)
    {
        $this->validate($request, self::$validationRules);
        $requestData = $request->toArray();
        $updatedRequsitionArray = [];
        $updatedAllocationArray = [];
        $deletedAllocation = [];
        $editAllocation = [];
        $deleteAllocationIds = [];
        $deleteRequisitionsIds = [];
        $deleteMappingsIds = [];
        $requisationIDArray = [];
        $requisationDelIDArray = [];
        $directDeleteArray = [];
        $flag = false;
        $directAllocation = true;

        try {
            if (isset($requestData['allocation_data'])) {
                $projectDetails = Project::where('uuid', $requestData['project_id'])->first();
                foreach ($requestData['allocation_data'] as $value) {
                    //old status
                    //$resourceRequisition = ResourceRequisition::where('uuid', $value['resource_req_id'])->first();
                    $resourceRequisition = ResourceRequisition::with(['resource', 'requestedUser'])->where('uuid', $value['resource_req_id'])->first();
                    $value['oldStatus'] = ResourceAllocation::where('uuid', $value['allocated_resource_id'])->pluck('allocation_status')->first();
                    if ($value['isDelete']) {
                        $department = $this->getDepatmentIdFromAllocatedResourcesUuid($value['allocated_resource_id']);
                        if ($value['directAllocateResource']) {
                            array_push($deleteAllocationIds, $value['allocated_resource_id']);
                            array_push($deleteRequisitionsIds, $value['resource_req_id']);
                            array_push($deleteMappingsIds, $value['allocated_resource_id']);
                        } else {
                            $flag = true;
                            $response = $this->allocationRemove($value['allocated_resource_id']);
                        }
                        $action = config('constant.LOG_ACTIONS.delete_allocation');
                        $value['resource_name'] = Helpers::getUserName($value['resource_id']);
                        $value['employee_code'] = Helpers::getEmployeeCode($value['resource_id']);
                        $value['employee_email'] = Helpers::getUserEmail($value['resource_id']);
                        $value['billing_type'] = \Helpers::getBillableType($resourceRequisition['billing_type']);
                        $value['type'] = $resourceRequisition['type'];
                        $value['IsFullystatus'] = $this->isFullAllocationAgainstAllocatedResource($value);
                        //current status
                        $value['currentStatus'] = ResourceAllocation::where('uuid', $value['allocated_resource_id'])->pluck('allocation_status')->first();
                        $value['status'] = $this->getMappingStatus($value['allocated_resource_id'], $projectDetails['uuid']);
                        $value['resource_requisition'] = $resourceRequisition;
                        $value['tech_id'] = $resourceRequisition['tech_id'];
                        $value['tech_name'] = \Helpers::getTechnolgyNameByID($resourceRequisition['tech_id']);
                        $value['role_id'] = $resourceRequisition['role_id'];
                        $value['role_name'] = \Helpers::getDesignationNameByID($resourceRequisition['role_id']);
                        array_push($deletedAllocation, $value);
                    } else {
                        if ($value['directAllocateResource']) {
                            $response = $this->updateDirectAllocationResource($value, $request->user->id, $requestData['project_id']);
                        } else {
                            $flag = true;
                            $response = $this->updateAllocatedResourceWithStatus($value, $request->user->id, $requestData['project_id']);
                        }
                        $action = config('constant.LOG_ACTIONS.edit_allocation');
                        $value['resource_name'] = Helpers::getUserName($value['resource_id']);
                        $value['employee_code'] = Helpers::getEmployeeCode($value['resource_id']);
                        $value['employee_email'] = Helpers::getUserEmail($value['resource_id']);
                        $value['billing_type'] = \Helpers::getBillableType($resourceRequisition['billing_type']);
                        $value['type'] = $resourceRequisition['type'];
                        $value['IsFullystatus'] = $this->isFullAllocationAgainstAllocatedResource($value);
                        //current status
                        $value['currentStatus'] = ResourceAllocation::where('uuid', $value['allocated_resource_id'])->pluck('allocation_status')->first();
                        $value['status'] = $this->getMappingStatus($value['allocated_resource_id'], $projectDetails['uuid']);
                        $value['resource_requisition'] = $resourceRequisition;
                        $value['tech_id'] = $resourceRequisition['tech_id'];
                        $value['tech_name'] = \Helpers::getTechnolgyNameByID($resourceRequisition['tech_id']);
                        $value['role_id'] = $resourceRequisition['role_id'];
                        $value['role_name'] = \Helpers::getDesignationNameByID($resourceRequisition['role_id']);
                        array_push($editAllocation, $value);
                    }
                    if (!$value['directAllocateResource']) {
                        if (!in_array($value['resource_req_id'], $updatedRequsitionArray)) {
                            array_push($updatedRequsitionArray, $value['resource_req_id']);
                        }
                        if (!in_array($value['allocated_resource_id'], $updatedAllocationArray)) {
                            array_push($updatedAllocationArray, $value['allocated_resource_id']);
                        }
                    }
                }
                ResourceMapping::whereIn('allocated_resource_id', $deleteMappingsIds)->delete();
                ResourceAllocation::whereIn('uuid', $deleteAllocationIds)->delete();
                ResourceRequisition::whereIn('uuid', $deleteRequisitionsIds)->delete();
                if (!empty($updatedRequsitionArray) || $directAllocation) {
                    if ($flag) {
                        $editAllocationArray = $this->getEditAllocationUuidArray($request->user->id, $requestData['project_id'], $updatedRequsitionArray);
                        $this->updateRequisitionStatus($updatedRequsitionArray, $editAllocationArray);
                        $this->updateProjectStatusAccordingResources($requestData['project_id']);
                    }
                    if (!empty($editAllocation)) {
                        $trueArrayAllocation = [];
                        $partialArray = [];
                        $mailEditArray = [];
                        $directArray = [];
                        $normalAllocation = [];
                        foreach ($editAllocation as $checkstatus) {
                            if ($checkstatus['oldStatus'] == '14' && $checkstatus['currentStatus'] == '4') {
                                array_push($trueArrayAllocation, $checkstatus);
                                array_push($normalAllocation, $checkstatus);
                            } elseif ($checkstatus['oldStatus'] == '4' && $checkstatus['currentStatus'] == '4') {
                                array_push($partialArray, $checkstatus);
                                array_push($normalAllocation, $checkstatus);
                            } elseif ($checkstatus['oldStatus'] == '14' && $checkstatus['currentStatus'] == '14' && $checkstatus['directAllocateResource'] == 'true') {
                                array_push($directArray, $checkstatus);
                            } elseif ($checkstatus['oldStatus'] == '4' && $checkstatus['currentStatus'] == '14') {
                                array_push($requisationIDArray, $checkstatus['resource_req_id']);
                                array_push($normalAllocation, $checkstatus);
                            }
                        }
                        if (!empty($trueArrayAllocation)) {
                            array_push($mailEditArray, config('constant.TEMPLATES.edit_allocation_rm'));
                        }
                        if (!empty($directArray)) {
                            array_push($mailEditArray, config('constant.TEMPLATES.edit_direct_allocation'));
                        }
                        if (!empty($partialArray)) {
                            array_push($mailEditArray, config('constant.TEMPLATES.edit_allocation'));
                        }
                        foreach ($mailEditArray as $val) {
                            if ($val == 'edit_allocation_rm') {
                                $mailArray = $trueArrayAllocation;
                            } elseif ($val == 'edit_direct_allocation') {
                                $mailArray = $directArray;
                            } else {
                                $mailArray = $partialArray;
                            }
                            $mailService = new MailService($val, $requestData['project_id'], $mailArray);
                            $mailService->sendMail();
                        }
                        if (!empty($requisationIDArray)) {
                            $allocatedIDArray = ResourceAllocation::whereIn('resource_req_id', $requisationIDArray)->pluck('uuid')->toArray();
                            Helpers::sendProjectMappingMailWithAllocationId($requestData['project_id'], $allocatedIDArray);
                        }
                        if (!empty($directArray)) {
                            Log::info($this->helpers->addToLog($requestData['project_id'], $request, $directArray, config('constant.LOG_ACTIONS.edit_direct_allocation')));
                            $this->helpers->addlogActivityDB($requestData['project_id'], $request, $directArray, config('constant.LOG_ACTIONS.edit_direct_allocation'));
                        }
                        if (!empty($normalAllocation)) {
                            Log::info($this->helpers->addToLog($requestData['project_id'], $request, $normalAllocation, config('constant.LOG_ACTIONS.edit_allocation')));
                            $this->helpers->addlogActivityDB($requestData['project_id'], $request, $normalAllocation, config('constant.LOG_ACTIONS.edit_allocation'));
                        }
                    }

                    if (!empty($deletedAllocation)) {
                        $truedeleteAllocation = [];
                        $mailDeleteArray = [];
                        $partialDelArray = [];
                        $normalDelAllocation = [];
                        foreach ($deletedAllocation as $checkstatus) {
                            if ($checkstatus['oldStatus'] == '14' && $checkstatus['currentStatus'] == null) {
                                array_push($normalDelAllocation, $checkstatus);
                                array_push($truedeleteAllocation, $checkstatus);
                            } elseif ($checkstatus['oldStatus'] == '4' && $checkstatus['currentStatus'] == null) {
                                array_push($partialDelArray, $checkstatus);
                                array_push($normalDelAllocation, $checkstatus);
                                array_push($requisationDelIDArray, $checkstatus['resource_req_id']);
                            } elseif ($checkstatus['oldStatus'] == '14' && $checkstatus['currentStatus'] == '14' && $checkstatus['directAllocateResource'] == 'true') {
                                array_push($directDeleteArray, $checkstatus);
                            } elseif ($checkstatus['oldStatus'] == '4' && $checkstatus['currentStatus'] == '14') {
                                array_push($requisationDelIDArray, $checkstatus['resource_req_id']);
                                array_push($normalDelAllocation, $checkstatus);
                            }
                        }

                        if (!empty($truedeleteAllocation)) {
                            array_push($mailDeleteArray, config('constant.TEMPLATES.delete_allocation_rm'));
                        }
                        if (!empty($directDeleteArray)) {
                            array_push($mailDeleteArray, config('constant.TEMPLATES.delete_direct_allocation'));
                        }
                        if (!empty($partialDelArray)) {
                            array_push($mailDeleteArray, config('constant.TEMPLATES.delete_allocation'));
                        }

                        foreach ($mailDeleteArray as $val) {
                            if ($val == 'delete_allocation_rm') {
                                $mailArrayDel = $truedeleteAllocation;
                            } elseif ($val == 'delete_direct_allocation') {
                                $mailArrayDel = $directDeleteArray;
                            } else {
                                $mailArrayDel = $partialDelArray;
                            }
                            $mailService = new MailService($val, $requestData['project_id'], $mailArrayDel);
                            $mailService->sendMail();
                        }
                        if (!empty($requisationDelIDArray)) {
                            $allocatedIDArray = ResourceAllocation::whereIn('resource_req_id', $requisationDelIDArray)->pluck('uuid')->toArray();
                            Helpers::sendProjectMappingMailWithAllocationId($requestData['project_id'], $allocatedIDArray);
                        }
                        if (!empty($directDeleteArray)) {
                            Log::info($this->helpers->addToLog($requestData['project_id'], $request, $directDeleteArray, config('constant.LOG_ACTIONS.delete_direct_allocation')));
                            $this->helpers->addlogActivityDB($requestData['project_id'], $request, $directDeleteArray, config('constant.LOG_ACTIONS.delete_direct_allocation'));
                        }
                        if (!empty($normalDelAllocation)) {
                            Log::info($this->helpers->addToLog($requestData['project_id'], $request, $normalDelAllocation, config('constant.LOG_ACTIONS.delete_allocation')));
                            $this->helpers->addlogActivityDB($requestData['project_id'], $request, $normalDelAllocation, config('constant.LOG_ACTIONS.delete_allocation'));
                        }
                    }
                }
            }

            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), true);
        } catch (\Exception $e) {
            Log::error($this->helpers->addToLog($requestData['project_id'], $request, $e->getMessage(), $action));
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function updateDirectAllocationResource($data, $userId, $projectId)
    {
        $allocationStatus = config('constant.PROJECT_ACTION')['resource_allocation_response_accept'];
        $updatedRequisition = [
            'efforts' => $data['efforts'],
            'experience' => $data['experience'],
            'start_date' => $data['start_date'],
            'end_date' => $data['end_date']
        ];
        $response = ResourceRequisition::where('uuid', $data['resource_req_id'])->update($updatedRequisition);
        $map = [
            'project_id' => $projectId,
            'resource_id' => $data['resource_id'],
            'hours' => $data['efforts'],
            'start_date' => $data['start_date'],
            'end_date' => $data['end_date'],
            'status' => '0'
        ];
        ResourceMapping::updateOrCreate(['allocated_resource_id' => $data['allocated_resource_id']], $map);
        ResourceAllocation::updateResourceAllocationTableData($data['allocated_resource_id'], $userId, $allocationStatus, $data['experience']);
        ResourceAllocationMeta::fullyDeallocateResource($data['allocated_resource_id']);
        ResourceAllocationMeta::storeResourceAllocationMeta($data['allocated_resource_id'], $data['start_date'], $data['end_date'], $data['efforts'], $data['resource_id']);
        return $response;
    }

    public function updateRequisitionStatus($requisitionArray, $allocationArray)
    {
        if (isset($requisitionArray)) {
            foreach ($requisitionArray as $requisitionId) {
                $allocationDone = false;
                $requisitionRecord = ResourceRequisition::with('resourceAllocation', 'DirectRequisition')->where('uuid', $requisitionId)->first();
                if (isset($requisitionRecord['DirectRequisition'])) {
                    continue;
                }
                if (count($requisitionRecord['resourceAllocation']) == 0) {
                    PerformedActionLog::where(
                        [
                            'project_id' => $requisitionRecord['project_id'],
                            'user_action_id' => config('constant.USER_ACTIONLIST.resource-allocation'),
                            'dept_id' => $requisitionRecord['dept_id']
                        ]
                    )->delete();
                    ResourceRequisition::where('uuid', $requisitionId)->update(['status' => config('constant.PERFORM_ACTIONLOG.inProgress')]);
                } else {
                    $flag = true;
                    foreach ($requisitionRecord['resourceAllocation'] as $allocation) {
                        if ($allocation['allocation_status'] == config('constant.PROJECT_ACTION')['resource_allocation_response_accept'] || $allocation['allocation_status'] == config('constant.PROJECT_ACTION')['resource_de_allocation_response_accept']) {
                            continue;
                        }
                        if (
                            $allocation['allocation_status'] == config('constant.PROJECT_ACTION')['resource_allocation_response_decline'] ||
                            $requisitionRecord['efforts'] != $allocation['resourceAllocationMeta'][0]['hours'] ||
                            Carbon::parse($requisitionRecord['start_date'])->notEqualTo(Carbon::parse($allocation['resourceAllocationMeta'][0]['start_date'])) ||
                            Carbon::parse($requisitionRecord['end_date'])->notEqualTo(Carbon::parse($allocation['resourceAllocationMeta'][0]['end_date'])) ||
                            $requisitionRecord['experience'] != $allocation['experience']
                        ) {

                            $flag = false;
                            break;
                        }
                        if ($requisitionRecord['type'] == 1 && $requisitionRecord['extension_resource_id'] != null && $allocation['resource_id'] != $requisitionRecord['extension_resource_id']) {
                            $flag = false;
                        }
                    }
                    if ($flag && $requisitionRecord['no_of_resource'] == count($requisitionRecord['resourceAllocation'])) {
                        $allocationDone = true;
                        ResourceAllocation::whereIn('uuid', $allocationArray)->update(['allocation_status' => config('constant.PROJECT_ACTION')['resource_allocation_response_accept']]);
                        ResourceRequisition::where('uuid', $requisitionId)->update(['status' => config('constant.PERFORM_ACTIONLOG.completed')]);
                    } else if ($flag && ($requisitionRecord['no_of_resource'] < count($requisitionRecord['resourceAllocation']) || $requisitionRecord['no_of_resource'] > count($requisitionRecord['resourceAllocation']))) {
                        ResourceAllocation::whereIn('uuid', $allocationArray)->update(['allocation_status' => config('constant.PROJECT_ACTION')['resource_allocation_request']]);
                        ResourceRequisition::where('uuid', $requisitionId)->update(['status' => config('constant.PERFORM_ACTIONLOG.inProgress')]);
                        ResourceMapping::whereIn('allocated_resource_id', $allocationArray)->delete();
                    }
                }
                if ($allocationDone && !isset($requisitionRecord['DirectRequisition'])) {
                    $this->multipleResourceMapping($requisitionId);
                }
            }
        }
    }

    public function multipleResourceMapping($requisitionId)
    {
        $allocationData = ResourceAllocation::with('resourceMapping', 'resourceRequisition', 'resourceAllocationMeta')->where('resource_req_id', $requisitionId)->get();
        if (isset($allocationData)) {
            foreach ($allocationData as $allocated) {
                if (!isset($allocated['resourceMapping'])) {
                    $mapping['start_date'] = $allocated['resourceAllocationMeta'][0]['start_date'];
                    $mapping['end_date'] = $allocated['resourceAllocationMeta'][0]['end_date'];
                    $mapping['efforts'] = $allocated['resourceAllocationMeta'][0]['hours'];
                    $mapping['resource_id'] = $allocated['resourceAllocationMeta'][0]['resource_id'];
                    ResourceMapping::storeAllocationMapping($allocated['uuid'], $allocated['resourceRequisition']['project_id'], $mapping);
                }
            }
        }
    }
    public function updateAllocatedResourceWithStatus($data, $userId, $projectId)
    {
        $isFullAllocation = $this->isFullAllocationAgainstAllocatedResource($data);
        if ($isFullAllocation) {
            $allocationStatus = config('constant.PROJECT_ACTION')['resource_allocation_response_accept'];
            $map = [
                'project_id' => $projectId,
                'resource_id' => $data['resource_id'],
                'hours' => trim($data['efforts']),
                'start_date' => $data['start_date'],
                'end_date' => $data['end_date'],
                'status' => '0'
            ];
            ResourceMapping::updateOrCreate(['allocated_resource_id' => $data['allocated_resource_id']], $map);
        } else {
            $allocationStatus = config('constant.PROJECT_ACTION')['resource_allocation_request'];
            ResourceMapping::where('allocated_resource_id', $data['allocated_resource_id'])->delete();
            ResourceRequisition::where('uuid', $data['resource_req_id'])->update(['status' => config('constant.PERFORM_ACTIONLOG.inProgress')]);
        }
        $response = ResourceAllocation::updateResourceAllocationTableData($data['allocated_resource_id'], $userId, $allocationStatus, $data['experience']);
        ResourceAllocationMeta::fullyDeallocateResource($data['allocated_resource_id']);
        ResourceAllocationMeta::storeResourceAllocationMeta($data['allocated_resource_id'], $data['start_date'], $data['end_date'], $data['efforts'], $data['resource_id']);
        return $response;
    }

    public function allocationRemove($allocatedResourceId)
    {
        $response = true;
        ResourceAllocation::where('uuid', $allocatedResourceId)->delete();
        ResourceMapping::where('allocated_resource_id', $allocatedResourceId)->delete();
        return $response;
    }

    /**
     * @OA\Post(
     *     path="/v1/direct-resource-allocation",
     *     summary="Resource Direct Allocation",
     *     operationId="/v1/direct-resource-allocation",
     *     tags={"Resource-allocation"},
     *     @OA\RequestBody(
     *         required=true,
     *         description="Post object",
     *         @OA\JsonContent(ref="#/components/schemas/ResourceDirectAllocate")
     *     ),
     *     @OA\Response(
     *         response=201,
     *         description="A post",
     *         @OA\JsonContent(),
     *     ),
     *     @OA\Response(
     *         response="default",
     *         description="unexpected error",
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     */
    public function directAllocation(Request $request)
    {
        $this->validate($request, self::$allocationValidationRules);
        $requestData = $request->toArray();
        $mailData = [];
        try {
            $role = Helpers::getRole($request->user->id, $requestData['project_id']);
            if ((!empty($role['project']) || in_array($this->rolesArray[config('constant.ROLES.global_operation')], $role['global'])) && !empty($role['department'])
                ||  in_array($this->rolesArray[config('constant.ROLES.admin')], $role['global'])
            ) {

                if (in_array($this->rolesArray[config('constant.ROLES.admin')], $role['global'])) {
                    $role['department'] = Department::pluck('id')->toArray();
                }
                $isAccess = $this->checkDepartmentValidation($requestData['allocation_data'], $role['department']);
                if ($isAccess) {
                    $projectDetails = Project::where('uuid', $requestData['project_id'])->first();
                    if (isset($requestData['allocation_data'])) {
                        foreach ($requestData['allocation_data'] as $record) {

                            $requisition = [
                                'project_id' => $requestData['project_id'],
                                'dept_id' => $record['dept_id'],
                                'tech_id' => $record['tech_id'],
                                'role_id' => $record['role_id'],
                                'efforts' => trim($record['efforts']),
                                'experience' => trim($record['experience']),
                                'start_date' => $record['start_date'],
                                'end_date' => $record['end_date'],
                                'no_of_resource' => config('constant.PERFORM_ACTIONLOG.completed'),
                                'status' => config('constant.PERFORM_ACTIONLOG.completed'),
                                'req_user_id' => $request->user->id,
                                'requested_By' => \Helpers::getUserName($request->user->id),
                                'billing_type' => $record['billing_type'],
                            ];
                            $requisitionRecord = new ResourceRequisition($requisition);
                            $requisitionRecord = $requisitionRecord->save();
                            $latestRequisition = ResourceRequisition::orderBy('id', 'desc')->first();
                            $latestRequisition->resource_id = $record['resource_id'];
                            $latestRequisition->role_name = \Helpers::getDesignationNameByID($record['role_id']);
                            $latestRequisition->tech_name = \Helpers::getTechnolgyNameByID($record['tech_id']);
                            $allocation = $this->resourceAllocation($latestRequisition, $request->user->id);
                            $projectAction = [
                                'link_id' => $latestRequisition['uuid'],
                                'comment' => config('constant.DIRECT_REQUISITION_CODE'),
                                'status_id' => $projectDetails['status'],
                                'previous_status' => $projectDetails['status'],
                                'requested_by' => $request->user->id,
                                'response_by' => $request->user->id
                            ];
                            ProjectAction::saveProjectAction($projectAction);
                            //Data for mail procedure
                            $requisition['department'] = Helpers::getDepartmentNameByID($record['dept_id']);
                            $requisition['allocation_status'] = config('constant.PROJECT_ACTION')['resource_allocation_response_accept'];
                            $requisition['resource_name'] = Helpers::getUserName($latestRequisition->resource_id);
                            $requisition['employee_code'] = \Helpers::getEmployeeCode($latestRequisition->resource_id);
                            $requisition['employee_email'] = \Helpers::getUserEmail($latestRequisition->resource_id);
                            $requisition['billing_type'] = \Helpers::getBillableType($record['billing_type']);
                            $requisition['flag'] = true;
                            $requisition['tech_id'] = $record['tech_id'];
                            $requisition['tech_name'] = \Helpers::getTechnolgyNameByID($record['tech_id']);
                            $requisition['role_id'] = $record['role_id'];
                            $requisition['role_name'] = \Helpers::getDesignationNameByID($record['role_id']);
                            $mailData[] = $requisition;
                        }

                        $mailTemplate = config('constant.TEMPLATES.allocation');
                        $mailService = new MailService($mailTemplate, $requestData['project_id'], $mailData);
                        $mailService->sendMail();
                        //Helpers::sendProjectMappingMail($requestData['project_id'],$mailData);
                        Log::info($this->helpers->addToLog($requestData['project_id'], $request, $latestRequisition, config('constant.LOG_ACTIONS.direct_resource_allocation')));
                        $this->helpers->addlogActivityDB($requestData['project_id'], $request, $mailData, config('constant.LOG_ACTIONS.direct_resource_allocation'));
                        $this->resourceMapping($request);
                        return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusCreated'), $latestRequisition);
                    }
                } else {
                    return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusUnauthorized'));
                }
            } else {
                return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusUnauthorized'));
            }
        } catch (\Exception $e) {
            Log::error($this->helpers->addToLog($requestData['project_id'], $request, $e->getMessage(), config('constant.LOG_ACTIONS.direct_resource_allocation')));
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function resourceAllocation($data, $userId)
    {
        $allocationData = [
            'resource_req_id' => $data['uuid'],
            'efforts' => trim($data['efforts']),
            'user_id' => $userId,
            'experience' => trim($data['experience']),
            'allocation_status' => config('constant.PROJECT_ACTION')['resource_allocation_response_accept'],
            'department' => $data['department'],
            'dept_id' => $data['dept_id'],
            'no_of_resource' => trim($data['no_of_resource']),
        ];
        $allocatedObj = new ResourceAllocation($allocationData);
        $allocatedObj->save();
        if ($allocatedObj) {
            ResourceAllocationMeta::storeResourceAllocationMeta($allocatedObj->uuid, $data['start_date'], $data['end_date'], $data['efforts'], $data['resource_id']);
            ResourceMapping::storeAllocationMapping($allocatedObj->uuid, $data['project_id'], $data);
        }
        return $allocationData;
    }

    public function checkDepartmentValidation($allocationData, $departments)
    {
        $response = true;
        if (isset($allocationData)) {
            foreach ($allocationData as $value) {
                if (!in_array($value['dept_id'], $departments)) {
                    $response = false;
                    break;
                }
            }
        }
        return $response;
    }

    public function resourceMapping($request)
    {
        $resourceMapping = new ResourceMappingController($this->helpers);
        foreach ($request['allocation_data'] as $allocation) {
            $resource = ResourceMapping::where('status', 0)
                ->where('resource_id', $allocation['resource_id'])->where('project_id', $request['project_id'])->first();
            if (isset($resource['uuid'])) {
                $user_data = LocalUser::where('user_id',  $allocation['resource_id'])->first();
                $startDate = Carbon::parse($allocation['start_date'])->isoFormat('MMM D, YYYY');
                $endDate = Carbon::parse($allocation['end_date'])->isoFormat('MMM D, YYYY');
                $map_data['action'] = false;
                $map_data['billing_type'] = \Helpers::getBillableType($allocation['billing_type']);
                $map_data['dept'] = \Helpers::getDepartmentNameByID($allocation['dept_id']);
                $map_data['designation'] = \Helpers::getDesignationNameByID($allocation['role_id']);
                $map_data['efforts'] = trim($allocation['efforts']);
                $map_data['end_date'] = $endDate;
                $map_data['experience'] = trim($allocation['experience']);
                $map_data['id'] = $resource['uuid'];
                $map_data['requested_by'] = $request['user']['full_name'];
                $map_data['requested_on'] = $startDate;
                $map_data['resource_mapping_id'] = $resource['uuid'];
                $map_data['resource_name'] = \Helpers::getUserName($allocation['resource_id']);
                $map_data['start_date'] = $startDate;
                $map_data['status'] = "1";
                $map_data['tech'] = \Helpers::getTechnolgyNameByID($allocation['tech_id']);
                $project = Project::with(['projectManagers'])->where('uuid', $request['project_id'])->first();
                $mailData = array(
                    'project_manager' => $project['projectManagers'][0]['user']['display_name'],
                    'project_hours' => trim($allocation['efforts']),
                    'email' => $user_data['email']
                );
                $request['map_data'] = [$map_data];
                $request['project_status'] = 7;
                $status = true;
                $resourceMapping->mapResource($request, $status);
                $this->sendEmailToEmployee($request['project_id'], $mailData);
            }
        }
        return 1;
    }

    public function sendEmailToEmployee($project_id, $mailData)
    {
        $mail = config('constant.TEMPLATES.employee_allocation_email');
        $mailService = new MailService($mail, $project_id, $mailData);
        $mailService->sendMail();
        return 1;
    }
}
