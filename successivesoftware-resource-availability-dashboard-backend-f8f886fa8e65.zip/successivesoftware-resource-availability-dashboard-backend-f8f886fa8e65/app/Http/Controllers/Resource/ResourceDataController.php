<?php

namespace App\Http\Controllers\Resource;

use App\Http\Controllers\Controller;
use App\ResourceBooking;
use App\TimeEntrie;
use Illuminate\Http\Request;
use DB;
use Webpatser\Uuid\Uuid;
use ApiResponse;
use Helpers;
use App\User;
use Carbon\Carbon;
use Log;
use App\Models\UserRole;
use App\Models\Department;
use App\Project;
use App\Models\ResourceAllocation;
use App\Models\ResourceAllocationMeta;
use App\Models\ResourceRequisition;
use App\Models\Technology;

class ResourceDataController extends Controller
{
    /**
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function resourcesAvailability(Request $request)
    {
        $response = $this->resourcesCommonQuery($request);
        return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $response);
    }


    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function resourcesAvailabilityDownload(Request $request)
    {
        $records = $this->resourcesCommonQuery($request);
        $allBooking = $this->allAssignedProject($request);
        $allUserExperience = $this->getAllUserExperience();
        $allData = [
            'unScheduled' => [],
            'fullyScheduled' => [],
            'partiallyScheduled' => [],
            'overScheduled' => [],
            'reportsData' => [],
        ];
        foreach ($records as $section => $users) {
            foreach ($users as $key => $user) {
                $user->experience = $this->getExperianceByEmpCode($user->empcode, $allUserExperience);
                $user->availableHours = (8 - $user->total)  < 0 ? 0 : (8 - $user->total);  
                $allData[$section][$key] = $this->getUserAllProject($user, $allBooking);
            }
        }
        return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $allData);
    }

    /**
     * @param $user
     * @param $allBooking
     * @return mixed
     */
    private function getUserAllProject($user, $allBooking)
    {
        $userStart = Carbon::parse($user->startDate)->format('Y-m-d');
        $userEnd =  Carbon::parse($user->endDate)->format('Y-m-d');
        $userId = $user->userId;
        // find skills of the userId
        $resReqMetaData = ResourceAllocationMeta::where('resource_id',$userId)->orderBy('created_at', 'desc')->withTrashed()->pluck('allocated_resources_uuid')->toArray();
        $resReqMetaData = array_unique($resReqMetaData);
        $skill = 'N/A';
        if(isset($resReqMetaData) && count($resReqMetaData)>0){
            $resAllotedData =ResourceAllocation::whereIn('uuid',$resReqMetaData)->orderBy('created_at', 'desc')->pluck('resource_req_id')->toArray();
            $resAllotedData = array_unique($resAllotedData);

            if(isset($resAllotedData) && count($resAllotedData)>0){
                $finalData = ResourceRequisition::whereIn('uuid',$resAllotedData)->orderBy('created_at', 'desc')->pluck('tech_id')->toArray();
                
                $finalData = array_unique($finalData);
            }
            if(isset($finalData) && count($finalData)>0){
                $skillArray = Technology::whereIn('id',$finalData)->pluck('name')->toArray();
                $skillObj = array_filter($skillArray, function($v) { return $v != "N/A"; });
                if(isset($skillObj) && count($skillObj)>0){
                $skill = implode(",",$skillObj);
              }
            }
        }
        $user->projectInfo = [];
        $user->expand = false;
        $user->skill = $skill;
        $groupedRecord = collect($allBooking)->groupBy('userId');
        if (isset($groupedRecord[$userId])) {
            foreach ($groupedRecord[$userId] as $booking) {
                $bookingStart =  Carbon::parse($booking['startDate'])->format('Y-m-d');
                $bookingEnd =  Carbon::parse($booking['endDate'])->format('Y-m-d');
                if ($bookingStart <= $userEnd && $bookingEnd >= $userStart && $booking['hours']!=0) {
                    $user->projectInfo[] = $booking;
                }   
            }
        }
        return $user;
    }

    private function getAllUserExperience()
    {
        $dataDepartmentWise = [];
        $result = Helpers::getKekaData();
        foreach ($result as $key => $value) {
            $PriviousExp = 0;
            foreach ($value['experienceDetails'] as $experienceDetails) {
                if (isset($experienceDetails['dateOfJoining']) && isset($experienceDetails['dateOfRelieving'])) {
                    $dateOfJoining = Carbon::createFromDate($experienceDetails['dateOfJoining']);
                    $dateOfRelieving = Carbon::createFromDate($experienceDetails['dateOfRelieving']);
                    $PriviousExp = $PriviousExp + $dateOfJoining->diffInDays($dateOfRelieving);
                }
            }
            $dateOfJoining = Carbon::createFromDate($value['joiningDate']);
            $now = Carbon::now();
            $currentExp = $dateOfJoining->diffInDays($now);
            $totaldays = $PriviousExp + $currentExp;
            $years = ($totaldays / 365); // days / 365 days
            $years1 = round($years, 1);
            $years = floor($years); // Remove all decimals
            $month = ($totaldays % 365) / 30.5; // I choose 30.5 for Month (30,31) ;)
            $month = floor($month); // Remove all decimals
            $data = [
                'experienceInYearMonth' => $years . " years " . $month . " months",
                'experience' => $years1,
                'empcode' => $value['employeeNumber']
            ];
            $dataDepartmentWise[] = $data;
        }
        return $dataDepartmentWise;
    }
    /**
     *
     * @param array $response
     * @param array $intervals
     */
    private function addToResponse(&$response, $intervals)
    {
        $buHeads = UserRole::where('role_id', 7)->pluck('user_id')->toArray();
        $leadershipUser = [1, 787, 1141,673];
        $globalExcepion = array_merge($buHeads, $leadershipUser);
        foreach ($intervals as $key => $interval) {
            $interval->uuid = (string)Uuid::generate(4);
            $interval->keyUnique = $key;
            if ($interval->total == 0) {
                if (!in_array($interval->userId, $globalExcepion)) {
                    $response['unScheduled'][] = $interval;
                }
            } elseif ($interval->total == 8) {
                $response['fullyScheduled'][] = $interval;
            } elseif ($interval->total < 8) {
                $response['partiallyScheduled'][] = $interval;
            } else {
                $response['overScheduled'][] = $interval;
            }
            if ($interval->total == 0 || $interval->total < 8) {
                if (!in_array($interval->userId, $globalExcepion)) {
                    $response['reportsData'][] = $interval;
                }
            }
        }
    }

    /**
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function assignedProjectToUser(Request $request)
    {
        $this->validate($request, [
            'start_date' => 'required|date_format:Y-m-d',
            'end_date' => 'required|date_format:Y-m-d|after_or_equal:start_date',
            'user_id' => 'required',
        ]);
        $userId = $request->get('user_id');
        $startDate = $request->get('start_date');
        $endDate = $request->get('end_date');
        $project_id  = $request->get('project_id');
        if ($project_id != '') {
            //$queryProject = "->where('project_id',$project_id)";
            $projects = ResourceBooking::where(function ($q) use ($endDate) {
                return $q->whereDate('start_date', '<=', $endDate);
            })->where(function ($q) use ($startDate) {
                return $q->whereDate('end_date', '>=', $startDate);
            })
                ->where('assigned_to_id', $userId)
                ->where('project_id', $project_id)
                ->with('project')
                ->get();
        } else {
            $projects = ResourceBooking::where(function ($q) use ($endDate) {
                return $q->whereDate('start_date', '<=', $endDate);
            })->where(function ($q) use ($startDate) {
                return $q->whereDate('end_date', '>=', $startDate);
            })
                ->where('assigned_to_id', $userId)
                ->with('project')
                ->get();
        }
        $response = [];
        foreach ($projects as $row) {
            $projectInfo = array(
                'projectId' => $row->project->id,
                'projectName' => $row->project->name,
                'startDate' => $row->start_date,
                'endDate' => $row->end_date,
                'hours' => $row->hours_per_day,
            );
            $response[] = $projectInfo;
        }

        return response(["data" => $response]);
    }

    /**
     * @param $request
     * @return array
     */
    private function resourcesCommonQuery($request)
    {
        $startDate = $request->get('start_date');
        $endDate = $request->get('end_date');
        $department = $request->get('department' . '');
        if ($department != '') {
            $department = '("' . implode('","', $department) . '")';
        }
        $location = $request->get('location', '');
        $billing = $request->get('billing', '');
        $projects = $request->get('projects', '');
        $excludeTrainee = $request->get('exclude_trainee', '');
        if ($projects != '') {
            $projects = implode(",", $projects);
        }
        $billingFilter = '';
        $projectsFilter = '';
        $projectGroupBY = '';
        $projectSelectID = '';
        $projectIDMAIN = '';
        $traineeFilter = '';
        if (isset($excludeTrainee) && $excludeTrainee == 'true') {
            $traineeData = Helpers::createTraineeUserArray();
            $traineeString = implode(",", $traineeData);
            $traineeFilter = ($traineeData) ? " AND users.id NOT IN ($traineeString) " : "";
        }
        if ($billing != '') {
            $billingProjectUsers = Helpers::getBillingProjectsID($billing);
            $billingFilter = ($billingProjectUsers) ? " AND temp.project_id IN ($billingProjectUsers) " : "";
            $projectSelectID = "r.project_id,";
            $projectIDMAIN = ",temp.project_id";
        }
        if (!empty($projects) && $billing != '') {
            $billingFilter = '';
            $projectsFilter = ($projects) ? " AND temp.project_id IN ($projects) " : "";
            $projectGroupBY = "r.project_id,";
            $projectSelectID = "r.project_id,";
            $projectIDMAIN = ",temp.project_id";
        }
        if (!empty($projects) && $billing == '') {
            $billingFilter = '';
            $projectsFilter = ($projects) ? " AND temp.project_id IN ($projects) " : "";
            $projectGroupBY = "r.project_id,";
            $projectSelectID = "r.project_id,";
            $projectIDMAIN = ",temp.project_id";
        }
        $username = $request->get('name', '');
        if ($username != '') {
            $username = '("' . implode('","', preg_replace('!\s+!', ' ', $username)) . '")';
        }
        if (!$startDate && !$endDate) {
            $startDate = date("Y-m-d");
            $endDate = date('Y-m-d');
        }
        $sDateTime = new \DateTime($startDate);
        $eDateTime = new \DateTime($endDate);

        $diff = $sDateTime->diff($eDateTime);
        $diffMonths = $diff->y * 12 + $diff->m;

        if ($sDateTime > $eDateTime) {
            $res['status'] = 200;
            $res['message'] = 'Please select valid date!';
            return response($res);
        }
        // if ($diffMonths > 6 || ($diffMonths == 6 && $diff->d > 0)) {
        //     $res['status'] = 200;
        //     $res['message'] = 'You can not fetch data for max 6 months!';
        //     return response($res);
        // }

        $locationFieldId = config('constant.CUSTOM_VALUES.location');
        $departmentFeildId = config('constant.CUSTOM_VALUES.business_unit');
        $bindings = [
            'startDate' => $startDate,
            'endDate' => $endDate,
            'startDate1' => $startDate,
            'endDate1' => $endDate
        ];
        $locationFilter = ($location != 'All') ? " AND location.value = :location " : "";
        $departmentFilter = ($department != '') ? " AND department.value IN $department " : " AND COALESCE(department.value,'') <> 'CLIENT'";
        $userFilter = ($username != '') ? " AND LOWER(TRIM(CONCAT(TRIM(users.`firstname`),' ',TRIM(users.`lastname`)))) IN $username " : "";
        if ($locationFilter) {
            $bindings['location'] = $location;
        }
        $data = DB::connection('redmine_db_mysql')->select(DB::raw(
            "SELECT users.id as userId,
                    TRIM(CONCAT(TRIM(users.`firstname`),' ',TRIM(users.`lastname`))) as name, 
                    coalesce(temp.hrs,0) as total,
                    temp.date,
                    coalesce(location.value,'') as location,
                    coalesce(department.value,'') as department,
                    coalesce(empcode.value,'') as empcode
                    $projectIDMAIN
                FROM users
                    LEFT JOIN (SELECT customized_id,value FROM custom_values WHERE custom_field_id =$locationFieldId) as location
                       ON location.customized_id = users.id  
                    JOIN (SELECT customized_id,value FROM custom_values WHERE custom_field_id =$departmentFeildId 
                       AND value NOT IN('Human Resource','HR','Research & Development','Client','Marketing & Branding',
                       'Marketing/Branding','Leadership','Account Management','Sales','Staffing','Learning and Development','Accounts & Admin')) as department
                       ON department.customized_id = users.id
                    LEFT JOIN (SELECT customized_id,value FROM custom_values WHERE custom_field_id =15) as empcode
                       ON empcode.customized_id = users.id 
                    LEFT JOIN
                (SELECT
                    r.assigned_to_id,
                    $projectSelectID
                    d.date,	
                    SUM(`hours_per_day`) as hrs
                FROM
                    (
                    SELECT * FROM 
                        (SELECT ADDDATE('1970-01-01',t4.i*10000 + t3.i*1000 + t2.i*100 + t1.i*10 + t0.i) date FROM
                         (SELECT 0 i UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) t0,
                         (SELECT 0 i UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) t1,
                         (SELECT 0 i UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) t2,
                         (SELECT 0 i UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) t3,
                         (SELECT 0 i UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) t4) v
                        WHERE date BETWEEN DATE_FORMAT(:startDate,'%Y-%m-%d') AND DATE_FORMAT(:endDate,'%Y-%m-%d')
                    ) d
                    LEFT JOIN resource_bookings r  ON d.date BETWEEN DATE_FORMAT(r.start_date,'%Y-%m-%d') AND DATE_FORMAT(r.end_date,'%Y-%m-%d')
                WHERE d.`date` BETWEEN  DATE_FORMAT(:startDate1,'%Y-%m-%d') AND DATE_FORMAT(:endDate1,'%Y-%m-%d')   
                GROUP BY
                    r.`assigned_to_id`,
                    $projectGroupBY
                    d.date) temp ON users.id=temp.assigned_to_id
                WHERE users.status=1 AND users.type='User' $locationFilter $departmentFilter $billingFilter $projectsFilter $traineeFilter $userFilter
                 ORDER BY users.id,temp.date"
        ), $bindings);
        $data = collect($data)->groupBy('userId')->toArray();
        $response = array(
            'unScheduled' => [],
            'fullyScheduled' => [],
            'partiallyScheduled' => [],
            'overScheduled' => [],
            'reportsData' => [],
        );
        foreach ($data as $keyId => $rows) {
            $intervals = Helpers::breakIntoIntervals($rows, $startDate, $endDate);
            $this->addToResponse($response, $intervals);
        }
        return $response;
    }

    /**
     * @param $request
     * @return array
     */
    private function allAssignedProject($request)
    {
        $startDate = $request->get('start_date');
        $endDate = $request->get('end_date');
        if (!$startDate && !$endDate) {
            $startDate = date("Y-m-d");
            $endDate = date('Y-m-d', strtotime('+2 months'));
        }
        $project_id  = $request->get('projects');
        if ($project_id != '') {
            //$queryProject = "->where('project_id',$project_id)";
            $projects = ResourceBooking::where(function ($q) use ($endDate) {
                return $q->whereDate('start_date', '<=', $endDate);
            })->where(function ($q) use ($startDate) {
                return $q->whereDate('end_date', '>=', $startDate);
            })
                ->whereIn('project_id', $project_id)
                ->with('project')
                ->get();
        } else {
            $projects = ResourceBooking::where(function ($q) use ($endDate) {
                return $q->whereDate('start_date', '<=', $endDate);
            })->where(function ($q) use ($startDate) {
                return $q->whereDate('end_date', '>=', $startDate);
            })
                ->with('project')
                ->get();
        }
        $response = [];
        foreach ($projects as $row) {
            $projectInfo = array(
                'userId' => $row->assigned_to_id,
                'projectId' => $row->project->id,
                'projectName' => $row->project->name,
                'startDate' => $row->start_date,
                'endDate' => $row->end_date,
                'hours' => $row->hours_per_day,
            );
            $response[] = $projectInfo;
        }
        return $response;
    }


    /**
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function resourcesUtilizationSummary(Request $request)
    {
        $startDate = date("Y-m-d");
        $endDate = date('Y-m-d');
        $department = $request->get('department' . '');
        if ($department != '') {
            $department = '("' . implode('","', $department) . '")';
        }
        $location = $request->get('location', '');
        $billing = $request->get('billing', '');
        $projects = $request->get('projects', '');
        $excludeTrainee = $request->get('exclude_trainee', '');
        if ($projects != '') {
            $projects = implode(",", $projects);
        }
        $billingFilter = '';
        $projectsFilter = '';
        $projectGroupBY = "r.project_id,";
        $projectSelectID = "r.project_id,";
        $projectIDMAIN = ",temp.project_id";
        $traineeFilter = '';
        if (isset($excludeTrainee) && $excludeTrainee == 'true') {
            $traineeData = Helpers::createTraineeUserArray();
            $traineeString = implode(",", $traineeData);
            $traineeFilter = ($traineeData) ? " AND users.id NOT IN ($traineeString) " : "";
        }
        if ($billing != '') {
            $billingProjectUsers = Helpers::getBillingProjectsID($billing);
            $billingFilter = ($billingProjectUsers) ? " AND temp.project_id IN ($billingProjectUsers) " : "";
            $projectSelectID = "r.project_id,";
            $projectIDMAIN = ",temp.project_id";
        }
        if (!empty($projects) && $billing != '') {
            $billingFilter = '';
            $projectsFilter = ($projects) ? " AND temp.project_id IN ($projects) " : "";
            $projectGroupBY = "r.project_id,";
            $projectSelectID = "r.project_id,";
            $projectIDMAIN = ",temp.project_id";
        }
        if (!empty($projects) && $billing == '') {
            $billingFilter = '';
            $projectsFilter = ($projects) ? " AND temp.project_id IN ($projects) " : "";
            $projectGroupBY = "r.project_id,";
            $projectSelectID = "r.project_id,";
            $projectIDMAIN = ",temp.project_id";
        }
        $username = $request->get('name', '');
        if ($username != '') {
            $username = '("' . implode('","', preg_replace('!\s+!', ' ', $username)) . '")';
        }
        if (!$startDate && !$endDate) {
            $startDate = date("Y-m-d");
            $endDate = date('Y-m-d');
        }
        $sDateTime = new \DateTime($startDate);
        $eDateTime = new \DateTime($endDate);

        $diff = $sDateTime->diff($eDateTime);
        $diffMonths = $diff->y * 12 + $diff->m;

        if ($sDateTime > $eDateTime) {
            $res['status'] = 200;
            $res['message'] = 'Please select valid date!';
            return response($res);
        }
        if ($diffMonths > 6 || ($diffMonths == 6 && $diff->d > 0)) {
            $res['status'] = 200;
            $res['message'] = 'You can not fetch data for max 6 months!';
            return response($res);
        }

        $locationFieldId = config('constant.CUSTOM_VALUES.location');
        $departmentFeildId = config('constant.CUSTOM_VALUES.business_unit');
        $bindings = [
            'startDate' => $startDate,
            'endDate' => $endDate,
            'startDate1' => $startDate,
            'endDate1' => $endDate
        ];
        $locationFilter = ($location != 'All') ? " AND location.value = :location " : "";
        $departmentFilter = ($department != '') ? " AND department.value IN $department " : " AND COALESCE(department.value,'') <> 'CLIENT'";
        $userFilter = ($username != '') ? " AND LOWER(TRIM(CONCAT(TRIM(users.`firstname`),' ',TRIM(users.`lastname`)))) IN $username " : "";
        if ($locationFilter) {
            $bindings['location'] = $location;
        }
        $data = DB::connection('redmine_db_mysql')->select(DB::raw(
            "SELECT users.id as userId,
                    TRIM(CONCAT(TRIM(users.`firstname`),' ',TRIM(users.`lastname`))) as name, 
                    coalesce(temp.hrs,0) as total,
                    temp.date,
                    coalesce(location.value,'') as location,
                    coalesce(department.value,'') as department,
                    coalesce(empcode.value,'') as empcode
                    $projectIDMAIN
                FROM users
                    LEFT JOIN (SELECT customized_id,value FROM custom_values WHERE custom_field_id =$locationFieldId) as location
                       ON location.customized_id = users.id  
                    JOIN (SELECT customized_id,value FROM custom_values WHERE custom_field_id =$departmentFeildId 
                       AND value NOT IN('Human Resource','HR','Research & Development','Client','IT Infra','Marketing/Branding',
                    'Sales','Staffing','Learning and Development','Accounts & Admin')) as department
                       ON department.customized_id = users.id 
                    LEFT JOIN (SELECT customized_id,value FROM custom_values WHERE custom_field_id =15) as empcode
                       ON empcode.customized_id = users.id
                    LEFT JOIN
                (SELECT
                    r.assigned_to_id,
                    $projectSelectID
                    d.date,	
                    SUM(`hours_per_day`) as hrs
                FROM
                    (
                    SELECT * FROM 
                        (SELECT ADDDATE('1970-01-01',t4.i*10000 + t3.i*1000 + t2.i*100 + t1.i*10 + t0.i) date FROM
                         (SELECT 0 i UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) t0,
                         (SELECT 0 i UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) t1,
                         (SELECT 0 i UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) t2,
                         (SELECT 0 i UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) t3,
                         (SELECT 0 i UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) t4) v
                        WHERE date BETWEEN DATE_FORMAT(:startDate,'%Y-%m-%d') AND DATE_FORMAT(:endDate,'%Y-%m-%d')
                    ) d
                    LEFT JOIN resource_bookings r  ON d.date BETWEEN DATE_FORMAT(r.start_date,'%Y-%m-%d') AND DATE_FORMAT(r.end_date,'%Y-%m-%d')
                WHERE d.`date` BETWEEN  DATE_FORMAT(:startDate1,'%Y-%m-%d') AND DATE_FORMAT(:endDate1,'%Y-%m-%d')   
                GROUP BY
                    r.`assigned_to_id`,
                    $projectGroupBY
                    d.date) temp ON users.id=temp.assigned_to_id
                WHERE temp.hrs!=0 AND users.status=1 AND users.type='User' $locationFilter $departmentFilter $billingFilter $projectsFilter $traineeFilter $userFilter
                 ORDER BY users.id,temp.date"
        ), $bindings);
        $data = collect($data)->toArray();
        $totalCount = count($data);
        if ($totalCount > 0) {
            $response['bench'] = [];
            $response['overview']['benchCount'] = 0;
            $response['overview']['benchCountPercentage'] = 0;
            $response['optimallyUtilized'] = [];
            $response['overview']['optimallyUtilizedCount'] = 0;
            $response['overview']['optimallyUtilizedCountPercentage'] = 0;
            $response['underUtilized'] = [];
            $response['overview']['underUtilizedCount'] = 0;
            $response['overview']['underUtilizedCountPercentage'] = 0;
            $response['overUtilized'] = [];
            $response['overview']['overUtilizedCount'] = 0;
            $response['overview']['overUtilizedCountPercentage'] = 0;
            $resultArray = [];
            foreach ($data as $key => $val) {
                $bookingResult = TimeEntrie::where(
                    'project_id',
                    $val->project_id
                )
                    ->where('user_id', $val->userId)
                    ->whereDate('spent_on', '=', $val->date)->first();
                $timeEntry = (isset($val->total) ? $val->total : 0);
                $bookedTime = (isset($bookingResult->hours) ? $bookingResult->hours : 0);
                if ($bookedTime == 0) {
                    $allocationUtilization = $bookedTime;
                } else {
                    $allocationUtilization = (($timeEntry / $bookedTime) * 100);
                }
                $resultArray = [
                    'name' => (isset($val->name) ? $val->name : ''),
                    'projectID' => (isset($val->project_id) ? $val->project_id : ''),
                    'projectName' => (isset($val->project_id) ? Helpers::getProjectNameRedmine($val->project_id) : ''),
                    'department' => (isset($val->department) ? $val->department : ''),
                    'startDate' => $startDate,
                    'endDate' => $endDate,
                    'utilizationPercentage' => round($allocationUtilization),
                ];
                if ($allocationUtilization == 0) {
                    $response['bench'][] = $resultArray;
                    $response['overview']['benchCount'] = count($response['bench']);
                    $response['overview']['benchCountPercentage'] = round(((count($response['bench']) / $totalCount) * 100));
                } elseif ($allocationUtilization == 100) {
                    $response['optimallyUtilized'][] = $resultArray;
                    $response['overview']['optimallyUtilizedCount'] = count($response['optimallyUtilized']);
                    $response['overview']['optimallyUtilizedCountPercentage'] = round(((count($response['optimallyUtilized']) / $totalCount) * 100));
                } elseif ($allocationUtilization < 100) {
                    $response['underUtilized'][] = $resultArray;
                    $response['overview']['underUtilizedCount'] = count($response['underUtilized']);
                    $response['overview']['underUtilizedCountPercentage'] = round(((count($response['underUtilized']) / $totalCount) * 100));
                } else {
                    $response['overUtilized'][] = $resultArray;
                    $response['overview']['overUtilizedCount'] = count($response['overUtilized']);
                    $response['overview']['overUtilizedCountPercentage'] = round(((count($response['overUtilized']) / $totalCount) * 100));
                }
            }
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $response);
        } else {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), '');
        }
    }

    private function getExperianceByEmpCode($empcode, $allUserExperience)
    {
        foreach ($allUserExperience as $userExperiance) {
            if ($empcode == $userExperiance['empcode']) {
                return $userExperiance['experience'];
            }
        }
    }

    public function resourceTimeBu(Request $request)
    {

        $userId = $request->user_id;
        $deptId = $request->dept_id;
        try{
            $deptName =explode(' ',Department::whereId($deptId)->pluck('name')->first());
            if($deptName[0] == 'Human'){
                $deptName[0] = 'HR';
            }
        
            $projectNameId = Project::where('name','like','%BU')->select('id','name')->get();
            $pattern = "/$deptName[0]/i";
            foreach($projectNameId as $key => $val){
                if( preg_match($pattern, $val->name)){
                    $valId =$val->id;
                    break;
                }
            }
            if(isset($valId)){
            $totalTimeLog = TimeEntrie::where('user_id',$userId)->where('project_id',$valId)->get()->count();
            } else {
            $totalTimeLog = 0;
            }
        return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), ["TotalTimelog"=>$totalTimeLog]);
        }catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
        
       
    }
    
}
