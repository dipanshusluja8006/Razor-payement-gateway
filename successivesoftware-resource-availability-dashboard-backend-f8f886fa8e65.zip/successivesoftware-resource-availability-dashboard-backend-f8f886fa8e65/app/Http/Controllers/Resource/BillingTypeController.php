<?php

namespace App\Http\Controllers\Resource;

use App\Http\Controllers\Controller;
use App\Models\BillingType;
use ApiResponse;

class BillingTypeController extends Controller
{
    public function index()
    {
        try {
            $billingTypes = BillingType::all();
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $billingTypes);
        }catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }
}
