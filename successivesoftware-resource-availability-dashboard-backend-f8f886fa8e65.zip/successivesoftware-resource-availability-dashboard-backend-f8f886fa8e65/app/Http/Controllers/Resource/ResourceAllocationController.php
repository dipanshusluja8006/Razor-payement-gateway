<?php

namespace App\Http\Controllers\Resource;

use App\Libraries\MailService;
use App\Models\DeAllocationMapping;
use App\Models\ResourceMapping;
use App\Models\ResourceRequisition;
use App\Models\PerformedActionLog;
use App\Models\ProjectAction;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Project;
use App\Models\ResourceAllocation;
use App\Models\ResourceAllocationMeta;
use Helpers;
use Carbon\Carbon;
use ApiResponse;
use Log;
use App\Traits\ResourceControllerTraits;
use App\Http\Controllers\Resource\ResourceMappingController;
use App\Models\LocalUser;

class ResourceAllocationController extends Controller
{
    use ResourceControllerTraits;
    protected $mailTemplate = [];
    protected $departmentArray = [];
    protected $allocationData = [];
    protected $helpers;

    public function __construct(Helpers $helpers)
    {
        $this->helpers = $helpers;
    }

    public static $validationRules = [
        'allocation_data' => 'array',
        'allocation_data.*.resource_req_id' => 'required|exists:resource_mysql.resource_requisitions,uuid',
        'allocation_data.*.efforts' => 'required',
        'allocation_data.*.experience' => 'required',
        'allocation_data.*.no_of_hours' => 'required',
        'allocation_data.*.start_date' => 'required',
        'allocation_data.*.end_date' => 'required',
        'allocation_data.*.resource_id' => 'required|exists:redmine_db_mysql.users,id',
        'project_id' => 'required|exists:resource_mysql.projects,uuid',
        'project_status' => 'required',

    ];

    public static $updateValidationRules = [
        'allocation_data' => 'array',
        'deleted_allocations' => 'array',
        'allocation_data.*.resource_req_id' => 'required|exists:resource_mysql.resource_requisitions,uuid',
        'allocation_data.*.efforts' => 'required',
        'allocation_data.*.experience' => 'required',
        'allocation_data.*.no_of_hours' => 'required',
        'allocation_data.*.start_date' => 'required',
        'allocation_data.*.end_date' => 'required',
        'allocation_data.*.resource_id' => 'required|exists:redmine_db_mysql.users,id',
        'allocation_data.*.is_new_resource' => 'required',
        'project_id' => 'required|exists:resource_mysql.projects,uuid',
        'project_status' => 'required',

    ];

    public static $aprroveValidationRules = [
        'approve_status' => 'required'
    ];

    public static $projectIdValidationRules = [
        'project_id' => 'required|exists:resource_mysql.projects,uuid',
    ];

    /**
     * @OA\Post(
     *     path="/v1/resource-allocation",
     *     summary="Resource Allocate",
     *     operationId="/v1/resource-allocation",
     *     tags={"Resource-allocation"},
     *     @OA\RequestBody(
     *         required=true,
     *         description="Post object",
     *         @OA\JsonContent(ref="#/components/schemas/ResourceAllocate")
     *     ),
     *     @OA\Response(
     *         response=201,
     *         description="A post",
     *         @OA\JsonContent(),
     *     ),
     *     @OA\Response(
     *         response="default",
     *         description="unexpected error",
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     * @throws \Illuminate\Validation\ValidationException
     *
     * Account Manager / Project Manager
     * GO/Sales
     * PM’s working with that resource on other project
     * Resource Manager
     */
    public function create(Request $request)
    {
        $this->validate($request, self::$validationRules);
        $resourceRequisitionArray = [];
        $requestData = $request->toArray();
        $allocationStatus = config('constant.PROJECT_ACTION')['resource_allocation_request'];
        $isAccess = $this->checkCorrectDepartmentAndAccess($request->user->id, $requestData['project_id'], $allocationStatus, $requestData);
        if ($isAccess) {
            $allocation_array_data = [];
            foreach ($requestData['allocation_data'] as $data) {
                $resourceRequisitionArray[$data['resource_req_id']] = $data['resource_req_id'];
                $resourceRequisition = ResourceRequisition::with(['resource', 'requestedUser'])->where('uuid', $data['resource_req_id'])->first();
                $totalAllocationAgainstRequisition = array_count_values(array_column($requestData['allocation_data'], 'resource_req_id'))[$data['resource_req_id']];
                if ($totalAllocationAgainstRequisition == $resourceRequisition['no_of_resource']) {
                    $allocationStatus = $this->currentAllocationStatus($data, $resourceRequisition);
                }
                if ($resourceRequisition->type == 1 && $resourceRequisition->extension_resource_id != null && $data['resource_id'] != $resourceRequisition->extension_resource_id) {
                    $allocationStatus = config('constant.PROJECT_ACTION')['resource_allocation_request'];
                }

                $allocation_data = [
                    'resource_req_id' => $data['resource_req_id'],
                    'efforts' => trim($data['efforts']),
                    'resource_id' => $data['resource_id'],
                    'resource_name' => \Helpers::getUserName($data['resource_id']),
                    'user_id' => $request->user->id,
                    'experience' => trim($data['experience']),
                    'allocation_status' => $allocationStatus,
                    'start_date' => $data['start_date'],
                    'end_date' => $data['end_date'],
                    'req_efforts' => $resourceRequisition['efforts'],
                    'department' => $data['department'],
                    'dept_id' => $resourceRequisition['dept_id'],
                    'tech_id' => $resourceRequisition['tech_id'],
                    'tech_name' => \Helpers::getTechnolgyNameByID($resourceRequisition['tech_id']),
                    'role_id' => $resourceRequisition['role_id'],
                    'role_name' => \Helpers::getDesignationNameByID($resourceRequisition['role_id']),
                    'no_of_resource' => $resourceRequisition['no_of_resource'],
                    'billing_type' => $resourceRequisition['billing_type'],
                    'billing_name' => \Helpers::getBillableType($resourceRequisition['billing_type']),
                    'type' => $resourceRequisition['type'],
                    'resource_requisition' => $resourceRequisition,

                ];
                $allocation_array_data[] = $allocation_data;
            }
            $response = $this->saveArrayRecords($allocation_array_data, $requestData['project_id']);
            $this->updateMultipleResourceRequisitionArray($resourceRequisitionArray);
            $this->updateProjectStatusAccordingResources($requestData['project_id']);

            //For mail
            $mailArray = [];
            $allocatedIDArray = [];
            foreach ($this->allocationData as $val) {
                array_push($allocatedIDArray, $val['allocated_resources_uuid']);
                if (array_key_exists($val['resource_req_id'], $mailArray)) {
                    $mailArray[$val['resource_req_id']]['data'][] = $val;
                } else {
                    $mailArray[$val['resource_req_id']]['data'][] = $val;
                    $mailArray[$val['resource_req_id']]['count'] = $val['no_of_resource'];
                }
            }
            if (isset($this->mailTemplate[0])) {
                foreach ($this->mailTemplate as $template) {
                    $mailService = new MailService($template, $requestData['project_id'], $mailArray);
                    $mailService->sendMail();
                }
                $this->mailTemplate = [];
                $this->departmentArray = [];
            }
            Log::info($this->helpers->addToLog($requestData['project_id'], $request, $response, config('constant.LOG_ACTIONS.creation_allocation')));
            $this->helpers->addlogActivityDB($requestData['project_id'], $request, $allocation_array_data, config('constant.LOG_ACTIONS.creation_allocation'));
            $this->resourceMapping($request);
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusCreated'), $response);
        } else {
            Log::error($this->helpers->addToLog($requestData['project_id'], $request, $e->getMessage(), config('constant.LOG_ACTIONS.creation_allocation')));
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusUnauthorized'), '', $e->getMessage());
        }
    }

    public function updateMultipleResourceRequisitionArray($resourceRequisitionArray)
    {
        if (isset($resourceRequisitionArray)) {
            foreach ($resourceRequisitionArray as $key => $value) {
                $this->updateResourceRequisitionStatus($value);
            }
        }
    }

    /**
     * @param $allocation_array_data  //mix array consist data about request and requisition
     * @param $project_id
     * @return ResourceAllocation
     * @throws \Exception
     */
    public function saveArrayRecords($allocation_array_data, $project_id)
    {
        foreach ($allocation_array_data as $data) {
            $allocation_data = [
                'resource_req_id' => $data['resource_req_id'],
                'efforts' => trim($data['efforts']),
                'user_id' => $data['user_id'],
                'experience' => trim($data['experience']),
                'allocation_status' => $data['allocation_status'],
                'department' => $data['department'],
                'dept_id' => $data['dept_id'],
                'no_of_resource' => trim($data['no_of_resource']),
            ];

            $allocated_obj = new ResourceAllocation($allocation_data);
            $allocated_obj->save();

            if ($allocated_obj) {
                //create allocation meta
                $meta = ResourceAllocationMeta::storeResourceAllocationMeta($allocated_obj->uuid, $data['start_date'], $data['end_date'], $data['efforts'], $data['resource_id']);

                //create resource mapping if allocation status is auto accept(resource_allocation_response_accept)
                if ($data['allocation_status'] == config('constant.PROJECT_ACTION')['resource_allocation_response_accept']) {
                    $createMapping = ResourceMapping::storeAllocationMapping($allocated_obj->uuid, $project_id, $data);
                }
            }
            PerformedActionLog::storePerformedActionLog($project_id, 3, config('constant.PERFORM_ACTIONLOG.inProgress'), $data['dept_id']);
            $allocationRecord = [
                'resource_req_id' => $data['resource_req_id'],
                'efforts' => trim($data['efforts']),
                'user_id' => $data['user_id'],
                'experience' => trim($data['experience']),
                'allocation_status' => $data['allocation_status'],
                'allocated_resources_uuid' => $allocated_obj->uuid,
                'start_date' => Carbon::parse($data['start_date'])->format('Y-m-d'),
                'end_date' => Carbon::parse($data['end_date'])->format('Y-m-d'),
                'hours' => $data['efforts'],
                'resource_id' => $data['resource_id'],
                'resource_name' => \Helpers::getUserName($data['resource_id']),
                'employee_code' => \Helpers::getEmployeeCode($data['resource_id']),
                'employee_email' => \Helpers::getUserEmail($data['resource_id']),
                'department' => $data['department'],
                'dept_id' => $data['dept_id'],
                'no_of_resource' => trim($data['no_of_resource']),
                'billing_type' => \Helpers::getBillableType($data['billing_type']),
                'type' => $data['type']
            ];
            array_push($this->allocationData, $allocationRecord);

            if ($data['allocation_status'] == config('constant.PROJECT_ACTION')['resource_allocation_response_accept']) {
                //check for fully Allocation
                $mailTemplate = [config('constant.TEMPLATES.allocation')];
                foreach ($mailTemplate as $val) {
                    if (!in_array($val, $this->mailTemplate)) {
                        array_push($this->mailTemplate, $val);
                    }
                }
            } else {
                $mailTemplate = [config('constant.TEMPLATES.partial_allocation')];
                foreach ($mailTemplate as $val) {
                    if (!in_array($val, $this->mailTemplate)) {
                        array_push($this->mailTemplate, $val);
                    }
                }
            }
        }
        return $allocated_obj;
    }


    public function checkCorrectDepartmentAndAccess($userId, $projectId, $statusId, $data)
    {
        $response = true;
        if (!empty($data)) {
            foreach ($data['allocation_data'] as $value) {
                $isAccess = $this->checkUserAccessForResourceAllocationOperations($userId, $projectId, $statusId, $value['dept']);
                if (!$isAccess) {
                    $response = false;
                    break;
                }
            }
        } else {
            $response = false;
        }
        return $response;
    }

    public function reAllocationLog($projectId)
    {
        $logDetails = Project::with(['ResourceRequisitionLog'])->where('uuid', $projectId)->first();
        return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $logDetails);
    }

    /**
     * @OA\Put(
     *     path="/v1/resource-re-allocation/{allocated_resources_uuid}",
     *     summary="Resource Re-Allocate",
     *     operationId="/v1/resource-re-allocation/{allocated_resources_uuid}",
     *     tags={"Resource-allocation"},
     *     @OA\Parameter(
     *         name="allocated_resources_uuid",
     *         in="path",
     *         description="Allocated Resources UUID",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\RequestBody(
     *         required=true,
     *         description="Post object",
     *         @OA\JsonContent(ref="#/components/schemas/ResourceReAllocate")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="A post",
     *         @OA\JsonContent(),
     *     ),
     *     @OA\Response(
     *         response="default",
     *         description="unexpected error",
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     *
     * Api for Reallocate Resource Allocation
     */
    public function reAllocate(Request $request)
    {
        $this->validate($request, self::$updateValidationRules);
        $requestData = $request->toArray();
        $projectUpdatedStatus = '';
        $reAllocateMailData = [];
        $resourceRequisitionArray = [];
        if (isset($requestData['allocation_data'][0])) {
            $isAccess = $this->checkUserAccessForResourceAllocationOperations($request->user->id, $requestData['project_id'], config('constant.PROJECT_ACTION')['resource_allocation_request'], $requestData['allocation_data'][0]['dept']);
        } elseif (isset($requestData['deleted_allocations'][0])) {
            $isAccess = $this->checkUserAccessForResourceAllocationOperations($request->user->id, $requestData['project_id'], config('constant.PROJECT_ACTION')['resource_allocation_request'], $requestData['deleted_allocations'][0]['dept_id']);
        }
        if ($isAccess) {
            $globalResponse = [];
            $templateArray = [];
            $deleteAllocationIdArray = [];
            $deleteReallocation = [];
            if (isset($requestData['deleted_allocations'][0])) {
                foreach ($requestData['deleted_allocations'] as $item) {
                    $deleteAllocationIdArray[] = $item['allocated_id'];
                    $resourceRequisition = ResourceRequisition::with(['resource', 'requestedUser'])->where('uuid', $item['resource_req_id'])->first();
                    $responseAllocation = ResourceRequisition::with(['ResourceAllocation', 'technology', 'department', 'designation', 'resource', 'requestedUser'])->where('uuid', $item['resource_req_id'])->first();
                    $value['resource_name'] = Helpers::getUserName($item['resource_name']);
                    $value['employee_code'] = Helpers::getEmployeeCode($item['resource_name']);
                    $value['employee_email'] = Helpers::getUserEmail($item['resource_name']);
                    $value['billing_type'] = \Helpers::getBillableType($item['billing_type']);
                    $value['efforts'] = $item['efforts'];
                    $value['experience'] = $item['experience'];
                    $value['department'] = $item['department']['name'];
                    $value['start_date'] = $item['start_date'];
                    $value['end_date'] = $item['end_date'];
                    $value['type'] = $item['type'];
                    $value['tech_id'] = $item['tech'];
                    $value['tech_name'] = \Helpers::getTechnolgyNameByID($item['tech']);
                    $value['role_id'] = $resourceRequisition['role_id'];
                    $value['role_name'] = \Helpers::getDesignationNameByID($resourceRequisition['role_id']);
                    $value['resource_requisition'] = $resourceRequisition;
                    $value['resource_allocation'] = $responseAllocation;
                    array_push($deleteReallocation, $value);
                }
                $deletedAllocationsRequisitionId = ResourceAllocation::whereIn('uuid', $deleteAllocationIdArray)->pluck('resource_req_id');
                ResourceAllocation::whereIn('uuid', $deleteAllocationIdArray)->delete();
            }
            if (isset($requestData['allocation_data'][0])) {

                $countArray = $this->fetchAllocationStatusAgainstRequisitionForReallocation($requestData['allocation_data']);

                foreach ($requestData['allocation_data'] as $record) {
                    $allocationStatus = config('constant.PROJECT_ACTION')['resource_allocation_request'];
                    $resourceRequisitionArray[$record['resource_req_id']] = $record['resource_req_id'];
                    $count = $countArray[$record['resource_req_id']];
                    $resourceRequisition = ResourceRequisition::with(['resource', 'requestedUser'])->where('uuid', $record['resource_req_id'])->first();
                    $responseAllocation = ResourceRequisition::with(['ResourceAllocation', 'technology', 'department', 'designation', 'resource', 'requestedUser'])->where('uuid', $record['resource_req_id'])->first();
                    if ($count) {
                        $allocationStatus = $this->currentAllocationStatus($record, $resourceRequisition);
                    }
                    if ($resourceRequisition->type == 1 && $resourceRequisition->extension_resource_id != null && $record['resource_id'] != $resourceRequisition->extension_resource_id) {
                        $allocationStatus = config('constant.PROJECT_ACTION')['resource_allocation_request'];
                    }
                    $allocatedResourcesUuid = isset($record['allocated_resources_uuid']) ? $record['allocated_resources_uuid'] : '';
                    $record['resource_name'] = \Helpers::getUserName($record['resource_id']);
                    $record['employee_code'] = \Helpers::getEmployeeCode($record['resource_id']);
                    $record['employee_email'] = \Helpers::getUserEmail($record['resource_id']);
                    $record['billing_type'] = \Helpers::getBillableType($resourceRequisition['billing_type']);
                    $record['type'] = $resourceRequisition['type'];
                    $record['tech_id'] = $resourceRequisition['tech_id'];
                    $record['tech_name'] = \Helpers::getTechnolgyNameByID($resourceRequisition['tech_id']);
                    $record['role_id'] = $resourceRequisition['role_id'];
                    $record['role_name'] = \Helpers::getDesignationNameByID($resourceRequisition['role_id']);
                    $record['resource_requisition'] = $resourceRequisition;
                    $record['resource_allocation'] = $responseAllocation;

                    $projectId = $requestData['project_id'];
                    if (!$record['is_new_resource']) {
                        $resourceAllocationdata = ResourceAllocation::where(['uuid' => $allocatedResourcesUuid])->first();
                        if (isset($resourceAllocationdata)) {
                            ResourceAllocationMeta::fullyDeallocateResource($allocatedResourcesUuid);
                            $response = ResourceAllocation::updateResourceAllocationTableData($allocatedResourcesUuid, $request->user->id, $allocationStatus, $record['experience']);
                            ResourceAllocationMeta::storeResourceAllocationMeta($allocatedResourcesUuid, $record['start_date'], $record['end_date'], $record['efforts'], $record['resource_id']);

                            //check resource allocation status is accept then create resource mapping data
                            if ($allocationStatus == config('constant.PROJECT_ACTION')['resource_allocation_response_accept']) {
                                $createMapping = ResourceMapping::storeAllocationMapping($allocatedResourcesUuid, $requestData['project_id'], $record);
                            }
                        } else {
                            return response()->json(["message" => 'Resource Allocation id not found', 'status' => 404], 404);
                        }
                    } else {
                        $allocation_data = [
                            'resource_req_id' => $record['resource_req_id'],
                            'efforts' => trim($record['no_of_hours']),
                            'user_id' => $request->user->id,
                            'experience' => trim($record['experience']),
                            'allocation_status' => $allocationStatus,
                        ];

                        $allocated_obj = new ResourceAllocation($allocation_data);
                        $allocated_obj->save();
                        if ($allocated_obj) {
                            $record['allocated_resources_uuid'] = $allocated_obj->uuid;
                            //create allocation meta
                            $meta = ResourceAllocationMeta::storeResourceAllocationMeta($allocated_obj->uuid, $record['start_date'], $record['end_date'], $record['efforts'], $record['resource_id']);
                            //create resource mapping if allocation status is auto accept(resource_allocation_response_accept)
                            if ($allocationStatus == config('constant.PROJECT_ACTION')['resource_allocation_response_accept']) {
                                $createMapping = ResourceMapping::storeAllocationMapping($allocated_obj->uuid, $projectId, $record);
                            }
                        }
                    }
                    PerformedActionLog::storePerformedActionLog($projectId, 3, config('constant.PERFORM_ACTIONLOG.inProgress'), $resourceRequisition['dept_id']);
                    $mailData = $record;
                    $mailData['allocation_status'] = $allocationStatus;
                    array_push($reAllocateMailData, $mailData);
                    if ($allocationStatus == config('constant.PROJECT_ACTION')['resource_allocation_response_accept']) {
                        $mailTemplate = [config('constant.TEMPLATES.resource_reallocation')];
                        foreach ($mailTemplate as $val) {
                            if (!in_array($val, $templateArray)) {
                                array_push($templateArray, $val);
                            }
                        }
                    } else {
                        $mailTemplate = config('constant.TEMPLATES.resource_reallocation_partial');
                        if (!in_array($mailTemplate, $templateArray)) {
                            array_push($templateArray, $mailTemplate);
                        }
                    }
                }
            }
            $this->updateMultipleResourceRequisitionArray($resourceRequisitionArray);
            $this->updateProjectStatusAccordingResources($requestData['project_id']);
            $allocatedIDArray = [];
            foreach ($reAllocateMailData as $val) {
                array_push($allocatedIDArray, $val['allocated_resources_uuid']);
            }
            if (isset($templateArray[0])) {
                foreach ($templateArray as $template) {
                    $mailService = new MailService($template, $requestData['project_id'], $reAllocateMailData);
                    $mailService->sendMail();
                }
            }
            if (!empty($reAllocateMailData)) {
                Log::info($this->helpers->addToLog($requestData['project_id'], $request, $reAllocateMailData, config('constant.LOG_ACTIONS.resource_reallocation')));
                $this->helpers->addlogActivityDB($requestData['project_id'], $request, $reAllocateMailData, config('constant.LOG_ACTIONS.resource_reallocation'));
                $this->resourceMapping($request, true);
            }
            if (!empty($deleteReallocation)) {
                $mailDeleteArray = [config('constant.TEMPLATES.delete_reallocation')];
                foreach ($mailDeleteArray as $template) {
                    $mailService = new MailService($template, $requestData['project_id'], $deleteReallocation);
                    $mailService->sendMail();
                }
                Log::info($this->helpers->addToLog($requestData['project_id'], $request, $deleteReallocation, config('constant.LOG_ACTIONS.delete_reallocation')));
                $this->helpers->addlogActivityDB($requestData['project_id'], $request, $deleteReallocation, config('constant.LOG_ACTIONS.delete_reallocation'));
            }

            $globalResponse = ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'));
        } else {
            Log::error($this->helpers->addToLog($requestData['project_id'], $request, $e->getMessage(), config('constant.LOG_ACTIONS.resource_reallocation')));
            $globalResponse = ApiResponse::genericResponse(config('constant.STATUS_CODE.statusUnauthorized'), '', $e->getMessage());
        }
        return $globalResponse;
    }

    public function fetchAllocationStatusAgainstRequisitionForReallocation($allocationData)
    {
        $allocationArray = [];
        $allocationCount = [];
        $reAllocateUuid = [];
        if (isset($allocationData[0])) {
            foreach ($allocationData as $value) {
                if (!array_key_exists($value['resource_req_id'], $allocationArray)) {
                    $allocationArray[$value['resource_req_id']] = false;
                    $allocationCount[$value['resource_req_id']] = 0;
                    $requisition = ResourceRequisition::where('uuid', $value['resource_req_id'])->first();
                    $existAllocation = ResourceAllocation::where(['resource_req_id' => $value['resource_req_id']])->with('resourceAllocationMeta')->get();
                    $existAllocationCount = 0;
                    foreach ($allocationData as $record) {
                        if (!$record['is_new_resource']) {
                            array_push($reAllocateUuid, $record['allocated_resources_uuid']);
                        }
                        if ($value['resource_req_id'] == $record['resource_req_id']) {
                            $allocationCount[$value['resource_req_id']]++;
                        }
                    }
                    if (isset($existAllocation[0])) {
                        foreach ($existAllocation as $item) {
                            if (!in_array($item['uuid'], $reAllocateUuid)) {
                                $existAllocationCount++;
                            }
                        }
                    }
                    $totalAllocationCount = $allocationCount[$value['resource_req_id']] + $existAllocationCount;

                    if ($totalAllocationCount == $requisition['no_of_resource']) {
                        $allocationArray[$value['resource_req_id']] = true;
                    }
                }
            }
        }
        return $allocationArray;
    }

    public function currentAllocationStatus($allocationData, $requisition)
    {
        $status = config('constant.PROJECT_ACTION')['resource_allocation_response_accept'];
        if (isset($allocationData)) {
            if ($requisition['uuid'] == $allocationData['resource_req_id']) {
                if (
                    $allocationData['efforts'] != $requisition['efforts'] ||
                    Carbon::parse($allocationData['start_date'])->notEqualTo(Carbon::parse($requisition['start_date'])) ||
                    Carbon::parse($allocationData['end_date'])->notEqualTo(Carbon::parse($requisition['end_date'])) ||
                    $allocationData['experience'] != $requisition['experience']
                ) {
                    $status = config('constant.PROJECT_ACTION')['resource_allocation_request'];
                }
                if (
                    $requisition['type'] == 1 && $requisition['extension_resource_id'] != null &&
                    $allocationData['resource_id'] != $requisition['extension_resource_id']
                ) {
                    $status = config('constant.PROJECT_ACTION')['resource_allocation_request'];
                }
            }
        }

        return $status;
    }


    /**
     *
     * @OA\Get(
     *     path="/v1/resource-allocation/{projectUuid}/{type}",
     *     operationId="/v1/resource-allocation/{projectUuid}/{type}",
     *     summary="Fetch Allocated resources using projectUuid and type(Allocation status)",
     *     tags={"Resource-allocation"},
     *     @OA\Parameter(
     *         name="projectUuid",
     *         in="path",
     *         description="Project UUID",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\Parameter(
     *         name="type",
     *         in="path",
     *         description="Allocation Status",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\Response(
     *         response="200",
     *         description="Returns Allocated Resources Detail",
     *         @OA\JsonContent()
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     *
     * Fetch resource allocation datas
     */
    public function show(Request $request, $projectUuid, $type)
    {
        $request->merge(['project_id' => $projectUuid]);
        $this->validate($request, self::$projectIdValidationRules);
        return $this->showByAllDepartment($projectUuid, $type);
    }


    public function showByAllDepartment($projectUuid, $type)
    {
        if ($type == 'all') {
            $response = ResourceRequisition::with(['ResourceAllocation', 'technology', 'department', 'designation', 'resource', 'requestedUser'])
                ->where('project_id', $projectUuid)
                ->get();
        } else {
            $typeValue = config('constant.PROJECT_ACTION')[$type];
            $response = ResourceRequisition::with(['technology', 'department', 'designation', 'requestedUser', 'resource', 'ResourceAllocation' => function ($query) use ($typeValue) {
                $query->where('allocation_status', $typeValue);
            }])
                ->where('project_id', $projectUuid)
                ->get();
        }
        return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $response);
    }

    /**
     *
     * @OA\Get(
     *     path="/v1/resource-allocation-dept/{projectUuid}/{type}",
     *     operationId="/v1/resource-allocation-dept/{projectUuid}/{type}",
     *     summary="Fetch Allocated resources by department using projectUuid and type(Allocation status)",
     *     tags={"Resource-allocation"},
     *     @OA\Parameter(
     *         name="projectUuid",
     *         in="path",
     *         description="Project UUID",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\Parameter(
     *         name="type",
     *         in="path",
     *         description="Allocation Status",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\Response(
     *         response="200",
     *         description="Returns Allocated Resources Detail",
     *         @OA\JsonContent()
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     *
     * Fetch resource allocation data
     */

    public function showByDepartment(Request $request, $projectUuid, $type)
    {
        $request->merge(['project_id' => $projectUuid]);
        $this->validate($request, self::$projectIdValidationRules);
        $roles = Helpers::getRole($request->user->id, $projectUuid);
        if (in_array(Helpers::getRoleIdByCode(config('constant.ROLES.admin')), $roles['global'])) {
            return $this->showByAllDepartment($projectUuid, $type);
        }
        if ($type == 'all') {
            $response = ResourceRequisition::with(['ResourceAllocation', 'technology', 'department', 'designation', 'resource', 'requestedUser'])
                ->where('project_id', $projectUuid)
                ->whereIn('dept_id', $roles['department'])
                ->get();
        } else {
            $typeValue = config('constant.PROJECT_ACTION')[$type];
            $response = ResourceRequisition::with(['technology', 'department', 'designation', 'requestedUser', 'resource', 'ResourceAllocation' => function ($query) use ($typeValue) {
                $query->where('allocation_status', $typeValue);
            }])
                ->where('project_id', $projectUuid)
                ->whereIn('dept_id', $roles['department'])
                ->get();
        }
        return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $response);
    }

    /**
     * @OA\Put(
     *     path="/v1/resource-allocation-approve/{allocated_resources_uuid}",
     *     summary="Resource Allocation Request approve-decline",
     *     operationId="/v1/resource-allocation-approve/{allocated_resources_uuid}",
     *     tags={"Resource-allocation"},
     *     @OA\Parameter(
     *         name="allocated_resources_uuid",
     *         in="path",
     *         description="Allocated Resources UUID",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\RequestBody(
     *         required=true,
     *         description="Post object",
     *         @OA\JsonContent(ref="#/components/schemas/ResourceApprove")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="A post",
     *         @OA\JsonContent(),
     *     ),
     *     @OA\Response(
     *         response="default",
     *         description="unexpected error",
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     *
     * Api for approve/decline resource allocation requests
     */
    public function approveRequest(Request $request, $allocated_uuid)
    {
        $action = '';
        $this->validate($request, self::$aprroveValidationRules);
        $requestData = $request->toArray();
        $globalResponse = [];
        $projectUpdatedStatus = '';
        $projectId = $this->getProjectIdFromAllocatedResourcesUuid($allocated_uuid);
        $departmentId = $this->getDepatmentIdFromAllocatedResourcesUuid($allocated_uuid);
        $requisitionId = $this->getRequisitionIdFromAllocatedResourcesUuid($allocated_uuid);
        $allocationStatus = strval(($requestData['approve_status'] != config('constant.PROJECT_ACTION')['resource_de_allocation_response_decline']) ? $requestData['approve_status'] : config('constant.PROJECT_ACTION')['resource_allocation_response_accept']);
        $isAccess = $this->checkUserAccessForResourceAllocationOperations($request->user->id, $projectId, $allocationStatus);
        if ($isAccess) {
            $response = ResourceAllocation::updateResourceAllocationTableData($allocated_uuid, $request->user->id, $allocationStatus);
            $this->updateResourceRequisitionStatus($requisitionId);
            //Remove record from Performed Action Log
            if ($allocationStatus == config('constant.PROJECT_ACTION')['resource_allocation_response_decline']) {
                PerformedActionLog::where(
                    [
                        'project_id' => $projectId,
                        'user_action_id' => 3,
                        'dept_id' => $departmentId
                    ]
                )->delete();
                $resourceMetaData = ResourceAllocationMeta::where('allocated_resources_uuid', $allocated_uuid)->first();
                $action = config('constant.LOG_ACTIONS.resource_allocation_response_decline');
            }
            $flag = false;
            //check allocation status and if accept then fetch resourceAllocationMeta to resource mapping record
            if ($allocationStatus == config('constant.PROJECT_ACTION')['resource_allocation_response_accept']) {
                $resourceMetaData = ResourceAllocationMeta::where('allocated_resources_uuid', $allocated_uuid)->first();
                $action = config('constant.LOG_ACTIONS.resource_allocation_response_accept');
                if ($resourceMetaData) {
                    $flag = true;
                    $data['start_date'] = $resourceMetaData->start_date;
                    $data['end_date'] = $resourceMetaData->end_date;
                    $data['efforts'] = trim($resourceMetaData->hours);
                    $data['resource_id'] = $resourceMetaData->resource_id;
                    ResourceMapping::storeAllocationMapping($allocated_uuid, $projectId, $data);
                }
                $projectRecord = Project::where('uuid', $projectId)->first();
                $projectAction = [
                    'link_id' => $allocated_uuid,
                    'comment' => config('constant.AM_APPROVE_RESOURCE_CODE'),
                    'status_id' => $projectRecord['status'],
                    'requested_by' => $request->user->id,
                    'previous_status' => $projectRecord['status'],
                    'response_by' => $request->user->id
                ];
                ProjectAction::saveProjectAction($projectAction);
            }
            $this->updateProjectStatusAccordingResources($projectId);
            $resourceAllocation = ResourceAllocation::where('uuid', $allocated_uuid)->first();
            $resourceRequisition = ResourceRequisition::with(['resource', 'requestedUser'])->where('uuid', $resourceAllocation['resource_req_id'])->first();
            $arrayMail = [
                'resource_id' => $resourceMetaData->resource_id,
                'resource_name' => \Helpers::getUserName($resourceMetaData->resource_id),
                'employee_code' => \Helpers::getEmployeeCode($resourceMetaData->resource_id),
                'employee_email' => \Helpers::getUserEmail($resourceMetaData->resource_id),
                'dept_id' => $resourceRequisition['dept_id'],
                'deptartment' => \Helpers::getDepartmentNameByID($resourceRequisition['dept_id']),
                'billing_type' => \Helpers::getBillableType($resourceRequisition['billing_type']),
                'efforts' => trim($resourceMetaData->hours),
                'experience' => trim($resourceAllocation['experience']),
                'allocation_status' => $resourceAllocation['allocation_status'],
                'start_date' => $resourceMetaData->start_date,
                'end_date' => $resourceMetaData->end_date,
                'tech_id' => $resourceRequisition['tech_id'],
                'tech_name' => \Helpers::getTechnolgyNameByID($resourceRequisition['tech_id']),
                'role_id' => $resourceRequisition['role_id'],
                'role_name' => \Helpers::getDesignationNameByID($resourceRequisition['role_id']),
                'resource_requisition' => $resourceRequisition
            ];
            $this->sendMailToReporter($allocationStatus, $projectId, $arrayMail, $departmentId);
            if (!$response) {
                $globalResponse = ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'));
            } else {
                Log::info($this->helpers->addToLog($projectId, $request, $arrayMail, $action));
                $this->helpers->addlogActivityDB($projectId, $request, $arrayMail, $action);
                if ($flag) {
                    $this->resourceMappingByAction($request, $allocated_uuid);
                }
                $globalResponse = ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $response);
            }
        } else {
            Log::error($this->helpers->addToLog($projectId, $request, $e->getMessage(), $action));
            $globalResponse = ApiResponse::genericResponse(config('constant.STATUS_CODE.statusUnauthorized'), '', $e->getMessage());
        }
        return $globalResponse;
    }

    public function updateResourceRequisitionStatus($requisitionId)
    {
        $response = true;
        $requisition = ResourceRequisition::with(['ResourceAllocation'])->where('uuid', $requisitionId)->first();
        if (!empty($requisition['ResourceAllocation'])) {
            foreach ($requisition['ResourceAllocation'] as $key => $value) {
                if ($value['allocation_status'] != config('constant.PROJECT_ACTION')['resource_allocation_response_accept']) {
                    $response = false;
                }
            }
        }
        if ($response) {
            ResourceRequisition::where('uuid', $requisitionId)->update(['status' => config('constant.GENERAL_STATUS')['approve']]);
        }
    }

    /**
     * Allocation status approve mail reporting
     */
    public function sendMailToReporter($allocationStatus, $projectId, $arrayMail, $departmentId = null)
    {
        $departmentArray = [];
        if (isset($departmentId)) {
            array_push($departmentArray, $departmentId);
        }
        $mailService = '';
        if ($allocationStatus == config('constant.PROJECT_ACTION')['resource_allocation_response_accept']) {
            $mailArray = [
                config('constant.TEMPLATES.resource_allocation_approval')
            ];
            foreach ($mailArray as $val) {
                $mailService = new MailService($val, $projectId, $arrayMail, $departmentArray);
                $mailService->sendMail();
            }
            return true;
        } elseif ($allocationStatus == config('constant.PROJECT_ACTION')['resource_allocation_response_decline']) {
            $mailArray = [
                config('constant.TEMPLATES.resource_allocation_rejection')
            ];
            foreach ($mailArray as $val) {
                $mailService = new MailService($val, $projectId, $arrayMail, $departmentArray);
                $mailService->sendMail();
            }
            return true;
        }
        return false;
    }

    public function deAllocationLog($projectId)
    {
        try {
            $logDetails = DeAllocationMapping::with('resource', 'resourceAllocation')
                ->where('project_id', $projectId)
                ->get();
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $logDetails);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }
    public function resourceMapping($request, $reAllocate = false)
    {
        $resourceMapping = new ResourceMappingController($this->helpers);
        foreach ($request['allocation_data'] as $allocation) {
            if ($allocation['efforts'] == $allocation['no_of_hours']) {
                $resourceRequisition = ResourceRequisition::with(['resource', 'requestedUser'])->where('uuid', $allocation['resource_req_id'])->first();
                $resource = ResourceMapping::where('status', 0)
                    ->where('resource_id', $allocation['resource_id'])->where('project_id', $request['project_id'])->first();
                if (isset($resource['uuid'])) {
                    $user_data = LocalUser::where('user_id',  $allocation['resource_id'])->first();
                    $startDate = Carbon::parse($allocation['start_date'])->isoFormat('MMM D, YYYY');
                    $endDate = Carbon::parse($allocation['end_date'])->isoFormat('MMM D, YYYY');
                    $map_data['action'] = false;
                    $map_data['billing_type'] = \Helpers::getBillableType($resourceRequisition['billing_type']);
                    $map_data['dept'] = $reAllocate ? $allocation['department']['name'] : $allocation['department'];
                    $map_data['designation'] = \Helpers::getDesignationNameByID($resourceRequisition['role_id']);
                    $map_data['efforts'] = trim($allocation['efforts']);
                    $map_data['end_date'] = $endDate;
                    $map_data['experience'] = trim($allocation['experience']);
                    $map_data['id'] = $resource['uuid'];
                    $map_data['requested_by'] = $resourceRequisition['requestedUser']['display_name'];
                    $map_data['requested_on'] = $startDate;
                    $map_data['resource_mapping_id'] = $resource['uuid'];
                    $map_data['resource_name'] = \Helpers::getUserName($allocation['resource_id']);
                    $map_data['start_date'] = $startDate;
                    $map_data['status'] = "1";
                    $map_data['tech'] = \Helpers::getTechnolgyNameByID($resourceRequisition['tech_id']);
                    $project = Project::with(['projectManagers'])->where('uuid', $request['project_id'])->first();
                    $mailData = array(
                        'project_manager' => (count($project['projectManagers']) > 0) ? $project['projectManagers'][0]['user']['display_name'] : '',
                        'project_hours' => trim($allocation['efforts']),
                        'email' => $user_data['email']
                    );
                    $request['map_data'] = [$map_data];
                    $request['project_status'] = 7;
                    $status = true;
                    $resourceMapping->mapResource($request, $status);
                    $this->sendEmailToEmployee($request['project_id'], $mailData);
                }
            }
        }
        return 1;
    }

    public function resourceMappingByAction($request, $allocated_uuid)
    {
        $resourceMetaData = ResourceAllocationMeta::where('allocated_resources_uuid', $allocated_uuid)->first();
        $resourceAllocation = ResourceAllocation::where('uuid', $allocated_uuid)->first();
        $resourceRequisition = ResourceRequisition::with(['resource', 'requestedUser'])->where('uuid', $resourceAllocation['resource_req_id'])->first();
        $resource = ResourceMapping::where('status', 0)
            ->where('resource_id', $resourceMetaData->resource_id)->where('project_id', $resourceRequisition['project_id'])->first();
        if (isset($resource['uuid'])) {
            $user_data = LocalUser::where('user_id', $resourceMetaData->resource_id)->first();
            $startDate = Carbon::parse($resourceMetaData->start_date)->isoFormat('MMM D, YYYY');
            $endDate = Carbon::parse($resourceMetaData->end_date)->isoFormat('MMM D, YYYY');
            $map_data['action'] = false;
            $map_data['billing_type'] = \Helpers::getBillableType($resourceRequisition['billing_type']);
            $map_data['dept'] = \Helpers::getDepartmentNameByID($resourceRequisition['dept_id']);
            $map_data['designation'] = \Helpers::getDesignationNameByID($resourceRequisition['role_id']);
            $map_data['efforts'] = trim($resource['efforts']);
            $map_data['end_date'] = $endDate;
            $map_data['experience'] = trim($resourceAllocation['experience']);
            $map_data['id'] = $resource['uuid'];
            $map_data['requested_by'] = $resourceRequisition['requestedUser']['display_name'];
            $map_data['requested_on'] = $startDate;
            $map_data['resource_mapping_id'] = $resource['uuid'];
            $map_data['resource_name'] = \Helpers::getUserName($resourceMetaData->resource_id);
            $map_data['start_date'] = $startDate;
            $map_data['status'] = "1";
            $map_data['tech'] = \Helpers::getTechnolgyNameByID($resourceRequisition['tech_id']);
            $request['map_data'] = [$map_data];
            $request['status'] = 7;
            $request['project_id'] = $resourceRequisition['project_id'];
            $request['project_status'] = 14;
            $status = true;
            $resourceMapping = new ResourceMappingController($this->helpers);
            $resourceMapping->mapResource($request, $status);
            $project = Project::with(['projectManagers'])->where('uuid', $request['project_id'])->first();
            $mailData = array(
                'project_manager' => $project['projectManagers'][0]['user']['display_name'],
                'project_hours' => trim($resourceMetaData->hours),
                'email' => $user_data['email']
            );
            return $this->sendEmailToEmployee($request['project_id'], $mailData);
        }
    }

    public function sendEmailToEmployee($project_id, $mailData)
    {
        $mail = config('constant.TEMPLATES.employee_allocation_email');
        $mailService = new MailService($mail, $project_id, $mailData);
        $mailService->sendMail();
        return 1;
    }
}
