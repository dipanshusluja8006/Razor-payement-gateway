<?php

namespace App\Http\Controllers\Resource;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\WeeklyStatusReport;
use Carbon\Carbon;
use ApiResponse;
use App\Models\Project;
use Helpers;
use App\Models\Department;
use App\Models\UserRole;
use App\ResourceBooking;
use App\User;

class WeeklyStatusReportController extends Controller
{
    public function __construct(Helpers $helpers)
    {
        $this->helpers = $helpers;
        $this->rolesArray = Helpers::getRoleByModel('Role');
        $this->departmentArray = Helpers::getRoleByModel('Department');
    }

    public static $validationRules = [
        'project_id' => 'required|exists:resource_mysql.projects,uuid',
        'sch_cat_status' =>  'required|integer|between:1,3',
        'qlt_cat_status' =>  'required|integer|between:1,3',
        'stf_cat_status' =>  'required|integer|between:1,3',
        'inv_cat_status' =>  'required|integer|between:1,3',
        'rsk_cat_status' =>  'required|integer|between:1,3',
        'eft_cat_status' =>  'required|integer|between:1,3'
    ];

    public static $editRequisitionRules = [
        'resource_data' => 'array',
        'resource_data.*.uuid' => 'required|exists:resource_mysql.weekly_status_reports,uuid'
    ];

    public function index(Request $request)
    {
        try {
            $today = Carbon::now();
            if ($request->week_no) {
                $week_no = $request->week_no;
            } else {
                $week_no = [($today->weekOfYear)];
            }
            if ($request->overall_health_status) {
                $overall_health = $request->overall_health_status;
            } else {
                $overall_health = [1, 2, 3];
            }
            if ($request->billing_type) {
                $billing_type = $request->billing_type;
            } else {
                $billing_type = [];
            }
            if ($request->pmuser_id) {
                $pmuser_id = $request->pmuser_id;
            } else {
                $pmuser_id = [];
            }
            if ($request->project_name) {
                $project_id = $request->project_name;
            } else {
                $project_id = [];
            }
            $clientValue = $request->client_exclation;

            if ($request->client_exclation == 1) {
                $clientexcID = $request->client_exclation;
            } elseif ($request->client_exclation == 2) {
                $clientexcID = 0;
            } else {
                $clientexcID = 3;
            }
            if ($clientexcID == 0) {
                $queryParam = 'sch_cat_clt_esclation=0 and qlt_cat_clt_esclation=0 and stf_cat_clt_esclation=0 
                 and inv_cat_clt_esclation=0 and rsk_cat_clt_esclation=0 and eft_cat_clt_esclation=0';
                $wsrLists = WeeklyStatusReport::whereIn('week_no', $week_no)
                    ->whereIn('overall_health_status', $overall_health)
                    ->whereRaw($queryParam)
                    ->with(['createdByUser', 'projectName', 'userRole'])
                    ->orderBy('week_end_date', 'desc')->get();
            } elseif ($clientexcID == 0 && count($project_id) > 0) {
                $queryParam = 'sch_cat_clt_esclation=0 and qlt_cat_clt_esclation=0 and stf_cat_clt_esclation=0 
                   and inv_cat_clt_esclation=0 and rsk_cat_clt_esclation=0 and eft_cat_clt_esclation=0';
                $wsrLists = WeeklyStatusReport::whereIn('week_no', $week_no)
                    ->whereIn('overall_health_status', $overall_health)
                    ->whereIn('project_id', $project_id)
                    ->whereRaw($queryParam)
                    ->with(['createdByUser', 'projectName', 'userRole'])
                    ->orderBy('week_end_date', 'desc')->get();
            } elseif ($clientexcID == 1) {
                $queryParam = '(sch_cat_clt_esclation=1 or qlt_cat_clt_esclation=1 or stf_cat_clt_esclation=1 
                 or inv_cat_clt_esclation=1 or rsk_cat_clt_esclation=1 or eft_cat_clt_esclation=1)';
                $wsrLists = WeeklyStatusReport::whereIn('week_no', $week_no)
                    ->whereIn('overall_health_status', $overall_health)
                    ->whereRaw($queryParam)
                    ->with(['createdByUser', 'projectName', 'userRole'])
                    ->orderBy('week_end_date', 'desc')->get();
            } elseif ($clientexcID == 1 && count($project_id) > 0) {
                $queryParam = '(sch_cat_clt_esclation=1 or qlt_cat_clt_esclation=1 or stf_cat_clt_esclation=1 
                 or inv_cat_clt_esclation=1 or rsk_cat_clt_esclation=1 or eft_cat_clt_esclation=1)';
                $wsrLists = WeeklyStatusReport::whereIn('week_no', $week_no)
                    ->whereIn('overall_health_status', $overall_health)
                    ->whereIn('project_id', $project_id)
                    ->whereRaw($queryParam)
                    ->with(['createdByUser', 'projectName', 'userRole'])
                    ->orderBy('week_end_date', 'desc')->get();
            } elseif (count($project_id) > 0 && $clientexcID == 3) {
                $wsrLists = WeeklyStatusReport::whereIn('week_no', $week_no)
                    ->whereIn('overall_health_status', $overall_health)
                    ->whereIn('project_id', $project_id)
                    ->with(['createdByUser', 'projectName', 'userRole'])
                    ->orderBy('week_end_date', 'desc')->get();
            } else {
                $wsrLists = WeeklyStatusReport::whereIn('week_no', $week_no)
                    ->whereIn('overall_health_status', $overall_health)
                    ->with(['createdByUser', 'projectName', 'userRole'])
                    ->orderBy('week_end_date', 'desc')->get();
            }
            $filterWsr = [];
            foreach ($wsrLists as $wsr) {
                $billing_typeID = $wsr['projectName']['billingType']['id'];
                if (count($pmuser_id) > 0) {
                    foreach ($wsr['userRole'] as $userRoleValue) {
                        $PMuser_id = $userRoleValue['user_id'];
                        if (in_array($PMuser_id, $pmuser_id)) {
                            if (count($billing_type) > 0) {
                                if (in_array($billing_typeID, $billing_type)) {
                                    $filterWsr[] = $wsr;
                                    break;
                                }
                            } else {
                                $filterWsr[] = $wsr;
                            }
                        }
                    }
                } else {
                    if (count($billing_type) > 0) {
                        if (in_array($billing_typeID, $billing_type)) {
                            $filterWsr[] = $wsr;
                        }
                    } else {
                        $filterWsr[] = $wsr;
                    }
                }
            }
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $filterWsr);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function show(Request $request, $uuid)
    {
        try {
            $viewWsrDetails = WeeklyStatusReport::with(['projectName'])->where('uuid', $uuid)->firstOrFail();
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $viewWsrDetails);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function checkOverallHealth($wsrLists)
    {
        $overallCount = [];
        $sumResult = 0;
        $resultHealth = '';
        foreach ($wsrLists as $key => $value) {
            $value->overallHealthCount = 0;
            $value->overallHealthStatus = '';
            if (
                $value->sch_cat_status && $value->qlt_cat_status && $value->stf_cat_status && $value->inv_cat_status
                && $value->rsk_cat_status && $value->eft_cat_status
            ) {
                $sumResult = number_format(($value->sch_cat_status * 0.3 + $value->qlt_cat_status * 0.3
                    + $value->stf_cat_status * 0.1 + $value->inv_cat_status * 0.1 + $value->rsk_cat_status * 0.1 + $value->eft_cat_status * 0.1), 2);
            }
            if ($sumResult < 2.5) {
                $resultHealth = 1;
            } elseif ($sumResult >= 2.5 && $sumResult < 3) {
                $resultHealth = 2;
            } else {
                $resultHealth = 3;
            }
            $value->overallHealthCount = $sumResult;
            $value->overallHealthStatus = $resultHealth;
            array_push($overallCount, $value);
        }
        return $overallCount;
    }
    public function store(Request $request)
    {
        $this->validate($request, self::$validationRules);
        try {
            $sumResult = 0;
            $resultHealth = '';
            if (
                $request->sch_cat_status && $request->qlt_cat_status && $request->stf_cat_status && $request->inv_cat_status
                && $request->rsk_cat_status && $request->eft_cat_status
            ) {
                $sumResult = number_format(($request->sch_cat_status * 0.3 + $request->qlt_cat_status * 0.3
                    + $request->stf_cat_status * 0.1 + $request->inv_cat_status * 0.1 + $request->rsk_cat_status * 0.1 + $request->eft_cat_status * 0.1), 2);
            }
            if ($sumResult < 2.5) {
                $resultHealth = 1;
            } elseif ($sumResult >= 2.5 && $sumResult < 3) {
                $resultHealth = 2;
            } else {
                $resultHealth = 3;
            }
            $today = Carbon::today();
            $weekNumber = $today->weekOfYear;
            $weekStartDate = $today->startOfWeek()->toDateString();
            $weekEndDate = $today->endOfWeek()->toDateString();
            $date = Carbon::createFromFormat('Y-m-d', $weekEndDate);
            $finalWeekEnddate = $date->subDays(2)->format('Y-m-d');
            $data = [
                'project_id' => $request->project_id,
                'sch_cat_clt_esclation' => isset($request->sch_cat_clt_esclation) ? $request->sch_cat_clt_esclation : 0,
                'sch_cat_status' => $request->sch_cat_status,
                'sch_cat_remark' => $request->sch_cat_remark,
                'qlt_cat_clt_esclation' => isset($request->qlt_cat_clt_esclation) ? $request->qlt_cat_clt_esclation : 0,
                'qlt_cat_status' => $request->qlt_cat_status,
                'qlt_cat_remark' => $request->qlt_cat_remark,
                'stf_cat_clt_esclation' => isset($request->stf_cat_clt_esclation) ? $request->stf_cat_clt_esclation : 0,
                'stf_cat_status' => $request->stf_cat_status,
                'stf_cat_remark' => $request->stf_cat_remark,
                'inv_cat_clt_esclation' => isset($request->inv_cat_clt_esclation) ? $request->inv_cat_clt_esclation : 0,
                'inv_cat_status' => $request->inv_cat_status,
                'inv_cat_remark' => $request->inv_cat_remark,
                'rsk_cat_clt_esclation' => isset($request->rsk_cat_clt_esclation) ? $request->rsk_cat_clt_esclation : 0,
                'rsk_cat_status' => $request->rsk_cat_status,
                'rsk_cat_remark' => $request->rsk_cat_remark,
                'eft_cat_clt_esclation' => isset($request->eft_cat_clt_esclation) ? $request->eft_cat_clt_esclation : 0,
                'eft_cat_status' => $request->eft_cat_status,
                'eft_cat_remark' => $request->eft_cat_remark,
                'highlights_remark' => $request->highlights_remark,
                'lowlights_remark' => $request->lowlights_remark,
                'customer_happiness_remark' => $request->customer_happiness_remark,
                'people_happiness_remark' => $request->people_happiness_remark,
                'overall_health_count' => $sumResult,
                'overall_health_status' => $resultHealth,
                'week_no' => $weekNumber,
                'week_start_date' => $weekStartDate,
                'week_end_date' => $finalWeekEnddate,
                'created_by' => $request->user->id
            ];

            $cronWSR = WeeklyStatusReport::whereYear('created_at', $today->format('Y'))
                ->where('project_id', $request->project_id)
                ->where('week_no', $weekNumber)
                ->where('overall_health_status', 4)->get();
            if (count($cronWSR) > 0) {
                $wsrDetails = WeeklyStatusReport::where('uuid', $cronWSR[0]['uuid'])->update($data);
                return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusCreated'), $wsrDetails);
            } else {
                $wsrData = WeeklyStatusReport::whereYear('created_at', $today->format('Y'))->where('project_id', $request->project_id)->where('week_no', $weekNumber)->get();
                if (count($wsrData) > 0) {
                    return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusUnprocessable'), $wsrData, 'Already Exist');
                } else {
                    $wsrDetails = new WeeklyStatusReport($data);
                    $wsrDetails->save();
                    return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusCreated'), $wsrDetails);
                }
            }
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function editWsr(Request $request, $uuid)
    {
        $this->validate($request, self::$editRequisitionRules);
        try {
            $sumResult = 0;
            $resultHealth = '';
            if (
                $request->sch_cat_status && $request->qlt_cat_status && $request->stf_cat_status && $request->inv_cat_status
                && $request->rsk_cat_status && $request->eft_cat_status
            ) {
                $sumResult = number_format(($request->sch_cat_status * 0.3 + $request->qlt_cat_status * 0.3
                    + $request->stf_cat_status * 0.1 + $request->inv_cat_status * 0.1 + $request->rsk_cat_status * 0.1 + $request->eft_cat_status * 0.1), 2);
            }
            if ($sumResult < 2.5) {
                $resultHealth = 1;
            } elseif ($sumResult >= 2.5 && $sumResult < 3) {
                $resultHealth = 2;
            } else {
                $resultHealth = 3;
            }
            $data = [
                'sch_cat_clt_esclation' => isset($request->sch_cat_clt_esclation) ? $request->sch_cat_clt_esclation : 0,
                'sch_cat_status' => $request->sch_cat_status,
                'sch_cat_remark' => $request->sch_cat_remark,
                'qlt_cat_clt_esclation' => isset($request->qlt_cat_clt_esclation) ? $request->qlt_cat_clt_esclation : 0,
                'qlt_cat_status' => $request->qlt_cat_status,
                'qlt_cat_remark' => $request->qlt_cat_remark,
                'stf_cat_clt_esclation' => isset($request->stf_cat_clt_esclation) ? $request->stf_cat_clt_esclation : 0,
                'stf_cat_status' => $request->stf_cat_status,
                'stf_cat_remark' => $request->stf_cat_remark,
                'inv_cat_clt_esclation' => isset($request->inv_cat_clt_esclation) ? $request->inv_cat_clt_esclation : 0,
                'inv_cat_status' => $request->inv_cat_status,
                'inv_cat_remark' => $request->inv_cat_remark,
                'rsk_cat_clt_esclation' => isset($request->rsk_cat_clt_esclation) ? $request->rsk_cat_clt_esclation : 0,
                'rsk_cat_status' => $request->rsk_cat_status,
                'rsk_cat_remark' => $request->rsk_cat_remark,
                'eft_cat_clt_esclation' => isset($request->eft_cat_clt_esclation) ? $request->eft_cat_clt_esclation : 0,
                'eft_cat_status' => $request->eft_cat_status,
                'eft_cat_remark' => $request->eft_cat_remark,
                'highlights_remark' => $request->highlights_remark,
                'lowlights_remark' => $request->lowlights_remark,
                'customer_happiness_remark' => $request->customer_happiness_remark,
                'people_happiness_remark' => $request->people_happiness_remark,
                'overall_health_count' => $sumResult,
                'overall_health_status' => $resultHealth,
                'updated_by' => $request->user->id
            ];
            $response = WeeklyStatusReport::where('uuid', $uuid)->update($data);
            $finalResponse = WeeklyStatusReport::with(['updatedByUser', 'projectName'])->where('uuid', $uuid)->firstOrFail();
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $finalResponse);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function getYearWeekList()
    {
        try {
            $currentWeek = Carbon::now()->weekOfYear;
            $previousWeek = $currentWeek - 1;
            $status = 'default';
            $yearLastMonthDate = Carbon::now()->endOfYear();
            $weekNumber = $yearLastMonthDate->weekOfYear;
            $weekArray = [];
            for ($i = 1; $i <= $weekNumber; $i++) {
                $date = $yearLastMonthDate->setISODate($yearLastMonthDate->year, $i);
                $start_date = $date->startOfWeek()->format('jS M');
                $end_date = $date->endOfWeek()->subDays(2)->format('jS M');
                if ($previousWeek == $i) {
                    $status = 'previousWeek';
                }
                if ($currentWeek == $i) {
                    $status = 'currentWeek';
                }
                $weekArray[] = [
                    'key' => $start_date . ' - ' . $end_date,
                    'value' => $i,
                    'status' => $status
                ];
                $status = 'default';
            }
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $weekArray);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function getBuWiseRagData(Request $request)
    {
        try {
            $today = Carbon::now();
            if ($request->week_no) {
                $week_nos = $request->week_no;
            } else {
                $week_nos = [($today->weekOfYear - 1)];
            }

            if ($request->department_id) {
                $department_id = $request->department_id;
            } else {
                $department_id = [];
            }

            $wsrLists = WeeklyStatusReport::whereIn('week_no', $week_nos)
                ->with(['getDepartment', 'project'])
                ->get()
                ->toArray();
            $dept_array = [];
            foreach ($wsrLists as $wsr) {
                $dept_ids = [];
                $redmineProjectID = $wsr['project']['redmine_project_id'];
                $week_no = $wsr['week_no'];
                foreach ($wsr['get_department'] as $departments) {
                    foreach ($departments['resource_allocation'] as $resourceAllocation) {
                        if ($resourceAllocation['mapped_resource']) {
                            $resource_id = $resourceAllocation['mapped_resource']['resource_id'];
                            $user = User::where('id', $resource_id)->where('status', 1)->first();
                            if (!empty($user)) {
                                $resourceBookings = ResourceBooking::where('project_id', $redmineProjectID)
                                    ->where('assigned_to_id', $resource_id)
                                    ->whereYear('updated_at', $today->year)
                                    ->orderBy('id', 'DESC')
                                    ->get();
                                $dept_id = $departments['dept_id'];
                                foreach ($resourceBookings as  $resourceBooking) {
                                    if (isset($resourceBooking['end_date'])) {
                                        $week = Carbon::parse($resourceBooking['end_date']);
                                        if ($week->weekOfYear >= $week_no && $week->year == $today->year) {
                                            if (!in_array($dept_id, $dept_ids)) {
                                                $dept_ids[] = $dept_id;
                                                $dept_name =  \Helpers::getDepartmentNameByID($dept_id);
                                                if (count($department_id) > 0) {
                                                    if (in_array($dept_id, $department_id)) {
                                                        if ($wsr['overall_health_status'] == 1) {
                                                            if (array_key_exists($dept_name, $dept_array) && isset($dept_array[$dept_name]['red'])) {
                                                                $dept_array[$dept_name]['red'] = $dept_array[$dept_name]['red'] + 1;
                                                            } else {
                                                                $dept_array[$dept_name]['red'] = 1;
                                                            }
                                                        } else if ($wsr['overall_health_status'] == 2) {
                                                            if (array_key_exists($dept_name, $dept_array) && isset($dept_array[$dept_name]['amber'])) {
                                                                $dept_array[$dept_name]['amber'] = $dept_array[$dept_name]['amber'] + 1;
                                                            } else {
                                                                $dept_array[$dept_name]['amber'] = 1;
                                                            }
                                                        } else if ($wsr['overall_health_status'] == 3){
                                                            if (array_key_exists($dept_name, $dept_array) && isset($dept_array[$dept_name]['green'])) {
                                                                $dept_array[$dept_name]['green'] = $dept_array[$dept_name]['green'] + 1;
                                                            } else {
                                                                $dept_array[$dept_name]['green'] = 1;
                                                            }
                                                        }else {
                                                            if (array_key_exists($dept_name, $dept_array) && isset($dept_array[$dept_name]['grey'])) {
                                                                $dept_array[$dept_name]['grey'] = $dept_array[$dept_name]['grey'] + 1;
                                                            } else {
                                                                $dept_array[$dept_name]['grey'] = 1;
                                                            }
                                                        }
                                                    }
                                                } else {
                                                    if ($wsr['overall_health_status'] == 1) {
                                                        if (array_key_exists($dept_name, $dept_array) && isset($dept_array[$dept_name]['red'])) {
                                                            $dept_array[$dept_name]['red'] = $dept_array[$dept_name]['red'] + 1;
                                                        } else {
                                                            $dept_array[$dept_name]['red'] = 1;
                                                        }
                                                    } else if ($wsr['overall_health_status'] == 2) {
                                                        if (array_key_exists($dept_name, $dept_array) && isset($dept_array[$dept_name]['amber'])) {
                                                            $dept_array[$dept_name]['amber'] = $dept_array[$dept_name]['amber'] + 1;
                                                        } else {
                                                            $dept_array[$dept_name]['amber'] = 1;
                                                        }
                                                    } else if ($wsr['overall_health_status'] == 3){
                                                        if (array_key_exists($dept_name, $dept_array) && isset($dept_array[$dept_name]['green'])) {
                                                            $dept_array[$dept_name]['green'] = $dept_array[$dept_name]['green'] + 1;
                                                        } else {
                                                            $dept_array[$dept_name]['green'] = 1;
                                                        }
                                                    }else {
                                                        if (array_key_exists($dept_name, $dept_array) && isset($dept_array[$dept_name]['grey'])) {
                                                            $dept_array[$dept_name]['grey'] = $dept_array[$dept_name]['grey'] + 1;
                                                        } else {
                                                            $dept_array[$dept_name]['grey'] = 1;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            $final_array = [];
            $categories = [];
            $red = [];
            $amber = [];
            $green = [];
            $grey = [];
            foreach ($dept_array as $key => $dep) {
                $red[] = isset($dep['red']) ? $dep['red'] : null;
                $amber[] = isset($dep['amber']) ? $dep['amber'] : null;
                $green[] = isset($dep['green']) ? $dep['green'] : null;
                $grey[] = isset($dep['grey']) ? $dep['grey'] : null;
                $categories[] = $key;
            }
            $final_array = array(
                array(
                    'name' => 'Red',
                    'data' => $red,
                    'categories' => $categories
                ),
                array(
                    'name' => 'Amber',
                    'data' => $amber,
                    'categories' => $categories
                ),
                array(
                    'name' => 'Green',
                    'data' => $green,
                    'categories' => $categories
                ),
                array(
                    'name' => 'Not Available',
                    'data' => $grey,
                    'categories' => $categories
                ),
            );
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $final_array);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function getPMWiseRagData(Request $request)
    {
        try {
            $today = Carbon::now();
            if ($request->user_id) {
                $user_id = $request->user_id;
            } else {
                $user_id = [];
            }
            if ($request->week_no) {
                $week_nos = $request->week_no;
            } else {
                $week_nos = [($today->weekOfYear - 1)];
            }
            $wsrLists = WeeklyStatusReport::with(['userRole'])
                ->select('id', 'project_id', 'overall_health_status')
                ->whereIn('week_no', $week_nos)
                ->get()
                ->toArray();
            $final_array = [];
            $pm_name_array = [];
            foreach ($wsrLists as $wsr) {
                foreach ($wsr['user_role'] as $pmWsr) {
                    if (isset($pmWsr['local_user'])) {
                        if (count($user_id) > 0) {
                            $pm_name = $pmWsr['local_user']['full_name'];
                            if (in_array($pmWsr['local_user']['user_id'], $user_id)) {
                                if ($wsr['overall_health_status'] == 1) {
                                    if (array_key_exists($pm_name, $pm_name_array) && isset($pm_name_array[$pm_name]['red'])) {
                                        $pm_name_array[$pm_name]['red'] =  $pm_name_array[$pm_name]['red'] + 1;
                                    } else {
                                        $pm_name_array[$pm_name]['red'] = 1;
                                    }
                                } else if ($wsr['overall_health_status'] == 2) {
                                    if (array_key_exists($pm_name, $pm_name_array) && isset($pm_name_array[$pm_name]['amber'])) {
                                        $pm_name_array[$pm_name]['amber'] =  $pm_name_array[$pm_name]['amber'] + 1;
                                    } else {
                                        $pm_name_array[$pm_name]['amber'] = 1;
                                    }
                                } else if ($wsr['overall_health_status'] == 3) {
                                    if (array_key_exists($pm_name, $pm_name_array) && isset($pm_name_array[$pm_name]['green'])) {
                                        $pm_name_array[$pm_name]['green'] =  $pm_name_array[$pm_name]['green'] + 1;
                                    } else {
                                        $pm_name_array[$pm_name]['green'] = 1;
                                    }
                                }
                                else {
                                    if (array_key_exists($pm_name, $pm_name_array) && isset($pm_name_array[$pm_name]['grey'])) {
                                        $pm_name_array[$pm_name]['grey'] =  $pm_name_array[$pm_name]['grey'] + 1;
                                    } else {
                                        $pm_name_array[$pm_name]['grey'] = 1;
                                    }
                                }
                            }
                        } else {
                            $pm_name = $pmWsr['local_user']['full_name'];
                            if ($wsr['overall_health_status'] == 1) {
                                if (array_key_exists($pm_name, $pm_name_array) && isset($pm_name_array[$pm_name]['red'])) {
                                    $pm_name_array[$pm_name]['red'] =  $pm_name_array[$pm_name]['red'] + 1;
                                } else {
                                    $pm_name_array[$pm_name]['red'] = 1;
                                }
                            } else if ($wsr['overall_health_status'] == 2) {
                                if (array_key_exists($pm_name, $pm_name_array) && isset($pm_name_array[$pm_name]['amber'])) {
                                    $pm_name_array[$pm_name]['amber'] =  $pm_name_array[$pm_name]['amber'] + 1;
                                } else {
                                    $pm_name_array[$pm_name]['amber'] = 1;
                                }
                            } else if ($wsr['overall_health_status'] == 3) {
                                if (array_key_exists($pm_name, $pm_name_array) && isset($pm_name_array[$pm_name]['green'])) {
                                    $pm_name_array[$pm_name]['green'] =  $pm_name_array[$pm_name]['green'] + 1;
                                } else {
                                    $pm_name_array[$pm_name]['green'] = 1;
                                }
                            }else {
                                if (array_key_exists($pm_name, $pm_name_array) && isset($pm_name_array[$pm_name]['grey'])) {
                                    $pm_name_array[$pm_name]['grey'] =  $pm_name_array[$pm_name]['grey'] + 1;
                                } else {
                                    $pm_name_array[$pm_name]['grey'] = 1;
                                }
                            }
                        }
                    }
                }
            }
            $final_array = [];
            $categories = []; // PM names
            $red = [];
            $amber = [];
            $green = [];
            $grey = [];
            foreach ($pm_name_array as $key => $dep) {
                $red[] = isset($dep['red']) ? $dep['red'] : null;
                $amber[] = isset($dep['amber']) ? $dep['amber'] : null;
                $green[] = isset($dep['green']) ? $dep['green'] : null;
                $grey[] = isset($dep['grey']) ? $dep['grey'] : null;
                $categories[] = $key;
            }
            $final_array = array(
                array(
                    'name' => 'Red',
                    'data' => $red,
                    'categories' => $categories
                ),
                array(
                    'name' => 'Amber',
                    'data' => $amber,
                    'categories' => $categories
                ),
                array(
                    'name' => 'Green',
                    'data' => $green,
                    'categories' => $categories
                ),
                array(
                    'name' => 'Not Available',
                    'data' => $grey,
                    'categories' => $categories
                ),
            );
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $final_array);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function getProjectWiseRagData(Request $request)
    {
        try {
            $today = Carbon::now();
            if ($request->week_no) {
                $week_no = $request->week_no;
            } else {
                $week_no =($today->weekOfYear - 1);
            }
            if ($request->billing_id) {
                $billing_id = $request->billing_id;
            } else {
                $billing_id = config('constant.billing_type');
            }
            $final_array = [];
            $activeProjectStatus = ['12', '13', '1'];
            $projects = Project::select('id', 'uuid', 'project_name', 'billing_type', 'is_draft', 'is_approve', 'status')
                ->whereNotIn('status', $activeProjectStatus)
                ->whereIn('billing_type', $billing_id)
                ->get()->toArray();
            $project_rag_status = [];
            $red = 0;
            $green = 0;
            $amber = 0;
            $grey = 0;
            $red_project = [];
            $green_project = [];
            $amber_project = [];
            $grey_project = [];
            foreach ($projects as $project) {
                $wsr = WeeklyStatusReport::select('project_id', 'overall_health_status')
                    ->where('project_id', $project['uuid'])
                    ->where('week_no', $week_no)
                    ->first();
                if (isset($wsr)) {
                    if ($wsr['overall_health_status'] == 1) {
                        $red = $red + 1;
                        $red_project[] = $project;
                    } else if ($wsr['overall_health_status'] == 2) {
                        $amber = $amber + 1;
                        $amber_project[] = $project;
                    } else if ($wsr['overall_health_status'] == 3) {
                        $green = $green + 1;
                        $green_project[] = $project;
                    }else {
                        $grey = $grey + 1;
                        $grey_project[] = $project;
                    }
                } 
            }
            $final_array = array(
                'Red' => array(
                    'statusCount' => $red,
                    'projects'  => $red_project
                ),
                'Green' => array(
                    'statusCount' => $green,
                    'projects'  => $green_project
                ),
                'Amber' => array(
                    'statusCount' => $amber,
                    'projects'  => $amber_project
                ),
                'UnScheduled' => array(
                    'statusCount' => $grey,
                    'projects'  => $grey_project
                )
            );
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $final_array);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function getDepartmentWiseRagData(Request $request, $deptId = 'default')
    {
        try {
            $today = Carbon::now();
            if ($request->week_no) {
                $week_no = $request->week_no;
            } else {
                $week_no = ($today->weekOfYear - 1);
            }
            $currentUserId = $request->user->id;
            $checkMapped = false;
            $pendingInitiaion = true;
            if ($deptId != 'default') {
                $request->department_id = $deptId;
            }
            $userRole = Helpers::getRole($currentUserId);
            if (in_array($this->rolesArray[config('constant.ROLES.admin')], $userRole['global'])) {
                if ($request->department_id) {
                    $user_role = UserRole::where('role_id', $this->rolesArray[config('constant.ROLES.bu_head')])->where('dept_id', $request->department_id)->first();
                    $userRole = Helpers::getRole($user_role['user_id']);
                    $userRole['department'] = [$request->department_id];
                } else {
                    $user_role = UserRole::where('role_id', $this->rolesArray[config('constant.ROLES.bu_head')])->where('dept_id', 3)->first();
                    $userRole = Helpers::getRole($user_role['user_id']);
                    $userRole['department'] = [$user_role['dept_id']];
                }
            }
            if ($request->department_id) {
                $department_id = $request->department_id;
            } else if (count($userRole['department']) > 0) {
                $department_id = $userRole['department'][0];
            } else {
                $department_id = 3;
            }

            $wsrLists = WeeklyStatusReport::where('week_no', $week_no)
                ->with(['getDepartment', 'project'])
                ->get()
                ->toArray();
            $dept_array = [];
            foreach ($wsrLists as $wsr) {
                $dept_ids = [];
                $redmineProjectID = $wsr['project']['redmine_project_id'];
                foreach ($wsr['get_department'] as $departments) {
                    foreach ($departments['resource_allocation'] as $resourceAllocation) {
                        if ($resourceAllocation['mapped_resource']) {
                            $resource_id = $resourceAllocation['mapped_resource']['resource_id'];
                            $user = User::where('id', $resource_id)->where('status', 1)->first();
                            if (!empty($user)) {
                                $resourceBookings = ResourceBooking::where('project_id', $redmineProjectID)
                                    ->where('assigned_to_id', $resource_id)
                                    ->whereYear('updated_at', $today->year)
                                    ->orderBy('id', 'DESC')
                                    ->get();
                                $dept_id = $departments['dept_id'];
                                foreach ($resourceBookings as  $resourceBooking) {
                                    $dept_id = $departments['dept_id'];
                                    if (isset($resourceBooking['end_date'])) {
                                        $week = Carbon::parse($resourceBooking['end_date']);
                                        if ($week->weekOfYear >= $week_no && $week->year == $today->year) {
                                            if (!in_array($dept_id, $dept_ids)) {
                                                $dept_ids[] = $dept_id;
                                                $dept_name =  \Helpers::getDepartmentNameByID($dept_id);
                                                if ($department_id) {
                                                    if ($department_id == $dept_id) {
                                                        if ($wsr['overall_health_status'] == 1) {
                                                            if (array_key_exists($dept_name, $dept_array) && isset($dept_array[$dept_name]['red'])) {
                                                                $dept_array[$dept_name]['red'] = $dept_array[$dept_name]['red'] + 1;
                                                            } else {
                                                                $dept_array[$dept_name]['red'] = 1;
                                                            }
                                                        } else if ($wsr['overall_health_status'] == 2) {
                                                            if (array_key_exists($dept_name, $dept_array) && isset($dept_array[$dept_name]['amber'])) {
                                                                $dept_array[$dept_name]['amber'] = $dept_array[$dept_name]['amber'] + 1;
                                                            } else {
                                                                $dept_array[$dept_name]['amber'] = 1;
                                                            }
                                                        } else if ($wsr['overall_health_status'] == 3) {
                                                            if (array_key_exists($dept_name, $dept_array) && isset($dept_array[$dept_name]['green'])) {
                                                                $dept_array[$dept_name]['green'] = $dept_array[$dept_name]['green'] + 1;
                                                            } else {
                                                                $dept_array[$dept_name]['green'] = 1;
                                                            }
                                                        }
                                                        else {
                                                            if (array_key_exists($dept_name, $dept_array) && isset($dept_array[$dept_name]['grey'])) {
                                                                $dept_array[$dept_name]['grey'] = $dept_array[$dept_name]['grey'] + 1;
                                                            } else {
                                                                $dept_array[$dept_name]['grey'] = 1;
                                                            }
                                                        }
                                                    }
                                                } else {
                                                    if ($wsr['overall_health_status'] == 1) {
                                                        if (array_key_exists($dept_name, $dept_array) && isset($dept_array[$dept_name]['red'])) {
                                                            $dept_array[$dept_name]['red'] = $dept_array[$dept_name]['red'] + 1;
                                                        } else {
                                                            $dept_array[$dept_name]['red'] = 1;
                                                        }
                                                    } else if ($wsr['overall_health_status'] == 2) {
                                                        if (array_key_exists($dept_name, $dept_array) && isset($dept_array[$dept_name]['amber'])) {
                                                            $dept_array[$dept_name]['amber'] = $dept_array[$dept_name]['amber'] + 1;
                                                        } else {
                                                            $dept_array[$dept_name]['amber'] = 1;
                                                        }
                                                    } else if ($wsr['overall_health_status'] == 3) {
                                                        if (array_key_exists($dept_name, $dept_array) && isset($dept_array[$dept_name]['green'])) {
                                                            $dept_array[$dept_name]['green'] = $dept_array[$dept_name]['green'] + 1;
                                                        } else {
                                                            $dept_array[$dept_name]['green'] = 1;
                                                        }
                                                    }
                                                    else {
                                                        if (array_key_exists($dept_name, $dept_array) && isset($dept_array[$dept_name]['grey'])) {
                                                            $dept_array[$dept_name]['grey'] = $dept_array[$dept_name]['grey'] + 1;
                                                        } else {
                                                            $dept_array[$dept_name]['grey'] = 1;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            $final_array = [];
            $categories = [];
            $red = [];
            $amber = [];
            $green = [];
            $grey = [];
            foreach ($dept_array as $key => $dep) {
                $red[] = isset($dep['red']) ? $dep['red'] : '0';
                $amber[] = isset($dep['amber']) ? $dep['amber'] : '0';
                $green[] = isset($dep['green']) ? $dep['green'] : '0';
                $grey[] = isset($dep['grey']) ? $dep['grey'] : '0';
                $categories[] = $key;
            }
            if (count($categories) == 0) {
                $dept_name =  \Helpers::getDepartmentNameByID($department_id);
                $categories[] = $dept_name;
            }
            $final_array = array(
                'Red' => array(
                    'statusCount' => $red
                ),
                'Green' => array(
                    'statusCount' => $green
                ),
                'Amber' => array(
                    'statusCount' => $amber
                ),
                'UnScheduled' => array(
                    'statusCount' => $grey
                )
            );
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $final_array);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function getDepartmentWiseRagListing(Request $request, $deptId = 'default')
    {
        try {
            $today = Carbon::now();
            if ($request->week_id) {
                $week_no = $request->week_id;
            } else {
                $week_no = [($today->weekOfYear - 1)];
            }
            if ($request->health_id) {
                $overall_health = $request->health_id;
            } else {
                $overall_health = [1, 2, 3];
            }
            if ($request->dept_id) {
                $department_id = $request->dept_id;
            } else {
                $department_id = [];
            }
            if ($request->billing_id) {
                $billing_type = $request->billing_id;
            } else {
                $billing_type = [];
            }

            if ($request->pm_id) {
                $pmuser_id = $request->pm_id;
            } else {
                $pmuser_id = [];
            }
            if ($request->client_exclation == 1) {
                $clientexcID = $request->client_exclation;
            } elseif ($request->client_exclation == 2) {
                $clientexcID = 0;
            } else {
                $clientexcID = 3;
            }
            if ($clientexcID == 0) {
                $queryParam = 'sch_cat_clt_esclation=0 and qlt_cat_clt_esclation=0 and stf_cat_clt_esclation=0 
                 and inv_cat_clt_esclation=0 and rsk_cat_clt_esclation=0 and eft_cat_clt_esclation=0';
                $wsrLists = WeeklyStatusReport::whereIn('week_no', $week_no)
                    ->whereIn('overall_health_status', $overall_health)
                    ->whereRaw($queryParam)
                    ->with(['createdByUser', 'projectName', 'userRole', 'getDepartment', 'project'])
                    ->orderBy('created_at', 'desc')->get()->toArray();
            } elseif ($clientexcID == 1) {
                $queryParam = '(sch_cat_clt_esclation=1 or qlt_cat_clt_esclation=1 or stf_cat_clt_esclation=1 
                 or inv_cat_clt_esclation=1 or rsk_cat_clt_esclation=1 or eft_cat_clt_esclation=1)';
                $wsrLists = WeeklyStatusReport::whereIn('week_no', $week_no)
                    ->whereIn('overall_health_status', $overall_health)
                    ->whereRaw($queryParam)
                    ->with(['createdByUser', 'projectName', 'userRole', 'getDepartment', 'project'])
                    ->orderBy('created_at', 'desc')->get()->toArray();
            } else {
                $wsrLists = WeeklyStatusReport::whereIn('week_no', $week_no)
                    ->whereIn('overall_health_status', $overall_health)
                    ->with(['createdByUser', 'projectName', 'userRole', 'getDepartment', 'project'])
                    ->orderBy('created_at', 'desc')->get()->toArray();
            }
            $dept_array = [];
            foreach ($wsrLists as $wsr) {
                $dept_ids = [];
                $redmineProjectID = $wsr['project']['redmine_project_id'];
                $billing_typeID = $wsr['project']['billing_type'];

                foreach ($wsr['user_role'] as $userRoleValue) {
                    $PMuser_id = $userRoleValue['user_id'];
                    if (count($pmuser_id) > 0) {
                        if (in_array($PMuser_id, $pmuser_id)) {
                            if (count($billing_type) > 0) {
                                if (in_array($billing_typeID, $billing_type)) {
                                    foreach ($wsr['get_department'] as $departments) {
                                        foreach ($departments['resource_allocation'] as $resourceAllocation) {
                                            if ($resourceAllocation['mapped_resource']) {
                                                $resource_id = $resourceAllocation['mapped_resource']['resource_id'];
                                                $user = User::where('id', $resource_id)->where('status', 1)->first();
                                                if (!empty($user)) {
                                                    $resourceBookings = ResourceBooking::where('project_id', $redmineProjectID)
                                                        ->where('assigned_to_id', $resource_id)
                                                        ->whereYear('updated_at', $today->year)
                                                        ->orderBy('id', 'DESC')
                                                        ->get();
                                                    $dept_id = $departments['dept_id'];
                                                    foreach ($resourceBookings as  $resourceBooking) {
                                                        if (isset($resourceBooking['end_date'])) {
                                                            $week = Carbon::parse($resourceBooking['end_date']);
                                                            if ($week->weekOfYear >= $week_no[0] && $week->year == $today->year) {
                                                                if (!in_array($dept_id, $dept_ids)) {
                                                                    $dept_ids[] = $dept_id;
                                                                    $dept_name =  \Helpers::getDepartmentNameByID($dept_id);
                                                                    if (count($department_id) > 0) {
                                                                        if (in_array($dept_id, $department_id)) {
                                                                            $dept_array[$dept_name][] = $wsr;
                                                                        }
                                                                    } else {
                                                                        $dept_array[$dept_name][] = $wsr;
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            } else {
                                foreach ($wsr['get_department'] as $departments) {
                                    foreach ($departments['resource_allocation'] as $resourceAllocation) {
                                        if ($resourceAllocation['mapped_resource']) {
                                            $resource_id = $resourceAllocation['mapped_resource']['resource_id'];
                                            $user = User::where('id', $resource_id)->where('status', 1)->first();
                                            if (!empty($user)) {
                                                $resourceBookings = ResourceBooking::where('project_id', $redmineProjectID)
                                                    ->where('assigned_to_id', $resource_id)
                                                    ->whereYear('updated_at', $today->year)
                                                    ->orderBy('id', 'DESC')
                                                    ->get();
                                                $dept_id = $departments['dept_id'];
                                                foreach ($resourceBookings as  $resourceBooking) {
                                                    if (isset($resourceBooking['end_date'])) {
                                                        $week = Carbon::parse($resourceBooking['end_date']);
                                                        if ($week->weekOfYear >= $week_no[0] && $week->year == $today->year) {
                                                            if (!in_array($dept_id, $dept_ids)) {
                                                                $dept_ids[] = $dept_id;
                                                                $dept_name =  \Helpers::getDepartmentNameByID($dept_id);
                                                                if (count($department_id) > 0) {
                                                                    if (in_array($dept_id, $department_id)) {
                                                                        $dept_array[$dept_name][] = $wsr;
                                                                    }
                                                                } else {
                                                                    $dept_array[$dept_name][] = $wsr;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        if (count($billing_type) > 0) {
                            if (in_array($billing_typeID, $billing_type)) {
                                foreach ($wsr['get_department'] as $departments) {
                                    foreach ($departments['resource_allocation'] as $resourceAllocation) {
                                        if ($resourceAllocation['mapped_resource']) {
                                            $resource_id = $resourceAllocation['mapped_resource']['resource_id'];
                                            $user = User::where('id', $resource_id)->where('status', 1)->first();
                                            if (!empty($user)) {
                                                $resourceBookings = ResourceBooking::where('project_id', $redmineProjectID)
                                                    ->where('assigned_to_id', $resource_id)
                                                    ->whereYear('updated_at', $today->year)
                                                    ->orderBy('id', 'DESC')
                                                    ->get();
                                                $dept_id = $departments['dept_id'];
                                                foreach ($resourceBookings as  $resourceBooking) {
                                                    if (isset($resourceBooking['end_date'])) {
                                                        $week = Carbon::parse($resourceBooking['end_date']);
                                                        if ($week->weekOfYear >= $week_no[0] && $week->year == $today->year) {
                                                            if (!in_array($dept_id, $dept_ids)) {
                                                                $dept_ids[] = $dept_id;
                                                                $dept_name =  \Helpers::getDepartmentNameByID($dept_id);
                                                                if (count($department_id) > 0) {
                                                                    if (in_array($dept_id, $department_id)) {
                                                                        $dept_array[$dept_name][] = $wsr;
                                                                    }
                                                                } else {
                                                                    $dept_array[$dept_name][] = $wsr;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        } else {
                            foreach ($wsr['get_department'] as $departments) {
                                foreach ($departments['resource_allocation'] as $resourceAllocation) {
                                    if ($resourceAllocation['mapped_resource']) {
                                        $resource_id = $resourceAllocation['mapped_resource']['resource_id'];
                                        $user = User::where('id', $resource_id)->where('status', 1)->first();
                                        if (!empty($user)) {
                                            $resourceBookings = ResourceBooking::where('project_id', $redmineProjectID)
                                                ->where('assigned_to_id', $resource_id)
                                                ->whereYear('updated_at', $today->year)
                                                ->orderBy('id', 'DESC')
                                                ->get();
                                            $dept_id = $departments['dept_id'];
                                            foreach ($resourceBookings as  $resourceBooking) {
                                                if (isset($resourceBooking['end_date'])) {
                                                    $week = Carbon::parse($resourceBooking['end_date']);
                                                    if ($week->weekOfYear >= $week_no[0] && $week->year == $today->year) {
                                                        if (!in_array($dept_id, $dept_ids)) {
                                                            $dept_ids[] = $dept_id;
                                                            $dept_name =  \Helpers::getDepartmentNameByID($dept_id);
                                                            if (count($department_id) > 0) {
                                                                if (in_array($dept_id, $department_id)) {
                                                                    $dept_array[$dept_name][] = $wsr;
                                                                }
                                                            } else {
                                                                $dept_array[$dept_name][] = $wsr;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $dept_array);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function destroyWsr($uuid)
    {
        $deleteWsr=false;
        if (isset($uuid)) {
              $deleteWsr = WeeklyStatusReport::where('uuid', $uuid)->delete();
          }
        return $deleteWsr;
    }
}
