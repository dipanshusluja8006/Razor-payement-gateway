<?php

namespace App\Http\Controllers\Resource;

use App\Http\Controllers\Controller;
use App\Models\ProjectActionType;
use ApiResponse;

class ProjectActionTypeController extends Controller
{
    public function index()
    {
        try{
        $projectActionTypes = ProjectActionType::orderBy('priority', 'ASC')->get();
        return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'),$projectActionTypes);
    }catch(\Exception $e ) {
        return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'),'',$e->getMessage());
       }
    }
}
