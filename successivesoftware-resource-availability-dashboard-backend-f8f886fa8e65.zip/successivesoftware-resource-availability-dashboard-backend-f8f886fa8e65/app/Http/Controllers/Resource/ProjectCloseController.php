<?php

namespace App\Http\Controllers\Resource;

use App\Http\Controllers\Controller;
use App\Libraries\MailService;
use App\Models\Project;
use App\Models\ProjectAction;
use App\Project as RedmineProjectModel;
use App\Models\ProjectClosureChecklist;
use Illuminate\Http\Request;
use Webpatser\Uuid\Uuid;
use ApiResponse;
use Helpers;
use Log;
use App\Traits\ResourceControllerTraits;

/**
 * Class ProjectCloseController
 * @package App\Http\Controllers\Resource
 */
class ProjectCloseController extends Controller
{
    use ResourceControllerTraits;

    /**
     * to avoid static strings
     */
    const MESSAGE = 'message';
    const STATUS_ID = 'status_id';
    protected $helpers;

    public function __construct(Helpers $helpers)
    {
        $this->helpers = $helpers;
    }

    /**
     * @OA\Put(
     *     path="/v1/project-close/{projectUUID}",
     *     summary="Project Close",
     *     operationId="/v1/project-close/{projectUUID}",
     *     tags={"Project Close"},
     *     @OA\Parameter(
     *         name="projectUUID",
     *         in="path",
     *         description="Project UUID",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\RequestBody(
     *         required=true,
     *         description="Post object",
     *         @OA\JsonContent(ref="#/components/schemas/ProjectClose")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="A put",
     *         @OA\JsonContent(),
     *     ),
     *     @OA\Response(
     *         response="default",
     *         description="unexpected error",
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     *
     * gets the checkboxIds and status_id
     * update projectClosureChecklist, Project and ProjectAction
     *
     * @param Request $request
     * @param $projectUUID
     * @return \Illuminate\Http\JsonResponse
     */
    public function update(Request $request, $projectUUID)
    {
        $parameters = $request->json()->all();
        $comment_data = (object) [
            "code" => "Project Closed",
            "done_by" => $request->user->id,
            "checkboxIds" => json_encode($parameters['checkboxIds'])
        ];
        try {
            //manage all pending and progress requestion
            $this->deleteAllPendingRequisitionAndMapping($request,$projectUUID);
            $unMappedMailData = $this->MapAllDeAllocationMappingAndSendMail($request,$projectUUID);

            $closureChecklist = ProjectClosureChecklist::updateOrCreate(
                ['project_id' => $projectUUID],
                [
                    'uuid' => (string) Uuid::generate(4),
                    'project_id' => $projectUUID,
                    'project_checklist' => $parameters['checkboxIds'],
                    'updated_by' => $request->user->id
                ]
            );
            if ($closureChecklist) {
                $projectDetails = Project::where('uuid', $projectUUID)->first();
                $status = Project::updateProjectStatus($parameters[self::STATUS_ID], $request->user->id, $projectUUID);
                if ($status['uuid']) {
                    $projectAction = [
                        'link_id' => $status['uuid'],
                        'comment' => json_encode($comment_data, true),
                         self::STATUS_ID => $parameters[self::STATUS_ID],
                        'from' => NULL,
                        'to' => NULL,
                        'previous_status' => $projectDetails['status'],
                        'requested_by' => $request->user->id,
                    ];
                    ProjectAction::saveProjectAction($projectAction);
                    $appFrontendUrl = ['APP_FRONTEND_URL' => config('constant.FRONTEND_URL')];
                    //for mail
                    $mailArray=[config('constant.TEMPLATES.project_close')];
                    foreach($mailArray as $val){
                    $mailService = new MailService($val, $projectUUID, $unMappedMailData,$appFrontendUrl);
                    $mailService->sendMail();
                    }
                    Log::info($this->helpers->addToLog($projectUUID,$request,$closureChecklist,config('constant.LOG_ACTIONS.project_close')));
                    $this->helpers->addlogActivityDB($projectUUID,$request,$closureChecklist,config('constant.LOG_ACTIONS.project_close'));
                    return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $closureChecklist);
                }
            }
        } catch (\Exception $e) {
            Log::error($this->helpers->addToLog($projectUUID,$request,$e->getMessage(),config('constant.LOG_ACTIONS.project_close')));
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function mapProjectClose(Request $request, $projectRedmineID){

        $response =  RedmineProjectModel::where('id', $projectRedmineID)->update(['status' => 5]);
        if($response){
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $response);
        }
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '');
    }
}
