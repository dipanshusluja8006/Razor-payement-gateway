<?php

namespace App\Http\Controllers\Resource;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Models\UserRole;
use App\Models\Department;
use App\CustomValue;
use ApiResponse;
use Helpers;


class BUHeadController extends Controller
{
    protected $helpers;
    public function __construct(Helpers $helpers)
    {
        $this->helpers = $helpers;
        $this->rolesArray = Helpers::getRoleByModel('Role');
        $this->departmentArray = Helpers::getRoleByModel('Department');
    }

    public function BuTotalResources(Request $request)
    {
        $currentUserId = $request->user->id;
        $userRole = Helpers::getRole($currentUserId);
        $bussUnit = config('constant.CUSTOM_VALUES.business_unit');
        // admin case 
        if(count($userRole['global']) == 1 && in_array(1,$userRole['global'])){
            try{
            $resourceCount = CustomValue::where('custom_field_id',$bussUnit)->where('value','<>','N/A')->where('value','<>','')->count();
                return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), ["resourceCount"=>$resourceCount]);
            }catch (\Exception $e) {
                return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
            }
        }else {
            try{
                $userInfo = UserRole::where('user_id',$currentUserId)
                    ->where(function($q){
                        $q->where('role_id', 1)
                        ->orWhere('role_id', 7);
                    })
                    ->pluck('dept_id')->toArray();
                if(count($userInfo)>0){
                    $deptIds = array_filter($userInfo);
                    $deptName = Department::whereIn('id',$deptIds)->pluck('name')->toArray();
                    $resourceCount = CustomValue::where('custom_field_id',$bussUnit)->whereIn('value',$deptName)->count();
                    return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), ["resourceCount"=>$resourceCount]);
    
                }else {
                    return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), ["resourceCount"=>0]);
                }
            }catch (\Exception $e) {
                return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
            }
        }
        
    }

    
}


