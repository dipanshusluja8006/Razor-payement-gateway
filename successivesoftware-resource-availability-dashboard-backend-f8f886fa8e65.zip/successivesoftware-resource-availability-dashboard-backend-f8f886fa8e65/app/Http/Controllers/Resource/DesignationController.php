<?php

namespace App\Http\Controllers\Resource;

use App\Http\Controllers\Controller;
use App\Models\Designation;
use Illuminate\Http\Request;
use ApiResponse;

/**
 *
 * @OA\Get(
 *     path="/v1/designation",
 *     operationId="/v1/designation/index",
 *     summary="Fetch all Designation",
 *     tags={"Designation"},
 *     @OA\Response(
 *         response="200",
 *         description="Returns all Designation",
 *         @OA\JsonContent()
 *     ),
 *     security={
 *      {"api_key_security": {}}
 *     }
 * )
 *
 */
class DesignationController extends Controller
{
    public static $designationValidation = [
        'code' => 'required',
        'name' => 'required',
    ];

    public function index()
    {
        $designation = Designation::orderBy('name', 'ASC')->get();
        return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $designation);
    }

    /**
     * @OA\Post(
     *     path="/v1/designation",
     *     summary="Designation Creation",
     *     operationId="/v1/designation",
     *     tags={"Designation"},
     *     @OA\RequestBody(
     *         required=true,
     *         description="Post object",
     *         @OA\JsonContent(ref="#/components/schemas/DesignationCreation")
     *     ),
     *     @OA\Response(
     *         response=201,
     *         description="A post",
     *         @OA\JsonContent(),
     *     ),
     *     @OA\Response(
     *         response="default",
     *         description="unexpected error",
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     *
     * @param Request $request
     * @return array
     */
    public function store(Request $request)
    {
        $this->validate($request, self::$designationValidation);
        try {
            $data = $request->toArray();
            $designation = Designation::where('name', $data['name'])->first();
            if (!isset($designation)) {
                $designation_data = [
                    'code' => $data['code'],
                    'name' => $data['name'],
                ];
                $newDesignation = new Designation($designation_data);
                $newDesignation->save();
                return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusCreated'), $newDesignation);
            } else {
                return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusForbidden'), '', 'Record Already Exists');
            }
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    /**
     * @OA\Put(
     *     path="/v1/designation/{id}",
     *     summary="Designation Update",
     *     operationId="/v1/designation/{id}",
     *     tags={"Designation"},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="Designation Id",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\RequestBody(
     *         required=true,
     *         description="Post object",
     *         @OA\JsonContent(ref="#/components/schemas/DesignationCreation")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="A post",
     *         @OA\JsonContent(),
     *     ),
     *     @OA\Response(
     *         response="default",
     *         description="unexpected error",
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     *
     * @param Request $request
     * @param $uuid
     * @return \Illuminate\Http\JsonResponse
     * @throws \Illuminate\Validation\ValidationException
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, self::$designationValidation);
        $data = $request->toArray();
        try {
            $designation = Designation::where('id', $id)->first();
            if (isset($designation)) {
                Designation::where('id', $id)->update([
                    'code' => $data['code'],
                    'name' => $data['name']
                    ]);
                $designation = Designation::where('id', $id)->first();
                return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $designation, 'Record Updated');
            } else {
                return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', 'Id does not exist');
            }
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    /**
     * @OA\Delete(
     *     path="/v1/designation/{id}",
     *     summary="Designation Delete",
     *     operationId="/v1/designation/{id}",
     *     tags={"Designation"},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="Designation Id",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Designation Delete",
     *         @OA\JsonContent(),
     *     ),
     *     @OA\Response(
     *         response="default",
     *         description="unexpected error",
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     */
    public function destroy(Request $request, $id)
    {
        try {
            $designation = Designation::where('id', $id)->first();
            if (isset($designation)) {
                Designation::destroy($id);
                return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), '', 'Record Destroy');
            } else {
                return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', 'Id does not exist');
            }
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }
}
