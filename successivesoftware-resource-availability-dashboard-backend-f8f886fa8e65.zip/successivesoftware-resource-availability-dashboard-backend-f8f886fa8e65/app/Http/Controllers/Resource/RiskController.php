<?php

namespace App\Http\Controllers\Resource;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use ApiResponse;
use App\Models\Project;
use Helpers;
use App\Models\Department;
use Carbon\Carbon;

class RiskController extends Controller
{
    protected $helpers;
    /**
     * RiskController constructor.
     */
    public function __construct(Helpers $helpers)
    {
        $this->helpers = $helpers;
        $this->rolesArray = Helpers::getRoleByModel('Role');
        $this->departmentArray = Helpers::getRoleByModel('Department');
    }

    public function activeRisk(Request $request)
    {
        try {
            if ($request->project_id) {
                $uuid = $request->project_id;
                $projects = Project::with(['activeProjectRisk'])
                    ->whereIn('uuid', $uuid)
                    ->orderBy('created_at', 'desc')
                    ->get();
            } else {
                $projects = Project::with(['activeProjectRisk'])
                    ->orderBy('created_at', 'desc')
                    ->get();
            }
            $month_name = [];
            $project_redmine_id = [];
            foreach ($projects as $project) {
                foreach ($project['activeProjectRisk'] as $projectRisk) {
                    $month = date('M', strtotime($projectRisk['created_on']));
                    $status = $projectRisk['priority_id'];
                    $category = isset($projectRisk['riskCategory']) ? $projectRisk['riskCategory']['value'] : '';
                    if (!in_array("All", $request->category_id)) {
                        if (in_array(ucfirst(strtolower($category)), $request->category_id)) {
                            if ($status == 1) {
                                if (array_key_exists($month, $month_name) && isset($month_name[$month]['low'])) {
                                    $month_name[$month]['low'] = $month_name[$month]['low'] + 1;
                                } else {
                                    $month_name[$month]['low'] = 1;
                                }
                            } else if ($status == 2) {
                                if (array_key_exists($month, $month_name) && isset($month_name[$month]['normal'])) {
                                    $month_name[$month]['normal'] = $month_name[$month]['normal'] + 1;
                                } else {
                                    $month_name[$month]['normal'] = 1;
                                }
                            } else if ($status == 3) {
                                if (array_key_exists($month, $month_name) && isset($month_name[$month]['high'])) {
                                    $month_name[$month]['high'] = $month_name[$month]['high'] + 1;
                                } else {
                                    $month_name[$month]['high'] = 1;
                                }
                            } else if ($status == 4) {
                                if (array_key_exists($month, $month_name) && isset($month_name[$month]['blocker'])) {
                                    $month_name[$month]['blocker'] = $month_name[$month]['blocker'] + 1;
                                } else {
                                    $month_name[$month]['blocker'] = 1;
                                }
                            } else {
                                if (array_key_exists($month, $month_name) && isset($month_name[$month]['immediate'])) {
                                    $month_name[$month]['immediate'] = $month_name[$month]['immediate'] + 1;
                                } else {
                                    $month_name[$month]['immediate'] = 1;
                                }
                            }
                            if (!in_array($project['redmine_project_id'], $project_redmine_id)) {
                                $project_redmine_id[] = $project['redmine_project_id'];
                            }
                        }
                    } else {
                        if ($status == 1) {
                            if (array_key_exists($month, $month_name) && isset($month_name[$month]['low'])) {
                                $month_name[$month]['low'] = $month_name[$month]['low'] + 1;
                            } else {
                                $month_name[$month]['low'] = 1;
                            }
                        } else if ($status == 2) {
                            if (array_key_exists($month, $month_name) && isset($month_name[$month]['normal'])) {
                                $month_name[$month]['normal'] = $month_name[$month]['normal'] + 1;
                            } else {
                                $month_name[$month]['normal'] = 1;
                            }
                        } else if ($status == 3) {
                            if (array_key_exists($month, $month_name) && isset($month_name[$month]['high'])) {
                                $month_name[$month]['high'] = $month_name[$month]['high'] + 1;
                            } else {
                                $month_name[$month]['high'] = 1;
                            }
                        } else if ($status == 4) {
                            if (array_key_exists($month, $month_name) && isset($month_name[$month]['blocker'])) {
                                $month_name[$month]['blocker'] = $month_name[$month]['blocker'] + 1;
                            } else {
                                $month_name[$month]['blocker'] = 1;
                            }
                        } else {
                            if (array_key_exists($month, $month_name) && isset($month_name[$month]['immediate'])) {
                                $month_name[$month]['immediate'] = $month_name[$month]['immediate'] + 1;
                            } else {
                                $month_name[$month]['immediate'] = 1;
                            }
                        }
                        if (!in_array($project['redmine_project_id'], $project_redmine_id)) {
                            $project_redmine_id[] = $project['redmine_project_id'];
                        }
                    }
                }
            }
            $data = array();
            $monthArray = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
            for ($i = 0; $i < count($monthArray); $i++) {
                $monthName = $monthArray[$i];
                foreach ($month_name as $key => $month_data) {
                    if ($key == $monthName) {
                        $data['low'][] = isset($month_data['low']) ? $month_data['low'] : 0;
                        $data['normal'][] = isset($month_data['normal']) ? $month_data['normal'] : 0;
                        $data['high'][] = isset($month_data['high']) ? $month_data['high'] : 0;
                        $data['blocker'][] = isset($month_data['blocker']) ? $month_data['blocker'] : 0;
                        $data['immediate'][] = isset($month_data['immediate']) ? $month_data['immediate'] : 0;
                        $data['categories'][] = $monthName;
                    }
                }
                if (!array_key_exists($monthName, $month_name)) {
                    $data['low'][] =  0;
                    $data['normal'][] = 0;
                    $data['high'][] = 0;
                    $data['blocker'][] = 0;
                    $data['immediate'][] = 0;
                    $data['categories'][] = $monthName;
                }
            }

            $final_array = array(
                array(
                    'name' => 'Low',
                    'data' => $data['low'],
                    'categories' => $data['categories'],
                    'project_redmine_id' => $project_redmine_id
                ),
                array(
                    'name' => 'Normal',
                    'data' => $data['normal'],
                    'categories' => $data['categories'],
                    'project_redmine_id' => $project_redmine_id
                ),
                array(
                    'name' => 'High',
                    'data' => $data['high'],
                    'categories' => $data['categories'],
                    'project_redmine_id' => $project_redmine_id
                ),
                array(
                    'name' => 'Blocker',
                    'data' => $data['blocker'],
                    'categories' => $data['categories'],
                    'project_redmine_id' => $project_redmine_id
                ),
                array(
                    'name' => 'Immediate',
                    'data' => $data['immediate'],
                    'categories' => $data['categories'],
                    'project_redmine_id' => $project_redmine_id
                ),
            );
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $final_array);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }
}
