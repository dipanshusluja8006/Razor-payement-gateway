<?php

namespace App\Http\Controllers\Resource;

use App\Http\Controllers\Controller;
use App\Models\LifeCycle;
use ApiResponse;

class LifeCycleController extends Controller
{
    public function index()
    {
        try {
            $lifeCycles = LifeCycle::all();
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $lifeCycles);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }
}
