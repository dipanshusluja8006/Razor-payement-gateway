<?php

namespace App\Http\Controllers\Resource;

use App\Http\Controllers\Controller;
use App\Models\ProjectClosureChecklist;
use App\Models\Project;
use Illuminate\Http\Request;
use Webpatser\Uuid\Uuid;
use Helpers;
use ApiResponse;
use Log;

class ProjectClosureController extends Controller
{

    protected $helpers;

    public function __construct(Helpers $helpers)
    {
        $this->helpers = $helpers;
    }

    /**
     * @OA\Post(
     *     path="/v1/project-closure",
     *     summary="Project Closure",
     *     operationId="/v1/project-closure",
     *     tags={"Project Closure"},
     *     @OA\Parameter(
     *         name="projectUUID",
     *         in="path",
     *         description="Project UUID",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\RequestBody(
     *         required=true,
     *         description="Post object",
     *         @OA\JsonContent(ref="#/components/schemas/ProjectClosure")
     *     ),
     *     @OA\Response(
     *         response=201,
     *         description="A post",
     *         @OA\JsonContent(),
     *     ),
     *     @OA\Response(
     *         response="default",
     *         description="unexpected error",
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     *
     * create a new project closure checklist
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     * @throws \Exception
     */
    public function create(Request $request)
    {
        $parameters = $request->json()->all();
        try {
            $projectClosureChecklist = ProjectClosureChecklist::firstOrCreate(
                ['project_id' => $parameters['projectId']],
                [
                    'uuid' => (string) Uuid::generate(4),
                    'project_checklist' => $parameters['checkboxIds'],
                    'updated_by' => $request->user->id,
                ]
            );
            $request->merge(['project_id' => $parameters['projectId']]);
            Log::info($this->helpers->addToLog($$parameters['projectId'],$request,$projectClosureChecklist,config('constant.LOG_ACTIONS.update_project_closure_checklist')));
            $this->helpers->addlogActivityDB($$parameters['projectId'],$request,$projectClosureChecklist,config('constant.LOG_ACTIONS.update_project_closure_checklist'));
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusCreated'), $projectClosureChecklist);
        } catch (\Exception $e) {
            Log::error($this->helpers->addToLog($parameters['projectId'],$request,$e->getMessage(),config('constant.LOG_ACTIONS.update_project_closure_checklist')));
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    /**
     * get the record acc to projectId
     *
     * @param $projectId
     * @return \Illuminate\Http\JsonResponse
     */
    public function show(Request $request, $projectId)
    {
        try {
            $projectClosureChecklist = ProjectClosureChecklist::where('project_id', $projectId)
                ->first();
            $project = Project::where('uuid', $projectId)->first();
            $project_name = $project['project_name'];
            $redmineProjectID = Helpers::projectIDRedmine($project_name);
            $project_close_status=true;
            if(isset($redmineProjectID)){
                $project_close_status=false;
            }
            if($projectClosureChecklist){
                $projectClosureChecklist->project_close_status = $project_close_status;
                $projectClosureChecklist->project_redmine_id = $redmineProjectID;
            }
            $message = "Fetched Successfully";
            if (is_null($projectClosureChecklist)) {
                $projectClosureChecklist = new \stdClass();
                $message = 'No Data Found';
            }
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $projectClosureChecklist, $message);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }


    /**
     * @OA\Put(
     *     path="/v1/project-closure/{uuid}",
     *     summary="Project Closure",
     *     operationId="/v1/project-closure/{uuid}",
     *     tags={"Project Closure"},
     *     @OA\Parameter(
     *         name="projectUUID",
     *         in="path",
     *         description="Project UUID",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\RequestBody(
     *         required=true,
     *         description="Post object",
     *         @OA\JsonContent(ref="#/components/schemas/UpdateProjectClosure")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="A put",
     *         @OA\JsonContent(),
     *     ),
     *     @OA\Response(
     *         response="default",
     *         description="unexpected error",
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     *
     * update the list
     *
     * @param Request $request
     * @param $projectId
     * @return \Illuminate\Http\JsonResponse
     */
    public function update(Request $request, $projectId)
    {
        try {
            $projectClosureChecklist = ProjectClosureChecklist::where('project_id', $projectId)->first();
            if (!is_null($projectClosureChecklist)) {
                $projectClosureChecklist->update(['project_checklist' => $request->checkboxIds]);
                $message = 'Record Updated Successfully';
            } else {
//                    $projectClosureChecklist = new \stdClass();
                $message = 'No Data Found';
            }
            Log::info($this->helpers->addlogActivityDB($projectId,$request->merge(['project_id' => $projectId]),$projectClosureChecklist,config('constant.LOG_ACTIONS.update_project_closure_checklist')));
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $projectClosureChecklist, $message);
        } catch (\Exception $e) {
            Log::error($this->helpers->addlogActivityDB($request->merge(['project_id' => $projectId]),$e->getMessage(),config('constant.LOG_ACTIONS.update_project_closure_checklist')));
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }
}
