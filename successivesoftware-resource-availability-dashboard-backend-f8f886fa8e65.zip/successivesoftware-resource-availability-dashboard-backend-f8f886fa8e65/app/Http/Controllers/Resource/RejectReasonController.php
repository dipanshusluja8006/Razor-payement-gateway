<?php

namespace App\Http\Controllers\Resource;

use App\Http\Controllers\Controller;
use ApiResponse;
use App\Models\RejectReason;

class RejectReasonController extends Controller
{

    public function index()
    {
        try {
            $rejectReasons = RejectReason::all();
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $rejectReasons);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }
}
