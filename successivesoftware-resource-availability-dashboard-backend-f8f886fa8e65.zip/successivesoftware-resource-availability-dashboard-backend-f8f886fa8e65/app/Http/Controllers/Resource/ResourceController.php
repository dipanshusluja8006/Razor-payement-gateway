<?php

namespace App\Http\Controllers\Resource;

use App\Http\Controllers\Controller;
use Illuminate\Http\Response;
use DB;
use Laravel\Lumen\Http\ResponseFactory;
use log;
use Helpers;
use App\Project;
use App\CustomFieldEnumeration;
use App\Models\Project as PMOProjectModel;
use ApiResponse;
use Carbon\Carbon;


class ResourceController extends Controller
{

    /**
     * we are passing (name = locations) in PossibleValuesArray function for find locations data;
     * calling sendResponse() function for create response passing $location for data and $message for message
     * @return Response|ResponseFactory
     */

    public function location()
    {
        log::info('into location');
        $location =  [
            "Noida",
            "Pune",
            "Other"
        ]; //Helpers::PossibleValuesArray(config('constant.CUSTOM_VALUES.location'));
        if ($location) {
            $message = 'location fetch successfully';
        } else {
            $message = 'Unable to fetch location';
        }
        return Helpers::sendResponse($location, $message);
    }

    /**
     * we are passing (name = Department) in PossibleValuesArray() function for find Department data;
     * calling sendResponse() function for create response passing $department for data and $message for message
     * @return Response|ResponseFactory
     */
    public function department()
    {
        $department = Helpers::PossibleValuesArray(config('constant.CUSTOM_VALUES.business_unit'));
        if ($department) {
            $message = 'Department fetch successfully';
        } else {
            $message = 'Unable to fetch Department';
        }
        return Helpers::sendResponse($department, $message);
    }

    /**
     * this function is showing billing type listing data;
     * calling sendResponse() function for create response passing $billing for data and $message for message
     * @return Response|ResponseFactory
     */
    public function billing()
    {
        $billing = CustomFieldEnumeration::where('custom_field_id', '!=', 53)->get(['id', 'name']);
        if ($billing) {
            $message = 'Billing Type fetch successfully';
        } else {
            $message = 'Unable to fetch Billing Type';
        }
        return Helpers::sendResponse($billing, $message);
    }

    /**
     * this function is showing projects listing data;
     * calling sendResponse() function for create response passing $project for data and $message for message
     * @return Response|ResponseFactory
     */

    public function project()
    {
        log::info('into project');
        $redmineProject = Project::whereHas('userProjects', function ($q) {
            $q->where('status', config('constant.REDMINE_PROJECTSTATUS.activeProject'));
        })->with('userProjects')->get(['id', 'name', 'status']);

        $pmoProject = PMOProjectModel::get(['redmine_project_id', 'project_name']);
        $projects = [];
        foreach ($redmineProject as $redmine) {
            foreach ($pmoProject as $pmo) {
                if ($pmo->redmine_project_id == $redmine->id || strtolower(str_replace(' ', '', $pmo->project_name)) == strtolower(str_replace(' ', '', $redmine->name))) {
                    $projects[] = $redmine;
                }
            }
        }

        if ($projects) {
            $message = 'projects fetch successfully';
        } else {
            $message = 'Unable to fetch projects';
        }
        return Helpers::sendResponse($projects, $message);
    }

    public function getResourceExperience()
    {
        try {
            $result = Helpers::getKekaData();
            $exp1 = 0;
            $exp2 = 0;
            $exp3 = 0;
            $exp4 = 0;
            $resource_expereince = [];
            $expereince1 = [];
            $expereince2 = [];
            $expereince3 = [];
            $expereince4 = [];
            foreach ($result as $key => $value) {
                $PriviousExp = 0;
                foreach ($value['experienceDetails'] as $experienceDetails) {
                    if (isset($experienceDetails['dateOfJoining']) && isset($experienceDetails['dateOfRelieving'])) {
                        $dateOfJoining = Carbon::createFromDate($experienceDetails['dateOfJoining']);
                        $dateOfRelieving = Carbon::createFromDate($experienceDetails['dateOfRelieving']);
                        $PriviousExp = $PriviousExp + $dateOfJoining->diffInDays($dateOfRelieving);
                    }
                }
                $dateOfJoining = Carbon::createFromDate($value['joiningDate']);
                $now = Carbon::now();
                $currentExp = $dateOfJoining->diffInDays($now);
                $totaldays = $PriviousExp + $currentExp;
                $years = ($totaldays / 365); // days / 365 days
                $years1 = round($years, 1);
                $years = floor($years); // Remove all decimals
                $month = ($totaldays % 365) / 30.5; // I choose 30.5 for Month (30,31) ;)
                $month = floor($month); // Remove all decimals
                $data = [
                    'experienceInYearMonth' => $years . " years " . $month . " months",
                    'experience' => $years1,
                    'employeeNumber' => $value['employeeNumber'],
                    'displayName' => $value['displayName'],
                    'email' => $value['email'],
                    'jobTitle' => $value['jobTitle']['title']
                ];
                if ($years1 > 0 && $years1 <= 3) {
                    $exp1 = $exp1 + 1;
                    $expereince1[] =  $data;
                } else if ($years1 >= 3 && $years1 <= 6) {
                    $exp2 = $exp2 + 1;
                    $expereince2[] =  $data;
                } else if ($years1 >= 6 && $years1 <= 10) {
                    $exp3 = $exp2 + 1;
                    $expereince3[] =  $data;
                } else {
                    $exp4 = $exp4 + 1;
                    $expereince4[] =  $data;
                }
            }
            $resource_expereince = array(
                '0-3' => array('count' => $exp1, 'users' => $expereince1),
                '3-6' => array('count' => $exp2, 'users' => $expereince2),
                '6-10' => array('count' => $exp3, 'users' => $expereince3),
                '10-20' => array('count' => $exp4, 'users' => $expereince4)
            );
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $resource_expereince);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function categories()
    {
        $categories = Helpers::PossibleValuesArray(config('constant.CUSTOM_VALUES.categories'));
        if ($categories) {
            $resultArray[]=['id' => '', 'name' => 'All'];
            foreach($categories as $key=>$value){
                $resultArray[]=['id' => $key+1, 'name' => $value];
            }
            $message = 'categories fetch successfully';
        } else {
            $message = 'Unable to fetch categories';
        }
        return Helpers::sendResponse($resultArray, $message);
    }
}
