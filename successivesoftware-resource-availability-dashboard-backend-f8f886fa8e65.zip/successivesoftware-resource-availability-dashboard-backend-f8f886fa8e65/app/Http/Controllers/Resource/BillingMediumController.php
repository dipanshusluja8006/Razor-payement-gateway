<?php

namespace App\Http\Controllers\Resource;

use App\Http\Controllers\Controller;
use App\Models\BillingMedium;
use ApiResponse;

class BillingMediumController extends Controller
{
    public function index()
    {
        try {
             $billingMedium = BillingMedium::all();
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $billingMedium);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }
}
