<?php

namespace App\Http\Controllers\Resource;

use App\EmailAddresse;
use App\Http\Controllers\Controller;
use App\Models\Department;
use App\Models\LocalUser;
use App\Models\Project;
use App\Models\ProjectRole;
use App\User;
use App\Models\UserRole;
use App\Models\Role;
use App\Models\LogActivity;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Helpers;
use Webpatser\Uuid\Uuid;
use ApiResponse;
use Successive\Keka\Http\Services\EmployeeService;


class UserController extends Controller
{

    /**
     * UserController constructor.
     */
    public function __construct()
    {
        $this->rolesArray = Helpers::getRoleByModel('Role');
    }

    public function index()
    {
        $user = LocalUser::select(
            'user_id as id',
            'full_name',
            'email',
            'employee_id',
            'job_title'
        )
            ->with(['userDepartment'])
            ->where('status', config('constant.REDMINE_USERSTATUS.activeUser'))
            ->where('type', config('constant.REDMINE_USERSTATUS.userType'))->get();
        $userDetails = Helpers::mapDepartmentWithUser($user);
        return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $userDetails);
    }

    public function mapJobProfileWithUser($users)
    {
        $data = [];
        $result = Helpers::getKekaData();
        foreach ($users as $user) {
            foreach ($result as $key => $value) {
                if (trim($value['employeeNumber']) == trim($user['employee_id']) || trim($value['email']) == trim($user['email'])) {
                    $user->job_title = isset($value['jobTitle']['title']) ? $value['jobTitle']['title'] : '';
                    $data[] = $user;
                }
            }
        }
        return $data;
    }


    public static $updateUserAdminAccessValidationRules = [
        'email' => 'required',
        'global_role' => 'required',
        'department' => 'required'
    ];

    public static $deleteUserAdminAccessValidationRules = [
        'email' => 'required'
    ];

    public static $validationRules = [
        'login' => 'required',
        'hashed_password' => 'required',
        'firstname' => 'required',
        'lastname' => 'required',
        'must_change_passwd' => 'required',
        'mail_notification' => 'required',
        'email' => 'required'

    ];


    public function userUserRole(Request $request)
    {
        try {

            $userRole = UserRole::where('user_id', $request->user->id)
                ->with(['role', 'department'])
                ->get();
            $AllRoles = Helpers::getRole($request->user->id);
            $projectRole = $this->checkProjectRole($request->user->id, $AllRoles);
            $data['projectDashboard'] = false;
            $data['projectInitiation'] = false;
            if (
                in_array($this->rolesArray[config('constant.ROLES.sales')], $AllRoles['global']) ||
                in_array($this->rolesArray[config('constant.ROLES.global_operation')], $AllRoles['global']) ||
                in_array($this->rolesArray[config('constant.ROLES.admin')], $AllRoles['global']) ||
                in_array($this->rolesArray[config('constant.ROLES.bu_head')], $AllRoles['global']) ||
                in_array($this->rolesArray[config('constant.ROLES.go_team')], $AllRoles['global'])
            ) {
                $data['projectInitiation'] = true;
            }
            $data['userRole'] = $userRole;
            if ($projectRole) {
                $data['projectDashboard'] = true;
            }
            if (in_array($this->rolesArray[config('constant.ROLES.go_team')], $AllRoles['global'])) {
                $data['go_team'] = true;
            } else {
                $data['go_team'] = false;
            }
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $data);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function destroyUserRole(Request $request)
    {
        try {
            $this->validate($request, self::$deleteUserAdminAccessValidationRules);
            $data = $request->toArray();
            $response = 'User Not Found';
            $userDetail = EmailAddresse::where('address', $data['email'])->first();
            if (isset($userDetail->user_id)) {
                $response = UserRole::where(['user_id' => $userDetail['user_id'], 'project_id' => null])->delete();
            }
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $response);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function checkProjectRole($userId, $userRole)
    {
        $projectRole = false;
        $projects = Project::where('created_by', $userId)->get();
        if (
            in_array($this->rolesArray[config('constant.ROLES.admin')], $userRole['global']) ||
            in_array($this->rolesArray[config('constant.ROLES.global_operation')], $userRole['global']) ||
            in_array($this->rolesArray[config('constant.ROLES.sales')], $userRole['global']) ||
            in_array($this->rolesArray[config('constant.ROLES.resource_manager')], $userRole['global'])
        ) {
            $projectRole = true;
        } else if ((in_array($this->rolesArray[config('constant.ROLES.bu_head')], $userRole['global']) || in_array($this->rolesArray[config('constant.ROLES.go_team')], $userRole['global'])) && count($projects) > 0) {
            $projectRole = true;
        } else {
            $projects = Project::with(['UserRole' => function ($query) use ($userId) {
                $query->where('user_id', $userId);
            }, 'ResourceRequisition' => function ($query) use ($userRole) {
                $query->whereIn('dept_id', $userRole['department']);
            }])->get();
            if ($projects) {
                foreach ($projects as $key => $value) {
                    if (count($value['ResourceRequisition']) > 0 || count($value['UserRole']) > 0) {
                        $projectRole = true;
                        break;
                    }
                }
            }
        }
        return $projectRole;
    }

    public function update(Request $request)
    {
        $this->validate($request, self::$updateUserAdminAccessValidationRules);
        $data = $request->toArray();
        $globalResponse = ['message' => 'Not Access', 'status' => 401];
        $globalResponse = ['data' => '', 'message' => 'User Not Found', 'status' => 404];
        $userDetail = EmailAddresse::where('address', $data['email'])->first();
        if (isset($userDetail->user_id)) {
            $roleExists = Role::where('id', $data['global_role'])->first();
            if (isset($roleExists)) {
                if (isset($data['delete']) && $data['delete']) {
                    UserRole::where(['user_id' => $userDetail['user_id'], 'project_id' => null])->delete();
                }
                if ($data['global_role'] == $this->rolesArray[config('constant.ROLES.bu_head')]) {
                    $roleMeta = [
                        'user_id' => $userDetail['user_id'],
                        'role_id' => $data['global_role'],
                        'dept_id' => $data['department']
                    ];
                } else {
                    $roleMeta = [
                        'user_id' => $userDetail['user_id'],
                        'role_id' => $data['global_role']
                    ];
                }
                $existGlobalRole = UserRole::where($roleMeta)->first();
                if (!isset($existGlobalRole)) {
                    $globalRole = new UserRole($roleMeta);
                    $globalRole->save();
                    $globalResponse = ApiResponse::genericResponse(config('constant.STATUS_CODE.statusCreated'), $globalRole, 'Global Role Created');
                } else {
                    $globalResponse = ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $existGlobalRole, 'Global Role Already assigned');
                }
            } else {
                $globalResponse = ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'));
            }
        }
        return $globalResponse;
    }


    /**
     * Api for Create User on DB
     */
    public function store(Request $request)
    {
        $this->validate($request, self::$validationRules);
        $requestData = $request->toArray();
        $returnData = [];
        $userData = [
            "login" => $requestData['login'],
            "hashed_password" => $requestData['hashed_password'],
            "firstname" => $requestData['firstname'],
            "lastname" => $requestData['lastname'],
            "admin" => 0,
            "status" => 1,
            "must_change_passwd" => $requestData['must_change_passwd'],
            "mail_notification" => $requestData['mail_notification'],
            "last_login_on" => date('Y-m-d'),
            "language" => null,
            "auth_source_id" => null,
            "created_on" => null,
            "updated_on" => null,
            "type" => 'User',
            "identity_url" => null,
            "salt" => null,
            "passwd_changed_on" => null,
            "accept_agreement_at" => null
        ];
        try {
            $user = User::updateOrCreate(['login' => $requestData['login']], $userData);
            $returnData[] = $user;
            if ($user->id) {
                $emailData = [
                    "user_id" => $user->id,
                    "address" => $requestData['email'],
                    "is_default" => 1,
                    "notify" => 1,
                ];
                $email = EmailAddresse::updateOrCreate(['user_id' => $user->id], $emailData);
                $returnData[] = $email;
            }
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusCreated'), $returnData);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function showActivity($projectId)
    {
        try {
            $userActivity = Helpers::logActivityLists($projectId);
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $userActivity);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }
    public function activityLogListing($projectId)
    {
        try {
            $userActivity = LogActivity::with(['projectActionType', 'createdBy'])
                ->where('link_id', $projectId)
                ->orderBy('id', 'desc')
                ->get(['id', 'link_id', 'action_id', 'user_id', 'response', 'created_at']);
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $userActivity);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function getUserAllGlobalRoles(Request $request)
    {
        $currentUserId = $request->user->id;
        try {
            $data = Helpers::getRole($currentUserId);
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $data);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function getAssignUsers(Request $request)
    {
        try {
            $userRole = LocalUser::with('userRoleLocal')->whereHas('userRoleLocal')
                ->where('status', config('constant.REDMINE_USERSTATUS.activeUser'))->select('user_id', 'full_name', 'status')
                ->get();
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $userRole);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }
    public function getAssignUsersPM(Request $request)
    {
        try {
            $userRole = LocalUser::with('userRolePM')->whereHas('userRolePM')
                ->where('status', config('constant.REDMINE_USERSTATUS.activeUser'))->select('user_id', 'full_name', 'status')
                ->get();
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $userRole);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }
}
