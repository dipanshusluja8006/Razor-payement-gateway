<?php

namespace App\Http\Controllers\Resource;

use App\Http\Controllers\Controller;
use App\Libraries\MailService;
use App\Models\Attachment;
use App\Models\AttachmentMapping;
use App\Models\ProjectRcaDetail;
use App\Models\RcaReporterUser;
use App\Models\RcaUser;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Webpatser\Uuid\Uuid;
use Carbon\Carbon;
use Helpers;
use ApiResponse;
use Log;


class ProjectRcaDetailController extends Controller
{

    protected $helpers;

    public function __construct(Helpers $helpers)
    {
        $this->helpers = $helpers;
        $this->rolesArray = Helpers::getRoleByModel('Role');
    }

    public static $validationRules = [
        'project_id' => 'required|exists:resource_mysql.projects,uuid',
        'issue_detail' => 'required',
        'date_of_issue_reported_first' => 'required|date',
        'date_of_action_reported_first' => 'required|date|after_or_equal:date_of_issue_reported_first',
        'issue_reported_by' => 'required|exists:resource_mysql.rca_reporter_users,id',
        'resolve_issue_type' => 'required',
        'time_taken_to_fix' => 'required',
        'issue_priority' => 'required|numeric|between:1,3',
        'prevent_for_future' => 'required',
        'fixed_by' => 'required|array',
        'fixed_by.*' => 'exists:redmine_db_mysql.users,id'

    ];

    public static $rcalistingvalidationRules = [
        'project_id' => 'required|exists:resource_mysql.projects,uuid',
    ];

    public static $rcaDetailsvalidationRules = [
        'rca_id' => 'required|exists:resource_mysql.project_rca_details,uuid',
    ];


    /**
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     * @throws \Illuminate\Validation\ValidationException
     */

    /**
     * @OA\Post(
     *     path="/v1/rca/{project_id}",
     *     summary="Route Cause Analysis",
     *     operationId="/v1/rca/{project_id}",
     *     tags={"RootCauseDetails"},
     *     @OA\Parameter(
     *         name="project_id",
     *         in="path",
     *         description="Project UUID",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\RequestBody(
     *         required=true,
     *         description="Post object",
     *         @OA\JsonContent(ref="#/components/schemas/RcaCreate")
     *     ),
     *     @OA\Response(
     *         response=201,
     *         description="A post",
     *         @OA\JsonContent(),
     *     ),
     *     @OA\Response(
     *         response="default",
     *         description="unexpected error",
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     * @throws \Illuminate\Validation\ValidationException
     *
     * Project Manager
     * PM’s create a root cause analysis
     */

    public function create(Request $request,$uuid)
    {
        $request->merge(['project_id' => $uuid]);
        $this->validate($request, self::$validationRules);
        $data = [
            'project_id' => $uuid,
            'issue_detail' => $request->issue_detail,
            'date_of_issue_reported_first' => $request->date_of_issue_reported_first,
            'date_of_action_reported_first' => $request->date_of_action_reported_first,
            'issue_reported_by' => $request->issue_reported_by,
            'resolve_issue_type' => $request->resolve_issue_type,
            'time_taken_to_fix' => $request->time_taken_to_fix,
            'issue_priority' => $request->issue_priority,
            'prevent_for_future' => $request->prevent_for_future,
            'created_by' => $request->user->id,
            'fixed_by' => $request->fixed_by
        ];
        try{
            //INSERT RCA FORM
            $projectRca = new ProjectRcaDetail($data);
            $projectRca->save();
            RcaUser::saveRcaUser($projectRca->uuid,$request->fixed_by);
            if(!empty($request->attachments)){
                AttachmentMapping::SaveAttachments($projectRca->uuid, $request->attachments);
            }
            $projectRca->load('projectDetails','reportedUser','createdBy','fixedByUsers','attachmentMappings');
            //for email
            $mailService = new MailService(config('constant.TEMPLATES.rca_creation'), $projectRca->project_id);
            $mailService->sendMail();
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusCreated'),$projectRca);
        }catch(\Exception $e ) {
            Log::error($this->helpers->addToLog($request->merge(['project_id' => $uuid]),$e->getMessage(),config('constant.LOG_ACTIONS.creation_rca')));
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'),'',$e->getMessage());
        }
    }

    /**
     *
     * @OA\Get(
     *     path="/v1/rca-listing/{project_id}",
     *     operationId="/v1/rca-listing/{project_id}",
     *     summary="Fetch rca listing using project uuid",
     *     tags={"RootCauseDetails"},
     *     @OA\Parameter(
     *         name="project_id",
     *         in="path",
     *         description="Project UUID",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\Response(
     *         response="200",
     *         description="Returns all RootCauseAnalysis Listing Project Wise",
     *         @OA\JsonContent()
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     *
     * @param $uuid
     * @return \Illuminate\Http\JsonResponse
     */

    public function show(Request $request, $projectId)
    {
        $request->merge(['project_id' => $projectId]);
        $this->validate($request, self::$rcalistingvalidationRules);
        try{
            $projectRcaLists = ProjectRcaDetail::where('project_id', $projectId)
                ->with(['projectDetails','createdBy','reportedUser','fixedByUsers','attachmentMappings'])
                ->orderBy('created_at', 'desc')
                ->get();
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'),$projectRcaLists);
        }catch(\Exception $e ) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'),'',$e->getMessage());
        }
    }

    /**
     *
     * @OA\Get(
     *     path="/v1/rca-details/{rca_id}",
     *     operationId="/v1/rca-details/{rca_id}",
     *     summary="Fetch specific rca detail using rca uuid",
     *     tags={"RootCauseDetails"},
     *     @OA\Parameter(
     *         name="rca_id",
     *         in="path",
     *         description="Rca UUID",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\Response(
     *         response="200",
     *         description="Returns Specific Project Detail",
     *         @OA\JsonContent()
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     *
     * @param $uuid
     * @return \Illuminate\Http\JsonResponse
     */

    public function viewRcaDetails(Request $request,$rcaUuid)
    {
        $request->merge(['rca_id' => $rcaUuid]);
        $this->validate($request, self::$rcaDetailsvalidationRules);
        try{
            $projectRcaDetails = ProjectRcaDetail::where('uuid', $rcaUuid)->with(['projectDetails','reportedUser','createdBy','fixedByUsers','attachmentMappings'])->first();
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'),$projectRcaDetails);
        }catch(\Exception $e ) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'),'',$e->getMessage());
        }
    }
    /**
     *
     * @OA\Get(
     *     path="/v1/rca-reporter-users",
     *     operationId="/v1/rca-reporter-users",
     *     summary="Fetch all reporters details users",
     *     tags={"RootCauseDetails"},
     *     @OA\Response(
     *         response="200",
     *         description="Returns all Reportes Users",
     *         @OA\JsonContent()
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function rcaReporterUsers()
    {
        try{
            $rcaReporterUsers = RcaReporterUser::get();
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'),$rcaReporterUsers);
        }catch(\Exception $e ) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'),'',$e->getMessage());
        }
    }

    public function rcaListForKedb(Request $request,$uuid)
    {
        $request->merge(['project_id' => $uuid]);
        $this->validate($request, self::$rcalistingvalidationRules);
        try{
            $roles = Helpers::getRole($request->user->id, $uuid);
            $projectRcaLists = [];
            if(  in_array($this->rolesArray[config('constant.ROLES.admin')], $roles['global']) ||
                in_array($this->rolesArray[config('constant.ROLES.global_operation')], $roles['global']) ||
                in_array($this->rolesArray[config('constant.ROLES.account_manager')], $roles['project']) ||
                in_array($this->rolesArray[config('constant.ROLES.project_manager')], $roles['project'])){
                $projectRcaLists = ProjectRcaDetail::where('project_id', $uuid)
                    ->orderBy('created_at', 'desc')
                    ->get();
            }
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'),$projectRcaLists);
        }catch(\Exception $e ) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'),'',$e->getMessage());
        }
    }

}
