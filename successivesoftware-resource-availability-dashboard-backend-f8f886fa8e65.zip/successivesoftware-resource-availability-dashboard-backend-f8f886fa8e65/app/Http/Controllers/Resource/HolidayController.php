<?php

namespace App\Http\Controllers\Resource;

use App\Http\Controllers\Controller;
use App\Models\Project;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
use Illuminate\Http\Request;
use ApiResponse;

class HolidayController extends Controller
{

    public static $validationRules = [
        'data.project_ids' => 'required|array',
    ];

    public function index(Request $request)
    {
        $this->validate($request, self::$validationRules);
        $projectIds = $request->data['project_ids'];

        try{
            $pmoResource = Project::with('currentBookings')
                ->whereIn('uuid' ,$projectIds)
                ->where('status', '!=', 17)
                ->get();
            $data = [];
            $header = [];
            $sNo = 0;

            $today = Carbon::today()->subDays(10);
            $addThreeMonths = Carbon::today()->addDays(79);

            $today = Carbon::parse($today)->format('Y-m-d');
            $addThreeMonths = Carbon::parse($addThreeMonths)->format('Y-m-d');

            $dates = ['from' => $today, 'to' => $addThreeMonths, 'pagesize' => 5000];
            $kekaData = \Helpers::callKekaHoliday($dates);
            $kekaData = json_decode($kekaData);

            $dateFrom = Carbon::createFromFormat('Y-m-d', $today);
            $dateTo = Carbon::createFromFormat('Y-m-d', $addThreeMonths);
            $dateRange = CarbonPeriod::create($dateFrom, $dateTo);

            //create date range array of 90 days
            foreach ($dateRange as $date) {
                $header[] = $date->format('Y-m-d');
            }

            foreach ($pmoResource as $key => $pmoproject){
                $projectName = $pmoproject->project_name;
                $resourceIdArray = [];
                foreach ($pmoproject['currentBookings'] as $resourceMapped){
                    if(isset($resourceMapped['resourceAllocation']['resourceAllocationMeta'][0])) {
                        foreach ($resourceMapped['resourceAllocation']['resourceAllocationMeta'] as $resourceAllocationMeta) {

                            if(!in_array($resourceAllocationMeta->resource_id, $resourceIdArray)){
                                if(isset($resourceAllocationMeta['resource']->status) &&
                                    $resourceAllocationMeta['resource']->status == config('constant.REDMINE_USERSTATUS.activeUser')
                                ) {
                                    $userDept = isset($resourceMapped['resourceAllocation']['ResourceRequisition']['department']->name) ? $resourceMapped['resourceAllocation']['ResourceRequisition']['department']->name : '';
                                    $resourceId = $resourceAllocationMeta->resource_id;
                                    $resourceEmployeeCode = isset($resourceAllocationMeta['resource']->employee_id) ? $resourceAllocationMeta['resource']->employee_id : "";
                                    $resourceName = isset($resourceAllocationMeta['resource']->display_name) ? $resourceAllocationMeta['resource']->display_name : "";
                                    $projectName = $pmoproject->project_name;
                                    $resourceIdArray[] = $resourceId;
                                    $sNo = $sNo + 1;
                                    //filter resource array
                                    $resourceLeavesData = $this->filterResourceArray($kekaData,$resourceEmployeeCode);

                                    // creating all leaves and present values for 90 days date wise
                                    $slotData = $this->getAllLeavesAndPresentDates($resourceLeavesData, $header);
                                    $slots = $slotData['slot'];
                                    $count = $slotData['count'];
                                    $staticData = [ 'S_No' => $sNo,
                                                    'EMP ID' => $resourceEmployeeCode,
                                                    'Resource Name' => $resourceName,
                                                    'Project Name' => $projectName,
                                                    'Business Unit' => $userDept];
                                    $slotData = $slots;
                                    $countData = ['Count' => $count];
                                    $data[] = array_merge($staticData,$slotData, $countData);
                                }
                            }
                        }
                    }
                }
            }
            $calendarData['header'] = $header;
            $calendarData['data'] = $data;
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'),$calendarData);
        }catch(\Exception $e ) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'),'',$e->getMessage());
        }
    }

    public function filterResourceArray($kekaData,$resourceEmployeeCode)
    {
        $resourceLeavesData = array_filter($kekaData, function ($var) use ($resourceEmployeeCode) {
            return (in_array($var->status, config('constant.KEKA_LEAVE_STATUS')) && $var->employeeNumber == $resourceEmployeeCode);
        });
        return $resourceLeavesData;
    }

    public function getAllLeavesAndPresentDates($resourceLeavesData, $header){
        //get all leave dates
        $count = 0;
        $leaveDates = [];
        if(isset($resourceLeavesData) && count($resourceLeavesData) > 0){
            foreach ($resourceLeavesData as $val){
                if(isset($val->selection)){
                    foreach ($val->selection as $selection){
                        $count = $count + $selection->count;
                    }
                }
                $period = CarbonPeriod::create($val->fromDate, $val->toDate);
                foreach ($period as $date) {
                    $leaveDates[] = $date->format('Y-m-d');
                }
            }
        }

        // creating all leaves and present values for 90 days date wise
        $slot = [];
        if(isset($header) && count($header) > 0) {
            foreach ($header as $val) {
                if (in_array($val, $leaveDates)) {
                    $slot[$val] = 'leave';
                } else {
                    $slot[$val] = '';
                }
            }
        }
        $data['slot'] = $slot;
        $data['count'] = $count;
        return $data;
    }

}
