<?php

namespace App\Http\Controllers\Resource;

use App\Http\Controllers\Controller;
use App\Models\Attachment;
use App\Models\AttachmentMapping;
use Illuminate\Http\Request;
use ApiResponse;
use Helpers;
use Illuminate\Support\Facades\File;
use Carbon\Carbon;
use Symfony\Component\HttpFoundation\BinaryFileResponse;

class AttachmentController extends Controller
{
    public static $attachmentValidationRoles = [
            'attachments' => 'array|max:3',
            'attachments.*' => 'mimes:jpg,jpeg,png,pdf,docx,doc,xlsx,xls,zip'
    ];

    public static $attachmentIdValidationRoles = [
        'attachment_id' =>  'required|exists:resource_mysql.attachments,id',
    ];


    public function create(Request $request)
    {
        $this->validate($request, self::$attachmentValidationRoles);
        try{
            $data = [];
            if($request->hasFile('attachments'))
            {
                $attachments = $request->file('attachments');
                foreach ($attachments as $attachment) {
                    $name = time().'-'.$attachment->getClientOriginalName();
                    $destinationPath = base_path() . '/public/files/';
                    $attachment->move($destinationPath, $name);
                    $data[] = Attachment::create([
                        'name' => $name,
                    ]);
                }
            }
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusCreated'),$data);
        }catch(\Exception $e ) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'),'',$e->getMessage());
        }
    }

    public function destroy(Request $request, $id)
    {
        $request->merge(['attachment_id' => $id]);
        $this->validate($request, self::$attachmentIdValidationRoles);
        try{
            $attachment = Attachment::findOrFail($id);
            $attachment_path = base_path().'/public/files/'.$attachment->name;
            if (File::exists($attachment_path)) {
                File::delete($attachment_path);
            }
            $attachment->delete();
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), '', 'Record Destroy');
        }catch(\Exception $e ) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'),'',$e->getMessage());
        }
    }

    public function getDownload(Request $request, $id)
    {
        $request->merge(['attachment_id' => $id]);
        $this->validate($request, self::$attachmentIdValidationRoles);
        $attachment = Attachment::where('id', $id)->first();
        $file= base_path().'/public/files/'.$attachment->name;
        return response()->download($file);

    }
}
