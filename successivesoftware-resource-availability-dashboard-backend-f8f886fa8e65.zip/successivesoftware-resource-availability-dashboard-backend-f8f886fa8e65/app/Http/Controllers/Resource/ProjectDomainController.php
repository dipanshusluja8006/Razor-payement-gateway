<?php

namespace App\Http\Controllers\Resource;

use App\Http\Controllers\Controller;
use App\Models\ProjectDomain;
use Illuminate\Http\Request;
use ApiResponse;
use Helpers;
use Log;

class ProjectDomainController extends Controller
{
    protected $helpers;
    public function __construct(Helpers $helpers)
    {
        $this->helpers = $helpers;
    }
    public function index()
    {
        $projectDomain = ProjectDomain::get();
        return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $projectDomain);
    }

    public static $projectDomainValidationRoles = [
        'name' => 'required',
    ];

    /**
     * @OA\Post(
     *     path="/v1/project-domain",
     *     summary="Project Domain",
     *     operationId="/v1/project-domain",
     *     tags={"Project Domain"},
     *     @OA\RequestBody(
     *         required=true,
     *         description="Post object",
     *         @OA\JsonContent(ref="#/components/schemas/ProjectDomain")
     *     ),
     *     @OA\Response(
     *         response=201,
     *         description="A post",
     *         @OA\JsonContent(),
     *     ),
     *     @OA\Response(
     *         response="default",
     *         description="unexpected error",
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     *
     * @param Request $request
     * @return array
     */

    public function store(Request $request)
    {
        $this->validate($request, self::$projectDomainValidationRoles);
        try{
        $data = $request->toArray();
        $domain = ProjectDomain::where('name', $data['name'])->first();
        if (!isset($domain)) {
            $domain_data = [
                'name' => $data['name'],
            ];
            $projectDomain = new ProjectDomain($domain_data);
            $projectDomain->save();
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusCreated'), $projectDomain);
        } else {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusForbidden'), '', 'Record Already Exists');
        }
    }catch(\Exception $e ) {
        Log::error($this->helpers->addToLog($request,$e->getMessage(),config('constant.LOG_ACTIONS.creation_domain')));
        return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'),'',$e->getMessage());
       }
    }
/**
     * @OA\Put(
     *     path="/v1/project-domain/{id}",
     *     summary="Project Domain Update",
     *     operationId="/v1/project-domain/{id}",
     *     tags={"Project Domain"},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="Project Domain id",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\RequestBody(
     *         required=true,
     *         description="Post object",
     *         @OA\JsonContent(ref="#/components/schemas/ProjectDomainUpdate")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="A post",
     *         @OA\JsonContent(),
     *     ),
     *     @OA\Response(
     *         response="default",
     *         description="unexpected error",
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     *
     * @param Request $request
     * @param $uuid
     * @return \Illuminate\Http\JsonResponse
     * @throws \Illuminate\Validation\ValidationException
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, self::$projectDomainValidationRoles);
        $data = $request->toArray();
        try{
        $domain = ProjectDomain::where('id', $id)->first();
        if (isset($domain)) {
            $response=ProjectDomain::where('id', $id)->update(['name' => $data['name']]);
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), '', 'Record Updated');
        } else {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', 'Id does not exist');
        }
    }catch(\Exception $e ) {
        Log::info($this->helpers->addToLog($request,$e->getMessage(),config('constant.LOG_ACTIONS.updation_domain')));
        return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'),'',$e->getMessage());
       }
    }

    public function destroy(Request $request, $id)
    {
        try{
        $domain = ProjectDomain::where('id', $id)->first();
        if (isset($domain)) {
            ProjectDomain::destroy($id);
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), '', 'Record Destroy');
        } else {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', 'Id does not exist');
        }
    }catch(\Exception $e ) {
        return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'),'',$e->getMessage());
       }
    }
}
