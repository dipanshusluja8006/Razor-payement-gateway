<?php

namespace App\Http\Controllers\Resource;

use App\Http\Controllers\Controller;
use App\Models\AttachmentMapping;
use App\Models\ProjectKedbDetail;
use Illuminate\Http\Request;
use ApiResponse;
use Log;
use Helpers;
use Carbon\Carbon;

class ProjectKedbDetailController extends Controller
{
    protected $helpers;
    public function __construct(Helpers $helpers)
    {
        $this->helpers = $helpers;
    }

    public static $validationRules = [
        'project_id' => 'nullable|exists:resource_mysql.projects,uuid',
        'project_rca_id' => 'nullable|exists:resource_mysql.project_rca_details,uuid',
        'description_of_known_error' => 'required',
        'description_of_workaround' => 'required',
        'tags' => 'required|array',
        'tags.*' => 'exists:resource_mysql.tags,id',
        'attachments' => 'array',
        'attachments.*' => 'exists:resource_mysql.attachments,id',
    ];

    public static $kedbIdValidationRoles = [
        'kedb_id' =>  'required|exists:resource_mysql.project_kedb_details,uuid',
    ];

    public function index()
    {
        try{
            $kedbLists = ProjectKedbDetail::with(['createdBy', 'project', 'rca', 'tags', 'attachmentMappings'])
                ->orderBy('created_at', 'desc')->get();
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'),$kedbLists);
        }catch(\Exception $e ) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'),'',$e->getMessage());
        }
    }


    /**
     * @OA\Post(
     *     path="/v1/kedb",
     *     summary="Create KEDB",
     *     operationId="/v1/kedb",
     *     tags={"Kedb"},
     *     @OA\RequestBody(
     *         required=true,
     *         description="Post object",
     *         @OA\JsonContent(ref="#/components/schemas/Kedb")
     *     ),
     *     @OA\Response(
     *         response=201,
     *         description="A post",
     *         @OA\JsonContent(),
     *     ),
     *     @OA\Response(
     *         response="default",
     *         description="unexpected error",
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     *
     * @param Request $request
     * @return array
     */

    public function create(Request $request)
    {
        $this->validate($request, self::$validationRules);
        $data = [
            'project_id' => $request->project_id,
            'project_rca_id' => $request->project_rca_id,
            'created_by' => $request->user->id,
            'description_of_known_error' => $request->description_of_known_error,
            'description_of_workaround' => $request->description_of_workaround,
        ];
        try{
            //INSERT KEDB RECORD
            $kedb = new ProjectKedbDetail($data);
            $kedb->save();
            $kedb->tags()->sync($request->get('tags'));
            $kedb->tags()->sync($request->get('tags'));
            if(!empty($request->attachments)){
                AttachmentMapping::SaveAttachments($kedb->uuid, $request->attachments);
            }
            $kedb->load('createdBy', 'rca', 'project', 'tags', 'attachmentMappings');
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusCreated'),$kedb);
        }catch(\Exception $e ) {
            Log::error($this->helpers->addToLog($request,$e->getMessage(),config('constant.LOG_ACTIONS.creation_kedb')));
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'),'',$e->getMessage());
        }
    }

    /**
     *
     * @OA\Get(
     *     path="/v1/kedb/{kedb_id}",
     *     operationId="/v1/kedb/{kedb_id}",
     *     summary="Fetch specific project detail using project uuid",
     *     tags={"Kedb"},
     *     @OA\Parameter(
     *         name="kedb_id",
     *         in="path",
     *         description="kedb UUID",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\Response(
     *         response="200",
     *         description="Returns Specific Kedb Detail",
     *         @OA\JsonContent()
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     *
     * @param $uuid
     * @return \Illuminate\Http\JsonResponse
     */

    public function show(Request $request, $kedb_id)
    {
        $request->merge(['kedb_id' => $kedb_id]);
        $this->validate($request, self::$kedbIdValidationRoles);
        try{
            $projectKedbDetails = ProjectKedbDetail::where('uuid', $kedb_id)->with(['createdBy', 'project', 'rca', 'tags', 'attachmentMappings'])->first();
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'),$projectKedbDetails);
        }catch(\Exception $e ) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'),'',$e->getMessage());
        }
    }

}
