<?php

namespace App\Http\Controllers\Resource;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Console\Command;
use App\Mail\InvoiceReminderAMPMMail;
use Helpers;
use Log;
use Carbon\Carbon;
use Illuminate\Support\Facades\Mail;
use App\Project as RedmineProjectModel;
use App\Invoice;
use App\Models\Department;
use App\Models\Project;
use ApiResponse;
use App\Jobs\QueueJob;


class InvoiceController extends Controller
{
    public static $projectSummaryValidation = [
        'redmine_project_ids' => 'array'
    ];
    protected $helpers;
    /**
     * ProjectController constructor.
     */
    public function __construct(Helpers $helpers)
    {
        $this->helpers = $helpers;
        $this->rolesArray = Helpers::getRoleByModel('Role');
        $this->departmentArray = Helpers::getRoleByModel('Department');
    }
    public function index(Request $request)
    {
        try{
            $currentUserId = $request->user->id;
            $checkMapped = false;
            $pendingInitiaion = true;
            $userRole = Helpers::getRole($currentUserId);
            if(in_array($this->rolesArray[config('constant.ROLES.admin')], $userRole['global'])){
                $userRole['department'] = Department::pluck('id')->toArray();
            }
                $pmoProjects = Project::with(['resourceRequisitionAllProject' => function ($query) use ($userRole) {
                $query->whereIn('dept_id', $userRole['department']);
                }, 'ProjectRole' => function ($query) use ($currentUserId) {
                    $query->where('user_id', $currentUserId);
                }
            ])
                ->orderBy('created_at', 'desc')
                ->get();
             $pmoProjects = $this->removeUnAuthorizedProject($pmoProjects, $currentUserId, $userRole, $checkMapped, $pendingInitiaion);
             $redmineId =[];
            foreach($pmoProjects as $key=>$projectValue){
                $redmineId[]=$projectValue->redmine_project_id;
            }
            $projectIds = array_filter($redmineId, function($value) { return !is_null($value) && $value !== ''; });
            $data = [];
            $today = Carbon::now();
            $invoiceProject = [];
            $currentMonth = $today->month; // retrieve the month
            $currentYear = $today->year; // retrieve the year of the date
            $invoice = Invoice::whereMonth('invoice_date', $currentMonth)->whereYear('invoice_date', $currentYear)->get();
            foreach($invoice as $val){
                $invoiceProject[] = $val['project_id'];
            }
            $redmineProjects = RedmineProjectModel::whereIn('id', $projectIds)->whereHas('billingProjects',function($q){
                $q->where('status', config('constant.REDMINE_PROJECTSTATUS.activeProject'));
            })->with('projectInvoices','billingProjects','ProjectMembers')->get(['id','name','status']);
            $datanew = [];
            foreach ($redmineProjects as $redmineProject) {
                $invoceGeneratedStatus=[];
                $invocePendingStatus=[];
                $InvoiceStatus = [];
                foreach ($redmineProject['ProjectMembers'] as $userProjects) {
                    foreach ($userProjects['MemberRole'] as $memberRole){
                        if(isset($redmineProject['projectInvoices']->invoice_date)){
                                 $invoiceMonth = Carbon::parse($redmineProject['projectInvoices']->invoice_date)->format('m');
                                 $InvoiceDate = Carbon::parse($redmineProject['projectInvoices']->invoice_date)->format('Y-m-d');
                                 $date = Carbon::createFromFormat('Y-m-d', $InvoiceDate)->addMonth();
                                 $nextInvoiceDate = $date->format('Y-m-d');
                        }
                        if(isset($redmineProject['projectInvoices']->status_id)){
                           if($redmineProject['projectInvoices']->status_id==0){
                            $InvoiceStatus = 'Estimate';
                            $InvoiceDate = $InvoiceDate;
                            $nextInvoiceDate = $nextInvoiceDate;
                            }elseif($redmineProject['projectInvoices']->status_id==1 && ($invoiceMonth == $currentMonth)){
                            $InvoiceStatus = 'Draft';
                            $InvoiceDate = $InvoiceDate;
                            $nextInvoiceDate = $nextInvoiceDate;
                            }elseif($redmineProject['projectInvoices']->status_id==2){
                            $InvoiceStatus = 'Sent';
                            $InvoiceDate = $InvoiceDate;
                            $nextInvoiceDate = $nextInvoiceDate;
                            }elseif($redmineProject['projectInvoices']->status_id==3){
                                $InvoiceStatus = 'Paid';
                                $InvoiceDate = $InvoiceDate;
                                $nextInvoiceDate = $nextInvoiceDate;
                            }elseif($redmineProject['projectInvoices']->status_id==4){
                                $InvoiceStatus = 'Cancelled';
                                $InvoiceDate = $InvoiceDate;
                                $nextInvoiceDate = $nextInvoiceDate;
                            }else{
                            $InvoiceStatus = 'Pending';
                            $InvoiceDate = $InvoiceDate;
                            $nextInvoiceDate = $nextInvoiceDate;
                        }
                     }
                    }
                }
                if(is_array($InvoiceStatus)){
                    $InvoiceStatus = 'Pending';
                    $InvoiceDate = 'N/A';
                    $nextInvoiceDate = Carbon::now()->format('Y-m-d');
                }
                $data = [
                    'ProjectID' => $redmineProject['billingProjects']->customized_id,
                    'ProjectName' => Helpers::getProjectNameRedmine($redmineProject['billingProjects']->customized_id),
                    'BillingType' => Helpers::getCustomBillingType($redmineProject['billingProjects']->value),
                    'LastInvoiceDate' =>$InvoiceDate,
                    'InvoiceStatus' =>$InvoiceStatus,
                    'NextInvoiceDate' => $nextInvoiceDate
                ];
            $datanew[]=$data;
        }
        $resultArray = [];
        $pendingIds = [];
        $generatedIds = [];
        $estimatesIds = [];
        $sentIds = [];
        $paidIds = [];
        $canceledIds = [];
        $resultArray['Pending']['statusCount'] = 0;
        $resultArray['Draft']['statusCount'] = 0;
        $resultArray['Estimate']['statusCount'] = 0;
        $resultArray['Sent']['statusCount'] = 0;
        $resultArray['Paid']['statusCount'] = 0;
        $resultArray['Cancelled']['statusCount'] = 0;
        if(!empty($datanew)){
            foreach ($datanew as $result) {
            $InvoiceStatus = $result['InvoiceStatus'];
            $array = [  'ProjectID' => $result['ProjectID'],
                        'ProjectName' => $result['ProjectName'],
                        'BillingType' => $result['BillingType'],
                        'LastInvoiceDate' => $result['LastInvoiceDate'],
                        'NextInvoiceDate' => $result['NextInvoiceDate'],
                        'InvoiceStatus' => $result['InvoiceStatus']
                     ];
            $resultArray[$InvoiceStatus]['resource'][] = $array;
            if($InvoiceStatus=='Pending'){
                $pendingIds[] = $result['InvoiceStatus'];
                $resultArray[$InvoiceStatus]['statusCount'] = count($pendingIds);
            }
            if($InvoiceStatus=='Draft'){
                $generatedIds[] = $result['InvoiceStatus'];
                $resultArray[$InvoiceStatus]['statusCount'] = count($generatedIds);
            }
            if($InvoiceStatus=='Estimate'){
                $estimatesIds[] = $result['InvoiceStatus'];
                $resultArray[$InvoiceStatus]['statusCount'] = count($estimatesIds);
            }
            if($InvoiceStatus=='Sent'){
                $sentIds[] = $result['InvoiceStatus'];
                $resultArray[$InvoiceStatus]['statusCount'] = count($sentIds);
            }
            if($InvoiceStatus=='Paid'){
                $paidIds[] = $result['InvoiceStatus'];
                $resultArray[$InvoiceStatus]['statusCount'] = count($paidIds);
            }
            if($InvoiceStatus=='Cancelled'){
                $canceledIds[] = $result['InvoiceStatus'];
                $resultArray[$InvoiceStatus]['statusCount'] = count($canceledIds);
            }
        }
        return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'),$resultArray);
        
       }else{
        return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), '', 'No Data Found');
       }
    }catch(\Exception $e ) {
        return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'),'',$e->getMessage());
       }
    }

    public function invoiceSendReminder(Request $request)
    {
        try{
            $this->validate($request, self::$projectSummaryValidation);
            $projectIds = $request->redmine_project_ids;
            $projectIds = array_filter($projectIds, function($value) { return !is_null($value) && $value !== ''; });
            $redmineProjects = RedmineProjectModel::whereIn('id', $projectIds)->with('ProjectMembers')->get();
            foreach ($redmineProjects as $redmineProject) {
                $emailArray=[];
               foreach ($redmineProject['ProjectMembers'] as $userProjects) {
                  foreach ($userProjects['MemberRole'] as $memberRole){
                    if($memberRole->role_id == 3 || $memberRole->role_id == 15){
                        if(!in_array($userProjects['User']->email,$emailArray)){
                            $emailArray[]=$userProjects['User']->email;
                            $redmineProjectAMPMIds[\Helpers::getProjectNameRedmine($redmineProject['billingProjects']->customized_id)][] = $userProjects['User']->email;
                        }
                   }
                }
            }
        }
        $mailData = \Helpers::getTemplateByCode(config('constant.TEMPLATES.invoice_reminder_email'));
        foreach ($redmineProjectAMPMIds as $key1 => $billing){
            $finalMailData =[];
            $mail=[];
            $blackListEmails = config('constant.BLACKLIST_EMAILS');
            $mail = $billing;
            $key = config('constant.QUEUEJOB.InvoiceReminderEmail');
            $mailCC =  \Helpers::getGlobalUserId('', config('constant.ROLES.global_operation'));
            $mergedArray = array_diff($mail, $blackListEmails);
            $mergedArrayCC= array_diff($mailCC, $blackListEmails);
            $finalMailData['subject'] = $mailData->subject;
            $finalMailData['code'] = $mailData->code;
            $finalMailData['template'] = $mailData->template;
            $finalMailData['mailTo'] = $mergedArray;
            $finalMailData['mailcc'] = $mergedArrayCC;
            $finalMailData['key'] = 'InvoiceReminderEmail';
            $finalMailData['data'] = [$key1];
            $finalMailData = (object) $finalMailData;
            if(!empty($mergedArray)){
                dispatch(new QueueJob($mergedArray,$finalMailData,$key,$mergedArrayCC))->onQueue('default');
            }
        }
        $msg = 'Success';
        return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'),$msg);
    }catch(\Exception $e ) {
        return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'),'',$e->getMessage());
       }
    }

    private function removeUnAuthorizedProject($projects, $currentUserId, $userRole, $checkMapped, $pendingInitiaion = false)
    {
        $filterProjects = [];
        if (!empty($projects)) {
                foreach ($projects as $key => $value) {
                    $flag = false;
                  if($value->is_draft == 0){
                      if (
                          in_array($this->rolesArray[config('constant.ROLES.admin')], $userRole['global']) ||
                          in_array($this->rolesArray[config('constant.ROLES.global_operation')], $userRole['global'])
                      ) {
                          $flag = true;
                      }else{
                          if ((   in_array($this->rolesArray[config('constant.ROLES.sales')], $userRole['global']) ||
                                  in_array($this->rolesArray[config('constant.ROLES.resource_manager')], $userRole['global']))
                              && $value->status != config('constant.PROJECT_ACTION.initiation_request')){
                              $flag = true;
                          }

                          else if(count($value['ProjectRole']) > 0 && $value->status != config('constant.PROJECT_ACTION.initiation_request')){
                              $flag = true;
                          }
                          else if($value->created_by == $currentUserId && $value->status == config('constant.PROJECT_ACTION.initiation_request')){
                              $flag = true;
                          }
                          else if(count($value['resourceRequisitionAllProject']) > 0){
                              foreach ($value['resourceRequisitionAllProject'] as $requisition){
                                  if($requisition->status == 0){
                                      $flag = true;
                                      break;
                                  }else{
                                      if(count($requisition['Allocation']) > 0){
                                          foreach ($requisition['Allocation'] as $allocation){
                                              if($allocation->allocation_status == 14){
                                                  $flag = true;
                                                  break;
                                              }
                                          }
                                          if($flag){
                                              break;
                                          }
                                      }
                                  }
                              }
                          }
                          else{
                              if($checkMapped){
                                  if(isset($value['resourceMapped'])){
                                      foreach ($value['resourceMapped'] as $mappedResource){
                                          if(isset($mappedResource['resourceAllocation']['resourceAllocationMeta']) && $mappedResource['resourceAllocation']->allocation_status ==14){
                                              $flag = true;
                                              break;
                                          }
                                      }
                                  }
                              }
                          }
                      }
                  }else{
                      if($value->created_by == $currentUserId){
                          $flag = true;
                      }
                  }

                if($flag){
                    array_push($filterProjects, $value);
                }
            }
        }
        return $filterProjects;
    }
}
