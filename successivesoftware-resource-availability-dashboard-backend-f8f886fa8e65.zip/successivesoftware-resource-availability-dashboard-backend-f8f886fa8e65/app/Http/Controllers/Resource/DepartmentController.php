<?php

namespace App\Http\Controllers\Resource;

use App\Http\Controllers\Controller;
use App\Models\Department;
use ApiResponse;

class DepartmentController extends Controller
{
    public function index()
    {
        try {
            $departments = Department::whereNotIn('code', ['Client'])->orderBy('name', 'ASC')->get();
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $departments);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }
}
