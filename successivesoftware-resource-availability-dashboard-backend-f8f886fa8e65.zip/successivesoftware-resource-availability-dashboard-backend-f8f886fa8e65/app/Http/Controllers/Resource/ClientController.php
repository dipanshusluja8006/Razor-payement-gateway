<?php

namespace App\Http\Controllers\Resource;

use App\Http\Controllers\Controller;
use App\Models\Client;
use Illuminate\Http\Request;
use ApiResponse;

/**
 *
 * @OA\Get(
 *     path="/v1/designation",
 *     operationId="/v1/designation/index",
 *     summary="Fetch all Designation",
 *     tags={"Designation"},
 *     @OA\Response(
 *         response="200",
 *         description="Returns all Designation",
 *         @OA\JsonContent()
 *     ),
 *     security={
 *      {"api_key_security": {}}
 *     }
 * )
 *
 */
class ClientController extends Controller
{
    public static $clientValidation = [
        'name' => 'required',
        'email' => 'required',
    ];

    public function index()
    {
        $client = Client::get();
        return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $client);
    }


    public function store(Request $request)
    {
        $this->validate($request, self::$clientValidation);
        try {
            $data = $request->toArray();

//            return $data['name'];
            $client = Client::where('name', $data['name'])
                ->where('emails', $data['email'])->first();
            if (!isset($client)) {
                $client_data = [
                    'name' => $data['name'],
                    'emails' => $data['email'],
                ];
                $newClient = new Client($client_data);
                $newClient->save();
                return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusCreated'), $newClient);
            } else {
                return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusForbidden'), '', 'Record Already Exists');
            }
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }


    public function update(Request $request, $id)
    {
        $this->validate($request, self::$clientValidation);
        $data = $request->toArray();
        try {
            $client = Client::where('id', $id)->first();
            if (isset($client)) {
                Client::where('id', $id)->update([
                    'name' => $data['name'],
                    'email' => $data['email'],
                ]);
                $client = Client::where('id', $id)->first();
                return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $client, 'Record Updated');
            } else {
                return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', 'Id does not exist');
            }
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }


    public function destroy(Request $request, $id)
    {
        try {
            $client = Client::where('id', $id)->first();
            if (isset($client)) {
                Client::destroy($id);
                return Client::genericResponse(config('constant.STATUS_CODE.statusOk'), '', 'Record Destroy');
            } else {
                return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', 'Id does not exist');
            }
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }
}
