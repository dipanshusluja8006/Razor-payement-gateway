<?php

namespace App\Http\Controllers\Resource;

use App\Libraries\MailService;
use App\Mail\ResourceMailable;
use App\Models\Project;
use App\Models\User;
use App\EmailAddresse;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\ResourceMapping;
use App\Models\PerformedActionLog;
use App\Models\ResourceAllocation;
use App\Models\ProjectAction;
use Helpers;
use ApiResponse;
use Carbon\Carbon;
use Log;
use App\ResourceBooking;
use App\Member;
use App\MemberRole;

class ResourceMappingController extends Controller
{

    protected $helpers;

    public function __construct(Helpers $helpers)
    {
        $this->helpers = $helpers;
    }

    public static $validationRules = [
        'map_data' => 'required|array',
        'map_data.*.resource_mapping_id' => 'required|exists:resource_mysql.resource_mappings,uuid',
        'map_data.*.status' => 'required',
        'project_status' => 'required',
        'project_id' => 'required|exists:resource_mysql.projects,uuid',
    ];
    /**
     *
     * @OA\Get(
     *     path="/v1/allocation-map/{uuid}",
     *     operationId="/v1/allocation-map/{uuid}",
     *     summary="Fetch Resource Allocation Map",
     *     tags={"Resource-Mapping"},
     *     @OA\Parameter(
     *         name="projectId",
     *         in="path",
     *         description="Project UUID",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\Response(
     *         response="200",
     *         description="Returns allocation-map Detail",
     *         @OA\JsonContent()
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     *
     * @param type $projectId
     * @return \Illuminate\Http\JsonResponse
     */
    public function showAllocated(Request $request, $uuid)
    {
        try {
            $project = Project::where('uuid', $uuid)
                ->with(['resourceMapping', 'initiatedBy', 'projectManagers', 'accountManagers'])
                ->first();
            $project_name = $project['project_name'];
            $redmineProjectID = $project['redmine_project_id'];
            if ($redmineProjectID == null || $redmineProjectID == '') {
                $redmineProjectID = Helpers::projectIDRedmine($project_name);
            }
            $project_exist_redmine = false;
            if (isset($redmineProjectID)) {
                $project_exist_redmine = true;
            }
            $project->project_exist_redmine = $project_exist_redmine;
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $project);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    /**
     * @OA\Put(
     *     path="/v1/map-resource",
     *     summary="Map Resource",
     *     operationId="/map-resource",
     *     tags={"Resource-Mapping"},
     *     @OA\RequestBody(
     *         required=true,
     *         description="Post object",
     *         @OA\JsonContent(ref="#/components/schemas/ResourceMapResource")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="A post",
     *         @OA\JsonContent(),
     *     ),
     *     @OA\Response(
     *         response="default",
     *         description="unexpected error",
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     */

    public function mapResource(Request $request, $status = false)
    {
        $this->validate($request, self::$validationRules);
        $resourcesData = $request->toArray();
        try {
            $return_data = [];
            $departmentArray = [];
            $mapIdArray = [];
            $arrayMailAllData = [];
            $membershipData = [];
            $currentUserId = $request->user->id;
            $projectTimelineTo = Project::where('uuid', $resourcesData['project_id'])->pluck('estimated_timeline_to')->first();
            $updateTimelineTo = $projectTimelineTo;
            $project = Project::where('uuid', $resourcesData['project_id'])->first();
            $project_name = $project['project_name'];
            $redmineProjectID = $project['redmine_project_id'];
            if ($redmineProjectID == null || $redmineProjectID == '') {
                $redmineProjectID = Helpers::projectIDRedmine($project_name);
            }
            $newOfSet = 0;
            $limit = 100;
            $totalCount = 0;
            while ($newOfSet <= $totalCount) {
                $projectmembershipJson = Helpers::callAPIGET('/projects/' . $redmineProjectID . '/memberships.json?offset=' . $newOfSet . '&limit=' . $limit);
                $membershipDataInner = json_decode($projectmembershipJson, true);
                $totalCount = $membershipDataInner['total_count'];
                if (isset($membershipDataInner['memberships'])) {
                    $membershipData = array_merge($membershipDataInner['memberships'], $membershipData);
                }
                $newOfSet = $newOfSet + $limit;
            }
            $newMembershipData['memberships'] = $membershipData;
            Log::info(['Project_Membership_Get_API', json_encode($newMembershipData)]);
            foreach ($resourcesData['map_data'] as $key => $map_datum) {
                ResourceMapping::where('uuid', $map_datum['resource_mapping_id'])->update(array('status' => $map_datum['status']));
                $mapped = ResourceMapping::where('uuid', $map_datum['resource_mapping_id'])->first();
                if (Carbon::parse($updateTimelineTo)->lessThan(Carbon::parse($mapped['end_date']))) {
                    $updateTimelineTo = $mapped['end_date'];
                }
                $return_data[] = $mapped;
                //for mail
                $department = $this->getDepatmentIdFromAllocatedResourcesUuid($mapped['allocated_resource_id']);
                if (!in_array($department, $departmentArray)) {
                    array_push($departmentArray, $department);
                }
                $mapIdArray[] = $map_datum['resource_mapping_id'];
                $mappedRecord = ResourceMapping::with('resourceAllocation')->where('uuid', $map_datum['resource_mapping_id'])->first();
                $finalData = Helpers::checkMembers($redmineProjectID, $mappedRecord['resource_id'], $map_datum, $newMembershipData);
                $requisitionRecord = ResourceBooking::saveResourceBooking($currentUserId, $mappedRecord, $redmineProjectID);
            }
            if (Carbon::parse($updateTimelineTo)->notEqualTo(Carbon::parse($projectTimelineTo))) {
                Helpers::updateProjectEstimatedToDate($resourcesData['project_id'], $updateTimelineTo);
            }
            $change_status = Project::where('uuid', $resourcesData['project_id'])->update(array('status' => $resourcesData['project_status']));
            $this->updatePerformedActionLogOfProject($resourcesData['project_id']);

            $mappedAllData = ResourceMapping::with('resourceAllocation')
                ->whereIn('uuid', $mapIdArray)->get();
            foreach ($mappedAllData as $mappedData) {
                if (isset($mappedData['resourceAllocation']['resourceRequisition'])) {
                    $arrayMail = [
                        'resource_id' => $mappedData->resource_id,
                        'resource_name' => \Helpers::getUserName($mappedData->resource_id),
                        'employee_code' => \Helpers::getEmployeeCode($mappedData->resource_id),
                        'employee_email' => \Helpers::getUserEmail($mappedData->resource_id),
                        'department' => \Helpers::getDepartmentNameByID($mappedData['resourceAllocation']['resourceRequisition']->dept_id),
                        'billing_type' => \Helpers::getBillableType($mappedData['resourceAllocation']['resourceRequisition']->billing_type),
                        'experience' => trim($mappedData['resourceAllocation']['resourceRequisition']->experience),
                        'efforts' => trim($mappedData->hours),
                        'start_date' => $mappedData->start_date,
                        'end_date' => $mappedData->end_date,
                    ];
                    $arrayMailAllData[] = $arrayMail;
                }
            }

            if ($status == true) {
                Log::info($this->helpers->addToLog($resourcesData['project_id'], $request, $return_data, config('constant.LOG_ACTIONS.resource_mapping')));
                $this->helpers->addlogActivityDB($resourcesData['project_id'], $request, $resourcesData['map_data'], config('constant.LOG_ACTIONS.resource_mapping'));
                return true;
            } else {
                //for mail
                $mailArray = [config('constant.TEMPLATES.mapping')];
                foreach ($mailArray as $val) {
                    $mailService = new MailService($val, $resourcesData['project_id'], $arrayMailAllData, $departmentArray);
                    $mailService->sendMail();
                }
                Log::info($this->helpers->addToLog($resourcesData['project_id'], $request, $return_data, config('constant.LOG_ACTIONS.resource_mapping')));
                $this->helpers->addlogActivityDB($resourcesData['project_id'], $request, $resourcesData['map_data'], config('constant.LOG_ACTIONS.resource_mapping'));
                return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusCreated'), $return_data);
            }
        } catch (\Exception $e) {
            Log::error($this->helpers->addToLog($resourcesData['project_id'], $request, $e->getMessage(), config('constant.LOG_ACTIONS.resource_mapping')));
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function updatePerformedActionLogOfProject($projectId)
    {
        PerformedActionLog::where('project_id', $projectId)->update(['status' => '1']);
        PerformedActionLog::storePerformedActionLog($projectId, 4, config('constant.PERFORM_ACTIONLOG.completed'));
    }

    public function getUserEmailFromAllocatedResourcesUuid($allocatedResourcesUuid)
    {
        $resourceEmail = [];
        $resourceAllocationdata = ResourceAllocation::where('uuid', $allocatedResourcesUuid)
            ->first();
        if ($resourceAllocationdata->user_id) {

            $userEmail = EmailAddresse::where('user_id', $resourceAllocationdata->user_id)->select('address as email')->first();
            $resourceEmail[] = $userEmail->email;
        }
        return $resourceEmail;
    }

    public function getDepatmentIdFromAllocatedResourcesUuid($allocatedResourcesUuid)
    {
        $resourceAllocationdata = ResourceAllocation::where('uuid', $allocatedResourcesUuid)
            ->with('resourceRequisition')
            ->firstOrFail();
        return $resourceAllocationdata->resourceRequisition->dept_id;
    }
}
