<?php

namespace App\Http\Controllers\Resource;

use App\Http\Controllers\Controller;
use App\Libraries\MailService;
use App\Mail\ProjectInitiation;
use App\Mail\ResourceMailable;
use App\Models\Department;
use App\Models\ProjectAction;
use App\Models\ResourceRequisition;
use App\Models\PerformedActionLog;
use App\Models\Project;
use App\Models\User;
use Illuminate\Http\Request;
use Helpers;
use Illuminate\Support\Facades\Mail;
use ApiResponse;
use App\Traits\ResourceControllerTraits;
use Carbon\Carbon;
use Log;
use Webpatser\Uuid\Uuid;
use App\Models\ResourceMapping;
use App\Models\LocalUser;
use App\Http\Controllers\Resource\ResourceMappingController;

class ResourceRequisitionController extends Controller
{
    use ResourceControllerTraits;
    protected $helpers;

    public function __construct(Helpers $helpers)
    {
        $this->helpers = $helpers;
        $this->rolesArray = Helpers::getRoleByModel('Role');
    }

    public static $validationRules = [
        'project_id' => 'required|exists:resource_mysql.projects,uuid',
        'resource_data' => 'array',
        'resource_data.*.dept_id' => 'required|exists:resource_mysql.departments,id',
        'resource_data.*.tech_id' => 'required|exists:resource_mysql.technologies,id',
        'resource_data.*.role_id' => 'required|exists:resource_mysql.designations,id',
        'resource_data.*.efforts' => 'required',
        'resource_data.*.experience' => 'required',
        'resource_data.*.no_of_resource' => 'required',
        'resource_data.*.start_date' => 'required',
        'resource_data.*.end_date' => 'required',
        'project_status' => 'required',
        'resource_data.*.billing_type' => 'required'
    ];

    public static $updateRequisitionRoleRules = [
        'role_id' => 'required|exists:resource_mysql.designations,id',
        'resource_requisition_uuid' => 'required|exists:resource_mysql.resource_requisitions,uuid',
    ];

    public static $editRequisitionRules = [
        'resource_data' => 'array',
        'resource_data.*.resource_requisition_uuid' => 'required|exists:resource_mysql.resource_requisitions,uuid',
        'resource_data.*.isDelete' => 'required',
        'resource_data.*.dept_id' => 'required|exists:resource_mysql.departments,id',
        'resource_data.*.tech_id' => 'required|exists:resource_mysql.technologies,id',
        'resource_data.*.role_id' => 'required|exists:resource_mysql.designations,id',
        'resource_data.*.no_of_resource' => 'required',
        'resource_data.*.efforts' => 'required',
        'resource_data.*.experience' => 'required',
        'resource_data.*.start_date' => 'required',
        'resource_data.*.end_date' => 'required',
        'project_id' => 'required|exists:resource_mysql.projects,uuid'
    ];

    public static $resourceExtensionRules = [
        'project_id' => 'required|exists:resource_mysql.projects,uuid',
        'resource_data' => 'array',
        'resource_data.*.dept_id' => 'required|exists:resource_mysql.departments,id',
        'resource_data.*.tech_id' => 'required|exists:resource_mysql.technologies,id',
        'resource_data.*.role_id' => 'required|exists:resource_mysql.designations,id',
        'resource_data.*.efforts' => 'required',
        'resource_data.*.experience' => 'required',
        'resource_data.*.start_date' => 'required',
        'resource_data.*.end_date' => 'required|date|after_or_equal:resource_data.*.start_date',
        'resource_data.*.extension_resource_id' => 'required|exists:redmine_db_mysql.users,id',
    ];

    /**
     * @OA\Post(
     *     path="/v1/resource-requisition",
     *     summary="Resource Requisition",
     *     operationId="/resource-requisition",
     *     tags={"Resource-requisition"},
     *     @OA\RequestBody(
     *         required=true,
     *         description="Post object",
     *         @OA\JsonContent(ref="#/components/schemas/ResourceRequisition")
     *     ),
     *     @OA\Response(
     *         response=201,
     *         description="A post",
     *         @OA\JsonContent(),
     *     ),
     *     @OA\Response(
     *         response="default",
     *         description="unexpected error",
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     */

    public function create(Request $request)
    {
        $this->validate($request, self::$validationRules);
        $resourcesData = $request->resource_data;
        $projectId = $request->project_id;
        $departmentArray = [];
        $requisitionMailArray = [];
        $requisitionDataArray = [];
        $status = config('constant.PERFORM_ACTIONLOG.inProgress');
        $type = config('constant.REQUISITION_TYPE.requisition');
        $max = ResourceRequisition::withTrashed()->find(\DB::table('resource_requisitions')->max('id'));
        $id = (isset($max->id) ? $max->id : 0);

        try {
            foreach ($resourcesData as $data) {
                $requisitionDataArray[] = $this->requisitionArray($request, $data, $projectId, $type, $status, ++$id);
                $change_status = Project::where('uuid', $projectId)->update(array('status' => $request->project_status));
                $this->requisitionPerformedActionLog($projectId);
                if (!in_array($data['dept_id'], $departmentArray)) {
                    array_push($departmentArray, $data['dept_id']);
                }
                $requisitionArray = [
                    'dept_id' => $data['dept_id'],
                    'department' => \Helpers::getDepartmentNameByID($data['dept_id']),
                    'efforts' => trim($data['efforts']),
                    'start_date' => $data['start_date'],
                    'end_date' => $data['end_date'],
                    'experience' => trim($data['experience']),
                    'no_of_resource' => trim($data['no_of_resource']),
                    'billing_type' => \Helpers::getBillableType($data['billing_type']),
                    'suggested_resource' => $data['suggested_resource'],
                    'tech_id' => $data['tech_id'],
                    'tech_name' => \Helpers::getTechnolgyNameByID($data['tech_id']),
                    'role_id' => $data['role_id'],
                    'role_name' => \Helpers::getDesignationNameByID($data['role_id']),
                    'project_id' => $request['project_id'],
                    'APP_FRONTEND_URL' => config('constant.FRONTEND_URL')
                ];
                $requisitionMailArray[] = $requisitionArray;
            }
            $response = ResourceRequisition::insert($requisitionDataArray);
            PerformedActionLog::where(['project_id' => $request['project_id'], 'user_action_id' => config('constant.USER_ACTIONLIST.resource-allocation'), 'dept_id' => $data['dept_id']])->delete();
            $project = Project::with('ResourceRequisition', 'billingType', 'technologies', 'accountManagers', 'projectManagers', 'initiatedBy')
                ->where('uuid', $projectId)->first();
            if ($response) {
                //for mail
                $mailArray = [config('constant.TEMPLATES.requisition')];
                foreach ($mailArray as $val) {
                    $mailService = new MailService($val, $request['project_id'], $requisitionMailArray, $departmentArray);
                    $mailService->sendMail();
                }
            }
            $logResult = $project->toArray();
            Log::info($this->helpers->addToLog($projectId, $request, $project, config('constant.LOG_ACTIONS.creation_requisition')));
            $this->helpers->addlogActivityDB($projectId, $request, $requisitionMailArray, config('constant.LOG_ACTIONS.creation_requisition'));
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusCreated'), $project);
        } catch (\Exception $e) {
            Log::error($this->helpers->addToLog($projectId, $request, $e->getMessage(), config('constant.LOG_ACTIONS.creation_requisition')));
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    /**
     * separate direct extension and extension request and create it by using separate functions
     * @param Request $request
     * @return \Illuminate\Http\Response|\Laravel\Lumen\Http\ResponseFactory
     * @throws \Illuminate\Validation\ValidationException
     */
    public function ResourceExtensionRequest(Request $request)
    {
        $this->validate($request, self::$resourceExtensionRules);
        $resourcesData = $request->resource_data;
        $projectId = $request->project_id;
        $type = config('constant.REQUISITION_TYPE.extension');
        $roleDepartment = [];
        try {
            $role = Helpers::getRole($request->user->id, $projectId);
            if ((!empty($role['project']) || in_array($this->rolesArray[config('constant.ROLES.global_operation')], $role['global'])) && !empty($role['department'])
                ||  in_array($this->rolesArray[config('constant.ROLES.admin')], $role['global'])
            ) {

                if (in_array($this->rolesArray[config('constant.ROLES.admin')], $role['global'])) {
                    $role['department'] = Department::pluck('id')->toArray();
                }
                $roleDepartment = $role['department'];
            }
            $response['directAllocation'] = [];
            $response['extension'] = [];
            $response = $this->checkDepartmentValidation($resourcesData, $roleDepartment);
            if (!empty($response['directAllocation'])) {
                $logDetails = $this->saveDirectAllocationForExtension($request, $response['directAllocation'], $projectId, $type);
            }
            if (!empty($response['extension'])) {
                $logDetails = $this->saveExtensionRequest($request, $response['extension'], $projectId, $type);
            }
            $project = Project::with('ResourceRequisition', 'billingType', 'technologies', 'accountManagers', 'projectManagers', 'initiatedBy')
                ->where('uuid', $projectId)->first();
            Log::info($this->helpers->addToLog($projectId, $request, $project, config('constant.LOG_ACTIONS.resource_extension')));
            $this->helpers->addlogActivityDB($projectId, $request, $logDetails, config('constant.LOG_ACTIONS.resource_extension'));
            if (!empty($response['directAllocation'])) {
                $this->resourceMapping($request);
            }
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusCreated'), $project);
        } catch (\Exception $e) {
            Log::error($this->helpers->addToLog($projectId, $request, $e->getMessage(), config('constant.LOG_ACTIONS.resource_extension')));
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    /**
     * for direct extension first requisition, allocation, allocation meta and mapping record created
     * @param $request
     * @param $resourcesData
     * @param $projectId
     * @param $type
     * @return bool
     * @throws \Exception
     */
    public function saveDirectAllocationForExtension($request, $resourcesData, $projectId, $type)
    {
        $latestRequisition = false;
        $departmentArray = [];
        $projectDetails = Project::where('uuid', $projectId)->first();
        $mailDataArray = [];
        $status = config('constant.PERFORM_ACTIONLOG.completed');

        foreach ($resourcesData as $record) {
            $requisitionRecord = ResourceRequisition::saveRequisition($request, $record, $projectId, $type, $status);
            $latestRequisition = ResourceRequisition::orderBy('id', 'desc')->first();
            if (!in_array($record['dept_id'], $departmentArray)) {
                array_push($departmentArray, $record['dept_id']);
            }
            $latestRequisition->resource_id = $record['extension_resource_id'];
            $allocation = $this->resourceAllocation($latestRequisition, $request->user->id);
            $projectAction = [
                'link_id' => $latestRequisition['uuid'],
                'comment' => config('constant.DIRECT_REQUISITION_CODE'),
                'status_id' => $projectDetails['status'],
                'previous_status' => $projectDetails['status'],
                'requested_by' => $request->user->id,
                'response_by' => $request->user->id
            ];
            ProjectAction::saveProjectAction($projectAction);

            //Data for  direct allocation mail procedure
            $mailData = [
                'department' => \Helpers::getDepartmentNameByID($record['dept_id']),
                'efforts' => $record['efforts'],
                'allocation_efforts' => $record['allocation_efforts'],
                'experience' => $record['experience'],
                'resource_name' => \Helpers::getUserName($record['extension_resource_id']),
                'employee_code' => \Helpers::getEmployeeCode($record['extension_resource_id']),
                'employee_email' => \Helpers::getUserEmail($record['extension_resource_id']),
                'technology' =>  \Helpers::getTechnolgyNameByID($record['tech_id']),
                'role' =>  \Helpers::getDesignationNameByID($record['role_id']),
                'start_date' => $record['start_date'],
                'end_date' => $record['end_date'],
                'allocation_start_date' => $record['allocation_start_date'],
                'allocation_end_date' => $record['allocation_end_date'],
                'billing_type' => \Helpers::getBillableType($record['billing_type']),
            ];
            $mailDataArray[] = $mailData;
        }

        //for direct extension mail
        $mailArray = [config('constant.TEMPLATES.direct_extension')];
        foreach ($mailArray as $mailTemplate) {
            $mailService = new MailService($mailTemplate, $projectId, $mailDataArray, $departmentArray);
            $mailService->sendMail();
        }
        return $mailDataArray;
    }

    /**
     * extension resource request creation (create requisition with type extension)
     * @param $request
     * @param $resourcesData
     * @param $projectId
     * @param $type
     * @throws \Exception
     */
    public function saveExtensionRequest($request, $resourcesData, $projectId, $type)
    {
        $departmentArray = [];
        $requisitionMailArray = [];
        $requisitionDataArray = [];
        $status = config('constant.PERFORM_ACTIONLOG.inProgress');
        $max = ResourceRequisition::withTrashed()->find(\DB::table('resource_requisitions')->max('id'));
        $id = (isset($max->id) ? $max->id : 0);
        foreach ($resourcesData as $data) {
            $requisitionDataArray[] = $this->requisitionArray($request, $data, $projectId, $type, $status, ++$id);
            if ($type == config('constant.REQUISITION_TYPE.requisition')) {
                Project::where('uuid', $projectId)->update(array('status' => $request->project_status));
            }
            $this->requisitionPerformedActionLog($projectId);
            if (!in_array($data['dept_id'], $departmentArray)) {
                array_push($departmentArray, $data['dept_id']);
            }
            $requisitionArray = [
                'dept_id' => $data['dept_id'],
                'department' => \Helpers::getDepartmentNameByID($data['dept_id']),
                'efforts' => trim($data['efforts']),
                'allocation_efforts' => trim($data['allocation_efforts']),
                'start_date' => $data['start_date'],
                'end_date' => $data['end_date'],
                'allocation_start_date' => $data['allocation_start_date'],
                'allocation_end_date' => $data['allocation_end_date'],
                'experience' => trim($data['experience']),
                'resource_name' => \Helpers::getUserName($data['extension_resource_id']),
                'extension_resource_id' => \Helpers::getUserName($data['extension_resource_id']),
                'employee_code' => \Helpers::getEmployeeCode($data['extension_resource_id']),
                'employee_email' => \Helpers::getUserEmail($data['extension_resource_id']),
                'technology' =>  \Helpers::getTechnolgyNameByID($data['tech_id']),
                'role' =>  \Helpers::getDesignationNameByID($data['role_id']),
                'billing_type' => \Helpers::getBillableType($data['billing_type'])
            ];
            $requisitionMailArray[] = $requisitionArray;
        }
        $responce = ResourceRequisition::insert($requisitionDataArray);
        PerformedActionLog::where(['project_id' => $request['project_id'], 'user_action_id' => config('constant.USER_ACTIONLIST.resource-allocation'), 'dept_id' => $data['dept_id']])->delete();
        if ($responce) {
            //for extension mail
            $mailArray = [config('constant.TEMPLATES.extension')];
            foreach ($mailArray as $val) {
                $mailService = new MailService($val, $request['project_id'], $requisitionMailArray, $departmentArray);
                $mailService->sendMail();
            }
        }
        return $requisitionMailArray;
    }

    /**
     * separate direct extension and extension request data
     * @param $allocationData
     * @param $departments
     * @return mixed
     */
    public function checkDepartmentValidation($allocationData, $departments)
    {
        $response['directAllocation'] = [];
        $response['extension'] = [];
        if (isset($allocationData)) {
            foreach ($allocationData as $value) {
                if (in_array($value['dept_id'], $departments)) {
                    $response['directAllocation'][] = $value;
                } else {
                    $response['extension'][] = $value;
                }
            }
        }
        return $response;
    }

    /**
     * @param $request
     * @param $data
     * @param $projectId
     * @param $type
     * @param $status
     * @param $id unique id of row
     * @return array
     * @throws \Exception
     */
    public function requisitionArray($request, $data, $projectId, $type, $status, $id)
    {

        $uuid = (string) Uuid::generate(4);
        $resource = [
            'id' => $id,
            'uuid' => $uuid,
            'project_id' => $projectId,
            'dept_id' => $data['dept_id'],
            'tech_id' => $data['tech_id'],
            'role_id' => $data['role_id'],
            'no_of_resource' => isset($data['no_of_resource']) ? trim($data['no_of_resource']) : 1,
            'efforts' => trim($data['efforts']),
            'experience' => trim($data['experience']),
            'start_date' => $data['start_date'],
            'end_date' => $data['end_date'],
            'type' => trim($type),
            'req_user_id' => $request->user->id,
            'extension_resource_id' => isset($data['extension_resource_id']) ? $data['extension_resource_id'] : null,
            'status' => trim($status),
            'billing_type' => $data['billing_type'],
            'suggested_resource' => json_encode($data['suggested_resource'], TRUE),
            'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
            'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            'auto_extn_deallocation' => isset($data['auto_extn_deallocation']) ? $data['auto_extn_deallocation'] : 0,
            'reason' => isset($data['reason']) ? $data['reason'] : null,
            'other_reason' => isset($data['other_reason']) ? $data['other_reason'] : null,
            'tentative_date' => isset($data['tentative_date']) ? $data['tentative_date'] : null
        ];
        return $resource;
    }

    public function requisitionPerformedActionLog($projectId)
    {
        $checkPreviousLog = PerformedActionLog::where(['project_id' => $projectId, 'user_action_id' => 2, 'status' => '1'])->first();
        if (isset($checkPreviousLog)) {
            PerformedActionLog::where('project_id', $projectId)->where('user_action_id', '!=', 1)->delete();
            PerformedActionLog::storePerformedActionLog($projectId, 2, config('constant.PERFORM_ACTIONLOG.inProgress'));
        } else {
            PerformedActionLog::storePerformedActionLog($projectId, 2, config('constant.PERFORM_ACTIONLOG.inProgress'));
        }
    }

    /**
     *
     * @OA\Get(
     *     path="/v1/resource-requisition/{projectId}",
     *     operationId="/v1/resource-requisition/{projectId}",
     *     summary="Fetch Resource Requisition",
     *     tags={"Resource-requisition"},
     *     @OA\Parameter(
     *         name="projectId",
     *         in="path",
     *         description="Project UUID",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\Response(
     *         response="200",
     *         description="Returns Resource Requisition Detail",
     *         @OA\JsonContent()
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     * Return project's request resources based on project_id
     *
     * @param type $projectId
     * @return \Illuminate\Http\JsonResponse
     */

    public function show($projectId)
    {
        try {
            $data = Project::with('ResourceRequisition', 'billingType', 'technologies', 'accountManagers', 'projectManagers', 'initiatedBy')->where('uuid', $projectId)->first();
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $data);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    /**
     *
     * @OA\Get(
     *     path="/v1/resource-requiestion-by-dept/{projectId}",
     *     operationId="/v1/resource-requiestion-by-dept/{projectId}",
     *     summary="Fetch Resource Requisition By Dept",
     *     tags={"Resource-requisition"},
     *     @OA\Parameter(
     *         name="projectId",
     *         in="path",
     *         description="Project UUID",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\Response(
     *         response="200",
     *         description="Returns Resource Requisition Detail",
     *         @OA\JsonContent()
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     * Return project's request resources based on project_id
     *
     * @param type $projectId
     * @return \Illuminate\Http\JsonResponse
     */

    public function showRequistionByDept(Request $request, $projectId)
    {
        $department = [];
        $roles = Helpers::getRole($request->user->id, $request['project_id']);
        if (in_array(Helpers::getRoleIdByCode(config('constant.ROLES.admin')), $roles['global'])) {
            return $this->show($projectId);
        }
        if ($roles['department']) {
            $department = $roles['department'];
        }
        try {
            $data = Project::with(['ResourceRequisition' => function ($query) use ($department) {
                $query->whereIn('dept_id', $department);
            }, 'billingType', 'technologies', 'accountManagers', 'projectManagers', 'initiatedBy'])
                ->where('uuid', $projectId)->first();
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $data);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function updateRequisitionRole(Request $request)
    {
        $this->validate($request, self::$updateRequisitionRoleRules);
        $requestData = $request->toArray();
        try {
            $updatedRequisition = [
                'role_id' => $requestData['role_id'],
            ];
            $response = ResourceRequisition::where('uuid', $requestData['resource_requisition_uuid'])->update($updatedRequisition);
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $response);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    /**
     * @OA\Put(
     *     path="/v1/edit-requisition",
     *     summary="Edit Resource Requisition",
     *     operationId="/v1/edit-requisition",
     *     tags={"Resource-requisition"},
     *     @OA\RequestBody(
     *         required=true,
     *         description="Post object",
     *         @OA\JsonContent(ref="#/components/schemas/EditRequisition")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="A post",
     *         @OA\JsonContent(),
     *     ),
     *     @OA\Response(
     *         response="default",
     *         description="unexpected error",
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     *
     * Api for Edit Resource Requisition
     */
    public function editRequisition(Request $request)
    {
        $this->validate($request, self::$editRequisitionRules);
        $requestData = $request->toArray();
        $projectStatusChangeRequired = false;
        $finalResponse = '';
        try {
            $isDataCorrect = $this->checkRequisitionEditAccess($requestData['project_id'], $requestData['resource_data']);
            if ($isDataCorrect) {
                if ($requestData['resource_data']) {
                    $editDeptArray = [];
                    $deleteDeptArray = [];
                    $editRequisation = [];
                    $editExtensionRequisation = [];
                    $deleteRequisation = [];
                    $deleteExtensionRequisation = [];
                    foreach ($requestData['resource_data'] as $key => $data) {
                        $resourceRequisition = ResourceRequisition::where('uuid', $data['resource_requisition_uuid'])->first();
                        if ($data['isDelete']) {
                            $projectStatusChangeRequired = true;
                            $action = config('constant.LOG_ACTIONS.delete_requisition');
                            $response = ResourceRequisition::where('uuid', $data['resource_requisition_uuid'])->delete();
                            $response = [];
                            $response['isDeleted'] = true;
                            $data['Designation'] = Helpers::getDesignationNameByID($data['role_id']);
                            $data['Tech'] = Helpers::getTechnolgyNameByID($data['tech_id']);
                            $data['billing_type'] = \Helpers::getBillableType($data['billing_type']);
                            $data['requisition_type'] = $resourceRequisition['type'];
                            $data['dept_id'] = $resourceRequisition['dept_id'];
                            $data['department'] = \Helpers::getDepartmentNameByID($data['dept_id']);
                            if ($resourceRequisition['type'] == 1) {
                                $data['extension_resource_id'] = $resourceRequisition['extension_resource_id'];
                                $data['extension_resource_name'] =  \Helpers::getUserName($resourceRequisition['extension_resource_id']);
                                $data['employee_code'] = \Helpers::getEmployeeCode($data['extension_resource_id']);
                                $data['employee_email'] = \Helpers::getUserEmail($data['extension_resource_id']);
                                array_push($deleteExtensionRequisation, $data);
                            } else {
                                array_push($deleteRequisation, $data);
                            }
                            if (!in_array($data['dept_id'], $deleteDeptArray)) {
                                array_push($deleteDeptArray, $data['dept_id']);
                            }
                        } else {
                            $updatedRequisition = [
                                'tech_id' => $data['tech_id'],
                                'role_id' => $data['role_id'],
                                'no_of_resource' => trim($data['no_of_resource']),
                                'efforts' => trim($data['efforts']),
                                'experience' => trim($data['experience']),
                                'start_date' => $data['start_date'],
                                'end_date' => $data['end_date'],
                                'billing_type' => $data['billing_type'],
                                'suggested_resource' => $data['suggested_resource']
                            ];
                            $action = config('constant.LOG_ACTIONS.edit_requisition');
                            $response = ResourceRequisition::where('uuid', $data['resource_requisition_uuid'])->update($updatedRequisition);
                            $response = [];
                            $response['isDeleted'] = false;
                            $data['Designation'] = Helpers::getDesignationNameByID($data['role_id']);
                            $data['Tech'] = Helpers::getTechnolgyNameByID($data['tech_id']);
                            $data['billing_type'] = \Helpers::getBillableType($data['billing_type']);
                            $data['requisition_type'] = $resourceRequisition['type'];
                            $data['dept_id'] = $resourceRequisition['dept_id'];
                            $data['department'] = \Helpers::getDepartmentNameByID($resourceRequisition['dept_id']);
                            if ($data['requisition_type'] == 1) {
                                $data['extension_resource_id'] = $resourceRequisition['extension_resource_id'];
                                $data['extension_resource_name'] =  \Helpers::getUserName($resourceRequisition['extension_resource_id']);
                                $data['employee_code'] = \Helpers::getEmployeeCode($data['extension_resource_id']);
                                $data['employee_email'] = \Helpers::getUserEmail($data['extension_resource_id']);
                                array_push($editExtensionRequisation, $data);
                            } else {
                                array_push($editRequisation, $data);
                            }
                            if (!in_array($data['dept_id'], $editDeptArray)) {
                                array_push($editDeptArray, $data['dept_id']);
                            }
                        }
                    }
                    if ($projectStatusChangeRequired) {
                        $this->updateProjectStatusAccordingResources($requestData['project_id'], true);
                        $this->removePerformedLog($requestData['project_id']);
                    }
                    if (isset($editDeptArray[0])) {
                        if (!empty($editRequisation)) {
                            $mailRequisation = [config('constant.TEMPLATES.edit_requisition')];
                            foreach ($mailRequisation as $val) {
                                $mailService = new MailService($val, $requestData['project_id'], $editRequisation, $editDeptArray);
                                $mailService->sendMail();
                            }
                            Log::info($this->helpers->addToLog($requestData['project_id'], $request, $editRequisation, config('constant.LOG_ACTIONS.edit_requisition')));
                            $this->helpers->addlogActivityDB($requestData['project_id'], $request, $editRequisation, config('constant.LOG_ACTIONS.edit_requisition'));
                        }

                        if (!empty($editExtensionRequisation)) {
                            $mailExtension = [config('constant.TEMPLATES.edit_extension_requisition')];
                            foreach ($mailExtension as $val) {
                                $mailService = new MailService($val, $requestData['project_id'], $editExtensionRequisation, $editDeptArray);
                                $mailService->sendMail();
                            }
                            Log::info($this->helpers->addToLog($requestData['project_id'], $request, $editExtensionRequisation, config('constant.LOG_ACTIONS.edit_extension_requisition')));
                            $this->helpers->addlogActivityDB($requestData['project_id'], $request, $editExtensionRequisation, config('constant.LOG_ACTIONS.edit_extension_requisition'));
                        }
                    }
                    if (isset($deleteDeptArray[0])) {
                        $finalResponse = $deleteRequisation;
                        if (!empty($deleteRequisation)) {
                            $mailDelete = config('constant.TEMPLATES.delete_requisition');
                            $mailService = new MailService($mailDelete, $requestData['project_id'], $deleteRequisation, $deleteDeptArray);
                            $mailService->sendMail();
                            Log::info($this->helpers->addToLog($requestData['project_id'], $request, $deleteRequisation, config('constant.LOG_ACTIONS.delete_requisition')));
                            $this->helpers->addlogActivityDB($requestData['project_id'], $request, $deleteRequisation, config('constant.LOG_ACTIONS.delete_requisition'));
                        }
                        if (!empty($deleteExtensionRequisation)) {
                            $mailDeleteExtension = config('constant.TEMPLATES.delete_extension_requisition');
                            $mailService = new MailService($mailDeleteExtension, $requestData['project_id'], $deleteExtensionRequisation, $deleteDeptArray);
                            $mailService->sendMail();
                            Log::info($this->helpers->addToLog($requestData['project_id'], $request, $deleteExtensionRequisation, config('constant.LOG_ACTIONS.delete_extension_requisition')));
                            $this->helpers->addlogActivityDB($requestData['project_id'], $request, $deleteExtensionRequisation, config('constant.LOG_ACTIONS.delete_extension_requisition'));
                        }
                    }
                }
                return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $response);
            } else {
                return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusUnprocessable'), '', 'Requisition id incorrect');
            }
        } catch (\Exception $e) {
            Log::error($this->helpers->addToLog($requestData['project_id'], $request, $e->getMessage(), $action));
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function removePerformedLog($projectId)
    {
        $requisition = ResourceRequisition::where('project_id', $projectId)->first();
        if (!isset($requisition)) {
            PerformedActionLog::where('project_id', $projectId)->where('user_action_id', config('constant.USER_ACTIONLIST')['resource-requisition'])->delete();
        }
    }

    public function checkRequisitionEditAccess($projectId, $record)
    {
        $response = true;
        $eligibleRequisition = [];
        $requisition = ResourceRequisition::where('project_id', $projectId)->with('ResourceAllocation')->get();
        if ($requisition) {
            foreach ($requisition as $key => $value) {
                if ((count($value['ResourceAllocation']) == 0)) {
                    array_push($eligibleRequisition, $value['uuid']);
                }
            }
        }
        if ($record) {
            foreach ($record as $index => $data) {
                if (!in_array($data['resource_requisition_uuid'], $eligibleRequisition)) {
                    $response = false;
                    break;
                }
            }
        }
        return $response;
    }

    public function rejectRequisition(Request $request)
    {
        $requestData = $request->toArray();
        $project_id = $requestData['project_id'];
        $reason = $requestData['reason'];
        $other_reason = $requestData['other_reason'];
        $uuid = $requestData['uuid'];
        $tentative_date = Carbon::parse($requestData['tentative_date'])->format('Y-m-d');
        $update = ResourceRequisition::where('uuid', $uuid)->where('project_id', $project_id)->first();
        try {
            if ($update) {
                $update->reason = $reason;
                $update->other_reason = $other_reason;
                $update->tentative_date = $tentative_date;
                $update->save();
                $update->delete();

                $requisitionArray = [
                    'dept_id' => $update['dept_id'],
                    'department' => \Helpers::getDepartmentNameByID($update['dept_id']),
                    'efforts' => trim($update['efforts']),
                    'start_date' => $update['start_date'],
                    'end_date' => $update['end_date'],
                    'experience' => trim($update['experience']),
                    'no_of_resource' => trim($update['no_of_resource']),
                    'billing_type' => \Helpers::getBillableType($update['billing_type']),
                    'suggested_resource' => $update['suggested_resource'],
                    'tech_id' => $update['tech_id'],
                    'tech_name' => \Helpers::getTechnolgyNameByID($update['tech_id']),
                    'role_id' => $update['role_id'],
                    'role_name' => \Helpers::getDesignationNameByID($update['role_id']),
                    'project_id' => $request['project_id'],
                    'reason' => $reason,
                    'other_reason' => $other_reason,
                    'tentative_date' => $tentative_date
                ];
                $requisitionMailArray[] = $requisitionArray;

                $mailArray = [config('constant.TEMPLATES.reject_requisition_email')];
                foreach ($mailArray as $val) {
                    $mailService = new MailService($val, $project_id, $requisitionMailArray);
                    $mailService->sendMail();
                }
                $updatedData = ResourceRequisition::where('uuid', $uuid)->where('project_id', $project_id)->withTrashed()->first();
                Log::info($this->helpers->addToLog($project_id, $request, $updatedData, config('constant.LOG_ACTIONS.reject_requisition')));
                $this->helpers->addlogActivityDB($project_id, $request, $requisitionMailArray, config('constant.LOG_ACTIONS.reject_requisition'));
                return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $updatedData);
            } else {
                return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), '', 'Already rejected');
            }
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function resourceMapping($request)
    {
        $resourceMapping = new ResourceMappingController($this->helpers);
        foreach ($request['resource_data'] as $allocation) {
            $resource = ResourceMapping::where('status', 0)
                ->where('resource_id', $allocation['extension_resource_id'])->where('project_id', $request['project_id'])->first();
            if (isset($resource['uuid'])) {
                $user_data = LocalUser::where('user_id',  $allocation['extension_resource_id'])->first();
                $startDate = Carbon::parse($allocation['start_date'])->isoFormat('MMM D, YYYY');
                $endDate = Carbon::parse($allocation['end_date'])->isoFormat('MMM D, YYYY');
                $map_data['action'] = false;
                $map_data['billing_type'] = \Helpers::getBillableType($allocation['billing_type']);
                $map_data['dept'] = \Helpers::getDepartmentNameByID($allocation['dept_id']);
                $map_data['designation'] = \Helpers::getDesignationNameByID($allocation['role_id']);
                $map_data['efforts'] = trim($allocation['efforts']);
                $map_data['end_date'] = $endDate;
                $map_data['experience'] = trim($allocation['experience']);
                $map_data['id'] = $resource['uuid'];
                $map_data['requested_by'] = $request['user']['full_name'];
                $map_data['requested_on'] = $startDate;
                $map_data['resource_mapping_id'] = $resource['uuid'];
                $map_data['resource_name'] = \Helpers::getUserName($allocation['extension_resource_id']);
                $map_data['start_date'] = $startDate;
                $map_data['status'] = "1";
                $map_data['tech'] = \Helpers::getTechnolgyNameByID($allocation['tech_id']);
                $project = Project::with(['projectManagers'])->where('uuid', $request['project_id'])->first();
                $mailData = array(
                    'project_manager' => $project['projectManagers'][0]['user']['display_name'],
                    'project_hours' => trim($allocation['efforts']),
                    'email' => $user_data['email']
                );
                $request['map_data'] = [$map_data];
                $request['project_status'] = 7;
                $status = true;
                $resourceMapping->mapResource($request, $status);
                $this->sendEmailToEmployee($request['project_id'], $mailData);
            }
        }
        return 1;
    }

    public function sendEmailToEmployee($project_id, $mailData)
    {
        $mail = config('constant.TEMPLATES.employee_allocation_email');
        $mailService = new MailService($mail, $project_id, $mailData);
        $mailService->sendMail();
        return 1;
    }
}
