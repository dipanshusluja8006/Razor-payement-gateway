<?php

namespace App\Http\Controllers\Resource;
use App\Http\Controllers\Controller;
use App\Libraries\MailService;
use App\Models\Project;
use App\Models\ProjectAction;
use App\Models\PerformedActionLog;
use App\Models\ProjectClosureChecklist;
use Carbon\Carbon;
use Illuminate\Http\Request;
use ApiResponse;
use Log;
use Helpers;
use App\Traits\ResourceControllerTraits;

class ProjectStatusController extends Controller
{
    use ResourceControllerTraits;
    protected $helpers;
    public function __construct(Helpers $helpers)
    {
        $this->helpers = $helpers;
    }

    public static $onHoldValidationRules = [
        'reason' => 'required',
        'from' => 'required|date',
        'to' => 'required|date',
    ];
    /**
     * @OA\Get(
     *     path="/v1/on-hold/{uuid}",
     *     operationId="/v1/on-hold/{uuid}",
     *     summary="Fetch project Status details",
     *     tags={"Project-OnHold"},
     *     @OA\Parameter(
     *         name="uuid",
     *         in="path",
     *         description="Project UUID",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\Response(
     *         response="200",
     *         description="Returns Project Status",
     *         @OA\JsonContent()
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     *
     * Api for fetch Project Status by passing Project uuid as argument
     */

    public function show(Request $request, $projectId)
    {
        try {
            $projectStatus = Project::where('uuid', $projectId)
                ->with(['status', 'projectAction', 'accountManagers', 'projectManagers', 'initiatedBy'])
                ->firstOrFail();
            $previousProjectDetails = ProjectAction::where([
                'link_id' => $projectId,
                'status_id' => config('constant.PROJECT_ACTION')['project_on_hold_request']
            ])
                ->orderBy('id', 'desc')
                ->first();
            if(isset($previousProjectDetails)){
                $projectStatus->requested_by = Helpers::getUserName($previousProjectDetails['requested_by']);
                $projectStatus->requested_on = $previousProjectDetails['created_at'];
            }else{
                $projectStatus->requested_by = null;
                $projectStatus->requested_on = null;
            }
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $projectStatus);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    /**
     * Api for update Project Status request(Approve/Reject)
     */

    /**
     * @OA\Put(
     *     path="/v1/on-hold/{uuid}",
     *     summary="Project On-Hold Request",
     *     operationId="/v1/on-hold/projectOnhold",
     *     tags={"Project-OnHold"},
     *     @OA\Parameter(
     *         name="uuid",
     *         in="path",
     *         description="Project UUID",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\RequestBody(
     *         required=true,
     *         description="Post object",
     *         @OA\JsonContent(ref="#/components/schemas/ProjectOnHold")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="A post",
     *         @OA\JsonContent(),
     *     ),
     *     @OA\Response(
     *         response="default",
     *         description="unexpected error",
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     */
    public function onHoldRequest(Request $request, $projectId)
    {
        $this->validate($request, self::$onHoldValidationRules);
        $data = $request->toArray();
        try {
            if (strtotime($data['to']) >= strtotime($data['from'])) {
                $project = Project::where('uuid', $projectId)->first();
                $status = Project::updateProjectStatus(config('constant.PROJECT_ACTION.project_on_hold_request'), $data['user']->id, $projectId);
                if ($status['uuid']) {
                    $projectAction = [
                        'link_id' => $status['uuid'],
                        'comment' => $data['reason'],
                        'from' => Carbon::parse($data['from'])->format('Y-m-d'),
                        'to' => Carbon::parse($data['to'])->format('Y-m-d'),
                        'status_id' => config('constant.PROJECT_ACTION.project_on_hold_request'),
                        'previous_status' => $project['status'],
                        'requested_by' => $data['user']->id,
                    ];
                    $onholdRequestLog = [
                        'link_id' => $status['uuid'],
                        'comment' => $data['reason'],
                        'from' => Carbon::parse($data['from'])->format('Y-m-d'),
                        'to' => Carbon::parse($data['to'])->format('Y-m-d'),
                        'status_id' => config('constant.PROJECT_ACTION.project_on_hold_request'),
                        'previous_status' => $project['status'],
                        'requested_by' => $data['user']->id,
                        'requested_by_name' => \Helpers::getUserName($data['user']->id),
                    ];
                    $action = ProjectAction::saveProjectAction($projectAction);
                    PerformedActionLog::where('project_id', $projectId)->where('user_action_id', config('constant.USER_ACTIONLIST.hold-request'))->delete();
                    PerformedActionLog::storePerformedActionLog($projectId, config('constant.USER_ACTIONLIST.hold-request'), config('constant.PERFORM_ACTIONLOG.inProgress'));
                    //for mail
                    $mailArray = [config('constant.TEMPLATES.on_hold_request')];
                    foreach ($mailArray as $val) {
                    $mailService = new MailService($val, $projectId);
                    $mailService->sendMail();
                   }
                }
            } else {
                $msg = 'From date is greater than To date';
                return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusUnprocessable'), $msg);
            }
            Log::info($this->helpers->addToLog($projectId,$request,$status,config('constant.LOG_ACTIONS.hold_request')));
            Log::info($this->helpers->addlogActivityDB($projectId,$request,$onholdRequestLog,config('constant.LOG_ACTIONS.hold_request')));
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $status);
        } catch (\Exception $e) {
            Log::error($this->helpers->addToLog($projectId,$request,$e->getMessage(),config('constant.LOG_ACTIONS.hold_request')));
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public static $onHoldActionValidationRules = [
        'status_id' => 'required',
        'requested_by' => 'required|exists:redmine_db_mysql.users,id',
        'reason' => 'required',
        'from' => 'required|date',
        'to' => 'required|date',
    ];

    public static $updateProjectStatusValidationRules = [
        'status_id' => 'required',
    ];

    /**
     * Api for update project status
     */
    public function update(Request $request, $projectId)
    {
        $globalResponse = ['data' => '', 'msg' => '', 'status' => '400'];
        $this->validate($request, self::$updateProjectStatusValidationRules);
        $data = $request->toArray();
        try{
        $status = Project::updateProjectStatus($data['status_id'], $data['user']->id, $projectId);
        if ($status['uuid']) {
            $lastProjectAction = ProjectAction::where('link_id', $status['uuid'])->orderBy('id', 'DESC')->first();
            $projectAction = [
                'link_id' => $status['uuid'],
                'comment' => $lastProjectAction['comment'],
                'from' => Carbon::parse($lastProjectAction['from'])->format('Y-m-d'),
                'to' => Carbon::parse($lastProjectAction['to'])->format('Y-m-d'),
                'status_id' => $data['status_id'],
                'requested_by' => $data['user']->id,
            ];
            $action = ProjectAction::saveProjectAction($projectAction);
            Log::info($this->helpers->addlogActivityDB($request->merge(['project_id' => $projectId]),$action,config('constant.LOG_ACTIONS.project_close')));
            $globalResponse = ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $action);
        }
        return $globalResponse;
    }catch (\Exception $e) {
        Log::error($this->helpers->addlogActivityDB($request->merge(['project_id' => $projectId]),$e->getMessage(),config('constant.LOG_ACTIONS.project_close')));
        return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
    }
    }

    /**
     * @OA\Put(
     *     path="/v1/on-hold-action/{uuid}",
     *     summary="Project On-Hold Action",
     *     operationId="/v1/on-hold-action/{uuid}",
     *     tags={"Project-OnHold"},
     *     @OA\Parameter(
     *         name="uuid",
     *         in="path",
     *         description="Project UUID",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\RequestBody(
     *         required=true,
     *         description="Post object",
     *         @OA\JsonContent(ref="#/components/schemas/ProjectOnHoldAction")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="A post",
     *         @OA\JsonContent(),
     *     ),
     *     @OA\Response(
     *         response="default",
     *         description="unexpected error",
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     */
    public function onHoldAction(Request $request, $projectId)
    {
        $unMappedMailData = [];
        $action='';
        $this->validate($request, self::$onHoldActionValidationRules);
        $data = $request->toArray();
        try{
        $projectActionLog = true;
        $projectStatus = $data['status_id'];
        if ($projectStatus != config('constant.PROJECT_ACTION')['project_on_hold_request_accept']) {
            $previousProjectDetails = ProjectAction::where([
                'link_id' => $projectId,
                'status_id' => config('constant.PROJECT_ACTION')['project_on_hold_request']
            ])
                ->orderBy('id', 'desc')
                ->first();
            $projectStatus = $previousProjectDetails['previous_status'];
            $projectActionLog = false;
        }
        $project = Project::where('uuid', $projectId)->first();
        if ($projectStatus == config('constant.PROJECT_ACTION')['project_on_hold_request_accept']) {
            $this->deleteAllPendingRequisitionAndMapping($request,$projectId);
            $unMappedMailData = $this->MapAllDeAllocationMappingAndSendMail($request,$projectId);
        }

        $status = Project::updateProjectStatus($projectStatus, $data['user']->id, $projectId);
        if ($status['uuid']) {
            $projectAction = [
                'link_id' => $status['uuid'],
                'comment' => $data['reason'],
                'from' => Carbon::parse($data['from'])->format('Y-m-d'),
                'to' => Carbon::parse($data['to'])->format('Y-m-d'),
                'status_id' => $projectStatus,
                'requested_by' => $data['requested_by'],
                'previous_status' => $project['status'],
                'response_by' => $data['user']->id
            ];
            $action = ProjectAction::saveProjectAction($projectAction);
            $projectActionActivity = [
                'link_id' => $status['uuid'],
                'comment' => $data['reason'],
                'from' => Carbon::parse($data['from'])->format('Y-m-d'),
                'to' => Carbon::parse($data['to'])->format('Y-m-d'),
                'status_id' => $projectStatus,
                'requested_by' => $data['requested_by'],
                'requested_by_name' => \Helpers::getUserName($data['requested_by']),
                'previous_status' => $project['status'],
                'response_by' => $data['user']->id,
                'response_by_name' => \Helpers::getUserName($data['user']->id),
            ];
        }
        if ($projectActionLog) {
            PerformedActionLog::where(['project_id' => $projectId, 'user_action_id' => config('constant.USER_ACTIONLIST.hold-request')])->update(['status' => '1']);
        } else {
            $isHoldApprovedPreviously = ProjectAction::where(
                [
                    'link_id' => $projectId,
                    'status_id' => config('constant.PROJECT_ACTION')['project_on_hold_request_accept']
                ]
            )->first();
            if (isset($isHoldApprovedPreviously)) {
                PerformedActionLog::where(['project_id' => $projectId, 'user_action_id' => config('constant.USER_ACTIONLIST.hold-request')])->update(['status' => '1']);
            } else {
                PerformedActionLog::where('project_id', $projectId)->where('user_action_id', config('constant.USER_ACTIONLIST.hold-request'))->delete();
            }
        }
        //for mail
        if ($projectStatus == config('constant.PROJECT_ACTION')['project_on_hold_request_accept']) {
            /*if(isset($unMappedMailData['unMappingData']) && !empty($unMappedMailData['unMappingData'])){
                $templates[] = config('constant.TEMPLATES.on_hold_approved');
            }*/
            $templates[] = config('constant.TEMPLATES.on_hold_approved');
            $action=config('constant.LOG_ACTIONS.project_on_hold_request_accept');
        }else{
            $templates[] = config('constant.TEMPLATES.on_hold_rejection');
            $action=config('constant.LOG_ACTIONS.project_on_hold_rejection');
        }
        foreach ($templates as $template){
            $mailService = new MailService($template, $projectId, $unMappedMailData);
            $mailService->sendMail();
        }
        Log::info($this->helpers->addToLog($projectId,$request,$status,$action));
        $this->helpers->addlogActivityDB($projectId,$request,$projectActionActivity,$action);
        return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $status);
    }catch (\Exception $e) {
        Log::error($this->helpers->addToLog($projectId,$request,$e->getMessage(),$action));
        return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
    }
}

    /**
     * @OA\Put(
     *     path="/v1/project-restart/{uuid}",
     *     summary="project Restart",
     *     operationId="/v1/project-restart/{uuid}",
     *     tags={"Project-OnHold"},
     *     @OA\Parameter(
     *         name="uuid",
     *         in="path",
     *         description="Project UUID",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="A post",
     *         @OA\JsonContent(),
     *     ),
     *     @OA\Response(
     *         response="default",
     *         description="unexpected error",
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     */
    public function restart(Request $request, $projectId)
    {
        $data = $request->toArray();
        try {
            $previousProjectStatusId = config('constant.PROJECT_ACTION')['resource_mapping'];
            $previousProjectDetails = ProjectAction::where(['link_id' => $projectId])
                ->where('previous_status', '!=', config('constant.PROJECT_ACTION')['project_on_hold_request_accept'])
                ->where(function ($query) {
                    $query->where('status_id', '=', config('constant.PROJECT_ACTION')['project_on_hold_request'])
                        ->orWhere('status_id', '=', config('constant.PROJECT_ACTION')['project_closure_checklist']);
                })
                ->orderBy('id', 'desc')->first();
            if ($previousProjectDetails['previous_status']) {
                $previousProjectStatusId = $previousProjectDetails['previous_status'];
            }
            $closureChecklist = [
                'project_checklist' => null,
                'updated_by' => $request->user->id
            ];
            ProjectClosureChecklist::where('project_id', $projectId)->update($closureChecklist);
            $status = Project::updateProjectStatus($previousProjectStatusId, $data['user']->id, $projectId);
            $projectAction = [
                'link_id' => $projectId,
                'comment' => (isset($data['message'])) ? $data['message'] : config('constant.PROJECT_CLOSE_DEFAULT_MESSAGE'),
                'status_id' => $previousProjectDetails['status_id'],
                'from' => NULL,
                'to' => NULL,
                'previous_status' => $previousProjectStatusId,
                'requested_by' => $request->user->id,
            ];
            ProjectAction::saveProjectAction($projectAction);
            $projectActionRestart = [
                'link_id' => $projectId,
                'comment' => (isset($data['message'])) ? $data['message'] : config('constant.PROJECT_CLOSE_DEFAULT_MESSAGE'),
                'status_id' => $previousProjectDetails['status_id'],
                'from' => NULL,
                'to' => NULL,
                'previous_status' => $previousProjectStatusId,
                'requested_by' => $request->user->id,
                'response_by_name' => \Helpers::getUserName($request->user->id),
            ];
            $mailArray=[config('constant.TEMPLATES.restart')];
            foreach($mailArray as $val){
                $mailService = new MailService($val, $projectId,$projectAction);
                $mailService->sendMail();
            }
            Log::info($this->helpers->addToLog($projectId,$request,$status,config('constant.LOG_ACTIONS.restart_project')));
            $this->helpers->addlogActivityDB($projectId,$request,$projectActionRestart,config('constant.LOG_ACTIONS.restart_project'));
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $status);
        } catch (\Exception $e) {
            Log::error($this->helpers->addToLog($projectId,$request,$e->getMessage(),config('constant.LOG_ACTIONS.restart_project')));
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }
}
