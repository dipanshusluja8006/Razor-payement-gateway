<?php

namespace App\Http\Controllers\Resource;

use App\Libraries\MailService;
use App\Models\DeAllocationMapping;
use App\Models\Project;
use App\Models\ReportingManager;
use App\Models\ResourceAllocation;
use App\Models\ResourceAllocationMeta;
use App\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Log;
use App\Traits\ResourceControllerTraits;
use Illuminate\Support\Facades\DB;
use Helpers;
use App\Models\Department;
use ApiResponse;
use Successive\Keka\Http\Services\EmployeeService;
use Carbon\Carbon;
use Webpatser\Uuid\Uuid;
use Illuminate\Support\Facades\Mail;
use App\Models\LocalUser;

class ReportingManagerController extends Controller
{
    use ResourceControllerTraits;

    public static $validationRules = [
        'resource_data' => 'array',
        'resource_data.*.resource_id' => 'required|exists:redmine_db_mysql.users,id',
        'resource_data.*.requested_rm_id' => 'required|exists:redmine_db_mysql.users,id',
        'resource_data.*.active_rm_id' => 'required|exists:redmine_db_mysql.users,id',
        'resource_data.*.dept_id' => 'required|exists:resource_mysql.departments,id',
        'project_id' => 'required|exists:resource_mysql.projects,uuid',
    ];

    public static $approvalValidationRules = [
        'resource_data' => 'array',
        'resource_data.*.uuid' => 'required|exists:resource_mysql.reporting_managers,uuid',
        'resource_data.*.resource_id' => 'required|exists:redmine_db_mysql.users,id',
        'resource_data.*.active_rm_id' => 'required|exists:redmine_db_mysql.users,id',
        'resource_data.*.requested_rm_id' => 'required|exists:redmine_db_mysql.users,id',
        'resource_data.*.dept_id' => 'required|exists:resource_mysql.departments,id',
        'is_approved' => 'required',
    ];

    public static $directReportingValidationRules = [
        'resource_data' => 'array',
        'resource_data.*.resource_id' => 'required|exists:redmine_db_mysql.users,id',
        'resource_data.*.active_rm_id' => 'required|exists:redmine_db_mysql.users,id',
        'resource_data.*.requested_rm_id' => 'exists:redmine_db_mysql.users,id',
        'resource_data.*.dept_id' => 'required|exists:resource_mysql.departments,id',

    ];

    // show all users in under bu unit for teams
    public function departmentWiseReporting(Request $request)
    {
        $result = Helpers::getKekaData();
        $managers = User::select(
            'id',
            DB::raw("CONCAT(firstname,' ',lastname) as display_name"),
            DB::raw("(select address from email_addresses where users.id  =   user_id) as email")
        )
            ->where('status', config('constant.REDMINE_USERSTATUS')['activeUser'])
            ->where('type', config('constant.REDMINE_USERSTATUS')['userType'])->get();

        $users = User::select(
            'id',
            DB::raw("CONCAT(firstname,' ',lastname) as display_name"),
            DB::raw("(select address from email_addresses where users.id  =   user_id) as email"),
            DB::raw("(select value from custom_values where customized_id = users.id and custom_field_id = 15) as employee_id")
        )
            ->with(['userDepartment', 'ReportingManager'])
            ->where('status', config('constant.REDMINE_USERSTATUS')['activeUser'])
            ->where('type', config('constant.REDMINE_USERSTATUS')['userType'])->get();

        $currentUserId = $request->user->id;
        $globalDepartment = null;
        $userRole = Helpers::getRole($currentUserId);
        $data = [];
        $trimDepartments = [];
        if (in_array(Helpers::getRoleIdByCode(config('constant.ROLES.bu_head')), $userRole['global'])) {
            $globalDepartment = Department::whereIn('id', $userRole['department'])->pluck('name')->toArray();
            foreach ($globalDepartment as $dept) {
                $trimDepartments[] = Helpers::cleanAll($dept);
            }
        }
        $userIds = [];
        foreach ($users as $user) {
            $user->key = false;
            foreach ($user['userDepartment'] as $value) {
                $department = Helpers::cleanAll($value['value']);
                if (
                    !in_array($user->id, $userIds) && $department != "" &&
                    $department != trim(config('constant.EXCLUDE_REPORTING_DEPARTMENTS')) &&
                    (in_array($department, $trimDepartments) ||
                        in_array(Helpers::getRoleIdByCode(config('constant.ROLES.admin')), $userRole['global']))
                ) {
                    $userIds[] = $user->id;
                    $user = $this->mapCurrentRM($user, $managers, $result);
                    if ($user) {
                        $data[$department][] = $user;
                    }
                    break;
                }
            }
        }
        return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $data);
    }

    public function mapCurrentRM($user, $managers, $result)
    {
        foreach ($result as $key => $value) {
            if (
                trim($value['employeeNumber']) == trim($user->employee_id) ||
                trim($value['email']) == trim($user->email)
            ) {
                if (isset($user['ReportingManager']['ActiveResourceManager']->id)) {
                    if (trim($value['reportsTo']['email']) == trim($user['ReportingManager']['ActiveResourceManager']->email)) {
                        $user->current_rm = $user['ReportingManager']['ActiveResourceManager'];
                        $user->status = 'Assigned';
                        $user->requested_rm_id = null;
                        $user->keka_rm = $value['reportsTo']["firstName"] . " " . $value['reportsTo']["lastName"];
                        $user->keka_rm_email = $value['reportsTo']['email'];
                        return $user;
                    } else {
                        $user->current_rm = $user['ReportingManager']['ActiveResourceManager'];
                        $user->status = 'inProgress';
                        $user->requested_rm_id = $user['ReportingManager']['RequestedResourceManager'];
                        $user->keka_rm = $value['reportsTo']["firstName"] . " " . $value['reportsTo']["lastName"];
                        $user->keka_rm_email = $value['reportsTo']['email'];
                        return $user;
                    }
                } else {
                    foreach ($managers as $manager) {
                        if (trim($value['reportsTo']['email']) == trim($manager->email)) {
                            $user->current_rm = $manager;
                            $user->status = 'Assigned';
                            $user->requested_rm_id = null;
                            $user->keka_rm = $value['reportsTo']["firstName"] . " " . $value['reportsTo']["lastName"];
                            $user->keka_rm_email = $value['reportsTo']['email'];
                            return $user;
                        }
                    }
                }
            }
        }
        return null;
    }

    // show all users in under bu unit for teams
    public function directReportingResource(Request $request)
    {
        $result = Helpers::getKekaData();
        $users = User::select(
            'id',
            DB::raw("CONCAT(firstname,' ',lastname) as display_name"),
            DB::raw("(select address from email_addresses where users.id  =   user_id) as email"),
            DB::raw("(select value from custom_values where customized_id = users.id and custom_field_id = 15) as employee_id")
        )
            ->where('status', config('constant.REDMINE_USERSTATUS')['activeUser'])
            ->where('type', config('constant.REDMINE_USERSTATUS')['userType'])->get();
        $manager =  $request->user;
        $data = [];
        foreach ($users as $key => $user) {
            $user = $this->mapCurrentAssignedRM($user, $manager, $result);
            if (isset($user)) {
                $data[] = $user;
            }
        }
        return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $data);
    }

    public function mapCurrentAssignedRM($user, $manager, $result)
    {
        foreach ($result as $key => $value) {
            if (trim($value['employeeNumber']) == trim($user->employee_id) || trim($value['email']) == trim($user->email)) {
                if (trim($value['reportsTo']['email']) == trim($manager->email)) {
                    $user->current_rm = $manager;
                    $user->status = 'Assigned';
                    return $user;
                }
            }
        }
    }

    public function reportingRequestList(Request $request)
    {
        $pendingRequests = ReportingManager::with('resource', 'ActiveResourceManager', 'RequestedResourceManager', 'CreatedBy', 'UpdatedBy')->where('is_approved', 0)->get();
        $result = Helpers::getKekaData();
        $departmentName = '';
        $currentUserId = $request->user->id;
        $globalDepartment = null;
        $userRole = Helpers::getRole($currentUserId);
        $data = [];
        $trimDepartments = [];
        if (in_array(Helpers::getRoleIdByCode(config('constant.ROLES.bu_head')), $userRole['global'])) {
            $globalDepartment = Department::whereIn('id', $userRole['department'])->pluck('name')->toArray();
            foreach ($globalDepartment as $dept) {
                $trimDepartments[] = Helpers::cleanAll($dept);
            }
        }
        foreach ($pendingRequests as $pendingRequest) {
            if (
                isset($pendingRequest['resource']->status) &&
                $pendingRequest['resource']->status == config('constant.REDMINE_USERSTATUS')['activeUser']
            ) {
                foreach ($pendingRequest['resource']['userDepartment'] as $value) {
                    $dept = Helpers::cleanAll($value['value']);
                    if (
                        in_array($dept, $trimDepartments) ||
                        in_array(Helpers::getRoleIdByCode(config('constant.ROLES.admin')), $userRole['global'])
                    ) {
                        if (
                            isset($pendingRequest['resource']->email) ||
                            isset($pendingRequest['resource']->employee_id)
                        ) {
                            $pendingRequest = $this->mapResourceExprence($pendingRequest, $result);
                            if ($pendingRequest) {
                                $data[] = $pendingRequest;
                                break;
                            }
                        }
                    }
                }
            }
        }
        return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $data);
    }

    public function mapResourceExprence($pendingRequest, $result)
    {
        foreach ($result as $value) {
            $redmineEmail = isset($pendingRequest['resource']->email) ? $pendingRequest['resource']->email : '';
            $redmineEmployeeId = isset($pendingRequest['resource']->employee_id) ? $pendingRequest['resource']->employee_id : '';
            if (
                trim($value['email']) == trim($redmineEmail) ||
                trim($value['employeeNumber']) == trim($redmineEmployeeId)
            ) {
                $firstName = isset($value['reportsTo']['firstName']) ? $value['reportsTo']['firstName'] : '';
                $lastName = isset($value['reportsTo']['lastName']) ? $value['reportsTo']['lastName'] : '';
                $value['reportsTo']['email'] = isset($value['reportsTo']['email']) ? $value['reportsTo']['email'] : '';
                $PriviousExp = 0;
                foreach ($value['experienceDetails'] as $experienceDetails) {
                    if (isset($experienceDetails['dateOfJoining']) && isset($experienceDetails['dateOfRelieving'])) {
                        $dateOfJoining = Carbon::createFromDate($experienceDetails['dateOfJoining']);
                        $dateOfRelieving = Carbon::createFromDate($experienceDetails['dateOfRelieving']);
                        $PriviousExp = $PriviousExp + $dateOfJoining->diffInDays($dateOfRelieving);
                    }
                }
                $dateOfJoining = Carbon::createFromDate($value['joiningDate']);
                $now = Carbon::now();
                $currentExp = $dateOfJoining->diffInDays($now);
                $totaldays = $PriviousExp + $currentExp;
                $years = ($totaldays / 365); // days / 365 days
                $years = floor($years); // Remove all decimals
                $month = ($totaldays % 365) / 30.5; // I choose 30.5 for Month (30,31) ;)
                $month = floor($month); // Remove all decimals
                $pendingRequest['resource']->experience = $years . " years " . $month . " months";
                $pendingRequest['resource']->keka_rm = $firstName . " " . $lastName;
                $pendingRequest['resource']->keka_rm_email = isset($value['reportsTo']['email']) ? $value['reportsTo']['email'] : '';
                return $pendingRequest;
            }
        }
    }

    // show all users in project
    public function manageProjectReporting(Request $request, $projectId)
    {
        $project = Project::with('allBookings', 'ProjectUsers')->where('uuid', $projectId)->first();
        $allBookings = isset($project['allBookings']) ? $project['allBookings'] : [];
        $projectUsers = isset($project['ProjectUsers']) ? $project['ProjectUsers'] : [];
        $users = $this->getAllProjectResource($allBookings, $projectUsers);
        $result = Helpers::getKekaData();
        $rmApprovalIds = [
            config('constant.RM_APPROVAL.pending'),
            config('constant.RM_APPROVAL.approved'),
            config('constant.RM_APPROVAL.decline')
        ];
        $reportingManagers = ReportingManager::with('resource', 'ActiveResourceManager', 'RequestedResourceManager')
            ->select('id', 'uuid', 'project_id', 'resource_id', 'active_rm_id', 'requested_rm_id', 'is_approved', 'created_by')
            ->where('project_id', $projectId)
            ->whereIn('is_approved', $rmApprovalIds)
            ->orderBy('id', 'desc')->get();
        $managers = User::select(
            'id',
            DB::raw("CONCAT(firstname,' ',lastname) as display_name"),
            DB::raw("(select address from email_addresses where users.id  =   user_id) as email")
        )
            ->where('status', config('constant.REDMINE_USERSTATUS')['activeUser'])
            ->where('type', config('constant.REDMINE_USERSTATUS')['userType'])->get();
        $currentUserId = $request->user->id;
        $globalDepartment = null;
        $userRole = Helpers::getRole($currentUserId);
        $data = [];
        $trimDepartments = [];
        if (in_array(Helpers::getRoleIdByCode(config('constant.ROLES.bu_head')), $userRole['global'])) {
            $globalDepartment = Department::whereIn('id', $userRole['department'])->pluck('name')->toArray();
            foreach ($globalDepartment as $dept) {
                $trimDepartments[] = Helpers::cleanAll($dept);
            }
        }
        $userIds = [];
        foreach ($users as $user) {
            if (!in_array($user->id, $userIds)) {
                if ($this->mapResourceRMData($user, $managers, $result, $reportingManagers)) {
                    $data[] = $this->mapResourceRMData($user, $managers, $result, $reportingManagers);
                }
                $userIds[] = $user->id;
            }
        }
        return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $data);
    }

    public function mapResourceRMData($user, $managers, $result, $reportingManagers)
    {
        foreach ($result as $key => $value) {
            $firstName = isset($value['reportsTo']['firstName']) ? $value['reportsTo']['firstName'] : '';
            $lastName = isset($value['reportsTo']['lastName']) ? $value['reportsTo']['lastName'] : '';
            $value['reportsTo']['email'] = isset($value['reportsTo']['email']) ? $value['reportsTo']['email'] : '';
            if (isset($value['employeeNumber']) && $value['email']) {
                if (
                    trim($value['employeeNumber']) == trim($user->employee_id) ||
                    trim($value['email']) == trim($user->email)
                ) {
                    foreach ($reportingManagers as $reportingManager) {
                        if ($user->id == $reportingManager->resource_id) {
                            $reportingManagerData = $reportingManager;
                            break;
                        }
                    }
                    if (isset($reportingManagerData)) {
                        if ($reportingManagerData->is_approved == config('constant.RM_APPROVAL.pending')) {
                            //BU Head Approval Pending
                            $user->current_rm = isset($reportingManagerData['ActiveResourceManager']) ? $reportingManagerData['ActiveResourceManager'] : null;
                            $user->status = 'BU Head Approval Pending';
                            $user->status_meg_id = config('constant.RM_STATUS.bu_head_approval_pending');
                            $user->requested_rm = isset($reportingManagerData['RequestedResourceManager']) ? $reportingManagerData['RequestedResourceManager'] : null;
                            $user->keka_rm = $firstName . " " . $lastName;
                            $user->keka_rm_email = isset($value['reportsTo']['email']) ? $value['reportsTo']['email'] : '';
                            return $user;
                        }
                        if ($reportingManagerData->is_approved == config('constant.RM_APPROVAL.approved')) {
                            //Accept On BU if yes check for KEKA  (KEKA Mapping Pending/ Approved On Keka)
                            if (isset($reportingManagerData['ActiveResourceManager']->email)) {

                                if (trim($value['reportsTo']['email']) == trim($reportingManagerData['ActiveResourceManager']->email)) {
                                    $user->current_rm = $reportingManagerData['ActiveResourceManager'];
                                    $user->status = 'Approved';
                                    $user->status_meg_id = config('constant.RM_STATUS.approved_on_keka');
                                    $user->requested_rm = null;
                                    $user->keka_rm = $firstName . " " . $lastName;
                                    $user->keka_rm_email = $value['reportsTo']['email'];
                                    return $user;
                                } else {
                                    $user->current_rm = isset($reportingManagerData['ActiveResourceManager']) ? $reportingManagerData['ActiveResourceManager'] : null;
                                    $user->status = 'Keka Mapping Pending';
                                    $user->status_meg_id = config('constant.RM_STATUS.mapping_pending_on_keka');
                                    $user->requested_rm = $reportingManagerData['RequestedResourceManager'];
                                    $user->keka_rm = $firstName . " " . $lastName;
                                    $user->keka_rm_email = $value['reportsTo']['email'];
                                    return $user;
                                }
                            } else {
                                return $this->mapKekaRM($user, $value, $managers, $firstName, $lastName);
                            }
                        }
                        if ($reportingManagerData->is_approved == config('constant.RM_APPROVAL.decline')) {
                            //Decline
                            $user->current_rm = isset($reportingManagerData['ActiveResourceManager']) ? $reportingManagerData['ActiveResourceManager'] : null;
                            $user->status = 'Decline';
                            $user->status_meg_id = config('constant.RM_STATUS.decline');
                            $user->requested_rm = isset($reportingManagerData['RequestedResourceManager']) ? $reportingManagerData['RequestedResourceManager'] : null;
                            $user->keka_rm = $firstName . " " . $lastName;
                            $user->keka_rm_email = $value['reportsTo']['email'];
                            return $user;
                        }
                    } else {
                        return $this->mapKekaRM($user, $value, $managers, $firstName, $lastName);
                    }
                }
            }
        }
        //        return $user;
    }

    public function mapKekaRM($user, $value, $managers, $firstName, $lastName)
    {
        foreach ($managers as $manager) {
            //No Record on PMO Using KEKA RM  (Approved)
            if (
                trim($value['reportsTo']['email']) == trim($manager->email) ||
                (trim($value['reportsTo']['email']) == config('constant.EXCEPTION_EMAILS_KEKA.sid') &&
                    trim($manager->email) == config('constant.EXCEPTION_EMAILS_REDMINE.sid'))
            ) {
                $user->current_rm = $manager;
                $user->status = 'Approved';
                $user->status_meg_id = config('constant.RM_STATUS.approved_on_keka');
                $user->requested_rm = null;
                $user->keka_rm = $firstName . " " . $lastName;
                $user->keka_rm_email = $value['reportsTo']['email'];
                return $user;
            }
        }
    }

    //request reporting
    public function reportingRequest(Request $request)
    {
        $this->validate($request, self::$validationRules);
        //check current project role AM/PM
        $responce = false;
        $data = [];
        $requestData = $request->toArray();
        $projectId = $requestData['project_id'];
        $userId = $request->user->id;
        try {
            foreach ($requestData['resource_data'] as $user) {
                $record = [
                    'uuid' => (string) Uuid::generate(4),
                    'project_id' => $projectId,
                    'dept_id' => $user['dept_id'],
                    'resource_id' =>  $user['resource_id'],
                    'active_rm_id' => $user['active_rm_id'],
                    'requested_rm_id' => $user['requested_rm_id'],
                    'is_approved' => config('constant.RM_APPROVAL.pending'),
                    'created_by' => $userId,
                    'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                    'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
                ];
                $data[] = $record;
                $resourceIds[] = $user['resource_id'];
            }
            if (isset($resourceIds) && count($resourceIds) > 0) {
                $responce = ReportingManager::whereIn('resource_id', $resourceIds)
                    ->where('is_approved', config('constant.RM_APPROVAL.pending'))
                    ->where('project_id', $projectId)->delete();
                $responce = ReportingManager::insert($data);
            }
            $ids = [];
            foreach ($data as $id) {
                if (isset($id['uuid'])) {
                    $ids[] = $id['uuid'];
                }
            }
            $pendingRequests = ReportingManager::with('resource', 'ActiveResourceManager', 'RequestedResourceManager', 'CreatedBy', 'UpdatedBy')->whereIn('uuid', $ids)->get();
            $selectedArray = [];
            foreach ($pendingRequests as $pendingRequest) {
                $selectedArray[$pendingRequest->dept_id][] = [
                    'resource_name' => $pendingRequest['resource']->display_name,
                    'resource_email' => $pendingRequest['resource']->email,
                    'department' => \Helpers::getDepartmentNameByID($pendingRequest->dept_id),
                    'resource_employee_number' => $pendingRequest['resource']->employee_id,
                    'requested_manager_name' => $pendingRequest['RequestedResourceManager']->display_name,
                    'active_manager_name' => $pendingRequest['ActiveResourceManager']->display_name,
                ];
            }
            $val = config('constant.TEMPLATES.reporting_manager_change_request');

            foreach ($selectedArray as $key => $records) {
                $dept = [];
                $dept[] = $key;
                $mailService = new MailService($val, $projectId, $selectedArray[$key], $dept, [], $userId);
                $mailService->sendMail();
            }
            Log::info(Helpers::addToLog($projectId, $request, $pendingRequests, config('constant.LOG_ACTIONS.reporting_request')));
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusCreated'), $responce);
        } catch (\Exception $e) {
            Log::error(Helpers::addToLog($projectId, $request, $e->getMessage(), config('constant.LOG_ACTIONS.reporting_request')));
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }


    //accept/decline reporting
    public function approvalReporting(Request $request)
    {
        $this->validate($request, self::$approvalValidationRules);
        //check current project role AM/PM
        $responce = false;
        $result = Helpers::getKekaData();
        $requestData = $request->toArray();
        $userId = $request->user->id;
        $approvedRequests = [];
        $declinedRequests = [];
        try {
            if ($requestData['is_approved'] == true) {
                foreach ($requestData['resource_data'] as $id) {
                    $recordIds[] = $id['resource_id'];
                }
                if (isset($recordIds)) {
                    $oldManager = ReportingManager::whereIn('resource_id', $recordIds)
                        ->where('is_approved', config('constant.RM_APPROVAL.approved'))
                        ->update(['is_approved' => config('constant.RM_APPROVAL.deActive')]);
                }
                foreach ($requestData['resource_data'] as $data) {
                    $reportingRequest = ReportingManager::with('resource', 'ActiveResourceManager', 'RequestedResourceManager', 'CreatedBy', 'UpdatedBy')
                        ->where('uuid', $data['uuid'])->first();
                    $record = [
                        'is_approved' => config('constant.RM_APPROVAL.approved'),
                        'active_rm_id' => $data['requested_rm_id'],
                        'updated_by' => $userId,
                    ];
                    $approvedRequest = tap($reportingRequest)->update($record);
                    $approvedRequests[] = $approvedRequest;
                }
                $declinedRequests = ReportingManager::whereIn('resource_id', $recordIds)
                    ->where('is_approved', config('constant.RM_APPROVAL.pending'))
                    ->get();
                $responce = ReportingManager::whereIn('resource_id', $recordIds)
                    ->where('is_approved', config('constant.RM_APPROVAL.pending'))
                    ->update(['is_approved' => config('constant.RM_APPROVAL.decline')]);
            } else {
                foreach ($requestData['resource_data'] as $data) {
                    $recordIds[] = $data['uuid'];
                }
                if (isset($recordIds)) {
                    $declinedRequests = ReportingManager::whereIn('uuid', $recordIds)
                        ->where('is_approved', config('constant.RM_APPROVAL.pending'))
                        ->get();
                    $responce = ReportingManager::whereIn('uuid', $recordIds)
                        ->update(['is_approved' => config('constant.RM_APPROVAL.decline')]);
                }
            }
            // mail code
            if (isset($approvedRequests) && count($approvedRequests) > 0) {
                $selectedApprovedArray = [];
                foreach ($approvedRequests as $value) {
                    $lastRmName = '';
                    $lastRMEmail = null;
                    foreach ($result as $kekaValue) {
                        if (
                            trim($kekaValue['employeeNumber']) == trim($value['resource']->employee_id) ||
                            trim($kekaValue['email']) == trim($value['resource']->email)
                        ) {
                            $lastRMEmail = $kekaValue['reportsTo']['email'];
                            $lastRmName = $kekaValue['reportsTo']['firstName'] . ' ' . $kekaValue['reportsTo']['lastName'];
                            break;
                        }
                    }
                    $selectedApprovedArray[$value->project_id]['data'][] = [
                        'resource_name' => $value['resource']->display_name,
                        'resource_email' => $value['resource']->email,
                        'department' => \Helpers::getDepartmentNameByID($value->dept_id),
                        'resource_employee_number' => $value['resource']->employee_id,
                        'requested_manager_name' => $value['RequestedResourceManager']->display_name,
                        'active_manager_name' => $lastRmName,
                    ];
                    $selectedApprovedArray[$value->project_id]['dept'][] = $value->dept_id;
                    $selectedApprovedArray[$value->project_id]['lastReportingManagerEmails'][] = $lastRMEmail;
                }
                $val = config('constant.TEMPLATES.reporting_manager_approval');
                foreach ($selectedApprovedArray as $key => $records) {
                    $projectId = $key;
                    $selectedArray = $records['data'];
                    $dept[] = $records['dept'];
                    $lastRMEmails = $records['lastReportingManagerEmails'];
                    $mailService = new MailService($val, $projectId, $selectedArray, $dept, $lastRMEmails, $userId);
                    $mailService->sendMail();
                }
                Log::info(Helpers::addToLog('', $request, $approvedRequests, config('constant.LOG_ACTIONS.approval_reporting')));
            }
            if (isset($declinedRequests) && count($declinedRequests) > 0) {
                $selectedDeclinedArray = [];
                foreach ($declinedRequests as $value) {
                    $selectedDeclinedArray[$value->project_id]['data'][] = [
                        'resource_name' => $value['resource']->display_name,
                        'resource_email' => $value['resource']->email,
                        'department' => \Helpers::getDepartmentNameByID($value->dept_id),
                        'resource_employee_number' => $value['resource']->employee_id,
                        'requested_manager_name' => $value['RequestedResourceManager']->display_name,
                        'active_manager_name' => $value['ActiveResourceManager']->display_name,
                    ];
                    $selectedDeclinedArray[$value->project_id]['dept'][] = $value->dept_id;
                }
                $val = config('constant.TEMPLATES.reporting_manager_decline');
                foreach ($selectedDeclinedArray as $key => $records) {
                    $projectId = $key;
                    $selectedArray = $records['data'];
                    $dept[] = $records['dept'];
                    $mailService = new MailService($val, $projectId, $selectedArray, $dept, [], $userId);
                    $mailService->sendMail();
                }
                Log::info(Helpers::addToLog('', $request, $declinedRequests, config('constant.LOG_ACTIONS.decline_reporting')));
            }
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $responce);
        } catch (\Exception $e) {
            Log::error(Helpers::addToLog('', $request, $e->getMessage(), config('constant.LOG_ACTIONS.approval_reporting')));
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    //direct change reporting for bu_head
    public function directChangeReporting(Request $request)
    {
        $this->validate($request, self::$directReportingValidationRules);
        $data = [];
        $result = Helpers::getKekaData();
        $requestData = $request->toArray();
        $userId = $request->user->id;
        $lastRMIds = [];
        $lastRMEmails = [];
        $curentRMEmails = [];
        try {
            foreach ($requestData['resource_data'] as $id) {
                $recordIds[] = $id['resource_id'];
            }
            if (isset($recordIds)) {
                $oldManager = ReportingManager::whereIn('resource_id', $recordIds)
                    ->where('is_approved', config('constant.RM_APPROVAL.approved'))
                    ->update(['is_approved' => config('constant.RM_APPROVAL.deActive')]);
            }
            foreach ($requestData['resource_data'] as $user) {
                $record = [
                    'uuid' => (string) Uuid::generate(4),
                    'dept_id' => $user['dept_id'],
                    'resource_id' =>  $user['resource_id'],
                    'requested_rm_id' => $user['requested_rm_id'],
                    'active_rm_id' => $user['requested_rm_id'],
                    'is_approved' => config('constant.RM_APPROVAL.approved'),
                    'created_by' => $userId,
                    'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                    'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
                ];
                $data[] = $record;
            }
            $responce = ReportingManager::insert($data);
            if (isset($recordIds)) {
                $declinedRequests = ReportingManager::whereIn('resource_id', $recordIds)
                    ->where('is_approved', config('constant.RM_APPROVAL.pending'))
                    ->get();
                $oldRequest = ReportingManager::whereIn('resource_id', $recordIds)
                    ->where('is_approved', config('constant.RM_APPROVAL.pending'))
                    ->update(['is_approved' => config('constant.RM_APPROVAL.decline')]);
            }
            $ids = [];
            foreach ($data as $id) {
                if (isset($id['uuid'])) {
                    $ids[] = $id['uuid'];
                }
            }
            $changedRecords = ReportingManager::with('resource', 'ActiveResourceManager', 'RequestedResourceManager', 'CreatedBy', 'UpdatedBy')
                ->whereIn('uuid', $ids)->get();
            if (isset($changedRecords) && count($changedRecords) > 0) {
                $selectedArray = [];
                foreach ($changedRecords as $value) {
                    $lastRmName = '';
                    foreach ($result as $kekaValue) {
                        if (
                            trim($kekaValue['employeeNumber']) == trim($value['resource']->employee_id) ||
                            trim($kekaValue['email']) == trim($value['resource']->email)
                        ) {
                            $lastRMEmails[] = $kekaValue['reportsTo']['email'];
                            $lastRmName = $kekaValue['reportsTo']['firstName'] . ' ' . $kekaValue['reportsTo']['lastName'];
                            break;
                        }
                    }
                    $selectedArray[] = [
                        'resource_name' => $value['resource']->display_name,
                        'resource_email' => $value['resource']->email,
                        'department' => \Helpers::getDepartmentNameByID($value->dept_id),
                        'resource_employee_number' => $value['resource']->employee_id,
                        'requested_manager_name' => $value['RequestedResourceManager']->display_name,
                        'active_manager_name' => $lastRmName,
                    ];
                    $dept[] = $value->dept_id;
                    $curentRMEmails[] = $value['ActiveResourceManager']->email;
                }
                $val = config('constant.TEMPLATES.reporting_manager_changes');
                $allRMEmails = array_merge($curentRMEmails, $lastRMEmails);
                $dept[] = $dept;
                $mailService = new MailService($val, '', $selectedArray, $dept, $allRMEmails, $userId);
                $mailService->sendMail();
            }

            if (isset($declinedRequests) && count($declinedRequests) > 0) {
                $selectedDeclinedArray = [];
                foreach ($declinedRequests as $value) {
                    $selectedDeclinedArray[$value->project_id]['data'][] = [
                        'resource_name' => $value['resource']->display_name,
                        'resource_email' => $value['resource']->email,
                        'department' => \Helpers::getDepartmentNameByID($value->dept_id),
                        'resource_employee_number' => $value['resource']->employee_id,
                        'requested_manager_name' => $value['RequestedResourceManager']->display_name,
                        'active_manager_name' => $value['ActiveResourceManager']->display_name,
                    ];
                    $selectedDeclinedArray[$value->project_id]['dept'][] = $value->dept_id;
                }
                $val = config('constant.TEMPLATES.reporting_manager_decline');
                foreach ($selectedDeclinedArray as $key => $records) {
                    $projectId = $key;
                    $selectedArray = $records['data'];
                    $dept[] = $records['dept'];
                    $mailService = new MailService($val, $projectId, $selectedArray, $dept, [], $userId);
                    $mailService->sendMail();
                }
            }
            Log::info(Helpers::addToLog('', $request, $changedRecords, config('constant.LOG_ACTIONS.direct_change_reporting')));
            Log::info(Helpers::addToLog('', $request, $declinedRequests, config('constant.LOG_ACTIONS.direct_change_reporting_decline')));
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusCreated'), $responce);
        } catch (\Exception $e) {
            Log::error(Helpers::addToLog('', $request, $e->getMessage(), config('constant.LOG_ACTIONS.direct_change_reporting')));
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    // RM maintenance Script
    public function updateActiveRM(Request $request)
    {
        $email = $request->email;
        $result = Helpers::getKekaData();
        foreach ($result as $kekaData) {
            if (trim($email) == trim($kekaData['email'])) {
                $reportsEmail = $kekaData['reportsTo']['email'];
                $user_data = LocalUser::where('email', $email)->first();
                $reports_data = LocalUser::where('email', $reportsEmail)->first();
                if ($reports_data) {
                    $user_id = $reports_data['user_id'];
                    if (ReportingManager::where('resource_id', $user_data['user_id'])->update(['active_rm_id' => $user_id])) {
                        return 'Success';
                    } else {
                        return 'Something went wrong..!';
                    }
                } else {
                    return $reportsEmail . ': user not exist in db';
                }
            }
        }
    }
}
