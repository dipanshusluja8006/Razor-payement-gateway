<?php

namespace App\Http\Controllers\Resource;

use App\Http\Controllers\Controller;
use App\Models\Technology;
use Illuminate\Http\Request;
use ApiResponse;
use Helpers;

class TechnologyController extends Controller
{
    public static $technologyValidationRoles = [
        'name' => 'required',
    ];

    public static $technologyUpdateValidationRoles = [
        'name' => 'required',
        'delete' => 'required',
    ];

    public function index()
    {
        try {
                $technologies = Technology::orderBy('name', 'ASC')->get();
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $technologies);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function create(Request $request)
    {
        $this->validate($request, self::$technologyValidationRoles);
        $data = $request->toArray();
        try {
            $code = Helpers::clean($data['name']);
            $tech = Technology::where('name', $data['name'])->first();
            if (!isset($tech)) {
                $technology_data = [
                    'code' => $code,
                    'name' => $data['name'],
                ];
                $technology = new Technology($technology_data);
                $technology->save();
                return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusCreated'), $technology);
            } else {
                return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusForbidden'), '', 'Record Already Exists');
            }
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function update(Request $request, $id)
    {
        $this->validate($request, self::$technologyUpdateValidationRoles);
        $data = $request->toArray();
        try {
            $tech = Technology::where('id', $id)->first();
            if (isset($tech)) {
                if ($data['delete']) {
                    Technology::where('id', $id)->delete();
                } else {
                    Technology::where('id', $id)->update(['name' => $data['name']]);
                }
                return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), '', 'Record Updated');
            } else {
                return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', 'Id does not exist');
            }
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }
}
