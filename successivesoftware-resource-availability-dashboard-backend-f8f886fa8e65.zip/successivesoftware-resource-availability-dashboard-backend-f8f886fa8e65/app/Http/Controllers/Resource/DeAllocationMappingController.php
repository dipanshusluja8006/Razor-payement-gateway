<?php

namespace App\Http\Controllers\Resource;

use App\Libraries\MailService;
use App\Models\DeAllocationMapping;
use App\Models\Project;
use App\Models\ProjectAction;
use App\Models\PerformedActionLog;
use App\Models\ReportingManager;
use App\Models\UserRole;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Carbon\Carbon;
use Helpers;
use ApiResponse;
use Log;
use Webpatser\Uuid\Uuid;
use App\Traits\ResourceControllerTraits;
use App\ResourceBooking;

class DeAllocationMappingController extends Controller
{
    use ResourceControllerTraits;
    protected $helpers;

    public function __construct(Helpers $helpers)
    {
        $this->helpers = $helpers;
    }

    public static $validationRules = [
        'de_allocation_map_data' => 'required|array',
        'de_allocation_map_data.*.de_allocation_map_id' => 'required|exists:resource_mysql.de_allocation_mappings,uuid',
        'de_allocation_map_data.*.status' => 'required',
        'project_id' => 'required|exists:resource_mysql.projects,uuid',
    ];

    /**
     *
     * @OA\Get(
     *     path="/v1/de-allocation-map/{uuid}",
     *     operationId="/v1/de-allocation-map/{uuid}",
     *     summary="Fetch Resource De Allocation Map",
     *     tags={"Resource-De-Mapping"},
     *     @OA\Parameter(
     *         name="projectId",
     *         in="path",
     *         description="Project UUID",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\Response(
     *         response="200",
     *         description="Returns deallocation-map Detail",
     *         @OA\JsonContent()
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     *
     * @param type $projectId
     * @return \Illuminate\Http\JsonResponse
     */

    public function showDeAllocated(Request $request,$uuid)
    {
        try{
        $project = Project::where('uuid', $uuid)
            ->with('DeAllocationMapping')
            ->first();
        $project_name = $project['project_name'];
        $redmineProjectID = $project['redmine_project_id'];
        if($redmineProjectID == null || $redmineProjectID == '') {
            $redmineProjectID = Helpers::projectIDRedmine($project_name);
        }
        //$redmineProjectID = Helpers::projectIDRedmine($project_name);
        /*$redmineProjectID = '';
            if(isset($project['redmine_project_id'])){
                $redmineProjectID = $project['redmine_project_id'];
            }else{
                $redmineProjectID = Helpers::projectIDRedmine($project_name);
        }*/
        $project_exist_redmine=false;
        if(isset($redmineProjectID)){
        $project_exist_redmine=true;
        }
        $project->project_exist_redmine = $project_exist_redmine;
        return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'),$project);
    }catch(\Exception $e ) {
        return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'),'',$e->getMessage());
       }
    }
    /**
     * @OA\Put(
     *     path="/v1/de-allocation-map",
     *     summary="De Map Resource",
     *     operationId="/de-allocation-map",
     *     tags={"Resource-De-Mapping"},
     *     @OA\RequestBody(
     *         required=true,
     *         description="Post object",
     *         @OA\JsonContent(ref="#/components/schemas/ResourceDeMapResource")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="A post",
     *         @OA\JsonContent(),
     *     ),
     *     @OA\Response(
     *         response="default",
     *         description="unexpected error",
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     */

    public function mapDeAllocated(Request $request, $status = 0)
    {
        $this->validate($request, self::$validationRules);
        try{
            $currentUserId = $request->user->id;
            $unMapData = $request->toArray();
            $alldeAllocationMappingData = [];
            $departmentArray = [];
            $resourceIdArray = [];
            $projectData = Project::where('uuid', $request['project_id'])->first();
            $projectName = $projectData->project_name;
            $redmineProjectID = $projectData['redmine_project_id'];
            if($redmineProjectID == null || $redmineProjectID == '') {
                $redmineProjectID = Helpers::projectIDRedmine($projectName);
            }
            foreach ($unMapData['de_allocation_map_data'] as $key => $map_datum) {
                $deAllocationMapping = DeAllocationMapping::where('uuid', $map_datum['de_allocation_map_id'])->with('resourceAllocation', 'resource')->first();
                $department = $deAllocationMapping['resourceAllocation']['resourceRequisition']['dept_id'];
                if (!in_array($department, $departmentArray)) {
                    array_push($departmentArray, $department);
                }
            if(!in_array($deAllocationMapping->resource_id, $resourceIdArray)){
                $alldeAllocationMappingData[] = $deAllocationMapping;
                $resourceIdArray[] = $deAllocationMapping->resource_id;
            }
                DeAllocationMapping::where('uuid', $map_datum['de_allocation_map_id'])->update(array('status' => $map_datum['status']));
                $hours_per_day = $map_datum['efforts'];
                $start_date = Carbon::parse($map_datum['start_date'])->format('Y-m-d');
                $end_date = Carbon::parse($map_datum['end_date'])->format('Y-m-d');
                $bookingID = ResourceBooking::where(
                    'project_id',$redmineProjectID)
                ->where('assigned_to_id',$deAllocationMapping->resource_id)
                ->whereDate('start_date',$start_date)
                ->whereDate('end_date',$end_date)
                ->where('hours_per_day',$hours_per_day)->pluck('id')->first();

                $bookingQueryArray=[
                'project_id'=>$redmineProjectID,
                'hours_per_day'=>$hours_per_day,
                'assigned_to_id'=>$deAllocationMapping->resource_id,
                'start_date'=>$start_date,
                'end_date'=>$end_date,
                'bookingID'=>$bookingID
               ];
              Log::info(['Booking_Query_Data_Unmapping', json_encode($bookingQueryArray)]);
            if($bookingID){
                ResourceBooking::updateResourceBooking($bookingID,$currentUserId,$map_datum);
            }
            }
            PerformedActionLog::where(['project_id' => $request['project_id'], 'user_action_id' => 9])->update(['status' => '1']);
            PerformedActionLog::storePerformedActionLog($request['project_id'], 10, config('constant.PERFORM_ACTIONLOG.completed'));
            //here on deallocation rm change code
            // $buHeads = Helpers::getAllBUHeads();
            // $result = Helpers::getKekaData();
            // $project = Helpers::getProjectAllCurrentBookings($request['project_id']);
            // $currentBookings = isset($project['currentBookings']) ? $project['currentBookings'] : [];
            // $ProjectUsers =  isset($project['ProjectUsers']) ? $project['ProjectUsers'] : [];
            // $allProjectResource = $this->getAllProjectResource($currentBookings, $ProjectUsers);
            // $allData = $this->updateResourceManagersOfDeallocatedResources($alldeAllocationMappingData, $result, $buHeads, $project, $allProjectResource);
            // $AllDataForUpdate = [];
            // $AllResourceIdForUpdate = [];
            // foreach ($allData['data'] as $resource){
            //     if(!in_array($resource->resource_id, $allData['allBuHeadAssignedArray']) && in_array($resource->resource_id, $allData['allAMPMAssignedArray'])){
            //         $AllDataForUpdate[] = $resource;
            //         $AllResourceIdForUpdate[] = $resource->resource_id;
            //     }
            // }
            // $this->updateReportingManager($AllDataForUpdate, $AllResourceIdForUpdate, $request['project_id'], $currentUserId);
            //for mail
            if($status){
                Log::info($this->helpers->addToLog($request['project_id'],$request,$unMapData['de_allocation_map_data'],config('constant.LOG_ACTIONS.resource_unmapping')));
                $this->helpers->addlogActivityDB($request['project_id'],$request,$unMapData['de_allocation_map_data'],config('constant.LOG_ACTIONS.resource_unmapping'));
                return 1;
            } else {
            $mailArray=[config('constant.TEMPLATES.de_allocation_mapping')];
            foreach($mailArray as $val){
                $mailService = new MailService($val, $request['project_id'],[],$departmentArray);
                $mailService->sendMail();
            }
            Log::info($this->helpers->addToLog($request['project_id'],$request,$unMapData['de_allocation_map_data'],config('constant.LOG_ACTIONS.resource_unmapping')));
            $this->helpers->addlogActivityDB($request['project_id'],$request,$unMapData['de_allocation_map_data'],config('constant.LOG_ACTIONS.resource_unmapping'));
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'));
        }
        }catch (\Exception $e) {
            Log::error($this->helpers->addToLog($request['project_id'],$request,$e->getMessage(),config('constant.LOG_ACTIONS.resource_unmapping')));
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    function testUnmapping(){
        $redmineProjectID=487;
        $resource_id=471;
        $map_start_date="2020-09-13";
        $map_end_date="2020-09-30";
        $start_date = Carbon::parse($map_start_date)->format('Y-m-d');
        $end_date = Carbon::parse($map_end_date)->format('Y-m-d');
                //$hours_per_day = $map_datum['efforts'];

                $bookingID = ResourceBooking::where('project_id',$redmineProjectID)
                ->where('assigned_to_id',$resource_id)
                ->whereDate('start_date',$start_date)
                ->whereDate('end_date',$end_date)->pluck('id')->first();

                $bookingQueryArray=[
                'assigned_to_id'=>$resource_id,
                'start_date'=>$start_date,
                'end_date'=>$end_date,
                'bookingID'=>$bookingID
               ];
                return $bookingQueryArray;
              //Log::info(['Booking_Query_Data_Unmapping', json_encode($bookingQueryArray)]);
    }


}
