<?php

namespace App\Http\Controllers\Resource;

use App\Http\Controllers\Controller;
use App\Models\GovernanceCategory;
use ApiResponse;
use Illuminate\Support\Facades\Cache;

class GovernanceCategoryController extends Controller
{
    public function index()
    {
        try {
            if (Cache::has('governanceCategory')) {
                $governanceCategory = Cache::get('governanceCategory');
            }else {
                $governanceCategory = GovernanceCategory::all();
                Cache::put('governanceCategory', $governanceCategory, 30);
            }
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $governanceCategory);
        } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }
}
