<?php

namespace App\Http\Controllers\Resource;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\WsrActionItem;
use Webpatser\Uuid\Uuid;
use ApiResponse;

class WSRActionItemsController extends Controller
{
    public static $validationRules = [
        'project_id' => 'required|exists:resource_mysql.projects,uuid',
        'priority' =>  'required|integer|between:1,4',
        'status' =>  'required|integer|between:0,2'
    ];
    
    public function index(Request $request)
    {
        try{
        $currentUserId = $request->user->id;
        $allActionLists = WsrActionItem::with(['createdByUser','updatedByUser','projectName'])->where('assiged_user_id',$currentUserId)->get();
        return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'),$allActionLists);
        }catch(\Exception $e ) {
        return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'),'',$e->getMessage());
       }
    }

    public function assignedActionItem(Request $request)
    {
        try{
        $currentUserId = $request->user->id;
        $assignedctionLists = WsrActionItem::with(['assignedToUser','createdByUser','updatedByUser','projectName'])
        ->where('created_by',$currentUserId)->get();
        return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'),$assignedctionLists);
        }catch(\Exception $e ) {
        return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'),'',$e->getMessage());
       }
    }
    
    public function store(Request $request)
    {
        //$this->validate($request, self::$validationRules);
        try {
        $data = [
            'assiged_user_id' => $request->assiged_user_id,
            'project_id' => $request->project_id,
            'target_closure_date' => $request->target_closure_date,
            'priority' => $request->priority,
            'status' => $request->status,
            'description' => $request->description,
            'created_by' => $request->user->id,
            'updated_by' => $request->user->id
            ];
            $wsrActionItem = new WsrActionItem($data);
            $wsrActionItem->save();
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusCreated'), $wsrActionItem);
            } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    public function actionItemMarkDone(Request $request,$uuid)
    {
        try {
            $data = [
            'status' => $request->status
            ];
            $response = WsrActionItem::where('uuid', $uuid)->update($data);
            $updatedResponse = WsrActionItem::where('uuid', $uuid)->firstOrFail();
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusCreated'), $updatedResponse);
            } catch (\Exception $e) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }


}
