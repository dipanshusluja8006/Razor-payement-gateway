<?php

namespace App\Http\Controllers\Resource;

use App\Http\Controllers\Controller;
use App\Models\Tag;
use Illuminate\Http\Request;
use ApiResponse;
use Helpers;

class TagController extends Controller
{
    public static $tagValidationRoles = [
        'name' => 'required',
    ];

    public static $tagIdValidationRoles = [
        'tag_id' =>  'required|exists:resource_mysql.tags,id',
    ];

    public static $updateTagValidationRoles = [
        'tag_id' =>  'required|exists:resource_mysql.tags,id',
        'name' => 'required',
    ];

    public function index()
    {
        $tags = Tag::get();
        return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'),$tags);
    }

    /**
     * @OA\Post(
     *     path="/v1/tag",
     *     summary="KEDB Tag",
     *     operationId="/v1/tag",
     *     tags={"kedb Tag"},
     *     @OA\RequestBody(
     *         required=true,
     *         description="Post object",
     *         @OA\JsonContent(ref="#/components/schemas/Tag")
     *     ),
     *     @OA\Response(
     *         response=201,
     *         description="A post",
     *         @OA\JsonContent(),
     *     ),
     *     @OA\Response(
     *         response="default",
     *         description="unexpected error",
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     *
     * @param Request $request
     * @return array
     */
    public function create(Request $request)
    {
        $this->validate($request, self::$tagValidationRoles);
        $data = $request->toArray();
        try{
            $code = Helpers::clean($data['name']);
            $tagExist = Tag::where('name', $data['name'])->first();
            if (empty($tagExist)) {
                $tag_data = [
                    'code' => $code,
                    'name' => $data['name'],
                ];
                $tag = new Tag($tag_data);
                $tag->save();
                return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusCreated'),$tag);
            } else {
                return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusForbidden'),'','Record Already Exists');
            }
        }catch(\Exception $e ) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'),'',$e->getMessage());
        }
    }

    /**
     * @OA\Put(
     *     path="/v1/tag/{id}",
     *     summary="KEDB Tag Update",
     *     operationId="/v1/tag/{id}",
     *     tags={"kedb Tag"},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="tag id",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\RequestBody(
     *         required=true,
     *         description="Post object",
     *         @OA\JsonContent(ref="#/components/schemas/TagUpdate")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="A put",
     *         @OA\JsonContent(),
     *     ),
     *     @OA\Response(
     *         response="default",
     *         description="unexpected error",
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     *
     * @param Request $request
     * @param $uuid
     * @return \Illuminate\Http\JsonResponse
     * @throws \Illuminate\Validation\ValidationException
     */
    public function update(Request $request, $id)
    {
        $request->merge(['tag_id' => $id]);
        $this->validate($request, self::$updateTagValidationRoles);
        $data = $request->toArray();
        try{
            $code = Helpers::clean($data['name']);
            $tag = Tag::where('id', $id)->update(['code' => $code, 'name' => $data['name']]);
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $tag, 'Record Updated');
        }catch(\Exception $e ) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'),'',$e->getMessage());
        }
    }

    public function destroy(Request $request, $id)
    {
        $request->merge(['tag_id' => $id]);
        $this->validate($request, self::$tagIdValidationRoles);
        try{
            Tag::destroy($id);
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), '', 'Record Destroy');
        }catch(\Exception $e ) {
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'),'',$e->getMessage());
        }
    }
}
