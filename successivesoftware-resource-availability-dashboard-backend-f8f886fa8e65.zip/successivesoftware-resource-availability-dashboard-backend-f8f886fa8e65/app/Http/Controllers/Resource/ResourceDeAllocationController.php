<?php

namespace App\Http\Controllers\Resource;

use App\Libraries\MailService;
use App\Models\DeAllocationMapping;
use App\Models\PerformedActionLog;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Project;
use App\Models\ResourceAllocation;
use App\Models\ResourceAllocationMeta;
use Helpers;
use Carbon\Carbon;
use ApiResponse;
use Log;
use App\Traits\ResourceControllerTraits;
use App\ResourceBooking;
use App\Models\LocalUser;
use App\Http\Controllers\Resource\DeAllocationMappingController;

class ResourceDeAllocationController extends Controller
{
    use ResourceControllerTraits;
    protected $helpers;

    public function __construct(Helpers $helpers)
    {
        $this->helpers = $helpers;
    }

    public static $DeAllocationValidationRules = [
        'de_allocation_data' => 'required|array',
        'de_allocation_data.*.uuid' => 'required|exists:resource_mysql.allocated_resources,uuid',
        'de_allocation_data.*.full_deallocate' => 'required',
        'de_allocation_data.*.hours' => 'required',
        'de_allocation_data.*.start_date' => 'required',
        'de_allocation_data.*.allocation_meta_uuid' => 'required|exists:resource_mysql.allocated_resources_meta,uuid',
    ];

    /**
     * @OA\Post(
     *     path="/v1/resource-deallocation",
     *     summary="Resource De-Allocate",
     *     operationId="/v1/resource-deallocation",
     *     tags={"Resource-allocation"},
     *     @OA\RequestBody(
     *         required=true,
     *         description="Post object",
     *         @OA\JsonContent(ref="#/components/schemas/ResourceDeallocate")
     *     ),
     *     @OA\Response(
     *         response=201,
     *         description="A post",
     *         @OA\JsonContent(),
     *     ),
     *     @OA\Response(
     *         response="default",
     *         description="unexpected error",
     *     ),
     *     security={
     *      {"api_key_security": {}}
     *     }
     * )
     *
     * Project Resource De-Allocation
     */
    public function deAllocate(Request $request)
    {
        $this->validate($request, self::$DeAllocationValidationRules);
        $requestData = $request->toArray();
        $templateArray = [];
        $departmentTemplateArray = [];
        $isAccess = $this->checkUserAccessForResourceAllocationOperations($request->user->id, $requestData['project_id'], config('constant.PROJECT_ACTION')['resource_de_allocation_request']);
        $template = '';
        if ($isAccess) {
            $de_allocation_data = $request->de_allocation_data;
            $return_data = [];
            $projectData = Project::where('uuid', $requestData['project_id'])->first();
            $previousStatus = $projectData->status;
            $projectName = $projectData->project_name;
            foreach ($de_allocation_data as $key => $data) {
                $resourceAllocationMetadata = ResourceAllocationMeta::where('uuid', $data['allocation_meta_uuid'])->first();
                $resourceAllocationdata = ResourceAllocation::where('uuid', $resourceAllocationMetadata['allocated_resources_uuid'])->first();
                if ($data['full_deallocate']) {
                    ResourceAllocationMeta::fullyDeallocateResource($data['uuid'], $data['allocation_meta_uuid']);
                    $isAllDeallocate = ResourceAllocationMeta::where('allocated_resources_uuid', $data['uuid'])->get();
                    if (!isset($isAllDeallocate[0])) {
                        ResourceAllocation::updateResourceAllocationTableData($data['uuid'], $request->user->id, config('constant.PROJECT_ACTION')['resource_de_allocation_response_accept']);
                    }
                    $isAllResourcesDeallocate = $this->checkIsAllResourceDeallocateInProject($requestData['project_id']);
                    if ($isAllResourcesDeallocate) {
                        $previousStatus = config('constant.PROJECT_ACTION')['resource_de_allocation_response_accept'];
                    }
                    $mailTemplate=[config('constant.TEMPLATES.de_allocation')];
                    foreach($mailTemplate as $val){
                    if (!in_array($val, $templateArray)) {
                    array_push($templateArray, $val);
                    }
                  }
                } else {
                    if (Carbon::parse($data['start_date'])->greaterThan(Carbon::parse($resourceAllocationMetadata['end_date'])) || Carbon::parse($data['start_date'])->lessThan(Carbon::parse($resourceAllocationMetadata['start_date']))) {
                        return response()->json(["message" => 'Deallocation date Validation Error', 'status' => 422], 422);
                    } else if ($resourceAllocationMetadata['hours'] < $data['hours']) {
                        return response()->json(["message" => 'Deallocated hours are greater', 'status' => 422], 422);
                    } else if (isset($resourceAllocationMetadata)) {
                        $this->distributeProjectAllocationHoursAccordingDate($resourceAllocationMetadata, $data);
                    }
                    // if($data['hours']==$resourceAllocationMetadata['hours']){
                        $mailTemplate=[config('constant.TEMPLATES.de_allocation')];
                    // }else{
                    //     $mailTemplate=[config('constant.TEMPLATES.partial_resource_deallocation')];
                    // }
                    foreach($mailTemplate as $val){
                    if (!in_array($val, $templateArray)) {
                    array_push($templateArray, $val);
                    }
                  }
                }
                $department = $this->getDepatmentIdFromAllocatedResourcesUuid($data['uuid']);
                // for insert DeAllocation Mapping record
                $data['uuid'] = $requestData['project_id'];
                $data['status'] = config('constant.PROJECT_ACTION')['resource_de_allocation_mapping'];
                $data['previous_status'] = $previousStatus;
                $data['requested_by'] = $request->user->id;
                $data['comment'] = 'deallocate';
                $this->SaveProjectAction($data);
                $status = Project::where('uuid', $requestData['project_id'])->update(array('status' => config('constant.PROJECT_ACTION')['resource_de_allocation_mapping']));
                PerformedActionLog::storePerformedActionLog($requestData['project_id'], 9, config('constant.PERFORM_ACTIONLOG.inProgress'), $department);

                DeAllocationMapping::storeDeAllocationMapping($resourceAllocationMetadata, $requestData['project_id'], $data, $request->user->id);
                if (array_key_exists($template, $departmentTemplateArray)) {
                    if (!in_array($department, $departmentTemplateArray[$template])) {
                        array_push($departmentTemplateArray[$template], $department);
                    }
                } else {
                    $departmentTemplateArray[$template] = [$department];
                }
                if($data['hours']==$resourceAllocationMetadata['hours']){
                    $data['full_deallocate']= true;
                }
                $deallocationMaildata[]=$Maildata = [
                    'full_deallocate'=> $data['full_deallocate'],
                    'resource_id' => $resourceAllocationMetadata['resource_id'],
                    'resource_name' => \Helpers::getUserName($resourceAllocationMetadata['resource_id']),
                    'employee_code' => \Helpers::getEmployeeCode($resourceAllocationMetadata['resource_id']),
                    'employee_email' => \Helpers::getUserEmail($resourceAllocationMetadata['resource_id']),
                    'dept_id'=> $department,
                    'dept'=> \Helpers::getDepartmentNameByID($department),
                    'deallocate_for' => $data['hours'],
                    'efforts' => trim($resourceAllocationMetadata['hours']),
                    'experience' => trim($resourceAllocationdata['experience']),
                    'billing_type' => $data['billing_type'],
                    'start_date' => $data['allocation_start_date'],
                    'end_date' => $resourceAllocationMetadata['end_date'],
                    'designation' => $data['role_name'],
                    'tech' => $data['tech_name'],
                    'deallocate_from' => $data['start_date'],
                    'allocation_start_date' => $data['allocation_start_date'],
                    'allocation_end_date' => $data['allocation_end_date'],
                ];
            }
            //For mail
            if (isset($templateArray[0])) {
                foreach ($templateArray as $templateCode) {
                    $mailService = new MailService($templateCode, $requestData['project_id'],$deallocationMaildata,$departmentTemplateArray[$template]);
                    $mailService->sendMail();
                }
            }
            Log::info($this->helpers->addToLog($requestData['project_id'],$request,$deallocationMaildata,config('constant.LOG_ACTIONS.resource_deallocation')));
            $this->helpers->addlogActivityDB($requestData['project_id'],$request,$deallocationMaildata,config('constant.LOG_ACTIONS.resource_deallocation'));
            $this->unMapResources($request);
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusCreated'), $return_data);
        } else {
            Log::error($this->helpers->addToLog($requestData['project_id'],$request,$e->getMessage(),config('constant.LOG_ACTIONS.resource_deallocation')));
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusUnauthorized'), '', $e->getMessage());
        }
    }

    public function distributeProjectAllocationHoursAccordingDate($resourceAllocationMetadata, $data)
    {
            $response = true;
            $startDate1 = $resourceAllocationMetadata['start_date'];
            $endDate1 = Carbon::parse($data['start_date'])->format('Y-m-d');
            $previousDay = Carbon::today()->subDays(1);
            $hours1 = $resourceAllocationMetadata['hours'];
            $startDate2 = Carbon::parse($data['start_date'])->addDays(1)->format('Y-m-d');
            $endDate2 = $resourceAllocationMetadata['end_date'];
            $hours2 = ($resourceAllocationMetadata['hours'] - $data['hours']);
            ResourceAllocationMeta::where('uuid', $resourceAllocationMetadata['uuid'])->delete();
            if (Carbon::parse($endDate1)->greaterThan(Carbon::parse($previousDay))){
                $response = ResourceAllocationMeta::storeResourceAllocationMeta($resourceAllocationMetadata['allocated_resources_uuid'], $startDate1, $endDate1, $hours1, $resourceAllocationMetadata['resource_id']);
            }
            if ($hours2 > 0) {
                $response = ResourceAllocationMeta::storeResourceAllocationMeta($resourceAllocationMetadata['allocated_resources_uuid'], $startDate2, $endDate2, $hours2, $resourceAllocationMetadata['resource_id']);
            }
            return $response;
    }
    // method to unmapped sources
    public function unMapResources($request){
        $resourceUnMapping = new DeAllocationMappingController($this->helpers);
        foreach ($request['de_allocation_data'] as $deAllocation) {
            $resource = DeAllocationMapping::where('status', 0)
                ->where('resource_id', $deAllocation['resource_id'])->where('project_id', $request['project_id'])->first();
            $resourceAllocation = ResourceAllocation::where('uuid', $deAllocation['uuid'])->select('experience', 'efforts')->first();
            $user_data = LocalUser::where('user_id', $deAllocation['resource_id'])->first(); 
            $map_data['allocation_id'] = $deAllocation['uuid'];
            $map_data['billing_type'] = $deAllocation['billing_type'];
            $map_data['de_allocation_map_id'] = $resource['uuid'];
            $map_data['deallocate_for'] = $deAllocation['hours'];
            $map_data['deallocate_from'] = $deAllocation['start_date'];
            $map_data['dept'] = $deAllocation['dept_name'];
            $map_data['designation'] = $deAllocation['role_name'];
            $map_data['efforts'] = $resource['efforts'];
            $map_data['end_date'] = $resource['end_date'];
            $map_data['experience'] = $resourceAllocation['experience'];
            $map_data['id'] = $resource['uuid'];
            $map_data['requested_by'] = $request['user']['full_name'];
            $map_data['requested_on'] = Carbon::now()->isoFormat('MMM D, YYYY');
            $map_data['resource_id'] = $deAllocation['resource_id'];
            $map_data['resource_name'] = \Helpers::getUserName($deAllocation['resource_id']);
            $map_data['start_date'] = $deAllocation['allocation_start_date'];
            $map_data['status'] = "1";
            $map_data['tech'] = $deAllocation['tech_name'];
            $request['de_allocation_map_data'] = [$map_data];
            $status = true;
            $mailData = array(
                'deallocation_date' => trim($deAllocation['start_date']),
                'deallocation_hours' => $deAllocation['hours'],
                'email' => $user_data['email']
            );
            $resourceUnMapping->mapDeAllocated($request, $status);
            $this->sendEmailToEmployee($request['project_id'], $mailData);
        } 
        return 1;
    }

    public function sendEmailToEmployee($project_id, $mailData)
    {
        $mail = config('constant.TEMPLATES.employee_de_allocation_email');
        $mailService = new MailService($mail, $project_id, $mailData);
        $mailService->sendMail();
        return 1;
    }
}
