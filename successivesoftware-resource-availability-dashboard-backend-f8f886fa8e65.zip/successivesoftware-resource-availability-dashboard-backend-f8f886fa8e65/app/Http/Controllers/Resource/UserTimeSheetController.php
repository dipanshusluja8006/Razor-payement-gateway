<?php

namespace App\Http\Controllers\Resource;

use App\Http\Controllers\Controller;
use App\ResourceBooking;
use App\Models\Department;
use App\Models\Project;
use Illuminate\Http\Request;
use DB;
use Webpatser\Uuid\Uuid;
use ApiResponse;
use Helpers;
use App\User;
use Carbon\Carbon;
use Log;
use App\Jobs\QueueJob;

class UserTimeSheetController extends Controller
{

    private static $timesheetSummaryValidation = [
        'redmine_project_ids' => 'array'
    ];

    private static $timesheetValidation = [
        'user_ids' => 'array'
    ];

    protected $helpers;
    /**
     * ProjectController constructor.
     */
    public function __construct(Helpers $helpers)
    {
        $this->helpers = $helpers;
        $this->rolesArray = Helpers::getRoleByModel('Role');
        $this->departmentArray = Helpers::getRoleByModel('Department');
    }
    /**
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function resourcesTimesheetSummary(Request $request){
        $response = $this->timesheetCommonQuery($request);
        return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $response);
    }

    /**
     * @param $request
     * @return array
     */
    private function timesheetCommonQuery(Request $request){

            $currentUserId = $request->user->id;
            $checkMapped = false;
            $pendingInitiaion = true;
            $userRole = Helpers::getRole($currentUserId);
            if(in_array($this->rolesArray[config('constant.ROLES.admin')], $userRole['global'])){
                $userRole['department'] = Department::pluck('id')->toArray();
            }
                $pmoProjects = Project::with(['resourceRequisitionAllProject' => function ($query) use ($userRole) {
                $query->whereIn('dept_id', $userRole['department']);
                }, 'ProjectRole' => function ($query) use ($currentUserId) {
                    $query->where('user_id', $currentUserId);
                }
            ])
                ->orderBy('created_at', 'desc')
                ->get();
             $pmoProjects = $this->removeUnAuthorizedProjectTimesheet($pmoProjects, $currentUserId, $userRole, $checkMapped, $pendingInitiaion);
             $redmineId =[];
            foreach($pmoProjects as $key=>$projectValue){
                $redmineId[]=$projectValue->redmine_project_id;
            }
        $projectIds = array_filter($redmineId, function($value) { return !is_null($value) && $value !== ''; });
        $projectIdsString = implode(",", $projectIds);
        $currentDay = Carbon::now()->format('D');
        if($currentDay=='Sun'){
           $startDate = Carbon::now()->subDay(6)->format('Y-m-d');
           $endDate = Carbon::now()->subDay(2)->format('Y-m-d');
        }elseif($currentDay=='Mon'){
             $startDate = Carbon::now()->format('Y-m-d');
             $endDate = Carbon::now()->addDay(4)->format('Y-m-d');
         }elseif($currentDay=='Tue'){
            $startDate = Carbon::now()->subDay(1)->format('Y-m-d');
            $endDate = Carbon::now()->addDay(3)->format('Y-m-d');
        }elseif($currentDay=='Wed'){
            $startDate = Carbon::now()->subDay(2)->format('Y-m-d');
            $endDate = Carbon::now()->addDay(2)->format('Y-m-d');
        }elseif($currentDay=='Thu'){
            $startDate = Carbon::now()->subDay(3)->format('Y-m-d');
            $endDate = Carbon::now()->addDay(1)->format('Y-m-d');
        }elseif($currentDay=='Fri'){
            $startDate = Carbon::now()->subDay(4)->format('Y-m-d');
            $endDate = Carbon::now()->format('Y-m-d');
        }elseif($currentDay=='Sat'){
            $startDate = Carbon::now()->subDay(5)->format('Y-m-d');
            $endDate = Carbon::now()->subDay(1)->format('Y-m-d');
        }
        
        $data= DB::connection('redmine_db_mysql')->select(DB::raw(
            "SELECT
            projects.id AS projectsID,
            projects.name  `ProjectName`,users.id `UsersId`,
            TRIM(CONCAT(firstname, ' ', lastname)) `EmployeeName`,
            (SELECT VALUE FROM custom_values WHERE customized_id=`time_entries`.`user_id` AND custom_field_id=15)  AS  `EmployeeCode`,
            SUM(hours)  AS `Hours`,spent_on AS `SpentDate`
                FROM time_entries
            INNER JOIN `users` ON users.id = `time_entries`.`user_id`
            INNER JOIN `projects` ON projects.id = `time_entries`.`project_id`
            WHERE spent_on  BETWEEN '$startDate' AND '$endDate' AND projects.id IN($projectIdsString)
            GROUP BY `user_id`, `SpentDate`
            ORDER BY `ProjectName`,`EmployeeName`"));
        $data = collect($data)->toArray();
        $response = array(
            'Approved' => [],
            'Pending' =>[],
        );
        $pendingIds = [];
        $approvedIds = [];
        $response['Approved']['statusCount'] = 0;
        $response['Pending']['statusCount'] = 0;
        foreach($data as $keyId => $rows){
            if(round($rows->Hours) >=8){
                $projectInfo = $this->getUserProjects($rows->UsersId,$rows->SpentDate);
                $rows->projectInfo = $projectInfo;
                $approvedIds[] = $rows->Hours;
                $response['Approved']['statusCount'] = count($approvedIds);
                $response['Approved']['resource'][] = $rows;
            }else{
                $projectInfo = $this->getUserProjects($rows->UsersId,$rows->SpentDate);
                $rows->projectInfo = $projectInfo;
                $pendingIds[] = $rows->Hours;
                $response['Pending']['statusCount'] = count($pendingIds);
                $response['Pending']['resource'][] = $rows;
            }
        }
        return $response;
    }
    private function getUserProjects($userID,$spentOn){
    $data= DB::connection('redmine_db_mysql')->select(DB::raw(
        "SELECT projects.id AS projectsID,
        projects.name  `ProjectName`,SUM(hours) AS `Hours`,
        time_entries.user_id `UserID`,spent_on AS `SpentDate`
        FROM time_entries
        INNER JOIN `projects` ON projects.id = `time_entries`.`project_id`
        WHERE time_entries.spent_on  ='$spentOn'  AND  time_entries.user_id =$userID
        GROUP BY projectsID, SpentDate"));
        return $data = collect($data)->toArray();
    }

    public function timesheetSendReminder(Request $request)
    {
        try{
            $this->validate($request, self::$timesheetValidation);
            $userIds = $request->user_ids;
            $userIds = array_filter($userIds, function($value) { return !is_null($value) && $value !== ''; });
            $userData = User::with('emailAddresse')
                ->whereIn('id', $userIds)
                ->where('status', config('constant.REDMINE_USERSTATUS.activeUser'))
                ->select('id', 'status', 'firstname', 'lastname', DB::raw("CONCAT(firstname,' ',lastname) as display_name"))
                ->get();

            $mailData = \Helpers::getTemplateByCode(config('constant.TEMPLATES.time_sheet_reminder_email'));

            foreach ($userData as $value){
                if(isset($value['emailAddresse']->address) && $value['emailAddresse']->address != null){
                    $finalMailData =[];
                    $mail=[];
                    $blackListEmails = config('constant.BLACKLIST_EMAILS');
                    $finalMailData['name'] = $value->display_name;
                    $mail[] = $value['emailAddresse']->address;
                    $key = config('constant.QUEUEJOB.TimeSheetReminderEmail');
                    $mergedArray = array_diff($mail, $blackListEmails);

                    $finalMailData['subject'] = $mailData->subject;
                    $finalMailData['code'] = $mailData->code;
                    $finalMailData['template'] = $mailData->template;

                    $finalMailData['mailTo'] = $mergedArray;
                    $finalMailData['mailcc'] = [];
                    $finalMailData['key'] = 'TimeSheetReminderEmail';
                    $finalMailData = (object) $finalMailData;

                    if(!empty($mergedArray)){
                        dispatch(new QueueJob($mergedArray,$finalMailData,$key,[]))->onQueue('default');
                    }
                }
            }

        $msg = 'Success';
        return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'),$msg);
    }catch(\Exception $e ) {
        return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'),'',$e->getMessage());
       }
    }


    private function removeUnAuthorizedProjectTimesheet($projects, $currentUserId, $userRole, $checkMapped, $pendingInitiaion = false)
    {
        $filterProjects = [];
        if (!empty($projects)) {
                foreach ($projects as $key => $value) {
                    $flag = false;
                  if($value->is_draft == 0){
                      if (
                          in_array($this->rolesArray[config('constant.ROLES.admin')], $userRole['global']) ||
                          in_array($this->rolesArray[config('constant.ROLES.global_operation')], $userRole['global'])
                      ) {
                          $flag = true;
                      }else{
                          if ((   in_array($this->rolesArray[config('constant.ROLES.sales')], $userRole['global']) ||
                                  in_array($this->rolesArray[config('constant.ROLES.resource_manager')], $userRole['global']))
                              && $value->status != config('constant.PROJECT_ACTION.initiation_request')){
                              $flag = true;
                          }

                          else if(count($value['ProjectRole']) > 0 && $value->status != config('constant.PROJECT_ACTION.initiation_request')){
                              $flag = true;
                          }
                          else if($value->created_by == $currentUserId && $value->status == config('constant.PROJECT_ACTION.initiation_request')){
                              $flag = true;
                          }
                          else if(count($value['resourceRequisitionAllProject']) > 0){
                              foreach ($value['resourceRequisitionAllProject'] as $requisition){
                                  if($requisition->status == 0){
                                      $flag = true;
                                      break;
                                  }else{
                                      if(count($requisition['Allocation']) > 0){
                                          foreach ($requisition['Allocation'] as $allocation){
                                              if($allocation->allocation_status == 14){
                                                  $flag = true;
                                                  break;
                                              }
                                          }
                                          if($flag){
                                              break;
                                          }
                                      }
                                  }
                              }
                          }
                          else{
                              if($checkMapped){
                                  if(isset($value['resourceMapped'])){
                                      foreach ($value['resourceMapped'] as $mappedResource){
                                          if(isset($mappedResource['resourceAllocation']['resourceAllocationMeta']) && $mappedResource['resourceAllocation']->allocation_status ==14){
                                              $flag = true;
                                              break;
                                          }
                                      }
                                  }
                              }
                          }
                      }
                  }else{
                      if($value->created_by == $currentUserId){
                          $flag = true;
                      }
                  }

                if($flag){
                    array_push($filterProjects, $value);
                }
            }
        }
        return $filterProjects;
    }
}
