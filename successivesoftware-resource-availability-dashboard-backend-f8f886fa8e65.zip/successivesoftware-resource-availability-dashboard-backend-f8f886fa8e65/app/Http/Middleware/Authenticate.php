<?php

namespace App\Http\Middleware;

use App\EmailAddresse;
use Closure;
use Illuminate\Contracts\Auth\Factory as Auth;
use log;
use Google_Client;
use App\User;
use Illuminate\Support\Facades\DB;

class Authenticate
{
    /**
     * The authentication guard factory instance.
     *
     * @var \Illuminate\Contracts\Auth\Factory
     */
    protected $auth;

    /**
     * Create a new middleware instance.
     *
     * @param  \Illuminate\Contracts\Auth\Factory  $auth
     * @return void
     */
    public function __construct(Auth $auth)
    {
        $this->auth = $auth;
    }

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @param  string|null  $guard
     * @return mixed
     */
    public function handle($request, Closure $next, $guard = null)
     {
        $token = $request->header('authorization');
        if(!$token) {
            $res['status'] = config('constant.STATUS_CODE.statusUnauthorized');
            $res['message'] = 'Error, Header must be present.';
            return response($res,config('constant.STATUS_CODE.statusUnauthorized'));
        }
        try{

            $client = new \GuzzleHttp\Client();
            $url = "https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=".env("API_KEY");

            $requestAuth = $client->post($url, array(
                'form_params' => array(
                    'idToken' => $token
                )
            ));
            $body = $requestAuth->getBody();
            $content = json_decode($body->getContents());
            $userInfo = $content->users;
            $userId = EmailAddresse::where('address',$userInfo[0]->email)->first();
            if($userId->user_id){
                $user = User::where('id', $userId->user_id)
                    ->select('id', 'status','firstname','lastname',  DB::raw("CONCAT(firstname,' ',lastname) as full_name"),
                        DB::raw("(select address from email_addresses where users.id = user_id) as email"),
                        DB::raw("(select value from custom_values where customized_id = users.id and custom_field_id = 15) as employee_id"))
                    ->first();
                if($user){
                    $request->merge(['user'=>$user]);
                }
            }
            if ($requestAuth->getStatusCode() !== config('constant.STATUS_CODE.statusOk')) {
                $res['status'] = config('constant.STATUS_CODE.statusUnauthorized');
                $res['message'] = 'Error, Invalid domain.';
                return response($res,config('constant.STATUS_CODE.statusUnauthorized'));
            }
        }
        catch(\GuzzleHttp\Exception\ClientException $e) {
           log::info('catch========== Exception');
            $res['status'] = config('constant.STATUS_CODE.statusUnauthorized');
            $res['message'] = 'Error, Unauthorized.';
            return response($res,config('constant.STATUS_CODE.statusUnauthorized'));
        }
        return $next($request);
    }
}
