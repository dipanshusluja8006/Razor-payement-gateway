<?php

namespace App\Http\Middleware;

use Closure;
use App\Models\DeAllocationMapping;
use App\Models\PerformedActionLog;
use App\Models\Project;
use App\Models\ResourceAllocation;
use App\Models\ResourceAllocationMeta;
use Helpers;
use ApiResponse;

class RolesMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next,$admin,$global_operation=null,$sales=null,$resource_manager=null,$account_manager=null,$project_manager=null,$bu_head=null, $go_team=null)
    {
        $projectId = Helpers::getProjectId($request);
        $roles = Helpers::getRole($request->user->id, $projectId);
        $routeRolesArray = Helpers::getUserRole($admin,$global_operation,$sales,$resource_manager,$account_manager,$project_manager,$bu_head, $go_team);
        foreach ($routeRolesArray as $key => $value){
            if(in_array($value, $roles['global']) || in_array($value, $roles['project'])){
                $response=$next($request);
            break;
            }else{
                $response= ApiResponse::genericResponse(config('constant.STATUS_CODE.statusUnauthorized'));
            }
        }
        return $response;
    }
}
