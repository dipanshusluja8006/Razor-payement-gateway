<?php

namespace App\Http\Middleware;

use Illuminate\Http\Request;
use Closure;
use ApiResponse;

class AuthenticatePMOMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        $token = $request->header('X-PMO-API-KEY');
        if(!$token) {
            $res['status'] = config('constant.STATUS_CODE.statusUnauthorized');
            $res['message'] = 'Error, Header must be present.';
            return response($res,config('constant.STATUS_CODE.statusUnauthorized'));
        }elseif($token==env("X_PMO_API_KEY")){
            $response = $next($request);
            return $response;
        }else{
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusUnauthorized'));
        }
    }
}
