<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Project;
use Illuminate\Support\Facades\DB;
use Helpers;
use Carbon\Carbon;
use Log;
use Awobaz\Compoships\Compoships;

class ResourceBooking extends Model
{

    /**
     * The table associated with the model.
     *
     * @var string
     */
    use Compoships;
    protected $connection = "redmine_db_mysql";
    protected $fillable = [
        'id',
        'project_id',
        'assigned_to_id',
        'issue_id',
        'author_id',
        'start_date',
        'end_date',
        'hours_per_day',
        'notes',
        'created_at',
        'updated_at',
    ];

    public function project()
    {
        return $this->belongsTo('App\Project', 'project_id', 'id')->select('id', 'name');
    }
    public function user()
    {
        return $this->HasOne('App\User', 'id', 'assigned_to_id')->with('emailAddresse')->select('id', 'firstname', 'lastname', 'status')->where('status', config('constant.REDMINE_USERSTATUS.activeUser'));
    }

    public function userDetail()
    {
        return $this->HasOne('App\User', 'id', 'assigned_to_id')
                     ->select('id', 'status', DB::raw("CONCAT(firstname,' ',lastname) as display_name"), DB::raw("(select address from email_addresses where users.id  =   user_id) as email"), DB::raw("(select value from custom_values where customized_id = users.id and custom_field_id = 15) as employee_id"))
                     ->where('status', config('constant.REDMINE_USERSTATUS.activeUser'));
    }


    public function userDepartment()
    {
        return $this->hasOne('App\CustomValue', 'customized_id', 'assigned_to_id')->where('custom_field_id', config('constant.REDMINE_DEPARTMENT_FIELD_ID'));
    }

    public function userProjects()
    {
        return $this->hasMany('App\Member', 'user_id', 'assigned_to_id')->with('MemberRole');
    }

    public function userMembers()
    {
        return $this->hasOne('App\Member', ['user_id', 'project_id'], ['assigned_to_id', 'project_id'])->with('MemberRole');
    }


    public static function saveResourceBooking($currentUserId, $data, $redmineProjectID)
    {
        $resource = [
            'project_id' => $redmineProjectID,
            'assigned_to_id' => $data['resource_id'],
            'issue_id' => NULL,
            'author_id' => $currentUserId,
            'start_date' => Carbon::createFromFormat('Y-m-d', $data['start_date']),
            'end_date' => Carbon::createFromFormat('Y-m-d', $data['end_date']),
            'hours_per_day' => $data['hours'],
            'notes' => ''
        ];
        $resource = new ResourceBooking($resource);
        return $resource->save();
    }

    static function updateResourceBooking($bookingID,$userId,$data)
    {
        $result = ResourceBooking::where('id',$bookingID)->first();
        $startDate = Carbon::parse($result['start_date']);
        $deallocateFrom = Carbon::createFromFormat('Y-m-d', $data['deallocate_from']);
        $response = false;
        if (isset($data)) {
            if(Carbon::parse($startDate)->isSameDay(Carbon::parse($deallocateFrom)) && Carbon::parse($deallocateFrom)->greaterThan(Carbon::now()) && $result['hours_per_day']==$data['deallocate_for']){
                //$response = ResourceBooking::where('id', $bookingID)->delete();
                $booking_dataZero = [
                    'hours_per_day' => 0,
                    'author_id' => $userId
                ];
                $response =  ResourceBooking::where('id', $bookingID)->update($booking_dataZero);
            }else{
             $booking_data = [
                'end_date' => $deallocateFrom,
                'author_id' => $userId
            ];
            $response =  ResourceBooking::where('id', $bookingID)->update($booking_data);
            if($result['hours_per_day']!=$data['deallocate_for']){
                $leftHours=$result['hours_per_day']-$data['deallocate_for'];
                $newStartDate = Carbon::parse($deallocateFrom)->addDays(config('constant.CRON_DAYS.one_day'));
                $end_date = Carbon::createFromFormat('Y-m-d', $data['end_date']);
                $resourceData = [
                    'project_id' => $result['project_id'],
                    'assigned_to_id' => $result['assigned_to_id'],
                    'issue_id' => NULL,
                    'author_id' => $userId,
                    'start_date' => $newStartDate,
                    'end_date' => $end_date,
                    'hours_per_day' => $leftHours,
                    'notes' => ''
                ];
                $response = new ResourceBooking($resourceData);
                $response->save();
            }
            if($result)
            return $response;
        }
        } else {
            return $response;
        }
    }
}
