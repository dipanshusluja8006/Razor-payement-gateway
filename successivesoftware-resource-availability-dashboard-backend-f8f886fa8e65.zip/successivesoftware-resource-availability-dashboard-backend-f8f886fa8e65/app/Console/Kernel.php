<?php

namespace App\Console;

use Illuminate\Console\Command;
use Illuminate\Console\Scheduling\Schedule;
use Laravel\Lumen\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [
        Commands\ResourceDeAllocationEmail::class,
        Commands\CheckAndSaveDeAllocatedResource::class,
        Commands\BenchResourceEmail::class,
        Commands\ClearViewCache::class,
        Commands\deleteExpireResourceExtensionRequest::class,
        Commands\ResourceUnmappingReminder::class,
        Commands\ResourceBookingsMismatchedCron::class,
        Commands\OverScheduleResourceCron::class,
        Commands\ResourceDeleteRedmineCron::class,
        Commands\AddFutureBookingMembers::class,
        Commands\AddCustomApisResponseDB::class,
        // Commands\AutoExtensionCron::class,
        // Commands\ProjectInvoiceAMPMReminderCron::class,
        // Commands\InvoiceStatusReportsRMCron::class,
        Commands\MergeRedmineUsers::class,
        Commands\RMAssignment::class,
        Commands\CreateWSR::class,
    ];

    /**
     * Define the application's command schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule  $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
        $schedule->command('expire-resource-extension:request')
            ->dailyAt("06:00")
            ->timezone('Asia/Kolkata');
        $schedule->command('de-allocate:resources')
            ->dailyAt("07:00")
            ->timezone('Asia/Kolkata');
        if (config('app.env') == 'production') {
            $schedule->command('resource-de-allocation:reminder')
                ->dailyAt("07:30")
                ->timezone('Asia/Kolkata');
        }
        $schedule->command('bench-resource-weekly:reminder')
            ->weeklyOn(1, '8:00')
            ->timezone('Asia/Kolkata');
        $schedule->command('resource-unmapping-reminder-request:reminder')
            ->dailyAt("08:15")
            ->timezone('Asia/Kolkata');
        $schedule->command('resource-bookings-mismatched:reminder')
            ->dailyAt("04:00")
            ->timezone('Asia/Kolkata');
        $schedule->command('over-schedule-resource-weekly:reminder')
            ->weeklyOn(1, '05:00')
            ->timezone('Asia/Kolkata');
        $schedule->command('resource-delete-redmine:reminder')
            ->days([1, 2, 3, 4, 5])
            ->at("11:55")
            ->timezone('Asia/Kolkata');
        $schedule->command('add-future-booking:members')
            ->dailyAt("06:30")
            ->timezone('Asia/Kolkata');
        $schedule->command('custom-api-response-request:reminder')
            ->dailyAt("05:30")
            ->timezone('Asia/Kolkata');
        //  $schedule->command('auto-extension:resources')
        //      ->dailyAt("07:00")
        //      ->timezone('Asia/Kolkata');
        // $schedule->command('project-invoice-reminder-ampm:reminder')
        //      ->monthlyOn(27, '07:00')
        //      ->timezone('Asia/Kolkata');
        // $schedule->command('invoice-status-reports-rm:reminder')
        //     ->monthlyOn(30, '07:00')
        //     ->timezone('Asia/Kolkata');
        $schedule->command('get-redmine-users:fetch')
            ->cron('0 8-23/4 * * *')
            ->timezone('Asia/Kolkata');
        $schedule->command('create-weekly-wsr:generate')
            ->weeklyOn(1, '04:30')
            ->timezone('Asia/Kolkata');
    }
}
