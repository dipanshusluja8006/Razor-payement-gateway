<?php

namespace App\Console\Commands;

use App\Libraries\MailService;
use Illuminate\Console\Command;
use Carbon\Carbon;
use Webpatser\Uuid\Uuid;
use App\Models\WeeklyStatusReport;
use App\Models\Project;


class CreateWSR extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'create-weekly-wsr:generate';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Generate all active project wsr week wise';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $today = Carbon::today();
        $weekNumber = $today->weekOfYear;
        $weekStartDate = $today->startOfWeek()->toDateString();
        $weekEndDate = $today->endOfWeek()->toDateString();
        $date = Carbon::createFromFormat('Y-m-d', $weekEndDate);
        $finalWeekEnddate = $date->subDays(2)->format('Y-m-d');

        $activeProjectStatus = ['12', '13', '1'];
        $projects = Project::whereNotIn('status', $activeProjectStatus)
            ->whereIn('billing_type', config('constant.billing_type'))->orderBy('created_at', 'desc')->get();

        $allProject = [];
        foreach ($projects as $value) {
            if ($value['is_draft'] == 1) {
                $allProject[] = $value;
            } else if ((($value['is_approve'] == 0 || $value['is_approve'] == 1) && $value['status'] == 17)) {
                $allProject[] = $value;
            } else {
                $allProject[] = $value;
            }
        }
        foreach ($allProject as $project) {
            $data = [
                'project_id' => $project['uuid'],
                'sch_cat_clt_esclation' => 0,
                'sch_cat_status' => 0,
                'sch_cat_remark' => '',
                'qlt_cat_clt_esclation' => 0,
                'qlt_cat_status' => 0,
                'qlt_cat_remark' => '',
                'stf_cat_clt_esclation' => 0,
                'stf_cat_status' => 0,
                'stf_cat_remark' => '',
                'inv_cat_clt_esclation' => 0,
                'inv_cat_status' => 0,
                'inv_cat_remark' => '',
                'rsk_cat_clt_esclation' => 0,
                'rsk_cat_status' => 0,
                'rsk_cat_remark' => '',
                'eft_cat_clt_esclation' => 0,
                'eft_cat_status' => 0,
                'eft_cat_remark' => '',
                'highlights_remark' => '',
                'lowlights_remark' => '',
                'customer_happiness_remark' => '',
                'people_happiness_remark' => '',
                'overall_health_count' => 0,
                'overall_health_status' => 4,
                'week_no' => $weekNumber,
                'week_start_date' => $weekStartDate,
                'week_end_date' => $finalWeekEnddate,
                'created_by' => 0
            ];
            $wsrDetails = new WeeklyStatusReport($data);
            $wsrDetails->save();
        }
    }
}
