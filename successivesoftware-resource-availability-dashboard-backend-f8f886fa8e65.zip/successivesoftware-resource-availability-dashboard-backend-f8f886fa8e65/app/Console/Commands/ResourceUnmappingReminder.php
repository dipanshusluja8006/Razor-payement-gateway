<?php

namespace App\Console\Commands;

use App\Mail\ResourceUnmappingReminderMail;
use App\Models\Project;
use Illuminate\Console\Command;
use Helpers;
use Illuminate\Support\Facades\Mail;
use Log;


class ResourceUnmappingReminder extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'resource-unmapping-reminder-request:reminder';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'check all resource pending unmapping resource and send mail to RM';

    /**
     * Create a new command instance.
     *
     * @return void
     */

    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle(){

        $mailData =[];
        $statusArray = [config('constant.PROJECT_ACTION.project_on_hold_request_accept'), config('constant.PROJECT_ACTION.project_closure_checklist')];

        $projects = Project::whereIn('status', $statusArray)->with(['DeAllocationMapping' => function ($query) {
            $query->where('status', config('constant.MAP_STATUS.Unmapped'));
        }])->get();

        foreach ($projects as $project) {
            if(isset($project['DeAllocationMapping'])){
                foreach ($project['DeAllocationMapping'] as $row) {

                    $user['name'] = $row['resource']->display_name;
                    $user['projectName'] = $project->project_name;
                    $user['employeeId'] = $row['resource']->employee_id;
                    $user['email'] = $row['resource']->email;
                    if(isset($row['resourceAllocation']['resourceRequisition']['department']->name)){
                        $user['department'] = $row['resourceAllocation']['resourceRequisition']['department']->name;
                    }
                    if(isset($row['resourceAllocation']['resourceRequisition']['department']->name)){
                        $user['technology'] = $row['resourceAllocation']['resourceRequisition']['technology']->name;
                    }
                    if(isset($row['resourceAllocation']['resourceRequisition']['department']->name)){
                        $user['role'] = $row['resourceAllocation']['resourceRequisition']['designation']->name;
                    }
                    $user['dailyEfforts'] = $row->efforts;
                    $user['deAllocationForHours'] = $row->hours;
                    $user['deAllocationFrom'] = $row->de_allocation_from;
                    $mailData['unMappingData'][] = $user;

                }
            }
        }

        if (!empty($mailData['unMappingData'])) {
            $blackListEmails = config('constant.BLACKLIST_EMAILS');
            $customEmail=config('constant.CUSTOM_RESOURCEMAIL');
            $CUSTOM_GAURAVEMAIL = config('constant.CUSTOM_GAURAVEMAIL');
            $toEmails = \Helpers::getGlobalUserId('', config('constant.ROLES.resource_manager'));
            $toEmails = array_merge($toEmails,$customEmail);
            $toEmails = array_merge($toEmails,$CUSTOM_GAURAVEMAIL);
            $toEmails = array_diff($toEmails, $blackListEmails);
            $mailData['subject'] = 'Resource Unmapping Reminder Mail';
            Mail::to($toEmails)->send(new ResourceUnmappingReminderMail($mailData));
            Log::info([json_encode($toEmails), json_encode($mailData)]);
        }
        $this->info('success');
    }

}
