<?php

namespace App\Console\Commands;

use App\ResourceBooking;
use Helpers;
use Illuminate\Console\Command;
use Log;
use Carbon\Carbon;

class ResourceDeAllocationEmail extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'resource-de-allocation:reminder';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Sending mail to RM, resource, and other emails about comes deallocate date about resource in next 5,3,last days';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $previousDay = Carbon::today()->subDays(config('constant.CRON_DAYS.one_day'));
        $threeDay = Carbon::today()->addDays(config('constant.CRON_DAYS.three_day'));
        $fiveDay = Carbon::today()->addDays(config('constant.CRON_DAYS.five_day'));
        $dataByProject = [];

        $resources = ResourceBooking::with('user', 'project', 'userProjects')
            ->where('hours_per_day', '!=' , 0)
            ->whereDate('end_date', $previousDay)
            ->orWhereDate('end_date', $threeDay)
            ->orWhereDate('end_date', $fiveDay)
            ->get();

        $threeDay = Carbon::parse($threeDay);
        $fiveDay = Carbon::parse($fiveDay);
        $previousDay = Carbon::parse($previousDay);

        foreach ($resources as $resource) {
            $endDay = Carbon::parse($resource->end_date);
            $deallocatedDate = $endDay->format('Y-m-d');
            $nextDay = Carbon::parse($resource->end_date)->addDays(1);
            $isProjectStillAssign = false;

            if ($resource['user']) {
                if(isset($resource['userProjects'])){
                    foreach ($resource['userProjects'] as $assignedProject){
                        if($assignedProject->project_id == $resource->project_id){
                            $isProjectStillAssign = true;
                            break;
                        }
                    }
                }

                $resourceName = $resource['user']->firstname . ' ' . $resource['user']->lastname;
                $resourceEmail = $resource['user']['emailAddresse']->address;
                if ($resource['project']) {
                    $projectName = $resource['project']->name;
                }
                if(!$this->reBookedCheck($resource->assigned_to_id, $resource->project_id, $nextDay)) {

                    if (($endDay->isSameDay($threeDay)) || ($endDay->isSameDay($fiveDay))) {
                        $dataByProject[$resource->project_id]['endingSoon'][] = ['projectName' => $projectName,
                            'resourceName' => $resourceName,
                            'deallocatedDate' => $deallocatedDate,
                            'isProjectStillAssign' => $isProjectStillAssign,
                        ];
                        $this->bookingEndingSoonMailToResource($resourceName, $resourceEmail, $deallocatedDate, $projectName);
                    }
                    if (($endDay->isSameDay($previousDay))) {
                        $dataByProject[$resource->project_id]['ended'][] = ['projectName' => $projectName,
                            'resourceName' => $resourceName,
                            'deallocatedDate' => $deallocatedDate,
                            'isProjectStillAssign' => $isProjectStillAssign,
                        ];

                        $this->bookingEndedMailToResource($resourceName, $resourceEmail, $deallocatedDate, $projectName);
                    }
                }
            }
        }
        if(!empty($dataByProject)){
            $this->sendMailToProjectManager($dataByProject);
            $this->sendMailToResourceManager($dataByProject);
            $this->sendMailToGlobalManager($dataByProject);
        }
        $this->info('success');
    }

    public function sendMailToProjectManager($dataByProject){
        foreach ($dataByProject as $key => $data){
            $projectManagerIds = Helpers::getProjectManagerEmail($key);
            $accountManagerIds = Helpers::getAccountManagerEmail($key);
            $emailArray = array_merge($projectManagerIds, $accountManagerIds);
            $mailData['data'] = $data;
            $mailData['mailTo'] = 'projectManager';
            Helpers::sendMail($mailData, $emailArray);
            Log::info([json_encode($projectManagerIds), json_encode($mailData)]);
        }
    }

    public function sendMailToResourceManager($dataByProject){
        $data = [];

        foreach ($dataByProject as $key => $details){
            $resource = [];
            if(!empty($details['ended'])) {
                foreach ($details['ended'] as $records) {
                    if ($records['isProjectStillAssign']) {
                        $resource[] = $records;
                    }
                }
                if (!empty($resource)) {
                    $data[$key] = $resource;
                }
            }
        }

        if(!empty($data)){
            $mail = \Helpers::getGlobalUserId('', config('constant.ROLES.resource_manager'));
            $mailData['data'] = $data;
            $mailData['mailTo'] = 'resourceManager';
            Helpers::sendMail($mailData, $mail);
            Log::info([json_encode($mail), json_encode($mailData)]);
        }
    }

    public function sendMailToGlobalManager($dataByProject){

        $data = [];
        foreach ($dataByProject as $key => $details){
            $resource = [];
            if(!empty($details['ended'])) {
                if (!empty($details['ended'])) {
                    $data[$key] = $details['ended'];
                }
            }
        }

        if(!empty($data)) {
            $mail = \Helpers::getGlobalUserId('', config('constant.ROLES.global_operation'));
            $mailData['data'] = $data;
            $mailData['mailTo'] = 'globalOperation';
            Helpers::sendMail($mailData, $mail);
            Log::info([json_encode($mail), json_encode($mailData)]);
        }
    }

    public function bookingEndedMailToResource($resourceName, $resourceEmail, $deallocatedDate, $projectName){
        $mail[] = $resourceEmail;
        $mailData['template']['subject'] = "Resource Booking Ended";
        $mailData['template']['template'] = "<p>Hello,</p><p>Your booking for one of your projects has ended, Detail below:</p></br></br><p><span><b>Resource Name:&nbsp;</b></span><span>$resourceName</span></p><p><span><b>Project Name:&nbsp;</b></span><span>$projectName</span></p><p><span><b>Booking End Date:&nbsp;</b></span><spam>$deallocatedDate</spam></p>";
        $mailData['mailTo'] = 'resource';
        Helpers::sendMail($mailData, $mail);
        Log::info([$mail, json_encode($mailData)]);
    }

    public function bookingEndingSoonMailToResource($resourceName, $resourceEmail, $deallocatedDate, $projectName){
        $mail[] = $resourceEmail;
        $mailData['template']['subject'] = "Resource Booking Ending Soon!";
        $mailData['template']['template'] = "<p>Hello,</p><p>Your booking for one of your projects is ending soon. Detail below:</p></br></br><p><span><b>Resource Name:&nbsp;</b></span><span>$resourceName</span></p><p><span><b>Project Name:&nbsp;</b></span><span>$projectName</span></p><p><span><b>Booking End Date:&nbsp;</b></span><spam>$deallocatedDate</spam></p>";
        $mailData['mailTo'] = 'resource';
        Helpers::sendMail($mailData, $mail);
        Log::info([$mail, json_encode($mailData)]);
    }

    public function reBookedCheck($resourceId, $projectId, $nextDay){
        $endedCheck = ResourceBooking::where('assigned_to_id', $resourceId)
            ->where('project_id', $projectId)
            ->whereDate('start_date', $nextDay)
            ->first();
        return $endedCheck;
    }

}
