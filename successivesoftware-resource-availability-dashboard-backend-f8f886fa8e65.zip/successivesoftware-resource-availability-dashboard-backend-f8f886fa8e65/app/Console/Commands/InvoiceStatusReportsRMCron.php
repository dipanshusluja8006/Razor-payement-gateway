<?php

namespace App\Console\Commands;

use Helpers;
use Illuminate\Console\Command;
use App\Mail\InvoiceReminderRMMail;
use Log;
use Carbon\Carbon;
use Illuminate\Support\Facades\Mail;
use App\Project as RedmineProjectModel;
use App\Invoice;


class InvoiceStatusReportsRMCron extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'invoice-status-reports-rm:reminder';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Sending mail to RM, for invoice generate and pending status of current month';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $data = [];
        $today = Carbon::now();
        $invoiceProject = [];
        $currentMonth = $today->month; // retrieve the month
        $currentYear = $today->year; // retrieve the year of the date
        $invoice = Invoice::whereMonth('invoice_date', $currentMonth)->whereYear('invoice_date', $currentYear)->get();
        foreach($invoice as $val){
            $invoiceProject[] = $val['project_id'];
        }
        $redmineProjects = RedmineProjectModel::whereHas('billingProjects',function($q){
            $q->where('status', config('constant.REDMINE_PROJECTSTATUS.activeProject'));
        })->with('projectInvoices','billingProjects','ProjectMembers')->get(['id','name','status']);
        foreach ($redmineProjects as $redmineProject) {
            $redmineProjectAMNames=[];
            $redmineProjectPMNames=[];
            $InvoiceStatus = [];
            foreach ($redmineProject['ProjectMembers'] as $userProjects) {
                foreach ($userProjects['MemberRole'] as $memberRole){
                    if(isset($redmineProject['projectInvoices']->invoice_date)){
                             $invoiceMonth = carbon::parse($redmineProject['projectInvoices']->invoice_date)->format('m');
                             $InvoiceDate = carbon::parse($redmineProject['projectInvoices']->invoice_date)->format('Y-m-d');
                    }
                    if($memberRole->role_id == 3){
                        if($userProjects['User']->status==1){
                        $redmineProjectAMNames[] = isset($userProjects['User']->display_name)?$userProjects['User']->display_name:'';
                        }
                    }
                    if($memberRole->role_id == 15){
                        if($userProjects['User']->status==1){
                        $redmineProjectPMNames[] = isset($userProjects['User']->display_name)?$userProjects['User']->display_name:'';
                        }
                    }
                    if($invoiceMonth == $currentMonth){
                        $InvoiceStatus = 'Generated';
                        $InvoiceDate = $InvoiceDate;
                    }else{
                        $InvoiceStatus = 'Pending';
                        $InvoiceDate = $InvoiceDate;
                    }
                }
            }
            $redmineAM = count($redmineProjectAMNames) > 0 ? implode(", ",$redmineProjectAMNames) : 'N/A';
            $redminePM = count($redmineProjectPMNames) > 0 ? implode(", ",$redmineProjectPMNames) : 'N/A';
            if(is_array($InvoiceStatus)){
                $InvoiceStatus = 'Pending';
                $InvoiceDate = 'N/A';
            }
            $data = [
                'ProjectName' => Helpers::getProjectNameRedmine($redmineProject['billingProjects']->customized_id),
                'BillingType' => Helpers::getCustomBillingType($redmineProject['billingProjects']->value),
                'RedmineAM' =>$redmineAM,
                'RedminePM' =>$redminePM,
                'LastInvoiceDate' =>$InvoiceDate,
                'InvoiceStatus' =>$InvoiceStatus
            ];
        $datanew[]=$data;
    }
    $flag = false;
    foreach ($datanew as $key => $result){
        if(count($result) > 0){
            $flag = true;
            break;
        }
    }
    if($flag){
        $blackListEmails = config('constant.BLACKLIST_EMAILS');
        $customEmail=config('constant.CUSTOM_RESOURCEMAIL');
        $CUSTOM_GAURAVEMAIL = config('constant.CUSTOM_GAURAVEMAIL');
        $toEmails = \Helpers::getGlobalUserId('', config('constant.ROLES.resource_manager'));
        $toEmails = array_merge($toEmails,$customEmail);
        $toEmails = array_merge($toEmails,$CUSTOM_GAURAVEMAIL);
        $toEmails = array_diff($toEmails, $blackListEmails);
        $mailData['data'] = $datanew;
        $mailData['subject'] = 'Invoices Status Report';
        Mail::to($toEmails)->send(new InvoiceReminderRMMail($mailData));
        Log::info([json_encode($toEmails), json_encode($mailData)]);
    }
  }
}
