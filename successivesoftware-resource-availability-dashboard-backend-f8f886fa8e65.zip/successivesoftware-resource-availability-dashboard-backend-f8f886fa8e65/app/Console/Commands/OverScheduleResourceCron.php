<?php

namespace App\Console\Commands;

use App\Mail\OverScheduleResourceMail;
use App\ResourceBooking;
use Helpers;
use Illuminate\Console\Command;
use App\User;
use Carbon\Carbon;
use Log;
use Illuminate\Support\Facades\Mail;
use DB;
use Webpatser\Uuid\Uuid;


class OverScheduleResourceCron extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'over-schedule-resource-weekly:reminder';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Sending Unscheduled/Bench Resource weekly report of current and upcoming Week to GO and BU head';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */

    public function handle()
    {
        $benchResourceExcludeDepartmentList = config('constant.BENCHRESOURCE_EXCLUDEDEPARTMENT');
        $timeEntryExcepion = Helpers::timeEntryExceptionUsersIdList();
        $currentDay = Carbon::now()->format('D');
        if ($currentDay == 'Mon') {
            $currentWeekStartDate = Carbon::now()->format('Y-m-d');
            $currentWeekEndDate = Carbon::now()->addDay(4)->format('Y-m-d');

            $durationStart = Carbon::now()->format('D, dS M y');
            $durationEnd = Carbon::now()->addDay(4)->format('D, dS M y');
        } else {
            $currentWeekStartDate = Carbon::now()->previous('Monday')->format('Y-m-d');
            $currentWeekEndDate = Carbon::parse($currentWeekStartDate)->addDay(4)->format('Y-m-d');

            $durationStart = Carbon::parse($currentWeekStartDate)->format('D, dS M y');
            $durationEnd = Carbon::parse($currentWeekStartDate)->addDay(4)->format('D, dS M y');
        }
        $startDate = $currentWeekStartDate;
        $endDate = $currentWeekEndDate;

        $records = $this->checkOverScheduleQuery($startDate, $endDate);
        $allBooking = $this->allAssignedOverScheduleProject($startDate, $endDate);
        foreach ($records as $section => $users) {
            foreach ($users as $key => $user) {
                if(!in_array($user->userId, $timeEntryExcepion) && $user->department != $benchResourceExcludeDepartmentList){
                    $allData[$user->department][] = $this->getUserAllOverScheduleProject($user, $allBooking, $startDate);
                }
            }
        }

        if (isset($allData)) {
            $mailData = [
                'subject' => 'Over Scheduled Resources Weekly Report',
                'duration' => $durationStart . ' - ' . $durationEnd,
                'data' => $allData
            ];
            $blackListEmails = config('constant.BLACKLIST_EMAILS');
            $customEmail=config('constant.CUSTOM_RESOURCEMAIL');
            $CUSTOM_GAURAVEMAIL = config('constant.CUSTOM_GAURAVEMAIL');
            $mailId = \Helpers::getGlobalUserId('', config('constant.ROLES.global_operation'));
            $mailId = array_merge($mailId,$customEmail);
            $mailId = array_merge($mailId,$CUSTOM_GAURAVEMAIL);
            $mailId = array_diff($mailId, $blackListEmails);
            if(isset($mailId)){
                Mail::to($mailId)->send(new OverScheduleResourceMail($mailData));
            }
            Log::info([json_encode($mailId), json_encode($mailData)]);
        }
        $this->info('success');

    }

    private function getUserAllOverScheduleProject($user, $allBooking, $startDate){
        $userStart = strtotime($user->startDate);
        $userEnd = strtotime($user->endDate);
        $userId = $user->userId;
        $groupedRecord = collect($allBooking)->groupBy('userId');
        if(isset($groupedRecord[$userId])) {
            foreach ($groupedRecord[$userId] as $booking) {
                $bookingStart = strtotime($booking['startDate']);
                $bookingEnd = strtotime($booking['endDate']);
                if ($bookingStart <= $userEnd && $bookingEnd >= $userStart) {
                    $user->projectInfo[] = $booking;
                }
            }
        }
        $addSinceValue = $this->getBenchSinceValue($user, $startDate);
        return $addSinceValue;
    }

    private function allAssignedOverScheduleProject($startDate, $endDate){
        $projects = ResourceBooking::where(function($q) use($endDate) {
            return $q->whereDate('start_date', '<=', $endDate);
        })->where(function($q) use($startDate) {
            return $q->whereDate('end_date', '>=', $startDate);
        })
            ->with('project')
            ->get();
        $response = [];
        foreach($projects as $row){
            $projectInfo = array(
                'userId' => $row->assigned_to_id,
                'projectId' => $row->project->id,
                'projectName' => $row->project->name,
                'startDate' => $row->start_date,
                'endDate' => $row->end_date,
                'hours' => $row->hours_per_day,
            );
            $response[] =$projectInfo;
        }
        return $response;
    }

    public function checkOverScheduleQuery($startDate, $endDate)
    {
        $department = 'All';
        $location = 'All';
        $username = '';

        $locationFieldId = config('constant.CUSTOM_VALUES.location');
        $departmentFeildId = config('constant.CUSTOM_VALUES.business_unit');
        $bindings = [
            'startDate'=> $startDate,
            'endDate' => $endDate,
            'startDate1'=> $startDate,
            'endDate1' => $endDate
        ];
        $locationFilter = ($location!='All') ? " AND location.value = :location " : "";
        $departmentFilter = ($department!='All') ? " AND department.value = :department" : " AND COALESCE(department.value,'') <> :department";
        $userFilter = ($department!='') ? " AND LOWER(TRIM(CONCAT(TRIM(users.`firstname`),' ',TRIM(users.`lastname`)))) LIKE :username " : "";
        if($locationFilter){
            $bindings['location'] = $location;
        }
        if($departmentFilter){
            $bindings['department'] = $department =="All" ? 'CLIENT' : $department;
        }
        if($userFilter){
            $bindings['username'] = "%".$username."%";
        }
        $data= DB::connection('redmine_db_mysql')->select(DB::raw(
            "SELECT users.id as userId,
                    TRIM(CONCAT(TRIM(users.`firstname`),' ',TRIM(users.`lastname`))) as name, 
                    coalesce(temp.hrs,0) as total,
                    temp.date,
                    coalesce(location.value,'') as location,
                    coalesce(department.value,'') as department
                FROM users
                    LEFT JOIN (SELECT customized_id,value FROM custom_values WHERE custom_field_id =$locationFieldId) as location
                       ON location.customized_id = users.id  
                    LEFT JOIN (SELECT customized_id,value FROM custom_values WHERE custom_field_id =$departmentFeildId) as department
                       ON department.customized_id = users.id 
                    LEFT JOIN
                (SELECT
                    r.assigned_to_id,
                    d.date,	
                    SUM(`hours_per_day`) as hrs
                FROM
                    (
                    SELECT * FROM 
                        (SELECT ADDDATE('1970-01-01',t4.i*10000 + t3.i*1000 + t2.i*100 + t1.i*10 + t0.i) date FROM
                         (SELECT 0 i UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) t0,
                         (SELECT 0 i UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) t1,
                         (SELECT 0 i UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) t2,
                         (SELECT 0 i UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) t3,
                         (SELECT 0 i UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) t4) v
                        WHERE date BETWEEN DATE_FORMAT(:startDate,'%Y-%m-%d') AND DATE_FORMAT(:endDate,'%Y-%m-%d')
                    ) d
                           LEFT JOIN resource_bookings r  ON d.date BETWEEN DATE_FORMAT(r.start_date,'%Y-%m-%d') AND DATE_FORMAT(r.end_date,'%Y-%m-%d')
                WHERE d.`date` BETWEEN  DATE_FORMAT(:startDate1,'%Y-%m-%d') AND DATE_FORMAT(:endDate1,'%Y-%m-%d')    
                GROUP BY
                    r.`assigned_to_id`,
                    d.date) temp ON users.id=temp.assigned_to_id
                WHERE users.status=1 AND users.type='User' $locationFilter $departmentFilter $userFilter
                 ORDER BY users.id,temp.date"),$bindings);
        $data = collect($data)->groupBy('userId')->toArray();
        $response = array(
            'unScheduled' => [],
        );
        foreach($data as $keyId => $rows){
            $intervals = Helpers::breakIntoIntervals($rows,$startDate,$endDate);
            $this->addToOverScheduleResponse($response,$intervals);
        }
        return $response;
    }

    private function addToOverScheduleResponse(&$response,$intervals){
        foreach($intervals as $interval){
            $interval->uuid = (string)Uuid::generate(4);
            if($interval->total > 8){
                $response['overScheduled'][] = $interval;
            }
        }
    }

    public function getBenchSinceValue($user, $startDate)
    {
        $benchSince = 0;
        $benchSinceDate = false;
        if(isset($user)){
            foreach ($user->projectInfo as $booking){
                if($benchSinceDate == false){
                    $benchSinceDate = $booking['startDate'];
                }
                else{
                    if(Carbon::parse($benchSinceDate)->lessThan(Carbon::parse($booking['startDate']))) {
                        $benchSinceDate = $booking['startDate'];
                    }
                }
            }
            if ($benchSinceDate) {
                $benchSince = Helpers::dateDiffExcludingWeekend($benchSinceDate, $startDate);
            }
            $user->benchSince = $benchSince;
        }
        return $user;
    }
}
