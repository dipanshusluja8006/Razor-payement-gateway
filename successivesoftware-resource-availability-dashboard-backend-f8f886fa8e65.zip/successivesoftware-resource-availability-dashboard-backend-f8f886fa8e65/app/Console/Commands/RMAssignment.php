<?php

namespace App\Console\Commands;

use App\Libraries\MailService;
use App\Models\Department;
use Helpers;
use Illuminate\Console\Command;
use App\Models\LocalUser;
use App\Models\UserRole;
use Log;
use Carbon\Carbon;
use Webpatser\Uuid\Uuid;
use App\Models\ReportingManager;


class RMAssignment extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'bu-assignment-to-rm:assign';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'BU Head assigned as RM if current RM has been inactive';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $data = array();
        $selectedArray = array();
        $kekaData = Helpers::getKekaData();
        $activeUsers = LocalUser::with(['department'])->where('status', config('constant.REDMINE_USERSTATUS')['activeUser'])->get()->toArray();
        foreach ($activeUsers as $checkResource) {
            foreach ($kekaData as $value) {
                if (trim($value['email']) == trim($checkResource['email'])) { //resource match condition
                    //get resource rm data
                    $rmEmailKeka = isset($value['reportsTo']['email']) ? $value['reportsTo']['email'] : '';
                    //$rmEmailKeka find in active user list
                    if (
                        $value['email'] == 'samrat.singh@successive.tech' || $value['email'] == 'md.arif@successive.tech' ||
                        $value['email'] == 'abhishek.punj@successive.tech'
                    ) {
                        // if (!$rmEmailKeka) {
                        $departmentName = $checkResource['department'][0]['value'];
                        $userDepartment = Department::where('name', $departmentName)->first()->toArray();
                        if ($userDepartment) {
                            $dep_id = $userDepartment['id'];
                            $dept[] = $dep_id;
                            $bu_head = UserRole::where('role_id', 7)->where('dept_id', $dep_id)->first()->toArray();
                            $bu_head_details = LocalUser::where('user_id', $bu_head['user_id'])->first()->toArray();
                            $record = [
                                'uuid' => (string) Uuid::generate(4),
                                'dept_id' => $dep_id,
                                'resource_id' =>  $checkResource['user_id'],
                                'requested_rm_id' => $bu_head['user_id'],
                                'active_rm_id' => $bu_head['user_id'],
                                'is_approved' => config('constant.RM_APPROVAL.approved'),
                                'created_by' => $bu_head['user_id'],
                                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
                            ];
                            $data[] = $record;
                            $selectedArray[] = [
                                'resource_name' => $checkResource['full_name'],
                                'resource_email' => $checkResource['email'],
                                'department' => \Helpers::getDepartmentNameByID($dep_id),
                                'resource_employee_number' => $checkResource['employee_id'],
                                'requested_manager_name' => $bu_head_details['full_name'],
                                'active_manager_name' => 'Left the organization',
                            ];
                        }
                        $emails[] = $bu_head_details['email'];
                    }
                }
            }
        }
        if (count($data) > 0) {
            $responce = ReportingManager::insert($data);
            if ($responce) {
                $val = config('constant.TEMPLATES.bu_assignment_as_rm');
                $allRMEmails = $emails;
                $dept[] = $dept;
                $mailService = new MailService($val, '', $selectedArray, $dept, $allRMEmails);
                $mailService->sendMail();
            }
        }
    }
}
