<?php

namespace App\Console\Commands;

use App\ResourceBooking;
use Helpers;
use Illuminate\Console\Command;
use Log;
use Carbon\Carbon;
use App\Mail\ResourceBookingsMismatchedMail;
use App\Models\Project;
use Illuminate\Support\Facades\Mail;
use App\Project as RedmineProjectModel;


class ResourceBookingsMismatchedCron extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'resource-bookings-mismatched:reminder';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Sending mail to RM, resource that booking not match on rmo and redmine';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $data = [];
        $redmineProjects = RedmineProjectModel::select('id', 'name', 'status')->with('currentBooking', 'tillYesterdayBooking')
            ->where('status', 1)
            ->get();
        $pmoResource = Project::with('currentBookings')
            ->where('status', '!=', 17)
            ->get();

        foreach ($pmoResource as $key => $pmoproject){
            $matchRecordsRedmineId = [];
            $projectName = $pmoproject->project_name;
            $data[$projectName] = [];
            $pmoResourceIdArray = [];
            $tillYesterdayBooking = [];
            $redmineResources = [];
            foreach ($redmineProjects as $redmineProject){
                if(trim(strtolower(str_replace( array(' '), '', $redmineProject->name))) ==
                    trim(strtolower(str_replace( array(' '), '', $projectName)))){
                    $redmineResources = $redmineProject['currentBooking'];
                    $tillYesterdayBooking = $redmineProject['tillYesterdayBooking'];
                }
            }

            foreach ($pmoproject['currentBookings'] as $resourceMapped){
                if(isset($resourceMapped['resourceAllocation']['resourceAllocationMeta'][0])) {
                    foreach ($resourceMapped['resourceAllocation']['resourceAllocationMeta'] as $resourceAllocationMeta) {
                        if(isset($resourceAllocationMeta['resource']->status) &&
                            $resourceAllocationMeta['resource']->status == config('constant.REDMINE_USERSTATUS.activeUser')) {
                            $flag = false;
                            $endDate = Carbon::parse($resourceAllocationMeta->end_date);
                            $resourceId = $resourceAllocationMeta->resource_id;
                            $resourceEmail = isset($resourceAllocationMeta['resource']->email) ? $resourceAllocationMeta['resource']->email : "";
                            $resourceEmployeeCode = isset($resourceAllocationMeta['resource']->employee_id) ? $resourceAllocationMeta['resource']->employee_id : "";
                            $pmoResourceIdArray[] = $resourceAllocationMeta->resource_id;
                            $resourceName = isset($resourceAllocationMeta['resource']->display_name) ? $resourceAllocationMeta['resource']->display_name : "";
                            $projectName = $pmoproject->project_name;
                            $count = 0;
                            $redmineResourceBookingCount = 0;
                            $pmoResourceBookingCount = 0;
                            //booking count check for single resource
                            foreach ($pmoproject['currentBookings'] as $countPmoBookig) {
                                if ($countPmoBookig->resource_id == $resourceId) {
                                    $pmoResourceBookingCount = $pmoResourceBookingCount + 1;
                                }
                            }
                            foreach ($redmineResources as $redmineResource) {
                                if ($redmineResource->assigned_to_id == $resourceId
                                ) {
                                    $redmineResourceBookingCount = $redmineResourceBookingCount + 1;
                                }
                            }
                            //if both pmo and redmine has entry
                            foreach ($redmineResources as $redmineResource) {
                                if (!in_array($redmineResource->id, $matchRecordsRedmineId) &&
                                    $redmineResource->assigned_to_id == $resourceId &&
                                    $endDate->greaterThanOrEqualTo(Carbon::today())
                                ) {
                                    if (Carbon::parse($resourceAllocationMeta->start_date)->format('Y-m-d') == Carbon::parse($redmineResource->start_date)->format('Y-m-d') &&
                                        Carbon::parse($resourceAllocationMeta->end_date)->format('Y-m-d') == Carbon::parse($redmineResource->end_date)->format('Y-m-d') &&
                                        $redmineResource->hours_per_day == $resourceAllocationMeta->hours) {
                                        $matchRecordsRedmineId[] = $redmineResource->id;
                                        $count = $count + 1;
                                        $flag = true;
                                        break;
                                    } else {
                                        if (\Helpers::checkMatchedRecordPMO($pmoproject['currentBookings'], $redmineResource) ||
                                            \Helpers::checkMatchedRecordRedmine($resourceAllocationMeta, $redmineResources)) {
                                            continue;
                                        } else {
                                            $matchRecordsRedmineId[] = $redmineResource->id;
                                            $array = $this->createMailData($redmineResource, $resourceMapped, $projectName, $resourceId, true, true, $resourceName, $resourceEmail, $resourceEmployeeCode, $resourceAllocationMeta);
                                            $data[$projectName][$resourceName][] = $array;
                                            $count = $count + 1;
                                            $flag = true;
                                            break;

                                        }
                                    }
                                }
                            }
                            //if only pmo has entry that is not in Redmine and reCheck if pmo booking has mismatch entry which have end date as yesterday
                            if ($redmineResourceBookingCount < $pmoResourceBookingCount && $flag == false &&
                                $endDate->greaterThanOrEqualTo(Carbon::today())) {
                                // reCheck if pmo booking has mismatch entry which have end date as yesterday
                                $yesterdayBooking = Helpers::checkBackDateRecordRedmine($matchRecordsRedmineId, $tillYesterdayBooking, $resourceId);
                                if ($yesterdayBooking) {
                                    $matchRecordsRedmineId[] = $yesterdayBooking->id;
                                    $array = $this->createMailData($yesterdayBooking, $resourceMapped, $projectName, $resourceId, true, true, $resourceName, $resourceEmail, $resourceEmployeeCode, $resourceAllocationMeta);
                                    $data[$projectName][$resourceName][] = $array;
                                    $count = $count + 1;
                                    $flag = true;
                                    break;
                                } else {
                                    //if only pmo has entry that is not in Redmine
                                    $array = $this->createMailData([], $resourceMapped, $projectName, $resourceId, false, true, $resourceName, $resourceEmail, $resourceEmployeeCode, $resourceAllocationMeta);
                                    $data[$projectName][$resourceName][] = $array;
                                }
                            }
                            //if only redmine has entry that is not in pmo
                            if ($redmineResourceBookingCount > $pmoResourceBookingCount && $count == $pmoResourceBookingCount) {
                                foreach ($redmineResources as $redmineResource) {
                                    if (!in_array($redmineResource->id, $matchRecordsRedmineId) &&
                                        $redmineResource->assigned_to_id == $resourceId &&
                                        $endDate->greaterThanOrEqualTo(Carbon::today())
                                    ) {
                                        $matchRecordsRedmineId[] = $redmineResource->id;
                                        $array = $this->createMailData($redmineResource, [], $projectName, $resourceId, true, false, $resourceName, $resourceEmail, $resourceEmployeeCode, []);
                                        $data[$projectName][$resourceName][] = $array;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            //if only redmine has entry for diffrent resource that is not in pmo
            foreach ($redmineResources as $redmineResource){
                if( isset($redmineResource['userDetail']->status) &&
                    $redmineResource['userDetail']->status == config('constant.REDMINE_USERSTATUS.activeUser')){
                    $endDate = Carbon::parse($redmineResource->end_date);
                    if(!in_array($redmineResource->assigned_to_id, $pmoResourceIdArray)){
                        if(!in_array($redmineResource->id, $matchRecordsRedmineId) &&
                            $endDate->greaterThanOrEqualTo(Carbon::today())
                        ){
                            $matchRecordsRedmineId[] = $redmineResource->id;
                            if(isset($redmineResource['userDetail']->display_name) || isset($redmineResource['userDetail']->email)) {
                                $resourceName = isset($redmineResource['userDetail']->display_name) ? $redmineResource['userDetail']->display_name : '';
                                $resourceEmail = isset($redmineResource['userDetail']->email) ? $redmineResource['userDetail']->email : "";
                                $resourceEmployeeCode = isset($redmineResource['userDetail']->employee_id) ? $redmineResource['userDetail']->employee_id : "";
                                $array = $this->createMailData($redmineResource, [], $projectName, $redmineResource->assigned_to_id, true, false, $resourceName, $resourceEmail, $resourceEmployeeCode, []);
                                $data[$projectName][$resourceName][] = $array;
                            }
                        }
                    }
                }
            }
        }
        $flag = false;
        foreach ($data as $key => $project){
            if(count($project) > 0){
                $flag = true;
                break;
            }
        }
        if($flag){
            $blackListEmails = config('constant.BLACKLIST_EMAILS');
            $customEmail=config('constant.CUSTOM_RESOURCEMAIL');
            $CUSTOM_GAURAVEMAIL = config('constant.CUSTOM_GAURAVEMAIL');
            $toEmails = \Helpers::getGlobalUserId('', config('constant.ROLES.resource_manager'));
            $toEmails = array_merge($toEmails,$customEmail);
            $toEmails = array_merge($toEmails,$CUSTOM_GAURAVEMAIL);
            $toEmails = array_diff($toEmails, $blackListEmails);
            $mailData['data'] = $data;
            $mailData['subject'] = 'Resource Booking Discrepancies';
            Mail::to($toEmails)->send(new ResourceBookingsMismatchedMail($mailData));
            Log::info([json_encode($toEmails), json_encode($mailData)]);
        }else{
            $customEmail=config('constant.CUSTOM_RESOURCEMAIL');
            $CUSTOM_GAURAVEMAIL = config('constant.CUSTOM_GAURAVEMAIL');
            $toEmails = \Helpers::getGlobalUserId('', config('constant.ROLES.resource_manager'));
            $toEmails = array_merge($toEmails,$customEmail);
            $toEmails = array_merge($toEmails,$CUSTOM_GAURAVEMAIL);
            $mailData['data'] = ['No Discrepancies'];
            $mailData['subject'] = 'Resource Booking Discrepancies';
            Log::info([json_encode($toEmails), json_encode($mailData)]);
        }
        $this->info('success');
    }

    public function createMailData($redmineResource, $resourceMapped, $projectName, $resourceId, $redmine, $pmo, $resourceName, $resourceEmail, $resourceEmployeeCode, $resourceAllocationMeta){
        if($redmine == true && $pmo == true ){
            $array = [
                'projectName' => $projectName,
                'resourceName' => $resourceName,
                'employeeId' => $resourceEmployeeCode,
                'email' => $resourceEmail,
                'redmineStartDate' => Carbon::parse($redmineResource->start_date)->format('d/m/Y'),
                'redmineEndDate' => Carbon::parse($redmineResource->end_date)->format('d/m/Y'),
                'redmineDailyEfforts' => $redmineResource->hours_per_day,
                'pmoStartDate' => Carbon::parse($resourceAllocationMeta->start_date)->format('d/m/Y'),
                'pmoEndDate' => Carbon::parse($resourceAllocationMeta->end_date)->format('d/m/Y'),
                'pmoDailyEfforts' => $resourceAllocationMeta->hours,
            ];
        }
        if($redmine != true && $pmo == true ){
            $array = [
                'projectName' => $projectName,
                'resourceName' => $resourceName,
                'employeeId' => $resourceEmployeeCode,
                'email' => $resourceEmail,
                'redmineStartDate' =>"N/A",
                'redmineEndDate' => "N/A",
                'redmineDailyEfforts' =>"N/A",
                'pmoStartDate' => Carbon::parse($resourceAllocationMeta->start_date)->format('d/m/Y'),
                'pmoEndDate' => Carbon::parse($resourceAllocationMeta->end_date)->format('d/m/Y'),
                'pmoDailyEfforts' => $resourceAllocationMeta->hours,
            ];
        }
        if($redmine == true && $pmo != true ){
            $array = [
                'projectName' => $projectName,
                'resourceName' => $resourceName,
                'employeeId' => $resourceEmployeeCode,
                'email' => $resourceEmail,
                'redmineStartDate' => Carbon::parse($redmineResource->start_date)->format('d/m/Y'),
                'redmineEndDate' => Carbon::parse($redmineResource->end_date)->format('d/m/Y'),
                'redmineDailyEfforts' => $redmineResource->hours_per_day,
                'pmoEndDate' => "N/A",
                'pmoStartDate' => "N/A",
                'pmoDailyEfforts' =>"N/A",
            ];
        }
        return $array;
    }
}
