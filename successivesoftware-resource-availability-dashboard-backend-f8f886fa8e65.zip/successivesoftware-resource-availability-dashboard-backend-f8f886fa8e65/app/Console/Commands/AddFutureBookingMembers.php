<?php

namespace App\Console\Commands;

use App\ResourceBooking;
use Helpers;
use Illuminate\Console\Command;
use Log;
use Carbon\Carbon;
use App\Mail\ResourceBookingsMismatchedMail;
use App\Models\Project;
use Illuminate\Support\Facades\Mail;



class AddFutureBookingMembers extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'add-future-booking:members';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Assign Member Role to future booking in redmine';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $data = [];
        $redmineResources = ResourceBooking::whereHas('project', function($q){
            $q->where('status', 1);
        })->whereDate('start_date', '=', Carbon::today())
            ->where('hours_per_day', '!=' , 0)
            ->get();
        $pmoResource = Project::with('futureBookings')
            ->where('status', '!=', 17)
            ->get();
        $matchRecordsRedmineId = [];
        foreach ($pmoResource as $key => $pmoproject){
            $redmineProjectId = $pmoproject->redmine_project_id;
            $projectName = $pmoproject->project_name;
            if($redmineProjectId == null || $redmineProjectId == '') {
                $redmineProjectId = Helpers::projectIDRedmine($projectName);
            }

            foreach ($pmoproject['futureBookings'] as $resourceMapped){
                if(isset($resourceMapped['resourceAllocation']['resourceAllocationMeta'][0])) {
                    foreach ($resourceMapped['resourceAllocation']['resourceAllocationMeta'] as $resourceAllocationMeta) {

                        $pmoRole = isset($resourceMapped['resourceAllocation']['ResourceRequisition']['designation']->name) ? $resourceMapped['resourceAllocation']['ResourceRequisition']['designation']->name : '';
                        $redmineRoleId = Helpers::roleIDRedmine($pmoRole);
                        $resourceId = $resourceAllocationMeta->resource_id;
                        $pmoResourceIdArray[] = $resourceAllocationMeta->resource_id;

                        //if both pmo and redmine has entry
                        foreach ($redmineResources as $redmineResource) {
                            if (!in_array($redmineResource->id, $matchRecordsRedmineId) &&
                                $redmineResource->assigned_to_id == $resourceId &&
                                $redmineResource['project']->id == $redmineProjectId
                            ) {
                                if (Carbon::parse($resourceAllocationMeta->start_date)->format('Y-m-d') == Carbon::parse($redmineResource->start_date)->format('Y-m-d') &&
                                    Carbon::parse($resourceAllocationMeta->end_date)->format('Y-m-d') == Carbon::parse($redmineResource->end_date)->format('Y-m-d') &&
                                    $redmineResource->hours_per_day == $resourceAllocationMeta->hours) {
                                    $matchRecordsRedmineId[] = $redmineResource->id;
                                    $assignRole = $this->UpdateRole($redmineProjectId, $resourceId, $redmineRoleId);
                                }

                            }
                        }

                    }
                }
            }
        }

        $this->info('success');
    }

    public function UpdateRole($redmineProjectId, $resourceId, $redmineRoleId){
        if($redmineProjectId != null || $resourceId != null || $redmineRoleId != null){
            //here write assign member role code.
            $data = json_encode([
                'membership' =>
                [
                  'user_id' => $resourceId,
                  'role_ids' =>
                  [
                    0 => $redmineRoleId,
                  ],
                ],
            ]);
               $result = Helpers::callAPI('POST','/projects/'.$redmineProjectId.'/memberships.json',$data);
               Log::info(['Project_Membership_POST_API_FUTUREBOOKING', json_encode($result),$data]);
               if($result==200){
                 return true;
               }else{
                 return false;
            }
        }
    }
}
