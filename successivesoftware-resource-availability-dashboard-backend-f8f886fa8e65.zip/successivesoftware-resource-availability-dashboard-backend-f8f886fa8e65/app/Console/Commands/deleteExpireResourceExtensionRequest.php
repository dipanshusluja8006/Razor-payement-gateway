<?php

namespace App\Console\Commands;

use App\Mail\deleteLapsedResourceExtensionRequest;
use App\Models\Project;
use App\Models\ResourceMapping;
use App\Models\ResourceRequisition;
use App\Traits\ResourceControllerTraits;
use Helpers;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Mail;
use Log;
use Carbon\Carbon;

class deleteExpireResourceExtensionRequest extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'expire-resource-extension:request';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'check all resource extension request that has any pending action on allocation(not mapped) delete and send mail according to condition';

    /**
     * Create a new command instance.
     *
     * @return void
     */

    use ResourceControllerTraits;

    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle(){
        $allMappingIds = [];
        $allRequisitionIds = [];
        $blockProjectStatus = [
            config('constant.PROJECT_ACTION.project_closure_checklist'),
            config('constant.PROJECT_ACTION.project_on_hold_request_accept'),
            config('constant.PROJECT_ACTION.project_on_hold_request'),
            config('constant.PROJECT_ACTION.initiation_request'),
            config('constant.PROJECT_ACTION.initiation')
        ];
        $projecIds = Project::select('uuid', 'status','is_draft')
            ->where('status', '!=', config('constant.PROJECT_ACTION.initiation_request'))
            ->where('is_draft', 0)->pluck('uuid')->toArray();
        foreach ($projecIds as $projectId) {
            $data = [];
            $toEmails = [];
            $ccEmails = [];
            $projectStatus = Project::where('uuid', $projectId)->pluck('status')->first();
            $blackListEmails = config('constant.BLACKLIST_EMAILS');
            $pendingRequisitions = $this->checkIsRequisitionPending($projectId); //expire pending requisition
            $getAllStagePendingData = $this->pendingRequisitionLogic($pendingRequisitions, $projectId);
            $mappingIds = array_unique($getAllStagePendingData['deleteData']['allMappingIdsToDelete']);
            $requisitionIds = array_unique($getAllStagePendingData['deleteData']['allRequisitionIdsToDelete']);
            $allMappingIds = array_merge($allMappingIds, $mappingIds);
            $allRequisitionIds = array_merge($allRequisitionIds, $requisitionIds);
            if(!in_array($projectStatus, $blockProjectStatus)){
                $this->updateProjectStatusAccordingResources($projectId, true);
             }
            $buHead = \Helpers::getGlobalUserId(array_unique($getAllStagePendingData['departments']), config('constant.ROLES.bu_head'));
            $accountManagers = \Helpers::getProjectUserId($projectId, config('constant.ROLES.account_manager'));
            $projectManagers = \Helpers::getProjectUserId($projectId, config('constant.ROLES.project_manager'));
            $resourceManagers = \Helpers::getGlobalUserId('', config('constant.ROLES.resource_manager'));
            //send Mail
            $stage = $getAllStagePendingData['stage'];

            if(!empty($stage['noAllocation']) || !empty($stage['reallocation']) || !empty($stage['mappingPending']) || !empty($stage['partialAllocation']) ){
                if(!empty($stage['noAllocation']) || !empty($stage['reallocation'])){
                    $CUSTOM_GAURAVEMAIL = config('constant.CUSTOM_GAURAVEMAIL');
                    $ccEmails = array_merge($ccEmails,$buHead);
                    $ccEmails = array_merge($ccEmails,$CUSTOM_GAURAVEMAIL);
                }
                if(!empty($stage['mappingPending'])){
                    $CUSTOM_GAURAVEMAIL = config('constant.CUSTOM_GAURAVEMAIL');
                    $ccEmails = array_merge($ccEmails,$resourceManagers);
                    $ccEmails = array_merge($ccEmails,$CUSTOM_GAURAVEMAIL);
                }
                $customEmail=config('constant.CUSTOM_RESOURCEMAIL');
                $toEmails = array_merge($accountManagers, $projectManagers,$customEmail);
                $toEmails = array_diff($toEmails, $blackListEmails);
                $ccEmails = array_diff($ccEmails, $blackListEmails);
                $data['stage'] = $stage;
                $data['stage']['projectName'] = \Helpers::getProjectName($projectId);
                $data['emails'] = array_unique($ccEmails);
                Mail::to($toEmails)->send(new deleteLapsedResourceExtensionRequest($data));
                Log::info([json_encode($toEmails), json_encode($data)]);
            }
        }
        if (!empty($allMappingIds)) {
            ResourceMapping::whereIn('uuid', $allMappingIds)->delete();
        }
        if (!empty($allRequisitionIds)) {
            ResourceRequisition::whereIn('uuid', $allRequisitionIds)->delete();
        }

        $this->info('success');
    }

    protected function pendingRequisitionLogic($pendingRequisitions, $projectId){
        $stage['noAllocation'] = [];
        $stage['partialAllocation'] = [];
        $stage['reallocation'] = [];
        $stage['mappingPending'] = [];
        $deleteData['allRequisitionIdsToDelete'] = [];
        $deleteData['allMappingIdsToDelete'] = [];
        $departments = [];
        $pendingReqIds = [];
        foreach ($pendingRequisitions as $pendingRequisition) {
            $pendingReqIds[] = $pendingRequisition->uuid;
            if(!empty($pendingRequisition['ResourceAllocation'][0])) {
                switch (($pendingRequisition['ResourceAllocation'][0]->allocation_status)) {
                    case config('constant.PROJECT_ACTION.resource_allocation_request'):
                        $stage['partialAllocation'][] = $this->formatData($pendingRequisition, true);
                        break;
                    case config('constant.PROJECT_ACTION.resource_allocation_response_decline'):
                        $stage['reallocation'][] = $this->formatData($pendingRequisition, true);
                        $departments[] = $pendingRequisition->dept_id;
                        break;
                    default:
                }
            }else{
                $stage['noAllocation'][] = $this->noAllocationFormatData($pendingRequisition);
                $departments[] = $pendingRequisition->dept_id;
            }
        }
        $pendingMappingData = $this->getMappingPendingRequisitionList($projectId);
        $stage['mappingPending'] = $pendingMappingData['reqData'];
        $deleteData['allMappingIdsToDelete'] = $pendingMappingData['mappingIds'];
        $deleteData['allRequisitionIdsToDelete'] = array_merge($pendingMappingData['reqIds'], $pendingReqIds);
        $data['stage'] = $stage;
        $data['deleteData'] = $deleteData;
        $data['departments'] = $departments;
        return $data;
    }

    protected function formatData($pendingRequisition, $withAllocation){
        $data = [
            'uuid' =>  $pendingRequisition->uuid,
            'resource_name' =>  isset($pendingRequisition['resource']->display_name) ? $pendingRequisition['resource']->display_name : '',
            'department' =>  $pendingRequisition['department']->name,
            'role' =>  $pendingRequisition['designation']->name,
            'technology' =>  $pendingRequisition['technology']->name,
            'dailyEffort' =>  $pendingRequisition->efforts,
            'startData' =>  $pendingRequisition->start_date,
            'endDate' =>  $pendingRequisition->end_date,
        ];
        if($withAllocation){
            $data['resource_name'] = $pendingRequisition['ResourceAllocation'][0]['resourceAllocationMeta'][0]['resource']->display_name;
        }
        return $data;
    }

    protected function noAllocationFormatData($pendingRequisition){
        $data = [
            'uuid' =>  $pendingRequisition->uuid,
            'resource_name' =>  isset($pendingRequisition['resource']->display_name) ? $pendingRequisition['resource']->display_name : '',
            'department' =>  $pendingRequisition['department']->name,
            'role' =>  $pendingRequisition['designation']->name,
            'technology' =>  $pendingRequisition['technology']->name,
            'dailyEffort' =>  $pendingRequisition->efforts,
            'startData' =>  $pendingRequisition->start_date,
            'endDate' =>  $pendingRequisition->end_date,
        ];
        return $data;
    }

    protected function checkIsRequisitionPending($projectId){
        $previousDay = Carbon::today()->subDays(1);
        $pendingRequisition = ResourceRequisition::with('ResourceAllocation', 'resource')->where('project_id', $projectId)->where('status', config('constant.REQUISITION_TYPE.extension'))->where('status', config('constant.PERFORM_ACTIONLOG.inProgress'))->whereDate('end_date', $previousDay)->get();
        return $pendingRequisition;
    }

    protected function getMappingPendingRequisitionList($projectId){
        $previousDay = Carbon::today()->subDays(1);
        $reqIds = [];
        $mappingIds = [];
        $pendingMappingRequisition = [];
        $mappingDetails = ResourceMapping::where(
            [
                'project_id' => $projectId,
                'status' => '0'
            ]
        )->with('resourceAllocation')->get();
        if (isset($mappingDetails)) {
            foreach ($mappingDetails as $record) {
                if (isset($record['resourceAllocation']['resourceRequisition'])) {
                    $endDay = Carbon::parse($record['resourceAllocation']['resourceRequisition']->end_date);
                    if($record['resourceAllocation']['resourceRequisition']->type == config('constant.REQUISITION_TYPE.extension') && ($endDay->isSameDay($previousDay))){
                        array_push($reqIds, $record['resourceAllocation']['resourceRequisition']->uuid);
                        array_push($mappingIds, $record->uuid);
                        $pendingMappingRequisition[] = [
                            'resource_name' =>  isset($record['resource']->display_name) ? $record['resource']->display_name : '',
                            'department' =>  $record['resourceAllocation']['resourceRequisition']['department']->name,
                            'role' =>  $record['resourceAllocation']['resourceRequisition']['designation']->name,
                            'technology' => $record['resourceAllocation']['resourceRequisition']['technology']->name,
                            'dailyEffort' =>  $record['resourceAllocation']['resourceRequisition']->efforts,
                            'startData' =>  $record['resourceAllocation']['resourceRequisition']->start_date,
                            'endDate' =>  $record['resourceAllocation']['resourceRequisition']->end_date,
                        ];

                    }
                }
            }
        }

        $response['reqIds'] = $reqIds;
        $response['reqData'] = $pendingMappingRequisition;
        $response['mappingIds'] = $mappingIds;
        return $response;
    }


}
