<?php

namespace App\Console\Commands;

use App\EmailAddresse;
use App\Models\UserRole;
use App\ResourceBooking;
use Helpers;
use Illuminate\Console\Command;
use App\User;
use Carbon\Carbon;
use Log;

class BenchResourceEmail extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'bench-resource-weekly:reminder';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Sending Unscheduled/Bench Resource weekly report of current and upcoming Week to GO and BU head';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {

        $customEmails = ['saurabh.tiwari@successive.tech', 'sainath.giradkar@successive.tech', 'amtestuser@successivesoftwares.com', 'saurabhtiwari.snt@gmail.com'];
        $buHeads = UserRole::where('role_id', 7)->pluck('user_id')->toArray();
        $customResourcesIds = EmailAddresse::whereIn('address', $customEmails)->pluck('user_id')->toArray();
        $globalExcepion = Helpers::timeEntryExceptionUsersIdList();
        $timeEntryExcepion = array_merge($buHeads, $customResourcesIds, $globalExcepion);
        $traineeUser = Helpers::createTraineeUserArray();

        $mailData = [];
        $finalRecord = [];
        $mailId = config('constant.BENCH_RESOURCEMAIL');
        $benchResourceExcludeDepartmentList = config('constant.BENCHRESOURCE_EXCLUDEDEPARTMENT');

        $resourceBookings = User::with('ResourceBooking', 'userDepartment')->where([
            'status' => config('constant.REDMINE_USERSTATUS.activeUser'),
            'type' => config('constant.REDMINE_USERSTATUS.userType')
        ])->get();
        if (isset($resourceBookings)) {
            foreach ($resourceBookings as $key => $resource) {
                if (!in_array($resource->id, $timeEntryExcepion)) {
                    $resourceName = $resource->firstname . ' ' . $resource->lastname;
                    $resourceId = $resource->id;
                    $department = ($resource['userDepartment'] && !empty($resource['userDepartment'][0]['value'])) ? $resource['userDepartment'][0]['value'] : 'N/A';
                    if (in_array($department, $benchResourceExcludeDepartmentList)) {
                        continue;
                    }
                    $currentDay = Carbon::now()->format('D');
                    if ($currentDay == 'Mon') {
                        $currentWeekStartDate = Carbon::now()->format('Y-m-d');
                        $currentWeekEndDate = Carbon::now()->addDay(4)->format('Y-m-d');
                        $nextWeekStartDate = Carbon::now()->addDay(7)->format('Y-m-d');
                        $nextWeekEndDate = Carbon::now()->addDay(11)->format('Y-m-d');

                        $durationStart = Carbon::now()->format('D, dS M y');
                        $durationEnd = Carbon::now()->addDay(4)->format('D, dS M y');
                        $nextDurationStart = Carbon::now()->addDay(7)->format('D, dS M y');
                        $nextDurationEnd = Carbon::now()->addDay(11)->format('D, dS M y');
                    } else {
                        $currentWeekStartDate = Carbon::now()->previous('Monday')->format('Y-m-d');
                        $currentWeekEndDate = Carbon::parse($currentWeekStartDate)->addDay(4)->format('Y-m-d');
                        $nextWeekStartDate = Carbon::parse($currentWeekStartDate)->addDay(7)->format('Y-m-d');
                        $nextWeekEndDate = Carbon::parse($currentWeekStartDate)->addDay(11)->format('Y-m-d');

                        $durationStart = Carbon::parse($currentWeekStartDate)->format('D, dS M y');
                        $durationEnd = Carbon::parse($currentWeekStartDate)->addDay(4)->format('D, dS M y');
                        $nextDurationStart = Carbon::parse($currentWeekStartDate)->addDay(7)->format('D, dS M y');
                        $nextDurationEnd = Carbon::parse($currentWeekStartDate)->addDay(11)->format('D, dS M y');
                    }
                    $benchResource['week'] = $this->checkResourceBooking($resource, $currentWeekStartDate);
                    $benchResource['nextWeek'] = $this->checkResourceBooking($resource, $nextWeekStartDate);

                    if ($benchResource['week']['benchResource']) {
                        foreach ($benchResource['week']['startDate'] as $startDate => $value) {
                            $sinceDays = $benchResource['week']['benchSince'][$startDate];
                            $record = [$department, $resourceName, $startDate, $currentWeekEndDate, $value, $sinceDays];
                        }
                        if (!array_key_exists('week', $finalRecord)) {
                            if(!in_array($resourceId, $traineeUser)){
                                $finalRecord['week'][$department]['Employees'][] = $record;
                            } else{
                                $finalRecord['week'][$department]['Trainees'][] = $record;
                            }
                        } else {
                            if(!in_array($resourceId, $traineeUser)){
                                $finalRecord['week'][$department]['Employees'][] = $record;
                            } else{
                                $finalRecord['week'][$department]['Trainees'][] = $record;
                            }
                        }
                    }

                    if ($benchResource['nextWeek']['benchResource']) {
                        foreach ($benchResource['nextWeek']['startDate'] as $startDate => $value) {
                            $sinceDays = $benchResource['nextWeek']['benchSince'][$startDate];
                            $record = [$department, $resourceName, $startDate, $nextWeekEndDate, $value, $sinceDays];
                        }
                        if (!array_key_exists('nextWeek', $finalRecord)) {
                            if(!in_array($resourceId, $traineeUser)){
                                $finalRecord['nextWeek'][$department]['Employees'][] = $record;
                            } else{
                                $finalRecord['nextWeek'][$department]['Trainees'][] = $record;
                            }
                        } else {
                            if(!in_array($resourceId, $traineeUser)){
                                $finalRecord['nextWeek'][$department]['Employees'][] = $record;
                            } else{
                                $finalRecord['nextWeek'][$department]['Trainees'][] = $record;
                            }
                        }
                    }

                }
            }

        }
        if ($finalRecord) {
            $mailData = [
                'subject' => 'Unscheduled/Bench Resources Report',
                'duration' => $durationStart . ' - ' . $durationEnd,
                'nextDuration' => $nextDurationStart . ' - ' . $nextDurationEnd,
                'data' => $finalRecord
            ];
            Helpers::sendBenchResourceMail($mailData, $mailId);
            Log::info(json_encode($mailData));
        }
        $this->info('success');
    }

    public function checkResourceBooking($resource, $weekDate)
    {
        $response = [];
        $unAllocatedHours = 0;
        $benchHours = 0;
        $totalHours = 0;
        $allocatedHours = 0;
        $benchSince = 0;
        $startDateArray = [];
        $benchSinceArray = [];
        $resourceCreatedOn = Carbon::Parse($resource->created_on)->format('Y-m-d');
        if (count($resource['ResourceBooking']) > 0) {
            foreach ($resource['ResourceBooking'] as $booking) {
                $totalHours = $totalHours + $booking->hours_per_day;
            }
            if ($totalHours < config('constant.REDMINE_DAILYENTRYHOURS')) {
                $benchHours = config('constant.REDMINE_DAILYENTRYHOURS') - $totalHours;
            }
            foreach ($resource['ResourceBooking'] as $booking) {
                $weekEndDate = Carbon::Parse($weekDate)->addDay(4)->format('Y-m-d');
                $bookingEndDate = Carbon::Parse($booking['end_date'])->format('Y-m-d');
                $bookingNextEndDate = Carbon::Parse($booking['end_date'])->addDay(1)->format('Y-m-d');
                if (strtotime($booking['end_date']) >= strtotime($weekEndDate) && strtotime($booking['start_date']) >= strtotime($weekEndDate)) {
                    continue;
                }
                if (strtotime($booking['end_date']) >= strtotime($weekEndDate)) {
                    $allocatedHours = $allocatedHours + $booking->hours_per_day;
                } else {
                    if (strtotime($booking['end_date']) >= strtotime($weekDate)) {
                        $benchResponse = $this->getBenchHoursForSpecificDate($bookingNextEndDate, $resource['ResourceBooking'], $booking->hours_per_day, $bookingEndDate, $benchHours);
                        if ($benchResponse['freeHours']) {
                            $benchHours = 0;
                        }
                        if (array_key_exists($bookingNextEndDate, $startDateArray)) {
                            $tempHours = $startDateArray[$bookingNextEndDate] + $benchResponse['benchHours'];
                            if ($tempHours > config('constant.REDMINE_DAILYENTRYHOURS')) {
                                $tempHours = config('constant.REDMINE_DAILYENTRYHOURS');
                            }
                            $startDateArray[$bookingNextEndDate] = $tempHours;
                        } else {
                            $startDateArray[$bookingNextEndDate] = $benchResponse['benchHours'];
                        }
                        $benchSinceArray[$bookingNextEndDate] = 0;
                    } else {
                        $benchResponse = $this->getBenchHoursForSpecificDate($weekDate, $resource['ResourceBooking'], $booking->hours_per_day, $bookingEndDate, $benchHours);
                        if ($benchResponse['freeHours']) {
                            $benchHours = 0;
                        }
                        if (array_key_exists($weekDate, $startDateArray)) {
                            $tempHours = $startDateArray[$weekDate] + $benchResponse['benchHours'];
                            if ($tempHours > config('constant.REDMINE_DAILYENTRYHOURS')) {
                                $tempHours = config('constant.REDMINE_DAILYENTRYHOURS');
                            }
                            $startDateArray[$weekDate] = $tempHours;
                        } else {
                            $startDateArray[$weekDate] = $benchResponse['benchHours'];
                        }
                        $benchSince = $this->getBenchSinceValue($resource['ResourceBooking'], $weekDate);
                        $benchSinceArray[$weekDate] = $benchSince;
                    }
                }
            }
            if (empty($startDateArray)) {
                if ($allocatedHours < config('constant.REDMINE_DAILYENTRYHOURS')) {
                    $benchSinceDays = Helpers::dateDiffExcludingWeekend($resourceCreatedOn, $weekDate);
                    $startDateArray[$weekDate] = config('constant.REDMINE_DAILYENTRYHOURS') - $allocatedHours;
                    $benchSinceArray[$weekDate] = $benchSinceDays;
                }
            } else {
                $startHours = $allocatedHours;
                foreach ($startDateArray as $key => $value) {
                    $startHours = $startHours + $value;
                }
                $extraHours = $startHours - config('constant.REDMINE_DAILYENTRYHOURS');
                if (array_key_exists($weekDate, $startDateArray)) {
                    $startDateArray[$weekDate] = $startDateArray[$weekDate] - $extraHours;
                    if ($startDateArray[$weekDate] < 1) {
                        unset($startDateArray[$weekDate]);
                        unset($benchSinceArray[$weekDate]);
                    }
                }
                $finalHours = $allocatedHours;
                foreach ($startDateArray as $key => $value) {
                    $finalHours = $finalHours + $value;
                }
                $finalExtraHours = $finalHours - config('constant.REDMINE_DAILYENTRYHOURS');
                $startDateArray = $this->reduceExtraHours($startDateArray, $finalExtraHours);
            }
            if ($allocatedHours < config('constant.REDMINE_DAILYENTRYHOURS')) {
                $response['benchResource'] = true;
                $response['startDate'] = $startDateArray;
                $response['benchSince'] = $benchSinceArray;
            } else {
                $response['benchResource'] = false;
            }
        } else {
            $benchSinceDays = Helpers::dateDiffExcludingWeekend($resourceCreatedOn, $weekDate);
            $startDateArray[$weekDate] = config('constant.REDMINE_DAILYENTRYHOURS');
            $benchSinceArray[$weekDate] = $benchSinceDays;
            $response['benchResource'] = true;
            $response['startDate'] = $startDateArray;
            $response['benchSince'] = $benchSinceArray;
        }
        return $response;
    }

    public function reduceExtraHours($startDateArray, $finalExtraHours)
    {
        if ($finalExtraHours > 0) {
            foreach ($startDateArray as $startDate => $value) {
                $smallerStartDate = true;
                foreach ($startDateArray as $index => $element) {
                    if (strtotime($startDate) > strtotime($index)) {
                        $smallerStartDate = false;
                        break;
                    }
                }
                if ($smallerStartDate) {
                    if ($startDateArray[$startDate] > $finalExtraHours) {
                        $startDateArray[$startDate] = $startDateArray[$startDate] - $finalExtraHours;
                        break;
                    } elseif ($startDateArray[$startDate] == $finalExtraHours) {
                        unset($startDateArray[$startDate]);
                        break;
                    } else {
                        $finalExtraHours = $finalExtraHours - $startDateArray[$startDate];
                        unset($startDateArray[$startDate]);
                        $startDateArray = $this->reduceExtraHours($startDateArray, $finalExtraHours);
                    }
                }
            }
        }
        return $startDateArray;
    }

    public function getBenchSinceValue($bookings, $weekDate)
    {
        $benchSince = 0;
        $benchSinceDate = false;
        $startDuration = false;
        if (isset($bookings)) {
            foreach ($bookings as $value) {
                $endDate = Carbon::Parse($value['end_date'])->format('Y-m-d');
                $startDate = Carbon::Parse($value['start_date'])->format('Y-m-d');
                if (strtotime($value['end_date']) < strtotime($weekDate)) {
                    if ($benchSinceDate) {
                        if (strtotime($value['end_date']) > strtotime($benchSinceDate)) {
                            $benchSinceDate = $endDate;
                            $startDuration = false;
                        }
                    } else {
                        $benchSinceDate = $endDate;
                    }
                }
                if (strtotime($value['start_date']) < strtotime($weekDate)) {
                    if ($benchSinceDate) {
                        if (strtotime($value['start_date']) > strtotime($benchSinceDate)) {
                            $benchSinceDate = $startDate;
                            $startDuration = true;
                        }
                    } else {
                        $benchSinceDate = $startDate;
                        $startDuration = true;
                    }
                }
            }
            if ($benchSinceDate) {
                $day = Carbon::parse($benchSinceDate)->format('D');
                $benchSince = Helpers::dateDiffExcludingWeekend($benchSinceDate, $weekDate);
                if ($day != 'Sat' && $day != 'Sun' && !$startDuration) {
                    $benchSince--;
                }
            }
        }
        return $benchSince;
    }

    public function getBenchHoursForSpecificDate($date, $bookings, $hour, $endDate, $freeHours)
    {
        $hours = 0;
        $response['benchHours'] = 0;
        $lowerEndDate = true;
        if (isset($bookings)) {
            foreach ($bookings as $value) {
                if (strtotime($endDate) > strtotime($value['end_date'])) {
                    $lowerEndDate = false;
                }
                if (strtotime($value['end_date']) >= strtotime($date)) {
                    $hours = $hours + $value['hours_per_day'];
                }
            }
            if ($lowerEndDate) {
                $response['benchHours'] = $hour + $freeHours;
                $response['freeHours'] = true;
            } else {
                $response['benchHours'] = $hour;
                $response['freeHours'] = false;
            }
        }
        return $response;
    }
}
