<?php

namespace App\Console\Commands;

use Helpers;
use Illuminate\Console\Command;
use App\Mail\InvoiceReminderAMPMMail;
use Log;
use Carbon\Carbon;
use Illuminate\Support\Facades\Mail;
use App\Project as RedmineProjectModel;
use App\Invoice;


class ProjectInvoiceAMPMReminderCron extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'project-invoice-reminder-ampm:reminder';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Sending mail to AM/PM, for invoice not generate till 27 of current month';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $data = [];
        $today = Carbon::now();
        $invoiceProject = [];
        $currentMonth = $today->month; // retrieve the month
        $currentYear = $today->year; // retrieve the year of the date
        $invoice = Invoice::whereMonth('invoice_date', $currentMonth)->whereYear('invoice_date', $currentYear)->get();
        foreach($invoice as $val){
            $invoiceProject[] = $val['project_id'];
        }
        $redmineProjects = RedmineProjectModel::whereHas('billingProjects', function($q){
            $q->where('status', config('constant.REDMINE_PROJECTSTATUS.activeProject'));
        })->with('billingProjects','ProjectMembers')->whereNotIn('id', $invoiceProject)->get(['id','name','status']);
        foreach ($redmineProjects as $redmineProject) {
            $emailArray=[];
           foreach ($redmineProject['ProjectMembers'] as $userProjects) {
              foreach ($userProjects['MemberRole'] as $memberRole){
                if($memberRole->role_id == 3 || $memberRole->role_id == 15){
                    if(!in_array($userProjects['User']->email,$emailArray)){
                        $emailArray[]=$userProjects['User']->email;
                        $redmineProjectAMPMIds[$userProjects['User']->email][\Helpers::getCustomBillingType($redmineProject['billingProjects']->value)][] = Helpers::getProjectNameRedmine($redmineProject['billingProjects']->customized_id);
                 }
               }
            }
        }
    }
    foreach ($redmineProjectAMPMIds as $key => $billing){
        $toEmails =[];
        $blackListEmails = config('constant.BLACKLIST_EMAILS');
        $toEmails[] = $key;
        $toEmails = array_diff($toEmails, $blackListEmails);
        $mailData['data'] = $billing;
        $mailData['subject'] = 'Invoice Reminder Mail';
        Mail::to($toEmails)->send(new InvoiceReminderAMPMMail($mailData));
        Log::info([json_encode($toEmails), json_encode($mailData)]);
        $this->info('success');
    }
  }
}
