<?php

namespace App\Console\Commands;

use App\Libraries\MailService;
use App\Models\Project;
use App\Models\ReportingManager;
use App\Models\UserRole;
use Illuminate\Console\Command;
use App\Models\ResourceAllocation;
use App\Models\ResourceAllocationMeta;
use App\Models\DeAllocationMapping;
use Helpers;
use Log;
use Carbon\Carbon;
use Webpatser\Uuid\Uuid;
use App\Traits\ResourceControllerTraits;



class CheckAndSaveDeAllocatedResource extends Command
{
    use ResourceControllerTraits;
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'de-allocate:resources';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'check and save resources these booking expire yesterday';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */

    public function handle()
    {
        $adminId = Helpers::getUserIdByGlobalRole(config('constant.ROLES.admin'));
        $data = [];
        $blockProjectStatus = [
            config('constant.PROJECT_ACTION.initiation_request'),
            config('constant.PROJECT_ACTION.initiation')
        ];
        $projects = Project::with('ResourceRequisition', 'currentBookings', 'ProjectUsers')
                ->whereNotIn('status', $blockProjectStatus)
                ->where('is_draft', 0)->get();
        $count = 0;
        // $buHeads = Helpers::getAllBUHeads();
        // $result = Helpers::getKekaData();
        foreach ($projects as $project) {
            $projectId = $project->uuid;
            $deAllocationMappingObj = [];
            $idsArray = [];
            // $currentBookings = isset($project['currentBookings']) ? $project['currentBookings'] : [];
            // $ProjectUsers =  isset($project['ProjectUsers']) ? $project['ProjectUsers'] : [];
            foreach ($project['ResourceRequisition'] as $ResourceRequisition) {
                $requisitionId = $ResourceRequisition->uuid;
                foreach ($ResourceRequisition['resourceAllocation'] as $resourceAllocation) {
                    $allocationId = $resourceAllocation->uuid;
                    $lastDay = Carbon::now()->subDay(1);
                    $lastDay = Carbon::parse($lastDay);
                    foreach ($resourceAllocation['resourceAllocationMeta'] as $resourceAllocationMeta) { //all resource allocation meta recourds here
                        $second = Carbon::parse($resourceAllocationMeta->end_date);
                        if (strtotime($second) <= strtotime($lastDay)) { //check resource last date is equal or not with (current date -1)
                            $count++;
                            $allocationMetaId = $resourceAllocationMeta->uuid;
                            $resourceAllocationMeta = $resourceAllocationMeta;
                            $data['start_date'] = Carbon::now()->format('Y-m-d');
                            $data['hours'] = $resourceAllocationMeta->hours;
                            ResourceAllocationMeta::fullyDeallocateResource($allocationId, $allocationMetaId);
                            $isAllDeallocate = ResourceAllocationMeta::where('allocated_resources_uuid', $allocationId)
                                ->get();
                            if (!isset($isAllDeallocate[0])) {
                                ResourceAllocation::updateResourceAllocationTableData(
                                    $allocationId,
                                    $adminId,
                                    config('constant.PROJECT_ACTION')['resource_de_allocation_response_accept']
                                );
                            }
                            if ($project['status'] == config('constant.PROJECT_ACTION')['resource_mapping']) {
                                $isAllResourcesDeallocate = $this->checkIsAllResourceDeallocateInProject($projectId);
                                if ($isAllResourcesDeallocate) {
                                    $statusId = config('constant.PROJECT_ACTION')['resource_de_allocation_response_accept'];
                                    Project::where('uuid', $projectId)->update(array('status' => $statusId));
                                }
                            }
                            // for insert DeAllocation Mapping record
                            $status = 1;
                            $deAllocationMapping = DeAllocationMapping::storeDeAllocationMapping($resourceAllocationMeta, $projectId, $data,null, $status);
                            Log::info(['DeAllocation Mapping Data', $deAllocationMapping]);
                            if(!in_array($deAllocationMapping->resource_id, $idsArray)){
                                $deAllocationMappingObj[] = $deAllocationMapping;
                                 $idsArray[] = $deAllocationMapping->resource_id;
                            }
                        }
                    }
                }
            }
             //here on deallocation rm change code
            // $allProjectResource = $this->getAllProjectResource($currentBookings, $ProjectUsers);
            // $allData = $this->updateResourceManagersOfDeallocatedResources($deAllocationMappingObj, $result, $buHeads, $project, $allProjectResource);
            // $AllDataForUpdate = [];
            // $AllResourceIdForUpdate = [];
            // foreach ($allData['data'] as $resource){
            //     if(!in_array($resource->resource_id, $allData['allBuHeadAssignedArray']) && in_array($resource->resource_id, $allData['allAMPMAssignedArray'])){
            //         $AllDataForUpdate[] = $resource;
            //         $AllResourceIdForUpdate[] = $resource->resource_id;
            //     }
            // }
            // Log::info(['deAllocation Mapping', $AllDataForUpdate]);
            // $this->updateReportingManager($AllDataForUpdate, $AllResourceIdForUpdate, $projectId, null);
        }
        $this->info('success');
    }

    /**
     * Check Is All Resources deallocated in Project
     */
    protected function checkIsAllResourceDeallocateInProject($projectId)
    {
        $response = true;
        $projectDetails = Project::where('uuid', $projectId)
            ->with(['ResourceRequisition'])
            ->first();
        if (isset($projectDetails)) {
            foreach ($projectDetails['ResourceRequisition'] as $key => $value) {
                foreach ($value['ResourceAllocation'] as $index => $element) {
                    if ($element['allocation_status'] != config('constant.PROJECT_ACTION')['resource_de_allocation_response_accept']) {
                        $response = false;
                        return $response;
                    }
                }
            }
        }
        return $response;
    }
}