<?php

namespace App\Console\Commands;

use Helpers;
use Illuminate\Console\Command;
use App\User;
use App\Models\LocalUser;
use Illuminate\Support\Facades\DB;
use App\Models\CronLog;
use Log;

class MergeRedmineUsers extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'get-redmine-users:fetch';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Fetch redmine users and store those users to local_users tabe';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $cronName = 'get-redmine-users';

        $user = User::select(
            'users.id as id',
            'login',
            'hashed_password',
            'firstname',
            'lastname',
            'admin',
            'status',
            'last_login_on',
            'language',
            'auth_source_id',
            'type',
            'identity_url',
            'mail_notification',
            'salt',
            'must_change_passwd',
            'accept_agreement_at',
            DB::raw("CONCAT(firstname,' ',lastname) as full_name"),
            DB::raw("(select value from custom_values where customized_id = users.id and custom_field_id = 15) as employee_id")
        )
            ->with('emailAddresse')
            ->get();
        $userDetails = $this->mapJobProfileWithUser($user);

        $userArray = [];

        foreach ($userDetails as $requestData) {

            $userData = [
                "user_id" => $requestData['id'],
                "login" => $requestData['login'],
                "hashed_password" => $requestData['hashed_password'],
                "firstname" => $requestData['firstname'],
                "lastname" => $requestData['lastname'],
                "full_name" => $requestData['full_name'],
                "email" => $requestData['emailAddresse']['address'],
                "job_title" => $requestData['job_title'],
                "employee_id" => $requestData['employee_id'],
                "admin" => $requestData['admin'],
                "status" => $requestData['status'],
                "language" => $requestData['language'],
                "is_default" => $requestData['emailAddresse']['is_default'],
                "notify" => $requestData['emailAddresse']['notify'],
                "auth_source_id" => $requestData['auth_source_id'],
                "type" => $requestData['type'],
                "identity_url" => $requestData['identity_url'],
                "mail_notification" => $requestData['mail_notification'],
                "salt" => $requestData['salt'],
                "must_change_passwd" => $requestData['must_change_passwd'],
                "accept_agreement_at" => $requestData['accept_agreement_at'],
            ];
            if (isset($userData)) {
                $user = LocalUser::updateOrCreate(['user_id' => $requestData['id']], $userData);
            }
        }
        $is_exist = CronLog::where('name', $cronName)->first();
        $cron = new CronLog();
        $cron->name = $cronName;
        if (!empty($is_exist)) {
            $is_exist->touch();
        } else {
            $cron->save();
        }
        Log::info('get-redmine-users:fetch success');
    }

    public function mapJobProfileWithUser($users)
    {
        $data = [];
        $result = Helpers::getKekaData();
        foreach ($users as $user) {
            foreach ($result as $key => $value) {
                if (trim($value['employeeNumber']) == trim($user['employee_id']) || trim($value['email']) == trim($user['email'])) {
                    $user->job_title = isset($value['jobTitle']['title']) ? $value['jobTitle']['title'] : '';
                    $data[] = $user;
                }
            }
        }
        return $data;
    }
}
