<?php

namespace App\Console\Commands;

use App\Models\CustomValueApi;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Mail;
use Successive\Keka\Http\Services\EmployeeService;
use Helpers;
use Log;


class AddCustomApisResponseDB extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'custom-api-response-request:reminder';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'add all custom apis response in DB';

    /**
     * Create a new command instance.
     *
     * @return void
     */

    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle(){

        $employeeService = new EmployeeService();
        $response = $employeeService->getEmployees(['pagesize' => config('constant.PAGE_SIZE_OF_KEKA')]);
        $dataArray = json_decode($response, true);
        if(isset($dataArray[0]['employeeNumber'])){
        $data = [
            'custom_field_api_id'=>1,
            'values'=>$response
        ];
        $customValue = CustomValueApi::where('custom_field_api_id', 1)->first();
        if($customValue){
        $result = CustomValueApi::where('custom_field_api_id', 1)->update($data);
        }else{
        $result = CustomValueApi::create($data);
        }
      }
      Log::info(['Keka_Response', $response,count($dataArray)]);
      $this->info('success');
    }
}
