<?php

namespace App\Console\Commands;

use App\ResourceBooking;
use Illuminate\Console\Command;
use Log;
use Carbon\Carbon;
use Helpers;

class ResourceDeleteRedmineCron extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'resource-delete-redmine:reminder';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Run cron next day except sat and sunday';
    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $previousDay = Carbon::now()->subDays(config('constant.CRON_DAYS.one_day'));
        $fiveDay = Carbon::now()->subDays(5);
        $dataByProject = [];
        $resources = ResourceBooking::with('user', 'project', 'userProjects')
            ->whereDate('end_date', '>=', $fiveDay)
            ->whereDate('end_date', '<=', $previousDay)
            ->get();
        $previousDay = Carbon::parse($previousDay);
        foreach ($resources as $resource) {
            $endDay = Carbon::parse($resource->end_date);
            $day = Carbon::parse($resource->end_date)->format('D');
            if ($day == 'Fri') {
                $nextDay = Carbon::parse($resource->end_date)->addDays(3);
            }else{
                $nextDay = Carbon::parse($resource->end_date)->addDays(1);
            }
            if ($resource['user']) {
                if(!$this->reBookedCheck($resource->assigned_to_id, $resource->project_id, $nextDay)) {
                         $this->getMemberRoles($resource['userProjects'], $resource->project_id);
                }
            }
        }
        Log::info('success');
    }

    public function getMemberRoles($userProjects, $projectId){
        // here write code to check role
        if(isset($userProjects)){
            $excludeMember = [3,15,14];
            $flag=true;
            foreach ($userProjects as $assignedProject){
                if($assignedProject->project_id == $projectId){
                    foreach($assignedProject['memberRole'] as $member){
                        if(in_array($member->role_id,$excludeMember)){
                            $flag = false;
                        }
                    }
                    if($flag){
                       Log::info([json_encode($assignedProject->id), json_encode($assignedProject)]);
                       $result=Helpers::callAPI('DELETE','/memberships/'.$assignedProject->id.'.json',$data=[]);
                       Log::info(['Project_Membership_Delete_API_CRON',json_encode($result)]);
                       return $result;
                    }
                }
            }
        }
    }
    public function reBookedCheck($resourceId, $projectId, $nextDay){
         $endedCheck = ResourceBooking::where('assigned_to_id', $resourceId)
            ->where('project_id', $projectId)
            ->whereDate('end_date', '>=', $nextDay)
            ->first();
        return $endedCheck;
    }
}
