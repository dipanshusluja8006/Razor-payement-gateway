<?php

namespace App\Console\Commands;

use App\Libraries\MailService;
use App\Models\Project;
use Illuminate\Console\Command;
use App\Models\ResourceAllocationMeta;
use App\Models\ResourceMapping;
use App\ResourceBooking;
use Helpers;
use Log;
use Carbon\Carbon;
use DateTime;



class AutoExtensionCron extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'auto-extension:resources';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'auto extension resources for 30 days';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */

    public function handle()
    {
        $adminId = Helpers::getUserIdByGlobalRole(config('constant.ROLES.admin'));
        $data = [];
        $blockProjectStatus = [
            config('constant.PROJECT_ACTION.initiation_request'),
            config('constant.PROJECT_ACTION.initiation'),
            config('constant.PROJECT_ACTION.project_closure_checklist'),
            config('constant.PROJECT_ACTION.project_on_hold_request_accept')
        ];
        $projects = Project::with('currentBookings', 'ProjectUsers')
                ->whereNotIn('status', $blockProjectStatus)
                ->where('is_draft', 0)->get();
        $count = 0;
        foreach ($projects as $project) {
            $projectId = $project->uuid;
            $deAllocationMappingObj = [];
            $idsArray = [];
            $currentBookings = isset($project['currentBookings']) ? $project['currentBookings'] : [];
            $ProjectUsers =  isset($project['ProjectUsers']) ? $project['ProjectUsers'] : [];
            foreach ($project['ResourceRequisition'] as $ResourceRequisition) {
                $requisitionId = $ResourceRequisition->uuid;
                $deptName = $ResourceRequisition['department']->name;
                foreach ($ResourceRequisition['resourceAllocation'] as $resourceAllocation) {
                    $allocationId = $resourceAllocation->uuid;
                    $lastDay = Carbon::now()->subDay(1);
                    $lastDay = Carbon::parse($lastDay);
                    foreach ($resourceAllocation['resourceAllocationMeta'] as $resourceAllocationMeta) { //all resource allocation meta recourds here
                        if( isset($resourceAllocationMeta['resource']->status) &&
                             $resourceAllocationMeta['resource']->status == config('constant.REDMINE_USERSTATUS.activeUser')) {
                            $second = Carbon::parse($resourceAllocationMeta->end_date);
                            if ($second->isSameDay($lastDay)) { //check resource last date is equal or not with (current date -1)
                                $count++;
                                 $allocationMetaId = $resourceAllocationMeta->uuid;
                                $resourceAllocationMeta = $resourceAllocationMeta;
                                $data['start_date'] = Carbon::now()->format('Y-m-d');
                                $data['hours'] = $resourceAllocationMeta->hours;
                                $updatedLastDay = $second->addDays(30)->format('Y-m-d');
                                $allocated_resources_uuid = $resourceAllocationMeta->allocated_resources_uuid;
                                $futureBookingDate = ResourceBooking::where('assigned_to_id', $resourceAllocationMeta->resource_id)
                                  ->whereDate('start_date', '>=', Carbon::now())
                                  ->whereDate('start_date', '<', $updatedLastDay)
                                  ->orderBy('start_date', 'asc')
                                  ->pluck('start_date')->first();
                                  if(isset($futureBookingDate)){
                                    $futureBookingDate = Carbon::parse($futureBookingDate);
                                    if ($futureBookingDate->isSameDay(Carbon::now())) {
                                          break;
                                    }
                                  }
                                ResourceAllocationMeta::updateDeallocateResourceMetaCron($resourceAllocationMeta->resource_id,$resourceAllocationMeta->end_date,$allocationId, $updatedLastDay, $allocationMetaId);
                                ResourceMapping::updateMappingData($resourceAllocationMeta->resource_id,$resourceAllocationMeta->end_date,$allocated_resources_uuid, $updatedLastDay);
                                $projectData = Project::with(['accountManagers', 'projectManagers'])->where('uuid', $projectId)->first();
                                $projectName = $projectData->project_name;
                                $redmineProjectID = $projectData['redmine_project_id'];
                                if ($redmineProjectID == null || $redmineProjectID == '') {
                                    $redmineProjectID = Helpers::projectIDRedmine($projectName);
                                }
                                
                                $bookingID = ResourceBooking::where('assigned_to_id', $resourceAllocationMeta->resource_id)
                                    ->whereDate('start_date', $resourceAllocationMeta->start_date)
                                    ->whereDate('end_date', $resourceAllocationMeta->end_date)
                                    ->orderBy('start_date', 'asc')
                                    ->pluck('id')->first();
                                    
                                    if (isset($bookingID)) {
                                    $response = $this->UpdateRedmineBooking($resourceAllocationMeta->resource_id,$resourceAllocationMeta->end_date,$resourceAllocationMeta->start_date,$resourceAllocationMeta->hours,$bookingID, $deptName,$projectName,$updatedLastDay);
                                    $request='';
                                     Helpers::addlogActivityDB($projectId,$request, $response, config('constant.LOG_ACTIONS.project_auto_extension'));
                                     Log::info(Helpers::addToLog($projectId,$request, $response, config('constant.LOG_ACTIONS.project_auto_extension')));
                                    }
                                $amArray = $this->getAMEmailID($projectData['accountManagers']);
                                $pmArray = $this->getPMEmailID($projectData['projectManagers']);
                                if (count($amArray) > 0 && count($pmArray) > 0) {
                                    $mailTo = array_merge($amArray, $pmArray);
                                    $this->bookingExtensionMailToAM_PM($response,$resourceAllocationMeta->resource_id, $mailTo, $projectName);
                                }
                            }
                        }
                    }
                }
            }
        }
        $this->info('Auto_Extension_success');
        $todayDay = Carbon::now()->format('D');
        if ($todayDay != 'Sat' || $todayDay != 'Sun') {
        $this->deleteRedmineMember();
        $this->info('Delete Redmine Member');
        }
    }
    public function UpdateRedmineBooking($resource_id,$endDate,$startDate,$hours,$bookingID, $department,$projectName,$updatedDate){
            $futureBookingDetails = ResourceBooking::where('assigned_to_id', $resource_id)
            ->whereDate('start_date', '>', Carbon::now())
            ->whereDate('start_date', '<=', $updatedDate)
            ->orderBy('start_date', 'asc')
            ->first(); 
            $futureBookingDate='';
            $futureBookingEndDate ='';
            $futureBookingProject ='';
            $futureBookingHours ='';
            $finalArray = [];
        if(isset($futureBookingDetails)){
            $futureBookingDate = $futureBookingDetails['start_date'];
            $futureBookingEndDate = $futureBookingDetails['end_date'];
            $futureBookingProject = $futureBookingDetails['project_id'];
            $futureBookingHours = $futureBookingDetails['hours_per_day'];
            $bookingendDate = Carbon::createFromFormat('Y-m-d', $endDate);
            $datetime1=Carbon::parse($bookingendDate);
            $datetime2=Carbon::parse($futureBookingDate);
            $finaldaysToAdd = $datetime1->diffInDays($datetime2);
            $date = $bookingendDate->addDays($finaldaysToAdd);
            $response =  ResourceBooking::where('id', $bookingID)->update(['end_date'=>$date]);
         }else{
             $finaldaysToAdd=30;
             $futureBookingDate = $startDate;
             $bookingendDate = Carbon::createFromFormat('Y-m-d', $endDate);
             $date = Carbon::createFromFormat('Y-m-d', $updatedDate);
             $response =  ResourceBooking::where('id', $bookingID)->update(['end_date'=>$date]);
         }
        if($response){
            $finalArray=[
                'futureBookingDate'=>$futureBookingDate,
                'futureBookingEndDate'=>$futureBookingEndDate,
                'futureBookingProject'=>$futureBookingProject,
                'futureBookingHours'=>$futureBookingHours,
                'endDate'=>$bookingendDate,
                'hours'=>$hours,
                'date'=>$date->format('Y-m-d'),
                'finaldaysToAdd'=>$finaldaysToAdd,
                'resourceName'=>Helpers::getUserName($resource_id),
                'department' =>$department,
                'projectName'=>$projectName,
                'PlanedEndDate'=>$endDate
            ];
            return $finalArray;
        }else{
            return $finalArray;
        }
    }

    public function getAMEmailID($accountManagersDetails){
        $amMailID=[];
        if(count($accountManagersDetails) > 0){
             foreach($accountManagersDetails as $val){
                 if($val['User']['status']==1){
                 array_push($amMailID,$val['User']['email']);
                 }
             }
        }
        return $amMailID;
    }

    public function getPMEmailID($projectManagersDetails){
        $pmMailID=[];
        if(count($projectManagersDetails) > 0){
             foreach($projectManagersDetails as $val){
                 if($val['User']['status']==1){
                 array_push($pmMailID,$val['User']['email']);
                 }
             }
        }
        return $pmMailID;
    }
    public function bookingExtensionMailToAM_PM($response,$resource_id,$mailTo,$projectName){
        $resourceName = Helpers::getUserName($resource_id);
        $finaldaysToAdd = $response['finaldaysToAdd'];
        $resource_start_date = $response['endDate']->addDays(1)->format('Y-m-d');
        $resource_end_date = $response['date'];
        $futureBookingStartDate = Carbon::parse($response['futureBookingDate'])->format('Y-m-d');
        $futureBookingEndDate = Carbon::parse($response['futureBookingEndDate'])->format('Y-m-d');
        $hours = $response['hours'];
        $employeeCode = \Helpers::getEmployeeCode($resource_id);
        $employeeEmail = \Helpers::getUserEmail($resource_id);
        $department = $response['department'];
        $futureBookingHours = $response['futureBookingHours'];
        $futureBookingProject = \Helpers::getProjectNameRedmine($response['futureBookingProject']);
        $mailData['template']['subject'] = "Resource Auto Booking extension";
        $bookingText ="";
        if($finaldaysToAdd==30){
            $bookingText = "<p>Hi There,</p><p>The below mentioned resource has been extended for $finaldaysToAdd days and $hours hours in <b>$projectName</b> project ,please find details below:</p></br><table width='100%' cellspacing='0' cellpadding='4' border='1px solid grey'><tr align='left' bgcolor='#41337C'><tr align='left' bgcolor='#41337C'><th><font color='#fff'>Resource Name</font></th><th><font color='#fff'>Employee Code</font></th><th><font color='#fff'>Employee Email</font></th><th><font color='#fff'>Department</font></th><th><font color='#fff'>Hours</font></th><th><font color='#fff'>Extension Start Date</font></th><th><font color='#fff'>End Date</font></th></tr><tr><td>$resourceName</td><td>$employeeCode</td><td>$employeeEmail</td><td>$department</td><td>$hours</td><td>$resource_start_date</td><td>$resource_end_date</td></tr></table><p><span>NOTE: This is a system-generated email</span><p/><p><span><b>Thanks and Regards</b></span><p/><p><span><b>Successive Technologies</b></span></p>"; 
        }else{
            $bookingText = "<p>Hi There,</p><p>The below mentioned resource has been extended for $finaldaysToAdd days and $hours hours in <b>$projectName</b> project.The resource is due to start their next allocation in the <b>$futureBookingProject</b> project ,please find details below:</p></br><table width='100%' cellspacing='0' cellpadding='4' border='1px solid grey'><tr align='left' bgcolor='#41337C'><tr align='left' bgcolor='#41337C'><th><font color='#fff'>Resource Name</font></th><th><font color='#fff'>Employee Code</font></th><th><font color='#fff'>Employee Email</font></th><th><font color='#fff'>Department</font></th><th><font color='#fff'>Hours</font></th><th><font color='#fff'>Future Booking Start Date</font></th><th><font color='#fff'>Future Booking End Date</font></th></tr><tr><td>$resourceName</td><td>$employeeCode</td><td>$employeeEmail</td><td>$department</td><td>$futureBookingHours</td><td>$futureBookingStartDate</td><td>$futureBookingEndDate</td></tr></table><p><span>NOTE: This is a system-generated email</span><p/><p><span><b>Thanks and Regards</b></span></p><p><span><b>Successive Technologies</b></span></p>";
        }
        $mailData['template']['template'] =$bookingText;
        Helpers::sendAutoExtensionMail($mailData, $mailTo);
        Log::info([$mailTo, json_encode($mailData)]);
    }

    //Delete Redmine Member Function
    public function deleteRedmineMember(){
        $previousDay = Carbon::now()->subDays(config('constant.CRON_DAYS.one_day'));
        $fiveDay = Carbon::now()->subDays(5);
        $dataByProject = [];
        $resources = ResourceBooking::with('user', 'project', 'userProjects')
            ->whereDate('end_date', '>=', $fiveDay)
            ->whereDate('end_date', '<=', $previousDay)
            ->get();
        $previousDay = Carbon::parse($previousDay);
        foreach ($resources as $resource) {
            $endDay = Carbon::parse($resource->end_date);
            $day = Carbon::parse($resource->end_date)->format('D');
            if ($day == 'Fri') {
                $nextDay = Carbon::parse($resource->end_date)->addDays(3);
            }else{
                $nextDay = Carbon::parse($resource->end_date)->addDays(1);
            }
            if ($resource['user']) {
                if(!$this->reBookedCheck($resource->assigned_to_id, $resource->project_id, $nextDay)) {
                         $this->getMemberRoles($resource['userProjects'], $resource->project_id);
                }
            }
        }
        Log::info('success');
    }

    public function getMemberRoles($userProjects, $projectId){
        // here write code to check role
        if(isset($userProjects)){
            $excludeMember = [3,15,14];
            $flag=true;
            foreach ($userProjects as $assignedProject){
                if($assignedProject->project_id == $projectId){
                    foreach($assignedProject['memberRole'] as $member){
                        if(in_array($member->role_id,$excludeMember)){
                            $flag = false;
                        }
                    }
                    if($flag){
                       Log::info([json_encode($assignedProject->id), json_encode($assignedProject)]);
                       $result=Helpers::callAPI('DELETE','/memberships/'.$assignedProject->id.'.json',$data=[]);
                       Log::info(['Project_Membership_Delete_API_CRON',json_encode($result)]);
                       return $result;
                    }
                }
            }
        }
    }
    public function reBookedCheck($resourceId, $projectId, $nextDay){
         $endedCheck = ResourceBooking::where('assigned_to_id', $resourceId)
            ->where('project_id', $projectId)
            ->whereDate('end_date', '>=', $nextDay)
            ->first();
        return $endedCheck;
    }
}
