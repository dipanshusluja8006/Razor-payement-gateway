<?php

namespace App;
use Illuminate\Database\Eloquent\Model;
use Helpers;
use Carbon\Carbon;
use Awobaz\Compoships\Compoships;
use Illuminate\Support\Facades\DB;

class Member extends Model {

    /**
     * The table associated with the model.
     *
     * @var string
     */
    use Compoships;
    protected $connection="redmine_db_mysql";
    protected $fillable = [

        'id',
        'user_id',
        'project_id',
        'created_on',
        'mail_notification',
        'dmsf_mail_notification',
        'dmsf_title_format',
        'dmsf_fast_links'
    ];

    public function MemberRole()
    {
        return $this->hasMany('App\MemberRole', 'member_id', 'id')->with('Role');
    }

    public function User()
    {
        return $this->hasOne('App\User', 'id', 'user_id')
            ->select('id', DB::raw("CONCAT(firstname,' ',lastname) as display_name"), DB::raw("(select address from email_addresses where users.id  =   user_id) as email"),'status');

    }

}
