<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Support\Facades\Mail;
use App\Mail\SendMailable;
use App\Mail\TimeSheetReminderMail;
use App\Mail\InvoiceReminderMail;
use App\Mail\ResourceMailable;
use App\Mail\ResourceDeAllocationMail;
use App\Mail\BenchResourceMail;

class QueueJob implements ShouldQueue
{
    use InteractsWithQueue, Queueable, SerializesModels;

    public $mergedArray;
    public $mailData;
    public $mergedArrayCC;
    public $key;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($mergedArray,$mailData,$key = false,$mergedArrayCC=[])
    {
        $this->mergedArray = $mergedArray;
        $this->mailData = $mailData;
        $this->mergedArrayCC = $mergedArrayCC;
        $this->key = $key;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {

        if($this->key==config('constant.QUEUEJOB.ResourceMailable')) {
            Mail::to($this->mergedArray)
            ->cc($this->mergedArrayCC)
            ->send(new ResourceMailable($this->mailData));
        }
        if($this->key==config('constant.QUEUEJOB.TimeSheetReminderEmail')) {
            Mail::to($this->mergedArray)
                ->cc($this->mergedArrayCC)
                ->send(new TimeSheetReminderMail($this->mailData));
        }
        if($this->key==config('constant.QUEUEJOB.InvoiceReminderEmail')) {
            Mail::to($this->mergedArray)
                ->cc($this->mergedArrayCC)
                ->send(new InvoiceReminderMail($this->mailData));
        }
    }
}
