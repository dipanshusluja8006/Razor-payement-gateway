<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Awobaz\Compoships\Compoships;

class Role extends Model {

    /**
     * The table associated with the model.
     *
     * @var string
     */
    use Compoships;
    protected $connection="redmine_db_mysql";
    protected $fillable = [

        'id',
        'name',
        'position',
        'assignable',
        'builtin',
        'permissions',
        'issues_visibility',
        'users_visibility',
        'time_entries_visibility',
        'all_roles_managed',
        'settings'
    ];


}
