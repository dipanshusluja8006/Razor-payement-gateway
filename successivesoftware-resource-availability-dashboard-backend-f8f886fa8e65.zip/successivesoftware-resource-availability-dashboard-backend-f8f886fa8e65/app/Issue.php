<?php

namespace App;
use Illuminate\Database\Eloquent\Model;
use Helpers;
use Carbon\Carbon;
use Awobaz\Compoships\Compoships;
use Illuminate\Support\Facades\DB;

class Issues extends Model {

    /**
     * The table associated with the model.
     *
     * @var string
     */
    use Compoships;
    protected $connection="redmine_db_mysql";
    protected $fillable = [
        'id',
        'tracker_id',
        'project_id',
        'subject',
        'description',
        'due_date',                                                                                                                                                                                                                                                                                                                                                                                       
        'category_id',          
        'status_id',
        'assigned_to_id',  
        'priority_id',  
        'fixed_version_id',  
        'author_id',  
        'lock_version',  
        'created_on',  
        'updated_on',           
        'start_date',           
        'done_ratio',                                                  
        'estimated_hours',  
        'parent_id',  
        'root_id',            
        'lft',  
        'rgt',    
        'is_private',  
        'closed_on',  
        'sprint_id',  
        'position'
    ];

    public function riskAsssignedTo()
    {
        return $this->hasOne('App\User', 'id', 'assigned_to_id')
        ->select('id', DB::raw("CONCAT(firstname,' ',lastname) as display_name"));
    }

    public function probability()
    {
        return $this->hasOne('App\CustomValue', 'customized_id', 'id')->where('custom_field_id','=',46);
    }

    public function impact()
    {
        return $this->hasOne('App\CustomValue', 'customized_id', 'id')->where('custom_field_id','=',47);
    }

    public function riskCategory()
    {
        return $this->hasOne('App\CustomValue', 'customized_id', 'id')->where('custom_field_id','=',52);
    }

}
