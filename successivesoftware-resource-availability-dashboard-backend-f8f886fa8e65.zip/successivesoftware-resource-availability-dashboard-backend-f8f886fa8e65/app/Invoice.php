<?php

namespace App;
use Illuminate\Database\Eloquent\Model;
use Helpers;
use Carbon\Carbon;
use Awobaz\Compoships\Compoships;
use Illuminate\Support\Facades\DB;

class Invoice extends Model {

    /**
     * The table associated with the model.
     *
     * @var string
     */
    use Compoships;
    protected $connection="redmine_db_mysql";
    protected $fillable = [
        'id',
        'number',
        'invoice_date',
        'discount',
        'discount_type',
        'description',                                                                                                                                                                                                                                                                                                                                                                                       
        'due_date',          
        'language',
        'currency',  
        'status_id',  
        'contact_id',  
        'project_id',  
        'assigned_to_id',  
        'author_id',  
        'created_at',           
        'updated_at',           
        'subject',                                                  
        'amount',  
        'comments_count',  
        'paid_date',            
        'balance',  
        'type',    
        'order_number',  
        'template_id',  
        'is_recurring',  
        'recurring_period',  
        'recurring_occurrences',  
        'recurring_action',  
        'recurring_profile_id',  
        'recurring_number',
    ];

}
