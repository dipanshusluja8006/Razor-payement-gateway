<?php

namespace App\Traits;

use App\Libraries\MailService;
use App\Models\DeAllocationMapping;
use App\Models\ReportingManager;
use App\Models\ResourceAllocationMeta;
use App\Models\ResourceMapping;
use App\Models\ResourceRequisition;
use App\Models\PerformedActionLog;
use App\Models\Project;
use App\Models\ResourceAllocation;
use App\Models\ProjectAction;
use Helpers;
use Log;
use ApiResponse;
use Webpatser\Uuid\Uuid;
use Carbon\Carbon;

trait ResourceControllerTraits
{
    protected function updateProjectStatusAccordingResources($projectId, $requisition = false)
    {
        $projectStatus = false;
        $projectDetails = Project::where('uuid', $projectId)->first();
        $isAllocationPending = ResourceRequisition::where([
            'project_id' => $projectId,
            'status' => '0'
        ])->first();
        if (!isset($isAllocationPending)) {
            if ($requisition) {
                $requisitionExist = ResourceRequisition::where(['project_id' => $projectId, 'status' => '1'])->first();
                if (isset($requisitionExist)) {
                    $isMappingPending = $this->getMappingPendingResponse($projectId);
                    if ($isMappingPending) {
                        $projectStatus = config('constant.PROJECT_ACTION')['resource_allocation_response_accept'];
                    } else {
                        PerformedActionLog::where(['project_id' => $projectId, 'user_action_id' => config('constant.USER_ACTIONLIST')['resource-requisition']])->update(['status' => config('constant.PERFORM_ACTIONLOG.completed')]);
                        PerformedActionLog::storePerformedActionLog($projectId, config('constant.USER_ACTIONLIST')['resource-mapping'], config('constant.PERFORM_ACTIONLOG.completed'));
                        $this->undoResourceAllocationLog($projectId);
                        if ($this->checkIsAllResourceDeallocateInProject($projectId)) {
                            PerformedActionLog::storePerformedActionLog($projectId, config('constant.USER_ACTIONLIST')['resource-deallocation-resource-manager'], config('constant.PERFORM_ACTIONLOG.completed'));
                            $projectStatus = config('constant.PROJECT_ACTION')['resource_de_allocation_response_accept'];
                        } else {
                            $projectStatus = config('constant.PROJECT_ACTION')['resource_mapping'];
                        }
                    }
                } else {
                    $projectStatus = config('constant.PROJECT_ACTION')['creation'];
                }
            } else {
                $projectStatus = config('constant.PROJECT_ACTION')['resource_allocation_response_accept'];
            }
        } else {
            $isRequestStatusExists = $this->checkAllocationStatusExistInResources($projectId, config('constant.PROJECT_ACTION')['resource_allocation_request']);
            $isAllocationDoneAgainstRequisition = $this->checkAllocationDoneAgainstRequisition($projectId);
            if (!$isAllocationDoneAgainstRequisition) {
                $projectStatus =  config('constant.PROJECT_ACTION')['resource_requisition_request'];
                $deptArray = $this->pendingRequisitionDepartment($projectId);
                PerformedActionLog::where(['project_id' => $projectId, 'user_action_id' => config('constant.USER_ACTIONLIST.resource-allocation')])->whereIn('dept_id', $deptArray)->delete();
            } else if ($projectDetails['status'] == config('constant.PROJECT_ACTION')['resource_allocation_response_decline']) {
                if ($this->checkAllocationStatusExistInResources($projectId, config('constant.PROJECT_ACTION')['resource_allocation_response_decline'])) {
                    $projectStatus =  config('constant.PROJECT_ACTION')['resource_allocation_response_decline'];
                } else if ($isRequestStatusExists) {
                    $projectStatus =  config('constant.PROJECT_ACTION')['resource_allocation_request'];
                }
            } else if ($isRequestStatusExists) {
                $projectStatus =  config('constant.PROJECT_ACTION')['resource_allocation_request'];
            } else if ($this->checkAllocationStatusExistInResources($projectId, config('constant.PROJECT_ACTION')['resource_allocation_response_decline'])) {
                $projectStatus =  config('constant.PROJECT_ACTION')['resource_allocation_response_decline'];
            }
        }
        if ($projectStatus) {
            Project::where('uuid', $projectId)->update(array('status' => $projectStatus));
        }
    }

    protected function fetchAllNotRequiredActionOfProject($projectId, $userProjectRole, $userId)
    {
        $rolesArray = Helpers::getRoleByModel('Role');
        $response = [
            config('constant.USER_ACTIONLIST')['resource-allocation-manager'],
            config('constant.USER_ACTIONLIST')['resource-reallocation'],
            config('constant.USER_ACTIONLIST')['resource-mapping'],
            config('constant.USER_ACTIONLIST')['resource-modification'],
            config('constant.USER_ACTIONLIST')['resource-deallocation-resource-manager'],
            config('constant.USER_ACTIONLIST')['edit-requisition'],
            config('constant.USER_ACTIONLIST')['resource-allocation'],
            config('constant.USER_ACTIONLIST')['initiation-request'],
            config('constant.USER_ACTIONLIST')['initiation-approval']
        ];
        $projectResourceDetails = Project::where('uuid', $projectId)->with('ResourceRequisition')->first();
        foreach ($projectResourceDetails['ResourceRequisition'] as $requisition) {
            if (count($requisition['ResourceAllocation']) == 0) {
                    if (($key = array_search(config('constant.USER_ACTIONLIST')['edit-requisition'], $response)) !== false) {
                        unset($response[$key]);
                    }
                if (
                    in_array($rolesArray[config('constant.ROLES.admin')], $userProjectRole['global']) ||
                    in_array($requisition['dept_id'], $userProjectRole['department'])
                ) {
                    if (($key = array_search(config('constant.USER_ACTIONLIST')['resource-allocation'], $response)) !== false) {
                        unset($response[$key]);
                    }
                }
            }
            foreach ($requisition['ResourceAllocation'] as $allocation) {
                if ($allocation['allocation_status'] == config('constant.PROJECT_ACTION')['resource_allocation_request']) {
                    if (($key = array_search(config('constant.USER_ACTIONLIST')['resource-allocation-manager'], $response)) !== false) {
                        unset($response[$key]);
                    }
                } else if (
                    (in_array($rolesArray[config('constant.ROLES.admin')], $userProjectRole['global']) && $allocation['allocation_status'] == config('constant.PROJECT_ACTION')['resource_allocation_response_decline']) || (in_array($requisition['dept_id'], $userProjectRole['department']) && $allocation['allocation_status'] == config('constant.PROJECT_ACTION')['resource_allocation_response_decline'])
                ) {
                    if (($key = array_search(config('constant.USER_ACTIONLIST')['resource-reallocation'], $response)) !== false) {
                        unset($response[$key]);
                    }
                }
            }
        }
        if ($this->getFullRequsitionMappingStatus($projectId)) {
            if (($key = array_search(config('constant.USER_ACTIONLIST')['resource-mapping'], $response)) !== false) {
                unset($response[$key]);
            }
        }
        if ($this->getExistingAllocatedResource($projectId)) {
            if (($key = array_search(config('constant.USER_ACTIONLIST')['resource-modification'], $response)) !== false) {
                unset($response[$key]);
            }
        }
        if ($this->isAnyDeallocationUnMappingResourceExists($projectId)) {
            if (($key = array_search(config('constant.USER_ACTIONLIST')['resource-deallocation-resource-manager'], $response)) !== false) {
                unset($response[$key]);
            }
        }
        if($projectResourceDetails->created_by == $userId || in_array($rolesArray[config('constant.ROLES.admin')], $userProjectRole['global'])) {
            if (!(in_array($rolesArray[config('constant.ROLES.sales')], $userProjectRole['global'])
                || in_array($rolesArray[config('constant.ROLES.global_operation')], $userProjectRole['global'])) ||
                in_array($rolesArray[config('constant.ROLES.admin')], $userProjectRole['global'])) {
                if ($projectResourceDetails->status == config('constant.PROJECT_ACTION.initiation_request') &&
                    $projectResourceDetails->is_approve == config('constant.PROJECT_APPROVAL.edit_initiation_request') &&
                    (in_array($rolesArray[config('constant.ROLES.bu_head')], $userProjectRole['global']) ||
                        in_array($rolesArray[config('constant.ROLES.go_team')], $userProjectRole['global']) ||
                        in_array($rolesArray[config('constant.ROLES.admin')], $userProjectRole['global']))
                ) {
                    if (($key = array_search(config('constant.USER_ACTIONLIST')['initiation-request'], $response)) !== false) {
                        unset($response[$key]);
                    }
                }
            }
        }
        if (($projectResourceDetails->status == config('constant.PROJECT_ACTION.initiation_request') && $projectResourceDetails->is_approve == config('constant.PROJECT_APPROVAL.approval_request')) &&
            (in_array($rolesArray[config('constant.ROLES.admin')], $userProjectRole['global']) ||
            in_array($rolesArray[config('constant.ROLES.global_operation')], $userProjectRole['global']))
        ) {
            if (($key = array_search(config('constant.USER_ACTIONLIST')['initiation-approval'], $response)) !== false) {
                unset($response[$key]);
            }
        }

        return $response;
    }

    protected function isAnyDeallocationUnMappingResourceExists($projectId)
    {
        $response = false;
        $deallocation = DeAllocationMapping::where(['project_id' => $projectId, 'status' => config('constant.PERFORM_ACTIONLOG.inProgress')])->first();
        if (isset($deallocation)) {
            $response = true;
        }
        return $response;
    }

    protected function getExistingAllocatedResource($projectId)
    {
        $response = false;
        $mappingDetails = ResourceMapping::where(
            [
                'project_id' => $projectId,
                'status' => config('constant.PERFORM_ACTIONLOG.completed')
            ]
        )->with('fullyAllocation')->has('fullyAllocation')->first();
        if (isset($mappingDetails)) {
            $response = true;
        }
        return $response;
    }

    protected function getFullRequsitionMappingStatus($projectId)
    {
        $response = false;
        $requisitionList = $this->getMappingPendingRequisitionList($projectId);
        if (!empty($requisitionList)) {
            $response = true;
        }
        return $response;
    }

    protected function getMappingPendingResponse($projectId)
    {
        $response = false;
        $mappingDetails = ResourceMapping::where(
            [
                'project_id' => $projectId,
                'status' => '0'
            ]
        )->first();
        if (isset($mappingDetails)) {
            $response = true;
        }
        return $response;
    }

    protected function getMappingPendingRequisitionList($projectId)
    {
        $response = [];
        $mappingDetails = ResourceMapping::where(
            [
                'project_id' => $projectId,
                'status' => '0'
            ]
        )->with('resourceAllocation')->get();
        if (isset($mappingDetails)) {
            foreach ($mappingDetails as $record) {
                if (isset($record['resourceAllocation']['resource_req_id'])) {
                    array_push($response, $record['resourceAllocation']['resource_req_id']);
                }
            }
        }
        return array_unique($response);
    }

    protected function undoResourceAllocationLog($projectId)
    {
        $completeRequisitions = ResourceRequisition::where(['project_id' => $projectId, 'status' => '1'])->get();
        if (isset($completeRequisitions)) {
            foreach ($completeRequisitions as $key => $value) {
                PerformedActionLog::storePerformedActionLog($projectId, config('constant.USER_ACTIONLIST')['resource-allocation'], config('constant.PERFORM_ACTIONLOG.completed'), $value['dept_id']);
            }
        }
    }

    /**
     * Check Is All Resources deallocated in Project
     */
    protected function checkIsAllResourceDeallocateInProject($projectId)
    {
        $response = true;
        $projectDetails = Project::where('uuid', $projectId)
            ->with(['ResourceRequisition'])
            ->first();
        if (isset($projectDetails)) {
            foreach ($projectDetails['ResourceRequisition'] as $key => $value) {
                foreach ($value['ResourceAllocation'] as $index => $element) {
                    if ($element['allocation_status'] != config('constant.PROJECT_ACTION')['resource_de_allocation_response_accept']) {
                        $response = false;
                        return $response;
                    }
                }
            }
        }
        return $response;
    }

    protected function checkAllocationStatusExistInResources($projectId, $statusId)
    {
        $response = false;
        $projectDetails = Project::where('uuid', $projectId)
            ->with(['ResourceRequisition'])
            ->first();
        if (isset($projectDetails)) {
            foreach ($projectDetails['ResourceRequisition'] as $key => $value) {
                foreach ($value['ResourceAllocation'] as $index => $element) {
                    if ($element['allocation_status'] == $statusId) {
                        $response = true;
                        return $response;
                    }
                }
            }
        }
        return $response;
    }

    protected function checkAllocationDoneAgainstRequisition($projectId)
    {
        $response = true;
        $requisition = ResourceRequisition::where(['project_id' => $projectId])->with(['ResourceAllocation'])->get();
        if (isset($requisition[0])) {
            foreach ($requisition as $value) {
                if (!isset($value['ResourceAllocation'][0])) {
                    $response = false;
                    break;
                }
            }
        }
        return $response;
    }

    protected function pendingRequisitionDepartment($projectId)
    {
        $response = [];
        $requisition = ResourceRequisition::where(['project_id' => $projectId])->with(['ResourceAllocation'])->get();
        if (isset($requisition)) {
            foreach ($requisition as $value) {
                if (!isset($value['ResourceAllocation'][0])) {
                    array_push($response, $value['dept_id']);
                }
            }
        }
        return $response;
    }

    /**
     * Check is user have access to change resource allocations status
     */
    protected function checkUserAccessForResourceAllocationOperations($userId, $projectId, $statusId, $departmentId = null)
    {
        $response = true;
        $userRoleAccess = config('constant.RESOURCE_ALLOCATION_USERROLE_ACCESS');
        if (isset($userId) && isset($projectId) && isset($statusId)) {
            $projectRole = Helpers::getRole($userId, $projectId);
            if (in_array(Helpers::getRoleIdByCode(config('constant.ROLES.admin')), $projectRole['global'])) {
                return $response;
            }
            if (!empty($projectRole)) {
                if (array_key_exists($statusId, $userRoleAccess)) {
                    if (
                        $statusId == config('constant.PROJECT_ACTION')['resource_de_allocation_request'] ||
                        $statusId == config('constant.PROJECT_ACTION')['resource_allocation_response_accept'] ||
                        $statusId == config('constant.PROJECT_ACTION')['resource_allocation_response_decline']
                    ) {
                        if (
                            empty(array_intersect($projectRole['project'], $userRoleAccess[$statusId])) &&
                            empty(array_intersect($projectRole['global'], $userRoleAccess[$statusId]))
                        ) {
                            $response = false;
                        }
                    } else if (empty(array_intersect($projectRole['global'], $userRoleAccess[$statusId])) || (isset($departmentId) && !in_array($departmentId, $projectRole['department']))) {
                        $response = false;
                    }
                }
            } else {
                $response = false;
            }
        }
        return $response;
    }

    protected function getRequisitionIdFromAllocatedResourcesUuid($allocatedResourcesUuid)
    {
        $resourceAllocationdata = ResourceAllocation::where('uuid', $allocatedResourcesUuid)
            ->with('resourceRequisition')
            ->firstOrFail();
        return $resourceAllocationdata->resourceRequisition->uuid;
    }

    protected function getDepatmentIdFromAllocatedResourcesUuid($allocatedResourcesUuid)
    {
        $resourceAllocationdata = ResourceAllocation::where('uuid', $allocatedResourcesUuid)
            ->with('resourceRequisition')
            ->firstOrFail();
        return $resourceAllocationdata->resourceRequisition->dept_id;
    }

    protected function getProjectIdFromAllocatedResourcesUuid($uuid)
    {
        $resourceAllocationdata = ResourceAllocation::where('uuid', $uuid)
            ->with('resourceRequisition')
            ->firstOrFail();
        return $resourceAllocationdata->resourceRequisition->project_id;
    }

    /**
     * @param $data
     */
    protected function SaveProjectAction($data)
    {
        $projectAction = [
            'link_id' => $data['uuid'],
            'comment' => $data['comment'],
            'status_id' => $data['status'],
            'requested_by' => $data['requested_by'],
            'previous_status' => $data['previous_status'],
        ];
        $action = ProjectAction::saveProjectAction($projectAction);
    }

    protected function isFullAllocationAgainstAllocatedResource($data)
    {
        $response = true;
        $requisition = ResourceRequisition::where('uuid', $data['resource_req_id'])->first();
        if (
            $data['efforts'] != $requisition['efforts'] ||
            $data['experience'] != $requisition['experience'] ||
            strtotime($data['start_date']) != strtotime($requisition['start_date']) ||
            strtotime($data['end_date']) != strtotime($requisition['end_date'])
        ) {
            $response = false;
        }
        if($requisition['type'] == 1 && $requisition['extension_resource_id'] != null && $data['resource_id'] != $requisition['extension_resource_id']){
            $response = false;
        }
        return $response;
    }

    protected function getAllMappedAllocationIdForProject($projectUuid)
    {
        $mappedIds = ResourceMapping::where(['project_id' => $projectUuid, 'status' => '1'])->pluck('allocated_resource_id')->toArray();
        return $mappedIds;
    }

    protected function editAllocationList($userId, $projectUuid, $show = false)
    {
        $finalResponse = [];
        $userRole = Helpers::getRole($userId, $projectUuid);
        if ($show) {
            $relation = config('constant.RESOURCE_ALLOCATION_RELATION');
        } else {
            $relation = config('constant.EDIT_RESOURCE_ALLOCATION_RELATION');
        }
        $mappingPendingRequisitionList = $this->getMappingPendingRequisitionList($projectUuid);
        $mappedIds = $this->getAllMappedAllocationIdForProject($projectUuid);

        if (in_array($this->rolesArray[config('constant.ROLES.admin')], $userRole['global'])) {
            $response = ResourceRequisition::with([$relation => function ($query) use ($mappedIds) {
                $query->where('allocation_status', '!=', config('constant.PROJECT_ACTION.resource_allocation_response_decline'));
                if(isset($mappedIds)) {
                    $query->whereNotIn('uuid', $mappedIds);
                }
            }, 'technology', 'department', 'designation', 'DirectRequisition', 'resource', 'requestedUser'])
                ->where('project_id', $projectUuid)
                ->where(function ($query) use ($mappingPendingRequisitionList) {
                    $query->where('status', '=', config('constant.PERFORM_ACTIONLOG')['inProgress'])
                        ->orWhereIn('uuid', $mappingPendingRequisitionList);
                })
                ->get();
            $finalResponse = $response;

        } else {
            $response = ResourceRequisition::with([$relation => function ($query) use ($mappedIds) {
                $query->where('allocation_status', '!=', config('constant.PROJECT_ACTION.resource_allocation_response_decline'));
                $query->whereNotIn('uuid',$mappedIds);
            }, 'technology', 'department', 'designation', 'DirectRequisition', 'resource', 'requestedUser'])
                ->where('project_id', $projectUuid)
                ->whereIn('dept_id', $userRole['department'])
                ->where(function ($query) use ($mappingPendingRequisitionList) {
                    $query->where('status', '=', config('constant.PERFORM_ACTIONLOG')['inProgress'])
                        ->orWhereIn('uuid', $mappingPendingRequisitionList);
                })
                ->get();
            if (count($response) > 0) {
                foreach ($response as $key => $requisition) {
                    if (isset($requisition['DirectRequisition'])) {
                        $flag = false;
                        if (!empty($userRole['project']) || in_array($this->rolesArray[config('constant.ROLES.global_operation')], $userRole['global'])) {
                            if (in_array($requisition['dept_id'], $userRole['department'])) {
                                $flag = true;
                            }
                        }
                        if ($flag) {
                            array_push($finalResponse, $requisition);
                        }
                    } else {
                        array_push($finalResponse, $requisition);
                    }
                }
            }
        }
        return $finalResponse;
    }

    protected function getEditAllocationUuidArray($userId, $projectUuid, $requisitionArray)
    {
        $allocationArray = [];
        $response = $this->editAllocationList($userId, $projectUuid);
        if (isset($response)) {
            foreach ($response as $value) {
                if (in_array($value['uuid'], $requisitionArray) && !isset($value['DirectRequisition'])) {
                    foreach ($value['EditResourceAllocation'] as $allocation) {
                        array_push($allocationArray, $allocation['uuid']);
                    }
                }
            }
        }
        return $allocationArray;
    }

    protected function isAnyEditAllocationExists($userId, $projectUuid)
    {
        $flag = false;
        $response = $this->editAllocationList($userId, $projectUuid);
        if (isset($response)) {
            foreach ($response as $value) {
                if (count($value['EditResourceAllocation']) > 0) {
                    $flag = true;
                    break;
                }
            }
        }
        return $flag;
    }

    protected function deleteAllPendingRequisitionAndMapping($request, $projectId)
    {
        try {
            $reqIdWhereAllocationPending = $this->checkIsRequisitionPending($projectId);
            $reqIdWhereMappingPending = $this->getMappingPendingRequisitionList($projectId);
            $requisitionIds = array_merge($reqIdWhereAllocationPending, $reqIdWhereMappingPending);
            $requisitionIds = array_unique($requisitionIds);
            $mappingData = ResourceAllocation::whereIn('resource_req_id', $reqIdWhereMappingPending)
                ->with(['resourceMapping' => function ($query) {
                    $query->where('status', config('constant.PERFORM_ACTIONLOG.inProgress'));
                }])->get();
            $mappingIds = [];
            foreach ($mappingData as $data) {
                if ($data['resourceMapping']) {
                    $mappingIds[] = $data['resourceMapping']->uuid;
                }
            }
            if (!empty($mappingIds)) {
                ResourceMapping::whereIn('uuid', $mappingIds)->delete();
            }
            if (!empty($requisitionIds)) {
                ResourceRequisition::whereIn('uuid', $requisitionIds)->delete();
            }
            $response = ['mappingIds' => $mappingIds, 'requisitionIds' => $requisitionIds];
            $this->updateProjectStatusAccordingResources($projectId, true);
            //Log::info($this->helpers->addlogActivityDB($request->merge(['project_id' => $projectId]), $response, config('constant.LOG_ACTIONS.deleteAllPendingRequisitionAndMapping')));
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusOk'), $response);
        } catch (\Exception $e) {
            //Log::error($this->helpers->addlogActivityDB($request->merge(['project_id' => $projectId]), $e->getMessage(), config('constant.LOG_ACTIONS.deleteAllPendingRequisitionAndMapping')));
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    protected function checkIsRequisitionPending($projectId)
    {
        $pendingReqId = ResourceRequisition::where('project_id', $projectId)->where('status', config('constant.PERFORM_ACTIONLOG.inProgress'))->pluck('uuid')->toArray();
        return ($pendingReqId);
    }

    protected function MapAllDeAllocationMappingAndSendMail($request, $projectId)
    {
        try {
            $project = Project::where('uuid', $projectId)
                ->with(['DeAllocationMapping' => function ($query) {
                    $query->where('status', config('constant.MAP_STATUS.Unmapped'));
                }])->first();
            $mailData['projectName'] = $project->project_name;
            $unMappedIds = [];
            foreach ($project['DeAllocationMapping'] as $row) {
                $user['name'] = $row['resource']->display_name;
                $user['employee_code'] = \Helpers::getEmployeeCode($row['resource_id']);
                $user['employee_email'] = \Helpers::getUserEmail($row['resource_id']);
                $user['department'] = $row['resourceAllocation']['resourceRequisition']['department']->name;
                $user['technology'] = $row['resourceAllocation']['resourceRequisition']['technology']->name;
                $user['role'] = $row['resourceAllocation']['resourceRequisition']['designation']->name;
                $user['billing_type'] = \Helpers::getBillableType($row['resourceAllocation']['resourceRequisition']['billing_type']);
                $user['dailyEfforts'] = $row->efforts;
                $user['deAllocationForHours'] = $row->hours;
                $user['startDate'] = $row->start_date;
                $user['endDate'] = $row->end_date;
                $user['deAllocationFrom'] = $row->de_allocation_from;
                $mailData['unMappingData'][] = $user;
                $unMappedIds[] = $row->uuid;
            }
            $response = ['unMappedIds' => $unMappedIds];
            //Log::info($this->helpers->addlogActivityDB($request->merge(['project_id' => $projectId]), $response, config('constant.LOG_ACTIONS.mapAllDeAllocationMapping')));
            return $mailData;
        } catch (\Exception $e) {
            //Log::error($this->helpers->addlogActivityDB($request->merge(['project_id' => $projectId]), $e->getMessage(), config('constant.LOG_ACTIONS.mapAllDeAllocationMapping')));
            return ApiResponse::genericResponse(config('constant.STATUS_CODE.statusNotFound'), '', $e->getMessage());
        }
    }

    protected function MapAllDeAllocationMapping($projectId)
    {
        $project = Project::where('uuid', $projectId)
            ->with(['DeAllocationMapping' => function ($query) {
                $query->where('status', config('constant.MAP_STATUS.Unmapped'));
            }])->first();
        $unMappedIds = [];
        foreach ($project['DeAllocationMapping'] as $row) {
            $unMappedIds[] = $row->uuid;
        }
        return $unMappedIds;
    }

    protected function checkIsRequisitionExist($projectId)
    {
        $response = true;
        $pendingReqId = ResourceRequisition::where('project_id', $projectId)->pluck('uuid')->toArray();
        if (count($pendingReqId) > 0) {
            $response = false;
        }
        return $response;
    }

    public function resourceAllocation($data, $userId)
    {
        $allocationData = [
            'resource_req_id' => $data['uuid'],
            'efforts' => $data['efforts'],
            'user_id' => $userId,
            'experience' => $data['experience'],
            'allocation_status' => config('constant.PROJECT_ACTION')['resource_allocation_response_accept'],
            'department' => $data['department'],
            'dept_id' => $data['dept_id'],
            'no_of_resource' => $data['no_of_resource'],
        ];
        $allocatedObj = new ResourceAllocation($allocationData);
        $allocatedObj->save();
        if ($allocatedObj) {
            ResourceAllocationMeta::storeResourceAllocationMeta($allocatedObj->uuid, $data['start_date'], $data['end_date'], $data['efforts'], $data['resource_id']);
            ResourceMapping::storeAllocationMapping($allocatedObj->uuid, $data['project_id'], $data);
        }
        return $allocationData;
    }

    protected function getMappingStatus($allocatedResourceId,$projectId)
    {
        $response = false;
        $mappingDetails = ResourceMapping::where(
            [
                'project_id' => $projectId,
                'allocated_resource_id' => $allocatedResourceId,
                'status' => '0'
            ]
        )->first();
        if (isset($mappingDetails)) {
            $response = true;
        }
        return $response;
    }

    public function getAllProjectResource($allBooking, $ProjectUsers)
    {
        $idsArray = [];
        $users = [];
        if(isset($allBooking) && count($allBooking) > 0){
            foreach ($allBooking as $resourceMapped) {
                if (isset($resourceMapped['resourceAllocation']['resourceAllocationMeta']) && count($resourceMapped['resourceAllocation']['resourceAllocationMeta']) > 0) {
                    foreach ($resourceMapped['resourceAllocation']['resourceAllocationMeta'] as $resourceAllocationMeta) {
                        if(!in_array($resourceAllocationMeta->resource_id, $idsArray) &&
                            $resourceAllocationMeta['resource']->status == config('constant.REDMINE_USERSTATUS.activeUser')){
                            $users[] = $resourceAllocationMeta['resource'];
                            $idsArray[] = $resourceAllocationMeta->resource_id;
                        }
                    }
                }
            }
        }
        if(isset($ProjectUsers) && count($ProjectUsers) > 0) {
            foreach ($ProjectUsers as $ProjectUser) {
                if (!in_array($ProjectUser->user_id, $idsArray) &&
                    $ProjectUser['user']->status == config('constant.REDMINE_USERSTATUS.activeUser')) {
                    $users[] = $ProjectUser['user'];
                    $idsArray[] = $ProjectUser->user_id;
                }
            }
        }
        return $users;
    }

    public function updateResourceManagersOfDeallocatedResources($alldeAllocationMappingData, $result, $buHeads, $currentBooking, $allProjectResource)
    {
        $allData['allBuHeadAssignedArray'] = [];
        $allData['allAMPMAssignedArray'] = [];
        $resourceIdArray = [];
        $allData['data'] = [];
        foreach ($alldeAllocationMappingData as $checkResource){
            $flag = true;
            $onKeka = false;
            $resourceIdsArray = [];
            $idsArray = [];
            $flag = $this->checkCurrentIsStillBooked($checkResource, $currentBooking);
            $deptId = $checkResource['resourceAllocation']['resourceRequisition']['dept_id'];
            $isActive = isset($checkResource['resource']->status) ? $checkResource['resource']->status : null;
            if(!in_array($checkResource->resource_id, $resourceIdsArray) && $isActive == 1 && $flag){
                foreach ($result as $value){
                        $rmEmailKeka = isset($value['reportsTo']['email'])? $value['reportsTo']['email'] : '';
                        if (trim($value['employeeNumber']) == trim($checkResource['resource']->employee_id) ||
                            trim($value['email']) == trim($checkResource['resource']->email)) {
                            $onKeka = true;
                            //bu head check
                            foreach ($buHeads as $buHead) {
                                if (isset($buHead->user_id)) {
                                    $buHeademail = isset($buHead->user->email)? $buHead->user->email : '';
                                    if (trim($rmEmailKeka) == trim($buHeademail) && $deptId == $buHead->dept_id) {
                                        $allData['allBuHeadAssignedArray'][] = $checkResource->resource_id;
                                    }
                                    if (!in_array($checkResource->resource_id, $resourceIdArray) && $deptId == $buHead->dept_id) {
                                        $checkResource->buHead = $buHead;
                                        $checkResource->buHeadId = $buHead->user_id;
                                        $checkResource->currentReportingEmail = $rmEmailKeka;
                                        $checkResource->currentReportingName = $value['reportsTo']['firstName'] . ' ' . $value['reportsTo']['lastName'];
                                        $resourceIdArray[] = $checkResource->resource_id;
                                    }
                                }
                            }
                            //project active record check to check assigned rm is on same project or not
                            foreach ($allProjectResource as $user) {
                                $flag1 = true;
                                if (!in_array($user->user_id, $idsArray) &&
                                    isset($user->status) == config('constant.REDMINE_USERSTATUS.activeUser')) {
                                    if (trim($rmEmailKeka) == trim($user->email)) {
                                        $flag1 = $this->checkSameRMOnProjects($checkResource->resource_id, $user->id, $currentBooking->uuid);
                                        if($flag1) {
                                            $allData['allAMPMAssignedArray'][] = $checkResource->resource_id;
                                            $idsArray[] = $user->user_id;
                                        }
                                    }
                                }
                            }
                        }
                }
                if($flag && $onKeka){
                    $allData['data'][] = $checkResource;
                }
            }
        }
        return $allData;
    }

    public function checkSameRMOnProjects($userId, $managerId, $projectId){
        $bookings = ResourceMapping::where('resource_id', $userId)->with('Project')->get();
            foreach ($bookings as $booking){
                    if(isset($booking['Project']['ProjectRole']) && count($booking['Project']['ProjectRole']) > 0 ){
                        if($booking['Project']->uuid != $projectId){
                            foreach ($booking['Project']['ProjectRole'] as $projectRole){
                                if($projectRole->user_id == $managerId){
                                    return false;
                                }
                            }
                        }
                    }
            }
            return true;
    }

    public function updateReportingManager($AllDataForUpdate, $AllResourceIdForUpdate, $projectId, $currentUserId)
    {
        $oldRMNames = [];
        $oldRMEmails = [];
        $data = [];
        if(isset($AllResourceIdForUpdate) && count($AllResourceIdForUpdate) > 0) {
            $oldManager = ReportingManager::whereIn('resource_id', $AllResourceIdForUpdate)
                ->where('project_id', $projectId)->whereIn('is_approved', [config('constant.RM_APPROVAL.approved'), config('constant.RM_APPROVAL.decline')])->update(['is_approved' => config('constant.RM_APPROVAL.deActive')]);
            foreach ($AllDataForUpdate as $resource) {
                $record = [
                    'uuid' => (string)Uuid::generate(4),
                    'dept_id' => $resource['resourceAllocation']['resourceRequisition']['dept_id'],
                    'resource_id' => $resource->resource_id,
                    'requested_rm_id' => $resource->buHeadId,
                    'active_rm_id' => $resource->buHeadId,
                    'is_approved' => config('constant.RM_APPROVAL.approved'),
                    'created_by' => $currentUserId,
                    'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                    'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
                ];
                $data[] = $record;
                $oldRMNames[] = $resource->currentReportingName;
                $oldRMEmails[] = $resource->currentReportingEmail;
            }
            $responce = ReportingManager::insert($data);
            $declinedRequests = ReportingManager::whereIn('resource_id', $AllResourceIdForUpdate)
                ->where('is_approved', config('constant.RM_APPROVAL.pending'))
                ->where('project_id', $projectId)
                ->get();
            $oldRequest = ReportingManager::whereIn('resource_id', $AllResourceIdForUpdate)
                ->where('is_approved', config('constant.RM_APPROVAL.pending'))->where('project_id', $projectId)
                ->delete();
            $ids = [];
            foreach ($data as $id) {
                if (isset($id['uuid'])) {
                    $ids[] = $id['uuid'];
                }
            }
            $changedRecords = ReportingManager::with('resource', 'ActiveResourceManager', 'RequestedResourceManager', 'CreatedBy', 'UpdatedBy')
                ->whereIn('uuid', $ids)->get();
            if (isset($changedRecords) && count($changedRecords) > 0) {
                $dept = [];
                $selectedArray = [];
                foreach ($changedRecords as $key => $value) {
                    $selectedArray[] = [
                        'resource_name' => isset($value['resource']->display_name) ? $value['resource']->display_name : '',
                        'resource_email' => isset($value['resource']->email) ? $value['resource']->email : '',
                        'department' => \Helpers::getDepartmentNameByID($value->dept_id),
                        'resource_employee_number' => $value['resource']->employee_id,
                        'active_manager_name' => isset($oldRMNames[$key]) ? $oldRMNames[$key] : '',
                        'requested_manager_name' => isset($value['ActiveResourceManager']->display_name) ? $value['ActiveResourceManager']->display_name : '',
                    ];
                    $dept[] = $value->dept_id;
                    $currentRMEmails[] = $value['ActiveResourceManager']->email;
                }
                $lastRMEmails = $oldRMEmails;
                $val = config('constant.TEMPLATES.reporting_manager_system_changes');
                $allRMEmails = array_merge($currentRMEmails, $lastRMEmails);
                $mailService = new MailService($val, $projectId, $selectedArray, $dept, $allRMEmails);
                $mailService->sendMail();
                Log::info([json_encode($changedRecords), json_encode(config('constant.LOG_ACTIONS.system_direct_change_reporting'))]);
            }

            if (isset($declinedRequests) && count($declinedRequests) > 0) {
                $selectedDeclinedArray = [];
                foreach ($declinedRequests as $value) {
                    $selectedDeclinedArray[$value->project_id]['data'][] = [
                        'resource_name' => isset($value['resource']->display_name) ? $value['resource']->display_name : '',
                        'resource_email' => isset($value['resource']->email) ? $value['resource']->email : '',
                        'department' => \Helpers::getDepartmentNameByID($value->dept_id),
                        'resource_employee_number' => isset($value['resource']->employee_id) ? $value['resource']->employee_id : '',
                        'requested_manager_name' => isset($value['RequestedResourceManager']->display_name) ? $value['RequestedResourceManager']->display_name : '',
                        'active_manager_name' => isset($value['ActiveResourceManager']->display_name) ? $value['ActiveResourceManager']->display_name : '',
                    ];
                    $selectedDeclinedArray[$value->project_id]['dept'][] = $value->dept_id;
                }
                $val = config('constant.TEMPLATES.reporting_manager_decline');
                foreach ($selectedDeclinedArray as $key => $records) {
                    $projectId = $key;
                    $selectedArray = $records['data'];
                    $dept1 = $records['dept'];
                    $mailService = new MailService($val, $projectId, $selectedArray, $dept1);
                    $mailService->sendMail();
                }
                Log::info([json_encode($declinedRequests), json_encode(config('constant.LOG_ACTIONS.system_direct_change_reporting_decline'))]);
            }
        }
    }

    public function checkCurrentIsStillBooked($checkResource, $pmoproject)
    {
        foreach ($pmoproject['currentBookings'] as $resourceMapped) {
            if (isset($resourceMapped['resourceAllocation']['resourceAllocationMeta']) &&
                count($resourceMapped['resourceAllocation']['resourceAllocationMeta']) > 0) {
                foreach ($resourceMapped['resourceAllocation']['resourceAllocationMeta'] as $resourceAllocationMeta) {
                    if($resourceAllocationMeta->resource_id == $checkResource->resource_id){
                        return false;
                        break;

                    }
                }
            }
        }
        return true;
    }
}
