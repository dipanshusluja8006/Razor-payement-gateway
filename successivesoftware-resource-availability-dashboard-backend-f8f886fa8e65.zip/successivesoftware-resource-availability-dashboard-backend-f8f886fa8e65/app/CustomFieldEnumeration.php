<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CustomFieldEnumeration extends Model {

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $connection="redmine_db_mysql";
    protected $fillable = [
            'id',
            'name',
            'custom_field_id',
            'active',
            'position',
    ];
}
