<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class LogActivity extends Model
{
    protected $fillable = [
        'link_id','url', 'action_id', 'ip', 'agent', 'user_id','request','response','created_at'
    ];

    public function createdBy()
    {
        return $this->hasOne('App\User', 'id', 'user_id')
            ->select('id', DB::raw("CONCAT(firstname,' ',lastname) as display_name"), DB::raw("(select address from email_addresses where users.id  =   user_id) as email"));
    }

    public function projectActionType()
    {
        return $this->hasOne('App\Models\ProjectActionType', 'id', 'action_id')->select('id','name','active');
    }
}
