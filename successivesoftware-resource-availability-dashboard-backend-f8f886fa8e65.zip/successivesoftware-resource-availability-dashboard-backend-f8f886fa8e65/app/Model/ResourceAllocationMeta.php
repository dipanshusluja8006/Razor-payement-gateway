<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\DB;
use Webpatser\Uuid\Uuid;
use Carbon\Carbon;
class ResourceAllocationMeta extends Model
{
    use SoftDeletes;
    protected $table = "allocated_resources_meta";
    protected $softDelete = true;
    public $incrementing = false;
    protected $fillable = ['uuid', 'resource_id', 'allocated_resources_uuid', 'start_date', "end_date", "hours"];

    static function storeResourceAllocationMeta($allocatedResourceUuid, $startDate, $endDate, $hours, $resourceId)
    {
        $allocationResourceMeta = [
            'allocated_resources_uuid' => $allocatedResourceUuid,
            'start_date' => Carbon::parse($startDate)->format('Y-m-d'),
            'end_date' => Carbon::parse($endDate)->format('Y-m-d'),
            'hours' => trim($hours),
            'resource_id' => $resourceId
        ];
        $allocatedMetaObj = new ResourceAllocationMeta($allocationResourceMeta);
        $allocatedMetaObj->save();
        if ($allocatedMetaObj) {
            return $allocatedMetaObj;
        }
    }

    static function fullyDeallocateResource($allocatedResourceUuid, $allocationMetaUuid = null)
    {
        if (isset($allocationMetaUuid)) {
            $status = ResourceAllocationMeta::where('uuid', $allocationMetaUuid)->delete();
        } else {
            $status = ResourceAllocationMeta::where('allocated_resources_uuid', $allocatedResourceUuid)->delete();
        }
        return $status;
    }

    public function resource()
    {
        return $this->hasOne('App\User', 'id', 'resource_id')
            ->select('id', 'status', DB::raw("CONCAT(firstname,' ',lastname) as display_name"),
                DB::raw("(select address from email_addresses where users.id  =   user_id) as email"),
                DB::raw("(select value from custom_values where customized_id = users.id and custom_field_id = 15) as employee_id"));
    }

    /**
     *  Setup model event hook
     */
    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $id = \Helpers::getUniqueId($model, 'allocated_resources_meta', true);
            $model->id = $id;
            $model->uuid = (string) Uuid::generate(4);
        });
    }
    
    static function updateDeallocateResourceMetaCron($resource_id,$endDate,$allocatedResourceUuid, $second,$allocationMetaUuid = null)
    {
            $futureBookingDate = ResourceAllocationMeta::where('resource_id', $resource_id)
            ->whereDate('start_date', '>', Carbon::now())
            ->whereDate('start_date', '<=', $second)
            ->orderBy('start_date', 'asc')
            ->pluck('start_date')
            ->first();
        if(isset($futureBookingDate)){
                $bookingendDate = Carbon::createFromFormat('Y-m-d', $endDate);
                $datetime1 = Carbon::parse($bookingendDate);
                $datetime2 = Carbon::parse($futureBookingDate);
                $finaldaysToAdd = $datetime1->diffInDays($datetime2);
                $date = $bookingendDate->addDays($finaldaysToAdd);
                if (isset($allocationMetaUuid)) {
                    $response = ResourceAllocationMeta::where('uuid', $allocationMetaUuid)->update(['end_date'=>$date]);
                }
                else {
                    $response = ResourceAllocationMeta::where('allocated_resources_uuid', $allocatedResourceUuid)->update(['end_date'=>$date]);
                }
            }else{
                 $finaldaysToAdd=30;
                 $date = Carbon::createFromFormat('Y-m-d', $second);
                 if (isset($allocationMetaUuid)) {
                    $response = ResourceAllocationMeta::where('uuid', $allocationMetaUuid)->update(['end_date'=>$date]);
            }
                else {
                    $response = ResourceAllocationMeta::where('allocated_resources_uuid', $allocatedResourceUuid)->update(['end_date'=>$date]);
                }
            }
            if($response){
                return $finaldaysToAdd;
            }else{
                return false;
        }
    }
}
