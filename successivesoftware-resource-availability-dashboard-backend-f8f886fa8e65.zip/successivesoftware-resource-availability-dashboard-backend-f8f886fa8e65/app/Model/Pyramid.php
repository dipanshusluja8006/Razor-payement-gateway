<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Webpatser\Uuid\Uuid;
use Illuminate\Database\Eloquent\SoftDeletes;

class Pyramid extends Model
{
    use SoftDeletes;
    public $incrementing = false;
    protected $fillable = [
        'id',
        'uuid',
        'dept_id',
        'employee_count',
        'created_by',
        'created_at',
        'updated_at'
    ];

    /**
     *  Setup model event hooks
     */
    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $id = \Helpers::getUniqueId($model, 'pyramids', true);
            $model->id = $id;
            $model->uuid = (string) Uuid::generate(4);
        });
    }

    public function ExperiencePercent()
    {
        return $this->hasMany('App\Models\ExperiencePercent', 'pyramid_id', 'uuid')->orderBy('min_experience', 'asc'); ;
    }

}
