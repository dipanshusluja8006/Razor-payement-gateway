<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Webpatser\Uuid\Uuid;
use Illuminate\Database\Eloquent\SoftDeletes;
use Helpers;
use Carbon\Carbon;

class ProjectKedbDetail extends Model
{
    use SoftDeletes;
    public $incrementing = false;
    protected $fillable = [
        'id',
        'uuid',
        'project_id',
        'project_rca_id',
        'number	',
        'created_by',
        'description_of_known_error',
        'description_of_workaround',
    ];

    public function tags()
    {
        return $this->belongsToMany('App\Models\Tag', 'kedb_tag_mappings', 'kedb_id','tag_id');
    }

    public function attachmentMappings()
    {
        return $this->hasMany('App\Models\AttachmentMapping', 'link_id', 'uuid')->with('attachment')->select('id', 'link_id', 'attachment_id');
    }

    public function createdBy()
    {
        return $this->hasOne('App\User', 'id', 'created_by')
            ->select('id', DB::raw("CONCAT(firstname,' ',lastname) as display_name"), DB::raw("(select address from email_addresses where users.id  =   user_id) as email"));
    }

    public function rca()
    {
        return $this->hasOne('App\Models\ProjectRcaDetail', 'uuid', 'project_rca_id');
    }

    public function project()
    {
        return $this->hasOne('App\Models\Project', 'uuid', 'project_id')->select('id', 'uuid', 'project_name');
    }

    /**
     *  Setup model event hooks
     */
    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $id = \Helpers::getUniqueId($model, 'project_kedb_details', true);
            $model->id = $id;
            $model->number = 'KE_'.Carbon::now()->format('d/m/Y').'_'.$id;
            $model->uuid = (string) Uuid::generate(4);
        });
    }

}
