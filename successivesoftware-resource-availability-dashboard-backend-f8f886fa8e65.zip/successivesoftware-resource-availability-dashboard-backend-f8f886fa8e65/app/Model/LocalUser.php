<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

use Webpatser\Uuid\Uuid;
use Illuminate\Database\Eloquent\SoftDeletes;
use Helpers;
use Carbon\Carbon;

class LocalUser extends Model
{
    use SoftDeletes;
    public $incrementing = false;
    protected $fillable = [
        'id',
        'user_id',
        'login',
        'hashed_password',
        'firstname',
        'lastname',
        'full_name',
        'email',
        'job_title',
        'employee_id',
        'admin',
        'status',
        'language',
        'is_default',
        'notify',
        'auth_source_id',
        'type',
        'identity_url',
        'mail_notification',
        'salt',
        'must_change_passwd',
        'accept_agreement_at',
    ];

    public function userDepartment()
    {
        return $this->hasMany('App\CustomValue', 'customized_id', 'id')->where('custom_field_id', 21);
    }

    public function userRoleLocal()
    {
        return $this->hasMany('App\Models\UserRole', 'user_id', 'user_id')->whereIn('role_id', [2,4,5,6,7,8])->select('user_id', 'role_id','dept_id');
    }

    public function userRolePM()
    {
        return $this->hasMany('App\Models\UserRole', 'user_id', 'user_id')->where('role_id', 6)->select('user_id', 'role_id','dept_id');
    }
    
    public function department()
    {
        return $this->hasMany('App\CustomValue', 'customized_id', 'user_id')->where('custom_field_id', 21);
    }

}
