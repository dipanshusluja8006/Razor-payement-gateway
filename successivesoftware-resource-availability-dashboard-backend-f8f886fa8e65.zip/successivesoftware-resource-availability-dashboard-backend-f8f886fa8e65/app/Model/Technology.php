<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Technology extends Model
{
    protected $table= "technologies";

    protected $fillable = [
        'id',
        'code',
        'name'
    ];

    public function projects() {
        $this->belongsToMany('App\Model\Technology','project_technologies','tech_id','project_id');
    }
}
