<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StaticActionList extends Model
{
    protected $table = 'status_action_lists';

    protected $fillable = [
        'id',
        'status_id',
        'user_action_id'
    ];
}
