<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;


class CustomFieldApi extends Model
{
    protected $fillable = [
        'id',
        'type',
        'name',
        'created_at',
        'updated_at'
    ];

}
