<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Webpatser\Uuid\Uuid;
use Carbon\Carbon;
use Helpers;

class ProjectRcaDetail extends Model
{
    public $incrementing = false;
    protected $fillable = [
        'uuid',
        'project_id',
        'number',
        'issue_detail',
        'date_of_issue_reported_first',
        'date_of_action_reported_first',
        'issue_reported_by',
        'resolve_issue_type',
        'time_taken_to_fix',
        'issue_priority',
        'prevent_for_future',
        'created_by',
    ];

    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $id = \Helpers::getUniqueId($model, 'project_rca_details',false);
            $model->id = $id;
            $model->number = 'RCA_'.Carbon::now()->format('d/m/Y').'_'.$id;
            $model->uuid = (string) Uuid::generate(4);
        });
    }

    public function projectDetails()
    {
        return $this->hasMany('App\Models\Project', 'uuid', 'project_id')->select('id','uuid','project_name');
    }

    public function createdBy()
    {
        return $this->hasOne('App\User', 'id', 'created_by')
            ->select('id', DB::raw("CONCAT(firstname,' ',lastname) as display_name"), DB::raw("(select address from email_addresses where users.id  =   user_id) as email"));
    }

    public function reportedUser()
    {
        return $this->hasOne('App\Models\RcaReporterUser', 'id', 'issue_reported_by')->select('id','code','name');
    }

    public function rcaUsers()
    {
        return $this->belongsToMany('App\Models\RcaUser', 'rca_users', 'rca_id', 'user_id');
    }
    public function fixedByUsers()
    {
        return $this->hasMany('App\Models\RcaUser', 'rca_id', 'uuid')->with('User')->select('id','rca_id','user_id');
    }

    public function attachmentMappings()
    {
        return $this->hasMany('App\Models\AttachmentMapping', 'link_id', 'uuid')->with('attachment')->select('id', 'link_id', 'attachment_id');
    }

}
