<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;


class PerformedActionLog extends Model
{
    use SoftDeletes;
    protected $softDelete = true;

    protected $fillable = [
        'project_id',
        'user_action_id',
        'status',
        'dept_id'
    ];

    public function userAction()
    {
        return $this->hasOne('App\Models\UserAction', 'id', 'user_action_id');
    }

    static function storePerformedActionLog($projectId, $actionId, $status, $departmentId = null)
    {
        $data = [
            'project_id' => $projectId,
            'user_action_id' => $actionId,
            'status' => $status,
            'dept_id' => $departmentId
        ];
        $log = PerformedActionLog::where($data)->first();
        if (!isset($log)) {
            $performAction = new PerformedActionLog($data);
            if ($performAction->save()) {
                return $performAction;
            }
        }
        return $log;
    }
}
