<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Webpatser\Uuid\Uuid;


class ProjectAction extends Model
{
    public $incrementing = false;
    protected $fillable = [
        'uuid',
        'link_id',
        'comment',
        'from',
        'to',
        'status_id',
        'requested_by',
        'response_by',
        'previous_status'
    ];

    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $id = \Helpers::getUniqueId($model, 'project_actions', false);
            $model->id = $id;
            $model->uuid = (string) Uuid::generate(4);
        });
    }
    static function saveProjectAction($creationData)
    {
        $data = [
            'link_id' => $creationData['link_id'],
            'comment' =>  $creationData['comment'],
            'from' =>isset($creationData['from']) ? $creationData['from'] : null,
            'to' => isset($creationData['to']) ? $creationData['to'] : null,
            'status_id' =>  $creationData['status_id'],
            'previous_status' => isset($creationData['previous_status']) ? $creationData['previous_status'] : null,
            'requested_by' => $creationData['requested_by'],
            'response_by' => isset($creationData['response_by']) ? $creationData['response_by'] : null,
        ];

        $data = new ProjectAction($data);
        if ($data->save()) {
            return $data;
        }
    }

    public function requestedBy()
    {
        return $this->hasOne('App\User', 'id', 'requested_by')
            ->select('id', DB::raw("CONCAT(firstname,' ',lastname) as display_name"), DB::raw("(select address from email_addresses where users.id  =   user_id) as email"));
    }
    public function responseBy()
    {
        return $this->hasOne('App\User', 'id', 'response_by')
            ->select('id', DB::raw("CONCAT(firstname,' ',lastname) as display_name"), DB::raw("(select address from email_addresses where users.id  =   user_id) as email"));
    }
}
