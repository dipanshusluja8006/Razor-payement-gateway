<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;


class MailContent extends Model
{

    protected $fillable = [

        'code',
        'subject',
        'template',

    ];



}
