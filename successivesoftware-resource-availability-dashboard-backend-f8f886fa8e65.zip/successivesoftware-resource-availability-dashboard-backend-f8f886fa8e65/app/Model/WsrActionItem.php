<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Webpatser\Uuid\Uuid;
use Illuminate\Support\Facades\DB;
use Helpers;

class WsrActionItem extends Model
{
    use SoftDeletes;
    protected $fillable = [
        'id',
        'uuid',
        'assiged_user_id',
        'project_id',
        'target_closure_date',
        'priority',
        'status',
        'description',
        'created_by',
        'updated_by',
        'created_at',
        'updated_at',
        'deleted_at'
    ];

    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $id = \Helpers::getUniqueId($model, 'wsr_action_items', true);
            $model->id = $id;
            $model->uuid = (string) Uuid::generate(4);
        });
    }

    public function projectName()
    {
        return $this->hasOne('App\Models\Project', 'uuid', 'project_id')->select('uuid','project_name');
    }

    public function createdByUser()
    {
        return $this->hasOne('App\User', 'id', 'created_by')
            ->select('id', DB::raw("CONCAT(firstname,' ',lastname) as display_name"), DB::raw("(select address from email_addresses where users.id  =   user_id) as email"));
    }

    public function updatedByUser()
    {
        return $this->hasOne('App\User', 'id', 'updated_by')
            ->select('id', DB::raw("CONCAT(firstname,' ',lastname) as display_name"), DB::raw("(select address from email_addresses where users.id  =   user_id) as email"));
    }

    public function assignedToUser()
    {
        return $this->hasOne('App\User', 'id', 'assiged_user_id')
            ->select('id', DB::raw("CONCAT(firstname,' ',lastname) as display_name"), DB::raw("(select address from email_addresses where users.id  =   user_id) as email"));
    }

}
