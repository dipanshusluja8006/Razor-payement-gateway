<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;


class GlobalRole extends Model
{
    protected $fillable = [
        'user_id',
        'role_id',
        'dept_id',
    ];

    public function role()
    {
        return $this->hasOne('App\Models\UserRole', 'id', 'role_id')->select('id', 'role');
    }


    public function department()
    {
        return $this->hasOne('App\Models\Department', 'id', 'dept_id')->select('id', 'name');
    }
}
