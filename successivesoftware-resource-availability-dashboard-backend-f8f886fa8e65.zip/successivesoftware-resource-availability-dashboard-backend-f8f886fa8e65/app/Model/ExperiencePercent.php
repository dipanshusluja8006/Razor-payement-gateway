<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

class ExperiencePercent extends Model
{
    protected $fillable = [
        'id',
        'pyramid_id',
        'percent',
        'min_experience',
        'max_experience',
        'created_at',
        'updated_at'
    ];

    static function saveExperiencePercent($pyramidId, $request)
    {
        $responce = false;
        $data = [];
        $experience_data = $request->experience_data;

        if(isset($experience_data[0]) && isset($pyramidId)){
            foreach ($experience_data as $value){
                $record = [
                    'pyramid_id' =>  $pyramidId,
                    'percent' => $value['percent'],
                    'min_experience' => $value['min_experience'],
                    'max_experience' => $value['max_experience'],
                    'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                    'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
                ];
                $data[] = $record;
            }
            $responce = ExperiencePercent::insert($data);
        }
        return $responce;
    }
}
