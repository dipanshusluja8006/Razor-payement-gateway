<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BillingMedium extends Model
{
    protected $table= "billing_mediums";
}
