<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;


class GovernanceCategory extends Model
{
    
    protected $fillable = [
        'id',
        'code',
        'name',
        'description',
        'created_at',
        'updated_at'
    ];

}