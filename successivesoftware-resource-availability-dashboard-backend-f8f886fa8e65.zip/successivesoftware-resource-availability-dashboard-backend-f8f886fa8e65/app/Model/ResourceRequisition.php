<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Webpatser\Uuid\Uuid;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Helpers;

class ResourceRequisition extends Model
{
    public $incrementing = false;
    use SoftDeletes;
    protected $fillable = [
        'project_id',
        'dept_id',
        'tech_id',
        'role_id',
        'no_of_resource',
        'efforts',
        'experience',
        'start_date',
        'end_date',
        'type',
        'extension_resource_id',
        'req_user_id',
        'status',
        'billing_type',
        'suggested_resource',
        'auto_extn_deallocation',
        'reason',
        'other_reason',
        'tentative_date'
    ];

    /**
     *  Setup model event hooks
     */
    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $id = \Helpers::getUniqueId($model, 'resource_requisitions', true);
            $model->id = $id;
            $model->uuid = (string) Uuid::generate(4);
        });
    }

    public function ResourceAllocation()
    {
        return $this->hasMany('App\Models\ResourceAllocation', 'resource_req_id', 'uuid')->with('user', 'resourceAllocationMeta', 'mappedResource', 'managerApproveAllocation');
    }

    public function ResourceAllocationOptimized()
    {
        return $this->hasMany('App\Models\ResourceAllocation', 'resource_req_id', 'uuid')
            ->select('id', 'uuid', 'user_id', 'resource_req_id', 'efforts', 'allocation_status')
            ->with('user', 'resourceAllocationMeta', 'mappedResource');
    }

    public function EditResourceAllocation()
    {
        return $this->hasMany('App\Models\ResourceAllocation', 'resource_req_id', 'uuid')->doesntHave('managerApproveAllocation')->with('user', 'resourceAllocationMeta', 'managerApproveAllocation');
    }

    public function ResourceAllocationLog()
    {
        return $this->hasMany('App\Models\ResourceAllocation', 'resource_req_id', 'uuid')->with('user', 'resourceAllocationMetaLog');
    }

    public function DirectRequisition()
    {
        return $this->hasOne('App\Models\ProjectAction', 'link_id', 'uuid');
    }

    public function technology()
    {
        return $this->hasOne('App\Models\Technology', 'id', 'tech_id');
    }
    public function department()
    {
        return $this->hasOne('App\Models\Department', 'id', 'dept_id');
    }
    public function designation()
    {
        return $this->hasOne('App\Models\Designation', 'id', 'role_id');
    }
    public function resource()
    {
        return $this->hasOne('App\User', 'id', 'extension_resource_id')
            ->select('id', DB::raw("CONCAT(firstname,' ',lastname) as display_name"), DB::raw("(select address from email_addresses where users.id  =   user_id) as email"));
    }

    public function requestedUser()
    {
        return $this->hasOne('App\User', 'id', 'req_user_id')
            ->select('id', DB::raw("CONCAT(firstname,' ',lastname) as display_name"), DB::raw("(select address from email_addresses where users.id  =   user_id) as email"));
    }

    public function Allocation()
    {
        return $this->hasMany('App\Models\ResourceAllocation', 'resource_req_id', 'uuid')
            ->select( 'uuid', 'allocation_status', 'resource_req_id');
    }

    static function saveRequisition($request, $data, $projectId, $type, $status)
    {
        $resource = [
            'project_id' => $projectId,
            'dept_id' => $data['dept_id'],
            'tech_id' => $data['tech_id'],
            'role_id' => $data['role_id'],
            'no_of_resource' => isset($data['no_of_resource']) ? trim($data['no_of_resource']) : 1,
            'efforts' => trim($data['efforts']),
            'experience' => trim($data['experience']),
            'start_date' => $data['start_date'],
            'end_date' => $data['end_date'],
            'type' => trim($type),
            'req_user_id' => $request->user->id,
            'extension_resource_id' => isset($data['extension_resource_id']) ? $data['extension_resource_id'] : null,
            'status' => trim($status),
            'billing_type' => $data['billing_type'],
            'suggested_resource' => $data['suggested_resource'],
        ];
        $resource = new ResourceRequisition($resource);
        return $resource->save();
    }
}
