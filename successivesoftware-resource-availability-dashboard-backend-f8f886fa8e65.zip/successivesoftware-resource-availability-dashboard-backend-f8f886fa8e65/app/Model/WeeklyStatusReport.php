<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Webpatser\Uuid\Uuid;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Helpers;

class WeeklyStatusReport extends Model
{
    use SoftDeletes;
    protected $fillable = [
        'id',
        'uuid',
        'project_id',
        'sch_cat_clt_esclation',
        'sch_cat_status',
        'sch_cat_remark',
        'qlt_cat_clt_esclation',
        'qlt_cat_status',
        'qlt_cat_remark',
        'stf_cat_clt_esclation',
        'stf_cat_status',
        'stf_cat_remark',
        'inv_cat_clt_esclation',
        'inv_cat_status',
        'inv_cat_remark',
        'rsk_cat_clt_esclation',
        'rsk_cat_status',
        'rsk_cat_remark',
        'eft_cat_clt_esclation',
        'eft_cat_status',
        'eft_cat_remark',
        'highlights_remark',
        'lowlights_remark',
        'customer_happiness_remark',
        'people_happiness_remark',
        'overall_health_count',
        'overall_health_status',
        'week_no',
        'week_start_date',
        'week_end_date',
        'created_by',
        'created_at',
        'updated_at',
        'deleted_at'
    ];

    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $id = \Helpers::getUniqueId($model, 'weekly_status_reports', true);
            $model->id = $id;
            $model->uuid = (string) Uuid::generate(4);
        });
    }

    public function projectName()
    {
        return $this->hasOne('App\Models\Project', 'uuid', 'project_id')->with('billingType')->select('uuid', 'project_name', 'billing_type');
    }

    public function createdByUser()
    {
        return $this->hasOne('App\User', 'id', 'created_by')
            ->select('id', DB::raw("CONCAT(firstname,' ',lastname) as display_name"), DB::raw("(select address from email_addresses where users.id  =   user_id) as email"));
    }

    public function updatedByUser()
    {
        return $this->hasOne('App\User', 'id', 'updated_by')
            ->select('id', DB::raw("CONCAT(firstname,' ',lastname) as display_name"), DB::raw("(select address from email_addresses where users.id  =   user_id) as email"));
    }

    public function getDepartments()
    {
        return $this->hasMany('App\Models\ResourceRequisition', 'project_id', 'project_id')->select('project_id', 'dept_id', 'end_date')->where('status', '1');
    }

    public function userRole()
    {
        return $this->hasMany('App\Models\UserRole', 'project_id', 'project_id')->select('project_id', 'user_id', 'role_id')->with(['localUser'])->where('role_id', 6);
    }

    public function getDepartment()
    {
        return $this->hasMany('App\Models\ResourceRequisition', 'project_id', 'project_id')
            ->with(['department', 'ResourceAllocation', 'DirectRequisition'])->select('uuid', 'project_id', 'dept_id', 'end_date')->where('status', '1');
    }

    public function project() {
        return $this->hasOne('App\Models\Project', 'uuid', 'project_id')->select('uuid', 'redmine_project_id','billing_type'); 
    }
}
