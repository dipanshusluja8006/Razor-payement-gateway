<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Webpatser\Uuid\Uuid;
use Carbon\Carbon;

class DeAllocationMapping extends Model
{
    public $incrementing = false;
    protected $fillable = ['uuid', 'project_id', 'allocated_resource_id', 'status', 'hours', 'resource_id', 'efforts', 'start_date', 'end_date', 'de_allocation_from', 'requested_by'];

    public function resourceAllocation()
    {
        return $this->hasOne('App\Models\ResourceAllocation', 'uuid', 'allocated_resource_id')->with('resourceRequisition', 'user');
    }

    public function resource()
    {
        return $this->hasOne('App\User', 'id', 'resource_id')
            ->select('id', 'status', DB::raw("CONCAT(firstname,' ',lastname) as display_name"),
                DB::raw("(select address from email_addresses where users.id  =   user_id) as email"),
                DB::raw("(select value from custom_values where customized_id = users.id and custom_field_id = 15) as employee_id"));
    }

    public function project()
    {
        return $this->hasOne('App\Models\Project', 'uuid', 'project_id');
    }

    public function requestedBy()
    {
        return $this->hasOne('App\User', 'id', 'requested_by')
            ->select('id', DB::raw("CONCAT(firstname,' ',lastname) as display_name"),
                DB::raw("(select address from email_addresses where users.id  =   user_id) as email"),
                DB::raw("(select value from custom_values where customized_id = users.id and custom_field_id = 15) as employee_id"));
    }


    /**
     *  Setup model event hooks
     */
    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $id = \Helpers::getUniqueId($model, 'de_allocation_mappings', false);
            $model->id = $id;
            $model->uuid = (string) Uuid::generate(4);
        });
    }

    static function storeDeAllocationMapping($allocationData, $project_id, $data, $userId, $status = 0)
    {
        $deAllocationMapping = [
            'project_id' => $project_id,
            'allocated_resource_id' => $allocationData->allocated_resources_uuid,
            'start_date' => Carbon::parse($allocationData->start_date)->format('Y-m-d'),
            'end_date' => Carbon::parse($allocationData->end_date)->format('Y-m-d'),
            'de_allocation_from' => Carbon::parse($data['start_date'])->format('Y-m-d'),
            'hours' => trim($data['hours']),
            'status' => $status,
            'efforts'=> trim($allocationData->hours),
            'resource_id' => $allocationData->resource_id,
            'requested_by' => $userId,

        ];
        $deAllocationMappingObj = new DeAllocationMapping($deAllocationMapping);
        $deAllocationMappingObj->save();
        $deAllocationMappingObj->load('resourceAllocation', 'resource');
        if ($deAllocationMappingObj) {
            return $deAllocationMappingObj;
        }
    }
}
