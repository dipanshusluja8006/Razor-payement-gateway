<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;


class CustomValueApi extends Model
{
    protected $fillable = [
        'id',
        'custom_field_api_id',
        'values',
        'created_at',
        'updated_at'
    ];

}
