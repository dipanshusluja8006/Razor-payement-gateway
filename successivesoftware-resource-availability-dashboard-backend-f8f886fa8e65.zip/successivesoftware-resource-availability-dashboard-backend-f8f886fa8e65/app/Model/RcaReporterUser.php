<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RcaReporterUser extends Model
{
       protected $fillable = [
        'id',
        'code',
        'name',
    ];
}
