<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Webpatser\Uuid\Uuid;

class ProjectClosureChecklist extends Model
{
    public $incrementing = false;
    protected $fillable=[
        'uuid',
        'project_checklist',
        'updated_by',
        'project_id',
        'created_at',
        'updated_at',
    ];

    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $id = \Helpers::getUniqueId($model, 'project_closure_checklists', false);
            $model->id = $id;
            $model->uuid = (string) Uuid::generate(4);
        });
    }

    public function projectCloseBy()
    {
        return $this->hasOne('App\Models\LocalUser', 'user_id', 'updated_by')->select(['user_id','full_name as display_name']);
    }
}
