<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Webpatser\Uuid\Uuid;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class ResourceAllocation extends Model
{
    use SoftDeletes;
    protected $table = "allocated_resources";
    protected $softDelete = true;
    protected $fillable = ['allocation_status', 'updated_by', 'uuid', "resource_req_id", "efforts", "updated_by", "user_id", "experience"];
    public $incrementing = false;

    static function updateResourceAllocation($allocation_data)
    {
        ResourceAllocation::where('uuid', $allocation_data['uuid'])->delete();

        $data = ResourceAllocation::insert($allocation_data);
        if ($data) {
            return true;
        }
    }

    /**
     *  Setup model event hooks
     */
    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $id = \Helpers::getUniqueId($model, 'allocated_resources', true);
            $model->id = $id;
            $model->uuid = (string) Uuid::generate(4);
        });
    }

    /**
     * @param $allocatedResourcesUuid
     * @param $userId
     * @param $allocationStatus
     * @return bool
     */
    static function updateResourceAllocationTableData($allocatedResourcesUuid, $userId, $allocationStatus, $experience = false)
    {
        $response = false;
        $resourceAllocationdata = ResourceAllocation::where('uuid', $allocatedResourcesUuid)
            ->with(['resourceAllocationMeta'])
            ->firstOrFail();
        $token = Carbon::now()->format('Y-m-d H:i:s');
        $max = Self::withTrashed()->find(\DB::table('allocated_resources')->max('id'));
        if (isset($resourceAllocationdata)) {
            $allocation_data = [
                'id' => (isset($max->id) ? $max->id : 0) + 1,
                'uuid' => $resourceAllocationdata['uuid'],
                'resource_req_id' => $resourceAllocationdata['resource_req_id'],
                'efforts' => trim($resourceAllocationdata['efforts']),
                'user_id' => $userId,
                'updated_by' => $userId,
                'experience' => ($experience) ? $experience : $resourceAllocationdata['experience'],
                'allocation_status' => $allocationStatus,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ];
            $response = ResourceAllocation::updateResourceAllocation($allocation_data);
            return $response;
        } else {
            return $response;
        }
    }


    public function resourceAllocationMeta()
    {
        return $this->hasMany('App\Models\ResourceAllocationMeta', 'allocated_resources_uuid', 'uuid')
            ->select('id', 'uuid', 'resource_id', 'allocated_resources_uuid', 'start_date', 'end_date', 'hours')
            ->with(['resource']);
    }

    public function resourceAllocationMetaLog()
    {
        return $this->hasMany('App\Models\ResourceAllocationMeta', 'allocated_resources_uuid', 'uuid')->with(['resource'])->onlyTrashed();
    }

    public function resourceRequisition()
    {
        return $this->hasOne('App\Models\ResourceRequisition', 'uuid', 'resource_req_id')->with('technology', 'department', 'designation', 'requestedUser');
    }

    public function mappedResource()
    {
        return $this->hasOne('App\Models\ResourceMapping', 'allocated_resource_id', 'uuid')
            ->select('id', 'uuid', 'project_id', 'allocated_resource_id', 'status', 'resource_id')
            ->where('status', config('constant.GENERAL_STATUS.approve'));
    }

    public function managerApproveAllocation()
    {
        return $this->hasOne('App\Models\ProjectAction', 'link_id', 'uuid')->where('comment', config('constant.AM_APPROVE_RESOURCE_CODE'));
    }

    public function resourceMapping()
    {
        return $this->hasOne('App\Models\ResourceMapping', 'allocated_resource_id', 'uuid');
    }

    public function user()
    {
        return $this->hasOne('App\User', 'id', 'user_id')
            ->select('id', DB::raw("CONCAT(firstname,' ',lastname) as display_name"), DB::raw("(select address from email_addresses where users.id  =   user_id) as email"));
    }
}
