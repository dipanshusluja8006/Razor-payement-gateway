<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class UserRole extends Model
{
    protected $connection = "resource_mysql";
    protected $fillable = [
        'user_id',
        'role_id',
        'dept_id',
        'project_id',
        'created_at',
        'updated_at'
    ];

    public function role()
    {
        return $this->hasOne('App\Models\Role', 'id', 'role_id')->select('id', 'role');
    }

    public function department()
    {
        return $this->hasOne('App\Models\Department', 'id', 'dept_id')->select('id', 'name');
    }

    public function userRole()
    {
        return $this->hasOne('App\Models\Role', 'id', 'role_id');
    }

    public function project()
    {
        return $this->hasOne('App\Models\Project', 'uuid', 'project_id');
    }

    public function User()
    {
        return $this->hasOne('App\User', 'id', 'user_id')
            ->select('id', 'status', DB::raw("CONCAT(firstname,' ',lastname) as display_name"),
                DB::raw("(select address from email_addresses where users.id  =   user_id) as email"),
                DB::raw("(select value from custom_values where customized_id = users.id and custom_field_id = 15) as employee_id"));
    }

    static function saveProjectRole($projectId, $users, $roleId)
    {
        $responce = false;
        $data = [];
        //return $max = Self::withTrashed()->find(\DB::table('user_roles')->max('id'));
        //$id =  (($max) ? $max->id : 0) + 1;
        foreach ($users as $user){
            $record = [
                'user_id' =>  $user,
                'role_id' => $roleId,
                'project_id' => $projectId,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ];
            $data[] = $record;
        }
        $responce = UserRole::insert($data);
        return $responce;
    }

    public function localUser()
    {
        return $this->hasOne('App\Models\LocalUser', 'user_id', 'user_id')->select('user_id', 'full_name');
    }
}
