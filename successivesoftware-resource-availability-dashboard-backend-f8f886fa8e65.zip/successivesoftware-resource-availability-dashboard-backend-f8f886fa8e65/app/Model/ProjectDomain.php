<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProjectDomain extends Model
{
    protected $table= "project_domains";

    protected $fillable = [
        'name'
    ];

    public function projects() {
        $this->belongsToMany('App\Model\ProjectDomain','project_domain_mappings','domain_id','project_id');
    }
}
