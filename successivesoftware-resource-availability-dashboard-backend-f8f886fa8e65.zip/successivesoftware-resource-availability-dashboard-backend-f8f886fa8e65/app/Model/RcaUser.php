<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class RcaUser extends Model
{
    protected $fillable = [
        'rca_id',
        'user_id',
        'created_at',
        'updated_at'
    ];
    public function User()
    {
        return $this->hasOne('App\User', 'id', 'user_id')
            ->select('id', DB::raw("CONCAT(firstname,' ',lastname) as display_name"), DB::raw("(select address from email_addresses where users.id  =   user_id) as email"));
    }
    static function saveRcaUser($rcaId, $users)
    {
        $data = [];
        foreach ($users as $user){
            $record = [
                'rca_id' => $rcaId,
                'user_id' => $user,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ];
            $data[] = $record;
        }
        $response = RcaUser::insert($data);
        return $response;
    }
}
