<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Webpatser\Uuid\Uuid;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class ReportingManager extends Model
{
    protected $connection = "resource_mysql";
    use SoftDeletes;
    protected $softDelete = true;
    protected $fillable = [
        'id',
        'uuid',
        'project_id',
        'dept_id',
        'resource_id',
        'is_approved',
        'active_rm_id',
        "requested_rm_id",
        "created_by",
        "updated_by",

    ];

    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
        });
    }

    public function resource()
    {
        return $this->hasOne('App\User', 'id', 'resource_id')->with('userDepartment')
            ->select('id', 'status', DB::raw("CONCAT(firstname,' ',lastname) as display_name"),
                DB::raw("(select address from email_addresses where users.id  =   user_id) as email"),
                DB::raw("(select value from custom_values where customized_id = users.id and custom_field_id = 15) as employee_id"));
    }

    public function ActiveResourceManager()
    {
        return $this->hasOne('App\User', 'id', 'active_rm_id')
            ->select('id', DB::raw("CONCAT(firstname,' ',lastname) as display_name"),
               DB::raw("(select address from email_addresses where users.id  =   user_id) as email"));
    }

    public function RequestedResourceManager()
    {
        return $this->hasOne('App\User', 'id', 'requested_rm_id')
            ->select('id', DB::raw("CONCAT(firstname,' ',lastname) as display_name"));
    }

    public function CreatedBy()
    {
        return $this->hasOne('App\User', 'id', 'created_by')
            ->select('id', DB::raw("CONCAT(firstname,' ',lastname) as display_name"));
    }

    public function UpdatedBy()
    {
        return $this->hasOne('App\User', 'id', 'updated_by')
            ->select('id', DB::raw("CONCAT(firstname,' ',lastname) as display_name"));
    }
}














