<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

class AttachmentMapping extends Model
{
    protected $fillable = [
        'id',
        'link_id',
        'attachment_id',
        'created_at',
        'updated_at',
    ];

    static function SaveAttachments($linkId, $attachments) {
        foreach ($attachments as $attachment) {
            $data[] = [
                'attachment_id' => $attachment,
                'link_id' => $linkId,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ];
        }
        $responce = AttachmentMapping::insert($data);
        return $responce;
    }

    public function attachment()
    {
        return $this->hasOne('App\Models\Attachment', 'id', 'attachment_id')->select('id', 'name');
    }

}
