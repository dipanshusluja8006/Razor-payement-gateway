<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Webpatser\Uuid\Uuid;
use Illuminate\Database\Eloquent\SoftDeletes;
use Helpers;
use Carbon\Carbon;
use App\Models\WeeklyStatusReport;

class Project extends Model
{
    use SoftDeletes;
    public $incrementing = false;
    protected $fillable = [
        'uuid',
        'redmine_project_id',
        'project_name',
        'parent_id',
        'identifier',
        'lifecycle_model_id',
        'company_name',
        'company_address',
        'state',
        'country',
        'billing_interval',
        'client_detail',
        'project_domain',
        'billing_type',
        'approved_hours',
        'maximum_hours_billed',
        'project_components',
        'initiation_date',
        'status',
        'project_documents_link',
        'specific_requests',
        'project_summary',
        'created_by',
        'updated_by',
        'estimated_timeline_to',
        'estimated_timeline_from',
        'project_type_id',
        'gov_category_id',
        'is_approve',
        'comment',
        'is_draft',
        'billing_medium'

    ];

    public function billingType()
    {
        return $this->hasOne('App\Models\BillingType', 'id', 'billing_type')->select('id', 'name');;
    }

    public function technologies()
    {
        return $this->belongsToMany('App\Models\Technology', 'project_technologies', 'project_id', 'tech_id');
    }

    public function projectDomains()
    {
        return $this->belongsToMany('App\Models\ProjectDomain', 'project_domain_mappings', 'project_id', 'domain_id');
    }

    public function UserRole()
    {
        return $this->hasMany('App\Models\UserRole', 'project_id', 'uuid')->with('role');
    }

    public function ProjectRole()
    {
        return $this->hasMany('App\Models\UserRole', 'project_id', 'uuid')->with('role', 'User');
    }

    public function ProjectUsers()
    {
        return $this->hasMany('App\Models\UserRole', 'project_id', 'uuid')->with('User')->select('project_id', 'user_id', 'id');;
    }

    public function ResourceRequisitionLog()
    {
        return $this->hasMany('App\Models\ResourceRequisition', 'project_id', 'uuid')->with(['technology', 'department', 'ResourceAllocationLog' => function ($query) {
            $query->where('allocation_status', config('constant.PROJECT_ACTION')['resource_allocation_response_decline']);
        }]);
    }

    public function deAllocationMapping()
    {
        return $this->hasMany('App\Models\DeAllocationMapping', 'project_id', 'uuid')->with('resourceAllocation', 'resource', 'requestedBy')->where('status', config('constant.MAP_STATUS.Unmapped'));
    }

    public function resourceMapping()
    {
        return $this->hasMany('App\Models\ResourceMapping', 'project_id', 'uuid')->with('resourceAllocation', 'resource')->where('status', config('constant.MAP_STATUS.Unmapped'));
    }

    public function resourceMapped()
    {
        return $this->hasMany('App\Models\ResourceMapping', 'project_id', 'uuid')->with('resourceAllocation')->where('status', config('constant.MAP_STATUS.mapped'));
    }

    public function accountManagers()
    {
        return $this->hasMany('App\Models\UserRole', 'project_id', 'uuid')->with('User')->where('role_id', Helpers::getRoleIdByCode(config('constant.ROLES.account_manager')))->select('project_id', 'user_id', 'role_id', 'id');
    }

    public function projectManagers()
    {
        return $this->hasMany('App\Models\UserRole', 'project_id', 'uuid')->with('User')->where('role_id', Helpers::getRoleIdByCode(config('constant.ROLES.project_manager')))->select('project_id', 'user_id', 'role_id', 'id');
    }

    public function initiatedBy()
    {
        return $this->hasOne('App\User', 'id', 'created_by')
            ->select('id', DB::raw("CONCAT(firstname,' ',lastname) as display_name"), DB::raw("(select address from email_addresses where users.id  =   user_id) as email"));
    }

    public function projectAction()
    {
        return $this->hasOne('App\Models\ProjectAction', 'link_id', 'uuid')->with('responseBy', 'requestedBy')->orderBy('id', 'DESC');
    }

    public function status()
    {
        return $this->hasOne('App\Models\Status', 'id', 'status');
    }

    public function projectType()
    {
        return $this->hasOne('App\Models\ProjectType', 'id', 'project_type_id')->select('id', 'code', 'name');
    }

    public function governanceCategory()
    {
        return $this->hasOne('App\Models\GovernanceCategory', 'id', 'gov_category_id')->select('id', 'code', 'name', 'description');
    }

    public function lifecycleModel()
    {
        return $this->hasOne('App\Models\LifeCycle', 'id', 'lifecycle_model_id')->select('id', 'code', 'name');
    }

    public function deAllocationMappingPending()
    {
        return $this->hasMany('App\Models\DeAllocationMapping', 'project_id', 'uuid')
            ->where('status', config('constant.MAP_STATUS.Unmapped'))
            ->select('id', 'uuid', 'project_id');;
    }

    public function resourceMappingPending()
    {
        return $this->hasMany('App\Models\ResourceMapping', 'project_id', 'uuid')
            ->where('status', config('constant.MAP_STATUS.Unmapped'))
            ->select('id', 'uuid', 'project_id');
    }

    public function ResourceRequisitionAll()
    {
        return $this->hasMany('App\Models\ResourceRequisition', 'project_id', 'uuid')->with('Allocation')->select('id', 'uuid', 'project_id', 'dept_id');
    }

    public function ResourceRequisitionAllProject()
    {
        return $this->hasMany('App\Models\ResourceRequisition', 'project_id', 'uuid')->with('Allocation')->select('id', 'uuid', 'project_id', 'dept_id');
    }

    public function ResourceRequisition()
    {
        return $this->hasMany('App\Models\ResourceRequisition', 'project_id', 'uuid')
            ->with('technology', 'designation', 'department', 'ResourceAllocation', 'resource', 'requestedUser')->with('DirectRequisition');
    }

    public function ResourceRequisitionOptimized()
    {
        return $this->hasMany('App\Models\ResourceRequisition', 'project_id', 'uuid')
            ->select('id', 'uuid', 'project_id', 'dept_id', 'status', 'type')
            ->with('ResourceAllocationOptimized', 'department');
    }

    public function currentBookings()
    {
        return $this->hasMany('App\Models\ResourceMapping', 'project_id', 'uuid')->with('resourceAllocation', 'resource')->where('status', config('constant.MAP_STATUS.mapped'))->whereDate('end_date', '>=', Carbon::today());
    }

    public function futureBookings()
    {
        return $this->hasMany('App\Models\ResourceMapping', 'project_id', 'uuid')->with('resourceAllocation', 'resource')->where('status', config('constant.MAP_STATUS.mapped'))->whereDate('start_date', '=', Carbon::today());
    }


    public function allBookings()
    {
        return $this->hasMany('App\Models\ResourceMapping', 'project_id', 'uuid')->with('resourceAllocation', 'resource')->where('status', config('constant.MAP_STATUS.mapped'));
    }
    /**
     *  Setup model event hooks
     */
    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $id = \Helpers::getUniqueId($model, 'projects', true);
            $model->id = $id;
            $model->uuid = (string) Uuid::generate(4);
        });
    }

    static function updateProjectStatus($status_id = 0, $user_id = 0, $project_id = 0)
    {
        $statusUpdateValue = [
            'status' => $status_id,
            'updated_by' => $user_id
        ];
        $status = Project::where('uuid', $project_id)->update($statusUpdateValue);

        if ($status) {
            $project = Project::where('uuid', $project_id)->first();
            $project->track = ['status' => $project->status, 'is_approve' => $project->is_approve, 'is_draft' => $project->is_draft];
            $project = self::checkWsrWeekStatusAction($project);
            return $project;
        }
    }
    static function checkWsrWeekStatusAction($projects)
    {
        if (!empty($projects)) {
            $today = Carbon::today();
            $weekNumber = $today->weekOfYear;
                $projects->wsr_status = 0;
                $wsrresult = WeeklyStatusReport::where('project_id', '=', $projects->uuid)->where('week_no', '=', $weekNumber)->pluck('uuid')->toArray();
                if (count($wsrresult) > 0) {
                    $projects->wsr_status = 1;
                }
            return $projects;
        }
    }
    public function subProjectName()
    {
        return $this->hasOne('App\Project', 'id', 'parent_id')->select('id', 'name', 'status');;
    }

    public function billingMediumData()
    {
        return $this->hasOne('App\Models\BillingMedium', 'redmine_billing_medium_id', 'billing_medium')->select('id', 'redmine_billing_medium_id', 'code', 'name');
    }

    public function ProjectRisk()
    {
        return $this->hasMany('App\Issues', 'project_id', 'redmine_project_id')->with('riskAsssignedTo', 'probability', 'impact', 'riskCategory')->where('tracker_id', '=', 16);
    }

    public function projectWSR()
    {
        return $this->hasMany('App\Models\WeeklyStatusReport', 'project_id', 'uuid')->orderBy('week_end_date', 'desc');
    }
    public function projectClosureDetails()
    {
        return $this->hasOne('App\Models\ProjectClosureChecklist', 'project_id', 'uuid')->with('projectCloseBy')->select('project_id', 'updated_by', 'updated_at');
    }

    public function activeProjectRisk(){
        $today = Carbon::today();
        return $this->hasMany('App\Issues', 'project_id', 'redmine_project_id')->with('riskCategory')->whereYear('created_on', $today->format('Y'))->where('tracker_id', '=', 16);
    }
}
