<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Webpatser\Uuid\Uuid;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\SoftDeletes;

class ResourceMapping extends Model
{
    use SoftDeletes;
    public $incrementing = false;
    protected $fillable = ['project_id', 'allocated_resource_id', 'uuid', 'status', 'resource_id', 'hours', 'start_date', 'end_date'];

    public function resourceAllocation()
    {
        return $this->hasOne('App\Models\ResourceAllocation', 'uuid', 'allocated_resource_id')->with('resourceRequisition', 'user', 'resourceAllocationMeta');
    }

    public function fullyAllocation()
    {
        return $this->hasOne('App\Models\ResourceAllocation', 'uuid', 'allocated_resource_id')->where('allocation_status', config('constant.PROJECT_ACTION')['resource_allocation_response_accept']);
    }

    public function resource()
    {
        return $this->hasOne('App\User', 'id', 'resource_id')
            ->select('id', DB::raw("CONCAT(firstname,' ',lastname) as display_name"),
                DB::raw("(select address from email_addresses where users.id  =   user_id) as email"),
                DB::raw("(select value from custom_values where customized_id = users.id and custom_field_id = 15) as employee_id"));
    }

    public function project()
    {
        return $this->hasOne('App\Models\Project', 'uuid', 'project_id')->with('ProjectRole');
    }

    /**
     *  Setup model event hooks
     */
    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $id = \Helpers::getUniqueId($model, 'resource_mappings', true);
            $model->id = $id;
            $model->uuid = (string) Uuid::generate(4);
        });
    }

    static function storeAllocationMapping($allocationId, $projectId, $data, $status = 0)
    {
        $resourceMapping = [
            'project_id' => $projectId,
            'allocated_resource_id' => $allocationId,
            'start_date' => Carbon::parse($data['start_date'])->format('Y-m-d'),
            'end_date' => Carbon::parse($data['end_date'])->format('Y-m-d'),
            'hours' => trim($data['efforts']),
            'status' => $status,
            'resource_id' => $data['resource_id'],
        ];
        $resourceMappingObj = new ResourceMapping($resourceMapping);
        $resourceMappingObj->save();
        if ($resourceMappingObj) {
            return $resourceMappingObj;
        }
    }
    static function updateMappingData($resource_id,$endDate,$allocatedResourceUuid, $second)
    {    
            $futureBookingDate = ResourceMapping::where('resource_id', $resource_id)
            ->whereDate('start_date', '>', Carbon::now())
            ->whereDate('start_date', '<=', $second)
            ->orderBy('start_date', 'asc')
            ->pluck('start_date')
            ->first();
        if(isset($futureBookingDate)){
                $bookingendDate = Carbon::createFromFormat('Y-m-d', $endDate);
                $datetime1 = Carbon::parse($bookingendDate);
                $datetime2 = Carbon::parse($futureBookingDate);
                $finaldaysToAdd = $datetime1->diffInDays($datetime2);
                $date = $bookingendDate->addDays($finaldaysToAdd);
                $response =  ResourceMapping::where('allocated_resource_id', $allocatedResourceUuid)->update(['end_date'=>$date]);
        }else{
                 $finaldaysToAdd=30;
                 $date = Carbon::createFromFormat('Y-m-d', $second);
                 $response =  ResourceMapping::where('allocated_resource_id', $allocatedResourceUuid)->update(['end_date'=>$date]);
            }
        if($response){
                return $finaldaysToAdd;
            }else{
                return false;
        }
    }
}
