<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Webpatser\Uuid\Uuid;


class ProjectStatus extends Model
{
    protected $fillable = [
        'uuid',
        'project_id',
        'status_id',
        'last_updated_by'
    ];

    public function project()
    {
        return $this->hasOne('App\Models\Project', 'uuid', 'project_id');
    }

    public function projectAction()
    {
        return $this->hasOne('App\Models\ProjectAction', 'link_id', 'uuid')->with('responseBy', 'requestedBy')->orderBy('id', 'DESC');
    }

    public function status()
    {
        return $this->hasOne('App\Models\Status', 'id', 'status_id');
    }

    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $id = \Helpers::getUniqueId($model, 'project_rca_details', true);
            $model->id = $id;
        });
    }

    static function saveProjectStatus($creationData)
    {
        $data = [
            'uuid' => (string) Uuid::generate(4),
            'project_id' => $creationData['project_id'],
            'status_id' =>  $creationData['status_id'],
            'last_updated_by' => $creationData['last_updated_by'],
        ];

        $data = new ProjectStatus($data);
        if ($data->save()) {
            return $data;
        }
    }

}
