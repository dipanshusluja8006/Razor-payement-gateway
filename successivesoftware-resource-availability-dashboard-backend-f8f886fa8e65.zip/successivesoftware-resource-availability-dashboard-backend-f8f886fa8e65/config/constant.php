<?php
use Illuminate\Support\Carbon;
/**\
 * In [resourceAllocationUserRoleAccess] array '4' defines allocation_status(Resource Allocation Request)
 * And array[4] shows authorized role for change Resource Allocation (BU Head)
 * 4 => Resource Allocation Request
 * 14 => Resource Allocation Accept Respone
 * 15 => Resource Allocation Decline Respone
 * 8 => Resource De-Allocation Request
 * 9 => Resource De-Allocation Accept Respone
 * 10 => Resource De-Allocation Decline Respone
 */

return [
    'ROLES' => [
        'admin' => 'admin',
        'global_operation' => 'global_operation',
        'sales' => 'sales',
        'resource_manager' => 'resource_manager',
        'account_manager' => 'account_manager',
        'project_manager' => 'project_manager',
        'bu_head' => 'bu_head',
        'go_team' => 'go_team',
        'hr' => 'hr',
    ],
    'DEPARTMENT' => [
        'global_operation' => 'global_operation',
        'sales' => 'sales',
    ],
    'PROJECT_ACTION' => [
        'initiation_request' => '17',
        'initiation' => '1',
        'creation' => '2',
        'resource_requisition_request' => '3',
        'resource_allocation_request' => '4',
        'resource_reallocation' => '6',
        'resource_mapping' => '7',
        'resource_de_allocation_request' => '8',
        'resource_de_allocation_response_accept' => '9',
        'resource_de_allocation_response_decline' => '10',
        'project_on_hold_request' => '11',
        'project_on_hold_request_accept' => '12',
        'project_closure_checklist' => '13',
        'resource_allocation_response_accept' => '14',
        'resource_allocation_response_decline' => '15',
        'resource_de_allocation_mapping' => '16',
    ],
    'TEMPLATES' => [
        'initiation' => 'initiation',
        'initiation_rm' => 'initiation_rm',
        'initiation_request' => 'initiation_request',
        'initiation_request_update' => 'initiation_request_update',
        'initiation_approval' => 'initiation_approval',
        'initiation_decline' => 'initiation_decline',
        'project_detail_updation' => 'project_detail_updation',
        'project_detail_updation_rm' => 'project_detail_updation_rm',
        'creation' => 'creation',
        'creation_go_sales' => 'creation_go_sales',
        'requisition' => 'requisition',
        'requisition_bu' => 'requisition_bu',
        'edit_requisition' => 'edit_requisition',
        'edit_requisition_bu' => 'edit_requisition_bu',
        'delete_requisition' => 'delete_requisition',
        'delete_requisition_bu' => 'delete_requisition_bu',
        'partial_allocation' => 'partial_allocation',
        'partial_allocation_bu' => 'partial_allocation_bu',
        'allocation' => 'allocation',
        'allocation_go_sales' => 'allocation_go_sales',
        'allocation_rm' => 'allocation_rm',
        'mapping' => 'mapping',
        'mapping_bu' => 'mapping_bu',
        'de_allocation' => 'de_allocation',
        'de_allocation_bu' => 'de_allocation_bu',
        'de_allocation_rm' => 'de_allocation_rm',
        'partial_resource_deallocation' => 'partial_resource_deallocation',
        'partial_resource_deallocation_bu' => 'partial_resource_deallocation_bu',
        'partial_resource_deallocation_rm' => 'partial_resource_deallocation_rm',
        'de_allocation_mapping' => 'de_allocation_mapping',
        'de_allocation_mapping_bu' => 'de_allocation_mapping_bu',
        'resource_allocation_rejection' => 'resource_allocation_rejection',
        'resource_allocation_rejection_bu' => 'resource_allocation_rejection_bu',
        'resource_allocation_rejection_go_sales' => 'resource_allocation_rejection_go_sales',
        'resource_allocation_approval' => 'resource_allocation_approval',
        'resource_allocation_approval_bu' => 'resource_allocation_approval_bu',
        'resource_allocation_approval_rm' => 'resource_allocation_approval_rm',
        'resource_allocation_approval_go_sales' => 'resource_allocation_approval_go_sales',
        'resource_reallocation' => 'resource_reallocation',
        'resource_reallocation_rm' => 'resource_reallocation_rm',
        'resource_reallocation_go_sales' => 'resource_reallocation_go_sales',
        'resource_reallocation_partial' => 'resource_reallocation_partial',
        'on_hold_request' => 'on_hold_request',
        'on_hold_request_go_sales' => 'on_hold_request_go_sales',
        'on_hold_approved' => 'on_hold_approved',
        'on_hold_rejection' => 'on_hold_rejection',
        'restart' => 'restart',
        'restart_rm' => 'restart_rm',
        'restart_go_sales' => 'restart_go_sales',
        'project_close' => 'project_close',
        'project_close_rm' => 'project_close_rm',
        'project_close_go_sales' => 'project_close_go_sales',
        'edit_allocation' => 'edit_allocation',
        'edit_allocation_rm' => 'edit_allocation_rm',
        'delete_allocation' => 'delete_allocation',
        'delete_allocation_rm' => 'delete_allocation_rm',
        'on_hold_approved_rm' => 'on_hold_approved_rm',
        'rca_creation' => 'rca_creation',
        'extension' => 'extension',
        'extension_bu' => 'extension_bu',
        'direct_extension' => 'direct_extension',
        'direct_extension_bu' => 'direct_extension_bu',
        'direct_extension_rm' => 'direct_extension_rm',
        'edit_extension_requisition' => 'edit_extension_requisition',
        'edit_extension_requisition_bu' => 'edit_extension_requisition_bu',
        'delete_extension_requisition' => 'delete_extension_requisition',
        'delete_extension_requisition_bu' => 'delete_extension_requisition_bu',
        'delete_reallocation' => 'delete_reallocation',
        'delete_reallocation_rm' => 'delete_reallocation_rm',
        'edit_direct_allocation' => 'edit_direct_allocation',
        'delete_direct_allocation' => 'delete_direct_allocation',
        //reporting manager change templates
        'reporting_manager_change_request' => 'reporting_manager_change_request',
        'reporting_manager_approval' => 'reporting_manager_approval',
        'reporting_manager_decline' => 'reporting_manager_decline',
        'reporting_manager_changes' => 'reporting_manager_changes',
        'reporting_manager_system_changes' => 'reporting_manager_system_changes',
        'time_sheet_reminder_email' => 'time_sheet_reminder_email',
        'invoice_reminder_email' => 'invoice_reminder_email',
        //reject requisition email to AM/PM
        'reject_requisition_email' => 'reject_requisition_email',
        // employee allocation email
        'employee_allocation_email' => 'employee_allocation_email',
        // cron assigned BU as RM
        'bu_assignment_as_rm' => 'bu_assignment_as_rm',
        // employee de allocation_email
        'employee_de_allocation_email' => 'employee_de_allocation_email'
    ],
    'CUSTOM_VALUES' => [
        'location' => '14',
        'business_unit' => '21',
        'billing_unit' => '27',
        'categories' => '52'
    ],
    'EXCLUDE_DEPARTMENTS' => [
        'human resource',
        'learning and development',
        'research & development',
        'sales',
        'staffing',
        'accounts & admin',
        'marketing/branding'
    ],
    'EXCLUDE_DEPARTMENTS_INNER' => [
        'client',
        'human_resource',
        'learning_and_development',
        'research_development',
        'sales',
        'staffing',
        'accounts_admin'
    ],
    'BLACKLIST_EMAILS' => [
        'sid@successive.tech',
        'sidd0001@gmail.com',
        'jai.shukla@successive.tech'
    ],

    'USER_ROLE_REDMINE' => [
        'project_manager' => 'Project Manager',
        'account_manager' => 'Account Manager',
    ],
    'CRON_DAYS' => [
        'one_day' => 1,
        'three_day' => 3,
        'five_day' => 5
    ],
    'RESOURCE_ALLOCATION_USERROLE_ACCESS' => [
        '4' => [7],
        '14' => [2, 5, 6],
        '15' => [2, 5, 6],
        '8' => [2, 5, 6],
        '9' => [4],
        '10' => [4],
    ],

    'REQUISITION_TYPE' => [
        'extension' => 1,
        'requisition' => 0
    ],

    'MAP_STATUS' => [
        'mapped' => 1,
        'Unmapped' => 0
    ],

    'GENERAL_STATUS' => [
        'approve' => '1',
        'decline' => '0'
    ],
    'PERFORM_ACTIONLOG' => [
        'inProgress' => '0',
        'completed' => '1'
    ],

    'REDMINE_USERSTATUS' => [
        'activeUser' => '1',
        'inActiveUser' => '0',
        'userType' => 'user'
    ],

    'REDMINE_PROJECTSTATUS' => [
        'activeProject' => '1'
    ],
    'Auto_EXTN_DEALLOCATION' => [
        'autoDeallocation' => '0',
        'autoExtension' => '1'
    ],

    'STATUS_CODE' => [
        'statusOk' => 200,
        'statusCreated' => 201,
        'statusUnauthorized' => 401,
        'statusForbidden' => 403,
        'statusNotFound' => 404,
        'statusUnprocessable' => 422,
        'internalServerError' => 500,
        'alreadyExist' => 409
    ],
    'BENCH_RESOURCEMAIL' => [
        //'globaloperations@successive.tech',
        //'rnd@successive.tech',
        'samadhan.misal@successive.tech',
        'gaurav.yadav1@successive.tech'

    ],
    'TIME_ENTRY_EXCEPTION' => [
        'group' => 'Group',
        'name' => 'Redmine Time Entry Exception'
    ],
    'REDMINE_DAILYENTRYHOURS' => 8,
    'PAGE_SIZE_OF_KEKA' => 2000,
    'REDMINE_CUSTOMFIELDID' => 15,
    'QUEUEJOB' => [
        'ResourceDeAllocationMail' => 'ResourceDeAllocationMail',
        'ResourceMailable' => 'ResourceMailable',
        'BenchResourceMail' => 'BenchResourceMail',
        'TimeSheetReminderEmail' => 'TimeSheetReminderEmail',
        'InvoiceReminderEmail' => 'InvoiceReminderEmail'
    ],
    'REDMINE_DEPARTMENT_FIELD_ID' => 21,

    'USER_ACTIONLIST' => [      //blongs to user actions table
        'creation-request' => 1,
        'resource-requisition' => 2,
        'resource-allocation' => 3,
        'resource-mapping' => 4,
        'resource-allocation-manager' => 5,
        'resource-reallocation' => 6,
        'hold-request' => 7,
        'resource-modification' => 9,
        'resource-deallocation-resource-manager' => 10,
        'edit-requisition' => 13,
        'edit-allocation' => 14,
        'initiation-request'=> 15,
        'initiation-approval'=> 16
    ],
    'RESPONSE_REQUIRED_ACTION_LIST' => [  //blongs to user actions table
        'creation-request',
        'resource-allocation',
        'resource-mapping',
        'resource-allocation-manager',
        'resource-reallocation',
        'hold-request-approval',
        'resource-deallocation-resource-manager',
        'initiation-request',
        'initiation-approval'
    ],

    'RESPONSE_REQUIRED_ACTION_LIST_WITH_ID' => [  //blongs to user actions table
        'creation-request' => 1,
        'resource-allocation' => 3,
        'resource-mapping' => 4,
        'resource-allocation-manager' => 5,
        'resource-reallocation' => 6,
        'hold-request-approval' => 8,
        'resource-deallocation-resource-manager' => 10,
        'initiation-request'=> 15,
        'initiation-approval'=> 16
    ],

    'BENCHRESOURCE_EXCLUDEDEPARTMENT' => [
        'Client'
    ],
    'AM_APPROVE_RESOURCE_CODE' => 'allocationManagerApprove',
    'DIRECT_REQUISITION_CODE' => 'directRequisition',
    'PROJECT_CLOSE_DEFAULT_MESSAGE' => 'Not Mention',
    'EDIT_ALLOCATION_KEY' => 'Edit_Allocation_dept_',
    'FRONTEND_URL' => env('APP_FRONTEND_URL'),
    'RESOURCE_ALLOCATION_RELATION' => 'ResourceAllocation',
    'EDIT_RESOURCE_ALLOCATION_RELATION' => 'EditResourceAllocation',
    'LOG_ACTIONS' => [
        'initiation_project' => 1,
        'update_project' => 2,
        'creation_project' => 3,
        'creation_requisition' => 4,
        'edit_requisition' => 5,
        'delete_requisition' => 6,
        'edit_extension_requisition' => 7,
        'delete_extension_requisition' => 8,
        'creation_allocation' => 9,
        'edit_allocation' => 10,
        'delete_allocation' => 11,
        'edit_direct_allocation'=> 12,
        'delete_direct_allocation'=> 13,
        'resource_allocation_response_accept' => 14,
        'resource_allocation_response_decline' => 15,
        'resource_reallocation' => 16,
        'resource_mapping' => 17,
        'resource_deallocation' => 18,
        'resource_unmapping' => 19,
        'hold_request' => 20,
        'project_on_hold_request_accept' => 21,
        'project_on_hold_rejection' => 22,
        'project_close' => 23,
        'restart_project' => 24,
        'resource_modification' => 25,
        'resource_extension' => 26,
        'creation_rca' => 27,
        'update_project_closure_checklist' => 28,
        'direct_resource_allocation' => 29,
        'delete_reallocation' => 30,
        'initiation_request' => 31,
        'initiation_approval' => 32,
        'initiation_request_edit' => 33,
        'initiation_decline' => 34,
        'initiation_project_draft' => 35,
        'project_auto_extension' => 36,
        'update_project_status' =>'Update Project Status',
        'creation_domain' =>'Creation Domain',
        'updation_domain' =>'Updation Domain',
        'creation_kedb' =>'KEDB creation',
        'deleteAllPendingRequisitionAndMapping' =>'DeleteAllPendingRequisitionAndMapping',
        'mapAllDeAllocationMapping' =>'MapAllDeAllocationMapping',
        'pyramid_create' => 'Pyramid Create',
        'reporting_request' => 'Reporting Request',
        'approval_reporting' => 'Approval Reporting',
        'decline_reporting' => 'Decline Reporting',
        'direct_change_reporting' => 'Direct Change Reporting',
        'direct_change_reporting_decline' => 'Direct Change Reporting Decline',
        'system_direct_change_reporting' => 'System Direct Change Reporting',
        'system_direct_change_reporting_decline' => 'System Direct Change Reporting Decline',
        'reject_requisition' => 37
    ],
    'REQ_BILLABLE_TYPE' => [
        'billable' => '1',
        'non_billable' => '0',
    ],

    'GO_TEAM_DEPARTMENT' => 'Global Operations',

    'PROJECT_APPROVAL' => [
        'approval_request' => 0,
        'edit_initiation_request' => 1,
        'approved' => 2,
    ],

    'RM_APPROVAL' => [
        'pending' => 0,
        'approved' => 1,
        'decline' => 2,
        'deActive' => 3,
    ],

    'RM_STATUS' => [
        'bu_head_approval_pending' => 0,
        'mapping_pending_on_keka' => 1,
        'decline' => 2,
        'approved_on_keka' => 3,
    ],

    'EXCLUDE_REPORTING_DEPARTMENTS' => 'client',
    'CUSTOM_RESOURCEMAIL' => [
        'samadhan.misal@successive.tech'
    ],

    'CUSTOM_GAURAVEMAIL' => [
        'gaurav.yadav1@successive.tech'
    ],
    'CUSTOM_ASHISHEMAIL' => [
        'ashish.baliyan@successive.tech'
    ],

    'EXCEPTION_EMAILS_REDMINE' => [
        'sid'=> 'sidd0001@gmail.com'
    ],

    'EXCEPTION_EMAILS_KEKA' => [
        'sid' => 'sid@successive.tech'
    ],
    'HR_GROUP_MAIL_ID' => 'hr.support@successivesoftwares.com',

    'PROJECT_CUSTOMFIELDS_ARRAY' => [
        'Technology_Stack_ID'=> '17',
        'Technology_Stack' => 'Technology Stack',
        'Client_Billable_ID'=> '24',
        'Client_Billable' => 'Client Billable',
        'Infrastructure_Details_ID'=> '26',
        'Infrastructure_Details' => 'Infrastructure Details',
        'Contract_Type_ID'=> '27',
        'Contract_Type' => 'Contract Type',
        'ProjectEndDate_ID'=> '29',
        'ProjectEndDate' => 'Project End Date',
        'ProjectStartDate_ID'=> '30',
        'ProjectStartDate' => 'Project Start Date',
        'RevisedEndDate_ID'=> '31',
        'RevisedEndDate' => 'Revised End Date',
        'Estimated_Hrs_ID'=> '32',
        'Estimated_Hrs' => 'Estimated Hrs',
        'Lifecycle_Model_ID'=> '33',
        'Lifecycle_Model' => 'Lifecycle Model',
        'Project_Type_ID'=> '34',
        'Project_Type' => 'Project Type',
        'Governance_Category_ID'=> '35',
        'Governance_Category' => 'Governance Category',
        'Billing_Medium_ID'=> '53',
        'Billing_Medium' => 'Billing Medium',
    ],

    'EXCLUDE_RESOURCE_BOOKED' => [
        'Non member',
        'Anonymous',
        'Client',
        'Timesheet Approver',
        'Timesheet Viewer',
        'Business Development',
        'Global Operations',
        'BU',
        'Reviewer',
        'Finance'
    ],


    // KEKA_LEAVE_ALL_STATUS 'Pending' => 0, 'Approved'=> 1, 'Rejected' => 2, 'Cancelled'=> 3, 'InApprovalProcess' => 4,
    'KEKA_LEAVE_STATUS' => [0,1,4],
    'CACHE_EXPIRE_TIME' => Carbon::now()->endOfDay()->addSecond(),
    'billing_type' => [
        1,2,3
    ]
];
