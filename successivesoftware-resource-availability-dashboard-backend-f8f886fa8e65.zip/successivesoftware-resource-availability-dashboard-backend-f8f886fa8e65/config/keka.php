<?php

return [
   'keka_client_id' => env('keka_client_id', ''),
   'keka_secret_key'=> env('keka_secret_key', ''),
   'api_key' => env('api_key', '')
];