<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use App\Models\MailContent;

class AddRejectRequisitionToMailContentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('mail_contents', function (Blueprint $table) {
            $items = [
                [
                    'code' => 'reject_requisition_email',
                    'subject' => 'Requisition Request Rejected',
                    'template' => 'reject-requisition-template'
                ]
            ];
            foreach ($items as $item) {
                MailContent::updateOrCreate(['code' => $item['code']], $item);
            }
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('mail_contents', function (Blueprint $table) {
            $items = [
                [
                    'code' => 'reject_requisition_email',
                    'subject' => 'Reject Requisition Mail',
                    'template' => 'reject-requisition-template'
                ]
            ];
    
            foreach ($items as $item) {
                MailContent::where('code', $item['code'])->delete();
            }
        });
    }
}
