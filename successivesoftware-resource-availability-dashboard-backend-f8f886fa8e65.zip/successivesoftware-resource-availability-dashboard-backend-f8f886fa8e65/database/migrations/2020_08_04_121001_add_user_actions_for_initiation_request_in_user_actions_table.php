<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use App\Models\UserAction;

class AddUserActionsForInitiationRequestInUserActionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        $items = [
            [
                'code' => 'initiation-request',
                'name' => 'Initiation-Request'
            ],
            [
                'code' => 'initiation-approval',
                'name' => 'Initiation-Approval'
            ]
        ];
        foreach ($items as $item) {
            UserAction::updateOrCreate(['code' => $item['code']], $item);
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        $items = [
            [
                'code' => 'initiation-request',
                'name' => 'Initiation-Request'
            ],
            [
                'code' => 'initiation-approval',
                'name' => 'Initiation-Approval'
            ]
        ];
        Schema::disableForeignKeyConstraints();
        foreach ($items as $item) {
            UserAction::where('code', $item['code'])->delete();
        }
    }
}
