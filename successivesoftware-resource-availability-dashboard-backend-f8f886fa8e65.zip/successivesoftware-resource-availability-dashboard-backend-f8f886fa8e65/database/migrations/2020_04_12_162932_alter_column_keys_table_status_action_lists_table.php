<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AlterColumnKeysTableStatusActionListsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::connection()->getDoctrineSchemaManager()->getDatabasePlatform()->registerDoctrineTypeMapping('enum', 'string');
        Schema::disableForeignKeyConstraints();
        Schema::table('status_action_lists', function (Blueprint $table) {
            $table->unsignedBigInteger('status_id')->change();
        });
        Schema::table('status_action_lists', function (Blueprint $table) {
            $table->foreign('status_id')
                ->references('id')
                ->on('status');
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::connection()->getDoctrineSchemaManager()->getDatabasePlatform()->registerDoctrineTypeMapping('enum', 'string');
        Schema::table('status_action_lists', function (Blueprint $table) {
            $table->dropForeign(['status_id']);
        });
        Schema::table('status_action_lists', function (Blueprint $table) {
            $table->integer('status_id')->change();
        });
    }
}
