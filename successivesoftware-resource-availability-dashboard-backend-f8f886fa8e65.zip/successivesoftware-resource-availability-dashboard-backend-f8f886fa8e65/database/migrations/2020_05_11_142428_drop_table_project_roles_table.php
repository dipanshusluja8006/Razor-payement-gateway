<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use App\Models\ProjectRole;
use App\Models\UserRole;
use Carbon\Carbon;

class DropTableProjectRolesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if (Schema::hasTable('project_roles')) {
            $projectRolesArray = [];
            foreach (ProjectRole::all() as $record){
                $record = [
                    'user_id' =>  $record->user_id,
                    'role_id' => $record->role_id,
                    'project_id' => $record->project_id,
                    'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                    'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
                ];
                $projectRolesArray[] = $record;
            }
            UserRole::insert($projectRolesArray);
        }
        Schema::dropIfExists('project_roles');
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::disableForeignKeyConstraints();
        if (!Schema::hasTable('project_roles')) {
            Schema::create('project_roles', function (Blueprint $table) {
                $table->unsignedBigInteger('id')->unique();
                $table->uuid('uuid');
                $table->uuid('project_id')->nullable();
                $table->integer('user_id')->nullable();
                $table->unsignedBigInteger('role_id')->nullable();
                $table->timestamps();
                $table->softDeletes();
                $table->primary('uuid');
                $table->foreign('project_id')
                    ->references('uuid')
                    ->on('project_details');
                $table->foreign('role_id')
                    ->references('id')
                    ->on('user_roles');
            });
        }
    }
}
