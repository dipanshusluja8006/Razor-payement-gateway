<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddSomeFieldsToWeeklyStatusReportsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('weekly_status_reports', function (Blueprint $table) {
            $table->integer('sch_cat_clt_esclation')->default(0)->after('project_id');
            $table->integer('qlt_cat_clt_esclation')->default(0)->after('sch_cat_remark');
            $table->integer('stf_cat_clt_esclation')->default(0)->after('qlt_cat_remark');
            $table->integer('inv_cat_clt_esclation')->default(0)->after('stf_cat_remark');
            $table->integer('rsk_cat_clt_esclation')->default(0)->after('inv_cat_remark');
            $table->integer('eft_cat_clt_esclation')->default(0)->after('rsk_cat_remark');
            $table->float('overall_health_count')->nullable()->after('people_happiness_remark');
            $table->integer('overall_health_status')->nullable()->after('overall_health_count');
            $table->integer('week_no')->nullable()->after('overall_health_status');
            $table->date('week_start_date')->nullable()->after('week_no');
            $table->date('week_end_date')->nullable()->after('week_start_date');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('weekly_status_reports', function (Blueprint $table) {
            $table->dropColumn('sch_cat_clt_esclation');
            $table->dropColumn('qlt_cat_clt_esclation');
            $table->dropColumn('stf_cat_clt_esclation');
            $table->dropColumn('inv_cat_clt_esclation');
            $table->dropColumn('rsk_cat_clt_esclation');
            $table->dropColumn('eft_cat_clt_esclation');
            $table->dropColumn('overall_health_count');
            $table->dropColumn('overall_health_status');
            $table->dropColumn('week_no');
            $table->dropColumn('week_start_date');
            $table->dropColumn('week_end_date');
        });
    }
}
