<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use App\Models\UserActionRole;
class AddNewRecordsInUserActionRolesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        {
            $userActionArray = [];
            $rolesArray = [];

            $items = [
                //new actions for initiation-request
                [
                    'user_action_code' => 'initiation-request',
                    'role_code' => 'go_team'
                ],
                [
                    'user_action_code' => 'initiation-request',
                    'role_code' => 'bu_head'
                ],
                [
                    'user_action_code' => 'initiation-approval',
                    'role_code' => 'global_operation'
                ],
            ];

            $allUserActions = \App\Models\UserAction::get();
            foreach ($allUserActions as $action) {
                $userActionArray[$action['code']] = $action['id'];
            }

            $allRoles = \App\Models\Role::get();
            foreach ($allRoles as $role) {
                $rolesArray[$role['code']] = $role['id'];
            }

            foreach ($items as $item) {
                $userActionRole = [
                    'user_action_id' => $userActionArray[$item['user_action_code']],
                    'role_id' => $rolesArray[$item['role_code']],
                ];
                UserActionRole::updateOrCreate($userActionRole, $userActionRole);
            }
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        {
            $userActionArray = [];
            $rolesArray = [];

            $items = [
                //new actions for initiation-request
                [
                    'user_action_code' => 'initiation-request',
                    'role_code' => 'go_team'
                ],
                [
                    'user_action_code' => 'initiation-request',
                    'role_code' => 'bu_head'
                ],
                [
                    'user_action_code' => 'initiation-approval',
                    'role_code' => 'global_operation'
                ],
            ];

            $allUserActions = \App\Models\UserAction::get();
            foreach ($allUserActions as $action) {
                $userActionArray[$action['code']] = $action['id'];
            }

            $allRoles = \App\Models\Role::get();
            foreach ($allRoles as $role) {
                $rolesArray[$role['code']] = $role['id'];
            }

            foreach ($items as $item) {
                $userActionRole = [
                    'user_action_id' => $userActionArray[$item['user_action_code']],
                    'role_id' => $rolesArray[$item['role_code']],
                ];
                UserActionRole::where($userActionRole)->delete();
            }
        }
    }
}
