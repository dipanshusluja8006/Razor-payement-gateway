<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AlterIdProjectDetailsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::connection()->getDoctrineSchemaManager()->getDatabasePlatform()->registerDoctrineTypeMapping('enum', 'string');
        Schema::table('project_details', function (Blueprint $table) {
            $table->bigIncrements('id')->unique()->change();
            if (Schema::hasColumn('project_details', 'project_domain'))
            {
                $table->dropColumn('project_domain');
            }
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::connection()->getDoctrineSchemaManager()->getDatabasePlatform()->registerDoctrineTypeMapping('enum', 'string');
        Schema::table('project_details', function (Blueprint $table) {
            $table->dropUnique(['id']);
            if ((!Schema::hasColumn('project_details', 'project_domain')))
            {
                $table->string('project_domain')->nullable()->after('company_address');
            }
        });
    }
}
