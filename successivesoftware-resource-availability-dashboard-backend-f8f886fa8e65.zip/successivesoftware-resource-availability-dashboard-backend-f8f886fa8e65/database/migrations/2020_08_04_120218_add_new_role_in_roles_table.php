<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use App\Models\Role;
class AddNewRoleInRolesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        $item = [
            'code' => 'go_team',
            'role' => 'GO Team'
         ];
        Role::updateOrCreate(['code' => $item['code']], $item);
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        $item = [
            'code' => 'go_team',
            'role' => 'GO Team'
            ];
            Role::where('code', $item['code'])->delete();
    }
}
