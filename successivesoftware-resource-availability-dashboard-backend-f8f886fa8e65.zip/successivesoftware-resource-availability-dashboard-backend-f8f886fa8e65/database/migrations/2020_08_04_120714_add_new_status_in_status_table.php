<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use App\Models\Status;

class AddNewStatusInStatusTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        $item = [
            'id' => 17,
            'code' => 'initiation_request',
            'name' => 'initiation_request'
        ];
        Status::updateOrCreate(['id' => $item['id']], $item);
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        $item = [
            'id' => 17,
            'code' => 'initiation_request',
            'name' => 'initiation_request'
        ];
        Status::where('id', $item['id'])->delete();
    }
}
