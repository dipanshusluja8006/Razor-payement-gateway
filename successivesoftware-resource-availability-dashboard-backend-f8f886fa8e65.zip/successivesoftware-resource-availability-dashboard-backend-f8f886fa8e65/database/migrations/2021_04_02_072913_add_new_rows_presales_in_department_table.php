<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddNewRowsPresalesInDepartmentTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        $items = [
            [
                'code' => 'pre_sales',
                'name' => 'Pre Sales'
            ],
        ];

            foreach ($items as $item) {
                \App\Models\Department::updateOrCreate(['code' => $item['code']], $item);
            }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        $items = [
            [
                'code' => 'pre_sales',
                'name' => 'Pre Sales'
            ],
        ];
        foreach ($items as $item) {
            \App\Models\Department::where(['code' => $item['code']], $item)->delete();
        }
    }
}
