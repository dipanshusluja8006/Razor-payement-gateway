<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AlterColumnKeysTableResourceMappingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::connection()->getDoctrineSchemaManager()->getDatabasePlatform()->registerDoctrineTypeMapping('enum', 'string');
        Schema::disableForeignKeyConstraints();
        Schema::table('resource_mappings', function (Blueprint $table) {
            $table->unsignedBigInteger('id')->change();
        });
        Schema::table('resource_mappings', function (Blueprint $table) {
            $table->dropPrimary('id');
            $table->primary('uuid');
            $table->foreign('project_id')
                ->references('uuid')
                ->on('project_details');
            $table->foreign('allocated_resource_id')
                ->references('uuid')
                ->on('allocated_resources');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::connection()->getDoctrineSchemaManager()->getDatabasePlatform()->registerDoctrineTypeMapping('enum', 'string');
        Schema::table('resource_mappings', function (Blueprint $table) {
            $table->dropPrimary('uuid');
            $table->bigIncrements('id')->change();
            $table->dropForeign(['project_id']);
            $table->dropForeign(['allocated_resource_id']);
        });
        Schema::table('resource_mappings', function (Blueprint $table) {
            $table->primary('id');
        });
    }
}
