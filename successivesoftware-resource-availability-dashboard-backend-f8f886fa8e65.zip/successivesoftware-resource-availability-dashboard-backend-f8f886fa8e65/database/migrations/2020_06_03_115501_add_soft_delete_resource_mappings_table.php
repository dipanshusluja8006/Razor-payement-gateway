<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddSoftDeleteResourceMappingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('resource_mappings', function (Blueprint $table) {
            if (!(Schema::hasColumn('resource_mappings', 'deleted_at'))) {
                $table->softDeletes();
            }
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('resource_mappings', function (Blueprint $table) {
            if ((Schema::hasColumn('resource_mappings', 'deleted_at'))) {
                $table->dropSoftDeletes();
            }
        });
    }
}
