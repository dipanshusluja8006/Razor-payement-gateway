<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AlterColumnKeysTableUserActionRolesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::connection()->getDoctrineSchemaManager()->getDatabasePlatform()->registerDoctrineTypeMapping('enum', 'string');
        Schema::disableForeignKeyConstraints();
        Schema::table('user_action_roles', function (Blueprint $table) {
            $table->unsignedBigInteger('user_action_id')->change();
        });
        Schema::table('user_action_roles', function (Blueprint $table) {
            $table->foreign('user_action_id')
                ->references('id')
                ->on('user_actions');
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::connection()->getDoctrineSchemaManager()->getDatabasePlatform()->registerDoctrineTypeMapping('enum', 'string');
        Schema::table('user_action_roles', function (Blueprint $table) {
            $table->dropForeign(['user_action_id']);
        });
        Schema::table('user_action_roles', function (Blueprint $table) {
            $table->integer('user_action_id')->change();
        });
    }
}
