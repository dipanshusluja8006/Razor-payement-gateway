<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AlterAddColumnsInResourceRequisitionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('resource_requisitions', function (Blueprint $table) {
            if ((!Schema::hasColumn('resource_requisitions', 'type')))
            {
                $table->tinyInteger('type')->default(0);
            }
            if ((!Schema::hasColumn('resource_requisitions', 'extension_resource_id')))
            {
                $table->integer('extension_resource_id')->nullable();
            }
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('resource_requisitions', function (Blueprint $table) {

            if (Schema::hasColumn('resource_requisitions', 'type'))
            {
                $table->dropColumn(['type']);
            }
            if (Schema::hasColumn('resource_requisitions', 'extension_resource_id'))
            {
                $table->dropColumn(['extension_resource_id']);
            }
        });
    }
}
