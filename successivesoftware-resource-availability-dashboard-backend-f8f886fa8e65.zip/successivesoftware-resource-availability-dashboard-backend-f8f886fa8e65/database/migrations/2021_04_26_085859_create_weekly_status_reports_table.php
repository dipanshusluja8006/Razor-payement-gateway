<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateWeeklyStatusReportsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('weekly_status_reports', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->uuid('uuid');
            $table->uuid('project_id')->nullable();
            $table->integer('sch_cat_status')->nullable();
            $table->mediumText('sch_cat_remark')->nullable();
            $table->integer('qlt_cat_status')->nullable();
            $table->mediumText('qlt_cat_remark')->nullable();
            $table->integer('stf_cat_status')->nullable();
            $table->mediumText('stf_cat_remark')->nullable();
            $table->integer('inv_cat_status')->nullable();
            $table->mediumText('inv_cat_remark')->nullable();
            $table->integer('rsk_cat_status')->nullable();
            $table->mediumText('rsk_cat_remark')->nullable();
            $table->integer('eft_cat_status')->nullable();
            $table->mediumText('eft_cat_remark')->nullable();
            $table->mediumText('highlights_remark')->nullable();
            $table->mediumText('lowlights_remark')->nullable();
            $table->mediumText('customer_happiness_remark')->nullable();
            $table->mediumText('people_happiness_remark')->nullable();
            $table->integer('created_by')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('weekly_status_reports');
    }
}
