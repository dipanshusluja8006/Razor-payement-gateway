<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProjectKedbDetailsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('project_kedb_details', function (Blueprint $table) {
            $table->uuid('uuid')->primary();
            $table->bigInteger('id')->unique();
            $table->uuid('project_id')->nullable();
            $table->foreign('project_id')->references('uuid')->on('projects');
            $table->uuid('project_rca_id')->nullable();
            $table->foreign('project_rca_id')->references('uuid')->on('project_rca_details');
            $table->string('number')->nullable();
            $table->integer('created_by')->nullable();
            $table->mediumText('description_of_known_error')->nullable();
            $table->mediumText('description_of_workaround')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('project_kedb_details');
    }
}
