<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AlterColumnKeysTableAllocatedResourcesMetaTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::connection()->getDoctrineSchemaManager()->getDatabasePlatform()->registerDoctrineTypeMapping('enum', 'string');
        Schema::disableForeignKeyConstraints();
        Schema::table('allocated_resources_meta', function (Blueprint $table) {
            $table->unsignedBigInteger('id')->change();
        });
        Schema::table('allocated_resources_meta', function (Blueprint $table) {
            $table->dropPrimary('id');
            $table->primary('uuid');
            $table->foreign('allocated_resources_uuid')
                ->references('uuid')
                ->on('allocated_resources');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::connection()->getDoctrineSchemaManager()->getDatabasePlatform()->registerDoctrineTypeMapping('enum', 'string');
        Schema::table('allocated_resources_meta', function (Blueprint $table) {
            $table->dropPrimary('uuid');
            $table->bigIncrements('id')->change();
            $table->dropForeign(['allocated_resources_uuid']);
        });
        Schema::table('allocated_resources_meta', function (Blueprint $table) {
            $table->primary('id');
        });
    }
}
