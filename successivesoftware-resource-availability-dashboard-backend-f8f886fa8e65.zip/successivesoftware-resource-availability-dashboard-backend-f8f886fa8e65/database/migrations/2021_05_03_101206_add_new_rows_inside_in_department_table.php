<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddNewRowsInsideInDepartmentTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        $items = [
            [
                'code' => 'staffing',
                'name' => 'Staffing'
            ],
            [
                'code' => 'leadership',
                'name' => 'Leadership'
            ],
            [
                'code' => 'python_and_data',
                'name' => 'Python and Data'
            ]
        ];
        foreach ($items as $item) {
            \App\Models\Department::updateOrCreate(['code' => $item['code']], $item);
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        $items = [
            [
                'code' => 'staffing',
                'name' => 'Staffing'
            ],
            [
                'code' => 'leadership',
                'name' => 'Leadership'
            ],
            [
                'code' => 'python_and_data',
                'name' => 'Python and Data'
            ]
        ];
        foreach ($items as $item) {
            \App\Models\Department::where(['code' => $item['code']], $item)->delete();
        }
    }
}
