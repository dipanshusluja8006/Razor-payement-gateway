<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AlterColumnKeysTableProjectRolesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::connection()->getDoctrineSchemaManager()->getDatabasePlatform()->registerDoctrineTypeMapping('enum', 'string');
        Schema::disableForeignKeyConstraints();
        Schema::table('project_roles', function (Blueprint $table) {
            $table->unsignedBigInteger('id')->change();
            $table->unsignedBigInteger('role_id')->change();
        });
        Schema::table('project_roles', function (Blueprint $table) {
            $table->dropPrimary('id');
            $table->primary('uuid');
            $table->foreign('project_id')
                ->references('uuid')
                ->on('project_details');
            $table->foreign('role_id')
                ->references('id')
                ->on('user_roles');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::connection()->getDoctrineSchemaManager()->getDatabasePlatform()->registerDoctrineTypeMapping('enum', 'string');
        Schema::table('project_roles', function (Blueprint $table) {
            $table->dropPrimary('uuid');
            $table->bigIncrements('id')->change();
            $table->dropForeign(['project_id']);
            $table->dropForeign(['role_id']);
        });
        Schema::table('project_roles', function (Blueprint $table) {
            $table->primary('id');
            $table->integer('role_id')->change();
        });
    }
}
