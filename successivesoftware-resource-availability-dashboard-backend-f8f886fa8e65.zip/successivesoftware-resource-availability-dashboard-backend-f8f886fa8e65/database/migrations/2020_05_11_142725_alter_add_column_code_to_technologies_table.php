<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use App\Models\Technology;

class AlterAddColumnCodeToTechnologiesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        $items  = [
            [
                'code' => 'php_laravel',
                'name' => 'Php - Laravel'
            ],
            [
                'code' => 'php_symfony',
                'name' => 'Php - Symfony'
            ],
            [
                'code' => 'php_yii',
                'name' => 'Php - Yii'
            ],
            [
                'code' => 'php_twig',
                'name' => 'Php - Twig'
            ],
            [
                'code' => 'net',
                'name' => '.Net'
            ],
            [
                'code' => 'angular_js',
                'name' => 'Angular Js'
            ],
            [
                'code' => 'esri_arcgis_js',
                'name' => 'ESRI ArcGIS Js'
            ],
            [
                'code' => 'd3_js',
                'name' => 'D3 Js'
            ],
            [
                'code' => 'vue_js',
                'name' => 'Vue Js'
            ],
            [
                'code' => 'node_js',
                'name' => 'Node Js'
            ],
            [
                'code' => 'react_js',
                'name' => 'React Js'
            ],
            [
                'code' => 'react_native',
                'name' => 'React Native'
            ],
            [
                'code' => 'knex_js',
                'name' => 'Knex Js'
            ],
            [
                'code' => 'elastic_search',
                'name' => 'Elastic search'
            ],
            [
                'code' => 'wordpress',
                'name' => 'Wordpress'
            ],
            [
                'code' => 'mySQL',
                'name' => 'MySQL'
            ],
            [
                'code' => 'msSQL',
                'name' => 'MsSQL'
            ],
            [
                'code' => 'xamarin',
                'name' => 'Xamarin'
            ],
            [
                'code' => 'wpf',
                'name' => 'WPF'
            ],
            [
                'code' => 'c#',
                'name' => 'C#'
            ],
            [
                'code' => 'xcode',
                'name' => 'Xcode'
            ],
            [
                'code' => 'selenium',
                'name' => 'Selenium'
            ],
            [
                'code' => 'angular_8',
                'name' => 'Angular 8'
            ],
            [
                'code' => 'asp_net',
                'name' => 'ASP .Net'
            ],
            [
                'code' => 'ui_ux',
                'name' => 'UI/UX'
            ]
        ];
        Schema::table('technologies', function (Blueprint $table) {
            $table->string('code')->nullable()->after('id');
        });
        foreach ($items as $item) {
            Technology::where(['name' => $item['name']])->update(['code' => $item['code']]);
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('technologies', function (Blueprint $table) {
            $table->dropColumn('code');
        });
    }
}
