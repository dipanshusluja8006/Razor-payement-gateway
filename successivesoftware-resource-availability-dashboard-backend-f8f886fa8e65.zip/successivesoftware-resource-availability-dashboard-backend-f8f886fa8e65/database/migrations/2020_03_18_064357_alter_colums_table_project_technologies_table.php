<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AlterColumsTableProjectTechnologiesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if(Schema::hasTable('project_technologies')) {
            Schema::table('project_technologies', function (Blueprint $table) {
                $table->integer('project_id')->charset(null)->collation(null)->change();
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        if(Schema::hasTable('project_technologies')) {
            Schema::table('project_technologies', function (Blueprint $table) {
                $table->string('project_id', 36)->change();
            });
        }
    }
}
