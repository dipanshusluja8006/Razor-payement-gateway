<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use App\Models\Department;

class AlterAddColumnCodeToDepartmentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        $items = [
            [
                'code' => 'quality_analysis',
                'name' => 'Quality Analysis'
            ],
            [
                'code' => 'php_js',
                'name' => 'Php JS'
            ],
            [
                'code' => 'human_resource',
                'name' => 'Human Resource'
            ],
            [
                'code' => 'node',
                'name' => 'Node'
            ],
            [
                'code' => 'client',
                'name' => 'Client'
            ],
            [
                'code' => 'global_operation',
                'name' => 'Global Operations'
            ],
            [
                'code' => 'sales',
                'name' => 'Sales'
            ],
            [
                'code' => 'devops',
                'name' => 'DevOps'
            ],
            [
                'code' => 'security',
                'name' => 'Security'
            ],
            [
                'code' => 'requirement_engineering',
                'name' => 'Requirement Engineering'
            ],
            [
                'code' => 'net',
                'name' => '.Net'
            ],
            [
                'code' => 'mobility',
                'name' => 'Mobility'
            ],
            [
                'code' => 'frontend',
                'name' => 'Frontend'
            ],
            [
                'code' => 'product_development',
                'name' => 'Product Development'
            ],
            [
                'code' => 'ui_ux',
                'name' => 'UI/UX'
            ],
            [
                'code' => 'erp_crm',
                'name' => 'ERP/CRM'
            ],
            [
                'code' => 'marketing_branding',
                'name' => 'Marketing/Branding'
            ],
            [
                'code' => 'it_infra',
                'name' => 'IT Infra'
            ],
            [
                'code' => 'accounts_admin',
                'name' => 'Accounts & Admin'
            ],
            [
                'code' => 'research_development',
                'name' => 'Research & development'
            ]
        ];
        Schema::table('departments', function (Blueprint $table) {
            $table->string('code')->nullable()->after('id');
        });
        foreach ($items as $item) {
            $department = Department::where('name', $item['name'])->first();
            if($department){
                Department::where(['name' => $item['name']])->update(['code' => $item['code']]);
            }
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('departments', function (Blueprint $table) {
            $table->dropColumn('code');
        });
    }
}
