<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use App\Models\MailContent;

class AddNewCodesForInitiationRequstInMailContentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        $items = [
            [
                'code' => 'initiation_request',
                'subject' => 'initiation-request',
                'template' => 'initiation-request-template'
            ],
            [
                'code' => 'initiation_approval',
                'subject' => 'initiation-approval',
                'template' => 'initiation-approval-template'
            ],
            [
                'code' => 'initiation_decline',
                'subject' => 'initiation-decline',
                'template' => 'initiation-decline-template'
            ],
            [
                'code' => 'initiation_request_update',
                'subject' => 'initiation-request-update',
                'template' => 'initiation-request-update-template'
            ],
        ];
        foreach ($items as $item) {
            MailContent::updateOrCreate(['code' => $item['code']], $item);
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        $items = [
            [
                'code' => 'initiation_request',
                'subject' => 'initiation-request',
                'template' => 'initiation-request-template'
            ],
            [
                'code' => 'initiation_approval',
                'subject' => 'initiation-approval',
                'template' => 'initiation-approval-template'
            ],
            [
                'code' => 'initiation_decline',
                'subject' => 'initiation-decline',
                'template' => 'initiation-decline-template'
            ],
            [
                'code' => 'initiation_request_update',
                'subject' => 'initiation-request-update',
                'template' => 'initiation-request-update-template'
            ],
        ];

        foreach ($items as $item) {
            MailContent::where('code', $item['code'])->delete();
        }
    }
}
