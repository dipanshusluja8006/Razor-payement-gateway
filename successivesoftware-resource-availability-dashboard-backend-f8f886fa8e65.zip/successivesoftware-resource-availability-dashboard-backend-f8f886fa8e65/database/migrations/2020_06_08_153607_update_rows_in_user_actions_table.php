<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class UpdateRowsInUserActionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        $item =
            [
                'code' => 'resource-modification',
                'name' => 'Resource Modification',
            ];

        \App\Models\UserAction::updateOrCreate(['code' => 'resource-deallocation'], $item);
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        $item =
            [
                'code' => 'resource-deallocation',
                'name' => 'Resource De-Allocation',
            ];

        \App\Models\UserAction::updateOrCreate(['code' => 'resource-modification'], $item);
    }
}
