<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use App\Models\Role;

class AlterAddColumnCodeToRolesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        $items = [
            [
                'code' => 'admin',
                'role' => 'Admin'
            ],
            [
                'code' => 'global_operation',
                'role' => 'Global Operation'
            ],
            [
                'code' => 'sales',
                'role' => 'Sales'
            ],
            [
                'code' => 'resource_manager',
                'role' => 'Resource Manager'
            ],
            [
                'code' => 'account_manager',
                'role' => 'Account Manager'
            ],
            [
                'code' => 'project_manager',
                'role' => 'Project Manager'
            ],
            [
                'code' => 'bu_head',
                'role' => 'BU Head'
            ]
        ];
        Schema::table('roles', function (Blueprint $table) {
            if ((!Schema::hasColumn('roles', 'code')))
            {
                $items = [
                    [
                        'code' => 'admin',
                        'role' => 'Admin'
                    ],
                    [
                        'code' => 'global_operation',
                        'role' => 'Global Operation'
                    ],
                    [
                        'code' => 'sales',
                        'role' => 'Sales'
                    ],
                    [
                        'code' => 'resource_manager',
                        'role' => 'Resource Manager'
                    ],
                    [
                        'code' => 'account_manager',
                        'role' => 'Account Manager'
                    ],
                    [
                        'code' => 'project_manager',
                        'role' => 'Project Manager'
                    ],
                    [
                        'code' => 'bu_head',
                        'role' => 'BU Head'
                    ]
                ];
                Schema::table('roles', function (Blueprint $table) {
                    $table->string('code')->nullable()->after('id');
                });
                foreach ($items as $item) {
                    \App\Models\Role::where(['role' => $item['role']])->update(['code' => $item['code']]);
                }
            }
        });

        foreach ($items as $item) {
            Role::where(['role' => $item['role']])->update(['code' => $item['code']]);
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('roles', function (Blueprint $table) {
            if (Schema::hasColumn('roles', 'code'))
            {
                $table->dropColumn(['code']);
            }
        });
    }
}
