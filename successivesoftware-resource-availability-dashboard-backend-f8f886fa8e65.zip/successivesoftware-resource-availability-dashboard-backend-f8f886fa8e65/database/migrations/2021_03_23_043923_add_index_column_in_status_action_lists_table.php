<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddIndexColumnInStatusActionListsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('status_action_lists', function (Blueprint $table) {
            $table->index(['status_id','user_action_id']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('status_action_lists', function (Blueprint $table) {
            $table->dropIndex(['status_id','user_action_id']); 
        });
    }
}
