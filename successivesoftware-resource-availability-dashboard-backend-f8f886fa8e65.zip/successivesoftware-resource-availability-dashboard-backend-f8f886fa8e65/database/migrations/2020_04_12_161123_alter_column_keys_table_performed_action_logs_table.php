<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AlterColumnKeysTablePerformedActionLogsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::connection()->getDoctrineSchemaManager()->getDatabasePlatform()->registerDoctrineTypeMapping('enum', 'string');
        Schema::disableForeignKeyConstraints();
        Schema::table('performed_action_logs', function (Blueprint $table) {
            $table->unsignedBigInteger('user_action_id')->change();
            $table->unsignedBigInteger('dept_id')->change();
        });
        Schema::table('performed_action_logs', function (Blueprint $table) {
            $table->foreign('user_action_id')
                ->references('id')
                ->on('user_actions');
            $table->foreign('project_id')
                ->references('uuid')
                ->on('project_details');
            $table->foreign('dept_id')
                ->references('id')
                ->on('departments');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::connection()->getDoctrineSchemaManager()->getDatabasePlatform()->registerDoctrineTypeMapping('enum', 'string');
        Schema::table('performed_action_logs', function (Blueprint $table) {
            $table->dropForeign(['user_action_id']);
            $table->dropForeign(['project_id']);
            $table->dropForeign(['dept_id']);
        });
        Schema::table('performed_action_logs', function (Blueprint $table) {
            $table->integer('user_action_id')->change();
            $table->integer('dept_id')->change();
        });
    }
}
