<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddTwoRecordsForDirectAllocationStatusActionListsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        $userActionArray = [];
        $items = [
            [
                'status_id' => 2,
                'user_action_code' => 'edit-requisition'
            ],
            [
                'status_id' => 2,
                'user_action_code' => 'edit-allocation'
            ],
        ];

        $allUserActions = \App\Models\UserAction::get();
        foreach ($allUserActions as $action) {
            $userActionArray[$action['code']] = $action['id'];
        }
        foreach ($items as $item) {
            $statusActionList = [
                'user_action_id' => ($item['user_action_code']) ? $userActionArray[$item['user_action_code']] : null,
                'status_id' => $item['status_id'],
            ];
            \App\Models\StaticActionList::updateOrCreate($statusActionList, $statusActionList);
        }

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        $items = [
            [
                'status_id' => 2,
                'user_action_code' => 'edit-requisition'
            ],
            [
                'status_id' => 2,
                'user_action_code' => 'edit-allocation'
            ],
        ];

        $allUserActions = \App\Models\UserAction::get();
        foreach ($allUserActions as $action) {
            $userActionArray[$action['code']] = $action['id'];
        }
        foreach ($items as $item) {
            $statusActionList = [
                'user_action_id' => ($item['user_action_code']) ? $userActionArray[$item['user_action_code']] : null,
                'status_id' => $item['status_id'],
            ];
           \App\Models\StaticActionList::where('user_action_id', $statusActionList['user_action_id'])->where('status_id', $statusActionList['status_id'])->delete();
        }
    }
}
