<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AlterTableStatusActionListsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if (Schema::hasTable('status_action_lists')) {
            Schema::table('status_action_lists', function (Blueprint $table) {
                $table->dropColumn('user_action');
                $table->integer('user_action_id')->nullable()->after('status_id');
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        if (Schema::hasTable('status_action_lists')) {
            Schema::table('status_action_lists', function (Blueprint $table) {
                $table->json('user_action')->nullable()->after('status_id');
                $table->dropColumn('user_action_id');
            });
        }
    }
}
