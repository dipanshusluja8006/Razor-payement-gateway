<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProjectRcaDetailsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('project_rca_details', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->uuid('uuid');
            $table->uuid('project_id')->nullable();
            $table->string('issue_detail')->nullable();
            $table->dateTime('date_of_issue_reported_first')->nullable();
            $table->dateTime('date_of_action_reported_first')->nullable();
            $table->integer('issue_reported_by')->nullable();
            $table->string('effort_to_resolve')->nullable();
            $table->string('time_taken_to_fix')->nullable();
            $table->string('prevent_for_future')->nullable();
            $table->string('fixed_by')->nullable();
            $table->enum('issue_priority', ['Low', 'Medium', 'High'])->nullable();
            $table->integer('status')->default('0');
            $table->integer('created_by')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('project_rca_details');
    }
}
