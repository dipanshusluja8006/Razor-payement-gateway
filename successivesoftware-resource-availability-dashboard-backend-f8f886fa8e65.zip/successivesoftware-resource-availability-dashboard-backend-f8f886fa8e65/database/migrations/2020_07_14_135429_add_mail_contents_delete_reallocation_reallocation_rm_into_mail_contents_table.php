<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use App\Models\MailContent;

class AddMailContentsDeleteReallocationReallocationRmIntoMailContentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        $items = [
               [
                'code' => 'delete_reallocation',
                'subject' => 'Delete Resource Reallocation',
                'template' => 'reallocation-delete-template'
              ],
              [
                'code' => 'delete_reallocation_rm',
                'subject' => 'Delete Resource Reallocation',
                'template' => 'reallocation-delete-template'
              ]
        ];
        foreach ($items as $item) {
            MailContent::updateOrCreate(['code' => $item['code']], $item);
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        $items = [
               [
                'code' => 'delete_reallocation',
                'subject' => 'Delete Resource Reallocation',
                'template' => 'reallocation-delete-template'
              ],
              [
                'code' => 'delete_reallocation_rm',
                'subject' => 'Delete Resource Reallocation',
                'template' => 'reallocation-delete-template'
              ]
      ];

       foreach ($items as $item) {
        MailContent::where('code', $item['code'])->delete();
       }
    }
}
