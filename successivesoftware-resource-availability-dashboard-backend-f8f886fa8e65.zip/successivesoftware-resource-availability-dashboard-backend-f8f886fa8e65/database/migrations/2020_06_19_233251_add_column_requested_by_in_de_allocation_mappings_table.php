<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddColumnRequestedByInDeAllocationMappingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('de_allocation_mappings', function (Blueprint $table) {
            if ((!Schema::hasColumn('de_allocation_mappings', 'requested_by')))
            {
                $table->integer('requested_by')->nullable()->after('status');
            }
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('de_allocation_mappings', function (Blueprint $table) {
            if (Schema::hasColumn('de_allocation_mappings', 'requested_by'))
            {
                $table->dropColumn('requested_by');
            }
        });
    }
}
