<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddColumnParentIdIdentifierLifecycleModelIdToProjectsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('projects', function (Blueprint $table) {
            $table->uuid('parent_id')->nullable()->after('project_name');
            $table->string('identifier')->nullable()->after('parent_id');
            $table->integer('lifecycle_model_id')->nullable()->after('identifier');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('projects', function (Blueprint $table) {  
                $table->dropColumn('parent_id');
                $table->dropColumn('identifier');
                $table->dropColumn('lifecycle_model_id');
        });
    }
}
