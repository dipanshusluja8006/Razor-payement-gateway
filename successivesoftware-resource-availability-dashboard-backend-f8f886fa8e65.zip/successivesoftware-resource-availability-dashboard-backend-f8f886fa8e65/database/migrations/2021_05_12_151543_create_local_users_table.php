<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateLocalUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('local_users', function (Blueprint $table) {
            $table->increments('id')->primary;
            $table->integer('user_id')->index();
            $table->string('login')->nullable(false);
            $table->string('hashed_password')->nullable(false);
            $table->string('firstname')->nullable()->index();
            $table->string('lastname')->nullable()->index();
            $table->string('full_name')->nullable()->index();
            $table->string('email')->collation('utf8mb4_bin')->nullable();
            $table->string('job_title')->nullable();
            $table->string('employee_id')->nullable();
            $table->tinyInteger('admin')->default(0)->nullable(false);
            $table->integer('status')->default(1)->nullable(false);
            $table->string('language')->nullable();
            $table->tinyInteger('is_default')->default(0)->nullable(false);
            $table->tinyInteger('notify')->default(1)->nullable(false);
            $table->integer('auth_source_id')->nullable()->index();
            $table->string('type')->nullable()->index();
            $table->string('identity_url')->nullable();
            $table->string('mail_notification')->nullable(false);
            $table->string('salt')->nullable();
            $table->tinyInteger('must_change_passwd')->default(0)->nullable(false);
            $table->dateTime('accept_agreement_at')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('local_users');
    }
}
