<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AlterColumnKeysTableProjectTechnologiesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::connection()->getDoctrineSchemaManager()->getDatabasePlatform()->registerDoctrineTypeMapping('enum', 'string');
        Schema::disableForeignKeyConstraints();
        Schema::table('project_technologies', function (Blueprint $table) {
            $table->unsignedBigInteger('tech_id')->change();
        });
        Schema::table('project_technologies', function (Blueprint $table) {
            $table->foreign('tech_id')
                ->references('id')
                ->on('technologies');
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::connection()->getDoctrineSchemaManager()->getDatabasePlatform()->registerDoctrineTypeMapping('enum', 'string');
        Schema::table('project_technologies', function (Blueprint $table) {
            $table->dropForeign(['tech_id']);
        });
        Schema::table('project_technologies', function (Blueprint $table) {
            $table->integer('tech_id')->change();
        });
    }
}
