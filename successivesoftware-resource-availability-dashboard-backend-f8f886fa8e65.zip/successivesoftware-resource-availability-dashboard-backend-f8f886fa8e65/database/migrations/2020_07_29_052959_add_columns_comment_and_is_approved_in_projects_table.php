<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddColumnsCommentAndIsApprovedInProjectsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('projects', function (Blueprint $table) {
            if ((!Schema::hasColumn('projects', 'comment')))
            {
                $table->mediumText('comment')->nullable()->after('gov_category_id');
            }
            if ((!Schema::hasColumn('projects', 'is_approve')))
            {
                $table->integer('is_approve')->nullable()->after('comment');
            }
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('projects', function (Blueprint $table) {
            if (Schema::hasColumn('projects', 'comment'))
            {
                $table->dropColumn('comment');
            }
            if (Schema::hasColumn('projects', 'is_approve'))
            {
                $table->dropColumn('is_approve');
            }
        });
    }
}
