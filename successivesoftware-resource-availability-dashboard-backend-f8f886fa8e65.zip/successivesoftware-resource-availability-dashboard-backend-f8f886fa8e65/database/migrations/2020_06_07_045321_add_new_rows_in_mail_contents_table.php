<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddNewRowsInMailContentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        $items = [
            [
                'code' => 'extension',
                'subject' => 'Resource Extension',
                'template' => 'extension-template'
            ],
            [
                'code' => 'extension_bu',
                'subject' => 'Resource Extension',
                'template' => 'extension-template'
            ],
            [
                'code' => 'direct_extension',
                'subject' => 'Allocates Resource',
                'template' => 'direct-extension-template'
            ],
            [
                'code' => 'direct_extension_bu',
                'subject' => 'Allocates Resource',
                'template' => 'direct-extension-template'
            ],
            [
                'code' => 'direct_extension_rm',
                'subject' => 'Allocates Resource',
                'template' => 'direct-extension-template'
            ],
        ];

            foreach ($items as $item) {
                \App\Models\MailContent::updateOrCreate(['code' => $item['code']], $item);
            }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        $items = [
            [
                'code' => 'extension',
                'subject' => 'Resource Extension',
                'template' => 'extension-template'
            ],
            [
                'code' => 'extension_bu',
                'subject' => 'Resource Extension',
                'template' => 'extension-template'
            ],
            [
                'code' => 'direct_extension',
                'subject' => 'Allocates Resource',
                'template' => 'direct-extension-template'
            ],
            [
                'code' => 'direct_extension_bu',
                'subject' => 'Allocates Resource',
                'template' => 'direct-extension-template'
            ],
            [
                'code' => 'direct_extension_rm',
                'subject' => 'Allocates Resource',
                'template' => 'direct-extension-template'
            ],
        ];
        foreach ($items as $item) {
            \App\Models\MailContent::where(['code' => $item['code']], $item)->delete();
        }
    }
}
