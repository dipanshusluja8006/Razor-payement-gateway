<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use App\Models\MailContent;

class AddMailContentsEditDeleteDirectAllocationIntoMailContentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        $items = [
               [
                'code' => 'edit_direct_allocation',
                'subject' => 'Edit Resource Direct Allocation',
                'template' => 'direct-allocation-edit-template'
              ],
              [
                'code' => 'delete_direct_allocation',
                'subject' => 'Delete Resource Direct Allocation',
                'template' => 'direct-allocation-delete-template'
              ]
        ];
        foreach ($items as $item) {
            MailContent::updateOrCreate(['code' => $item['code']], $item);
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        $items = [
             [
                'code' => 'edit_direct_allocation',
                'subject' => 'Edit Resource Direct Allocation',
                'template' => 'direct-allocation-edit-template'
             ],
              [
                'code' => 'delete_direct_allocation',
                'subject' => 'Delete Resource Direct Allocation',
                'template' => 'direct-allocation-delete-template'
              ]
      ];

       foreach ($items as $item) {
        MailContent::where('code', $item['code'])->delete();
       }
    }
}
