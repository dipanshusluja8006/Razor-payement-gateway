<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProjectDetailsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('project_details', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->uuid('uuid');
            $table->string('project_name')->nullable();
            $table->string('company_name')->nullable();
            $table->string('company_address')->nullable();
            $table->string('project_domain')->nullable();
            $table->json('client_detail')->nullable();
            $table->integer('billing_type')->nullable();
            $table->string('approved_hours')->nullable();
            $table->string('maximum_hours_billed')->nullable();
            $table->json('project_components')->nullable();
            $table->date('initiation_date')->nullable();
            $table->integer('status')->default('0');
            $table->integer('updated_by')->nullable();
            $table->json('project_documents_link')->nullable();
            $table->text('specific_requests')->nullable();
            $table->text('project_summary')->nullable();
            $table->integer('project_manager_id')->nullable();
            $table->integer('account_manager_id')->nullable();
            $table->integer('created_by')->nullable();
            $table->date('estimated_timeline_to')->nullable();
            $table->date('estimated_timeline_from')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('project_details');
    }
}
