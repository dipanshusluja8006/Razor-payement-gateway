<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class RcaUsers extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        
        Schema::create('rca_users', function (Blueprint $table) {
        $table->bigIncrements('id');
        $table->uuid('rca_id')->nullable();
        $table->integer('user_id')->nullable();
        $table->foreign('rca_id')
                ->references('uuid')
                ->on('project_rca_details');
        $table->timestamps();
       });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('rca_users', function (Blueprint $table) {
            $table->dropForeign(['rca_id']);
        });
        Schema::dropIfExists('rca_users');
    }
}
