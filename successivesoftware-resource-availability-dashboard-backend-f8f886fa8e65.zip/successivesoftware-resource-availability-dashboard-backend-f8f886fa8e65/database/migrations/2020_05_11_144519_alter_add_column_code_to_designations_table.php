<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use App\Models\Designation;

class AlterAddColumnCodeToDesignationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        $items = [
            [
                'code' => 'tech_lead',
                'name' => 'Tech Lead'
            ],
            [
                'code' => 'developer',
                'name' => 'Developer'
            ],
            [
                'code' => 'quality_analyst',
                'name' => 'Quality Analyst'
            ],
            [
                'code' => 'designer',
                'name' => 'Designer'
            ],
            [
                'code' => 'business_analyst',
                'name' => 'Business Analyst'
            ],
            [
                'code' => 'business_development',
                'name' => 'Business Development'
            ],
            [
                'code' => 'project_manager',
                'name' => 'Project Manager'
            ],
            [
                'code' => 'account_manager',
                'name' => 'Account Manager'
            ],
            [
                'code' => 'global_operation',
                'name' => 'Global Operation'
            ]
        ];
        Schema::table('designations', function (Blueprint $table) {
            if ((!Schema::hasColumn('designations', 'code')))
            {
                $table->string('code')->nullable()->after('id');
            }
        });
        foreach ($items as $item) {
            Designation::where(['name' => $item['name']])->update(['code' => $item['code']]);
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('designations', function (Blueprint $table) {
            if (Schema::hasColumn('designations', 'code'))
            {
                $table->dropColumn(['code']);
            }
        });

    }
}
