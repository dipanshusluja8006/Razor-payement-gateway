<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AlterColumnKeysTableAllocatedResourcesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::connection()->getDoctrineSchemaManager()->getDatabasePlatform()->registerDoctrineTypeMapping('enum', 'string');
        Schema::disableForeignKeyConstraints();
        Schema::table('allocated_resources', function (Blueprint $table) {
            $table->unsignedBigInteger('id')->change();
            $table->integer('updated_by')->charset(null)->collation(null)->change();
        });
        Schema::table('allocated_resources', function (Blueprint $table) {
            $table->dropPrimary('id');
            $table->foreign('resource_req_id')
                ->references('uuid')
                ->on('resource_requisitions');
        });
        Schema::table('allocated_resources', function (Blueprint $table) {
            $table->primary(['uuid', 'id']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::connection()->getDoctrineSchemaManager()->getDatabasePlatform()->registerDoctrineTypeMapping('enum', 'string');
        Schema::table('allocated_resources', function (Blueprint $table) {
            $table->dropPrimary(['uuid', 'id']);
        });
        Schema::table('allocated_resources', function (Blueprint $table) {
            $table->bigIncrements('id')->change();
            $table->dropForeign(['resource_req_id']);
        });
        Schema::table('allocated_resources', function (Blueprint $table) {
            $table->primary('id');
            $table->string('updated_by', 36)->change();
        });
    }
}
