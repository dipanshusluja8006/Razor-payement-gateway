<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use App\Models\BillingType;

class AlterAddColumnCodeToBillingTypesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        $items = [
            [
                'code' => 'fixed_cost',
                'name' => 'Fixed Cost'
            ],
            [
                'code' => 'hourly',
                'name' => 'Hourly'
            ],
            [
                'code' => 'retainer',
                'name' => 'Retainer'
            ]
        ];
        Schema::table('billing_types', function (Blueprint $table) {
            $table->string('code')->nullable()->after('id');
        });
        foreach ($items as $item) {
            BillingType::where(['name' => $item['name']])->update(['code' => $item['code']]);
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('billing_types', function (Blueprint $table) {
            $table->dropColumn('code');
        });
    }
}
