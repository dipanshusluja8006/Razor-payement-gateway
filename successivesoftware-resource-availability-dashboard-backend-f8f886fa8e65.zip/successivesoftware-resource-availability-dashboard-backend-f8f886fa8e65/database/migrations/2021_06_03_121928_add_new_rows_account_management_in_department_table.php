<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddNewRowsAccountManagementInDepartmentTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        $items = [
            [
                'code' => 'account_management',
                'name' => 'Account Management'
            ]
        ];

            foreach ($items as $item) {
                \App\Models\Department::updateOrCreate(['code' => $item['code']], $item);
            }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        $items = [
            [
                'code' => 'account_management',
                'name' => 'Account Management'
            ]
        ];
            foreach ($items as $item) {
               \App\Models\Department::where(['code' => $item['code']], $item)->delete();
            }
    }
}
