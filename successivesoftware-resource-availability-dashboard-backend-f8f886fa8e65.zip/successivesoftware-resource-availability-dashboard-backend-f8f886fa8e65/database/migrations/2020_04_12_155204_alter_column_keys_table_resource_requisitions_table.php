<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AlterColumnKeysTableResourceRequisitionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::connection()->getDoctrineSchemaManager()->getDatabasePlatform()->registerDoctrineTypeMapping('enum', 'string');
        Schema::disableForeignKeyConstraints();
        Schema::table('resource_requisitions', function (Blueprint $table) {
            $table->unsignedBigInteger('id')->change();
            $table->unsignedBigInteger('dept_id')->change();
            $table->unsignedBigInteger('tech_id')->change();
            $table->unsignedBigInteger('role_id')->change();
        });
        Schema::table('resource_requisitions', function (Blueprint $table) {
            $table->dropPrimary('id');
            $table->primary('uuid');
            $table->foreign('project_id')
                ->references('uuid')
                ->on('project_details');
            $table->foreign('dept_id')
                ->references('id')
                ->on('departments');
            $table->foreign('tech_id')
                ->references('id')
                ->on( 'technologies');
            $table->foreign('role_id')
                ->references('id')
                ->on( 'roles');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::connection()->getDoctrineSchemaManager()->getDatabasePlatform()->registerDoctrineTypeMapping('enum', 'string');
        Schema::table('resource_requisitions', function (Blueprint $table) {
            $table->dropPrimary('uuid');
            $table->bigIncrements('id')->change();
            $table->dropForeign(['project_id']);
            $table->dropForeign(['dept_id']);
            $table->dropForeign(['tech_id']);
            $table->dropForeign(['role_id']);
        });
        Schema::table('resource_requisitions', function (Blueprint $table) {
            $table->primary('id');
            $table->integer('dept_id')->change();
            $table->integer('tech_id')->change();
            $table->integer('role_id')->change();
        });

    }
}
