<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddReasonToResourceRequisitionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('resource_requisitions', function (Blueprint $table) {
            $table->string('reason')->nullable()->after('suggested_resource');
            $table->string('other_reason')->nullable()->after('reason');
            $table->dateTime('tentative_date')->nullable()->after('other_reason');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('resource_requisitions', function (Blueprint $table) {
            $table->dropColumn('reason');
            $table->dropColumn('other_reason');
            $table->dropColumn('tentative_date');
        });
    }
}
