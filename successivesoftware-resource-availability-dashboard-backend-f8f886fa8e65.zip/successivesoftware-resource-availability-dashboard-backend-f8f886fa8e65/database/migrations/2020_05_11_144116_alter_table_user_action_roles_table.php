<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AlterTableUserActionRolesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if (Schema::hasTable('user_action_roles')) {
            Schema::table('user_action_roles', function (Blueprint $table) {
                $table->dropColumn('role');
                $table->integer('role_id')->nullable()->after('user_action_id');
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        if (Schema::hasTable('user_action_roles')) {
            Schema::table('user_action_roles', function (Blueprint $table) {
                $table->json('role')->after('user_action_id');
                $table->dropColumn('role_id');
            });
        }
    }
}
