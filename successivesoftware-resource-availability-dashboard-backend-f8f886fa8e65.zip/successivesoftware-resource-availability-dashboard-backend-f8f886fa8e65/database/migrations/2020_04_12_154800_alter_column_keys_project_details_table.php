<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AlterColumnKeysProjectDetailsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::connection()->getDoctrineSchemaManager()->getDatabasePlatform()->registerDoctrineTypeMapping('enum', 'string');
        Schema::disableForeignKeyConstraints();
        Schema::table('project_details', function (Blueprint $table) {
            $table->unsignedBigInteger('id')->change();
            $table->unsignedBigInteger('billing_type')->change();
        });
        Schema::table('project_details', function (Blueprint $table) {
            $table->dropPrimary('id');
            $table->primary('uuid');
            $table->foreign('billing_type')
                ->references('id')
                ->on('billing_types');
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::connection()->getDoctrineSchemaManager()->getDatabasePlatform()->registerDoctrineTypeMapping('enum', 'string');
        Schema::table('project_details', function (Blueprint $table) {
            $table->dropPrimary('uuid');
            $table->bigIncrements('id')->change();
            $table->dropForeign(['billing_type']);
        });
        Schema::table('project_details', function (Blueprint $table) {
            $table->primary('id');
            $table->integer('billing_type')->change();
        });

    }

}
