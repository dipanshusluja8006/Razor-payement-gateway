<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProjectActionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('project_actions', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->uuid('uuid');
            $table->string('link_id')->nullable();
            $table->string('comment')->nullable();
            $table->date('from')->nullable();
            $table->date('to')->nullable();
            $table->integer('status_id')->nullable();
            $table->integer('requested_by')->nullable();
            $table->integer('response_by')->nullable();
            $table->integer('previous_status')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('project_actions');
    }
}
