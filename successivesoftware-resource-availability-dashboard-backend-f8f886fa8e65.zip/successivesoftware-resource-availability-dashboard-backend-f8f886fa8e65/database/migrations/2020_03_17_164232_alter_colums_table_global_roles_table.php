<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AlterColumsTableGlobalRolesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if(Schema::hasTable('global_roles')) {
            Schema::table('global_roles', function (Blueprint $table) {
                $table->string('user_id', 10)->change();
                $table->string('role_id', 10)->change();
                $table->string('dept_id', 10)->change();
            });
         }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        if(Schema::hasTable('global_roles')){
            Schema::table('global_roles', function (Blueprint $table) {
            $table->integer('user_id')->charset(null)->collation(null)->change();
            $table->integer('role_id')->charset(null)->collation(null)->change();
            $table->integer('dept_id')->charset(null)->collation(null)->change();
            });
        }
    }
}
