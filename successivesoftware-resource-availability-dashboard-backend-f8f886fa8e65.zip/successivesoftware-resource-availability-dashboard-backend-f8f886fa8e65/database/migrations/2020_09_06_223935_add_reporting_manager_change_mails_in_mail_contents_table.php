<?php

use Illuminate\Database\Migrations\Migration;
use App\Models\MailContent;

class AddReportingManagerChangeMailsInMailContentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {

        $items = [
            [
                'code' => 'reporting_manager_change_request',
                'subject' => 'Reporting Manager Change Request',
                'template' => 'reporting-manager-change-request-template'
            ],
            [
                'code' => 'reporting_manager_approval',
                'subject' => 'Reporting Manager Approval',
                'template' => 'reporting-manager-approval-template'
            ],
            [
                'code' => 'reporting_manager_decline',
                'subject' => 'Reporting Manager update declined',
                'template' => 'reporting-manager-update-declined-template'
            ],
            [
                'code' => 'reporting_manager_changes',
                'subject' => 'Reporting Manager Changes',
                'template' => 'reporting-manager-changes-template'
            ],
            [
                'code' => 'reporting_manager_system_changes',
                'subject' => 'Reporting Manager Changes By System',
                'template' => 'reporting-manager-system-changes-template'
            ]
        ];
        foreach ($items as $item) {
            MailContent::updateOrCreate(['code' => $item['code']], $item);
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        $items = [
            [
                'code' => 'reporting_manager_change_request',
                'subject' => 'Reporting Manager Change Request',
                'template' => 'reporting-manager-change-request-template'
            ],
            [
                'code' => 'reporting_manager_approval',
                'subject' => 'Reporting Manager Approval',
                'template' => 'reporting-manager-approval-template'
            ],
            [
                'code' => 'reporting_manager_decline',
                'subject' => 'Reporting Manager update declined',
                'template' => 'reporting-manager-update-declined-template'
            ],
            [
                'code' => 'reporting_manager_changes',
                'subject' => 'Reporting Manager Changes',
                'template' => 'reporting-manager-changes-template'
            ],
            [
                'code' => 'reporting_manager_system_changes',
                'subject' => 'Reporting Manager Changes By System',
                'template' => 'reporting-manager-system-changes-template'
            ]
        ];

        foreach ($items as $item) {
            MailContent::where('code', $item['code'])->delete();
        }
    }
}

