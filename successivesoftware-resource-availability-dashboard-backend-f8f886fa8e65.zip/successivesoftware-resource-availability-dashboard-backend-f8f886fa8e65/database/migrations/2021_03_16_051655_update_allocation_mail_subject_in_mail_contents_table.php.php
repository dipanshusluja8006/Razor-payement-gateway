<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use App\Models\MailContent;

class UpdateAllocationMailSubjectInMailContentsTable extends Migration
{

    /**

     * Run the migrations.

     *

     * @return void

     */

    public function up()

    {


        $items = [

            [

                'code' => 'partial_allocation',

                'subject' => 'Resource Partially Allocated',

                'template' => 'partial-allocation-template'

            ],

            [

                'code' => 'partial_allocation_bu',

                'subject' => 'Resource Partially Allocated',

                'template' => 'partial-allocation-template'

            ],

            [

                'code' => 'allocation',

                'subject' => 'Resource Allocated',

                'template' => 'fully-allocation-template'

            ],

            [

                'code' => 'allocation_go_sales',

                'subject' => 'Resource Allocated',

                'template' => 'fully-allocation-template'

            ],

            [

                'code' => 'allocation_rm',

                'subject' => 'Resource Allocated',

                'template' => 'fully-allocation-template'

            ]

        ];

        foreach ($items as $item) {

            MailContent::updateOrCreate(['code' => $item['code']], $item);

        }

    }


    /**

     * Reverse the migrations.

     *

     * @return void

     */

    public function down()

    {

        $items = [

            [

                'code' => 'partial_allocation',

                'subject' => 'Partially Allocates Resource',

                'template' => 'partial-allocation-template'

            ],

            [

                'code' => 'partial_allocation_bu',

                'subject' => 'Partially Allocates Resource',

                'template' => 'partial-allocation-template'

            ],

            [

                'code' => 'allocation',

                'subject' => 'Allocates Resource',

                'template' => 'fully-allocation-template'

            ],

            [

                'code' => 'allocation_go_sales',

                'subject' => 'Allocates Resource',

                'template' => 'fully-allocation-template'

            ],

            [

                'code' => 'allocation_rm',

                'subject' => 'Allocates Resource',

                'template' => 'fully-allocation-template'

            ]

        ];


        foreach ($items as $item) {

            MailContent::updateOrCreate(['code' => $item['code']], $item);

        }

    }

}
