<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateExperiencePercentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('experience_percents', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->uuid('pyramid_id')->nullable();
            $table->foreign('pyramid_id')
                ->references('uuid')
                ->on('pyramids');
            $table->integer('percent')->nullable();
            $table->float('min_experience', 5, 1)->nullable();
            $table->float('max_experience', 5, 1)->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('experience_percents');
    }
}
