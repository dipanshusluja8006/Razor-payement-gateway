<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class ChangeColumnTypeTimeTakenToFixInProjectRcaDetailsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('project_rca_details', function (Blueprint $table) {
        if (Schema::hasColumn('project_rca_details', 'time_taken_to_fix'))
          {
           $table->dropColumn('time_taken_to_fix');
          }
        });
        Schema::table('project_rca_details', function (Blueprint $table) {
        if ((!Schema::hasColumn('project_rca_details', 'time_taken_to_fix')))
           {
            $table->integer('time_taken_to_fix')->nullable()->after('resolve_issue_type');
           }
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('project_rca_details', function (Blueprint $table) {
            $table->string('time_taken_to_fix')->nullable()->change();
        });
    }
}
