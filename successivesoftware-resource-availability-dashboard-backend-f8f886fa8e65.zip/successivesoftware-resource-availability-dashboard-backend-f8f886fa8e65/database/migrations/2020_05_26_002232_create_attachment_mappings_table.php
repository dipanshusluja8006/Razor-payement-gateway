<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAttachmentMappingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('attachment_mappings', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->uuid('link_id');
            $table->bigInteger('attachment_id')->unsigned();
            $table->foreign('attachment_id')->references('id')->on('attachments');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('attachment_mappings');
    }
}
