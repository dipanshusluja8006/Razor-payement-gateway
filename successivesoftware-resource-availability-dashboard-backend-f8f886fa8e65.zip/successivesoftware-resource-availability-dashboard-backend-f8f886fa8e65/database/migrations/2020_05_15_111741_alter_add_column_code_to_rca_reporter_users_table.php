<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use App\Models\RcaReporterUser;

class AlterAddColumnCodeToRcaReporterUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        $items = [
            [
                'code' => 'client',
                'name' => 'Client'
            ],
            [
                'code' => 'anyone_else',
                'name' => 'Anyone else with the organization'
            ],
            [
                'code' => 'project_team',
                'name' => 'Project Team(Developers, QAs, BAs, etc)'
            ],
            [
                'code' => 'anonymous_user',
                'name' => 'Anonymous User'
            ]
        ];
        Schema::table('rca_reporter_users', function (Blueprint $table) {
            $table->string('code')->nullable()->after('id');
        });
        foreach ($items as $item) {
            $rcaReporterUsers = RcaReporterUser::where('name', $item['name'])->first();
            if($rcaReporterUsers){
                RcaReporterUser::where(['name' => $item['name']])->update(['code' => $item['code']]);
            }
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('rca_reporter_users', function (Blueprint $table) {
            $table->dropColumn('code');
        });
    }
}
