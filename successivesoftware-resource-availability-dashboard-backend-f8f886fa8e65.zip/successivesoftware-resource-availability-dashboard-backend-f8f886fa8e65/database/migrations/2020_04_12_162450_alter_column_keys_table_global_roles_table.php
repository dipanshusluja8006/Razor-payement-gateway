<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AlterColumnKeysTableGlobalRolesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::connection()->getDoctrineSchemaManager()->getDatabasePlatform()->registerDoctrineTypeMapping('enum', 'string');
        Schema::disableForeignKeyConstraints();
        Schema::table('global_roles', function (Blueprint $table) {
            $table->integer('user_id')->charset(null)->collation(null)->change();
            $table->unsignedBigInteger('role_id')->charset(null)->collation(null)->change();
            $table->unsignedBigInteger('dept_id')->charset(null)->collation(null)->change();
        });
        Schema::table('global_roles', function (Blueprint $table) {
            $table->foreign('role_id')
                ->references('id')
                ->on('user_roles');
            $table->foreign('dept_id')
                ->references('id')
                ->on('departments');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::connection()->getDoctrineSchemaManager()->getDatabasePlatform()->registerDoctrineTypeMapping('enum', 'string');
        Schema::table('global_roles', function (Blueprint $table) {
            $table->dropForeign(['role_id']);
            $table->dropForeign(['dept_id']);
        });
        Schema::table('global_roles', function (Blueprint $table) {
            $table->string('user_id', 36)->change();
            $table->string('role_id', 36)->change();
            $table->string('dept_id', 36)->change();
        });
    }
}
