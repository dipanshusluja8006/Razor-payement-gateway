<?php

use Illuminate\Database\Seeder;
use App\Models\RcaReporterUser;
class RcaReporterUsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $items = [
            [
                'code' => 'client',
                'name' => 'Client'
            ],
            [
                'code' => 'anyone_else',
                'name' => 'Anyone else with the organization'
            ],
            [
                'code' => 'project_team',
                'name' => 'Project Team(Developers, QAs, BAs, etc)'
            ],
            [
                'code' => 'anonymous_user',
                'name' => 'Anonymous User'
            ]
        ];

        foreach ($items as $item) {
            RcaReporterUser::updateOrCreate(['code' => $item['code']], $item);
        }

    }
}
