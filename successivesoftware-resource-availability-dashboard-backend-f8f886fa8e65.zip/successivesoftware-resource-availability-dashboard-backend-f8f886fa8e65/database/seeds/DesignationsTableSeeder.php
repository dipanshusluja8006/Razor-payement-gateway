<?php

use Illuminate\Database\Seeder;
use App\Models\Designation;

class DesignationsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $items = [
            [
                'code' => 'tech_lead',
                'name' => 'Tech Lead'
            ],
            [
                'code' => 'developer',
                'name' => 'Developer'
            ],
            [
                'code' => 'quality_analyst',
                'name' => 'Quality Analyst'
            ],
            [
                'code' => 'designer',
                'name' => 'Designer'
            ],
            [
                'code' => 'business_analyst',
                'name' => 'Business Analyst'
            ],
            [
                'code' => 'business_development',
                'name' => 'Business Development'
            ],
            [
                'code' => 'project_manager',
                'name' => 'Project Manager'
            ],
            [
                'code' => 'account_manager',
                'name' => 'Account Manager'
            ],
            [
                'code' => 'global_operation',
                'name' => 'Global Operation'
            ]
        ];

        foreach ($items as $item) {
            Designation::updateOrCreate(['code' => $item['code']], $item);
        }
    }
}
