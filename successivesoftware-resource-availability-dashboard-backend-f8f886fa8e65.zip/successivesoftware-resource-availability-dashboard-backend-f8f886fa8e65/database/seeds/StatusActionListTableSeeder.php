<?php

use Illuminate\Database\Seeder;
use Carbon\Carbon;

class StatusActionListTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $userActionArray = [];

        $items = [
            //new status for initiation-request
            [
                'status_id' => 17,
                'user_action_code' => 'initiation-request'
            ],
            [
                'status_id' => 17,
                'user_action_code' => 'initiation-approval'
            ],

            [
                'status_id' => 1,
                'user_action_code' => 'creation-request'
            ],
            [
                'status_id' => 2,
                'user_action_code' => 'resource-requisition'
            ],
            [
                'status_id' => 2,
                'user_action_code' => 'resource-mapping'
            ],
            [
                'status_id' => 2,
                'user_action_code' => 'resource-modification'
            ],
            [
                'status_id' => 2,
                'user_action_code' => 'resource-deallocation-resource-manager'
            ],
            [
                'status_id' => 2,
                'user_action_code' => 'hold-request'
            ],
            [
                'status_id' => 2,
                'user_action_code' => 'project-closure'
            ],
            [
                'status_id' => 3,
                'user_action_code' => 'resource-allocation'
            ],
            [
                'status_id' => 3,
                'user_action_code' => 'edit-requisition'
            ],
            [
                'status_id' => 3,
                'user_action_code' => 'edit-allocation'
            ],
            [
                'status_id' => 3,
                'user_action_code' => 'resource-requisition'
            ],
            [
                'status_id' => 3,
                'user_action_code' => 'resource-mapping'
            ],
            [
                'status_id' => 3,
                'user_action_code' => 'resource-allocation-manager'
            ],
            [
                'status_id' => 3,
                'user_action_code' => 'resource-reallocation'
            ],
            [
                'status_id' => 3,
                'user_action_code' => 'hold-request'
            ],
            [
                'status_id' => 3,
                'user_action_code' => 'resource-modification'
            ],
            [
                'status_id' => 3,
                'user_action_code' => 'resource-deallocation-resource-manager'
            ],
            [
                'status_id' => 3,
                'user_action_code' => 'project-closure'
            ],
            [
                'status_id' => 4,
                'user_action_code' => 'resource-allocation-manager'
            ],
            [
                'status_id' => 4,
                'user_action_code' => 'resource-requisition'
            ],
            [
                'status_id' => 4,
                'user_action_code' => 'resource-mapping'
            ],
            [
                'status_id' => 4,
                'user_action_code' => 'edit-allocation'
            ],
            [
                'status_id' => 4,
                'user_action_code' => 'resource-reallocation'
            ],
            [
                'status_id' => 4,
                'user_action_code' => 'hold-request'
            ],
            [
                'status_id' => 4,
                'user_action_code' => 'resource-modification'
            ],
            [
                'status_id' => 4,
                'user_action_code' => 'resource-deallocation-resource-manager'
            ],
            [
                'status_id' => 4,
                'user_action_code' => 'project-closure'
            ],
            [
                'status_id' => 14,
                'user_action_code' => 'resource-mapping'
            ],
            [
                'status_id' => 14,
                'user_action_code' => 'resource-allocation'
            ],
            [
                'status_id' => 14,
                'user_action_code' => 'edit-requisition'
            ],
            [
                'status_id' => 14,
                'user_action_code' => 'edit-allocation'
            ],
            [
                'status_id' => 14,
                'user_action_code' => 'resource-allocation-manager'
            ],
            [
                'status_id' => 14,
                'user_action_code' => 'resource-requisition'
            ],
            [
                'status_id' => 14,
                'user_action_code' => 'resource-reallocation'
            ],
            [
                'status_id' => 14,
                'user_action_code' => 'hold-request'
            ],
            [
                'status_id' => 14,
                'user_action_code' => 'resource-modification'
            ],
            [
                'status_id' => 14,
                'user_action_code' => 'resource-deallocation-resource-manager'
            ],
            [
                'status_id' => 14,
                'user_action_code' => 'project-closure'
            ],
            [
                'status_id' => 15,
                'user_action_code' => 'resource-mapping'
            ],
            [
                'status_id' => 15,
                'user_action_code' => 'edit-allocation'
            ],
            [
                'status_id' => 15,
                'user_action_code' => 'resource-allocation-manager'
            ],
            [
                'status_id' => 15,
                'user_action_code' => 'resource-requisition'
            ],
            [
                'status_id' => 15,
                'user_action_code' => 'resource-reallocation'
            ],
            [
                'status_id' => 15,
                'user_action_code' => 'hold-request'
            ],
            [
                'status_id' => 15,
                'user_action_code' => 'resource-modification'
            ],
            [
                'status_id' => 15,
                'user_action_code' => 'resource-deallocation-resource-manager'
            ],
            [
                'status_id' => 15,
                'user_action_code' => 'project-closure'
            ],
            [
                'status_id' => 7,
                'user_action_code' => 'resource-mapping'
            ],
            [
                'status_id' => 7,
                'user_action_code' => 'resource-allocation'
            ],
            [
                'status_id' => 7,
                'user_action_code' => 'edit-requisition'
            ],
            [
                'status_id' => 7,
                'user_action_code' => 'edit-allocation'
            ],
            [
                'status_id' => 7,
                'user_action_code' => 'resource-allocation-manager'
            ],
            [
                'status_id' => 7,
                'user_action_code' => 'resource-requisition'
            ],
            [
                'status_id' => 7,
                'user_action_code' => 'resource-reallocation'
            ],
            [
                'status_id' => 7,
                'user_action_code' => 'hold-request'
            ],
            [
                'status_id' => 7,
                'user_action_code' => 'resource-modification'
            ],
            [
                'status_id' => 7,
                'user_action_code' => 'resource-deallocation-resource-manager'
            ],
            [
                'status_id' => 7,
                'user_action_code' => 'project-closure'
            ],
            [
                'status_id' => 11,
                'user_action_code' => 'hold-request-approval'
            ],
            [
                'status_id' => 11,
                'user_action_code' => 'project-closure'
            ],
            [
                'status_id' => 12,
                'user_action_code' => 'restart'
            ],
            [
                'status_id' => 12,
                'user_action_code' => 'project-closure'
            ],
            [
                'status_id' => 13,
                'user_action_code' => 'restart'
            ],
            [
                'status_id' => 9,
                'user_action_code' => 'resource-mapping'
            ],
            [
                'status_id' => 9,
                'user_action_code' => 'resource-allocation'
            ],
            [
                'status_id' => 9,
                'user_action_code' => 'edit-requisition'
            ],
            [
                'status_id' => 9,
                'user_action_code' => 'edit-allocation'
            ],
            [
                'status_id' => 9,
                'user_action_code' => 'resource-allocation-manager'
            ],
            [
                'status_id' => 9,
                'user_action_code' => 'resource-requisition'
            ],
            [
                'status_id' => 9,
                'user_action_code' => 'resource-reallocation'
            ],
            [
                'status_id' => 9,
                'user_action_code' => 'hold-request'
            ],
            [
                'status_id' => 9,
                'user_action_code' => 'project-closure'
            ],
            [
                'status_id' => 9,
                'user_action_code' => 'resource-deallocation-resource-manager'
            ],
            [
                'status_id' => 16,
                'user_action_code' => 'resource-deallocation-resource-manager'
            ],
            [
                'status_id' => 16,
                'user_action_code' => 'resource-mapping'
            ],
            [
                'status_id' => 16,
                'user_action_code' => 'resource-allocation'
            ],
            [
                'status_id' => 16,
                'user_action_code' => 'edit-requisition'
            ],
            [
                'status_id' => 16,
                'user_action_code' => 'edit-allocation'
            ],
            [
                'status_id' => 16,
                'user_action_code' => 'resource-allocation-manager'
            ],
            [
                'status_id' => 16,
                'user_action_code' => 'resource-requisition'
            ],
            [
                'status_id' => 16,
                'user_action_code' => 'resource-reallocation'
            ],
            [
                'status_id' => 16,
                'user_action_code' => 'hold-request'
            ],
            [
                'status_id' => 16,
                'user_action_code' => 'resource-modification'
            ],
            [
                'status_id' => 16,
                'user_action_code' => 'project-closure'
            ],
            [
                'status_id' => 12,
                'user_action_code' => 'resource-deallocation-resource-manager'
            ],
            [
                'status_id' => 13,
                'user_action_code' => 'resource-deallocation-resource-manager'
            ],
            [
                'status_id' => 4,
                'user_action_code' => 'edit-requisition'
            ],
            [
                'status_id' => 4,
                'user_action_code' => 'resource-allocation'
            ],
            [
                'status_id' => 15,
                'user_action_code' => 'resource-allocation'
            ],
        ];

        $allUserActions = \App\Models\UserAction::get();
        foreach ($allUserActions as $action) {
            $userActionArray[$action['code']] = $action['id'];
        }

        \App\Models\StaticActionList::truncate();
        foreach ($items as $item) {
            $statusActionList = [
                'user_action_id' => ($item['user_action_code']) ? $userActionArray[$item['user_action_code']] : null,
                'status_id' => $item['status_id'],
            ];
            \App\Models\StaticActionList::updateOrCreate($statusActionList, $statusActionList);
        }
    }
}
