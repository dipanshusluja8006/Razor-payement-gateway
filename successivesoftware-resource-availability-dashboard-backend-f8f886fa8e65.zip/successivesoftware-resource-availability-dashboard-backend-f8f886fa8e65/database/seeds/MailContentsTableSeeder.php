<?php

use Illuminate\Database\Seeder;
use App\Models\MailContent;

class MailContentsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $items = [
            [
                'code' => 'initiation',
                'subject' => 'Project Initiation',
                'template' => 'initiation-template'
            ],
            [
                'code' => 'initiation_rm',
                'subject' => 'Project Initiation',
                'template' => 'initiation-template'
            ],
            [
                'code' => 'project_detail_updation',
                'subject' => 'Project Details Updated',
                'template' => 'project-detail-updation-template'
            ],
            [
                'code' => 'project_detail_updation_rm',
                'subject' => 'Project Details Updated',
                'template' => 'project-detail-updation-template'
            ],
            [
                'code' => 'creation',
                'subject' => 'Project Creation',
                'template' => 'creation-template'
            ],
            [
                'code' => 'creation_go_sales',
                'subject' => 'Project Creation',
                'template' => 'creation-template'
            ],
            [
                'code' => 'requisition',
                'subject' => 'Resource Requisition',
                'template' => 'requisition-template'
            ],
            [
                'code' => 'requisition_bu',
                'subject' => 'Resource Requisition',
                'template' => 'requisition-template'
            ],
            [
                'code' => 'edit_requisition',
                'subject' => 'Edit Resource Requisition',
                'template' => 'requisition-edit-template'
            ],
            [
                'code' => 'edit_requisition_bu',
                'subject' => 'Edit Resource Requisition',
                'template' => 'requisition-edit-template'
            ],
            [
                'code' => 'delete_requisition',
                'subject' => 'Delete Resource Requisition',
                'template' => 'requisition-delete-template'
            ],
            [
                'code' => 'delete_requisition_bu',
                'subject' => 'Delete Resource Requisition',
                'template' => 'requisition-delete-template'
            ],
            [
                'code' => 'edit_allocation',
                'subject' => 'Edit Resource Allocation',
                'template' => 'allocation-edit-template'
            ],
            [
                'code' => 'edit_allocation_rm',
                'subject' => 'Edit Resource Allocation',
                'template' => 'allocation-edit-template'
            ],
            [
                'code' => 'delete_allocation',
                'subject' => 'Delete Resource Allocation',
                'template' => 'allocation-delete-template'
            ],
            [
                'code' => 'delete_allocation_rm',
                'subject' => 'Delete Resource Allocation',
                'template' => 'allocation-delete-template'
            ],
            [
                'code' => 'partial_allocation',
                'subject' => 'Partially Allocates Resource',
                'template' => 'partial-allocation-template'
            ],
            [
                'code' => 'partial_allocation_bu',
                'subject' => 'Partially Allocates Resource',
                'template' => 'partial-allocation-template'
            ],
            [
                'code' => 'allocation',
                'subject' => 'Allocates Resource',
                'template' => 'fully-allocation-template'
            ],
            [
                'code' => 'allocation_go_sales',
                'subject' => 'Allocates Resource',
                'template' => 'fully-allocation-template'
            ],
            [
                'code' => 'allocation_rm',
                'subject' => 'Allocates Resource',
                'template' => 'fully-allocation-template'
            ],
            [
                'code' => 'mapping',
                'subject' => 'Resource Mapping',
                'template' => 'resource-mapping-template'
            ],
            [
                'code' => 'mapping_bu',
                'subject' => 'Resource Mapping',
                'template' => 'resource-mapping-template'
            ],
            [
                'code' => 'de_allocation',
                'subject' => 'Resource Deallocation',
                'template' => 'de-allocation-template'
            ],
            [
                'code' => 'de_allocation_bu',
                'subject' => 'Resource Deallocation',
                'template' => 'de-allocation-template'
            ],
            [
                'code' => 'de_allocation_rm',
                'subject' => 'Resource Deallocation',
                'template' => 'de-allocation-template'
            ],
            [
                'code' => 'partial_resource_deallocation',
                'subject' => 'Partial Resource Deallocation',
                'template' => 'partial-de-allocation-template'
            ],
            [
                'code' => 'partial_resource_deallocation_bu',
                'subject' => 'Partial Resource Deallocation',
                'template' => 'partial-de-allocation-template'
            ],
            [
                'code' => 'partial_resource_deallocation_rm',
                'subject' => 'Partial Resource Deallocation',
                'template' => 'partial-de-allocation-template'
            ],
            [
                'code' => 'de_allocation_mapping',
                'subject' => 'Resource DeAllocation Mapping',
                'template' => 'resource-demapping-template'
            ],
            [
                'code' => 'de_allocation_mapping_bu',
                'subject' => 'Resource DeAllocation Mapping',
                'template' => 'resource-demapping-template'
            ],
            [
                'code' => 'resource_allocation_rejection',
                'subject' => 'Resource Allocation rejection',
                'template' => 'allocation-approve-reject-template'
            ],
            [
                'code' => 'resource_allocation_rejection_bu',
                'subject' => 'Resource Allocation rejection',
                'template' => 'allocation-approve-reject-template'
            ],
            [
                'code' => 'resource_allocation_rejection_go_sales',
                'subject' => 'Resource Allocation rejection',
                'template' => 'allocation-approve-reject-template'
            ],
            [
                'code' => 'resource_allocation_approval',
                'subject' => 'Resource Allocation approval',
                'template' => 'allocation-approve-reject-template'
            ],
            [
                'code' => 'resource_allocation_approval_bu',
                'subject' => 'Resource Allocation approval',
                'template' => 'allocation-approve-reject-template'
            ],
            [
                'code' => 'resource_allocation_approval_rm',
                'subject' => 'Resource Allocation approval',
                'template' => 'allocation-approve-reject-template'
            ],
            [
                'code' => 'resource_allocation_approval_go_sales',
                'subject' => 'Resource Allocation approval',
                'template' => 'allocation-approve-reject-template'
            ],
            [
                'code' => 'resource_reallocation',
                'subject' => 'Resource Reallocation',
                'template' => 'resource-reallocation-template'
            ],
            [
                'code' => 'resource_reallocation_rm',
                'subject' => 'Resource Reallocation',
                'template' => 'resource-reallocation-template'
            ],
            [
                'code' => 'resource_reallocation_go_sales',
                'subject' => 'Resource Reallocation',
                'template' => 'resource-reallocation-template'
            ],
            [
                'code' => 'resource_reallocation_partial',
                'subject' => 'Resource Reallocation',
                'template' => 'resource-reallocation-partially-template'
            ],
            [
                'code' => 'on_hold_request',
                'subject' => 'Project On Hold Request',
                'template' => 'project-onhold-template'
            ],
            [
                'code' => 'on_hold_request_go_sales',
                'subject' => 'Project On Hold Request',
                'template' => 'project-onhold-template'
            ],
            [
                'code' => 'on_hold_approved',
                'subject' => 'Project On Hold Request Approved',
                'template' => 'onhold-approved-reject-template'
            ],
            [
                'code' => 'on_hold_approved_rm',
                'subject' => 'Project On Hold Request Approved',
                'template' => 'onhold-unmapping-reminder-rm'
            ],
            [
                'code' => 'on_hold_rejection',
                'subject' => 'Project On Hold Request rejection',
                'template' => 'onhold-approved-reject-template'
            ],
            [
                'code' => 'project_close',
                'subject' => 'Project Close',
                'template' => 'project-close-template'
            ],
            [
                'code' => 'project_close_rm',
                'subject' => 'Project Close',
                'template' => 'project-close-template-rm'
            ],
            [
                'code' => 'project_close_go_sales',
                'subject' => 'Project Close',
                'template' => 'project-close-template'
            ],
            [
                'code' => 'restart',
                'subject' => 'Project Restart',
                'template' => 'project-restart-template'
            ],
            [
                'code' => 'restart_rm',
                'subject' => 'Project Restart',
                'template' => 'project-restart-template'
            ],
            [
                'code' => 'restart_go_sales',
                'subject' => 'Project Restart',
                'template' => 'project-restart-template'
            ],
            [
                'code' => 'rca_creation',
                'subject' => 'Rca Creation',
                'template' => 'rca-creation-template'
            ],
            [
                'code' => 'extension',
                'subject' => 'Resource Extension',
                'template' => 'extension-template'
            ],
            [
                'code' => 'extension_bu',
                'subject' => 'Resource Extension',
                'template' => 'extension-template'
            ],
            [
                'code' => 'direct_extension',
                'subject' => 'Allocates Resource',
                'template' => 'direct-extension-template'
            ],
            [
                'code' => 'direct_extension_bu',
                'subject' => 'Allocates Resource',
                'template' => 'direct-extension-template'
            ],
            [
                'code' => 'direct_extension_rm',
                'subject' => 'Allocates Resource',
                'template' => 'direct-extension-template'
            ],
            [
                'code' => 'edit_extension_requisition',
                'subject' => 'Edit Resource Extension Requisition',
                'template' => 'requisition-extension-edit-template'
            ],
            [
                'code' => 'edit_extension_requisition_bu',
                'subject' => 'Edit Resource Extension Requisition',
                'template' => 'requisition-extension-edit-template'
            ],
            [
                'code' => 'delete_extension_requisition',
                'subject' => 'Delete Resource Extension Requisition',
                'template' => 'requisition-extension-delete-template'
            ],
            [
                'code' => 'delete_extension_requisition_bu',
                'subject' => 'Delete Resource Extension Requisition',
                'template' => 'requisition-extension-delete-template'
            ],
            [
                'code' => 'delete_reallocation',
                'subject' => 'Delete Resource Reallocation',
                'template' => 'reallocation-delete-template'
            ],
            [
                'code' => 'delete_reallocation_rm',
                'subject' => 'Delete Resource Reallocation',
                'template' => 'reallocation-delete-template'
            ],
            [
                'code' => 'initiation_request',
                'subject' => 'initiation-request',
                'template' => 'initiation-request-template'
            ],
            [
                'code' => 'initiation_approval',
                'subject' => 'initiation-approval',
                'template' => 'initiation-approval-template'
            ],
            [
                'code' => 'initiation_decline',
                'subject' => 'initiation-decline',
                'template' => 'initiation-decline-template'
            ],
            [
                'code' => 'initiation_request_update',
                'subject' => 'initiation-request-update',
                'template' => 'initiation-request-update-template'
            ],
            [
                'code' => 'edit_direct_allocation',
                'subject' => 'Edit Resource Direct Allocation',
                'template' => 'direct-allocation-edit-template'
            ],
            [
                'code' => 'delete_direct_allocation',
                'subject' => 'Delete Resource Direct Allocation',
                'template' => 'direct-allocation-delete-template'
            ]
        ];

        foreach ($items as $item) {
            MailContent::updateOrCreate(['code' => $item['code']], $item);
        }
    }
}
