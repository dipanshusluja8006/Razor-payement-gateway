<?php

use Illuminate\Database\Seeder;
use App\Models\ProjectType;

class ProjectTypesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $items = [
            [
                'code' => 'complete_development',
                'name' => 'Complete Development'
            ],
            [
                'code' => 'development_phase',
                'name' => 'Development Phase only'
            ],
            [
                'code' => 'testing_phase',
                'name' => 'Testing Phase'
            ],
            [
                'code' => 'design_phase',
                'name' => 'Design Phase'
            ],
            [
                'code' => 'maintenance_support',
                'name' => 'Maintenance and Support'
            ]
        ];

        foreach ($items as $item) {
            ProjectType::updateOrCreate(['code' => $item['code']], $item);
        }
    }
}
