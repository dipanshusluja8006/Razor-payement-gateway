<?php

use Illuminate\Database\Seeder;
use App\Models\RejectReason;

class RejectReasonsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $items = [
            [
                'name' => 'Resource not available',
                'status' => 1
            ],
            [
                'name' => 'Skill set does not match',
                'status' => 1
            ],
            [
                'name' => 'Experience does not match',
                'status' => 1
            ],
            [
                'name' => 'Others',
                'status' => 1
            ]
        ];
        foreach ($items as $item) {
            RejectReason::updateOrCreate(['name' => $item['name']], $item);
        }
    }
}
