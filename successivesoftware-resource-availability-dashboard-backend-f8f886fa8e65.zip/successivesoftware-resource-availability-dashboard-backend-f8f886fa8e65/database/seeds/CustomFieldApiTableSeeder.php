<?php

use Illuminate\Database\Seeder;
use App\Models\CustomFieldApi;

class CustomFieldApisTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $items = [
            [
                'id' => 1,
                'type' => 'Keka',
                'name' => 'Employees'
            ]
        ];

        foreach ($items as $item) {
            CustomFieldApi::updateOrCreate(['id' => $item['id']], $item);
        }
    }
}
