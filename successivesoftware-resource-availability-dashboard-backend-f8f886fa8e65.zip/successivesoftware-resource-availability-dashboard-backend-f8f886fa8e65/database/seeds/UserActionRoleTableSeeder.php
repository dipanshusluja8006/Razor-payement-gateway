<?php

use Illuminate\Database\Seeder;
use Carbon\Carbon;

class UserActionRoleTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $userActionArray = [];
        $rolesArray = [];

        $items = [
            [
                'user_action_code' => 'creation-request',
                'role_code' => 'resource_manager'
            ],
            [
                'user_action_code' => 'resource-requisition',
                'role_code' => 'global_operation'
            ],
            [
                'user_action_code' => 'resource-requisition',
                'role_code' => 'account_manager'
            ],
            [
                'user_action_code' => 'resource-requisition',
                'role_code' => 'project_manager'
            ],
            [
                'user_action_code' => 'resource-allocation',
                'role_code' => 'bu_head'
            ],
            [
                'user_action_code' => 'resource-mapping',
                'role_code' => 'resource_manager'
            ],
            [
                'user_action_code' => 'resource-allocation-manager',
                'role_code' => 'global_operation'
            ],
            [
                'user_action_code' => 'resource-allocation-manager',
                'role_code' => 'account_manager'
            ],
            [
                'user_action_code' => 'resource-allocation-manager',
                'role_code' => 'project_manager'
            ],
            [
                'user_action_code' => 'resource-reallocation',
                'role_code' => 'bu_head'
            ],
            [
                'user_action_code' => 'hold-request',
                'role_code' => 'global_operation'
            ],
            [
                'user_action_code' => 'hold-request',
                'role_code' => 'account_manager'
            ],
            [
                'user_action_code' => 'hold-request',
                'role_code' => 'project_manager'
            ],
            [
                'user_action_code' => 'hold-request-approval',
                'role_code' => 'global_operation'
            ],
            [
                'user_action_code' => 'hold-request-approval',
                'role_code' => 'sales'
            ],
            [
                'user_action_code' => 'resource-modification',
                'role_code' => 'global_operation'
            ],
            [
                'user_action_code' => 'resource-modification',
                'role_code' => 'account_manager'
            ],
            [
                'user_action_code' => 'resource-modification',
                'role_code' => 'project_manager'
            ],
            [
                'user_action_code' => 'resource-deallocation-resource-manager',
                'role_code' => 'resource_manager'
            ],
            [
                'user_action_code' => 'restart',
                'role_code' => 'global_operation'
            ],
            [
                'user_action_code' => 'restart',
                'role_code' => 'account_manager'
            ],
            [
                'user_action_code' => 'restart',
                'role_code' => 'project_manager'
            ],
            [
                'user_action_code' => 'project-closure',
                'role_code' => 'global_operation'
            ],
            [
                'user_action_code' => 'project-closure',
                'role_code' => 'account_manager'
            ],
            [
                'user_action_code' => 'project-closure',
                'role_code' => 'project_manager'
            ],
            [
                'user_action_code' => 'edit-requisition',
                'role_code' => 'global_operation'
            ],
            [
                'user_action_code' => 'edit-requisition',
                'role_code' => 'account_manager'
            ],
            [
                'user_action_code' => 'edit-requisition',
                'role_code' => 'project_manager'
            ],
            [
                'user_action_code' => 'edit-allocation',
                'role_code' => 'bu_head'
            ],

            //new actions for initiation-request
            [
                'user_action_code' => 'initiation-request',
                'role_code' => 'go_team'
            ],
            [
                'user_action_code' => 'initiation-request',
                'role_code' => 'bu_head'
            ],
            [
                'user_action_code' => 'initiation-approval',
                'role_code' => 'global_operation'
            ]
        ];

        $allUserActions = \App\Models\UserAction::get();
        foreach ($allUserActions as $action) {
            $userActionArray[$action['code']] = $action['id'];
        }

        $allRoles = \App\Models\Role::get();
        foreach ($allRoles as $role) {
            $rolesArray[$role['code']] = $role['id'];
        }

        \App\Models\UserActionRole::truncate();
        foreach ($items as $item) {
            $userActionRole = [
                'user_action_id' => $userActionArray[$item['user_action_code']],
                'role_id' => $rolesArray[$item['role_code']],
            ];
            \App\Models\UserActionRole::updateOrCreate($userActionRole, $userActionRole);
        }
    }
}
