<?php

use Illuminate\Database\Seeder;
use App\Models\Status;
class StatusTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $items =  [
            [
                'code' => 'initiation',
                'name' => 'initiation'
            ],
            [
                'code' => 'creation',
                'name' => 'creation'
            ],
            [
                'code' => 'resource_requisition_request',
                'name' => 'resource_requisition_request'
            ],
            [
                'code' => 'resource_allocation_request',
                'name' => 'resource_allocation_request'
            ],
            [
                'code' => 'resource_allocation_response',
                'name' => 'resource_allocation_response'
            ],
            [
                'code' => 'resource_reallocation',
                'name' => 'resource_reallocation'
            ],
            [
                'code' => 'resource_mapping',
                'name' => 'resource_mapping'
            ],
            [
                'code' => 'resource_de_allocation_request',
                'name' => 'resource_de_allocation_request'
            ],
            [
                'code' => 'resource_de_allocation_response_accept',
                'name' => 'resource_de_allocation_response_accept'
            ],
            [
                'code' => 'resource_de_allocation_response_decline',
                'name' => 'resource_de_allocation_response_decline'
            ],
            [
                'code' => 'project_on_hold_request',
                'name' => 'project_on_hold_request'
            ],
            [
                'code' => 'project_on_hold_request_accept',
                'name' => 'project_on_hold_request_accept'
            ],
            [
                'code' => 'project_closure_checklist',
                'name' => 'project_closure_checklist'
            ],
            [
                'code' => 'resource_allocation_response_accept',
                'name' => 'resource_allocation_response_accept'
            ],
            [
                'code' => 'resource_allocation_response_decline',
                'name' => 'resource_allocation_response_decline'
            ],
            [
                'code' => 'resource_de_allocation_mapping',
                'name' => 'resource_de_allocation_mapping'
            ],
            [
            'code' => 'initiation_request',
            'name' => 'initiation_request'
            ]

        ];

        foreach ($items as $item) {
            Status::updateOrCreate(['code' => $item['code']], $item);
        }
    }
}
