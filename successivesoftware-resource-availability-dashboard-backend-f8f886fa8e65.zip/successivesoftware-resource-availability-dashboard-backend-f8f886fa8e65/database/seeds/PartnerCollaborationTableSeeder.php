<?php

use Illuminate\Database\Seeder;
use App\Models\PartnerCollaboration;

class PartnerCollaborationTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $items = [
            [
                'code' => 'microsoft_azure_gold',
                'name' => 'Microsoft Azure Gold'
            ],
            [
                'code' => 'aws',
                'name' => 'AWS'
            ],
            [
                'code' => 'google_cloud',
                'name' => 'Google Cloud'
            ],
            [
                'code' => 'umbraco_gold',
                'name' => 'Umbraco Gold'
            ],
            [
                'code' => 'strapi',
                'name' => 'Strapi'
            ],
            [
                'code' => 'synerise',
                'name' => 'Synerise'
            ],
            [
                'code' => 'mongoDB',
                'name' => 'MongoDB'
            ],
            [
                'code' => 'zend_framework',
                'name' => 'Zend Framework'
            ],
            [
                'code' => 'sitecore',
                'name' => 'StSitecorerapi'
            ],
            [
                'code' => 'open_JS_foundation',
                'name' => 'Open JS Foundation'
            ],
            [
                'code' => 'cogniticx',
                'name' => 'Cogniticx'
            ],
            [
                'code' => 'automation_anywhere',
                'name' => 'Automation Anywhere'
            ],
            [
                'code' => 'cloudinary',
                'name' => 'Cloudinary'
            ],
            [
                'code' => 'Imagekit_io',
                'name' => 'Imagekit.io'
            ],
            [
                'code' => 'jetrails',
                'name' => 'Jetrails'
            ]
        ];

        foreach ($items as $item) {
            PartnerCollaboration::updateOrCreate(['code' => $item['code']], $item);
        }
    }
}
