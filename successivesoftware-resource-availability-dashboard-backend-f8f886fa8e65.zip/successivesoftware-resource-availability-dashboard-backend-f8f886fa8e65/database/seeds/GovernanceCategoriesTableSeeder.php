<?php

use Illuminate\Database\Seeder;
use App\Models\GovernanceCategory;

class GovernanceCategoriesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $items = [
            [
                'code' => 'managed_services',
                'name' => 'Managed Services',
                'description' => 'Engagement where successive have full control of the project. like: Estimation, Management, Engineering & Monitoring, etc.'
            ],
            [
                'code' => 'team_extension',
                'name' => 'Team Extension',
                'description' => 'Support and Maintenance project where task Estimation and Planning drive by the client.'
            ],
            [
                'code' => 'staff_augmentation',
                'name' => 'Staff Augmentation',
                'description' => 'Engagement where successive only provide staff to client and rest is managed by the client.'
            ]
        ];

        foreach ($items as $item) {
            GovernanceCategory::updateOrCreate(['code' => $item['code']], $item);
        }
    }
}
