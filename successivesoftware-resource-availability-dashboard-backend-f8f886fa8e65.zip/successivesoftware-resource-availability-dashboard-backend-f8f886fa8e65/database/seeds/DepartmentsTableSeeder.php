<?php

use Illuminate\Database\Seeder;
use App\Models\Department;
use Illuminate\Support\Facades\Schema;

class DepartmentsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $items = [
            [
                'id' => 2,
                'code' => 'quality_analysis',
                'name' => 'Quality Analysis'
            ],
            [
                'id' => 3,
                'code' => 'php_js',
                'name' => 'Php JS'
            ],
            [
                'id' => 4,
                'code' => 'human_resource',
                'name' => 'Human Resource'
            ],
            [
                'id' => 5,
                'code' => 'node',
                'name' => 'Node'
            ],
            [
                'id' => 6,
                'code' => 'client',
                'name' => 'Client'
            ],
            [
                'id' => 8,
                'code' => 'global_operation',
                'name' => 'Global Operations'
            ],
            [
                'id' => 9,
                'code' => 'sales',
                'name' => 'Sales'
            ],
            [
                'id' => 10,
                'code' => 'devops',
                'name' => 'DevOps'
            ],
            [
                'id' => 11,
                'code' => 'security',
                'name' => 'Security'
            ],
            [
                'id' => 12,
                'code' => 'requirement_engineering',
                'name' => 'Requirement Engineering'
            ],
            [
                'id' => 13,
                'code' => 'net',
                'name' => '.Net'
            ],
            [
                'id' => 14,
                'code' => 'mobility',
                'name' => 'Mobility'
            ],
            [
                'id' => 15,
                'code' => 'frontend',
                'name' => 'Frontend'
            ],
            [
                'id' => 16,
                'code' => 'product_development',
                'name' => 'Product Development'
            ],
            [
                'id' => 17,
                'code' => 'ui_ux',
                'name' => 'UI/UX'
            ],
            [
                'id' => 18,
                'code' => 'erp_crm',
                'name' => 'ERP/CRM'
            ],
            [
                'id' => 19,
                'code' => 'marketing_branding',
                'name' => 'Marketing/Branding'
            ],
            [
                'id' => 20,
                'code' => 'it_infra',
                'name' => 'IT Infra'
            ],
            [
                'id' => 21,
                'code' => 'accounts_admin',
                'name' => 'Accounts & Admin'
            ],
            [
                'id' => 22,
                'code' => 'research_development',
                'name' => 'Research & development'
            ]
        ];

        Schema::disableForeignKeyConstraints();

        foreach ($items as $item) {
            Department::updateOrCreate(['code' => $item['code']], $item);
        }
    }
}
