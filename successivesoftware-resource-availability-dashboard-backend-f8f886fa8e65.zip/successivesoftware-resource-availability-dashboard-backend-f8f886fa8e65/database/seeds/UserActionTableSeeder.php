<?php

use Illuminate\Database\Seeder;
use App\Models\UserAction;

class UserActionTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $items = [
            [
                'code' => 'creation-request',
                'name' => 'Create Project'
            ],
            [
                'code' => 'resource-requisition',
                'name' => 'Resource Requisition'
            ],
            [
                'code' => 'resource-allocation',
                'name' => 'Resource Allocation'
            ],
            [
                'code' => 'resource-mapping',
                'name' => 'Resource Mapping'
            ],
            [
                'code' => 'resource-allocation-manager',
                'name' => 'Resource Allocation Request Accept/Decline'
            ],
            [
                'code' => 'resource-reallocation',
                'name' => 'Resource Re-Allocation'
            ],
            [
                'code' => 'hold-request',
                'name' => 'Project On Hold Request'
            ],
            [
                'code' => 'hold-request-approval',
                'name' => 'Project On Hold Request Accept/Decline'
            ],
            [
                'code' => 'resource-modification',
                'name' => 'Resource Modification',
            ],
            [
                'code' => 'resource-deallocation-resource-manager',
                'name' => 'Resource Unmapping'
            ],
            [
                'code' => 'restart',
                'name' => 'Restart Project'
            ],
            [
                'code' => 'project-closure',
                'name' => 'Close Project'
            ],
            [
                'code' => 'edit-requisition',
                'name' => 'Edit Requisition'
            ],
            [
                'code' => 'edit-allocation',
                'name' => 'Edit Allocation'
            ],
            //new actions for initiation-request
            [
                'code' => 'initiation-request',
                'name' => 'Initiation-Request'
            ],
            [
                'code' => 'initiation-approval',
                'name' => 'Initiation-Approval'
            ]

        ];

        foreach ($items as $item) {
            UserAction::updateOrCreate(['code' => $item['code']], $item);
        }
    }
}
