<?php

use Illuminate\Database\Seeder;
use App\Models\BillingMedium;
class BillingMediumSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */

    public function run()
    {
        $items = [
            [
                'redmine_billing_medium_id' => 8,
                'code' => 'redmine',
                'name' => 'Redmine'
            ],
            [
                'redmine_billing_medium_id' => 9,
                'code' => 'jira',
                'name' => 'Jira'
            ],
            [
                'redmine_billing_medium_id' => 10,
                'code' => 'tracker',
                'name' => 'Tracker'
            ]
        ];

        foreach ($items as $item) {
            BillingMedium::updateOrCreate(['code' => $item['code']], $item);
        }
    }

}
