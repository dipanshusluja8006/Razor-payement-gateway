<?php

use Illuminate\Database\Seeder;
use App\Models\Role;

class RolesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $items = [
            [
                'code' => 'admin',
                'role' => 'Admin'
            ],
            [
                'code' => 'global_operation',
                'role' => 'GO Head'
            ],
            [
                'code' => 'sales',
                'role' => 'Sales'
            ],
            [
                'code' => 'resource_manager',
                'role' => 'Resource Manager'
            ],
            [
                'code' => 'account_manager',
                'role' => 'Account Manager'
            ],
            [
                'code' => 'project_manager',
                'role' => 'Project Manager'
            ],
            [
                'code' => 'bu_head',
                'role' => 'BU Head'
            ],
            //new role for initiation-request
            [
                'code' => 'go_team',
                'role' => 'GO Team'
            ]
        ];

        foreach ($items as $item) {
            Role::updateOrCreate(['code' => $item['code']], $item);
        }
    }
}
