<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
    //$this->call('BillingTypesTableSeeder');
    //$this->call('TechnologiesTableSeeder');
    //$this->call('DepartmentsTableSeeder');
    //$this->call('StatusTableSeeder');
    //$this->call('DesignationsTableSeeder');
    //$this->call('MailContentsTableSeeder');
    //$this->call('RcaReporterUsersTableSeeder');
    //$this->call('UserActionTableSeeder');
    //$this->call('RolesTableSeeder');
    //$this->call('UserActionRoleTableSeeder');
    //$this->call('StatusActionListTableSeeder');
    //$this->call('GovernanceCategoriesTableSeeder');
    //$this->call('ProjectTypesTableSeeder');
    //$this->call('ProjectActionTypesTableSeeder');
    //$this->call('LifeCycleTableSeeder');
    //$this->call('CustomFieldApisTableSeeder');
    //$this->call('BillingMediumSeeder');
    //$this->call('RejectReasonsTableSeeder');
    $this->call('PartnerCollaborationTableSeeder');
    }
}
