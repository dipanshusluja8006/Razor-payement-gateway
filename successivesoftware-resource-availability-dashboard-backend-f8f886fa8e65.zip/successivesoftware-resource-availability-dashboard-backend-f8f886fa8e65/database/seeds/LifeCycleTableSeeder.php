<?php

use Illuminate\Database\Seeder;
use App\Models\LifeCycle;

class LifeCycleTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $items = [
            [
                'code' => 'iterative_waterfall',
                'name' => 'Iterative waterfall'
            ],
            [
                'code' => 'hybrid',
                'name' => 'Hybrid'
            ],
            [
                'code' => 'waterfall',
                'name' => 'Waterfall'
            ],
            [
                'code' => 'kanban',
                'name' => 'Kanban'
            ],
            [
                'code' => 'scrum',
                'name' => 'Scrum'
            ],
            [
                'code' => 'maintenance',
                'name' => 'Maintenance'
            ],
            [
                'code' => 'support',
                'name' => 'Support'
            ]
        ];

        foreach ($items as $item) {
            LifeCycle::updateOrCreate(['code' => $item['code']], $item);
        }
    }
}
