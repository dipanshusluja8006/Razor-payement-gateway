<?php

use Illuminate\Database\Seeder;
use App\Models\UserRole;
use App\EmailAddresse;
use App\Models\Department;
use App\Models\Role;

class UserRolesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $items  = [

            //PHP
            [
                'email' => 'jitendra.singh@successive.tech',
                'role_code' => 'bu_head',
                'dept_code' => 'php_js',
            ],
            [
                'email' => 'bhanu.singh@successive.tech',
                'role_code' => 'bu_head',
                'dept_code' => 'php_js',
            ],

            //Node
            [
                'email' => 'sapna.upreti@successive.tech',
                'role_code' => 'bu_head',
                'dept_code' => 'node',
            ],
            [
                'email' => 'vinay.chaudhary@successive.tech',
                'role_code' => 'bu_head',
                'dept_code' => 'node',
            ],

            //DevOps
            [
                'email' => 'anil.chauhan@successive.tech',
                'role_code' => 'bu_head',
                'dept_code' => 'devops',
            ],
            [
                'email' => 'sapna.upreti@successive.tech',
                'role_code' => 'bu_head',
                'dept_code' => 'devops',
            ],

            //Security
            [
                'email' => 'anil.chauhan@successive.tech',
                'role_code' => 'bu_head',
                'dept_code' => 'security',
            ],
            [
                'email' => 'sapna.upreti@successive.tech',
                'role_code' => 'bu_head',
                'dept_code' => 'security',
            ],

            //Quality Analyst
            [
                'email' => 'prateek.gera@successive.tech',
                'role_code' => 'bu_head',
                'dept_code' => 'quality_analysis',
            ],
            [
                'email' => 'manoj.mehra@successive.tech',
                'role_code' => 'bu_head',
                'dept_code' => 'quality_analysis',
            ],

            //Requirement Engineering
            [
                'email' => 'prateek.gera@successive.tech',
                'role_code' => 'bu_head',
                'dept_code' => 'requirement_engineering',
            ],

            //Dot.Net
            [
                'email' => 'yogesh.verma@successive.tech',
                'role_code' => 'bu_head',
                'dept_code' => 'net',
            ],
            [
                'email' => 'sidd0001@gmail.com',
                'role_code' => 'bu_head',
                'dept_code' => 'net',
            ],

            //Mobility
            [
                'email' => 'sidd0001@gmail.com',
                'role_code' => 'bu_head',
                'dept_code' => 'mobility',
            ],
            [
                'email' => 'kartik.parashar@successive.tech',
                'role_code' => 'bu_head',
                'dept_code' => 'mobility',
            ],
            [
                'email' => 'skand.swami@successive.tech',
                'role_code' => 'bu_head',
                'dept_code' => 'mobility',
            ],

            //Frontend
            [
                'email' => 'sunil.sahoo@successive.tech',
                'role_code' => 'bu_head',
                'dept_code' => 'frontend',
            ],
            [
                'email' => 'sidd0001@gmail.com',
                'role_code' => 'bu_head',
                'dept_code' => 'frontend',
            ],

            //Product Development
            [
                'email' => 'mayank.awasthi@successive.tech',
                'role_code' => 'bu_head',
                'dept_code' => 'product_development',
            ],
            [
                'email' => 'sidd0001@gmail.com',
                'role_code' => 'bu_head',
                'dept_code' => 'product_development',
            ],

            //UI/UX
            [
                'email' => 'pranaw.kumar@successive.tech',
                'role_code' => 'bu_head',
                'dept_code' => 'ui_ux',
            ],
            [
                'email' => 'sidd0001@gmail.com',
                'role_code' => 'bu_head',
                'dept_code' => 'ui_ux',
            ],

            //ERP/CRM
            [
                'email' => 'pashupatinath.tiwari@successive.tech',
                'role_code' => 'bu_head',
                'dept_code' => 'erp_crm',
            ],
            [
                'email' => 'himanshu.singh@successive.tech',
                'role_code' => 'bu_head',
                'dept_code' => 'erp_crm',
            ],

            //Global Operations BU Head
            [
                'email' => 'pashu.tiwari@successive.tech',
                'role_code' => 'bu_head',
                'dept_code' => 'global_operation',
            ],
            [
                'email' => 'prateek.gera@successive.tech',
                'role_code' => 'bu_head',
                'dept_code' => 'global_operation',
            ],

            //Global Operations
            [
                'email' => 'pashu.tiwari@successive.tech',
                'role_code' => 'global_operation',
                'dept_code' => null,
            ],
            [
                'email' => 'prateek.gera@successive.tech',
                'role_code' => 'global_operation',
                'dept_code' => null,
            ],

            //Sales
            [
                'email' => 'awanish.singh@successive.tech',
                'role_code' => 'sales',
                'dept_code' => null,
            ],
            [
                'email' => 'jai.shukla@successive.tech',
                'role_code' => 'sales',
                'dept_code' => null,
            ],
            [
                'email' => 'sidd0001@gmail.com',
                'role_code' => 'sales',
                'dept_code' => null,
            ],
            [
                'email' => 'rituraj@successive.tech',
                'role_code' => 'sales',
                'dept_code' => null,
            ],

            //Marketing/Branding
            [
                'email' => 'yash.gupta@successive.tech',
                'role_code' => 'bu_head',
                'dept_code' => 'marketing_branding',
            ],

            //HR
            [
                'email' => 'manisha.rawat@successive.tech',
                'role_code' => 'bu_head',
                'dept_code' => 'human_resource',
            ],
            [
                'email' => 'sidd0001@gmail.com',
                'role_code' => 'bu_head',
                'dept_code' => 'human_resource',
            ],

            //IT-Infra
            [
                'email' => 'sidd0001@gmail.com',
                'role_code' => 'bu_head',
                'dept_code' => 'it_infra',
            ],
            [
                'email' => 'manish.mall@successive.tech',
                'role_code' => 'bu_head',
                'dept_code' => 'it_infra',
            ],

            //Accounts & Admin
            //Admin
            [
                'email' => 'aakash.kumar@successive.tech',
                'role_code' => 'admin',
                'dept_code' => null,
            ],
            [
                'email' => 'harsh.goel@successive.tech',
                'role_code' => 'admin',
                'dept_code' => null,
            ],

            //Cross Cutting (Research Development)
            [
                'email' => 'anil.chauhan@successive.tech',
                'role_code' => 'bu_head',
                'dept_code' => 'research_development',
            ],
            [
                'email' => 'vinay.chaudhary@successive.tech',
                'role_code' => 'bu_head',
                'dept_code' => 'research_development',
            ],

            //Resource Manager
            [
                'email' => 'ambuj.hardeniya@successive.tech',
                'role_code' => 'resource_manager',
                'dept_code' => null,
            ],
            [
                'email' => 'manish.mall@successive.tech',
                'role_code' => 'resource_manager',
                'dept_code' => null,
            ],
            [
                'email' => 'samadhan.misal@successive.tech',
                'role_code' => 'resource_manager',
                'dept_code' => null,
            ],
        ];

        foreach ($items as $item) {

            $userId = EmailAddresse::where('address', $item['email'])->pluck('user_id')->first();
            $roleId = Role::where('code', $item['role_code'])->pluck('id')->first();
            $deptId = Department::where('code', $item['dept_code'])->pluck('id')->first();

            $userRole = [
                'user_id' => $userId,
                'role_id' => $roleId,
                'dept_id' => $deptId,
            ];
            UserRole::updateOrCreate($userRole, $userRole);
        }
    }
}
