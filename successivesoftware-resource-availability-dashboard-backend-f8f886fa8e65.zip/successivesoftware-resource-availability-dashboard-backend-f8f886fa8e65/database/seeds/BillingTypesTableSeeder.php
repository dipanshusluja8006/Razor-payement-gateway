<?php

use Illuminate\Database\Seeder;
use App\Models\BillingType;
class BillingTypesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */

    public function run()
    {
        $items = [
            [
                'code' => 'fixed_cost',
                'name' => 'Fixed Cost'
            ],
            [
                'code' => 'hourly',
                'name' => 'T&M - Hourly'
            ],
            [
                'code' => 'retainer',
                'name' => 'Retainer'
            ],
            [
                'code' => 'internal',
                'name' => 'Internal'
            ],
            [
                'code' => 'poc',
                'name' => 'POC'
            ]
        ];

        foreach ($items as $item) {
            BillingType::updateOrCreate(['code' => $item['code']], $item);
        }
    }

}
