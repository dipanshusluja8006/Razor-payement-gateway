<?php

use Illuminate\Database\Seeder;
use App\Models\ProjectActionType;

class ProjectActionTypesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $items = [
            [
                'id' => '1',
                'code' => 'initiation_project',
                'name' => 'Project Initiation',
                'priority' => 1
            ],
            [
                'id' => '31',
                'code' => 'initiation_request',
                'name' => 'Project Initiation Request',
                'priority' => 2
                
            ],
            [
                'id' => '32',
                'code' => 'initiation_approval',
                'name' => 'Project Initiation Accept',
                'priority' => 3
            ],
            [
                'id' => '33',
                'code' => 'initiation_request_edit',
                'name' => 'Project Initiation Request Edit',
                'priority' => 4
            ],
            [
                'id' => '34',
                'code' => 'initiation_decline',
                'name' => 'Project Initiation Decline',
                'priority' => 5
            ],
            [
                'id' => '2',
                'code' => 'update_project',
                'name' => 'Project Updation',
                'priority' => 6
            ],
            [
                'id' => '3',
                'code' => 'creation_project',
                'name' => 'Project Creation',
                'priority' => 7
            ],
            [
                'id' => '4',
                'code' => 'creation_requisition',
                'name' => 'Resource Requisition',
                'priority' => 8
            ],
            [
                'id' => '5',
                'code' => 'edit_requisition',
                'name' => 'Edit Resource Requisition',
                'priority' => 9
            ],
            [
                'id' => '6',
                'code' => 'delete_requisition',
                'name' => 'Delete Resource Requisition',
                'priority' => 10
            ],
            [
                'id' => '7',
                'code' => 'edit_extension_requisition',
                'name' => 'Edit Extension Requisition',
                'priority' => 11
            ],
            [
                'id' => '8',
                'code' => 'delete_extension_requisition',
                'name' => 'Delete Extension Requisition',
                'priority' => 12
            ],
            [
                'id' => '26',
                'code' => 'resource_extension',
                'name' => 'Resource Extension',
                'priority' => 13
            ],
            [
                'id' => '29',
                'code' => 'direct_resource_allocation',
                'name' => 'Direct Resource Allocation',
                'priority' => 14
            ],
            [
                'id' => '9',
                'code' => 'creation_allocation',
                'name' => 'Resource Allocation',
                'priority' => 15
            ],
            [
                'id' => '10',
                'code' => 'edit_allocation',
                'name' => 'Edit Allocation',
                'priority' => 16
            ],
            [
                'id' => '11',
                'code' => 'delete_allocation',
                'name' => 'Delete Allocation',
                'priority' => 17
            ],
            [
                'id' => '12',
                'code' => 'edit_direct_allocation',
                'name' => 'Edit Direct Allocation',
                'active'=> 1,
                'priority' => 18
            ],
            [
                'id' => '13',
                'code' => 'delete_direct_allocation',
                'name' => 'Delete Direct Allocation',
                'active'=> 1,
                'priority' => 19
            ],
            [
                'id' => '16',
                'code' => 'resource_reallocation',
                'name' => 'Resource Re-Allocation',
                'priority' => 20
            ],
            [
                'id' => '14',
                'code' => 'resource_allocation_response_accept',
                'name' => 'Resource Allocation Accept',
                'priority' => 21
            ],
            [
                'id' => '15',
                'code' => 'resource_allocation_response_decline',
                'name' => 'Resource Allocation Decline',
                'priority' => 22
            ],
            [
                'id' => '30',
                'code' => 'delete_reallocation',
                'name' => 'Delete ReAllocation',
                'priority' => 23
            ],
            [
                'id' => '17',
                'code' => 'resource_mapping',
                'name' => 'Resource Mapping',
                'priority' => 24
            ],
            [
                'id' => '18',
                'code' => 'resource_deallocation',
                'name' => 'Resource DeAllocation',
                'priority' => 25
            ],
            [
                'id' => '19',
                'code' => 'resource_unmapping',
                'name' => 'Resource Unmapping',
                'priority' => 26
            ],
            [
                'id' => '20',
                'code' => 'hold_request',
                'name' => 'Project On Hold Request',
                'priority' => 27
            ],
            [
                'id' => '21',
                'code' => 'project_on_hold_request_accept',
                'name' => 'Project On Hold Accept',
                'priority' => 28
            ],
            [
                'id' => '22',
                'code' => 'project_on_hold_rejection',
                'name' => 'Project On Hold Rejection',
                'priority' => 29
            ],
            [
                'id' => '23',
                'code' => 'project_close',
                'name' => 'Close Project',
                'priority' => 30
            ],
            [
                'id' => '28',
                'code' => 'update_project_closure_checklist',
                'name' => 'Update ProjectClosure Checklist',
                'active'=> 0,
                'priority' => 31
            ],
            [
                'id' => '24',
                'code' => 'project_restart',
                'name' => 'Restart Project',
                'priority' => 32
            ],
            [
                'id' => '25',
                'code' => 'resource_modification',
                'name' => 'Resource Modification',
                'active' => '0',
                'priority' => 33
            ],
            [
                'id' => '27',
                'code' => 'creation_rca',
                'name' => 'RCA Creation',
                'active' => '0',
                'priority' => 34
            ],
            [
                'id' => '37',
                'code' => 'reject_requisition',
                'name' => 'Reject Requisition',
                'active' => '1',
                'priority' => 37
            ]
        ];
        foreach ($items as $item) {
            ProjectActionType::updateOrCreate(['code' => $item['code']], $item);
        }
    }
}
