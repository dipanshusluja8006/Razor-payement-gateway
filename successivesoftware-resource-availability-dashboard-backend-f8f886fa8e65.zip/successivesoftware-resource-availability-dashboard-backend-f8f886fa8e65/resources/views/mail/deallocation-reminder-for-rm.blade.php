<!DOCTYPE html>
<html>

<head>
    <title></title>
</head>
<body>
                <p >Hello,<br/>Please find the list of resources those booking has ended.</p>
                <div>

                <h4>Resource Booking Ended</h4>
                <table width="100%" cellspacing="0" cellpadding="4" border="1px solid grey">
                    <tr align="left" bgcolor="#41337C">
                        <th><font color="#fff">Project Name</font></th>
                        <th><font color="#fff">Resource Name</font></th>
                        <th><font color="#fff">End Date</font></th>
                    </tr>
                 @foreach($maildata['data'] as $project)
                    @foreach($project as $resource)
                        @if ($loop->first)
                            <tr>
                                <td rowspan={{count($project)}}><strong class="department">{{$resource['projectName']}}</strong></td>
                                <td class="name">{{$resource['resourceName']}}</td>
                                <td>{{$resource['deallocatedDate']}}</td>
                            </tr>
                        @else
                            <tr>
                                <td class="name">{{$resource['resourceName']}}</td>
                                <td>{{$resource['deallocatedDate']}}</td>
                            </tr>
                        @endif
                    @endforeach
                  @endforeach
                </table>
            <br /><br />
</div>
<br><br>
<p><strong>NOTE:</strong> This is a system-generated email.</p>
<br>
<p>Thanks and Regards,</p>
<p>Successive Technologies</p>
</body>

</html>
