<!DOCTYPE html>
<html>
<head>
    <title>Mail</title>
</head>
<body>
<div>
    <p><strong>Hello,</strong></p>
    <p>  This is a invoices reports with Generated/Pending status.</p>
    <br />
    <h3 > <font color="#FF0000"> Invoices Status Report</font></h3>
    <div>
        <table width="100%" cellspacing="0" cellpadding="4" border="1px solid grey">
            <tr align="left" bgcolor="#41337C">
                <th><font color="#fff">Project Name</font></th>
                <th><font color="#fff">Billing Type</font></th>
                <th><font color="#fff">Account Manager</font></th>
                <th><font color="#fff">Project Manager</font></th>
                <th><font color="#fff">Last Invoice Generated (Date)</font></th>
                <th><font color="#fff">Invoice Status</font></th>
            </tr>
            @foreach($maildata['data'] as $key => $val)
                    <tr>
                        <td><strong class="department">{{  $val['ProjectName']  }}</strong></td>
                        <td><strong class="department">{{  $val['BillingType']  }}</strong></td>
                        <td><strong class="department">{{  $val['RedmineAM']  }}</strong></td>
                        <td><strong class="department">{{  $val['RedminePM']  }}</strong></td>
                        <td><strong class="department">{{  $val['LastInvoiceDate']  }}</strong></td>
                        <td><strong class="department">{{  $val['InvoiceStatus']  }}</strong></td>
                    </tr>
            @endforeach
        </table>
        <br /><br />

    </div>
    <br><br>
    <p><strong>NOTE:</strong> This is a system-generated email.</p>
    <br>
    <p>Thanks and Regards,</p>
    <p>Successive Technologies</p>
</div>
</body>
</html>
