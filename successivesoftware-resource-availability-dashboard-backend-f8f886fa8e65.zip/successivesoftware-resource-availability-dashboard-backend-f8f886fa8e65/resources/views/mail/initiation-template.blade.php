<!DOCTYPE html>
<html>
<head>
    <title>{{ $maildata->subject}} Mail</title>
</head>
<body>
<div>
    <p><strong>Hello,</strong></p>
    <p>The Global Operations Head/Sales has initiated the project <strong>{!! $maildata->projectArray->project_name !!}</strong>.</p>
    <p>This initiation is auto-approved and the project has also been auto-created on Redmine.</p>
    <p><strong>NOTE:</strong> This is a system-generated email.</p>
    <br>
    <p>Thanks and Regards,</p>
    <p>Successive Technologies</p>
</div>
</body>
</html>