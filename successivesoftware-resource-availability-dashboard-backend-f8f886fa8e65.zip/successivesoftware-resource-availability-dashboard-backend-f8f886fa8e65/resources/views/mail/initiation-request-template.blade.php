<!DOCTYPE html>
<html>
<head>
    <title>{{ $maildata->subject}} Mail</title>
</head>
<body>
<div>
    <p><strong>Hello,</strong></p>
    <p>A request for the Project initiation has been raised by Global Operations Team/Bu Head(s) {!! $maildata->currentUserName !!} for the <strong>{!! $maildata->projectArray->project_name !!}</strong> project.</p>
    <p>The Global Operations Head must take action on the request to process it further.</p>
    <p><strong>NOTE:</strong> This is a system-generated email.</p>
    <br>
    <p>Thanks and Regards,</p>
    <p>Successive Technologies</p>
</div>
</body>
</html>
