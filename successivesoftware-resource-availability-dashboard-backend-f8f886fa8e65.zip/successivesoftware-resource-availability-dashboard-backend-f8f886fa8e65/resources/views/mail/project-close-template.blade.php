<!DOCTYPE html>
<html>
<head>
    <title>{{ $maildata->subject}} Mail</title>
</head>
<body>
<div>
    <p><strong>Hello,</strong></p>
    <p>The Account Manager/Project Manager has generated a request to close the <strong>{!! $maildata->projectArray->project_name !!}</strong> project.</p>
    @if(isset($maildata->submitArray['unMappingData']))
        <p>Please unmap the following resources from the project on Redmine.</p>
        <br>
        <table width="100%" cellspacing="0" cellpadding="4" border="1px solid grey">
            <tr align="left" bgcolor="#41337C">
                <th><font color="#fff">Employee Code</font></th>
                <th><font color="#fff">Resource Name</font></th>
                <th><font color="#fff">Email Address</font></th>
                <th><font color="#fff">Department</font></th>
                <th><font color="#fff">Technology</font></th>
                <th><font color="#fff">Role</font></th>
                <th><font color="#fff">Billing Type</font></th>
                <th><font color="#fff">Daily Efforts</font></th>
                <th><font color="#fff">Deallocated for (hrs)</font></th>
                <th><font color="#fff">Deallocation from</font></th>
            </tr>
            @foreach($maildata->submitArray['unMappingData'] as $key=>$value)
                <tr>
                    <td>{{$value['employee_code']}}</td>
                    <td>{{$value['name']}}</td>
                    <td>{{$value['employee_email']}}</td>
                    <td>{{$value['department']}}</td>
                    <td>{{$value['technology']}}</td>
                    <td>{{$value['role']}}</td>
                    <td>{{$value['billing_type']}}</td>
                    <td>{{$value['dailyEfforts']}}</td>
                    <td>{{$value['deAllocationForHours']}}</td>
                    <td>{{$value['deAllocationFrom']}}</td>
                </tr>
            @endforeach
        </table>
    @else
        <p>There is no pending resources for deallocation</p>
    @endif
    <p><a href="{{ $maildata->department['APP_FRONTEND_URL'].'/project/'.$maildata->projectArray->uuid.'/project-closure-mapping'}}">Please click here to view the project details</a></p>
    @if($maildata->code != 'project_close')
    <p>Please do the needful.</p>
    @endif
    <p><strong>NOTE:</strong> This is a system-generated email.</p>
    <br>
    <p>Thanks and Regards,</p>
    <p>Successive Technologies</p>
</div>
</body>
</html>
