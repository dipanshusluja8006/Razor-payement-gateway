<!DOCTYPE html>
<html>
<head>
    <title>{{ $maildata->subject}} Mail</title>
</head>
<body>
<div>
    <p><strong>Hello,</strong></p>
    <p>The Account Manager/Project Manager has updated a request for resource requisition for the <strong>{!! $maildata->projectArray->project_name !!}</strong> project.</p>
    <table width="100%" cellspacing="0" cellpadding="4" border="1px solid grey">
    <tr align="left" bgcolor="#41337C">
    <th><font color="#fff">No of Resource</font></th>
    <th><font color="#fff">Role</font></th>
    <th><font color="#fff">Technology</font></th>
    <th><font color="#fff">Daily Efforts</font></th>
    <th><font color="#fff">Experience</font></th>
    <th><font color="#fff">Billing Type</font></th>
    <th><font color="#fff">Start Date</font></th>
    <th><font color="#fff">End Date</font></th>
    </tr>
        @foreach($maildata->submitArray as $key=>$value)
        <tr>
        <td>{{$value['no_of_resource']}}</td>
        <td>{{$value['Designation']}}</td>
        <td>{{$value['Tech']}}</td>
        <td>{{$value['efforts']}}</td>
        <td>{{$value['experience']}}</td>
        <td>{{$value['billing_type']}}</td>
        <td>{{Carbon\Carbon::parse($value['start_date'])->format('d/m/Y')}}</td>
        <td>{{Carbon\Carbon::parse($value['end_date'])->format('d/m/Y')}}</td>
        </tr>
        @endforeach
    </table>
    <p>The Business Unit Heads must take action on resource requests by allocating resources</p>
    <p><strong>NOTE:</strong> This is a system-generated email.</p>
    <br>
    <p>Thanks and Regards,</p>
    <p>Successive Technologies</p>
</div>
</body>
</html>
