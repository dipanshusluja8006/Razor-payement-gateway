<!DOCTYPE html>
<html>

<head>
    <title>{{ $maildata->subject}} Mail</title>
</head>

<body>
    <div>
        <p><strong>Hello,</strong></p>
        <!-- <p>The Account Manager/Project Manager has generated a request for resource requisition for the <strong>{!! $maildata->projectArray->project_name !!}</strong> project.</p> -->
        <p>The BU Head has rejected the requisition request having the following details:</p>
        <table width="100%" cellspacing="0" cellpadding="4" border="1px solid grey">
            <tr align="left" bgcolor="#41337C">
                <th>
                    <font color="#fff">SNo</font>
                </th>
                <th>
                    <font color="#fff">No of Resource</font>
                </th>
                <th>
                    <font color="#fff">Department</font>
                </th>
                <th>
                    <font color="#fff">Daily Efforts</font>
                </th>
                <th>
                    <font color="#fff">Experience</font>
                </th>
                <th>
                    <font color="#fff">Billing Type</font>
                </th>
                <th>
                    <font color="#fff">Start Date</font>
                </th>
                <th>
                    <font color="#fff">End date</font>
                </th>
            </tr>
            @foreach($maildata->submitArray as $key=>$value)
            <tr>
                <td><strong>{{$key+1}}</strong></td>
                <td>{{$value['no_of_resource']}}</td>
                <td>{{$value['department']}}</td>
                <td>{{$value['efforts']}}</td>
                <td>{{$value['experience']}}</td>
                <td>{{$value['billing_type']}}</td>
                <td>{{Carbon\Carbon::parse($value['start_date'])->format('d/m/Y')}}</td>
                <td>{{Carbon\Carbon::parse($value['end_date'])->format('d/m/Y')}}</td>
            </tr>
            @endforeach
        </table>
        <p>The reason offered by BU Head for rejecting this request is <font color="#FF0000">{{ $maildata->submitArray[0]['reason'] == 'Others' ? $maildata->submitArray[0]['other_reason'] : $maildata->submitArray[0]['reason'] }}</font><br />
            Also, according to the BU Head, the tentative date by which the resource would be available is <font color="#00FF00">{{ $maildata->submitArray[0]['tentative_date'] }}</font></p>
        <p><strong>NOTE:</strong> This is a system-generated email.</p>
        <br>
        <p>Thanks and Regards,</p>
        <p>Successive Technologies</p>
    </div>
</body>

</html>