<!DOCTYPE html>
<html>

<head>
    <title></title>
</head>

<body>
<p class="heading">Hello,<br/>Please find the list of resources those booking has ended or ending soon.</p>
<div>

            @foreach($maildata['data'] as $key => $type)
                @if($key == 'endingSoon')

                <h4 class="header">Resource Booking Ending Soon!</h4>
            <table width="100%" cellspacing="0" cellpadding="4" border="1px solid grey">
                @endif
                @if($key == 'ended')
                <h4 >Resource Booking Ended</h4>
                @endif
                <table width="100%" cellspacing="0" cellpadding="4" border="1px solid grey">
                    <tr align="left" bgcolor="#41337C">
                        <th><font color="#fff">Project Name</font></th>
                        <th><font color="#fff">Resource Name</font></th>
                        <th><font color="#fff">End Date</font></th>
                        </tr>


                         @foreach($type as $resource)
                            @if ($loop->first)
                            <tr>
                                    <td rowspan={{count($type)}}><strong class="department">{{$resource['projectName']}}</strong></td>
                                    <td class="name">{{$resource['resourceName']}}</td>
                                    <td>{{$resource['deallocatedDate']}}</td>
                                </tr>
                            @else
                            <tr>
                                    <td class="name">{{$resource['resourceName']}}</td>
                                    <td>{{$resource['deallocatedDate']}}</td>
                                </tr>
                            @endif
                          @endforeach
                  </table>
            @endforeach
        </table>
        <br /><br />



</div>
<br><br>
<p><strong>NOTE:</strong> This is a system-generated email.</p>
<br>
<p>Thanks and Regards,</p>
<p>Successive Technologies</p>
</body>

</html>
