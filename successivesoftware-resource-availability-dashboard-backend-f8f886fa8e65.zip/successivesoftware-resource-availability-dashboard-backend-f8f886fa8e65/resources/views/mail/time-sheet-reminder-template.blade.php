<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
<div>
    <p><strong>Hello,</strong></p>
    <p>Please complete your time logs on Redmine for the week</p>
    <p><strong>NOTE:</strong> This is a system-generated email.</p>
    <br>
    <p>Thanks and Regards,</p>
    <p>Successive Technologies</p>
</div>
</body>
</html>
