<!DOCTYPE html>
<html>
<head>
    <title>{{ $maildata->subject}} Mail</title>
</head>
<body>
<div>
    <p><strong>Hello,</strong></p>
    <p>The Resource Manager has created the <strong>{!! $maildata->projectArray->project_name !!}</strong> project on Redmine.</p>
    <p><a href="{{ $maildata->submitArray['APP_FRONTEND_URL'].'/project/'.$maildata->projectArray->uuid.'/view'}}">Please click here to view the project details</a></p>
    <p><strong>NOTE:</strong> This is a system-generated email.</p>
    <br>
    <p>Thanks and Regards,</p>
    <p>Successive Technologies</p>
</div>
</body>
</html>