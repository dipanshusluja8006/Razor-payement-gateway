<!DOCTYPE html>
<html>
<head>
    <title>{{ $maildata->subject}} Mail</title>
</head>
<body>
<div>
    <p><strong>Hello,</strong></p>
    @if($maildata->code == 'on_hold_approved')
    <p>The Global Operations has approved the request to set <strong>{!! $maildata->projectArray->project_name !!}</strong> project On-Hold.</p>
    @else
    <p>The Global Operations has rejected the request to set <strong>{!! $maildata->projectArray->project_name !!}</strong> project On-Hold.</p>
    @endif
    <br>
    @if($maildata->code == 'on_hold_request')
    <p>Please proceed with Project Onhold request</p>
    @endif
    <p><strong>NOTE:</strong> This is a system-generated email.</p>
    <br>
    <p>Thanks and Regards,</p>
    <p>Successive Technologies</p>
</div>
</body>
</html>