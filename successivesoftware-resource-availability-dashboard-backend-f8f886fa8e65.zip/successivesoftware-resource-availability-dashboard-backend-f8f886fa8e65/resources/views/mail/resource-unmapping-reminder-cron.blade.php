
<!DOCTYPE html>
<html>
<head>
    <title>{{ $maildata['subject']}} Mail</title>
</head>
<body>
<div>
    <p><strong>Hello,</strong></p>
    <p>Please perform the pending resource unmapping action as the projects is closed/onhold.
        Following are the details</p>
        <br>
        <table width="100%" cellspacing="0" cellpadding="4" border="1px solid grey">
            <tr align="left" bgcolor="#41337C">
                <th><font color="#fff">Employee Code</font></th>
                <th><font color="#fff">Resource Name</font></th>
                <th><font color="#fff">Email Address</font></th>
                <th><font color="#fff">Project Name</font></th>
                <th><font color="#fff">Department</font></th>
                <th><font color="#fff">Technology</font></th>
                <th><font color="#fff">Role</font></th>
                <th><font color="#fff">Daily Efforts</font></th>
                <th><font color="#fff">Deallocated for (hrs)</font></th>
                <th><font color="#fff">Deallocation from</font></th>
            </tr>
            @foreach($maildata['unMappingData'] as $key=>$value)
                <tr>
                    <td>{{$value['employeeId']}}</td>
                    <td>{{$value['name']}}</td>
                    <td>{{$value['email']}}</td>
                    <td>{{$value['projectName']}}</td>
                    <td>{{$value['department']}}</td>
                    <td>{{$value['technology']}}</td>
                    <td>{{$value['role']}}</td>
                    <td>{{$value['dailyEfforts']}}</td>
                    <td>{{$value['deAllocationForHours']}}</td>
                    <td>{{Carbon\Carbon::parse($value['deAllocationFrom'])->format('d/m/Y')}}</td>
                </tr>
            @endforeach
        </table>
    <p><strong>NOTE:</strong> This is a system-generated email.</p>
    <br>
    <p>Thanks and Regards,</p>
    <p>Successive Technologies</p>
</div>
</body>
</html>
