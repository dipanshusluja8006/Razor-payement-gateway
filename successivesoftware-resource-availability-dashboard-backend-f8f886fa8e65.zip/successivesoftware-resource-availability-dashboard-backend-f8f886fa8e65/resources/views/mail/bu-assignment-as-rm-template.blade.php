<!DOCTYPE html>
<html>
<head>
    <title>{{ $maildata->subject}} Mail</title>
</head>
<body>
<div>
    <p><strong>Hello,</strong></p>
    <p>The RM of below employees has been changed and updated to their BU Head.</p>
    @if(isset($maildata->submitArray) && count($maildata->submitArray) > 0)
        <table width="100%" cellspacing="0" cellpadding="4" border="1px solid grey">
            <h4 style="text-align: left;">Updated Details</h4>
            <tr align="left" bgcolor="#41337C">
                <th><font color="#fff">Resource Name</font></th>
                <th><font color="#fff">Employee Code</font></th>
                <th><font color="#fff">Department</font></th>
                <th><font color="#fff">Email Address</font></th>
                <th><font color="#fff">Assigned RM</font></th>
                <th><font color="#fff">Requested RM</font></th>
            </tr>
            @foreach($maildata->submitArray as $key=>$value)
                <tr>
                    <td>{{$value['resource_name']}}</td>
                    <td>{{$value['resource_employee_number']}}</td>
                    <td>{{$value['department']}}</td>
                    <td>{{$value['resource_email']}}</td>
                    <td>{{$value['active_manager_name']}}</td>
                    <td>{{$value['requested_manager_name']}}</td>
                </tr>
            @endforeach
        </table>
    @endif
    <p>Required Action: Now, Hr needs to update the reporting manager in Keka for the above mentioned resources.</p>
    <p><strong>NOTE:</strong> This is a system-generated email.</p>
    <br>
    <p>Thanks and Regards,</p>
    <p>Successive Technologies</p>
</div>
</body>
</html>
