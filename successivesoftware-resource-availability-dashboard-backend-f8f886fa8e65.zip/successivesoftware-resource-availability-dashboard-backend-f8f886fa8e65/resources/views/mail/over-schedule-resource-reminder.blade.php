<!DOCTYPE html>
<html>

<head>
    <title></title>
</head>
<body>
<p class="heading">Hello,<br/>Please find the list of resources who are over schedule.</p>
<div>

        <h4 >Over Schedule Resource - This Week ({{$duration}})</h4>
        <table width="100%" cellspacing="0" cellpadding="4" border="1px solid grey">
            <tr align="left" bgcolor="#41337C">
                <th><font color="#fff">Department</font></th>
                <th><font color="#fff">Resource Name</font></th>
                <th><font color="#fff">Start Date</font></th>
                <th><font color="#fff">End Date</font></th>
                <th><font color="#fff">Overscheduled Hours</font></th>
                <th><font color="#fff">Overscheduled Since (Days)</font></th>
            </tr>
            @foreach($data as $department)
                @foreach($department as $record)
                    @if ($loop->first)
                        <tr>
                            <td rowspan={{count($department)}}><strong class="department">{{$record->department}}</strong></td>
                            <td class="name">{{$record->name}}</td>
                            <td>{{$record->startDate}}</td>
                            <td>{{$record->endDate}}</td>
                            <td>{{$record->total - 8}}</td>
                            <td class="benchSince">{{$record->benchSince}}</td>
                        </tr>
                    @else
                        <tr>
                            <td class="name">{{$record->name}}</td>
                            <td>{{$record->startDate}}</td>
                            <td>{{$record->endDate}}</td>
                            <td>{{$record->total - 8}}</td>
                            <td class="benchSince">{{$record->benchSince}}</td>
                        </tr>
                    @endif
                @endforeach
            @endforeach
        </table>
        <br /><br />

</div>
<br><br>
<p><strong>NOTE:</strong> This is a system-generated email.</p>
<br>
<p>Thanks and Regards,</p>
<p>Successive Technologies</p>
</body>

</html>
