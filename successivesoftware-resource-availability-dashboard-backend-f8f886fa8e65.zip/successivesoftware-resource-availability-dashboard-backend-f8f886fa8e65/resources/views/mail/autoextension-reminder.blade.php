<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
<div>
   {!! $maildata['template']['template'] !!}
</div>
</body>
</html>
