<!DOCTYPE html>
<html>
<head>
    <title>Mail</title>
</head>
<body>
<div>
    <p><strong>Hello,</strong></p>
    <p>  This is a reminder to generate invoices for the below listed projects.</p>
    <div>
        <table width="100%" cellspacing="0" cellpadding="4" border="1px solid grey">
            <tr align="left" bgcolor="#41337C">
                <th><font color="#fff">Billing Type</font></th>
                <th><font color="#fff">Project Name</font></th>
            </tr>
            @foreach($maildata['data'] as $billingTypeKey => $data)
                @php
                    $billingType = $billingTypeKey;
                    $count = 0;
                @endphp

                    @foreach($data as $projectName)
                    <tr>
                        @php
                        $count = $count + 1;
                        @endphp
                        @if ($count == 1)
                        <td rowspan={{count($data)}}><strong class="department">{{$billingType}}</strong></td>
                        @endif
                        <td><strong class="department">{{$projectName}}</strong></td>
                    </tr>
                    @endforeach
            @endforeach
        </table>
    </div>
    <p><strong>NOTE:</strong> This is a system-generated email.</p>
    <p>Thanks and Regards,</p>
    <p>Successive Technologies</p>
</div>
</body>
</html>
