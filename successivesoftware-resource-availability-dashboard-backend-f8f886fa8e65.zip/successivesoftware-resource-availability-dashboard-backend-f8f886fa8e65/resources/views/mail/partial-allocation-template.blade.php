<!DOCTYPE html>
<html>
<head>
    <title>{{ $maildata->subject}} Mail</title>
</head>
<body>
<div>
    <p><strong>Hello,</strong></p>
    <p>The Business Unit Head has partially allocated the resource(s) for the <strong>{!! $maildata->projectArray->project_name !!}</strong> project.</p>
    <h4> Allocation Details</h4>
    @php
        $checkheader = 0;
    @endphp
    @foreach($maildata->submitArray as $allocationData)
        @if($allocationData['data'][0]['allocation_status'] == config('constant.PROJECT_ACTION')['resource_allocation_request'])
        <p>Number of Requested Resources<strong> : {{$allocationData['count']}}</strong></p>
        @endif
        <table width="100%" cellspacing="0" cellpadding="4" border="1px solid grey">
            @foreach($allocationData['data'] as $key=>$value)
              @if($value['allocation_status'] == 4)
              @if(!empty($value['allocation_status']))
            @php
                $checkheader = $checkheader + 1;
            @endphp
            @if ($checkheader == 1 && $value['type']!=1)
                <tr align="left" bgcolor="#41337C">
                <th><font color="#fff">Employee Code</font></th>
                <th><font color="#fff">Resource Name</font></th>
                <th><font color="#fff">Email Address</font></th>
                <th><font color="#fff">Department</font></th>
                <th><font color="#fff">Daily Efforts</font></th>
                <th><font color="#fff">Experience</font></th>
                <th><font color="#fff">Billing Type</font></th>
                <th><font color="#fff">Start Date</font></th>
                <th><font color="#fff">End Date</font></th>
                </tr>
            @elseif($value['type']==1)
                <tr align="left" bgcolor="#41337C">
                <th><font color="#fff">Employee Code</font></th>
                <th><font color="#fff">Resource Name</font></th>
                <th><font color="#fff">Email Address</font></th>
                <th><font color="#fff">Department</font></th>
                <th><font color="#fff">Daily Efforts</font></th>
                <th><font color="#fff">Experience</font></th>
                <th><font color="#fff">Billing Type</font></th>
                <th><font color="#fff">Start Date</font></th>
                <th><font color="#fff">End Date</font></th>
                </tr>
            @endif
            @endif
            <tr>
              <td>{{$value['employee_code']}}</td>
              <td>{{$value['resource_name']}}</td>
              <td>{{$value['employee_email']}}</td>
              <td>{{$value['department']}}</td>
              <td>{{$value['efforts']}}</td>
              <td>{{$value['experience']}}</td>
              <td>{{$value['billing_type']}}</td>
              <td>{{Carbon\Carbon::parse($value['start_date'])->format('d/m/Y')}}</td>
              <td>{{Carbon\Carbon::parse($value['end_date'])->format('d/m/Y')}}</td>
            </tr>
              @endif
            @endforeach
        </table>
    @endforeach
    <p>The Account Manager/Project Manager must take actions on partial resource allocation to proceed further with the resource request.</p>
    <p><strong>NOTE:</strong> This is a system-generated email.</p>
    <br>
    <p>Thanks and Regards,</p>
    <p>Successive Technologies</p>
</div>
</body>
</html>
