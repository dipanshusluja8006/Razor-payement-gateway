<!DOCTYPE html>
<html>

<head>
    <title>{{ $maildata->subject}}</title>
</head>

<body>
    <div>
        <p><strong>Hello,</strong></p>
        <p>You need to report to {!! $maildata->submitArray['project_manager'] !!} because you have been allocated to {!! $maildata->projectArray->project_name !!} project for {!! $maildata->submitArray['project_hours'] !!} hours.</p>
        <p><strong>NOTE:</strong> This is a system-generated email.</p>
        <br>
        <p>Thanks and Regards,</p>
        <p>Successive Technologies</p>
    </div>
</body>

</html>