<!DOCTYPE html>
<html>
<head>
    <title>Mail</title>
</head>
<body>
<div>
    <p><strong>Hello,</strong></p>
    <p>  This mail contains the list of resource booking discrepancies for PMO and Redmine.</p>
    <br />
    <h3 > <font color="#FF0000"> Resource Booking Discrepancies</font></h3>
    <div>
        <table width="100%" cellspacing="0" cellpadding="4" border="1px solid grey">
            <tr align="left" bgcolor="#41337C">
                <th><font color="#fff">Project Name</font></th>
                <th><font color="#fff">Employee Code</font></th>
                <th><font color="#fff">Resource Name</font></th>
                <th><font color="#fff">Email Address</font></th>
                <th><font color="#fff">PMO Start Date</font></th>
                <th><font color="#fff">PMO End Date</font></th>
                <th><font color="#fff">PMO Daily Efforts</font></th>
                <th><font color="#fff">Redmine Start Date</font></th>
                <th><font color="#fff">Redmine End Date</font></th>
                <th><font color="#fff">Redmine Daily Efforts</font></th>
            </tr>
            @foreach($maildata['data'] as $projectName => $project)
                @php
                    $ProjectCount = 0;
                    $count = 0
                @endphp
                @foreach($project as $resource)
                    @php
                        $count = $count + count($resource)
                    @endphp
                @endforeach
            @foreach($project as $resourceName => $resource)
                    @php
                        $resourceCount = 0
                    @endphp
                @foreach($resource as $value)
                        <tr>
                        @php
                            $resourceCount = $resourceCount +1;
                            $ProjectCount = $ProjectCount + 1;
                        @endphp
                              @if ($ProjectCount == 1)
                                 <td rowspan={{$count}}><strong class="department">{{$projectName}}</strong></td>
                              @endif
                              @if ($resourceCount == 1)
                                <td rowspan={{count($resource)}}><strong>{{$value['resourceName']}}</strong></td>
                                <td rowspan={{count($resource)}}>{{$value['employeeId']}}</td>
                                <td rowspan={{count($resource)}}>{{$value['email']}}</td>
                              @endif
                                <td >{{$value['pmoStartDate']}}</td>
                                <td>{{$value['pmoEndDate']}}</td>
                                <td>{{$value['pmoDailyEfforts']}}</td>
                                <td >{{$value['redmineStartDate']}}</td>
                                <td>{{$value['redmineEndDate']}}</td>
                                <td >{{$value['redmineDailyEfforts']}}</td>
                        </tr>
                @endforeach
                @endforeach
            @endforeach
        </table>
        <br /><br />

    </div>
    <br><br>
    <p><strong>NOTE:</strong> This is a system-generated email.</p>
    <br>
    <p>Thanks and Regards,</p>
    <p>Successive Technologies</p>
</div>
</body>
</html>
