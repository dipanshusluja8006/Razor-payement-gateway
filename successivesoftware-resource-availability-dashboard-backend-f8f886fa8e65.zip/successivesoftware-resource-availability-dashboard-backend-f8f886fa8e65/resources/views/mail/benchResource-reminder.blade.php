<!DOCTYPE html>
<html>

<head>
    <title></title>
</head>
<body>
    <p class="heading">Hello,<br/>Please find the list of resources who are on bench or unscheduled.</p>
    <div>
        @if(array_key_exists('week', $data))
        <h4 >Bench/Unscheduled Resources - This Week ({{$duration}})</h4>
            <table width="100%" cellspacing="0" cellpadding="4" border="1px solid grey">
                <tr align="left" bgcolor="#41337C">
                <th><font color="#fff">Department</font></th>
                <th><font color="#fff">Resource Type</font></th>
                <th><font color="#fff">Resource Name</font></th>
                <th><font color="#fff">Start Date</font></th>
                <th><font color="#fff">End Date</font></th>
                <th><font color="#fff">Bench Hours</font></th>
                <th><font color="#fff">On Bench Since (Days)</font></th>
            </tr>
            @foreach($data['week'] as $department)
            @php
                $departmentEmp = isset($department['Employees']) ? $department['Employees'] : [];
                $departmentTrainee = isset($department['Trainees']) ? $department['Trainees'] : [];
                $totalDeptRes = count($departmentEmp) + count($departmentTrainee);
                $count = 0;
                $empCount = 0;
                $traneeCount = 0;
            @endphp
            @foreach($departmentEmp as $record)
                @php
                    $empCount =  $empCount + 1;
                    $count = $count + 1;
                @endphp
                <tr>
                    @if($count == 1 )
                        <td rowspan={{$totalDeptRes}}><strong class="department">{{$record[0]}}</strong></td>
                    @endif
                    @if($empCount == 1)
                        <td rowspan={{count($departmentEmp)}}><strong class="department">Employees</strong></td>
                    @endif
                    <td class="name">{{$record[1]}}</td>
                    <td>{{$record[2]}}</td>
                    <td>{{$record[3]}}</td>
                    <td>{{$record[4]}}</td>
                    <td class="benchSince">{{$record[5]}}</td>
                </tr>
            @endforeach
            @foreach($departmentTrainee as $record)
                @php
                    $traneeCount =  $traneeCount + 1;
                    $count = $count + 1;
                @endphp
                <tr>
                    @if($count == 1 )
                        <td rowspan={{$totalDeptRes}}><strong class="department">{{$record[0]}}</strong></td>
                    @endif
                    @if($traneeCount == 1)
                        <td rowspan={{count($departmentTrainee)}}><strong class="department">Trainees</strong></td>
                    @endif
                    <td class="name">{{$record[1]}}</td>
                    <td>{{$record[2]}}</td>
                    <td>{{$record[3]}}</td>
                    <td>{{$record[4]}}</td>
                    <td class="benchSince">{{$record[5]}}</td>
                </tr>
            @endforeach
            @endforeach

        </table>
        <br /><br />
        @endif

        @if(array_key_exists('nextWeek', $data))
        <h4 >Bench/Unscheduled Resources - Next Week ({{$nextDuration}})</h4>
        <table width="100%" cellspacing="0" cellpadding="4" border="1px solid grey">
            <tr align="left" bgcolor="#41337C">
                <th><font color="#fff">Department</font></th>
                <th><font color="#fff">Resource Type</font></th>
                <th><font color="#fff">Resource Name</font></th>
                <th><font color="#fff">Start Date</font></th>
                <th><font color="#fff">End Date</font></th>
                <th><font color="#fff">Bench Hours</font></th>
                <th><font color="#fff">On Bench Since (Days)</font></th>
            </tr>

            @foreach($data['nextWeek'] as $department)
                @php
                    $departmentEmp = isset($department['Employees']) ? $department['Employees'] : [];
                    $departmentTrainee = isset($department['Trainees']) ? $department['Trainees'] : [];
                    $totalDeptRes = count($departmentEmp) + count($departmentTrainee);
                    $count = 0;
                    $empCount = 0;
                    $traneeCount = 0;
                @endphp
                @foreach($departmentEmp as $record)
                    @php
                        $empCount =  $empCount + 1;
                        $count = $count + 1;
                    @endphp
                    <tr>
                        @if($count == 1 )
                            <td rowspan={{$totalDeptRes}}><strong class="department">{{$record[0]}}</strong></td>
                        @endif
                        @if($empCount == 1)
                            <td rowspan={{count($departmentEmp)}}><strong class="department">Employee</strong></td>
                        @endif
                        <td class="name">{{$record[1]}}</td>
                        <td>{{$record[2]}}</td>
                        <td>{{$record[3]}}</td>
                        <td>{{$record[4]}}</td>
                        <td class="benchSince">{{$record[5]}}</td>
                    </tr>
                @endforeach
                @foreach($departmentTrainee as $record)
                    @php
                        $traneeCount =  $traneeCount + 1;
                        $count = $count + 1;
                    @endphp
                    <tr>
                        @if($count == 1 )
                            <td rowspan={{$totalDeptRes}}><strong class="department">{{$record[0]}}</strong></td>
                        @endif
                        @if($traneeCount == 1)
                            <td rowspan={{count($departmentTrainee)}}><strong class="department">Trainees</strong></td>
                        @endif
                        <td class="name">{{$record[1]}}</td>
                        <td>{{$record[2]}}</td>
                        <td>{{$record[3]}}</td>
                        <td>{{$record[4]}}</td>
                        <td class="benchSince">{{$record[5]}}</td>
                    </tr>
                @endforeach
            @endforeach
        </table>
        @endif
    </div>
    <br><br>
    <p><strong>NOTE:</strong> This is a system-generated email.</p>
    <br>
    <p>Thanks and Regards,</p>
    <p>Successive Technologies</p>
</body>

</html>
