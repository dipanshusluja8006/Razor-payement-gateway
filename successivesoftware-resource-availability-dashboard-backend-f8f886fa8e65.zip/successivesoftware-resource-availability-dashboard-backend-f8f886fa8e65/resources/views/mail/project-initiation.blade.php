<!DOCTYPE html>
<html>
<head>
    <title>Test Mail</title>
</head>
<body>
<div>
    <p><strong>Hi,</strong></p>

  Test Mail
</div>
</body>
</html>
