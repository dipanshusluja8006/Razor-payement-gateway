<!DOCTYPE html>
<html>
<head>
    <title>{{ $maildata->subject}} Mail</title>
</head>
<body>
<div>
    <p><strong>Hello,</strong></p>
    <p>The Account Manager/Project Manager has restarted the <strong>{!! $maildata->projectArray->project_name !!}</strong> project. </p>
    @if($maildata->submitArray['comment']!='')
    <p><strong>Reason For Project Restart:</strong> {!! nl2br($maildata->submitArray['comment']) !!}</p>
    @endif
    <p><strong>NOTE:</strong> This is a system-generated email.</p>
    <br>
    <p>Thanks and Regards,</p>
    <p>Successive Technologies</p>
</div>
</body>
</html>