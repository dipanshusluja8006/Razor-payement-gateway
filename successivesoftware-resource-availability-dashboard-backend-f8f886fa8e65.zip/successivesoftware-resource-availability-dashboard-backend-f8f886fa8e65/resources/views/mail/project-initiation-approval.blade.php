<!DOCTYPE html>
<html>
<head>
    <title>{{ $maildata->subject}} Mail</title>
</head>
<body>
<div>
    <p><strong>Hello,</strong></p>
    <p>The Global operations head has updated details for the <strong>'{!! $maildata->projectArray->project_name !!}'</strong> project.</p>
    <h4 style="text-align: left;">Updated Details</h4>
    <table width="100%" cellspacing="0" cellpadding="4" border="1px solid grey">

    </table>
    <p>The Resource Manager must update the changes in project details on Redmine.</p>
    <p><strong>NOTE:</strong> This is a system-generated email.</p>
    <br>
    <p>Thanks and Regards,</p>
    <p>Successive Technologies</p>
</div>
</body>
</html>
