<!DOCTYPE html>
<html>
<head>
    <title>{{ $maildata->subject}} Mail</title>
</head>
<body>
<div>
    <p><strong>Hello,</strong></p>
    <p>The Account Manager/Project Manager has generated a request for partial resource deallocation for the  <strong>{!! $maildata->projectArray->project_name !!}</strong> project.</p>
    <h4>Partial Deallocated Details</h4>
    <table width="100%" cellspacing="0" cellpadding="4" border="1px solid grey">
    <tr align="left" bgcolor="#41337C" text="white">
        <th><font color="#fff">Employee Code</font></th>
        <th><font color="#fff">Resource Name</font></th>
        <th><font color="#fff">Email Address</font></th>
        <th><font color="#fff">Department</font></th>
        <th><font color="#fff">Daily Efforts</font></th>
        <th><font color="#fff">Experience</font></th>
        <th><font color="#fff">Billing Type</font></th>
        <th><font color="#fff">Deallocated for (hrs)</font></th>
        <th><font color="#fff">Deallocated from</font></th>
    </tr>
        @foreach($maildata->submitArray as $key=>$value)
        @if($value['full_deallocate'] == false)
    <tr>
        <td>{{$value['employee_code']}}</td>
        <td>{{$value['resource_name']}}</td>
        <td>{{$value['employee_email']}}</td>
        <td>{{$value['department']}}</td>
        <td>{{$value['efforts']}}</td>
        <td>{{$value['experience']}}</td>
        <td>{{$value['billing_type']}}</td>
        <td>{{$value['deallocated_hours']}}</td>
        <td>{{Carbon\Carbon::parse($value['start_date'])->format('d/m/Y')}}</td>
    </tr>
        @endif
        @endforeach
    </table>
    <p>The Resource Manager must proceed with resource unmapping on Redmine</p>
    <p><strong>NOTE:</strong> This is a system-generated email.</p>
    <br>
    <p>Thanks and Regards,</p>
    <p>Successive Technologies</p>
</div>
</body>
</html>
