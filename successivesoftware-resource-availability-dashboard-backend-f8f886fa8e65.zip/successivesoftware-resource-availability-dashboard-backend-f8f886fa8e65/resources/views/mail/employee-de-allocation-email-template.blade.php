<!DOCTYPE html>
<html>

<head>
    <title>{{ $maildata->subject}}</title>
</head>

<body>
    <div>
        <p><strong>Hello,</strong></p>
        <p>This is to inform you that you have been deallocated from {!! $maildata->projectArray->project_name !!} with effect from {!! $maildata->submitArray['deallocation_date'] !!} for {!! $maildata->submitArray['deallocation_hours'] !!} hours.</p>
        <p><strong>NOTE:</strong> This is a system-generated email.</p>
        <br>
        <p>Thanks and Regards,</p>
        <p>Successive Technologies</p>
    </div>
</body>

</html>