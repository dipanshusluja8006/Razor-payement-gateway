<!DOCTYPE html>
<html>
<head>
    <title>{{ $maildata->subject}} Mail</title>
</head>
<body>
<div>
    <p><strong>Hello,</strong></p>
    @if($maildata->code == 'on_hold_request')
    <p>The Account Manager/Project Manager has generated a request to set <strong>{!! $maildata->projectArray->project_name !!}</strong> project On-Hold </p>
    @endif
    <p>The Global Operations must take an action on the project on-hold request.</p>
    <p><strong>NOTE:</strong> This is a system-generated email.</p>
    <br>
    <p>Thanks and Regards,</p>
    <p>Successive Technologies</p>
</div>
</body>
</html>