<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
<div>
    <p><strong>Hello,</strong></p>
    <p>The resource extension request for the <strong>{{$maildata['projectName']}}</strong> project has been lapsed due to a delay in taking action.
            Following are the details: </p>
    @if(!empty($maildata['noAllocation']))
        <h4 class="header">No Action performed on extension request by BU Heads </h4>
        <table width="100%" cellspacing="0" cellpadding="4" border="1px solid grey">
            <tr align="left" bgcolor="#41337C">
                <th><font color="#fff">Resource Name</font></th>
                <th><font color="#fff">Department</font></th>
                <th><font color="#fff">Designation</font></th>
                <th><font color="#fff">Technology</font></th>
                <th><font color="#fff">Extended for</font></th>
                <th><font color="#fff">Extended From</font></th>
                <th><font color="#fff">Extended To</font></th>
            </tr>
            @foreach($maildata['noAllocation'] as $key => $value)
                <tr>
                    <td>{{$value['resource_name']}}</td>
                    <td>{{$value['department']}}</td>
                    <td>{{$value['role']}}</td>
                    <td>{{$value['technology']}}</td>
                    <td>{{$value['dailyEffort']}}</td>
                    <td>{{Carbon\Carbon::parse($value['startData'])->format('d/m/Y')}}</td>
                    <td>{{Carbon\Carbon::parse($value['endDate'])->format('d/m/Y')}}</td>
                </tr>
            @endforeach
        </table>
    @endif

    @if(!empty($maildata['partialAllocation']))
        <h4 >Partial Allocation performed on extension request Action by AM/PM </h4>
        <table width="100%" cellspacing="0" cellpadding="4" border="1px solid grey">
            <tr align="left" bgcolor="#41337C">
                <th><font color="#fff">Resource Name</font></th>
                <th><font color="#fff">Department</font></th>
                <th><font color="#fff">Designation</font></th>
                <th><font color="#fff">Technology</font></th>
                <th><font color="#fff">Extended for</font></th>
                <th><font color="#fff">Extended From</font></th>
                <th><font color="#fff">Extended To</font></th>
            </tr>
            @foreach($maildata['partialAllocation'] as $key => $value)
                <tr>
                    <td>{{$value['resource_name']}}</td>
                    <td>{{$value['department']}}</td>
                    <td>{{$value['role']}}</td>
                    <td>{{$value['technology']}}</td>
                    <td>{{$value['dailyEffort']}}</td>
                    <td>{{Carbon\Carbon::parse($value['startData'])->format('d/m/Y')}}</td>
                    <td>{{Carbon\Carbon::parse($value['endDate'])->format('d/m/Y')}}</td>
                </tr>
            @endforeach
        </table>
    @endif

    @if(!empty($maildata['reallocation']))
        <h4 >Reallocation pending on extension request Action by BU Head </h4>
        <table width="100%" cellspacing="0" cellpadding="4" border="1px solid grey">
            <tr align="left" bgcolor="#41337C">
                <th><font color="#fff">Resource Name</font></th>
                <th><font color="#fff">Department</font></th>
                <th><font color="#fff">Designation</font></th>
                <th><font color="#fff">Technology</font></th>
                <th><font color="#fff">Extended for</font></th>
                <th><font color="#fff">Extended From</font></th>
                <th><font color="#fff">Extended To</font></th>
            </tr>
            @foreach($maildata['reallocation'] as $key => $value)
                <tr>
                    <td>{{$value['resource_name']}}</td>
                    <td>{{$value['department']}}</td>
                    <td>{{$value['role']}}</td>
                    <td>{{$value['technology']}}</td>
                    <td>{{$value['dailyEffort']}}</td>
                    <td>{{Carbon\Carbon::parse($value['startData'])->format('d/m/Y')}}</td>
                    <td>{{Carbon\Carbon::parse($value['endDate'])->format('d/m/Y')}}</td>
                </tr>
            @endforeach
        </table>
    @endif

    @if(!empty($maildata['mappingPending']))
        <h4 >Mapping Pending on extension request Action by Resource Manager </h4>
        <table width="100%" cellspacing="0" cellpadding="4" border="1px solid grey">
            <tr align="left" bgcolor="#41337C">
                <th><font color="#fff">Resource Name</font></th>
                <th><font color="#fff">Department</font></th>
                <th><font color="#fff">Designation</font></th>
                <th><font color="#fff">Technology</font></th>
                <th><font color="#fff">Extended for</font></th>
                <th><font color="#fff">Extended From</font></th>
                <th><font color="#fff">Extended To</font></th>
            </tr>
            @foreach($maildata['mappingPending'] as $key => $value)
                <tr>
                    <td>{{$value['resource_name']}}</td>
                    <td>{{$value['department']}}</td>
                    <td>{{$value['role']}}</td>
                    <td>{{$value['technology']}}</td>
                    <td>{{$value['dailyEffort']}}</td>
                    <td>{{Carbon\Carbon::parse($value['startData'])->format('d/m/Y')}}</td>
                    <td>{{Carbon\Carbon::parse($value['endDate'])->format('d/m/Y')}}</td>
                </tr>
            @endforeach
        </table>
    @endif
    <p>Please raise a new resource requisition request in order to allocate the above-mentioned resources.</p>
    <p><strong>NOTE:</strong> This is a system-generated email.</p>
    <br>
    <p>Thanks and Regards,</p>
    <p>Successive Technologies</p>
</div>
</body>

</html>
