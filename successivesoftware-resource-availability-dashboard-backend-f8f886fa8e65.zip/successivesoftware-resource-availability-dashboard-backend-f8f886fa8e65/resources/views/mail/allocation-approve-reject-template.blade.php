<!DOCTYPE html>
<html>
<head>
    <title>{{ $maildata->subject}} Mail</title>
</head>
<body>
<div>
    <p><strong>Hello,</strong></p>
    @if($maildata->submitArray['allocation_status'] == 14)
    <p>The Account Manager/Project Manager has accepted partial allocation submitted by Business Unit Head for the <strong>{!! $maildata->projectArray->project_name !!}</strong> project.</p>
    <h4>Allocation Approve Details</h4>
    @else
    <p>The Account Manager/Project Manager has rejected partial allocation submitted by Business Unit Head for the <strong>{!! $maildata->projectArray->project_name !!}</strong> project.</p>
    <h4>Allocation Decline Details</h4>
    @endif
    <table width="100%" cellspacing="0" cellpadding="4" border="1px solid grey">
    <tr align="left" bgcolor="#41337C">
        <th><font color="#fff">Employee Code</font></th>
        <th><font color="#fff">Resource Name</font></th>
        <th><font color="#fff">Email Address</font></th>
        <th><font color="#fff">Department</font></th>
        <th><font color="#fff">Daily Efforts</font></th>
        <th><font color="#fff">Experience</font></th>
        <th><font color="#fff">Billing Type</font></th>
        <th><font color="#fff">Start Date</font></th>
        <th><font color="#fff">End Date</font></th>
    </tr>
        <tr>
        <td>{{$maildata->submitArray['employee_code']}}</td>
        <td>{{$maildata->submitArray['resource_name']}}</td>
        <td>{{$maildata->submitArray['employee_email']}}</td>
        <td>{{$maildata->submitArray['deptartment']}}</td>
        <td>{{$maildata->submitArray['efforts']}}</td>
        <td>{{$maildata->submitArray['experience']}}</td>
        <td>{{$maildata->submitArray['billing_type']}}</td>
        <td>{{Carbon\Carbon::parse($maildata->submitArray['start_date'])->format('d/m/Y')}}</td>
        <td>{{Carbon\Carbon::parse($maildata->submitArray['end_date'])->format('d/m/Y')}}</td>
        </tr>
    </table>
    @if($maildata->submitArray['allocation_status'] == 14)
    <!-- <p>The Resource Manager must proceed with resource mapping on Redmine.</p> -->
    @else
    <p>The Business Unit Heads must take action on resource reallocation.</p>
    @endif
    <p><strong>NOTE:</strong> This is a system-generated email.</p>
    <br>
    <p>Thanks and Regards,</p>
    <p>Successive Technologies</p>
</div>
</body>
</html>
