<!DOCTYPE html>
<html>
          @include('mail.'.$maildata->template)

</html>
