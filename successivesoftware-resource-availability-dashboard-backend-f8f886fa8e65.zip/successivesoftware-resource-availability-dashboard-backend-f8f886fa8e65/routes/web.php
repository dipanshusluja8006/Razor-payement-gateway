<?php



//$router->get('/', function () use ($router) {
// return $router->app->version();
//});


//$router->get('/locations', 'Resource\ResourceController@location');
//$router->get('/department', 'Resource\ResourceController@Department');
//
//$router->get('/fully-scheduled', 'Resource\ResourceController@fullyScheduled');
//$router->get('/un-scheduled', 'Resource\ResourceController@unScheduled');
