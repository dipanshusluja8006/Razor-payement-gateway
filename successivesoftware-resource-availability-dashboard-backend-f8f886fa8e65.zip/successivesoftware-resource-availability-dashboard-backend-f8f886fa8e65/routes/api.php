<?php

use Illuminate\Support\Facades\Artisan;

$router->get('/', function () use ($router) {
    return $router
        ->app
        ->version();
});

$router->group(['middleware' => 'auth'], function () use ($router) {
    $router->get('/v1/locations', 'Resource\ResourceController@location');
    $router->get('/v1/departments', 'Resource\ResourceController@department');
    $router->get('/v1/categories', 'Resource\ResourceController@categories');
    $router->get('/v1/billing-types', 'Resource\ResourceController@billing');
    $router->get('/v1/projects', 'Resource\ResourceController@project');
    $router->get('/v3/resources-availability', 'Resource\ResourceDataController@resourcesAvailability');
    $router->get('/v3/resources-availability-details', 'Resource\ResourceDataController@assignedProjectToUser');
    $router->get('/v3/resources-availability-download', 'Resource\ResourceDataController@resourcesAvailabilityDownload');
    $router->get('/v3/resourceutilization-summary', 'Resource\ResourceDataController@resourcesUtilizationSummary');
    $router->get('/v3/resource-time-bu', 'Resource\ResourceDataController@resourceTimeBu');
    $router->get('/v3/total-resources-bu', 'Resource\BUHeadController@BuTotalResources');


});

$router->group(['middleware' => ['auth'], 'prefix' => 'v1', 'namespace' => 'Admin'], function () use ($router) {
    // admin permission group Routes
    $router->group(['middleware' => ['roles:admin']], function () use ($router) {

        //User Management
        $router->get('/user-management', 'UserManagementController@index');
        $router->get('/all-roles', 'UserManagementController@allRoles');
        $router->post('/update-roles', 'UserManagementController@update');
        $router->get('/cron-log', 'UserManagementController@getCronLog');

    });

});

$router->group(['middleware' => ['auth'], 'prefix' => 'v1', 'namespace' => 'Resource'], function () use ($router) {
    //Billing
    $router->get('/billing-type', 'BillingTypeController@index');
    $router->get('/create-cron-logic', 'ProjectController@checkCronLogic');

    //Billing Medium
    $router->get('/billing-medium', 'BillingMediumController@index');

    //Department
    $router->get('/department', 'DepartmentController@index');

    //Department
    $router->get('/lifecycle-model', 'LifeCycleController@index');

    //Technology
    $router->get('/technology', 'TechnologyController@index');
    $router->post('/technology', 'TechnologyController@create');

    //Project Domain
    $router->get('/project-domain', 'ProjectDomainController@index');
    $router->post('/project-domain', 'ProjectDomainController@store');

    //Designation
    $router->get('/designation', 'DesignationController@index');
    $router->post('/designation', 'DesignationController@store');

    //User routes
    $router->get('/user', 'UserController@index');

    $router->get('/user-role', 'UserController@userUserRole');
    $router->get('/user-global-role', 'UserController@getUserAllGlobalRoles');

    //Clients
    $router->get('/client', 'ClientController@index');
    $router->post('/client', 'ClientController@store');

    //Holiday Details
    $router->put('/resource-calendar', 'HolidayController@index');

    //Project Routes
    $router->get('/project', 'ProjectController@index');
    $router->get('/project/{uuid}', 'ProjectController@show');
    $router->get('/user-project-role', 'ProjectController@userProjectRole');
    $router->get('/project-action/{projectId}', 'ProjectController@projectAction');
    $router->get('/project-export', 'ProjectController@exportMismatchSheet');

//    resource-summary
    $router->get('/resource-summary', 'ProjectController@resourceSummary');

    //Invoce Status
    $router->get('/invoice-status', 'InvoiceController@index');

    $router->post('/invoice-reminder', 'InvoiceController@invoiceSendReminder');

    $router->get('/timesheet-summary', 'UserTimeSheetController@resourcesTimesheetSummary');

    $router->post('/timesheet-reminder', 'UserTimeSheetController@timesheetSendReminder');


    //Resource requisition routes
    $router->get('/resource-requisition/{projectId}', 'ResourceRequisitionController@show');
    $router->get('/resource-requiestion-by-dept/{projectId}', 'ResourceRequisitionController@showRequistionByDept');
    $router->put('/reject-requisition', 'ResourceRequisitionController@rejectRequisition');
    $router->get('/get-reject-reason', 'RejectReasonController@index');

    //Resource allocation and deallocation routes
    $router->get('/resource-allocation/{projectUuid}/{type}', 'ResourceAllocationController@show');
    $router->get('/resource-allocation-dept/{projectUuid}/{type}', 'ResourceAllocationController@showByDepartment');
    $router->put('/resource-re-allocation', 'ResourceAllocationController@reAllocate');
    $router->put('/resource-allocation-approve/{allocated_uuid}', 'ResourceAllocationController@approveRequest');
    $router->post('/resource-allocation', 'ResourceAllocationController@create');
    $router->post('/resource-deallocation', 'ResourceDeAllocationController@deAllocate');
    //Direct Resource Allocation
    $router->post('/direct-resource-allocation', 'ResourceEditController@directAllocation');

    //Edit Resource Allocation
    $router->get('/edit-allocation-list/{projectUuid}', 'ResourceEditController@show');
    $router->put('/edit-allocation', 'ResourceEditController@update');

    // Resource mappings
    $router->get('/allocation-map/{uuid}', 'ResourceMappingController@showAllocated');

    //DeAllocation Mapping
    $router->get('/de-allocation-map/{uuid}', 'DeAllocationMappingController@showDeAllocated');

    // project on hold
    $router->get('/on-hold/{projectId}', 'ProjectStatusController@show');

    //project closure
    $router->get('/project-closure/{projectId}', 'ProjectClosureController@show');

    //Root Cause Analysis
    $router->get('/rca-reporter-users', 'ProjectRcaDetailController@rcaReporterUsers');
    $router->get('/rca-listing-for-kedb/{uuid}', 'ProjectRcaDetailController@rcaListForKedb');

    //Resource Allocation Log
    $router->get('/resource-reallocation-log/{projectId}', 'ResourceAllocationController@reAllocationLog');
    $router->get('/resource-deallocation-log/{projectId}', 'ResourceAllocationController@deAllocationLog');

    // Project KEDB
    $router->get('/kedb', 'ProjectKedbDetailController@index');
    $router->get('/kedb/{kedb_id}', 'ProjectKedbDetailController@show');
    $router->post('/kedb', 'ProjectKedbDetailController@create');
    $router->get('/all-assigned-project', 'ProjectController@getAllAssignedProject');

    // Attachment
    $router->post('/attachment', 'AttachmentController@create');
    $router->get('/attachment/{id}', 'AttachmentController@getDownload');
    $router->delete('/attachment/{id}', 'AttachmentController@destroy');

    //Tag
    $router->get('/tag', 'TagController@index');
    $router->post('/tag', 'TagController@create');

    //ProjectType
    $router->get('/project-type', 'ProjectTypeController@index');

    //Governance Category
    $router->get('/governance-category', 'GovernanceCategoryController@index');

    //pyramid
    $router->get('/pyramid-employee/{deptId}', 'KekaDetailController@getAllEmployeeDetails');
    $router->get('/pyramid', 'KekaDetailController@index');
    $router->get('/pyramid/{pyramidId}', 'KekaDetailController@show');

    //project-listings
    $router->get('/project-listings', 'ProjectController@projectListing');

    //project-listings-redmine
    $router->get('/project-redmine-listings', 'ProjectController@projectListingRedmine');

    //project-action types
    $router->get('/project-actiontypes', 'ProjectActionTypeController@index');

    //project-activities
    $router->get('/show-project-activity/{projectId}', 'ProjectController@projectActivity');

    //project-activities
    $router->get('/show-activity-user', 'ProjectController@projectActivityUsers');

    //requested records
    $router->get('/manager-requests', 'ReportingManagerController@reportingRequestList');
    $router->get('/department-wise-reporting', 'ReportingManagerController@departmentWiseReporting');
    $router->get('/direct-reporting', 'ReportingManagerController@directReportingResource');
    $router->get('/manager-requests/{projectId}', 'ReportingManagerController@manageProjectReporting');

    //Test Unmapping
    $router->get('/unmapping', 'DeAllocationMappingController@testUnmapping');

    //Add weekly-status-report
    $router->post('/weekly-status-report', 'WeeklyStatusReportController@store');

    //Update weekly-status-report
    $router->put('/weekly-status-report-update/{uuid}', 'WeeklyStatusReportController@editWsr');

    //weekly-status-report-list
    $router->get('/weekly-status-report-list', 'WeeklyStatusReportController@index');

    //weekly-status-report-list
    $router->post('/weekly-status-report-list', 'WeeklyStatusReportController@index');

    //weekly-status-report-list
    $router->get('/view-weekly-status-details/{uuid}', 'WeeklyStatusReportController@show');

    //project-wsr-data-list
    $router->get('/project-wsr-data', 'ProjectController@projectWSRData');

    // top-project-graph-backend
    $router->get('/top-project-graph', 'ProjectController@topProjectGarph');

    // project kick-off-backend
    $router->get('/project-kick-off','ProjectController@projectKickOff');

     //project-active-risk-list
     $router->get('/project-active-risk-data', 'ProjectController@projectActiveRisk');

    //Add action-items
    $router->post('/add-action-items', 'WSRActionItemsController@store');

    //action-items list
    $router->get('/action-item-list', 'WSRActionItemsController@index');

    //action-items mark-done
    $router->put('/action-item-mark-done/{uuid}', 'WSRActionItemsController@actionItemMarkDone');

    //action-items list
    $router->get('/assigned-action-item-list', 'WSRActionItemsController@assignedActionItem');

    //action-items list
    $router->get('/get-asssign-users', 'UserController@getAssignUsers');

    //project-manager list
    $router->get('/get-asssign-pm-users', 'UserController@getAssignUsersPM');

    //project-actual-estimated-efforts-list
    $router->get('/project-efforts-list', 'ProjectController@projectEffortsData');

    //current-year-week-list
    $router->get('/current-year-week-list', 'WeeklyStatusReportController@getYearWeekList');

    //pmo-project-listing
    $router->get('/pmo-project-listing', 'ProjectController@pmoProjectListing');

     //pmo-project-listing
     $router->get('/project-at-risk-data', 'ProjectController@projectAtRisk');

     //project-wsr-data-list
     $router->get('/project-wsr-pmrag-list', 'ProjectController@projectWisePMRag');

     //BU wise rag status
    $router->get('/bu-wise-rag-status', 'WeeklyStatusReportController@getBuWiseRagData');
    $router->post('/bu-wise-rag-status', 'WeeklyStatusReportController@getBuWiseRagData');

    // PM wise RAG status
    $router->get('/pm-wise-rag-status/{weekId}', 'WeeklyStatusReportController@getPMWiseRagData');
    $router->post('/pm-wise-rag-status', 'WeeklyStatusReportController@getPMWiseRagData');
    
    // Project wise RAG status
    $router->get('/project-wise-rag-status', 'WeeklyStatusReportController@getProjectWiseRagData');
    $router->post('/project-wise-rag-status', 'WeeklyStatusReportController@getProjectWiseRagData');
    // partnerCollaboration
    $router->get('/partner-collaboration', 'ProjectController@partnerCollaboration');

    // get year wise resource experience 
    $router->get('/resource-experience', 'ResourceController@getResourceExperience');
    // BU dashboard (display department wise data)
    // $router->get('department-wise-rag-status', 'WeeklyStatusReportController@getDepartmentWiseRagData');
    $router->get('department-wise-rag-status/{deptId}', 'WeeklyStatusReportController@getDepartmentWiseRagData');
    // Department wise rag status
    $router->get('department-wise-rag-listing/{deptId}', 'WeeklyStatusReportController@getDepartmentWiseRagListing');
    $router->post('department-wise-rag-listing', 'WeeklyStatusReportController@getDepartmentWiseRagListing');

    $router->get('/active-risk/{weekNo}', 'RiskController@activeRisk');
    $router->post('/active-risk', 'RiskController@activeRisk');
    $router->delete('/delete-wsr/{uuid}', 'WeeklyStatusReportController@destroyWsr');
    
    // admin permission group Routes
    $router->group(['middleware' => ['roles:admin']], function () use ($router) {
        $router->put('/update-project-status/{uuid}', 'ProjectController@projectStatusUpdate');
        $router->put('/user-admin-access', 'UserController@update');
        $router->post('/user', 'UserController@store');
        $router->delete('/user-role', 'UserController@destroyUserRole');
        $router->delete('/project/{uuid}', 'ProjectController@destroy');
        $router->put('/edit-requisition-role', 'ResourceRequisitionController@updateRequisitionRole');
        $router->put('/tag/{id}', 'TagController@update');
        $router->delete('/tag/{id}', 'TagController@destroy');

        $router->put('/technology/{id}', 'TechnologyController@update');
        $router->put('/designation/{id}', 'DesignationController@update');
        $router->delete('/designation/{id}', 'DesignationController@destroy');
        $router->put('/project-domain/{id}', 'ProjectDomainController@update');
        $router->delete('/project-domain/{id}', 'ProjectDomainController@destroy');
        $router->get('/show-useractivity/{projectId}', 'UserController@showActivity');
        $router->put('/change-managers/{projectId}', 'ProjectController@changeManagers');
        $router->get('/show-activitylog/{projectId}', 'UserController@activityLogListing');
        //test Mail
        $router->get('/test-mail', 'ProjectController@testMail');


        //Run resource extension cron
        $router->get('/extension-cron', function () {
            Artisan::call('expire-resource-extension:request');
            return 'expire-resource-extension cron run';
        });
        //Run banch resource cron
        $router->get('/bench-resource-cron', function () {
            Artisan::call('bench-resource-weekly:reminder');
            return 'bench-resource-weekly cron run';
        });
        //Run banch resource cron
        $router->get('/de-allocation-cron', function () {
            Artisan::call('resource-de-allocation:reminder');
            return 'resource-de-allocation reminder cron run';
        });

        //Run banch resource cron
        $router->get('/unmapping-reminder-cron', function () {
            Artisan::call('resource-unmapping-reminder-request:reminder');
            return 'resource-unmapping reminder cron run';
        });

        //Run banch resource cron
        $router->get('/de-allocate-resources', function () {
            Artisan::call('de-allocate:resources');
            return 'de-allocate:resources cron run';
        });

        //resource booking mismatch cron
        $router->get('/bookings-mismatch', function () {
            Artisan::call('resource-bookings-mismatched:reminder');
            return 'resource-bookings-mismatch cron run';
        });

        //over-schedule-resource-weekly
        $router->get('/check-over-schedulle', function () {
            Artisan::call('over-schedule-resource-weekly:reminder');
            return 'over-schedule-resource-weekly cron run';
        });

        //resource-delete-redmine:reminder
        $router->get('/check-resource-delete', function () {
            Artisan::call('resource-delete-redmine:reminder');
            return 'resource-delete-redmine:reminder cron run';
        });

        //add-future-booking:members
        $router->get('/add-members-future-booking', function () {
            Artisan::call('add-future-booking:members');
            return 'add-future-booking:members cron run';
        });

        //custom-api-response-request:reminder
        $router->get('/add-custom-api-response', function () {
            Artisan::call('custom-api-response-request:reminder');
            return 'custom-api-response-request:reminder cron run';
        });

         //project-invoice-reminder-ampm:reminder
        // $router->get('/project-invoice-reminder-ampm', function () {
        //     Artisan::call('project-invoice-reminder-ampm:reminder');
        //     return 'project-invoice-reminder-ampm:reminder cron run';
        // });

        // //invoice-status-reports-rm:reminder
        // $router->get('/invoice-status-reports-rm', function () {
        //     Artisan::call('invoice-status-reports-rm:reminder');
        //     return 'invoice-status-reports-rm:reminder cron run';
        // });

        //auto-extension-cron
        $router->get('/auto-extension-cron', function () {
            Artisan::call('auto-extension:resources');
            return 'auto-extension:resources cron run';
        });
        // get redmine users to store in local_users table
        $router->get('/get-redmine-users-cron', function () {
            Artisan::call('get-redmine-users:fetch');
            return 'get-redmine-users:fetch cron run';
        });

        // get redmine users to store in local_users table
        $router->get('/bu-assignment-to-rm', function () {
            Artisan::call('bu-assignment-to-rm:assign');
            return 'bu-assignment-to-rm:assign cron run';
        });

        //
        $router->get('/create-weekly-wsr-cron', function () {
            Artisan::call('create-weekly-wsr:generate');
            return 'create-weekly-wsr:generate cron run';
        });

        $router->put('/update-redmineID/{uuid}', 'ProjectController@updateRedmineIdInPMO');

        $router->put('/update-initiationDate/{uuid}', 'ProjectController@updateInitiationDatePMO');
    });
    // admin,global_operations_sales permission group Routes
    $router->group(['middleware' => ['roles:admin,global_operation,sales,go_team']], function () use ($router) {
        $router->put('/on-hold-action/{projectId}', 'ProjectStatusController@onHoldAction');
    });

    // admin,global_operations_sales permission group Routes
    $router->group(['middleware' => ['roles:admin,global_operation,sales']], function () use ($router) {
        $router->put('/project/{uuid}', 'ProjectController@update');
    });

    // admin,global_operations permission group Routes
    $router->group(['middleware' => ['roles:admin,global_operation,go_team']], function () use ($router) {
        $router->put('/pyramid/{pyramidId}', 'KekaDetailController@update');
        $router->post('/pyramid', 'KekaDetailController@store');
        $router->put('/initiation-approval/{uuid}', 'ProjectController@projectInitiationApproval');
    });

    //project initiation
    $router->group(['middleware' => ['roles:admin,go_team,bu_head,global_operation,sales']], function () use ($router) {
        $router->post('/project', 'ProjectController@store');
        $router->post('/project-draft', 'ProjectController@storeDraft');
    });

    //project request edit
    $router->group(['middleware' => ['roles:admin,go_team,bu_head']], function () use ($router) {
        $router->put('/initiation-request-edit/{uuid}', 'ProjectController@projectInitiationRequestEdit');
    });

    //project request edit
    $router->group(['middleware' => ['roles:admin,go_team,bu_head']], function () use ($router) {
        $router->put('/manager-approval', 'ReportingManagerController@approvalReporting');
        $router->post('/direct-change-reporting', 'ReportingManagerController@directChangeReporting');
        $router->post('/update-active-rm', 'ReportingManagerController@updateActiveRM');
    });

    //admin,resource_manager permission group Route
    $router->group(['middleware' => ['roles:admin,resource_manager']], function () use ($router) {
        $router->put('/de-allocation-map', 'DeAllocationMappingController@mapDeAllocated');
        $router->put('/project-creation', 'ProjectController@projectCreation');
        $router->put('/map-resource', 'ResourceMappingController@mapResource');
        $router->put('/project-close-redmine/{projectRedmineID}', 'ProjectCloseController@mapProjectClose');
    });
    //admin,global_operation,account_manager,project_manager permission group Route
    $router->group(['middleware' => ['roles:admin,global_operation,account_manager,project_manager']], function () use ($router) {
        $router->post('/resource-requisition', 'ResourceRequisitionController@create');
        $router->post('/extension-request', 'ResourceRequisitionController@ResourceExtensionRequest');
        $router->post('/project-closure', 'ProjectClosureController@create');
        $router->put('/project-close/{projectUUID}', 'ProjectCloseController@update');
        $router->put('/on-hold/{projectId}', 'ProjectStatusController@onHoldRequest');
        $router->put('/project-closure/{projectId}', 'ProjectClosureController@update');
        $router->put('/project-restart/{projectId}', 'ProjectStatusController@restart');
        $router->put('/edit-requisition', 'ResourceRequisitionController@editRequisition');
        $router->get('/rca-listing/{projectId}', 'ProjectRcaDetailController@show');
        $router->get('/rca-details/{rcaUuid}', 'ProjectRcaDetailController@viewRcaDetails');
        $router->post('/rca/{uuid}', 'ProjectRcaDetailController@create');
        $router->post('/manager-request', 'ReportingManagerController@reportingRequest');
    });
    //admin,project_manager permission group Route
    $router->group(['middleware' => ['roles:admin,project_manager']], function () use ($router) {
        //Project Status
        $router->put('/project-status/{projectId}', 'ProjectStatusController@update');
    });
});
$router->group(['middleware' => ['authPMO'], 'prefix' => 'v1', 'namespace' => 'Resource'], function () use ($router) {
    $router->get('/experience-count', 'KekaDetailController@getExperienceCount');
    $router->get('/business-units', 'KekaDetailController@Department');
});
